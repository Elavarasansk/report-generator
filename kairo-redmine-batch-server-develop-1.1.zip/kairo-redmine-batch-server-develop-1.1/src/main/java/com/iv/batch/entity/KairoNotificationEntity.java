package com.iv.batch.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "notification")
public class KairoNotificationEntity {
	
	@Id
	private Integer id;
	
	@Column(name = "employee_id")
	private Integer EmployeeId;
	
	@Column(name = "content_id")
	private Integer contentId;
}
