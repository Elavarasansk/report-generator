package com.iv.batch.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.iv.batch.constants.KairoRedmineConstants;
import com.iv.batch.dto.TmpRedmineMetaDataDto;
import com.taskadapter.redmineapi.RedmineException;
import com.taskadapter.redmineapi.RedmineManager;
import com.taskadapter.redmineapi.RedmineManagerFactory;

//<--------- File not used (Reference only) --------->
public class TmpRedmineMetaData {
	
//	@Value("${redmine.url}")
	private String URL = KairoRedmineConstants.URL;

	//	@Value("${redmine.apikey}")
	private String APIKEY = KairoRedmineConstants.APIKEY;
	
	private XSSFWorkbook reportBook = new XSSFWorkbook();
	
	private String outFilePath = System.getProperty("user.dir") + "\\Kairo-Redmine-Report\\RedmineMetaData.xlsx";
	
	public String createRedmineMeta () {
		
		RedmineManager redmineManager = RedmineManagerFactory.createWithApiKey(URL, APIKEY);
		
		 try {
			 SimpleDateFormat simpleDate = new SimpleDateFormat("YYYY-MM-dd");
			 
			 List<TmpRedmineMetaDataDto> metaList = new ArrayList<>();
			redmineManager.getTimeEntryManager().getTimeEntries().stream().forEach(entry -> {
				 
				TmpRedmineMetaDataDto entity = TmpRedmineMetaDataDto.builder()
						.userId(entry.getUserId()).projectName(entry.getProjectName())
						.userName(entry.getUserName()).spentOn(simpleDate.format(entry.getSpentOn()))
						.hours(entry.getHours()).build();
				 
				metaList.add(entity);
			 });
			
			
			XSSFSheet reportSheet = reportBook.createSheet("RedmineMetaData");

			IntStream.range(0, metaList.size()).forEach(index -> {

				TmpRedmineMetaDataDto entity =	metaList.get(index);
				
				Row row = reportSheet.createRow(index);

				createMeta(entity, row);

			});
			
			List<TmpRedmineMetaDataDto> userList = new ArrayList<>();
			
			redmineManager.getUserManager().getUsers().stream().forEach(user -> {
				TmpRedmineMetaDataDto entity = TmpRedmineMetaDataDto.builder()
						.userId(user.getId()).email(user.getMail()).build();
				userList.add(entity);
			});
			
			XSSFSheet reportSheet1 = reportBook.createSheet("userData");
			
			IntStream.range(0, userList.size()).forEach(index -> {

				TmpRedmineMetaDataDto entity =	userList.get(index);
				
				Row row = reportSheet1.createRow(index);

				createMeta(entity, row);

			});
			
			
			generateReport();
			
		} catch (RedmineException e) {
			e.printStackTrace();
		}
		return "Document created Successfully";
		
	}

	private void generateReport() {

		try {
			File dir = new File(outFilePath);

			if(!dir.getParentFile().exists()) {
				dir.getParentFile().mkdirs();
			}

			FileOutputStream outputStream = new FileOutputStream(new File(outFilePath));
			reportBook.write(outputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createMeta(TmpRedmineMetaDataDto entity, Row row) {

		for(int idx = 0; idx < 6; idx++) {
			Cell cell = row.createCell(idx);

			switch(idx) {
			case 0:
				cell.setCellValue(entity.getProjectName());
				break;
			case 1:
				cell.setCellValue(String.valueOf(entity.getUserId()));
				break;
			case 2:
				cell.setCellValue(entity.getUserName());
				break;
			case 3:
				cell.setCellValue(entity.getSpentOn());
				break;
			case 4:
				cell.setCellValue(String.valueOf(entity.getHours()));
				break;
			case 5:
				cell.setCellValue(String.valueOf(entity.getEmail()));
				break;
			}


		}
	}

}
