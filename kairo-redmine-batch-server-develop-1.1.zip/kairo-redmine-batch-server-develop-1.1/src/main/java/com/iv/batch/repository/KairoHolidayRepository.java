package com.iv.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoHolidayEntity;

@Repository
public interface KairoHolidayRepository extends JpaRepository<KairoHolidayEntity, Integer> {

	List<KairoHolidayEntity> findByActiveAndIsInternationnal(Boolean active, Boolean international);

}
