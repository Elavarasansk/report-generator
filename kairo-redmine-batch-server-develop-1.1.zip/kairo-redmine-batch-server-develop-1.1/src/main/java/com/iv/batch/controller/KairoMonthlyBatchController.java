package com.iv.batch.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iv.batch.service.KairoMonthlyBatchService;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class KairoMonthlyBatchController {

	@Autowired
	KairoMonthlyBatchService monthlyService;
	
	@GetMapping("/monthly/batch")
	public Map<String, Object> triggerDailyBatch() {
		return monthlyService.triggerMonthlyBatchApi();
	}
	
}
