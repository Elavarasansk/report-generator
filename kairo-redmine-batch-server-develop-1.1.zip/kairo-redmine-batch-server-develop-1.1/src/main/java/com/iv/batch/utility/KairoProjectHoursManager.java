package com.iv.batch.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.iv.batch.constants.KairoRedmineConstants;
import com.iv.batch.dto.KairoProjectUsersDto;
import com.iv.batch.entity.KairoHolidayEntity;
import com.iv.batch.entity.KairoLeaveRequestEntity;
import com.iv.batch.entity.KairoShiftConfigurationEntity;
import com.iv.batch.entity.KairoSplWorkingEntity;
import com.iv.batch.repository.KairoHolidayRepository;
import com.iv.batch.repository.KairoLeaveRequestRepository;
import com.iv.batch.repository.KairoShiftConfigurationRepository;
import com.iv.batch.repository.KairoSplWorkingRepository;

public class KairoProjectHoursManager {

	KairoLocalDateUtils dateUtils = new KairoLocalDateUtils();

	@Autowired
	KairoShiftConfigurationRepository shiftRepo;

	@Autowired
	KairoHolidayRepository holidayRepo;

	@Autowired
	KairoSplWorkingRepository splWorkDayRepo;

	@Autowired
	KairoLeaveRequestRepository leaveRequestRepo;

	public List<KairoShiftConfigurationEntity> getShiftConfiguration(){
		return shiftRepo.findByActive(true);
	}

	public List<KairoShiftConfigurationEntity> getShiftByApplicantId(Integer applicantId){
		return shiftRepo.findByActiveAndId(true, applicantId);
	}

	public List<KairoHolidayEntity> getAllHolidaysList() {
		return holidayRepo.findByActiveAndIsInternationnal(true, true);
	}

	public List<KairoHolidayEntity> getAllHolidaysByMonth(String month) {
		return holidayRepo.findByActiveAndIsInternationnal(true, true).stream()
				.filter(holiday -> holiday.getMonth().equals(month))
				.collect(Collectors.toList());
	}

	public List<KairoHolidayEntity> getHolidayByDate(LocalDate date) {
		return holidayRepo.findByActiveAndIsInternationnal(true, true).stream()
				.filter(holiday -> dateUtils.compareDateAndLocaDate(holiday.getOccasionDate(), date) == 0)
				.collect(Collectors.toList());
	}

	public List<KairoSplWorkingEntity> getAllSplWorkDayList() {
		return splWorkDayRepo.findByActiveAndIsInternationnal(true, true);
	}

	public List<KairoSplWorkingEntity> getAllSplWorkDaysByMonth(String month) {
		return splWorkDayRepo.findByActiveAndIsInternationnal(true, true).stream()
				.filter(workday -> workday.getMonth().equals(month))
				.collect(Collectors.toList());
	}

	public List<KairoSplWorkingEntity> getSplWorkDayByDate(LocalDate date) {
		return splWorkDayRepo.findByActiveAndIsInternationnal(true, true).stream()
				.filter(workday -> dateUtils.compareDateAndLocaDate(workday.getOccasionDate(), date) == 0)
				.collect(Collectors.toList());
	}

	public List<KairoLeaveRequestEntity> getAllLeaveRequestList() {
		return leaveRequestRepo.findAll().stream()
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.REJETED))
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.WITHDRAWN))
				.collect(Collectors.toList());

	}

	public List<KairoLeaveRequestEntity> getLeaveRequestByApplicant(Integer applicantId) {
		return leaveRequestRepo.findByApplicantId(applicantId).stream()
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.REJETED))
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.WITHDRAWN))
				.collect(Collectors.toList());
	}

	public List<KairoLeaveRequestEntity> getLeaveRequestByApplicantAndDate(Integer applicantId, LocalDate date) {
		return leaveRequestRepo.findByApplicantId(applicantId).stream()
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.REJETED))
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.WITHDRAWN))
				.filter(leave -> dateUtils.compareDateAndLocaDate(leave.getFromDate(), date) == 0 ||
				dateUtils.compareDateAndLocaDate(leave.getToDate(), date) == 0)
				.collect(Collectors.toList());
	}

	//request should have monthly cut off date as last day of month, to avoid merging months.
	public List<KairoLeaveRequestEntity> getAllLeaveRequestByDateRange(LocalDate startDate, LocalDate endDate) {
		return leaveRequestRepo.findAll().stream()
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.REJETED))
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.WITHDRAWN))
				.filter(leave -> dateUtils.compareDateAndLocaDate(leave.getFromDate(), startDate) >= 0)
				.filter(leave -> dateUtils.compareDateAndLocaDate(leave.getToDate(), endDate) <= 0)
				.collect(Collectors.toList());
	}

	//request should have monthly cut off date as last day of month, to avoid merging months.
	public List<KairoLeaveRequestEntity> getLeaveRequestByApplicantAndDateRange(Integer applicantId, LocalDate startDate, LocalDate endDate) {
		return leaveRequestRepo.findByApplicantId(applicantId).stream()
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.REJETED))
				.filter(leave -> !leave.getStatus().equals(KairoRedmineConstants.WITHDRAWN))
				.filter(leave -> dateUtils.compareDateAndLocaDate(leave.getFromDate(), startDate) >= 0)
				.filter(leave -> dateUtils.compareDateAndLocaDate(leave.getToDate(), endDate) <= 0)
				.collect(Collectors.toList());
	}

	public void getMonthlyCompensationHours(KairoProjectUsersDto user) {

		List<KairoSplWorkingEntity> splWorkDays = getAllSplWorkDaysByMonth(LocalDate.now().getMonth().toString().toUpperCase());

		if(!splWorkDays.isEmpty()) {

			splWorkDays.stream().forEach(work -> {
				Float hours = user.getCompensationHours();

				if(work.getShiftIds().contains(user.getShiftId())) {
					if(!work.getNoonType().equals(KairoRedmineConstants.FULLDAY)) {
						hours = hours + user.getHoursPerDay()/2;
					} else {
						hours = hours + user.getHoursPerDay();
					}
					user.setCompensationHours(hours);
				} else {
					System.out.println("Compenstion for " + work.getDayName() + " not applicable to "
							+ user.getApplicantId());
				}
			});
		} else {
			System.out.println("No Compensation for this Month");
		}
	}

	public void getMonthlylUserHolidayHours(KairoProjectUsersDto user) {

		List<KairoHolidayEntity> holidays = getAllHolidaysByMonth(LocalDate.now().getMonth().toString().toUpperCase());

		if(!holidays.isEmpty()) {

			holidays.stream().forEach(holiday -> {
				Float hours = user.getHolidayHours();

				if(holiday.getShiftIds().contains(user.getShiftId())) {
					if(!holiday.getNoonType().equals(KairoRedmineConstants.FULLDAY)) {
						hours = hours + user.getHoursPerDay()/2;
					} else {
						hours = hours + user.getHoursPerDay();
					}
					user.setHolidayHours(hours);
				} else {
					System.out.println("Occasion " + holiday.getDayName() + " not applicable to "
							+ user.getApplicantId());
				}
			});
		} else {
			System.out.println("No Holiday for this Month");
		}
	}

	public void getMonthlyUserEstimationHours(KairoProjectUsersDto user, List<Integer> workingDays) {

		LocalDate today = dateUtils.formatLocalDate(LocalDate.now());
		LocalDate startDate = today.withDayOfMonth(1);
		LocalDate endDate = today.withDayOfMonth(today.lengthOfMonth());

		user.setEstimationHours((dateUtils.countBusinessDaysBetween(startDate, endDate, workingDays)
				* user.getHoursPerDay()) + user.getCompensationHours() - user.getHolidayHours());

	}

	public void getMonthlyUserLeavedHours(KairoProjectUsersDto user) {

		LocalDate today = dateUtils.formatLocalDate(LocalDate.now());
		LocalDate startDate = today.withDayOfMonth(1);
		LocalDate endDate = today.withDayOfMonth(today.lengthOfMonth());

		List<Float> noOfDaysList = new ArrayList<>();

		getLeaveRequestByApplicantAndDateRange(user.getApplicantId(), startDate, endDate)
			.stream().forEach(request -> {

			if(dateUtils.compareDateAndLocaDate(request.getFromDate(), startDate) < 0 &&
					dateUtils.compareDateAndLocaDate(request.getToDate(), endDate) > 0) {

				Float previousLimit = getLimitDays(dateUtils.convertToLocalDate(request.getFromDate()), startDate, true);
				Float nextLimit = getLimitDays(endDate, dateUtils.convertToLocalDate(request.getToDate()), false);

				if(previousLimit > 0) {
					if(request.getStartNoon().equals(KairoRedmineConstants.AFTERNOON)) {
						previousLimit = previousLimit - Float.valueOf("0.5");
					}
				}

				if(nextLimit > 0) {
					if(request.getEndNoon().equals(KairoRedmineConstants.FORENOON)) {
						nextLimit = nextLimit - Float.valueOf("0.5");
					}
				}
				noOfDaysList.add(request.getNoOfDays() - nextLimit - previousLimit);

			} else {
				if(dateUtils.compareDateAndLocaDate(request.getFromDate(), startDate) < 0) {

					Float limitDays = getLimitDays(dateUtils.convertToLocalDate(request.getFromDate()), startDate, true);

					if(limitDays > 0) {
						if(request.getStartNoon().equals(KairoRedmineConstants.AFTERNOON)) {
							limitDays = limitDays - Float.valueOf("0.5");
						}
					}
					noOfDaysList.add(request.getNoOfDays() - limitDays);
				}

				if(dateUtils.compareDateAndLocaDate(request.getToDate(), endDate) > 0) {

					Float limitDays = getLimitDays(endDate, dateUtils.convertToLocalDate(request.getToDate()), false);

					if(limitDays > 0) {
						if(request.getEndNoon().equals(KairoRedmineConstants.FORENOON)) {
							limitDays = limitDays - Float.valueOf("0.5");
						}
					}
					noOfDaysList.add(request.getNoOfDays() - limitDays);
				}
			}

			if(dateUtils.compareDateAndLocaDate(request.getFromDate(), startDate) >= 0 &&
					dateUtils.compareDateAndLocaDate(request.getToDate(), endDate) <= 0) {
				noOfDaysList.add(request.getNoOfDays());
			}

		});

		user.setUserLeaveHours(noOfDaysList.stream().reduce(Float::sum).get());
	}

	private Float getLimitDays(LocalDate fromDate, LocalDate toDate, boolean limitFlg) {

		String month = limitFlg ? fromDate.getMonth().toString().toUpperCase() :
			toDate.getMonth().toString().toUpperCase();

		List<LocalDate> holidays = getAllHolidaysByMonth(month).stream()
				.map(holiday -> dateUtils.convertToLocalDate(holiday.getOccasionDate()))
				.collect(Collectors.toList());

		List<LocalDate> splWorkDays = getAllSplWorkDaysByMonth(month).stream()
				.map(workday -> dateUtils.convertToLocalDate(workday.getOccasionDate()))
				.collect(Collectors.toList());

		return Float.valueOf(dateUtils.countBusinessDaysBetween(fromDate, toDate, 
				getShiftConfiguration().get(0).getWorkingDays(), holidays, splWorkDays));
	}
}
