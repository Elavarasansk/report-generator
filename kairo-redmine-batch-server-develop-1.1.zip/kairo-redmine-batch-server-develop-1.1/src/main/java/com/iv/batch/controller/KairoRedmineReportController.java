package com.iv.batch.controller;

import java.util.HashMap;

import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class KairoRedmineReportController {

	@GetMapping("/report/daily")
	public Map<String, String> generateDailyReport(){
		
		return new HashMap<>();
	}
	
	@GetMapping("/report/monthly")
	public Map<String, String> generateMonthlyReport(){
		
		return new HashMap<>();
	}
	
}
