package com.iv.batch.scheduler;

import org.springframework.scheduling.annotation.Scheduled;

import com.iv.batch.utility.KairoBatchPreRequisite;

public class KairoRedmineBatchScheduler {

	//triggers daily at 10 PM
	@Scheduled(cron = "0 0 22 * * ?")
	public void triggerDailyBatch() {
		KairoBatchPreRequisite preRequisite = new KairoBatchPreRequisite();
		preRequisite.verifyDailyTrigger();
	}

	//triggers monthy last day at 11:55 PM
	@Scheduled(cron = "0 55 23 L * ?")
	public void triggerMonthlyBatch() {
		KairoBatchPreRequisite preRequisite = new KairoBatchPreRequisite();
		preRequisite.verifyMonthlyTrigger();
	}

}
