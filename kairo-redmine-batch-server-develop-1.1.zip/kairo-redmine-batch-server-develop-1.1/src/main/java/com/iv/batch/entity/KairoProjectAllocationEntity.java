package com.iv.batch.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "project_allocation")
public class KairoProjectAllocationEntity {

	@Id
	private Integer id;
	
	private Boolean current;
	
	private String department;
	
	@Column(name = "employee_id")
	private Integer employeeId;
	
	@Column(name = "project_id")
	private Integer projectId;
	
	@Column(name = "mamnager_id")
	private Integer managerId;
	
	@Column(name = "report_to")
	private Integer reporterId;
	
	@Column(name = "city_id")
	private Integer cityId;
	
	@Column(name = "role_id")
	private Integer roleId;
	
}
