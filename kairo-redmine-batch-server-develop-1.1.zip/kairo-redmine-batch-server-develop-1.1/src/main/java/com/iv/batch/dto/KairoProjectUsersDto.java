package com.iv.batch.dto;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class KairoProjectUsersDto {
	
	private String department;
	
	private Integer projectId;
	
	private Integer applicantId;
	
	private Integer roleId;
	
	private Integer managerId;
	
	private Integer cityId;
	
	private Integer redmineUserId;
	
	private String email;
	
	private Integer shiftId;
	
	private Float estimationHours;
	
	private Float actualHours;
	
	private Boolean warning;

	private Float errorHours;
	
	private Date errorDate;

	private String month;
	
	private Float holidayHours;
	
	private Float compensationHours;
	
	private Float userLeaveHours;
	
	private Float hoursPerDay;
}
