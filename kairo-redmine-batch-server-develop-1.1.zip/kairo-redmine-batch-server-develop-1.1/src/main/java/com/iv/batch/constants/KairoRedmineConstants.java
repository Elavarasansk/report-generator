package com.iv.batch.constants;

public class KairoRedmineConstants {
	
	public static final String URL = "http://192.168.41.154/redmine/";
	
	public static final String APIKEY = "56d24c8fc05ec2177e5abe43c81b27923c8c35c0";
	
	public static final String FULLDAY = "FULLDAY";
	
	public static final String FORENOON = "FORENOON";
	
	public static final String AFTERNOON = "AFTERNOON";
	
	public static final String REJETED = "REJETED";
	
	public static final String WITHDRAWN = "WITHDRAWN";

}
