package com.iv.batch.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "redmine_daily_batch")
public class KairoDailyBatchEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	
	private Integer redmineUserId;
	
	@Column(name = "applicant_id")
	private Integer applicantId;
	
	@DateTimeFormat(iso = ISO.DATE)
	private Date spentOn;
	
	private Float spentHours;
	
	private Float estimatedHours;
	
	private Integer warningDays;
	
}
