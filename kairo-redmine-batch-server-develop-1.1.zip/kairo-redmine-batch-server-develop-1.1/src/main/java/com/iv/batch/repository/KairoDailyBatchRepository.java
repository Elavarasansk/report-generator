package com.iv.batch.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoDailyBatchEntity;

@Repository
public interface KairoDailyBatchRepository extends JpaRepository<KairoDailyBatchEntity, Integer> {

	List<KairoDailyBatchEntity> findByEmpIdAndEmailId(int empId, String emialId);
	
	List<KairoDailyBatchEntity> findByProjectManager(String manager);
	
	List<KairoDailyBatchEntity> findBySpentOn(Date spentOn);

	List<KairoDailyBatchEntity> findByApplicantId(Integer id);
}
