package com.iv.batch.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iv.batch.service.KairoDailyBatchService;
import com.iv.batch.utility.TmpRedmineMetaData;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class KairoDailyBatchController {
	
	@Autowired
	KairoDailyBatchService dailyService;
	
	@GetMapping("/daily/batch")
	public Map<String, Object> triggerDailyBatch() {
		return dailyService.triggerDailyBatchApi();		
	}
	
	@GetMapping("/daily/notlogged")
	public Map<String, Object> getNotLoggedUsers() {
		return dailyService.getNotLoggedUsers();
	}
	
	@GetMapping("/redmine/metadata")
	public String createRedmineMetaReport() {
		TmpRedmineMetaData metadata = new TmpRedmineMetaData();
		return metadata.createRedmineMeta();
	}

}
