package com.iv.batch.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoUserEntity;

@Repository
public interface KairoUserRepository extends JpaRepository<KairoUserEntity, Integer> {
	
	List<KairoUserEntity> findByActive(boolean active);
	
	List<KairoUserEntity> findByActiveAndId(boolean active, Integer applicantId);
	
}
