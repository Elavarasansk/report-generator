package com.iv.batch.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "kairo_user")
public class KairoUserEntity {

	@Id
	private Integer id;
	
	private String email;
	
}
