package com.iv.batch.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "redmine_monthly_batch")
public class KairoMonthlyBatchEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	
	private Integer redmineUserId;
	
	@Column(name = "applicant_id")
	private Integer applicantId;
	
	private Float estimatedHours;
	
	private Float compensationHours;
	
	private Float holidayHours;
	
	private Float userLeaveHours;
	
	private Float actualHours;
	
	private Float errorHours;
	
	private String month;

	private Boolean isError;
}
