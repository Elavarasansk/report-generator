package com.iv.batch.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iv.batch.dto.KairoProjectUsersDto;
import com.iv.batch.entity.KairoMonthlyBatchEntity;
import com.iv.batch.repository.KairoMonthlyBatchRepository;
import com.iv.batch.utility.KairoBatchPreRequisite;

@Service
public class KairoMonthlyBatchService {
	
	@Autowired
	KairoMonthlyBatchRepository monthlyRepo;
	
	public Map<String, Object> triggerMonthlyBatch(List<KairoProjectUsersDto> projectUserList) {
		
		List<KairoMonthlyBatchEntity> monthlyEntityList = new ArrayList<>();
		
		projectUserList.stream().forEach(user -> {
			
			KairoMonthlyBatchEntity entity = KairoMonthlyBatchEntity.builder()
					.redmineUserId(user.getRedmineUserId()).applicantId(user.getApplicantId())
					.estimatedHours(user.getEstimationHours()).holidayHours(user.getHolidayHours())
					.compensationHours(user.getCompensationHours()).actualHours(user.getActualHours())
					.errorHours(user.getErrorHours()).isError(user.getErrorHours() > 0)
					.userLeaveHours(user.getUserLeaveHours()).month(user.getMonth()).build();
			
			monthlyEntityList.add(entity);
		});
		
		monthlyRepo.saveAll(monthlyEntityList);
		
		Map<String, Object> result = new HashMap<>();
		result.put("status", "200");
		result.put("message", "Batch Completed");
		return result;
	}
	
	public Map<String, Object> triggerMonthlyBatchApi() {
		return new KairoBatchPreRequisite().verifyMonthlyTrigger();
	}
}
