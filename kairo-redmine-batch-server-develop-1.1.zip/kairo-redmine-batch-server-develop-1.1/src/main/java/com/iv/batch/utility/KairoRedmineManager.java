package com.iv.batch.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.iv.batch.constants.KairoRedmineConstants;
import com.iv.batch.dto.TmpRedmineMetaDataDto;
import com.taskadapter.redmineapi.RedmineException;
import com.taskadapter.redmineapi.RedmineManager;
import com.taskadapter.redmineapi.RedmineManagerFactory;
import com.taskadapter.redmineapi.bean.TimeEntry;
import com.taskadapter.redmineapi.bean.User;

public class KairoRedmineManager {

	//	@Value("${redmine.url}")
	private String URL = KairoRedmineConstants.URL;

	//	@Value("${redmine.apikey}")
	private String APIKEY = KairoRedmineConstants.APIKEY;
	
	@Value("classpath:RedmineMetaData.xlsx")
	Resource resource;

	RedmineManager redmineManager;
	

	public List<TimeEntry> getTimeEntries(LocalDate today) {

		redmineManager = RedmineManagerFactory.createWithApiKey(URL, APIKEY);

		List<TimeEntry> timeEntries =  new ArrayList<>();

		try {

			final Map<String, String> parameter = new HashMap<>();

			parameter.put("from", today.toString());
			parameter.put("to", today.toString());

			timeEntries = redmineManager.getTimeEntryManager().getTimeEntries(parameter).getResults();

		} catch (RedmineException e) {

			e.printStackTrace();
		}

		return timeEntries;

	}

	public List<TimeEntry> getTimeEntriesWithUser(LocalDate today, Integer userId) {

		redmineManager = RedmineManagerFactory.createWithApiKey(URL, APIKEY);

		List<TimeEntry> timeEntries =  new ArrayList<>();

		try {

			final Map<String, String> parameter = new HashMap<>();

			parameter.put("from", today.toString());
			parameter.put("to", today.toString());
			parameter.put("user_id", userId.toString());

			timeEntries = redmineManager.getTimeEntryManager().getTimeEntries(parameter).getResults();

		} catch (RedmineException e) {

			e.printStackTrace();
		}

		return timeEntries;

	}

	public List<TimeEntry> getTimeEntriesRange(LocalDate fromDate, LocalDate toDate) {

		redmineManager = RedmineManagerFactory.createWithApiKey(URL, APIKEY);

		List<TimeEntry> timeEntries =  new ArrayList<>();

		try {

			final Map<String, String> parameter = new HashMap<>();

			parameter.put("from", fromDate.toString());
			parameter.put("to", toDate.toString());

			timeEntries = redmineManager.getTimeEntryManager().getTimeEntries(parameter).getResults();

		} catch (RedmineException e) {

			e.printStackTrace();
		}

		return timeEntries;

	}

	public List<TimeEntry> getTimeEntriesRangeWithUser(LocalDate formDate, LocalDate toDate, Integer userId) {

		redmineManager = RedmineManagerFactory.createWithApiKey(URL, APIKEY);

		List<TimeEntry> timeEntries =  new ArrayList<>();

		try {

			final Map<String, String> parameter = new HashMap<>();

			parameter.put("from", formDate.toString());
			parameter.put("to", toDate.toString());
			parameter.put("user_id", userId.toString());

			timeEntries = redmineManager.getTimeEntryManager().getTimeEntries(parameter).getResults();

		} catch (RedmineException e) {

			e.printStackTrace();
		}

		return timeEntries;

	}

	public List<User> getAllUeserManager() {

		redmineManager = RedmineManagerFactory.createWithApiKey(URL, APIKEY);

		List<User> userManager = new ArrayList<>();

		try {

			userManager = redmineManager.getUserManager().getUsers();

		} catch (RedmineException e) {
			e.printStackTrace();
		} 
		return userManager;

	}
	
	public List<TmpRedmineMetaDataDto> getAllUeserManagerMeta() {

		return readSheet(true);

	}
	
	public List<TmpRedmineMetaDataDto> getTimeEntriesMeta(LocalDate today) {
		
		List<TmpRedmineMetaDataDto> timeEntries = readSheet(false).stream()
				.filter(entry -> LocalDate.parse(entry.getSpentOn().toString()).compareTo(today) == 0)
				.collect(Collectors.toList());

		return timeEntries;

	}
	
	public List<TmpRedmineMetaDataDto> getTimeEntriesRangeMeta(LocalDate formDate, LocalDate toDate) {

		List<TmpRedmineMetaDataDto> timeEntries = readSheet(false).stream()
				.filter(entry -> LocalDate.parse(entry.getSpentOn().toString()).compareTo(formDate) > 0)
				.filter(entry -> LocalDate.parse(entry.getSpentOn().toString()).compareTo(toDate) < 0)
				.collect(Collectors.toList());
			
		return timeEntries;

	}
	
	private List<TmpRedmineMetaDataDto> readSheet(boolean isUser) {
		String filePath  = FileUtils.getTempDirectoryPath()+File.separator+"RedmineMetaData.xlsx";
		List<TmpRedmineMetaDataDto> metaData = new ArrayList<>();
		try {
			if(!(new File(filePath).exists())) {
				File newFile = new File(filePath);
				FileUtils.copyInputStreamToFile(resource.getInputStream(), newFile);
				filePath= newFile.getAbsolutePath();
			}
			
			FileInputStream wkFile = new FileInputStream(filePath);
			Workbook book = WorkbookFactory.create(wkFile);
			
			Sheet sheet = book.getSheetAt(isUser ? 1 : 0);
			
			for(int idx = 0; idx < sheet.getLastRowNum(); idx++) {
				Row row = sheet.getRow(idx);
				
				if(isUser) {
					TmpRedmineMetaDataDto data =  TmpRedmineMetaDataDto.builder()
							.userId(Integer.valueOf(row.getCell(0).toString().replace(".0", "")))
							.email(row.getCell(1).toString())
							.build();
					
					metaData.add(data);
				} else {
					
					@SuppressWarnings("deprecation")
					TmpRedmineMetaDataDto data =  TmpRedmineMetaDataDto.builder()
							.projectName(row.getCell(0).toString())
							.userId(Integer.valueOf(row.getCell(1).toString().replace(".0", "")))
							.userName(row.getCell(2).toString())
							.spentOn(new Date(row.getCell(3).toString()))
							.hours(Float.valueOf(row.getCell(4).toString()))
							.build();
					
					metaData.add(data);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return metaData;
	}
	
}
