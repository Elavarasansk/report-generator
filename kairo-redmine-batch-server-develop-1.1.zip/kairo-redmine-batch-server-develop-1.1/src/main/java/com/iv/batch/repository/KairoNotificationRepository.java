package com.iv.batch.repository;

import com.iv.batch.entity.KairoNotificationEntity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

@Repository
public interface KairoNotificationRepository extends JpaRepository<KairoNotificationEntity, Integer> {

	List<KairoNotificationEntity> findByEmployeeId(Integer employeeId);
}
