package com.iv.batch.entity;

import javax.persistence.Table;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "leave_request")
public class KairoLeaveRequestEntity {
	
	@Id
	private Integer id;
	
	private Date fromDate;
	
	private Date toDate;
	
	private String startNoon;
	
	private String endNoon;
	
	private String type;
	
	private String status;
	
	private Float noOfDays;
	
	@Column(name = "applicant_id")
	private Integer applicantId;

}
