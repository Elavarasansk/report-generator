package com.iv.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoShiftConfigurationEntity;

@Repository
public interface KairoShiftConfigurationRepository  extends JpaRepository<KairoShiftConfigurationEntity, Integer>{

	List<KairoShiftConfigurationEntity> findByActive(boolean active);

	List<KairoShiftConfigurationEntity> findByActiveAndId(boolean active, Integer applicantId);

	
}
