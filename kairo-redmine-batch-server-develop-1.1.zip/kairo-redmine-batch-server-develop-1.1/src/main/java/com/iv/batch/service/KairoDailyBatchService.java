package com.iv.batch.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iv.batch.constants.KairoRedmineConstants;
import com.iv.batch.dto.KairoProjectUsersDto;
import com.iv.batch.entity.KairoDailyBatchEntity;
import com.iv.batch.entity.KairoLeaveRequestEntity;
import com.iv.batch.entity.KairoNotLoggedEntity;
import com.iv.batch.entity.KairoNotificationEntity;
import com.iv.batch.repository.KairoDailyBatchRepository;
import com.iv.batch.repository.KairoLeaveRequestRepository;
import com.iv.batch.repository.KairoNotLoggedRepository;
import com.iv.batch.repository.KairoNotificationRepository;
import com.iv.batch.utility.KairoBatchPreRequisite;
import com.iv.batch.utility.KairoLocalDateUtils;
import com.iv.batch.utility.KairoRedmineManager;
import com.taskadapter.redmineapi.bean.TimeEntry;
import com.taskadapter.redmineapi.bean.User;

@Service
public class KairoDailyBatchService {
	
	@Autowired
	KairoDailyBatchRepository dailyBatchRepo;

	@Autowired
	KairoNotLoggedRepository notLoggedRepo;

	@Autowired
	KairoLeaveRequestRepository leaveRequestRepo;
	
	@Autowired
	KairoNotificationRepository notificationRepo;
	
	KairoLocalDateUtils dateUtils = new KairoLocalDateUtils();
	
	KairoRedmineManager redmineManager = new KairoRedmineManager();

	public void triggerDailyBatch(List<KairoProjectUsersDto> usersList) {
		
		List<User> redmineUsersList = redmineManager.getAllUeserManager();
		
		usersList.stream().forEach(user -> {
			
			List<User> currentUser = redmineUsersList.stream()
					.filter(redmine -> redmine.getMail().equals(user.getEmail()))
					.collect(Collectors.toList());
			
			if(!currentUser.isEmpty()) {
				
				user.setRedmineUserId(currentUser.get(0).getId());
				
				verifyNotLoggedUser(user);
				updateLoggedUser(user);
				
			} else {
				System.out.println("The user " + user.getEmail() + " does not have account in redmine");
			}
		});
	}
	
	private void verifyNotLoggedUser(KairoProjectUsersDto data) {
		
		List<KairoNotLoggedEntity> notLoggedList = notLoggedRepo.findByApplicantId(data.getApplicantId()).stream()
				.sorted(Comparator.comparing(KairoNotLoggedEntity::getErrorDate)).collect(Collectors.toList());
		
		if(!notLoggedList.isEmpty()) {
			
			LocalDate fromDate = dateUtils.convertToLocalDate(notLoggedList.get(0).getErrorDate());
			LocalDate toDate = dateUtils.convertToLocalDate(notLoggedList.get(notLoggedList.size()-1).getErrorDate());
			
			notLoggedList.stream().forEach(notlogged -> {
				
				List<TimeEntry> loggedList = redmineManager.getTimeEntriesRangeWithUser(fromDate, toDate, data.getRedmineUserId()).stream()
						.filter(entry -> dateUtils.compareDateAndDate(entry.getSpentOn(), notlogged.getErrorDate()) == 0)
						.collect(Collectors.toList());
				
				if(!loggedList.isEmpty()) {
					//Logged
					data.setWarning(true);
					executeDailyBatchUser(data, loggedList);
				} else {
					//Not Logged
					data.setErrorDate(notlogged.getErrorDate());
					checkLeaveRequestUser(data);
				}
			});

		}
	}
	
	private void updateLoggedUser(KairoProjectUsersDto data) {
		
		List<TimeEntry> loggedList = redmineManager.getTimeEntriesWithUser(LocalDate.now(), data.getRedmineUserId());
		
		if(!loggedList.isEmpty()) {
			//Logged
			data.setWarning(false);
			executeDailyBatchUser(data, loggedList);
		} else {
			//Not logged
			data.setErrorDate(loggedList.get(0).getSpentOn());
			checkLeaveRequestUser(data);
		}
	}
	
	private void executeDailyBatchUser(KairoProjectUsersDto data, List<TimeEntry> loggedList) {
		
		data.setActualHours(loggedList.stream().map(entry -> entry.getHours()).reduce(Float::sum).get());
		
		if(data.getActualHours() >= data.getEstimationHours()) {
			
			data.setErrorHours(Float.valueOf("0.0"));
			
			KairoDailyBatchEntity dailyEntity = KairoDailyBatchEntity.builder()
					.redmineUserId(data.getRedmineUserId()).applicantId(data.getApplicantId())
					.spentOn(loggedList.get(0).getSpentOn()).spentHours(data.getActualHours())
					.estimatedHours(data.getEstimationHours()).build();
			
			
			if(data.getWarning()) {
				dailyEntity.setWarningDays(dateUtils.getDaysBetween(dailyEntity.getSpentOn(), LocalDate.now()));
				notLoggedRepo.deleteByApplicantIdAndErrorDate(data.getApplicantId(), dailyEntity.getSpentOn());
			} else {
				dailyEntity.setWarningDays(0);
			}
			dailyBatchRepo.save(dailyEntity);
		} else {
			//User logged less than estimated
			data.setErrorHours(data.getEstimationHours() - data.getActualHours());
			data.setErrorDate(loggedList.get(0).getSpentOn());
			
			checkLeaveRequestUser(data);
		}
	}
	
	private void checkLeaveRequestUser(KairoProjectUsersDto data) {
		Float noOfDays;
		String noonType;
		Boolean notLogged = false;
		Float leaveDays = dateUtils.convertHoursToDays(data.getErrorHours());
		//All valid leave request of user
		List<KairoLeaveRequestEntity> leaveRequestList = leaveRequestRepo.findByApplicantId(data.getApplicantId())
				.stream().filter(status -> !status.getStatus().equals(KairoRedmineConstants.REJETED))
				.filter(status -> !status.getStatus().equals(KairoRedmineConstants.WITHDRAWN))
				.collect(Collectors.toList());
		
		if(!leaveRequestList.isEmpty()) {
			//Today present in fromDate
			List<KairoLeaveRequestEntity> leaveRequestFrom = leaveRequestList.stream()
					.filter(request -> dateUtils.compareDateAndDate(request.getFromDate(), data.getErrorDate()) == 0)
					.collect(Collectors.toList());

			if(!leaveRequestFrom.isEmpty()) {
				noOfDays = leaveRequestFrom.get(0).getNoOfDays();
				noonType = leaveRequestFrom.get(0).getStartNoon();
				
				if(noOfDays != leaveDays) {
					if((noonType.equals(KairoRedmineConstants.AFTERNOON) && leaveDays != 0.5) 
							|| (noonType.equals(KairoRedmineConstants.FULLDAY) && leaveDays != 1.0)) {
						notLogged = true;
					}
				}
			}
			
			//Today present in toDate
			List<KairoLeaveRequestEntity> leaveRequestTo = leaveRequestList.stream()
					.filter(request -> dateUtils.compareDateAndDate(request.getToDate(), data.getErrorDate()) == 0)
					.collect(Collectors.toList());
			
			if(!leaveRequestTo.isEmpty()) {
				noOfDays = leaveRequestTo.get(0).getNoOfDays();
				noonType = leaveRequestTo.get(0).getStartNoon();
				
				if(noOfDays != leaveDays) {
					if((noonType.equals(KairoRedmineConstants.FORENOON) && leaveDays != 0.5) 
							|| (noonType.equals(KairoRedmineConstants.FULLDAY) && leaveDays != 1.0)) {
						notLogged = true;
					}
				}
			}
			
			//Today not in from and to dates
			List<KairoLeaveRequestEntity> leaveRequestBetween = leaveRequestList.stream()
					.filter(request -> dateUtils.compareDateAndDate(request.getFromDate(), data.getErrorDate()) < 0
					&& dateUtils.compareDateAndDate(request.getToDate(), data.getErrorDate()) > 0)
					.collect(Collectors.toList());
			
			if(leaveRequestBetween.isEmpty()) {
					notLogged = true;
			}
		} else {
			notLogged = true;
		}
		
		if(notLogged) {
			//Not logged table update
			KairoNotLoggedEntity notLoggedEntity = KairoNotLoggedEntity.builder()
					.redmineUserId(data.getRedmineUserId()).applicantId(data.getApplicantId())
					.errorDate(data.getErrorDate()).estimatedHours(data.getEstimationHours())
					.isFullDay(leaveDays.equals(Float.valueOf("1.0"))).errorHours(data.getErrorHours())
					.isHalfDay(leaveDays.equals(Float.valueOf("0.5"))).build();
			
			//need to check (verify not logged repeated)
			notLoggedRepo.save(notLoggedEntity);

			KairoNotLoggedEntity notLoggedList = notLoggedRepo.findByApplicantIdAndErrorDate(data.getApplicantId(), data.getErrorDate());
			
			KairoNotificationEntity notifyEntity = KairoNotificationEntity.builder()
					.contentId(notLoggedList.getId()).EmployeeId(data.getApplicantId())
					.build();
			
			notificationRepo.save(notifyEntity);
			
		} else {
			System.out.println("User Applied Leave for not Logged Day");
		}
	}
	
	public Map<String, Object> getNotLoggedUsers() {
		
		Map<String, List<KairoNotLoggedEntity>> data = new HashMap<>();
		
		notLoggedRepo.findAll().stream().forEach(entry -> {
			String date = LocalDate.parse(entry.getErrorDate().toString(),DateTimeFormatter.ISO_DATE).toString();
			List<KairoNotLoggedEntity> DBDataEntity = data.get(date);
			
			if(Objects.nonNull(DBDataEntity)) {
				DBDataEntity.add(entry);
			} else {
				List<KairoNotLoggedEntity> entity =  new ArrayList<>();
				entity.add(entry);
				data.put(date, entity);
			}
		});
		
		Map<String, Object> resultMap = new HashMap<>(); 
		resultMap.put("data", data);
		return resultMap;
	}

	public Map<String, Object> triggerDailyBatchApi() {
		return new KairoBatchPreRequisite().verifyDailyTrigger();
	}

}
