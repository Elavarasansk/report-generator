package com.iv.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoProjectAllocationEntity;

@Repository
public interface KairoProjectAllocationRepository extends JpaRepository<KairoProjectAllocationEntity, Integer> {

	List<KairoProjectAllocationEntity> findByCurrent(boolean status);
	
	List<KairoProjectAllocationEntity> findByCurrentAndEmployeeId(boolean status, Integer id);

}
