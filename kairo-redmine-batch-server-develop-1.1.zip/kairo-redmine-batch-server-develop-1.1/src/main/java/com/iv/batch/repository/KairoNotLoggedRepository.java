package com.iv.batch.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoNotLoggedEntity;

@Repository
public interface KairoNotLoggedRepository extends JpaRepository<KairoNotLoggedEntity, Integer> {

	List<KairoNotLoggedEntity> findByErrorDate(Date errorDate);
	
	List<KairoNotLoggedEntity> findByApplicantId(Integer applicantId);
	
	KairoNotLoggedEntity findByApplicantIdAndErrorDate(Integer applicantId, Date errorDate);
	
	void deleteByApplicantIdAndErrorDate(Integer applicantId, Date spentOn);
}
