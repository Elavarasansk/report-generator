package com.iv.batch.utility;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class KairoLocalDateUtils {

	public LocalDate formatLocalDate(LocalDate date) {
		return LocalDate.parse(date.toString(),DateTimeFormatter.ISO_DATE);
	}

	public LocalDate convertToLocalDate(Date date) {
		return LocalDate.parse(date.toString(),DateTimeFormatter.ISO_DATE);
	}

	public Integer compareLocalDates(LocalDate startDate, LocalDate endDate) {
		return startDate.compareTo(endDate);
	}

	public Integer compareDateAndLocaDate(Date startDate, LocalDate endDate) {
		return convertToLocalDate(startDate).compareTo(endDate);
	}

	public Integer compareDateAndDate(Date startDate, Date endDate) {
		return startDate.compareTo(endDate);
	}

	public boolean checkWeekend(LocalDate date) {
		return date.getDayOfWeek().equals(DayOfWeek.SATURDAY) || date.getDayOfWeek().equals(DayOfWeek.SUNDAY);
	}

	public List<LocalDate> getCurrentMonthRange() {
		List<LocalDate> dates = new ArrayList<>();
		LocalDate today = LocalDate.now();
		dates.add(today.withDayOfMonth(1));
		dates.add(today.withDayOfMonth(today.lengthOfMonth()));
		return dates;
	}

	public Boolean checkDailyShift(List<Integer> shiftList) {
		return shiftList.contains(LocalDate.now().getDayOfWeek().getValue());
	}

	public Integer getDaysBetween(Date startDate, LocalDate endDate) {
		return Period.between(convertToLocalDate(startDate), endDate).getDays();
	}

	public Float convertHoursToDays(Float errorHours) {
		return Float.valueOf(errorHours < 4.0 ? "0.5" : "1.0" );
	}

	public Long countBusinessDaysBetween(LocalDate startDate, LocalDate endDate, List<Integer> workingDays) {
		//Doubt need to check isWorkDay predicate
		Predicate<LocalDate> isWorkDay = date -> workingDays.contains(date.getDayOfWeek().getValue());

		Long daysBetween = ChronoUnit.DAYS.between(startDate, endDate) + 1;

		return Stream.iterate(startDate, date -> date.plusDays(1)).limit(daysBetween).filter(isWorkDay).count();
	}

	public Long countBusinessDaysBetween(LocalDate startDate, LocalDate endDate, 
			List<Integer> workingDays, List<LocalDate> holidays, List<LocalDate> splWorkDays) {
		
		Predicate<LocalDate> splWorkDay = date -> splWorkDays.contains(formatLocalDate(date));
		Predicate<LocalDate> isHoliday = date -> holidays.contains(formatLocalDate(date));
		Predicate<LocalDate> isWorkDay = date -> workingDays.contains(date.getDayOfWeek().getValue());

		Long daysBetween = ChronoUnit.DAYS.between(startDate, endDate) + 1;

		return Stream.iterate(startDate, date -> date.plusDays(1)).limit(daysBetween)
				.filter(isHoliday.negate()).filter(splWorkDay).filter(isWorkDay).count();
	}
}
