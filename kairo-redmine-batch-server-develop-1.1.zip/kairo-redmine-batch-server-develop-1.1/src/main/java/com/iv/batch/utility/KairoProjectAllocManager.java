package com.iv.batch.utility;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.iv.batch.entity.KairoProjectAllocationEntity;
import com.iv.batch.entity.KairoUserEntity;
import com.iv.batch.repository.KairoProjectAllocationRepository;
import com.iv.batch.repository.KairoUserRepository;

public class KairoProjectAllocManager {

	@Autowired
	KairoProjectAllocationRepository projectAllocRepo;
	
	@Autowired
	KairoUserRepository userRepo;

	public List<KairoProjectAllocationEntity> getProjectAllocUsers() {
		return projectAllocRepo.findByCurrent(true);
	}

	public List<KairoProjectAllocationEntity> getProjectAllocUser(Integer applicantId) {
		return projectAllocRepo.findByCurrentAndEmployeeId(true, applicantId);
	}

	public List<KairoUserEntity> getAllUsers() {
		return userRepo.findByActive(true);
	}
	
	public List<KairoUserEntity> getUserByApplicantId(Integer applicantId) {
		return userRepo.findByActiveAndId(true,applicantId);
	}

}
