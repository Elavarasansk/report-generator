package com.iv.batch.entity;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat.ISO;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "special_working_day")
public class KairoSplWorkingEntity {
	
	@Id
	private Integer id;
	
	private String occasion;
	
	@DateTimeFormat(iso = ISO.DATE)
	private Date occasionDate;
	
	private Boolean isActive;
	
	private Boolean isInternational;
	
	private String noonType;
	
	private String dayName;
	
	private String dayType;
	
	private Integer year;
	
	private String month;
	
	@Column(name = "shift_ids")
	private List<Integer> shiftIds;

}
