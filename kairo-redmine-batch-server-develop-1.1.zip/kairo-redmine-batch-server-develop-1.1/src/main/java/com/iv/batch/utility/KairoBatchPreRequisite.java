package com.iv.batch.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.iv.batch.constants.KairoRedmineConstants;
import com.iv.batch.dto.KairoProjectUsersDto;
import com.iv.batch.entity.KairoHolidayEntity;
import com.iv.batch.entity.KairoProjectAllocationEntity;
import com.iv.batch.entity.KairoShiftConfigurationEntity;
import com.iv.batch.entity.KairoSplWorkingEntity;
import com.iv.batch.service.KairoDailyBatchService;
import com.iv.batch.service.KairoMonthlyBatchService;

public class KairoBatchPreRequisite {

	@Autowired
	KairoDailyBatchService dailyService;

	@Autowired
	KairoMonthlyBatchService monthlyService;

	KairoLocalDateUtils dateUtils = new KairoLocalDateUtils();

	KairoProjectHoursManager hourManager = new KairoProjectHoursManager();

	public Map<String, Object> verifyDailyTrigger() {

		List<KairoProjectUsersDto> projectUserList = new ArrayList<>();

		KairoProjectAllocManager projectAlloc = new KairoProjectAllocManager();

		if(dateUtils.checkWeekend(LocalDate.now())) {
			//Need to implement shift based special work day
			List<KairoSplWorkingEntity> splWorkDay = hourManager.getSplWorkDayByDate(LocalDate.now());

			if(!splWorkDay.isEmpty()) {
				//fetch users from project allocation
				projectAlloc.getProjectAllocUsers().stream().forEach(user -> {

					KairoProjectUsersDto entity = buildKairoProjectDto(user);

					//Need to implement project allocation based shift config
					List<KairoShiftConfigurationEntity> shift = hourManager.getShiftConfiguration();

					if(!splWorkDay.get(0).getNoonType().equals(KairoRedmineConstants.FULLDAY)) {
						entity.setEstimationHours(shift.get(0).getHoursPerDay()/2);
						entity.setCompensationHours(Float.valueOf("0.5"));
						entity.setShiftId(shift.get(0).getId());
					} else {
						entity.setEstimationHours(shift.get(0).getHoursPerDay());
						entity.setCompensationHours(Float.valueOf("8.0"));
						entity.setShiftId(shift.get(0).getId());
					}

					projectUserList.add(entity);
				});

				//trigger daily batch
				dailyService.triggerDailyBatch(projectUserList);
			} else {
				System.out.println("Weekend");
			}
		} else {
			//Need to implement shift based holidays
			List<KairoHolidayEntity> holiday = hourManager.getHolidayByDate(LocalDate.now());

			if(!holiday.isEmpty()) {
				if(!holiday.get(0).getNoonType().equals(KairoRedmineConstants.FULLDAY)) {

					//fetch users
					projectAlloc.getProjectAllocUsers().stream().forEach(user -> {

						KairoProjectUsersDto entity = buildKairoProjectDto(user);

						//Need to implement project allocation based shift config
						List<KairoShiftConfigurationEntity> shift = hourManager.getShiftConfiguration();

						entity.setHolidayHours(Float.valueOf("0.5"));
						entity.setEstimationHours(shift.get(0).getHoursPerDay()/2);
						entity.setShiftId(shift.get(0).getId());

						projectUserList.add(entity);
					});

					//trigger daily batch
					dailyService.triggerDailyBatch(projectUserList);
				} else {
					System.out.println("Holiday");
				}
			} else {
				//fetch users
				projectAlloc.getProjectAllocUsers().stream().forEach(user -> {

					KairoProjectUsersDto entity = buildKairoProjectDto(user);

					//Need to implement project allocation based shift config
					List<KairoShiftConfigurationEntity> shift = hourManager.getShiftConfiguration();

					entity.setShiftId(shift.get(0).getId());

					projectUserList.add(entity);
				});

				//trigger daily batch
				dailyService.triggerDailyBatch(projectUserList);
			}
		}
		Map<String, Object> result = new HashMap<>();
		result.put("status", "200");
		result.put("message", "Success");
		return result;
	}

	private KairoProjectUsersDto buildKairoProjectDto(KairoProjectAllocationEntity user) {

		KairoProjectAllocManager projectAlloc = new KairoProjectAllocManager();

		KairoProjectUsersDto entity = KairoProjectUsersDto.builder()
				.applicantId(user.getEmployeeId()).projectId(user.getProjectId())
				.email(projectAlloc.getUserByApplicantId(user.getEmployeeId()).get(0).getEmail())
				.department(user.getDepartment()).roleId(user.getRoleId()).warning(false)
				.managerId(user.getManagerId()).cityId(user.getCityId()).build();

		return entity;
	}

	public Map<String, Object> verifyMonthlyTrigger() {

		List<KairoProjectUsersDto> projectUserList = new ArrayList<>();

		KairoProjectAllocManager projectAlloc = new KairoProjectAllocManager();

		projectAlloc.getProjectAllocUsers().stream().forEach(user -> {

			KairoProjectUsersDto entity = buildKairoProjectDto(user);

			//Need to implement project allocation based shift config
			List<KairoShiftConfigurationEntity> shifts = hourManager.getShiftConfiguration();

			entity.setShiftId(shifts.get(0).getId());
			entity.setHoursPerDay(shifts.get(0).getHoursPerDay());
			entity.setMonth(LocalDate.now().getMonth().toString().toUpperCase());

			hourManager.getMonthlyCompensationHours(entity);
			hourManager.getMonthlylUserHolidayHours(entity);
			hourManager.getMonthlyUserEstimationHours(entity, shifts.get(0).getWorkingDays());
			hourManager.getMonthlyUserLeavedHours(entity);

			Float errorHours = entity.getEstimationHours() - entity.getUserLeaveHours() - entity.getActualHours(); 

			entity.setErrorHours(errorHours);

			projectUserList.add(entity);
		});

		return monthlyService.triggerMonthlyBatch(projectUserList);
	}

}
