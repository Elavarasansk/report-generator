package com.iv.batch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.iv.batch.entity.KairoLeaveRequestEntity;

@Repository
public interface KairoLeaveRequestRepository extends JpaRepository<KairoLeaveRequestEntity, Integer> {

	List<KairoLeaveRequestEntity> findByApplicantId(Integer applicantId);
	
}
