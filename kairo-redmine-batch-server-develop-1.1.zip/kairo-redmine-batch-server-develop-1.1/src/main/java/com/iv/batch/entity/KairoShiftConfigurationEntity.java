package com.iv.batch.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Entity
@Table(name = "kairo_shift_configuration")
public class KairoShiftConfigurationEntity {

	@Id
	private Integer id;
	
	private String shiftName;
	
	private Float hoursPerDay;
	
	private List<Integer> workingDays; 
	
	private Boolean active;
	
}
