package com.iv.batch.dto;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

//<--------- File not used (Reference only) --------->

@Data
@Builder
public class TmpRedmineMetaDataDto {
	
	private Integer id;
	
	private Integer userId;
	
	private String projectName;
	
	private String userName;
	
//	private String spentOn;
	private Date spentOn;
	
	private Float hours;
	
	private String email;
	
}
