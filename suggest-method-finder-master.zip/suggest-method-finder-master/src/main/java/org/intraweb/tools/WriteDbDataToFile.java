package org.intraweb.tools;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.bson.Document;
import org.intraweb.tools.dao.MongoConnector;
import org.intraweb.tools.dao.V36F4Fields;
import org.intraweb.tools.entity.F4EventsEntity;

public class WriteDbDataToFile {

    public static void main(String[] args) throws IOException {
        MongoConnector mc = new MongoConnector();
        List<Document> v36MethodDocs =  mc.fetchV36MethodData();
        List<F4EventsEntity> f4EventsList = new ArrayList<>();

        f4EventsList = v36MethodDocs.stream().map(record -> F4EventsEntity.builder()
                ._id(record.get("_id"))
                .fileName(record.getString(V36F4Fields.FILE_NAME))
                .searchCodeField(record.getString(V36F4Fields.SEARCH_CODE_FIELD))
                .componentType(record.getString(V36F4Fields.COMPONENT_TYPE))
                .onF4Event(record.getString(V36F4Fields.ON_F4))
                .onF4Method(record.getString(V36F4Fields.ON_F4_METHOD))
                .onExit(record.getString(V36F4Fields.ON_EXIT))
                .build()).collect(Collectors.toList());
        
        WriteDbDataToFile writer = new WriteDbDataToFile();
//        writer.writeToFile(f4EventsList);
        writer.writeToWorkSheet(f4EventsList);
    }
    
    private void writeToWorkSheet(List<F4EventsEntity> onF4MethodsEntityList)
            throws IOException {
        Workbook vulnerabilityCheckerWorkbook = WorkbookFactory.create(true);
        Sheet catchBlockSheet = vulnerabilityCheckerWorkbook.createSheet("Company_client_OnF4");
        setSheetProperties(catchBlockSheet);

        CellStyle wrapStyle = vulnerabilityCheckerWorkbook.createCellStyle();
        wrapStyle.setWrapText(true);

        int rowNum = 0;
        writeHeader(catchBlockSheet.createRow(rowNum++));
        for (F4EventsEntity x : onF4MethodsEntityList) {
            writeBody(x, catchBlockSheet.createRow(rowNum++), wrapStyle);
        }

        try (FileOutputStream out = new FileOutputStream(
                new File("D:\\Company_client_OnF4.xlsx"))) {
            vulnerabilityCheckerWorkbook.write(out);
        }
    }

    private void writeBody(F4EventsEntity x, Row columnRow, CellStyle wrapStyle) {
        int cellIdx = 0;
        columnRow.createCell(cellIdx++).setCellValue(columnRow.getRowNum());
        columnRow.createCell(cellIdx++).setCellValue(x.getFileName());
        columnRow.createCell(cellIdx++).setCellValue(x.getSearchCodeField());
        columnRow.createCell(cellIdx++).setCellValue(x.getComponentType());
        columnRow.createCell(cellIdx++).setCellValue(x.getOnF4Event());
        {
            Cell codeBlock = columnRow.createCell(cellIdx++);
            codeBlock.setCellStyle(wrapStyle);
            
            try {
                codeBlock.setCellValue(x.getOnF4Method());
            } catch(IllegalArgumentException e) {
                codeBlock.setCellValue("Invalid");
            }
        }
    }

    private void writeHeader(Row headerRow) {
        int cellIdx = 0;
        headerRow.createCell(cellIdx++).setCellValue("#");
        headerRow.createCell(cellIdx++).setCellValue(V36F4Fields.FILE_NAME.toUpperCase());
        headerRow.createCell(cellIdx++).setCellValue(V36F4Fields.SEARCH_CODE_FIELD.toUpperCase());
        headerRow.createCell(cellIdx++).setCellValue(V36F4Fields.COMPONENT_TYPE.toUpperCase());
        headerRow.createCell(cellIdx++).setCellValue(V36F4Fields.ON_F4.toUpperCase());
        headerRow.createCell(cellIdx++).setCellValue(V36F4Fields.ON_F4_METHOD.toUpperCase());
    }

    private void setSheetProperties(Sheet catchBlockSheet) {
        int colIndex = 0;
        catchBlockSheet.setColumnWidth(colIndex++, 2000);
        catchBlockSheet.setColumnWidth(colIndex++, 15000);
        catchBlockSheet.setColumnWidth(colIndex++, 3000);
        catchBlockSheet.setColumnWidth(colIndex++, 1500);
        catchBlockSheet.setColumnWidth(colIndex++, 20000);
        catchBlockSheet.setColumnWidth(colIndex++, 1500);
        catchBlockSheet.setAutoFilter(CellRangeAddress.valueOf("B1:F1"));
        //catchBlockSheet.setDefaultRowHeight((short)900);
        //catchBlockSheet.setHorizontallyCenter(true);
    }

    String nextCol = "*7Yh*";
    private void writeToFile(List<F4EventsEntity> f4EventsList) {
        String suggestListHeader = "FileName *7Yh* SearchCodeName *7Yh* ComponentType *7Yh* OnF4 *7Yh* OnF4Method";
        StringBuilder suggestBody = new StringBuilder();
        suggestBody.append(suggestListHeader).append("\r\n")
        .append(f4EventsList.stream().map(event -> event.getFileName()+nextCol+event.getSearchCodeField()+nextCol+
                event.getComponentType()+nextCol+event.getOnF4Event()+nextCol+event.getOnF4Method()).collect(Collectors.joining("\r\n")));

        writeToCsvFile("D:\\Vairavan\\", "OnF4Method", suggestBody.toString());
    }

    private void writeToCsvFile(String filePath, String fileName, String rows){
        try {
            File file = new File(filePath + fileName + ".csv");
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            if (!file.exists()) {
                file.createNewFile();

            }
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
            pw.print(rows);
            pw.println();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
