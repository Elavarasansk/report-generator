package org.intraweb.tools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.intraweb.tools.dao.MongoConnector;
import org.intraweb.tools.entity.F4EventsEntity;

public class ExtractEditcomponents {

    static String[] repoPath = {"C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cac\\company_client\\delphi\\","C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cam\\company_client\\delphi\\CAM\\","C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cbm\\company_client\\delphi\\CBM\\","C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-ccm\\company_client\\delphi\\CCM\\","C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cfm\\company_client\\delphi\\CFM\\"};
    String editListType = "D:\\Nayana\\Projects\\suggest-finder\\src\\main\\resources";
    final String OBJECT = "object"; 
    final String INHERITED = "inherited";
    final String ONF4 = "OnF4";
    final String ONEXIT = "OnExit";

    public static void main(String[] args) {
        List<File> allFilesDetailsList = new ArrayList<File>();
        ExtractEditcomponents extractSpEdit = new ExtractEditcomponents();
        Arrays.asList(repoPath).forEach(repo -> {
            System.out.println("Processing------->       "+repo);
            extractSpEdit.getFilesPath(repo, allFilesDetailsList);
        });
        List<F4EventsEntity> f4EventsList = allFilesDetailsList.stream().flatMap(dfmFile -> extractSpEdit.dfmFileReader(dfmFile).stream())
                .collect(Collectors.toList());
        
        MongoConnector mc = new MongoConnector();
//        mc.persistF4ToCollection(f4EventsList,"v40");
        mc.persistF4ToCollection(f4EventsList,"v36");
//        extractSpEdit.writeToFile(f4EventsList);
    }

    private List<File> getFilesPath(String mainDirectoryPath, List<File> allFilesDetailsList) {
        File readFile = new File(mainDirectoryPath);
        File[] allFilesFromDirectory = readFile.listFiles();
        for (File filesNames : allFilesFromDirectory) {
            boolean isDir = filesNames.isDirectory();
            boolean isFile = filesNames.isFile();
            if (isFile) {
                if (filesNames.getPath().toString().endsWith("dfm")) {
                    allFilesDetailsList.add(filesNames);
                }
            } else if (isDir) {
                getFilesPath(filesNames.getAbsolutePath(), allFilesDetailsList);
            }
        }
        return allFilesDetailsList;
    }

    private List<F4EventsEntity> dfmFileReader(File dfmFile) {
        System.out.println("Processing------->       "+dfmFile.getPath());
        BufferedReader dfmBufferReader;
        List<F4EventsEntity> f4EventsList = new ArrayList<>();

        try {
            dfmBufferReader = new BufferedReader(new FileReader(dfmFile));
            String dfmBuffer;
            boolean captureStarted = false;

            F4EventsEntity f4EventBuilder = F4EventsEntity.builder().build();

            while((dfmBuffer = dfmBufferReader.readLine())!=null) {
                String line = dfmBuffer.trim()/*.toLowerCase()*/;
                String[] declarationArr = {};
                boolean hasDeclaration = line.contains(OBJECT) || line.contains(INHERITED);

                if(captureStarted && hasDeclaration) {
                    if(f4EventBuilder.getOnF4Event() != null || f4EventBuilder.getOnExit() != null) {
                        f4EventsList.add(F4EventsEntity.builder()
                                .fileName(dfmFile.getPath())
                                .searchCodeField(f4EventBuilder.getSearchCodeField())
                                .componentType(f4EventBuilder.getComponentType())
                                .onF4Event(f4EventBuilder.getOnF4Event())
                                .onExit(f4EventBuilder.getOnExit())
                                .build());
                    }
                    f4EventBuilder = F4EventsEntity.builder().build();
                }
                if(hasDeclaration) {
                    declarationArr = line.replace(OBJECT,"").replace(INHERITED, "").trim().split(":");
                    if(declarationArr.length != 2) {
                        continue;
                    }
                    captureStarted = true;
                    f4EventBuilder.setSearchCodeField(declarationArr[0].trim());
                    f4EventBuilder.setComponentType(declarationArr[1].trim());
                    continue;
                }

                String[] compProps = line.split("=");
                if(compProps.length != 2) {
                    continue;
                }
                if(compProps[0].trim().equals(ONF4)) {
                    f4EventBuilder.setOnF4Event(compProps[1].trim());
                }
                if(compProps[0].trim().equals(ONEXIT)) {
                    f4EventBuilder.setOnExit(compProps[1].trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return f4EventsList;
    }


    private void findF4Events(String line, boolean captureStarted) {
        String[] declarationArr = {};
        if(line.contains(OBJECT) || line.contains(INHERITED)) {
            captureStarted = true;
            declarationArr = line.replace(OBJECT,"").replace(INHERITED, "").trim().split(":");
        }
        F4EventsEntity.builder()
        .searchCodeField(declarationArr[0])
        .componentType(declarationArr[1])
        .build();
    }

    private void writeToFile(List<F4EventsEntity> f4EventsList) {
        String suggestListHeader = "FileName, SearchCodeName,ComponentType,OnF4,OnExit";
        StringBuilder suggestBody = new StringBuilder();
        suggestBody.append(suggestListHeader).append("\n")
        .append(f4EventsList.stream().map(event -> event.getFileName()+","+event.getSearchCodeField()+","+
                event.getComponentType()+","+event.getOnF4Event()+","+event.getOnExit()).collect(Collectors.joining("\n")));

        writeToCsvFile("D:\\Vairavan\\", "OnF4suggest", suggestBody.toString());
        System.out.println(suggestBody);
    }

    public void writeToCsvFile(String filePath, String fileName, String rows){
        try {
            File file = new File(filePath + fileName + ".csv");
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            if (!file.exists()) {
                file.createNewFile();

            }
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
            pw.print(rows);
            pw.println();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
