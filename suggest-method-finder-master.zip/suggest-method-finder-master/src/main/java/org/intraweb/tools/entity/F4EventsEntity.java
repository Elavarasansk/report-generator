package org.intraweb.tools.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class F4EventsEntity {

    private Object _id;
    private String fileName;
    private String searchCodeField;
    private String componentType;
    private String onF4Event;
    private String onExit;
    private String onF4Method;
    private String onExitMethod;
    
}
