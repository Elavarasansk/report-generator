package org.intraweb.tools.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.intraweb.tools.entity.F4EventsEntity;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoConnector {

    MongoClient mongo;
    MongoDatabase intraWebDb;
    
    String V36_COLLECTION_NAME = "COMPANY_CLIENT_F4";
    MongoCollection<Document> v36Collection;
    
    String V40_COLLECTION_NAME = "HUE_CLIENT_F4";
    MongoCollection<Document> v40Collection;
    
    String V36_METHOD_COLLECTION_NAME = "COMPANY_CLIENT_F4_METHOD";
    MongoCollection<Document> v36MethodCollection;
    
    String V40_METHOD_COLLECTION_NAME = "HUE_CLIENT_F4_METHOD";
    MongoCollection<Document> v40MethodCollection;

    public MongoConnector() {
        this.mongo = new MongoClient( "localhost" , 27017 );
        this.intraWebDb = mongo.getDatabase("intraweb_tools");

        this.v36Collection = intraWebDb.getCollection(V36_COLLECTION_NAME);
        this.v40Collection = intraWebDb.getCollection(V40_COLLECTION_NAME);
        
        this.v36MethodCollection = intraWebDb.getCollection(V36_METHOD_COLLECTION_NAME);
        this.v40MethodCollection = intraWebDb.getCollection(V40_METHOD_COLLECTION_NAME);
        
        if(v36MethodCollection == null) {
            intraWebDb.createCollection(V36_METHOD_COLLECTION_NAME);
            this.v36MethodCollection = intraWebDb.getCollection(V36_METHOD_COLLECTION_NAME);
        }
        
        if(v40MethodCollection == null) {
            intraWebDb.createCollection(V40_METHOD_COLLECTION_NAME);
            this.v40MethodCollection = intraWebDb.getCollection(V40_METHOD_COLLECTION_NAME);
        }
        
        if(v36Collection == null) {
            intraWebDb.createCollection(V36_COLLECTION_NAME);
            this.v36Collection = intraWebDb.getCollection(V36_COLLECTION_NAME);
        }
        
        if(v40Collection == null) {
            intraWebDb.createCollection(V40_COLLECTION_NAME);
            this.v40Collection = intraWebDb.getCollection(V40_COLLECTION_NAME);
        }
    }

    public void persistF4ToCollection(List<F4EventsEntity> f4EventsList, String type) {
        List <Document> v36DocumentList = new ArrayList<Document>();
        f4EventsList.forEach(f4Events -> {
            Document document = new Document(V36F4Fields.FILE_NAME, f4Events.getFileName())
            .append(V36F4Fields.ID, f4Events.get_id())        
            .append(V36F4Fields.SEARCH_CODE_FIELD, f4Events.getSearchCodeField())
            .append(V36F4Fields.COMPONENT_TYPE, f4Events.getComponentType()) 
            .append(V36F4Fields.ON_F4, f4Events.getOnF4Event()) 
            .append(V36F4Fields.ON_EXIT, f4Events.getOnExit());
            v36DocumentList.add(document);
        });
        
        if(type.equals("v40")) {
            v40Collection.insertMany(v36DocumentList);
        } else {
            v36Collection.insertMany(v36DocumentList);
        }
    }
    
    public void insertF4MethodToCollection(List<F4EventsEntity> f4EventsList, String type) {
        List <Document> documentList = new ArrayList<Document>();
        f4EventsList.forEach(f4Events -> {
            Document document = new Document(V36F4Fields.FILE_NAME, f4Events.getFileName())
            .append(V36F4Fields.ID, f4Events.get_id())        
            .append(V36F4Fields.SEARCH_CODE_FIELD, f4Events.getSearchCodeField())
            .append(V36F4Fields.COMPONENT_TYPE, f4Events.getComponentType()) 
            .append(V36F4Fields.ON_F4, f4Events.getOnF4Event()) 
            .append(V36F4Fields.ON_EXIT, f4Events.getOnExit())
            .append(V36F4Fields.ON_F4_METHOD, f4Events.getOnF4Method());
            documentList.add(document);
        });
        
        if(type.equals("v40")) {
            v40MethodCollection.insertMany(documentList);
        } else {
            v36MethodCollection.insertMany(documentList);
        }
    }
    
    public List<Document> fetchV36Data() {
        List<Document> iterDoc = v36Collection.find().into(new ArrayList<Document>()); 
        return iterDoc;
    }
    
    public List<Document> fetchV40Data() {
        List<Document> iterDoc = v40Collection.find().into(new ArrayList<Document>()); 
        return iterDoc;
    }
    
    public List<Document> fetchV36MethodData() {
        List<Document> iterDoc = v36MethodCollection.find().into(new ArrayList<Document>()); 
        return iterDoc;
    }
    
    public List<Document> fetchV40MethodData() {
        List<Document> iterDoc = v40MethodCollection.find().into(new ArrayList<Document>()); 
        return iterDoc;
    }

}
