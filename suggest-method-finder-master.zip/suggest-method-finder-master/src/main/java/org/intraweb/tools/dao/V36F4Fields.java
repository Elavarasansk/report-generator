package org.intraweb.tools.dao;


public class V36F4Fields {
    
    public static String ID="_id";
    public static String FILE_NAME="fileName";
    public static String SEARCH_CODE_FIELD="searchCodefield";
    public static String COMPONENT_TYPE="componentType";
    public static String ON_F4="onF4";
    public static String ON_EXIT="onExit";
    public static String ON_F4_METHOD="onF4Method";
    public static String ON_EXIT_METHOD="onExitMethod";

}
