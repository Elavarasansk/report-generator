package org.intraweb.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.bson.Document;
import org.intraweb.tools.dao.MongoConnector;
import org.intraweb.tools.dao.V36F4Fields;
import org.intraweb.tools.entity.F4EventsEntity;

public class ExtractOnF4Function {

    String v36BasicInfo = "D:\\Nayana\\Projects\\suggest-finder\\src\\main\\resources\\CompanyClient-OnF4.csv";
    String PROCEDURE = "procedure";

    public static void main(String[] args) {
        new ExtractOnF4Function().readOnV36F4Info();
    }

    public void readOnV36F4Info() {
        MongoConnector mc = new MongoConnector();
        List<Document> v36Docs =  mc.fetchV36Data();
        List<F4EventsEntity> f4EventsList = new ArrayList<>();

        f4EventsList = v36Docs.stream().map(record -> F4EventsEntity.builder()
                ._id(record.get("_id"))
                .fileName(record.getString(V36F4Fields.FILE_NAME))
                .searchCodeField(record.getString(V36F4Fields.SEARCH_CODE_FIELD))
                .componentType(record.getString(V36F4Fields.COMPONENT_TYPE))
                .onF4Event(record.getString(V36F4Fields.ON_F4))
                .onExit(record.getString(V36F4Fields.ON_EXIT))
                .build()).collect(Collectors.toList());

        Map<String, List<F4EventsEntity>> fileMappedData = f4EventsList.stream().collect(Collectors.groupingBy(F4EventsEntity::getFileName, Collectors.toList()));

        long count=0;
        List<F4EventsEntity> f4IdentifiedList = new ArrayList<>();
        for(Entry<String, List<F4EventsEntity>> record: fileMappedData.entrySet()) {
            System.out.println(count++ +"------Processing-------"+record.getKey());
            f4IdentifiedList.addAll(processMethodsFromF4(record.getKey(), record.getValue()));
        }
        mc.insertF4MethodToCollection(f4IdentifiedList,"v36");
    }

    private List<F4EventsEntity> processMethodsFromF4(String fileName, List<F4EventsEntity> f4EntityList) {
        if(!fileName.endsWith("dfm")) {
            return new ArrayList<>();
        }
        String pasFileName = fileName.replace("dfm", "pas");
        String[] splittedPath = pasFileName.split("\\\\");

        File pasFile = new File(pasFileName);
        f4EntityList = f4EntityList.stream().filter(f4 -> f4.getOnF4Event()!=null).collect(Collectors.toList());

        f4EntityList.forEach(f4Event -> {
            try {
                String pasBuffer;
                int intermediateBegin=0;
                boolean captureStarted=false, beginStarted=false;
                BufferedReader pasBufferReader = new BufferedReader(new FileReader(pasFile));
                String classFileName = "T"+splittedPath[splittedPath.length - 1].replace("pas", "");

                StringBuilder sb = new StringBuilder();

                Map<String, String> onF4Method = new HashMap<String, String>(); 

                while((pasBuffer = pasBufferReader.readLine())!=null) {
                   boolean checkComments = pasBuffer.trim().startsWith("//");
                   if(checkComments) {
                       continue;
                   }

                    if(pasBuffer.contains("=") && pasBuffer.contains("class(")) {
                        String[] splittedName = pasBuffer.split("=");
                        classFileName = splittedName[0].trim();
                    }

                    if(pasBuffer.contains(PROCEDURE) &&
                            pasBuffer.contains(classFileName) && pasBuffer.contains(f4Event.getOnF4Event())){
                        captureStarted = true;
                    }

                    if(!captureStarted) {
                        continue;
                    }
                    sb.append(pasBuffer).append("\r\n");
                    
                    
                    if(pasBuffer.contains("begin")) {
                        
                        if(pasBuffer.contains("end")) {
                            continue;
                        }
                        
                        if(beginStarted) {
                            intermediateBegin++;
                            continue;
                        }
                        
                        if(intermediateBegin==0) {
                            beginStarted=true;
                            continue;
                        }

                    }

                    if(pasBuffer.contains("try")) {
                        if(beginStarted) {
                            intermediateBegin++;
                            continue;
                        }
                    }

                    if(pasBuffer.contains("end;")) {
                        if(intermediateBegin == 0) {
                            f4Event.setOnF4Method(new String(sb.toString()));
                            sb = new StringBuilder();
                            captureStarted = false;
                            beginStarted = false;
                            continue;
                        }
                        intermediateBegin--;
                    }
                }
            }catch(IOException e) {
            }
        });
        return f4EntityList;

    }

}








