package org.com.tools.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.com.tools.entity.LeaveRequestFragmentsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LeaveRequestFragmentsRepository extends JpaRepository<LeaveRequestFragmentsEntity, Integer>{

	List<LeaveRequestFragmentsEntity> findAllByLeaveRequestIdIn(List<Integer> leaveRequestIdList);
	
	List<LeaveRequestFragmentsEntity> findAllByIdIn(List<Integer> leaveRequestFragmentIdList);
	
	@Query(value="SELECT * FROM leave_request_fragments WHERE leave_request_id IN "
			+ "(SELECT id FROM leave_request WHERE applicant_id IN (SELECT id FROM kairo_user WHERE id=:id) "
			+ "AND status NOT IN ('WITHDRAWN','REJECTED')) AND fragmentDate=:fragmentDate", nativeQuery = true)
	LeaveRequestFragmentsEntity getUserLeaveRequestsOnDate(@Param("id") Integer id,
			@Param("fragmentDate") LocalDate fragmentDate);
	
	List<LeaveRequestFragmentsEntity> findAllByFragmentDateAndIsConflict(Date date, boolean isConflict);

}
