package org.com.tools.dto;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LeaveLogTimeConflictUserDto {

	private Date date;
	private Integer applicantId;
}
