package org.com.tools.utility;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.com.tools.entity.LeaveRequestEntity;
import org.com.tools.enums.LeaveStatus;
import org.com.tools.repository.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * LeaveRequestUtils utility for leave request grouping
 *
 */
@Component
public class LeaveRequestUtils {

	@Autowired
	private LeaveRequestRepository leaveRequestRepo;

	/**
	 * getLeaveReqForDateGroupByKairoUserId gets leave request for leave_request table for date param and
	 * groups by kairo_user_id and return the map.
	 * @param date
	 * @return List of leave request grouped by kairo_user_id 
	 */
	public Map<Integer, List<LeaveRequestEntity>> getLeaveReqForDateGroupByKairoUserId(LocalDate date) {
		List<LeaveRequestEntity> leaveRecList = leaveRequestRepo.findAll().stream()
				.filter(rec -> !rec.getStatus().equalsIgnoreCase(LeaveStatus.REJECTED.toString()) 
						&& !rec.getStatus().equalsIgnoreCase(LeaveStatus.WITHDRAWN.toString()))
				.collect(Collectors.toList());
		Date today = Date.valueOf(date);
		Map<Integer, List<LeaveRequestEntity>> resMap = leaveRecList.stream().filter(rec -> 
			rec.getFromDate().equals(today) || rec.getToDate().equals(today)
				|| (DateUtils.isFilterDateBetween(rec.getFromDate(), rec.getToDate(), today)))
				.collect(Collectors.groupingBy(LeaveRequestEntity::getApplicantId));
		return resMap;
	}

	/**
	 * getLeaveReqBtwnDatesGroupByKairoUserId gets leave request for leave_request table for date range passed as param and
	 * groups by kairo_user_id and return the map.
	 * @param startDate
	 * @param endDate
	 * @return List of leave request grouped by kairo_user_id 
	 */
	public Map<Integer, List<LeaveRequestEntity>> getLeaveReqBtwnDatesGroupByKairoUserId(LocalDate startDate, LocalDate endDate) {
		List<LeaveRequestEntity> leaveRecList = leaveRequestRepo.findAll().stream()
				.filter(rec -> !rec.getStatus().equalsIgnoreCase(LeaveStatus.REJECTED.toString())
						&& !rec.getStatus().equalsIgnoreCase(LeaveStatus.WITHDRAWN.toString()))
				.collect(Collectors.toList());
		Date startDay = Date.valueOf(startDate);
		Date endDay = Date.valueOf(endDate);
		Map<Integer, List<LeaveRequestEntity>> resMap = leaveRecList.stream().filter(rec ->
					rec.getFromDate().equals(startDay) || rec.getToDate().equals(startDay)
					|| rec.getFromDate().equals(endDay) || rec.getToDate().equals(endDay)
					|| rec.getFromDate().after(startDay) && rec.getFromDate().before(endDay)
					|| rec.getToDate().after(startDay) && rec.getToDate().before(endDay)
					|| startDay.after(rec.getFromDate()) && startDay.before(rec.getToDate())
					|| endDay.after(rec.getFromDate()) && endDay.before(rec.getToDate()))
				.collect(Collectors.groupingBy(LeaveRequestEntity::getApplicantId));
		return resMap;
	}

	/**
	 * getUserLeaveRequest checks and gets leave request of user for flaw date and groups by kairo_user_id
	 * @param userLeaveCheckMap (list of not logged user grouped by flaw date)
	 * @return List of leave request grouped by kairo_user_id 
	 */
	public Map<Integer, List<LeaveRequestEntity>> getUserLeaveRequest(Map<LocalDate, List<Integer>> userLeaveCheckMap) {
		Map<Integer, List<LeaveRequestEntity>> resMap = new HashMap<>();
		List<LeaveRequestEntity> leaveRecList = leaveRequestRepo.findAll().stream()
				.filter(rec -> !rec.getStatus().equalsIgnoreCase(LeaveStatus.REJECTED.toString())
						&& !rec.getStatus().equalsIgnoreCase(LeaveStatus.WITHDRAWN.toString()))
				.collect(Collectors.toList());

		List<LeaveRequestEntity> userLeaveRecList = new ArrayList<>();

		userLeaveCheckMap.entrySet().stream().forEach(entry -> {
			Date flawDate = Date.valueOf(entry.getKey());
			userLeaveRecList.addAll(leaveRecList.stream().filter(rec -> rec.getFromDate().equals(flawDate)
					|| rec.getToDate().equals(flawDate)
					|| (DateUtils.isFilterDateBetween(rec.getFromDate(), rec.getToDate(), 
							new java.util.Date(flawDate.getTime()))))
					.filter(user -> entry.getValue().contains(user.getApplicantId()))
					.collect(Collectors.toList()));
		});
		if(!userLeaveRecList.isEmpty()) {
			resMap = userLeaveRecList.stream().collect(Collectors.groupingBy(LeaveRequestEntity::getApplicantId));
		}
		return resMap;
	}
}
