package org.com.tools.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.entity.LeaveLogtimeConflictEntity;
import org.com.tools.entity.LeaveRequestEntity;
import org.com.tools.entity.LeaveRequestFragmentsEntity;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.enums.NoonType;
import org.com.tools.repository.LeaveLogTimeConflictRepository;
import org.com.tools.repository.LeaveRequestFragmentsRepository;
import org.com.tools.repository.LeaveRequestRepository;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.utility.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmergencyHolidayBatchService {

	
	@Autowired
	RedmineLogReportService logReportService;
	
	@Autowired
	LeaveRequestFragmentsRepository leaveFragmentRepo;
	
	@Autowired
	LeaveLogTimeConflictRepository leaveConflictRepo;
	
	@Autowired
	LeaveRequestRepository leaveRequestRepo;
	
	@Autowired
	RedmineConsolidatedLogRepository redmineConsolidatedRepo;
	
	@Autowired
	KairoDailyBatchService dailyBatchService;
	
	public Map<String, String> triggerEmergencyHolidayBatch(String holidayDate) {
		Map<String, String> responseMap = new HashMap<>();
		try {
			LocalDate executionDate = LocalDate.parse(holidayDate);
			logReportService.getRedmineLogReport(executionDate);
			updateConflictRequest(DateUtils.convertToUtilDate(executionDate));
			dailyBatchService.triggerDailyBatch(executionDate);
			responseMap.put("statusCode", "200");
			responseMap.put("message", "EMERGENCY HOLIDAY BATCH EXECUTED SUCCESSFULLY");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
		return responseMap;
	}
	
	private void updateConflictRequest(Date holidayDate) {
		 List<LeaveRequestFragmentsEntity> fragmentList = leaveFragmentRepo.findAllByFragmentDateAndIsConflict(holidayDate, true);
		 
		 List<Integer> leaveRequestIdList = fragmentList.stream().map(LeaveRequestFragmentsEntity::getLeaveRequestId)
				 .distinct().collect(Collectors.toList());

		 List<LeaveRequestEntity> leaveRequestList = leaveRequestRepo.findAllByIdIn(leaveRequestIdList);
		
		 List<Integer> kairoUserIdList = leaveRequestList.stream().map(LeaveRequestEntity::getApplicantId)
				 .collect(Collectors.toList());

		 List<RedmineConsolidatedLogEntity> consolidatedLogList = redmineConsolidatedRepo.findBySpentOnAndKairoUserIdIn(holidayDate, kairoUserIdList);

		 List<LeaveLogtimeConflictEntity> conflictList = leaveConflictRepo.findByConflictDate(holidayDate);
		 
		 List<LeaveLogtimeConflictEntity> updateList = new ArrayList<>();
		 List<LeaveLogtimeConflictEntity> deleteList = new ArrayList<>();
		 
		 conflictList.stream().forEach(conflict -> {
			 if(conflict.getNoonType().equalsIgnoreCase(NoonType.HALFDAY.toString())) {
				 deleteList.add(conflict);
			 } else {
				LeaveRequestEntity leaveRequest = leaveRequestList.stream().filter(entry -> entry.getApplicantId().equals(conflict.getApplicantId())).findFirst().orElse(null);
				if(Objects.nonNull(leaveRequest)) {
					conflict.setLeaveRequestId(leaveRequest.getId());
					LeaveRequestFragmentsEntity fragmentRecord = fragmentList.stream()
							.filter(fragment -> fragment.getLeaveRequestId().equals(leaveRequest.getId()))
							.findFirst().orElse(null);
					RedmineConsolidatedLogEntity logEntryRecord = consolidatedLogList.stream()
							.filter(entry -> entry.getKairoUserId().equals(leaveRequest.getApplicantId()))
							.findFirst().orElse(null);
					if(Objects.nonNull(fragmentRecord) && Objects.nonNull(logEntryRecord)) {
						conflict.setNoonType(NoonType.HALFDAY.toString());
						conflict.setLeaveRequestId(leaveRequest.getId());
						conflict.setLeaveRequestFragmentId(fragmentRecord.getId());
						conflict.setRedmineConsolidatedLogdetailsId(logEntryRecord.getId());
						updateList.add(conflict);
//					} else {
//						throw new Error("Leave Request Fragment or Consolidate Log Entry Record Not Exists !!!");
					}
//				} else {
//					throw new Error("Leave Request Record Not Exists !!!");
				}
			 }
		 });
		 
		 leaveConflictRepo.deleteAll(deleteList);
		 leaveConflictRepo.saveAll(updateList);
	}
	
}
