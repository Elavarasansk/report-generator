package org.com.tools.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.constant.KairoRedmineConstants;
import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.SchedulerConfigurationEntity;
import org.com.tools.entity.SchedulerHistoryEntity;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.SchedulerConfigurationRepository;
import org.com.tools.repository.SchedulerHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KairoApiPreValidationService {

	@Autowired
	SchedulerHistoryRepository schedulerHistoryRepo;
	
	@Autowired
	SchedulerConfigurationRepository schedulerConfigRepo;

	@Autowired
	RedmineUserDetailsService userService;
	
	@Autowired
	KairoUserRepository kairoUserService;
	
	@Autowired
	RedmineLogReportService logReportService;
	
	@Autowired
	KairoDailyBatchService dailyService;

	@Autowired
	KairoPreviousNotLoggedService previousNotLoggedService;

	@Autowired
	LeaveLogTimeConflictService leaveLogTimeConflictService;
	
	@Autowired
	OnDutyLogReportService onDutyService;

	public void updateSchedulerHistory(String schedulerName, boolean status) {

		SchedulerHistoryEntity recordToUpdate = schedulerHistoryRepo
				.findBySchedulerNameAndSchedulerTypeAndIsExecuting(schedulerName, KairoRedmineConstants.REDMINE, true);

		if (Objects.nonNull(recordToUpdate)) {

			recordToUpdate.setEndDateTime(LocalDateTime.now(ZoneOffset.UTC));
			recordToUpdate.setIsExecuting(false);
			recordToUpdate.setStatus(status ? KairoRedmineConstants.SUCCESS : KairoRedmineConstants.FAILED);

			int duration = (int) ChronoUnit.MINUTES.between(recordToUpdate.getStartDateTime(), recordToUpdate.getEndDateTime());
			recordToUpdate.setDurationMinutes(duration > 0 ? duration : 0);

			recordToUpdate.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));
			schedulerHistoryRepo.save(recordToUpdate);
		}
	}

	public void validateApiTrigger(String schedulerName, LocalDate Param, Integer triggeredBy) {
		SchedulerHistoryEntity isRecordExist = schedulerHistoryRepo
				.findBySchedulerNameAndSchedulerTypeAndIsExecuting(schedulerName, KairoRedmineConstants.REDMINE, true);

		if (Objects.nonNull(isRecordExist)) {
			throw new Error("Job Execution In-Progress!");
		}
		
		//If Directly Triggered Via Swagger/API URL default user will be "Ranjith kumar"
		Integer userId = Objects.isNull(triggeredBy) ? 456 : triggeredBy;
		KairoUserEntity userEntity = kairoUserService.findById(userId).get();
		
		String SchedulerType = schedulerName.equals(KairoRedmineConstants.ON_DUTY_LOG_ENTRY_CREATION) ? KairoRedmineConstants.ON_DUTY : KairoRedmineConstants.REDMINE;
		SchedulerConfigurationEntity configEntity = schedulerConfigRepo.findBySchedulerNameAndSchedulerType(schedulerName, SchedulerType);
		
		SchedulerHistoryEntity recordToInsert = SchedulerHistoryEntity.builder()
				.schedulerType(KairoRedmineConstants.REDMINE)
				.schedulerName(schedulerName)
				.startDateTime(LocalDateTime.now(ZoneOffset.UTC))
				.status(KairoRedmineConstants.INPROGRESS)
				.actualScheduledDate(Param)
				.isExecuting(true)
				.createdOn(LocalDateTime.now(ZoneOffset.UTC))
				.schedulerConfigurationId(configEntity.getId())
				.triggeredBy(userEntity.getFirstName())
				.build();

		schedulerHistoryRepo.save(recordToInsert);
	}

	public Map<String, String> fetchUserDetails(Integer triggeredBy) {
		String schedulerName = KairoRedmineConstants.USER_DETAILS;
		validateApiTrigger(schedulerName, LocalDate.now(), triggeredBy);
		try {
			userService.getRedmineUserDetails();
			updateSchedulerHistory(schedulerName, true);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("statusCode", "200");
			responseMap.put("message", "USER DETAILS BATCH EXECUTED SUCCESSFULLY");
			return responseMap;
		} catch (Exception e) {
			updateSchedulerHistory(schedulerName, false);
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}
	
	public Map<String, String> fetchRedmineTimeEntries(LocalDate executionDateParam, Integer triggeredBy) {
		String schedulerName = KairoRedmineConstants.LOG_ENTRIES;
		validateApiTrigger(schedulerName, executionDateParam, triggeredBy);
		try {
			logReportService.getRedmineLogReport(executionDateParam);
			updateSchedulerHistory(schedulerName, true);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("statusCode", "200");
			responseMap.put("message", "FETCH TIME ENTRIES BATCH EXECUTED SUCCESSFULLY");
			return responseMap;
		} catch (Exception e) {
			updateSchedulerHistory(schedulerName, false);
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}

	public Map<String, String> triggerDailyBatch(LocalDate executionDateParam, Integer triggeredBy) {
		String schedulerName = KairoRedmineConstants.DAILY_BATCH;
		checkForDepedentBatch(executionDateParam);
		validateApiTrigger(schedulerName, executionDateParam, triggeredBy);
		try {
			dailyService.triggerDailyBatch(executionDateParam);
			updateSchedulerHistory(schedulerName, true);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("statusCode", "200");
			responseMap.put("message", "DAILY NOT-LOGGED BATCH EXECUTED SUCCESSFULLY");
			return responseMap;
		} catch (Exception e) {
			updateSchedulerHistory(schedulerName, false);
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}
	
	public Map<String, String> triggerPreviousNotLoggedBatch(Integer triggeredBy) {
		String schedulerName = KairoRedmineConstants.PREVIOUS_NOT_LOGGED;
		validateApiTrigger(schedulerName, LocalDate.now(), triggeredBy);
		try {
			previousNotLoggedService.triggerPreviousNotLoggedBatch();
			updateSchedulerHistory(schedulerName, true);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("statusCode", "200");
			responseMap.put("message", "PREVIOUS NOT-LOGGED BATCH EXECUTED SUCCESSFULLY");
			return responseMap;
		} catch (Exception e) {
			updateSchedulerHistory(schedulerName, false);
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}

	private void checkForDepedentBatch(LocalDate executionDateParam) {
		String dependentSchedulerName = KairoRedmineConstants.LOG_ENTRIES;

		List<SchedulerHistoryEntity> historyData = schedulerHistoryRepo
				.findBySchedulerNameAndSchedulerType(dependentSchedulerName, KairoRedmineConstants.REDMINE)
				.stream().filter(data -> Objects.nonNull(data.getActualScheduledDate()))
				.filter(data -> data.getActualScheduledDate().equals(executionDateParam))
				.sorted(Comparator.comparing(SchedulerHistoryEntity::getStartDateTime).reversed())
				.collect(Collectors.toList());

		String status = historyData.isEmpty() ? KairoRedmineConstants.FAILED : historyData.get(0).getStatus();
		
		if(status.equals(KairoRedmineConstants.FAILED)) {
			throw new Error("Dependent Batch - " + KairoRedmineConstants.LOG_ENTRIES + " should be executed "
					+ "successfully before executing " + KairoRedmineConstants.DAILY_BATCH);
		}
	}

	public Map<String, String> triggerLeaveLogTimeConflictBatch(Integer triggeredBy) {
		String schedulerName = KairoRedmineConstants.LEAVE_CONFLICT;
		validateApiTrigger(schedulerName, LocalDate.now(), triggeredBy);
		try {
			leaveLogTimeConflictService.triggerLeaveLogTimeConflictBatch();
			updateSchedulerHistory(schedulerName, true);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("statusCode", "200");
			responseMap.put("message", "LEAVE LOG-TIME CONFLICT VALIDATE BATCH EXECUTED SUCCESSFULLY");
			return responseMap;
		} catch (Exception e) {
			updateSchedulerHistory(schedulerName, false);
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}

	public Map<String, String> triggerOnDutyBatch(Integer triggeredBy) {
		String schedulerName = KairoRedmineConstants.ON_DUTY_LOG_ENTRY_CREATION;
		LocalDate executionDate = LocalDate.now();
		checkForDepedentBatch(executionDate);
		validateApiTrigger(schedulerName, executionDate, triggeredBy);
		try {
			onDutyService.triggerOnDutyBatch();
			updateSchedulerHistory(schedulerName, true);
			Map<String, String> responseMap = new HashMap<>();
			responseMap.put("statusCode", "200");
			responseMap.put("message", "ON-DUTY LOG ENTRY CREATION BATCH EXECUTED SUCCESSFULLY");
			return responseMap;
		} catch (Exception e) {
			updateSchedulerHistory(schedulerName, false);
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}
}
