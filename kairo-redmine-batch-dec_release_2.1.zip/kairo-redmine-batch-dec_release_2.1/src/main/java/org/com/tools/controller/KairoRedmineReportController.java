package org.com.tools.controller;

import org.com.tools.service.RedmineMetaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class KairoRedmineReportController {

	@Autowired
	RedmineMetaDataService redmineService;
	
	@PostMapping("/redmine/logged/report/")
	public String generateLoggedReport() {
		return redmineService.createRedmineMetaData(System.getProperty("user.dir")+"\\Api");
	}
	
	@PostMapping("/redmine/notlogged/report/")
	public String generateNotLoggedReport() {
		return redmineService.generateNotLoggedReport(System.getProperty("user.dir")+"\\Api");
	}
}
