package org.com.tools.aspects.concerns;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class AccessLoggingConcern
 *
 */
@Aspect
@Component("AccessLoggingConcern")
@Slf4j

public class AccessLoggingConcern{
	
	@Value("${logs.delimiter}")
	private String delimiter;

	/**
	 * Log controller calls
	 */
	@Pointcut("execution(* org.com.tools.*.*.*(..))")
	private void logControllerCalls() {
	}

	/**
	 * Repository calls
	 */
	@Pointcut("execution(* org.com.tools.repository.*.*(..))")
	private void repositoryCalls() {
	}

	/**
	 * Respo method initiation
	 * 
	 * @Param jp the jp
	 */
	@Before("repositoryCalls()")
	public void respoMethodInitiation(JoinPoint jp) {
		String className = jp.getSignature().getDeclaringTypeName();
		String methodName = jp.getSignature().getName();
		Object[] arguments = jp.getArgs();
		String logs = String.format("Repository Call initiated on ------> %s::%s Parameters {%s} <---------", className,
				methodName, arguments.length > 0 ? arguments[0] : "");
		log.info(logs);
	}


	/**
	 * Log method initiation
	 * 
	 * @param jp the jp
	 * 
	 */
	@Before("logControllerCalls()")
	public void logMethodInitiation(JoinPoint jp) {
		String className = jp.getSignature().getDeclaringTypeName();
		String methodName = jp.getSignature().getName();
		String logs = String.format("Method Execution Started on ------> %s::%s <---------", className, methodName);
		log.info(logs);
	}

	/**
	 * Log method completion
	 * 
	 * @param jp the jp
	 * 
	 */
	@AfterReturning("logControllerCalls()")
	public void logMethodCompletion(JoinPoint jp) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
		String ip = request.getRemoteHost();
		String method = request.getMethod();
		String browser = request.getHeader("user-agent");
		String path = request.getRequestURI();
		int statusCode= response.getStatus();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		String date = dtf.format(now);
		String logs = date + delimiter + ip + delimiter + method + delimiter + path + delimiter 
				+ statusCode + delimiter + browser;
		writeLogFile(logs);
		log.info(logs);
	}
	
	
	private void writeLogFile(String log) {
		String directory = System.getProperty("user.dir");
		File dir = new File(directory + "\\\\logs");
		File accessLogFile = new File(directory + "\\\\logs\\access_log.txt");
		try {
			if(!dir.exists()) {				
				Files.createDirectories(Paths.get(dir.toString()));
				Files.createFile(Paths.get(accessLogFile.toString()));
			}
			FileWriter writer = new FileWriter(directory + "\\\\logs\\access_log.txt", true);
			writer.write(log);
			writer.write("\r\n"); 
			writer.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}