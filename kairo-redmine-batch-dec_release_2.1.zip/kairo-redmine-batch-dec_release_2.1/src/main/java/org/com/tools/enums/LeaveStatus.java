package org.com.tools.enums;

public enum LeaveStatus {

	APPLIED, IN_PROGRESS, APPROVED, REJECTED, WITHDRAWN
	
}
