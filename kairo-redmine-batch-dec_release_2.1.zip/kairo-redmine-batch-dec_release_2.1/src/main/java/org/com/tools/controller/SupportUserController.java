package org.com.tools.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.com.tools.service.KairoSupportUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class SupportUserController {
	
	@Autowired
	KairoSupportUserService kairoSupportUserService;
	
	@GetMapping("/supportusers/active/get")
	public List<String> getActiveSupportUsers() {
		return kairoSupportUserService.getActiveSupportUsers();
	}
	
	@PostMapping("/save/supportusers")
	public Map<String, Object> saveSupportUsers(@RequestBody List<String> emailList) {
		return kairoSupportUserService.saveOrDeleteSupportUserDetails(emailList, true);
	}
	
	@DeleteMapping("/delete/supportusers")
	public Map<String, Object> deleteSupportUsers(@RequestBody List<String> emailList) {
		return kairoSupportUserService.saveOrDeleteSupportUserDetails(emailList, false);
	}
	
	@GetMapping("/log/supportusers")
	public String logSupportUsers(@RequestParam(required = false) String date) {
		LocalDate executionDate = Objects.nonNull(date) ? LocalDate.parse(date) : LocalDate.now();
		return kairoSupportUserService.createSupportUsersLogDetails(executionDate);
	}
	
	@DeleteMapping("remove/notlog/supportusers")
	public String removeSupportUsers() {
		return kairoSupportUserService.deleteNotLoggedEntries();
	}
	
	@GetMapping("/log/supportusers/monthend")
	public String logSupportUsersToDate(@RequestParam(required = true) String month) {
		return kairoSupportUserService.createLogEntriesToDate(month);
	}

}
