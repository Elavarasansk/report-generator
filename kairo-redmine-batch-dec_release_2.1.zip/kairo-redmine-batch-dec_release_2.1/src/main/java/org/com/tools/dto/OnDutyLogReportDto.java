package org.com.tools.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OnDutyLogReportDto {

	private Integer kairoUserId;
	
	private String fromDate;
	
	private String toDate;
	
	private String period;
}
