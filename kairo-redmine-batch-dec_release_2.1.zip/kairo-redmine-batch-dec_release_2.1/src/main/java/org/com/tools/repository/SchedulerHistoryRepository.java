package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.SchedulerHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SchedulerHistoryRepository extends JpaRepository<SchedulerHistoryEntity, Integer> {

	SchedulerHistoryEntity findBySchedulerNameAndSchedulerTypeAndIsExecuting(String name, String type, boolean isExecuting);
	
	List<SchedulerHistoryEntity> findBySchedulerNameAndSchedulerType(String name, String type);

}
