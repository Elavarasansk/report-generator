package org.com.tools.constant;

public class NotificationConstants {

	public final static String REDMINE_INSUFFICIENT_LOGTIME = "REDMINE_INSUFFICIENT_LOGTIME";

	public final static String REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY = "REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY";

	public final static String CONFLICT_WITHDRAW_REVOKED = "CONFLICT_WITHDRAW_REVOKED";

	public final static String CONFLICT_WITHDRAW_REVOKED_HIERARCHY = "CONFLICT_WITHDRAW_REVOKED_HIERARCHY";
	
	public final static String IS_WEB_SUBSCRIBED = "isWebSubscribed";

	public final static String IS_MAIL_SUBSCRIBED = "isMailSubscribed";

	public final static String IS_MOBILE_SUBSCRIBED = "isMobileSubscribed";

	public final static String IS_SERVICE_WORKER_SUBSCRIBED = "isServiceWorkerSubscribed";
}
