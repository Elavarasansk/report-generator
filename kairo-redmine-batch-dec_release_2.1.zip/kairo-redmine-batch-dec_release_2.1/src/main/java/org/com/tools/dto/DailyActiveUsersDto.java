package org.com.tools.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DailyActiveUsersDto {

	private Integer kairoUserId;

	private Integer shiftId;

	private Float hoursPerDay;

	private String holidayNoonType;

	private Integer locationId;

	private Integer stateId;

	private Integer countryId;

	private Integer projectAllocId;

	private Integer projectId;

	private Integer organisationId;
	
}
