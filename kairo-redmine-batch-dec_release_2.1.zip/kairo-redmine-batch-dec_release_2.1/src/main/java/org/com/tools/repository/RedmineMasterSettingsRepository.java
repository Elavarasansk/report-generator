package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.RedmineMasterSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RedmineMasterSettingsRepository extends JpaRepository<RedmineMasterSettings, Integer> {
	
	List<RedmineMasterSettings> findByActive(boolean active);

}
