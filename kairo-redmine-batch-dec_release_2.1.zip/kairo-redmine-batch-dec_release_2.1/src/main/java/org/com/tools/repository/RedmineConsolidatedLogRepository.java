package org.com.tools.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RedmineConsolidatedLogRepository extends JpaRepository<RedmineConsolidatedLogEntity, Integer> {

	List<RedmineConsolidatedLogEntity> findByKairoUserIdIn(List<Integer> kairoUserList);

	@Transactional
	List<RedmineConsolidatedLogEntity> deleteBySpentOnAndKairoUserIdIn(Date date, List<Integer> userIdList);

	List<RedmineConsolidatedLogEntity> findBySpentOnAndKairoUserIdIn(Date date, List<Integer> userIdList);

	@Transactional
	List<RedmineConsolidatedLogEntity> deleteBySpentOnAndKairoUserIdNotIn(Date date, List<Integer> userIdList);
	
	List<RedmineConsolidatedLogEntity> findByIdIn(List<Integer> ids);

	RedmineConsolidatedLogEntity findBySpentOnAndKairoUserId(Date spentOn, Integer kairoUserId);

	@Transactional
	List<RedmineConsolidatedLogEntity> deleteBySpentOnInAndKairoUserId(List<Date> spentOnDateList, Integer kairoUserId);

	List<RedmineConsolidatedLogEntity> findBySpentOnInAndKairoUserId(List<Date> spentOnDateList, Integer kairoUserId);

	@Transactional
	List<RedmineConsolidatedLogEntity> deleteAllBySpentOnInAndKairoUserId(List<Date> spentOnDateList, Integer kairoUserId);
}
