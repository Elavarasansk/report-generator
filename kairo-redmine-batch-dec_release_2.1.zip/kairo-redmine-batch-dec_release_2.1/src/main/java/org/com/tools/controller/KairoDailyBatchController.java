package org.com.tools.controller;

import java.time.LocalDate;
import java.util.Map;
import java.util.Objects;

import org.com.tools.dto.KairoDailyBatchUsersListDto;
import org.com.tools.service.KairoApiPreValidationService;
import org.com.tools.service.KairoDailyBatchService;
import org.com.tools.service.RedmineLogReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class KairoDailyBatchController {

	@Autowired
	KairoDailyBatchService dailyService;

	@Autowired
	KairoApiPreValidationService apiPreValidationService;
	
	@Autowired
	RedmineLogReportService logReportService;
	
	/**
	 * triggers daily batch in KairoDailyBatchService
	 * 
	 * @return
	 */
	@GetMapping("/daily/calculate/notlogged")
	public Map<String, String> triggerDailyBatch(@RequestHeader(value = "userId", required = false) Integer triggeredBy, 
			@RequestParam(required = false) String date) {
		LocalDate executionDate = Objects.nonNull(date) ? LocalDate.parse(date) : LocalDate.now();
		return apiPreValidationService.triggerDailyBatch(executionDate, triggeredBy);
	}

	/**
	 * triggers cumulative batch in KairoDailyBatchService
	 * 
	 * @return
	 */
	@PostMapping("/specific/users/consolidated")
	public String triggerCumulativeBatch(@RequestBody(required = false) KairoDailyBatchUsersListDto userList) {
		LocalDate date = Objects.nonNull(userList.getDate()) ? LocalDate.parse(userList.getDate()) : LocalDate.now();
		dailyService.preCheckCumulativeBatch(date, userList, true);
		return "Success";
	}

	/**
	 * triggers daily batch in KairoRedmineBatchScheduler userdetails, logreport,
	 * cumulative log report
	 * 
	 * @return
	 */
	@GetMapping("/fetch/daily/timeentries")
	public Map<String, String> fetchRedmineData(@RequestHeader(value = "userId", required = false) Integer triggeredBy,
			@RequestParam(required = false) String date) {
		LocalDate executionDate = Objects.nonNull(date) ? LocalDate.parse(date) : LocalDate.now();
		return apiPreValidationService.fetchRedmineTimeEntries(executionDate, triggeredBy);
	}
	
	/**
	 * triggers log report batch for specific user or users in KairoDailyBatchService
	 * 
	 * @return
	 */
	@PostMapping("fetch/specific/users/logreport")
	public String fetchRedmineDataForUsers(@RequestBody KairoDailyBatchUsersListDto userList) {
		return logReportService.getRedmineLogReportForSpecifiedUsers(userList);
	}
}
