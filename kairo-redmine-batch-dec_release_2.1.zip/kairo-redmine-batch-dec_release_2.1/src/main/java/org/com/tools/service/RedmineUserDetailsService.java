package org.com.tools.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.ProjectAllocationEntity;
import org.com.tools.entity.RedmineMasterSettings;
import org.com.tools.entity.RedmineUserDetailsEntity;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.ProjectAllocationRepository;
import org.com.tools.repository.RedmineMasterSettingsRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.KairoRedmineManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taskadapter.redmineapi.bean.User;


/**
 * RedmineUserDetailsService fetches all users form the redmine
 *
 */
@Service
public class RedmineUserDetailsService {

	@Autowired
	RedmineUserDetailsRepository redmineUserRepo;

	@Autowired
	ProjectAllocationRepository projectAllocRepo;

	@Autowired
	KairoUserRepository kairoUserRepo;  

//	@Autowired
//	KairoRedmineManager redmineManager;

	@Autowired
	RedmineMasterSettingsRepository redmineMasterSettingsRepo;

	
	private KairoRedmineManager redmineManager;
	
	/**
	 * getRedmineUserDetails triggers user data fetch from redmine.
	 * @return status
	 */
	public String getRedmineUserDetails() {
		List<RedmineMasterSettings> redmineMasterSettingsList = redmineMasterSettingsRepo.findByActive(true);
		
		redmineMasterSettingsList.forEach(masterData -> {
			this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
			fetchRedmineUserManager(masterData.getId());
		});
		return "Redmine User Details Migrated";
	}

	/**
	 * fetchRedmineUserManager fetches redmine user and
	 * inserts in redmine_user_details table
	 */
	private void fetchRedmineUserManager(int redmineUrlMasterId) {

		Map<Integer, Integer> currentProjectList = projectAllocRepo.findByCurrent(true)
				.stream().collect(Collectors.toMap(ProjectAllocationEntity::getEmployeeId,
						ProjectAllocationEntity::getProjectId));
		
		List<KairoUserEntity> dbUsersList = kairoUserRepo.findAll();

		Map<String, Integer> kairoUserList = dbUsersList.stream()
				.collect(Collectors.toMap(KairoUserEntity::getEmail,
						KairoUserEntity::getId));

//		Map<String, Integer> redmineUserList = redmineUserRepo.findAll().stream()
		Map<String, Integer> redmineUserList = redmineUserRepo.findAllByRedmineUrlMasterId(redmineUrlMasterId).stream()
				.collect(Collectors.toMap(RedmineUserDetailsEntity::getMailId,
						RedmineUserDetailsEntity::getRedmineUserId));

		List<RedmineUserDetailsEntity> entityList = new ArrayList<>();

		redmineManager.getAllUsersList().stream().forEach(entry -> {

			List<String> duplicateRedmineUser = entityList.stream()
					.map(RedmineUserDetailsEntity::getMailId).collect(Collectors.toList());

			if(!duplicateRedmineUser.contains(entry.getMail()) &&
					!redmineUserList.keySet().contains(entry.getMail()) &&
					kairoUserList.keySet().contains(entry.getMail())){

				RedmineUserDetailsEntity entity = RedmineUserDetailsEntity.builder()
						.redmineUserId(entry.getId())
						.redmineUrlMasterId(redmineUrlMasterId)
						.userName(entry.getFullName())
						.mailId(entry.getMail())
						.userCreatedOn(entry.getCreatedOn())
						.lastLogin(Objects.nonNull(entry.getLastLoginOn()) ? entry.getLastLoginOn() : null)
						.active(Objects.nonNull(entry.getStatus()) ? entry.getStatus().equals(User.STATUS_ACTIVE) : false)
						.kairoUserId(kairoUserList.get(entry.getMail())).build();

				entity.setKairoUserProjectId(currentProjectList.get(entity.getKairoUserId()));

				entityList.add(entity);
			}
		});

		if(!entityList.isEmpty()) {
			redmineUserRepo.saveAll(entityList);
		}
	}
}
