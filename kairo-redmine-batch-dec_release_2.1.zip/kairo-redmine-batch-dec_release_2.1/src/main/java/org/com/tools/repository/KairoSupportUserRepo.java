package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.KairoSupportUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface KairoSupportUserRepo extends JpaRepository<KairoSupportUserEntity, Integer>  {

	List<KairoSupportUserEntity> findAllByActive(Boolean active);
	
	List<KairoSupportUserEntity> findAllByActiveAndKairoUserIdNotIn(Boolean active, List<Integer> userIdList);
	
	List<KairoSupportUserEntity> findAllByActiveAndKairoUserIdIn(Boolean active, List<Integer> userIdList);
	
	@Query(value = "SELECT * FROM kairo_support_team kst "
			+ "INNER JOIN kairo_user ku ON kst.kairo_user_id = ku.id " 
			+ "WHERE kst.active = true AND ku.active=true", nativeQuery = true)
	List<KairoSupportUserEntity> getActiveSupportKairoUser();
	
}
