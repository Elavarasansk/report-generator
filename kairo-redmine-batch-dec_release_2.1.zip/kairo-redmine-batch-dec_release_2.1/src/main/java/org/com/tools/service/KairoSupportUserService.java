package org.com.tools.service;

import java.sql.Date;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.dto.DailyActiveUsersDto;
import org.com.tools.entity.KairoShiftConfigurationEntity;
import org.com.tools.entity.KairoSupportUserEntity;
import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.LeaveRequestFragmentsEntity;
import org.com.tools.entity.OnDutyRequestEntity;
import org.com.tools.entity.OnDutyRequestFragmentsEntity;
import org.com.tools.entity.ProjectAllocationEntity;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.entity.RedmineLogReportEntity;
import org.com.tools.enums.NoonType;
import org.com.tools.repository.KairoShiftConfigurationRepository;
import org.com.tools.repository.KairoSupportUserRepo;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.LeaveRequestFragmentsRepository;
import org.com.tools.repository.OnDutyRequestFragmentsRepository;
import org.com.tools.repository.OnDutyRequestRepository;
import org.com.tools.repository.ProjectAllocationRepository;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.repository.RedmineLogReportRepositiory;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.utility.DateUtils;
import org.com.tools.utility.HolidaysManager;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KairoSupportUserService {

	@Autowired
	private KairoShiftConfigurationRepository shiftConfRepo;

	@Autowired
	private LeaveRequestFragmentsRepository leaveReqFragRepo;

	@Autowired
	private KairoSupportUserRepo supportUserRepo;

	@Autowired
	private KairoUserRepository kairoUserRepo;

	@Autowired
	private ProjectAllocationRepository projAllocRepo;

	@Autowired
	private RedmineLogReportRepositiory logReportRepo;

	@Autowired
	private RedmineConsolidatedLogRepository consolidatedLogRepo;
	
	@Autowired
	private RedmineNotLoggedRepository notLogRepo;
	
	@Autowired
	private OnDutyRequestFragmentsRepository odReqFragmentRepo;
	
	@Autowired
	private OnDutyRequestRepository odReqRepo;
	
	@Autowired
	HolidaysManager holidayManager;
	
	/**
	 * Save Supports Team users details in kairo_support_team
	 * 
	 * @param emailList
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> saveOrDeleteSupportUserDetails(List<String> emailList, boolean isActivate) {
		Map<String, Object> responseMap = new HashMap<>();
		Map<String, Object> actualUserMap = getActualSupportUsers(emailList);
		
		List<KairoUserEntity> kairoSupportUserRec = (List<KairoUserEntity>)actualUserMap.get("valid");
		List<String> invalidUsers = (List<String>)actualUserMap.get("invalid");
		
		if(Objects.nonNull(kairoSupportUserRec)) {
			responseMap.put("Input Email Count", emailList.size());
		
			Map<Integer, KairoSupportUserEntity> supportUserIdMap = supportUserRepo.findAll().stream()
						.collect(Collectors.toMap(key -> key.getKairoUserId(), value -> value));
			
			List<KairoSupportUserEntity> entityList = new ArrayList<>();
			kairoSupportUserRec.stream().forEach(user -> {
				Integer kairoUserId = user.getId();
				KairoSupportUserEntity entity = KairoSupportUserEntity.builder().build();
				KairoSupportUserEntity existingRec = supportUserIdMap.get(kairoUserId); 
				
				if(!isActivate && Objects.isNull(existingRec)) {
					return;
				}
				
				if(Objects.nonNull(existingRec)) {
					BeanUtils.copyProperties(existingRec, entity);
					Boolean isContractEmp = Objects.nonNull(entity.getIsContractEmployee()) && entity.getIsContractEmployee() ? true : false;
					entity.setIsContractEmployee(isContractEmp);
					entity.setModifiedOn(LocalDateTime.now());
				} else {
					entity.setKairoUserId(kairoUserId);
					entity.setCreatedOn(LocalDateTime.now());
					entity.setModifiedOn(LocalDateTime.now());
					entity.setIsContractEmployee(false);
				}
				entity.setActive(isActivate);
				entityList.add(entity);
			});
			supportUserRepo.saveAll(entityList);
			responseMap.put("Updated records count", entityList.size());
		}
		
		if(Objects.nonNull(invalidUsers)) {
			responseMap.put("Records update failed count", invalidUsers.size());
			responseMap.put("Inactive/Incorrect email ID list", invalidUsers);
		}
		
		if(responseMap.keySet().size() == 0) {
			responseMap.put("message", "No input email list provided");
		}
		
		return responseMap;
	}

	/**
	 * method to log for support team users in log and consolidated
	 * @param executionDate
	 * @return
	 */
	public String createSupportUsersLogDetails(LocalDate executionDate) {
		List<KairoSupportUserEntity> supportUsers = supportUserRepo.findAllByActive(true);

		deleteTodayLogReportDetails(supportUsers, executionDate);

		List<RedmineLogReportEntity> logReportRec = createLogReportEntries(supportUsers, executionDate);
		createConsolidatedLogDetails(logReportRec, executionDate);

		return "Support users logged successfully!";
	}

	/**
	 * method to calculate log time for support users based on holidays and leave request
	 * @param kairoUserId
	 * @param noonType
	 * @param executionDate 
	 * @param consolidatedLogList 
	 * @return
	 */
	private Float getTimeToLogForUser(Integer kairoUserId, String noonType, LocalDate executionDate, List<RedmineConsolidatedLogEntity> consolidatedLogList) {
		KairoShiftConfigurationEntity shiftRec = shiftConfRepo.getUserProjectShiftDetails(kairoUserId);
		Float logTime = shiftRec.getHoursPerDay();
		
		if (Objects.nonNull(noonType)) {
			logTime = (float) (noonType.equalsIgnoreCase(NoonType.FULLDAY.toString()) ? 0 : 4.0);
		}
		
		RedmineConsolidatedLogEntity consolidateLogEntity = consolidatedLogList.stream().filter(cond -> cond.getKairoUserId().equals(kairoUserId)).findFirst().orElse(null);
		
		if(Objects.nonNull(consolidateLogEntity)) {			
			Float loggedHours = consolidateLogEntity.getLoggedHours();
			if(loggedHours >= logTime) {
				logTime = (float) 0;
			}
		}
		
		if(logTime > 0) {			
			LeaveRequestFragmentsEntity resLeaves = leaveReqFragRepo.getUserLeaveRequestsOnDate(kairoUserId, executionDate);
			List<OnDutyRequestFragmentsEntity> odFragmentsList = odReqFragmentRepo.getUserODRequestsOnDate(kairoUserId, executionDate);
			
			if(Objects.nonNull(resLeaves)) {
				Float leaveDays = resLeaves.getNoOfDays();
				logTime = logTime == 4.0 && leaveDays == 0.5 ? 0 : logTime - (logTime * leaveDays);
			}
			if(!odFragmentsList.isEmpty() && logTime > 0) {
				Float odDays = odFragmentsList.stream().map(OnDutyRequestFragmentsEntity::getNoOfDays).reduce(Float::sum).get();
				logTime = logTime == 4.0 && odDays == 0.5 ? 0 : logTime - (logTime * odDays);
			}
		}
		return logTime;
	}

	/**
	 * method to delete existing log reports before inserting new log reports
	 * @param supportUsers
	 * @param executionDate 
	 */
	private void deleteTodayLogReportDetails(List<KairoSupportUserEntity> supportUsers, LocalDate executionDate) {
		List<Integer> kairoUserIdList = supportUsers.stream().map(rec -> rec.getKairoUserId()).collect(Collectors.toList());
		
		List<Integer> onDutyLeaveRequestIdList = 
				odReqFragmentRepo.getAllUserODFragmentsOnADate(kairoUserIdList, executionDate)
				.stream()
				.filter(cond -> cond.getIsLogTimeCreated().equals(true))
				.map(rec -> rec.getLeaveRequestId())
				.collect(Collectors.toList());
		
		Map<Integer, Integer> onDutyLeaveReqApplicantIdMap = odReqRepo.findAllByIdIn(onDutyLeaveRequestIdList).stream()
				.collect(Collectors.toMap(OnDutyRequestEntity::getId, OnDutyRequestEntity::getApplicantId));
		
		List<Integer> onDutyKairoUserIdList = onDutyLeaveReqApplicantIdMap.values().stream().collect(Collectors.toList());

		//before deleting check if they on duty applied and remove it from id list
		if(!onDutyKairoUserIdList.isEmpty()) {
			kairoUserIdList = kairoUserIdList.stream().filter(logId -> !onDutyKairoUserIdList.contains(logId)).collect(Collectors.toList());
		}

		if(!kairoUserIdList.isEmpty()) {			
			List<Integer> logRepIdList = logReportRepo.findByKairoUserIdIn(kairoUserIdList)
					.stream().map(rec -> rec.getId()).collect(Collectors.toList());
			
		logReportRepo.deleteBySpentOnAndIdIn(Date.valueOf(executionDate), logRepIdList);
		consolidatedLogRepo.deleteBySpentOnAndKairoUserIdIn(Date.valueOf(executionDate), kairoUserIdList);
		}
	}

	/**
	 * method to create log entry entity
	 * @param supportUsers
	 * @param executionDate
	 * @return
	 */
	private List<RedmineLogReportEntity> createLogReportEntries(List<KairoSupportUserEntity> supportUsers, LocalDate executionDate) {
		List<DailyActiveUsersDto> todayActiveUser = holidayManager.getTodayActiveUsers(executionDate);
		
		List<RedmineLogReportEntity> resLogReportDetails = new ArrayList<>();
		List<Integer> userIdList = supportUsers.stream().map(rec -> rec.getKairoUserId()).collect(Collectors.toList());
	
		List<DailyActiveUsersDto> activeUserList= todayActiveUser.stream().filter(rec -> userIdList.contains(rec.getKairoUserId())).collect(Collectors.toList());

		Map<Integer, ProjectAllocationEntity> projAllocEmpIdMap = projAllocRepo.findByCurrentAndEmployeeIdIn(true, userIdList).stream()
				.collect(Collectors.toMap(key -> key.getEmployeeId(), value -> value));
		
		//getConsolidatedLogDetails
		List<RedmineConsolidatedLogEntity> consolidatedLogList = consolidatedLogRepo.findBySpentOnAndKairoUserIdIn(DateUtils.convertToUtilDate(executionDate), userIdList);

		if(!activeUserList.isEmpty()) {
			activeUserList.stream().forEach(user -> {
				Integer kairoUserId = user.getKairoUserId();
				ProjectAllocationEntity projAllocRec = projAllocEmpIdMap.get(kairoUserId);
				
				//check if contract employee
				Boolean isContractEmp = false;
				KairoSupportUserEntity supportUserEntity = supportUsers.stream()
						.filter(cond -> cond.getKairoUserId().equals(kairoUserId))
						.findFirst().orElse(null);
				
				isContractEmp = Objects.nonNull(supportUserEntity) ? supportUserEntity.getIsContractEmployee() : false;
				
				Float timeToLog = getTimeToLogForUser(kairoUserId, user.getHolidayNoonType(), executionDate, consolidatedLogList);
				
				if(timeToLog > 0) {
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(Date.valueOf(executionDate));
					
					RedmineLogReportEntity entity = RedmineLogReportEntity.builder().build();
					entity.setLogEntryId(0);
					entity.setActivityId(0);
					entity.setIssueId(0);
					entity.setProjectId(0);
					entity.setRedmineUserId(0);
					
					entity.setHours(timeToLog);
					entity.setUserName(isContractEmp ? "CONTRACT_EMPLOYEE" : "REDMINE_USER");
					
					entity.setProjectName(isContractEmp ? "CONTRACT" : "SUPPORT");
					entity.setActivityName(isContractEmp ? "CONTRACT" : "SUPPORT");
					
					entity.setSpentOn(Date.valueOf(executionDate));
					
					entity.setKairoUserId(user.getKairoUserId());
					entity.setKairoUserProjectId(projAllocRec.getProjectId());
					entity.setProjectAllocId(projAllocRec.getId());
					
					entity.setDayName(DayOfWeek.of(calendar.get(Calendar.DAY_OF_WEEK) - 1).toString());
					entity.setMonth(Month.of(calendar.get(Calendar.MONTH)).toString());
					entity.setDayNo(executionDate.getDayOfMonth());
					entity.setYear(executionDate.getYear());
					entity.setDayType(executionDate.getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY");
					
					resLogReportDetails.add(entity);
				}
			});
		}
		
		return logReportRepo.saveAll(resLogReportDetails);
	}

	/**
	 * method to create consolidated log entry entity
	 * @param logEntity
	 * @param executionDate 
	 */
	private void createConsolidatedLogDetails(List<RedmineLogReportEntity> logEntity, LocalDate executionDate) {
		List<RedmineConsolidatedLogEntity> consolidateLogList = new ArrayList<>();

		List<Integer> kairoUserIdList = logEntity.stream().distinct().map(RedmineLogReportEntity::getKairoUserId).collect(Collectors.toList());

		List<RedmineConsolidatedLogEntity> consolidatedLogList = consolidatedLogRepo.findBySpentOnAndKairoUserIdIn(DateUtils.convertToUtilDate(executionDate), kairoUserIdList);

		logEntity.stream().forEach(log -> {

			RedmineConsolidatedLogEntity consolidatedEntity = consolidatedLogList.stream().filter(cond -> cond.getKairoUserId().equals(log.getKairoUserId())).findFirst().orElse(null);

			RedmineConsolidatedLogEntity entity = RedmineConsolidatedLogEntity.builder().build();

			if(Objects.nonNull(consolidatedEntity)) {
				Float loggedHours = consolidatedEntity.getLoggedHours();
				String logReportIdList = consolidatedEntity.getRedmineLogReportIds();

				List<Integer> idList = parseDataSource(logReportIdList);
				idList.add(log.getId());

				consolidatedEntity.setLoggedHours(loggedHours + log.getHours());
				consolidatedEntity.setRedmineLogReportIds(idList.toString());

				consolidateLogList.add(consolidatedEntity);
			}
			else{
				BeanUtils.copyProperties(log, entity);

				entity.setId(null);
				entity.setLoggedHours(log.getHours());
				entity.setRedmineLogReportIds(Arrays.asList(log.getId()).toString());
				entity.setProjectId(log.getKairoUserProjectId());
				consolidateLogList.add(entity);
			}


		});
		consolidatedLogRepo.saveAll(consolidateLogList);
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getActiveSupportUsers() {
		List<KairoSupportUserEntity> supportUsers = supportUserRepo.findAllByActive(true);
		List<Integer> userIdList = supportUsers.stream().map(rec -> rec.getKairoUserId()).collect(Collectors.toList());

		List<String> userEmailList = kairoUserRepo.findAllByIdIn(userIdList).stream().filter(rec -> rec.getActive())
				.map(rec -> rec.getEmail()).collect(Collectors.toList());
		return userEmailList;
	}

	/**
	 * 
	 * @return
	 */
	public String deleteNotLoggedEntries() {

		List<KairoSupportUserEntity> activeUsers = supportUserRepo.getActiveSupportKairoUser();
		List<Integer> supportUserskairoIdList = activeUsers
				.stream().map(KairoSupportUserEntity::getKairoUserId)
				.distinct()
				.collect(Collectors.toList());
		if(!supportUserskairoIdList.isEmpty()) {			
			notLogRepo.deleteAllByKairoUserIdIn(supportUserskairoIdList);
		}
		return "Not Logged Entries Removed Successfully";
	}
	
	/**
	 * 
	 * @param emailList
	 * @return
	 */
//	public String deleteSupportUserDetails(List<String> emailList) {
//
//		List<KairoUserEntity> userRec = kairoUserRepo.findAllByActiveAndEmailIn(true, emailList);
//		List<Integer> userIdList = userRec.stream().map(rec -> rec.getId()).collect(Collectors.toList());
//
//		List<KairoSupportUserEntity> activeSupportUsers = supportUserRepo.findAllByActiveAndKairoUserIdIn(true, userIdList);
//
//		activeSupportUsers.forEach(user -> {
//			user.setActive(false);
//			user.setModifiedOn(LocalDateTime.now());
//		});
//
//		supportUserRepo.saveAll(activeSupportUsers);
//		return "Support users deleted successfully!";
//	}


	/**
	 * Creates date list for months based on day of execution to insert logentries for support users
	 * for same month - only on last day of month
	 * for previous month - date need to be within 1st to 10th of the current month
	 * @param month
	 * @return result
	 */
	public String createLogEntriesToDate(String month) {
		LocalDate currentDate = LocalDate.now();
		List<LocalDate> localDateList = new ArrayList<>();

		if(!month.equalsIgnoreCase(currentDate.getMonth().toString()) && !month.equalsIgnoreCase(currentDate.minusMonths(1).getMonth().toString())) {
			return "Can be executed only for Current month or Previous ONE month";
		}

		LocalDate monthEndDate = currentDate.with(TemporalAdjusters.lastDayOfMonth());

		if(month.equalsIgnoreCase(currentDate.minusMonths(1).getMonth().toString()) && currentDate.getDayOfMonth() > 10) {
			return "Cannot be executed on Intermediate dates, other than Same Month - End date or Next month before 10th";
		}
		else if(month.equalsIgnoreCase(currentDate.getMonth().toString()) && currentDate != monthEndDate) {
			return "Sorry,Today is not Month End, must be Executed only on Month End for same month";
		}
		else {
			if(month.equalsIgnoreCase(currentDate.minusMonths(1).getMonth().toString())) {
				LocalDate endDate = currentDate.minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
				if(currentDate.minusMonths(1).getMonth().toString().equalsIgnoreCase("DECEMBER")) {
					LocalDate monthStartDate = LocalDate.of(currentDate.minusYears(1).getYear(), currentDate.minusMonths(1).getMonth() , 1);
					localDateList = DateUtils.getDatesBetweenTwoDates(monthStartDate, endDate, true, true);	
				}else {
					LocalDate monthStartDate = LocalDate.of(currentDate.getYear(), currentDate.minusMonths(1).getMonth() , 1);
					localDateList = DateUtils.getDatesBetweenTwoDates(monthStartDate, endDate, true, true);
				}
			}else {
				LocalDate monthStartDate = LocalDate.of(currentDate.getYear(), currentDate.getMonth(), 1);
				LocalDate endDate = currentDate.with(TemporalAdjusters.lastDayOfMonth());
				localDateList = DateUtils.getDatesBetweenTwoDates(monthStartDate, endDate, false, true);	
			}
		}

		if(!localDateList.isEmpty()) {
			localDateList.stream().forEach(executionDate -> {
				createSupportUsersLogDetails(executionDate);
			});
		}
		return "Support Users Logged Successfully";
	}
	
	private Map<String, Object> getActualSupportUsers(List<String> emailList) {
		Map<String, Object> resMap = new HashMap<>();
		
		List<KairoUserEntity> userRec = kairoUserRepo.findAllByActiveAndEmailIn(true, emailList);
		List<String> validUserEmail = userRec.stream().map(rec -> rec.getEmail()).collect(Collectors.toList());
		if(userRec.size() > 0) {
			resMap.put("valid", userRec);
		}
		
		List<String> invalidEmail = emailList.stream().filter(email -> !validUserEmail.contains(email)).collect(Collectors.toList());
		if(invalidEmail.size() > 0) {
			resMap.put("invalid", invalidEmail);
		}
		return resMap;
	}
	
	/**
	 * parseDataSource parse the text data type to integer
	 * 
	 * @param ids
	 * @return Lsit of Ids
	 */
	private List<Integer> parseDataSource(String ids) {
		return Arrays.asList(ids.replace("[", "").replace("]", "").split(",")).stream()
				.map(id -> Integer.parseInt(id.trim())).collect(Collectors.toList());
	}
	
}
