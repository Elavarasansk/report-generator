package org.com.tools.repository;

import java.time.LocalDate;
import java.util.List;

import org.com.tools.entity.RedmineNotLoggedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface RedmineNotLoggedRepository extends JpaRepository<RedmineNotLoggedEntity, Integer> {

	List<RedmineNotLoggedEntity> findByFlawDate(LocalDate today);
	
	List<RedmineNotLoggedEntity> findByKairoUserIdIn(List<Integer> kairoUserIds);
	
	@Transactional
	List<RedmineNotLoggedEntity> deleteByFlawDate(LocalDate date);

	@Transactional
	List<RedmineNotLoggedEntity> deleteByFlawDateAndKairoUserIdIn(LocalDate date, List<Integer> userIdList);

	List<RedmineNotLoggedEntity> findByIsLeaveAppliedAndIsNotificationSent(boolean isLeaveApplied, boolean isSent);

	@Transactional
	List<RedmineNotLoggedEntity> deleteAllByKairoUserIdIn(List<Integer> kairoUserIdList);

	List<RedmineNotLoggedEntity> findByIsLeaveApplied(boolean isLeaveApplied);

	List<RedmineNotLoggedEntity> findByKairoUserIdInAndIsLeaveApplied(List<Integer> kairoUserIds, boolean isLeaveApplied);

	RedmineNotLoggedEntity findByKairoUserIdAndFlawDate(Integer kairoUserId, LocalDate flawDate);

	List<RedmineNotLoggedEntity> findByFlawDateInAndKairoUserId(List<LocalDate> spentOnDateList, Integer kairoUserId);

}
