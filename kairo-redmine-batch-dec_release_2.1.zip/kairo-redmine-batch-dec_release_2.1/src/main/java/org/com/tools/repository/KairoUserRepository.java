package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.KairoUserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface KairoUserRepository  extends JpaRepository<KairoUserEntity, Integer>{

	List<KairoUserEntity> findAllByIdIn(List<Integer> notLoggedIdList);
	
	List<KairoUserEntity> findAllByActiveAndEmailIn(Boolean active, List<String> email);
	
}
