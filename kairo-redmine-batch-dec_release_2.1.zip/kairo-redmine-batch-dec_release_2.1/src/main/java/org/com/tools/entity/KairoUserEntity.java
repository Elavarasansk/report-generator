package org.com.tools.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "kairo_user")
public class KairoUserEntity {

	@Id
	private Integer id;
	
	private String email;
	
	private Boolean active;
	
	private String firstName;
	
	@Column(name = "organisation_id")
	private Integer organisationId;
	
}
