package org.com.tools.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.NotificationMasterSettingEntity;
import org.com.tools.entity.ProjectAllocationEntity;
import org.com.tools.entity.RedmineNotLoggedEntity;
import org.com.tools.entity.UserNotificationMessageEntity;
import org.com.tools.entity.UserNotificationSettingEntity;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.NotificationMasterSettingRepository;
import org.com.tools.repository.ProjectAllocationRepository;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.repository.UserNotificationMessageRepository;
import org.com.tools.repository.UserNotificationSettingRepository;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotLoggedNotificationService {

	@Autowired
	NotificationMasterSettingRepository notificationMasterSettingRepo;

	@Autowired
	RedmineNotLoggedRepository redmineNotLoggedRepo;

	@Autowired
	UserNotificationSettingRepository userNotificationSettingRepo;

	@Autowired
	UserNotificationMessageRepository userNotificationMessageRepo;

	@Autowired
	KairoUserRepository kairoUserRepo;

	@Autowired
	ProjectAllocationRepository projAllocationRepo;

	@Autowired
	UserNotificationMailService userNotificationMailService;
	
	@Autowired
	KairoSupportUserService supportUserService;

	private final static String REDMINE_INSUFFICIENT_LOGTIME = "REDMINE_INSUFFICIENT_LOGTIME";

	private final static String REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY = "REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY";

	private final static String IS_WEB_SUBSCRIBED = "isWebSubscribed";

	private final static String IS_MAIL_SUBSCRIBED = "isMailSubscribed";

	private final static String IS_MOBILE_SUBSCRIBED = "isMobileSubscribed";

	private final static String IS_SERVICE_WORKER_SUBSCRIBED = "isServiceWorkerSubscribed";

	/**
	 * 
	 */
	public void triggerNotLoggedNotificationBatch() {
	    //to delete support users notlogged entries before sending mail notification
	    supportUserService.deleteNotLoggedEntries();
		sendRedmineInsufficientLogTimeNotification();
	}

	/**
	 * 
	 */
	private void sendRedmineInsufficientLogTimeNotification() {

		NotificationMasterSettingEntity masterSettingEntity = notificationMasterSettingRepo
				.findByModuleName(REDMINE_INSUFFICIENT_LOGTIME);

		NotificationMasterSettingEntity masterSettingHeirarchyEntity = notificationMasterSettingRepo
				.findByModuleName(REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY);

		// String[] masterSettingFieldsList =
		// getFieldsList(masterSettingEntity.getFieldsList().toString());

		// //form native query to get data from redmine_notlogged table
		// String query = "SELECT ";
		// for (String key : masterSettingFieldsList) {
		// query = key.toString().equals("firstName") || key.toString().equals("email")
		// ? query + "user." + key + ", " : query + "notlog." + key + ", ";
		// }
		// query = query.substring(0, query.length() - 2);
		// query = query +
		// " FROM redmine_notlogged notlog " +
		// "join kairo_user user on user.id = notlog.kairo_user_id "+
		// "WHERE notlog.isLeaveApplied = false AND notlog.isNotificationSent = false";
		//

		List<RedmineNotLoggedEntity> redmineNotLoggedList = redmineNotLoggedRepo
				.findByIsLeaveAppliedAndIsNotificationSent(false, false);

		if (!redmineNotLoggedList.isEmpty()) {
			createNotificationForInsufficientLogtime(redmineNotLoggedList, masterSettingEntity);
			createNotificationForInsufficientLogtimeHeirarchy(redmineNotLoggedList, masterSettingHeirarchyEntity);
		}
	}

	/**
	 * 
	 * @param redmineInsufficientLogtime
	 * @param redmineNotLoggedDtoList
	 * @param notificationMasterSettingEntity
	 */
	private void createNotificationForInsufficientLogtime(List<RedmineNotLoggedEntity> redmineNotLoggedList,
			NotificationMasterSettingEntity notificationMasterSettingEntity) {

		String mailTemplate = notificationMasterSettingEntity.getMailTemplate();
		String webTemplate = notificationMasterSettingEntity.getWebTemplate();
		Integer id = notificationMasterSettingEntity.getId();

		List<Integer> kairoUserIdList = redmineNotLoggedList.stream().map(RedmineNotLoggedEntity::getKairoUserId)
				.collect(Collectors.toList());

		List<KairoUserEntity> kairoUserList = kairoUserRepo.findAllByIdIn(kairoUserIdList);

		Map<Integer, Map<String, Boolean>> userSubscribedModulesMap = new HashMap<>();

		userSubscribedModulesMap = getUserSubscribedModel(notificationMasterSettingEntity, kairoUserIdList);

		if (!userSubscribedModulesMap.isEmpty()) {

			List<UserNotificationMessageEntity> userNotificationMsgEntityList = new ArrayList<>();
			Map<Integer, Map<String, Boolean>> userSubscribedsMap = userSubscribedModulesMap;

			redmineNotLoggedList.stream().forEach(rec -> {

				KairoUserEntity kairoUser = kairoUserList.stream()
						.filter(predicate -> predicate.getId().toString().equals(rec.getKairoUserId().toString())).findFirst().orElse(null);

				JSONObject fieldJSONObject = getMessageValues(rec, kairoUser);

				String mailMessage = Objects.nonNull(rec) ? replaceTemplate(mailTemplate, rec, kairoUser, "") : "";
				String webMessage = Objects.nonNull(rec) ? replaceTemplate(webTemplate, rec, kairoUser, "") : "";

				JSONObject mailMessageNotifiaction = getNotificationMessage(mailMessage);
				JSONObject webMessageNotifiaction = getNotificationMessage(webMessage);


				Map<String, Boolean> subscribeMap = Objects.nonNull(userSubscribedsMap.get(rec.getKairoUserId()))
						? userSubscribedsMap.get(rec.getKairoUserId())
						: getDeafultSubscribeMap();

				UserNotificationMessageEntity messageEntity = UserNotificationMessageEntity.builder().id(null)
						.isWebSubscribed(Objects.nonNull(subscribeMap.get(IS_WEB_SUBSCRIBED))
								? subscribeMap.get(IS_WEB_SUBSCRIBED)
								: false)
						.isMobileSubscribed(Objects.nonNull(subscribeMap.get(IS_MOBILE_SUBSCRIBED))
								? subscribeMap.get(IS_MOBILE_SUBSCRIBED)
								: false)
						.isMailSubscribed(Objects.nonNull(subscribeMap.get(IS_MAIL_SUBSCRIBED))
								? subscribeMap.get(IS_MAIL_SUBSCRIBED)
								: false)
						.isServiceWorkerSubscribed(Objects.nonNull(subscribeMap.get(IS_SERVICE_WORKER_SUBSCRIBED))
								? subscribeMap.get(IS_SERVICE_WORKER_SUBSCRIBED)
								: false)
						.messageValues(fieldJSONObject.toString())
						.mailMessage(Arrays.asList(mailMessageNotifiaction).toString())
						.webMessage(Arrays.asList(webMessageNotifiaction).toString())
						.notification_type(id)
						.recipientId(rec.getKairoUserId())
						.isHr("false")
						.build();

				userNotificationMsgEntityList.add(messageEntity);
			});

			List<UserNotificationMessageEntity> savedNotificationMessagesList = userNotificationMessageRepo.saveAll(userNotificationMsgEntityList);

			redmineNotLoggedList.stream().forEach(rec -> rec.setIsNotificationSent(true));
			redmineNotLoggedRepo.saveAll(redmineNotLoggedList);
			
			if(!savedNotificationMessagesList.isEmpty()) {				
				List<Integer> notificationMessageIdList = savedNotificationMessagesList.stream().map(UserNotificationMessageEntity::getId).distinct().collect(Collectors.toList());
				userNotificationMailService.sendMail(notificationMessageIdList);
			}
		}
	}

	/**
	 * 
	 * @param redmineNotLoggedDtoList
	 * @param masterSettingEntity
	 */
	private void createNotificationForInsufficientLogtimeHeirarchy(List<RedmineNotLoggedEntity> redmineNotLoggedList,
			NotificationMasterSettingEntity notificationMasterSettingEntity) {

		String mailTemplate = notificationMasterSettingEntity.getMailTemplate();
		String webTemplate = notificationMasterSettingEntity.getWebTemplate();
		Integer id = notificationMasterSettingEntity.getId();

		List<Integer> kairoUserIdList = redmineNotLoggedList.stream().distinct()
				.map(RedmineNotLoggedEntity::getKairoUserId).collect(Collectors.toList());

		List<KairoUserEntity> kairoUserList = kairoUserRepo.findAllByIdIn(kairoUserIdList);

		Map<Integer, Map<String, Boolean>> userSubscribedModulesMap = new HashMap<>();

		Map<Integer, List<String>> reportToDataMap = getReportToMap(kairoUserIdList);

		List<Integer> reportToIdList = new ArrayList<>();

		reportToDataMap.entrySet().stream().forEach(rec -> {
			if (Objects.nonNull(rec) && !rec.getValue().isEmpty()) {
				reportToIdList.add(Integer.parseInt(rec.getValue().get(0)));
			}
		});

		if (Objects.nonNull(notificationMasterSettingEntity)) {
			userSubscribedModulesMap = getUserSubscribedModel(notificationMasterSettingEntity, reportToIdList);
		}

		if (!userSubscribedModulesMap.isEmpty()) {
			List<UserNotificationMessageEntity> userNotificationMsgEntityList = new ArrayList<>();
			Map<Integer, Map<String, Boolean>> userSubscribedsMap = userSubscribedModulesMap;

			redmineNotLoggedList.stream().forEach(rec -> {

				KairoUserEntity kairoUser = kairoUserList.stream()
						.filter(predicate -> predicate.getId().toString().equals(rec.getKairoUserId().toString())).findFirst().orElse(null);

				JSONObject fieldJSONObject = getMessageValues(rec, kairoUser);

				if (!reportToDataMap.isEmpty() && !reportToDataMap.get(rec.getKairoUserId()).isEmpty()) {

					List<String> reportToDetails = reportToDataMap.get(rec.getKairoUserId());

					String recipientName = Objects.nonNull(reportToDetails.get(1)) ? reportToDetails.get(1) : "";

					fieldJSONObject.put("report_to",
							Objects.nonNull(reportToDetails.get(0)) ? reportToDetails.get(0) : "");
					fieldJSONObject.put("recipientName", recipientName);
					fieldJSONObject.put("email", Objects.nonNull(reportToDetails.get(1)) ? reportToDetails.get(2) : "");

					String mailMessage = Objects.nonNull(rec)
							? replaceTemplate(mailTemplate, rec, kairoUser, recipientName)
							: "";
					String webMessage = Objects.nonNull(rec)
							? replaceTemplate(webTemplate, rec, kairoUser, recipientName)
							: "";

					Map<String, Boolean> subscribeMap = Objects.nonNull(userSubscribedsMap.get(rec.getKairoUserId()))
							? userSubscribedsMap.get(rec.getKairoUserId())
							: getDeafultSubscribeMap();

					JSONObject mailMessageNotifiaction = getNotificationMessage(mailMessage);
					JSONObject webMessageNotifiaction = getNotificationMessage(webMessage);

					UserNotificationMessageEntity messageEntity = UserNotificationMessageEntity.builder().id(null)
							.isWebSubscribed(Objects.nonNull(subscribeMap.get(IS_WEB_SUBSCRIBED))
									? subscribeMap.get(IS_WEB_SUBSCRIBED)
									: false)
							.isMobileSubscribed(Objects.nonNull(subscribeMap.get(IS_MOBILE_SUBSCRIBED))
									? subscribeMap.get(IS_MOBILE_SUBSCRIBED)
									: false)
							.isMailSubscribed(Objects.nonNull(subscribeMap.get(IS_MAIL_SUBSCRIBED))
									? subscribeMap.get(IS_MAIL_SUBSCRIBED)
									: false)
							.isServiceWorkerSubscribed(Objects.nonNull(subscribeMap.get(IS_SERVICE_WORKER_SUBSCRIBED))
									? subscribeMap.get(IS_SERVICE_WORKER_SUBSCRIBED)
									: false)
							.messageValues(fieldJSONObject.toString())
							.mailMessage(Arrays.asList(mailMessageNotifiaction).toString())
							.webMessage(Arrays.asList(webMessageNotifiaction).toString())
							.notification_type(id)
							.recipientId(Integer.parseInt(reportToDataMap.get(rec.getKairoUserId()).get(0)))
							.isHr("false")
							.build();

					userNotificationMsgEntityList.add(messageEntity);
				}
			});

			List<UserNotificationMessageEntity> savedNotificationMessagesList = userNotificationMessageRepo.saveAll(userNotificationMsgEntityList);

			if(!savedNotificationMessagesList.isEmpty()) {				
				List<Integer> notificationMessageIdList = savedNotificationMessagesList.stream().map(UserNotificationMessageEntity::getId).distinct().collect(Collectors.toList());
				userNotificationMailService.sendMail(notificationMessageIdList);
			}
		}

	}

	/**
	 * 
	 * @param masterSettingEntity
	 * @param kairoUserIdList
	 * @return
	 */
	public Map<Integer, Map<String, Boolean>> getUserSubscribedModel(
			NotificationMasterSettingEntity masterSettingEntity, List<Integer> kairoUserIdList) {

		Boolean isWebChangeAllowed = masterSettingEntity.getIsWebChangeAllowed();
		Boolean isWebPush = masterSettingEntity.getIsWebPush();
		Integer id = masterSettingEntity.getId();
		Boolean isMailChangeAllowed = masterSettingEntity.getIsMailChangeAllowed();
		Boolean isMailPush = masterSettingEntity.getIsMailPush();

		Map<Integer, Map<String, Boolean>> dataMap = new HashMap<>();

		List<UserNotificationSettingEntity> userNotificationSettingList = userNotificationSettingRepo
				.findAllByUserIdIn(kairoUserIdList);

		// dto - Change it to dto , instead of using map

		if (!userNotificationSettingList.isEmpty()) {
			userNotificationSettingList.stream().forEach(rec -> {
				Map<String, Boolean> subscribeMap = new HashMap<String, Boolean>() {
					{
						put(IS_MOBILE_SUBSCRIBED, false);
						put(IS_SERVICE_WORKER_SUBSCRIBED, false);
					}
				};

				// check for web notification modules
				List<Integer> webModules = rec.getWebNotificationModules();
				if (!isWebChangeAllowed && isWebPush) {
					subscribeMap.put(IS_WEB_SUBSCRIBED, true);
				} else if (isWebChangeAllowed && isWebPush) {
					if (Objects.nonNull(webModules) && webModules.contains(id)) {
						subscribeMap.put(IS_WEB_SUBSCRIBED, true);
					}
				} else {
					subscribeMap.put(IS_WEB_SUBSCRIBED, false);
				}

				// check for mail notification modules
				List<Integer> mailModules = rec.getMailNotificationModules();
				if (!isMailChangeAllowed && isMailPush) {
					subscribeMap.put(IS_MAIL_SUBSCRIBED, true);
				} else if (isMailChangeAllowed && isMailPush) {
					if (Objects.nonNull(mailModules) && mailModules.contains(id)) {
						subscribeMap.put(IS_MAIL_SUBSCRIBED, true);
					}
				} else {
					subscribeMap.put(IS_MAIL_SUBSCRIBED, false);
				}

				dataMap.put(rec.getUserId(), subscribeMap);
			});
		}
		return dataMap;
	}

	// need to change to for loop once the native query operation is complete
	/**
	 * 
	 * @param template
	 * @param rec
	 * @param kairoUser
	 * @param recipientName
	 * @return template
	 */
	private String replaceTemplate(String template, RedmineNotLoggedEntity rec, KairoUserEntity kairoUser,
			String recipientName) {
		template = template.toString();

		template = template.replace("[insufficientHours]", rec.getInsufficientHours().toString());
		template = template.replace("[flawDate]", rec.getFlawDate().toString());
		if (template.contains("[firstName]")) {
			template = template.replace("[firstName]", kairoUser.getFirstName().toString());
		}
		if (template.contains("[recipientName]")) {
			template = template.replace("[recipientName]", recipientName);
		}

		return template;
	}

	/**
	 * 
	 * @param masterSettingFields
	 * @return
	 */
	private String[] getFieldsList(String masterSettingFields) {
		masterSettingFields = masterSettingFields.replace("[", "");
		masterSettingFields = masterSettingFields.replace("]", "");
		masterSettingFields = masterSettingFields.replace("\"", "");
		String[] masterSettingFieldList = masterSettingFields.split(",");
		return masterSettingFieldList;
	}

	/**
	 * 
	 * @return
	 */
	public Map<String, Boolean> getDeafultSubscribeMap() {
		Map<String, Boolean> defaultSubscribeMap = new HashMap<>();

		defaultSubscribeMap.put(IS_MAIL_SUBSCRIBED, false);
		defaultSubscribeMap.put(IS_MOBILE_SUBSCRIBED, false);
		defaultSubscribeMap.put(IS_SERVICE_WORKER_SUBSCRIBED, false);
		defaultSubscribeMap.put(IS_WEB_SUBSCRIBED, false);

		return defaultSubscribeMap;
	}
	
	/**
	 * 
	 * @param rec
	 * @param message
	 * @return
	 */
	private JSONObject getNotificationMessage(String message) {
		JSONObject fieldJSONObject = new JSONObject();
		fieldJSONObject.put("message", message);
		fieldJSONObject.put("createdOn",LocalDateTime.now());
		return fieldJSONObject;
	}


	/**
	 * 
	 * @param rec
	 * @param kairoUserList
	 * @return
	 */
	private JSONObject getMessageValues(RedmineNotLoggedEntity rec, KairoUserEntity kairoUser) {
		JSONObject fieldJSONObject = new JSONObject();
		fieldJSONObject.put("id", rec.getId());
		fieldJSONObject.put("isHalfDay", rec.getIsHalfDay());
		fieldJSONObject.put("isFullDay", rec.getIsFullDay());
		fieldJSONObject.put("flawDate", rec.getFlawDate());
		fieldJSONObject.put("insufficentHours", rec.getInsufficientHours());
		fieldJSONObject.put("firstName", kairoUser.getFirstName());
		fieldJSONObject.put("kairo_user_id", rec.getKairoUserId());
		fieldJSONObject.put("email", kairoUser.getEmail());
		fieldJSONObject.put("modifiedOn", LocalDateTime.now());
		return fieldJSONObject;
	}

	/**
	 * 
	 * @param kairoUserIdList
	 * @return
	 */
	public Map<Integer, List<String>> getReportToMap(List<Integer> kairoUserIdList) {

		List<ProjectAllocationEntity> projectAllocationList = projAllocationRepo.findByCurrentAndEmployeeIdIn(true,
				kairoUserIdList);

		Map<Integer, List<String>> employeeIdMap = new HashMap<>();

		if (!projectAllocationList.isEmpty()) {
			List<Integer> reportToIdList = projectAllocationList.stream()
					.filter(Objects::nonNull)
					.map(ProjectAllocationEntity::getReporterId).distinct().collect(Collectors.toList());

			List<KairoUserEntity> kairoUserReportToList = kairoUserRepo.findAllByIdIn(reportToIdList);

			projectAllocationList.stream().forEach(rec -> {
				List<String> reportToIdNameEmailList = new ArrayList<>();
				if(Objects.nonNull(rec.getReporterId())){					
					KairoUserEntity reportTo = kairoUserReportToList.stream()
							.filter(cond -> cond.getId().toString().equals(rec.getReporterId().toString())).findFirst().orElse(null);
					if (Objects.nonNull(reportTo)) {
						reportToIdNameEmailList.add(reportTo.getId().toString());
						reportToIdNameEmailList.add(reportTo.getFirstName());
						reportToIdNameEmailList.add(reportTo.getEmail());
					}
				}
				employeeIdMap.put(rec.getEmployeeId(), reportToIdNameEmailList);
			});
		}

		return employeeIdMap;
	}
}