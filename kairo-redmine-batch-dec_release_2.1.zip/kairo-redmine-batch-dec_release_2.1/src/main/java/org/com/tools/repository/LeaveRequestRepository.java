package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.LeaveRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LeaveRequestRepository extends JpaRepository<LeaveRequestEntity, Integer> {

	List<LeaveRequestEntity> findAllByApplicantIdIn(List<Integer> applicantIdList);
	
	List<LeaveRequestEntity> findAllByIdIn(List<Integer> leaveRequestIdList);

}
