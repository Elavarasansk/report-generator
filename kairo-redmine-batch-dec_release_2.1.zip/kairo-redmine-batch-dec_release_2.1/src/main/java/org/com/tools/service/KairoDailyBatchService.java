package org.com.tools.service;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.dto.DailyActiveUsersDto;
import org.com.tools.dto.KairoDailyBatchUsersListDto;
import org.com.tools.entity.LeaveRequestEntity;
import org.com.tools.entity.ProjectAllocationEntity;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.entity.RedmineLogReportEntity;
import org.com.tools.entity.RedmineNotLoggedEntity;
import org.com.tools.entity.RedmineUserDetailsEntity;
import org.com.tools.enums.NoonType;
import org.com.tools.repository.ProjectAllocationRepository;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.repository.RedmineLogReportRepositiory;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.DateUtils;
import org.com.tools.utility.HolidaysManager;
import org.com.tools.utility.LeaveRequestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * KairoDailyBatchService checks redmine log entry and leave request daily for
 * each user in the organisation.
 *
 */
@Service
public class KairoDailyBatchService {

	@Autowired
	RedmineLogReportRepositiory logReportRepo;

	@Autowired
	RedmineUserDetailsRepository redmineUserRepo;

	@Autowired
	RedmineNotLoggedRepository redmineNotLoggedRepo;

	@Autowired
	RedmineConsolidatedLogRepository consolidatedRepo;

	@Autowired
	ProjectAllocationRepository projectAllocRepo;

	@Autowired
	LeaveRequestUtils leaveReqUtils;

	@Autowired
	HolidaysManager holidayManager;
	
	@Autowired
	NotLoggedNotificationService notLoggedService;

	/**
	 * TriggerDailyBatch initiate Daily Batch for Redmine Migrate log time from
	 * redmine to redmine_log_report table
	 * 
	 */
	public void triggerDailyBatch(LocalDate executionDate) {

		// Collect Daily Active Users Based On Shift And Holiday
		List<DailyActiveUsersDto> activeUser = holidayManager.getTodayActiveUsers(executionDate);
		if (!activeUser.isEmpty()) {
			verifyNotLoggedUsers(executionDate, activeUser);
		}
		Map<Integer, List<LeaveRequestEntity>> resMap = leaveReqUtils
				.getLeaveReqForDateGroupByKairoUserId(executionDate);
		if (!resMap.isEmpty()) {
			List<RedmineNotLoggedEntity> notLoggedList = redmineNotLoggedRepo
					.findByFlawDate(executionDate);
			if (!notLoggedList.isEmpty()) {
				checkIfLeaveApplied(resMap, notLoggedList);
			}
		}
		
		notLoggedService.triggerNotLoggedNotificationBatch();
	}

	/**
	 * verifyNotLoggedUsers checks for not logged or insufficient logged users then
	 * inserts in redmine_notlogged table
	 * 
	 * @param activeUser
	 */
	private void verifyNotLoggedUsers(LocalDate executionDate, List<DailyActiveUsersDto> activeUser) {

		List<RedmineUserDetailsEntity> redmineUserList = redmineUserRepo.findAll();
		List<Integer> kairoUserIds = redmineUserList.stream().map(RedmineUserDetailsEntity::getKairoUserId)
				.collect(Collectors.toList());

//		Map<Integer, Integer> usersMap = redmineUserList.stream().collect(
//				Collectors.toMap(RedmineUserDetailsEntity::getKairoUserId, RedmineUserDetailsEntity::getRedmineUserId));

		List<RedmineLogReportEntity> logReportList = logReportRepo.findBySpentOnAndKairoUserIdIn(
				DateUtils.convertToUtilDate(executionDate), kairoUserIds);

		List<RedmineNotLoggedEntity> notLoggedList = new ArrayList<>();
		List<Integer> notLoggedDeleteList = new ArrayList<>();
		activeUser.stream().forEach(project -> {

			Boolean isFullDay = true;
			if (Objects.nonNull(project.getHolidayNoonType()) &&
					!project.getHolidayNoonType().equalsIgnoreCase(NoonType.FULLDAY.toString())) {
				project.setHoursPerDay(project.getHoursPerDay() / 2);
				isFullDay = false;
			}

			List<RedmineLogReportEntity> currentUser = logReportList.stream()
					.filter(log -> log.getKairoUserId().equals(project.getKairoUserId())).collect(Collectors.toList());

			RedmineNotLoggedEntity entity = RedmineNotLoggedEntity.builder()
//					.redmineUserId(usersMap.get(project.getKairoUserId()))
					.kairoUserId(project.getKairoUserId())
					.flawDate(executionDate)
					.estimatedHours(project.getHoursPerDay())
					.projectId(project.getProjectId())
					.shiftId(project.getShiftId()).dayName(executionDate.getDayOfWeek().toString())
					.month(executionDate.getMonth().toString())
					.projectAllocId(project.getProjectAllocId())
					.dayNo(executionDate.getDayOfMonth())
					.year(executionDate.getYear())
					.dayType(executionDate.getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY")
					.build();

			int warningDays =  Period.between(entity.getFlawDate(), executionDate).getDays() + 1;
			if (!currentUser.isEmpty()) {
				Float hoursPerDay = project.getHoursPerDay();
				Float loggedHours = currentUser.stream().map(RedmineLogReportEntity::getHours).reduce(Float::sum).get();

				if (isFullDay) { 
					if (loggedHours < hoursPerDay && loggedHours >= hoursPerDay / 2) {
						entity.setInsufficientHours(roundOff(hoursPerDay - loggedHours));
						entity.setIsHalfDay(true);
						entity.setIsFullDay(false);
						entity.setWarningDays(warningDays);
						notLoggedList.add(entity);
					} else if (loggedHours < hoursPerDay / 2) {
						entity.setInsufficientHours(roundOff(hoursPerDay - loggedHours));
						entity.setIsFullDay(true);
						entity.setIsHalfDay(false);
						entity.setWarningDays(warningDays);
						notLoggedList.add(entity);
					}
				} else {
					if (loggedHours < hoursPerDay) {
						entity.setInsufficientHours(roundOff(hoursPerDay - loggedHours));
						entity.setIsHalfDay(true);
						entity.setWarningDays(warningDays);
						notLoggedList.add(entity);
					}
				}
				entity.setRedmineUrlMasterId(currentUser.get(0).getRedmineUrlMasterId());
				entity.setRedmineUserId(currentUser.get(0).getRedmineUserId());
				
				if(loggedHours >= hoursPerDay) {
					notLoggedDeleteList.add(project.getKairoUserId());
				}
				
			} else {
				entity.setInsufficientHours(project.getHoursPerDay());
				if (isFullDay) {
					entity.setIsFullDay(true);
					entity.setWarningDays(warningDays);
				} else {
					entity.setIsHalfDay(true);
					entity.setWarningDays(warningDays);
				}
				entity.setRedmineUrlMasterId(0);
				entity.setRedmineUserId(0);
				notLoggedList.add(entity);
			}

		});

		// redmineUsersId is null, need to check user existence in redmine(not sure)
		if (!notLoggedList.isEmpty()) {
//			redmineNotLoggedRepo.deleteByFlawDate(executionDate);
//			List<RedmineNotLoggedEntity> remineUserIdNotLoggedList = notLoggedList.stream()
//					.filter(user -> Objects.nonNull(user.getRedmineUserId())).collect(Collectors.toList());
//			redmineNotLoggedRepo.saveAll(remineUserIdNotLoggedList);
			
			List<Integer> kairoUserIdList = notLoggedList.stream().map(RedmineNotLoggedEntity::getKairoUserId).collect(Collectors.toList());
			if(!notLoggedDeleteList.isEmpty()) {
				redmineNotLoggedRepo.deleteByFlawDateAndKairoUserIdIn(executionDate, notLoggedDeleteList);
			}
			redmineNotLoggedRepo.deleteByFlawDateAndKairoUserIdIn(executionDate, kairoUserIdList);
			redmineNotLoggedRepo.saveAll(notLoggedList);
		}
	}

	/**
	 * checkIfLeaveApplied verifies the leave request and delete the not logged of
	 * insufficient logged entry present in redmine_notlogged table.
	 * 
	 * @param resMap
	 *            (List of leave request grouped by kairo_user_id)
	 * @param notLoggedList
	 *            (not logged or insufficient logged user present in
	 *            redmine_notlogged table)
	 */
	public void checkIfLeaveApplied(Map<Integer, List<LeaveRequestEntity>> resMap,
			List<RedmineNotLoggedEntity> notLoggedList) {
		List<RedmineNotLoggedEntity> notLoggedDeleteList = new ArrayList<>();
		notLoggedList.stream().forEach(entry -> {
			List<LeaveRequestEntity> todaysLeaveReqList = resMap.get(entry.getKairoUserId());
			if (Objects.nonNull(todaysLeaveReqList)) {
				if (todaysLeaveReqList.size() > 1) {
					todaysLeaveReqList.get(0).setStartNoon(NoonType.FULLDAY.toString());
				}
				LeaveRequestEntity todayLeaveReq = todaysLeaveReqList.stream().findFirst().get();

				Date fromDate = todayLeaveReq.getFromDate();
				Date toDate = todayLeaveReq.getToDate();
				Date flawDate = Date.valueOf(entry.getFlawDate());
				// negative scenario - leaves applied for past days need to be deleted in BE
				// server
				// After leave apply, check and delete in redmine_notLogged table
				// (if leave applied hours == InsufficientHours else update the record)
				// Since batch will be trigged EOD, past days leaves will be updated in
				// redmine_notlogged table on next day,
				// latest info will not be visible to employee
				if (DateUtils.isFilterDateBetween(fromDate, toDate, new java.util.Date(flawDate.getTime()))) {
					if (fromDate.equals(toDate) || fromDate.equals(flawDate)) {
						String startNoon = todayLeaveReq.getStartNoon();
						if (startNoon.equalsIgnoreCase(NoonType.FULLDAY.toString())) {
							// strictly full day leave
							entry.setIsLeaveApplied(true);
							notLoggedDeleteList.add(entry);
						} else {
							// strictly half day leave and half day logged
							if (entry.getIsHalfDay()) {
								entry.setIsLeaveApplied(true);
								notLoggedDeleteList.add(entry);
							}else {								
								Float insufficientHrs = Math.abs((float) (entry.getEstimatedHours() * 0.5 - entry.getInsufficientHours()));
								if(insufficientHrs > 0) {									
									entry.setInsufficientHours(roundOff(insufficientHrs));									
								}else {
									entry.setIsLeaveApplied(true);
								}
								notLoggedDeleteList.add(entry);
							}
						}
					} else if (toDate.equals(flawDate)) {
						String endNoon = todayLeaveReq.getEndNoon();
						if (endNoon.equalsIgnoreCase(NoonType.FULLDAY.toString())) {
							// strictly full day leave
							entry.setIsLeaveApplied(true);
							notLoggedDeleteList.add(entry);
						} else {
							// strictly half day leave and half day logged
							if (entry.getIsHalfDay()) {
								entry.setIsLeaveApplied(true);
								notLoggedDeleteList.add(entry);
							}else {
								Float insufficientHrs = Math.abs((float) (entry.getEstimatedHours() * 0.5 - entry.getInsufficientHours()));
								if(insufficientHrs > 0) {									
									entry.setInsufficientHours(roundOff(insufficientHrs));									
								}else {
									entry.setIsLeaveApplied(true);
								}
								notLoggedDeleteList.add(entry);
							}
						}
					} else {
						// strictly full day leave
						entry.setIsLeaveApplied(true);
						notLoggedDeleteList.add(entry);
					}
				}
			}
		});

		if (!notLoggedDeleteList.isEmpty()) {
			redmineNotLoggedRepo.saveAll(notLoggedDeleteList);
		}
	}
	
	public void preCheckCumulativeBatch(LocalDate executionDate, KairoDailyBatchUsersListDto executeUsers, boolean isSpecificUser) {
		
		List<RedmineLogReportEntity> loggedList = logReportRepo.findBySpentOn(DateUtils.convertToUtilDate(executionDate));
		
		if(Objects.nonNull(executeUsers) && Objects.nonNull(executeUsers.getMailId())) {

			List<Integer> executeUserList = redmineUserRepo.findAllByMailIdIn(executeUsers.getMailId())
					.stream().map(RedmineUserDetailsEntity::getKairoUserId).distinct()
					.collect(Collectors.toList());

			loggedList = loggedList.stream().filter(usr -> executeUserList.contains(usr.getKairoUserId()))
					.collect(Collectors.toList());
		}
		
		triggerCumulativeBatch(executionDate, loggedList, isSpecificUser);
	}

	/**
	 * triggerCumulativeBatch collects the data from redmine_log_report table and
	 * consolidates the time entry and creates a single entry for each user daily.
	 * @param loggedList
	 * @param executionDate
	 * @param isSpecificUser 
	 */
	public void triggerCumulativeBatch(LocalDate executionDate, List<RedmineLogReportEntity> loggedList, boolean isSpecificUser) {

		List<Integer> userList = loggedList.stream().map(RedmineLogReportEntity::getKairoUserId).distinct().collect(Collectors.toList());
		List<ProjectAllocationEntity> projectAllocList = projectAllocRepo.findByCurrentAndEmployeeIdIn(true, userList);
		Map<Integer, Integer> userIdConsolidatedLogMap = findExistingConsolidated(executionDate, userList);

		List<RedmineConsolidatedLogEntity> resultList = new ArrayList<>();
		userList.stream().forEach(user -> {
			List<RedmineLogReportEntity> userLogReportList = loggedList.stream().filter(rec -> rec.getKairoUserId().equals(user)).collect(Collectors.toList());
			Float loggedHours = userLogReportList.stream().map(RedmineLogReportEntity::getHours).reduce(Float::sum).get();
			List<Integer> redmineLogReportIds = userLogReportList.stream().map(RedmineLogReportEntity::getId).distinct().collect(Collectors.toList());

			LocalDate spentOn = DateUtils.convertToLocalDate(userLogReportList.get(0).getSpentOn());

			ProjectAllocationEntity currentUserAlloc = projectAllocList.stream()
					.filter(prj -> prj.getEmployeeId().equals(user)).findFirst().orElse(null);
			
			RedmineConsolidatedLogEntity entity = RedmineConsolidatedLogEntity.builder()
					.redmineUserId(userLogReportList.get(0).getRedmineUserId())
					.redmineUrlMasterId(userLogReportList.get(0).getRedmineUrlMasterId())
					.kairoUserId(user)
					.projectAllocId(currentUserAlloc.getId())
					.projectId(currentUserAlloc.getProjectId())
					.spentOn(userLogReportList.get(0).getSpentOn())
					.loggedHours(loggedHours)
					.dayName(spentOn.getDayOfWeek().toString().toUpperCase())
					.month(spentOn.getMonth().toString().toUpperCase())
					.redmineLogReportIds(redmineLogReportIds.toString())
					.dayNo(spentOn.getDayOfMonth())
					.year(spentOn.getYear())
					.dayType(spentOn.getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY")
					.id(Objects.nonNull(userIdConsolidatedLogMap.get(user)) ? userIdConsolidatedLogMap.get(user):null)
					.build();
			resultList.add(entity);
		});

		if(!isSpecificUser) {
			consolidatedRepo.deleteBySpentOnAndKairoUserIdNotIn(DateUtils.convertToUtilDate(executionDate), userList);
		}
		
		if (!resultList.isEmpty()) {
			consolidatedRepo.saveAll(resultList);
		}
	}
	
	private Map<Integer, Integer> findExistingConsolidated(LocalDate executionDate, List<Integer> userList) {
		List<RedmineConsolidatedLogEntity> redmineConsolidatedList = consolidatedRepo.findBySpentOnAndKairoUserIdIn(DateUtils.convertToUtilDate(executionDate), userList);
		Map<Integer, Integer> userIdConsolidatedLogMap = redmineConsolidatedList.stream()
				.collect(Collectors.toMap(RedmineConsolidatedLogEntity::getKairoUserId, RedmineConsolidatedLogEntity::getId));
		return userIdConsolidatedLogMap;
	}
	
	private Float roundOff(Float value) {
		return Float.valueOf(Math.round(value * 100)/100);
	}

}
