package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.LeaveLogtimeConflictApprovalEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LeaveLogtimeConflictApprovalRepository extends JpaRepository<LeaveLogtimeConflictApprovalEntity, Integer> {

	List<LeaveLogtimeConflictApprovalEntity> findAllByApplicantIdIn(List<Integer> applicantIdList);

}
