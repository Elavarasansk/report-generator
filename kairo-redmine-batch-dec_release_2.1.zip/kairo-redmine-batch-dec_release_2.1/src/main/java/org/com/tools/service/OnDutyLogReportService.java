package org.com.tools.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.dto.DailyActiveUsersDto;
import org.com.tools.entity.LeaveRequestFragmentsEntity;
import org.com.tools.entity.OnDutyRequestEntity;
import org.com.tools.entity.OnDutyRequestFragmentsEntity;
import org.com.tools.entity.ProjectAllocationEntity;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.entity.RedmineLogReportEntity;
import org.com.tools.entity.RedmineNotLoggedEntity;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.LeaveRequestFragmentsRepository;
import org.com.tools.repository.LeaveRequestRepository;
import org.com.tools.repository.OnDutyRequestFragmentsRepository;
import org.com.tools.repository.OnDutyRequestRepository;
import org.com.tools.repository.ProjectAllocationRepository;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.repository.RedmineLogReportRepositiory;
import org.com.tools.repository.RedmineMasterSettingsRepository;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.DateUtils;
import org.com.tools.utility.HolidaysManager;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OnDutyLogReportService {

	@Autowired
	RedmineUserDetailsRepository redmineUserRepo;

	@Autowired
	HolidaysManager holidaysManager;

	@Autowired
	ProjectAllocationRepository projAllocRepo;

	@Autowired
	RedmineLogReportRepositiory logReportRepo;

	@Autowired
	RedmineMasterSettingsRepository redmineMasterSettingsRepo;

	@Autowired
	OnDutyRequestRepository odRequestRepo;

	@Autowired
	OnDutyRequestFragmentsRepository odRequestFragmentsRepo;

	@Autowired
	RedmineConsolidatedLogRepository consolidatedLogReportRepo;

	@Autowired
	KairoUserRepository kairoUserRepo;

	@Autowired
	RedmineNotLoggedRepository notLoggedRepo;

	@Autowired
	LeaveRequestRepository leaveRequestRepo;

	@Autowired
	LeaveRequestFragmentsRepository leaveRequestFragmentsRepo;

	/**
	 * Method gets executed on On-Duty Request Approval gets od req and od req
	 * fragments and process log time
	 * 
	 * @param leaveRequestId
	 */
	public void triggerLogReportEntry(Integer leaveRequestId) {

		List<OnDutyRequestEntity> odRequestEntityList = Arrays
				.asList(odRequestRepo.findById(leaveRequestId).orElse(null));

		List<OnDutyRequestFragmentsEntity> odFragmentsEntityList = odRequestFragmentsRepo
				.findAllByLeaveRequestIdAndIsLogTimeCreated(leaveRequestId, false);

		// filter to get fragment dates lesser than todays date
		odFragmentsEntityList = odFragmentsEntityList.stream()
				.filter(cond -> DateUtils.convertToLocalDate(cond.getFragmentDate()).isBefore(LocalDate.now()))
				.collect(Collectors.toList());

		if (!odFragmentsEntityList.isEmpty() && !odRequestEntityList.isEmpty()) {
			List<RedmineLogReportEntity> logReportEntityList = createLogReportEntry(odRequestEntityList,
					odFragmentsEntityList);
			if (!logReportEntityList.isEmpty()) {
				createConsolidatedLogDetails(logReportEntityList);
				updateNotLoggedDetails(logReportEntityList, odFragmentsEntityList, "approve");
			}
			
			checkIfFullyLogged();
		}
	}

	/**
	 * Batch to create log report entries for on duty requests Executes for date
	 * lesser than or equal to todays date
	 * 
	 * Need to be executed after time entires batch
	 */
	public void triggerOnDutyBatch() {

		List<OnDutyRequestEntity> odRequestEntityList = odRequestRepo.getOnDutyEntityList();

		List<OnDutyRequestFragmentsEntity> odRequestFragmentsEntityList = odRequestFragmentsRepo
				.getOnDutyFragmentsForApproved();

		// filter to get fragment dates lesser than or equal to todays date
		odRequestFragmentsEntityList = odRequestFragmentsEntityList.stream()
				.filter(cond -> DateUtils.convertToLocalDate(cond.getFragmentDate()).isBefore(LocalDate.now())
						|| DateUtils.convertToLocalDate(cond.getFragmentDate()).isEqual((LocalDate.now())))
				.collect(Collectors.toList());

		if (!odRequestFragmentsEntityList.isEmpty() && !odRequestFragmentsEntityList.isEmpty()) {
			List<RedmineLogReportEntity> logReportEntityList = createLogReportEntry(odRequestEntityList,
					odRequestFragmentsEntityList);
			if (!logReportEntityList.isEmpty()) {
				createConsolidatedLogDetails(logReportEntityList);
				updateNotLoggedDetails(logReportEntityList, odRequestFragmentsEntityList, "batch");
			}
			
			checkIfFullyLogged();
		}
	}

	/**
	 * Method to create log time - based on od req and od req fragments
	 * 
	 * @param odRequestEntityList
	 * @param odFragmentsEntityList
	 * @return List<RedmineLogReportEntity>
	 */
	private List<RedmineLogReportEntity> createLogReportEntry(List<OnDutyRequestEntity> odRequestEntityList,
			List<OnDutyRequestFragmentsEntity> odFragmentsEntityList) {

		List<RedmineLogReportEntity> logReportDetailsList = new ArrayList<>();
		List<RedmineLogReportEntity> logReportEntityList = new ArrayList<>();
		List<OnDutyRequestFragmentsEntity> onDutyFragmentSaveList = new ArrayList<>();

		odRequestEntityList.stream().forEach(odReqEntity -> {

			if (Objects.nonNull(odReqEntity) && odReqEntity.getStatus().equals("APPROVED")) {

				int kairoUserId = odReqEntity.getApplicantId();
				String userName = kairoUserRepo.findById(kairoUserId).get().getFirstName();
				ProjectAllocationEntity prjAllocEntity = projAllocRepo.findByCurrentAndEmployeeId(true, kairoUserId);

				List<OnDutyRequestFragmentsEntity> fragmentsFilterList = odFragmentsEntityList.stream()
						.filter(cond -> cond.getLeaveRequestId().equals(odReqEntity.getId()))
						.collect(Collectors.toList());

				List<Date> spentOnDateList = fragmentsFilterList.stream()
						.map(OnDutyRequestFragmentsEntity::getFragmentDate).collect(Collectors.toList());

//				logReportRepo.deleteBySpentOnInAndKairoUserIdAndProjectName(spentOnDateList, kairoUserId, "ONDUTY");

				fragmentsFilterList.stream().forEach(fragmentEntity -> {

					LocalDate executionDate = DateUtils.convertToLocalDate(fragmentEntity.getFragmentDate());

					List<DailyActiveUsersDto> todayActiveUser = holidaysManager.getTodayActiveUsers(executionDate);
					List<DailyActiveUsersDto> activeUserList = todayActiveUser.stream()
							.filter(rec -> rec.getKairoUserId().equals(kairoUserId)).collect(Collectors.toList());

					// get log time based on redmine consolidated entry and leave entry
					Float timeToLog = getTimeToLogForUser(kairoUserId, executionDate, fragmentEntity);

					if (!activeUserList.isEmpty()) {
						activeUserList.stream().forEach(user -> {

							if (timeToLog > 0) {

								// need to confirm on common issue id and activity id
								RedmineLogReportEntity logReportEntity = RedmineLogReportEntity.builder().build();
								logReportEntity.setLogEntryId(0);
								logReportEntity.setActivityId(0);
								logReportEntity.setIssueId(0);
								logReportEntity.setProjectId(0);
								logReportEntity.setRedmineUserId(0);

								logReportEntity.setHours(timeToLog);
								logReportEntity.setUserName(userName);

								logReportEntity.setProjectName("ONDUTY");
								logReportEntity.setActivityName("ONDUTY");

								logReportEntity.setSpentOn(DateUtils.convertToUtilDate(executionDate));

								logReportEntity.setKairoUserId(user.getKairoUserId());
								logReportEntity.setKairoUserProjectId(prjAllocEntity.getProjectId());
								logReportEntity.setProjectAllocId(prjAllocEntity.getId());

								logReportEntity.setDayName(executionDate.getDayOfWeek().toString().toUpperCase());
								logReportEntity.setMonth(executionDate.getMonth().toString().toUpperCase());
								logReportEntity.setDayNo(executionDate.getDayOfMonth());
								logReportEntity.setYear(executionDate.getYear());
								logReportEntity.setDayType(
										executionDate.getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY");

								logReportEntity.setCreatedOn(DateUtils.convertToUtilDate(executionDate));
								logReportEntity.setUpdatedOn(DateUtils.convertToUtilDate(executionDate));

								logReportDetailsList.add(logReportEntity);
							}
						});
					}

					// set in od request fragments - islogtime true and loggedhours
					fragmentEntity.setIsLogTimeCreated(true);
					fragmentEntity.setLogTimeAdded(timeToLog);

					onDutyFragmentSaveList.add(fragmentEntity);
				});
			}
		});

		if (!logReportDetailsList.isEmpty()) {
			logReportEntityList = logReportRepo.saveAll(logReportDetailsList);
		}

		if (!onDutyFragmentSaveList.isEmpty()) {
			odRequestFragmentsRepo.saveAll(onDutyFragmentSaveList);
		}

		return logReportEntityList;
	}

	/**
	 * Method to create consolidated log entries for on duty log created entries
	 * 
	 * @param logReportEntityList
	 */
	private void createConsolidatedLogDetails(List<RedmineLogReportEntity> logReportEntityList) {
		List<RedmineConsolidatedLogEntity> consolidateLogList = new ArrayList<>();

		Map<Integer, List<RedmineLogReportEntity>> logReporEntitytMap = logReportEntityList.stream()
				.collect(Collectors.groupingBy(RedmineLogReportEntity::getKairoUserId));

		logReporEntitytMap.keySet().stream().forEach(kairoUserId -> {

			List<RedmineLogReportEntity> tempList = logReporEntitytMap.get(kairoUserId);

			List<Date> spentOnDateList = tempList.stream().map(RedmineLogReportEntity::getSpentOn).distinct()
					.collect(Collectors.toList());

			consolidatedLogReportRepo.deleteAllBySpentOnInAndKairoUserId(spentOnDateList, kairoUserId);

			List<RedmineLogReportEntity> logReportList = logReportRepo.findBySpentOnInAndKairoUserId(spentOnDateList,
					kairoUserId);

			spentOnDateList.stream().forEach(spentOnDate -> {

				RedmineConsolidatedLogEntity entity = RedmineConsolidatedLogEntity.builder().build();

				List<RedmineLogReportEntity> logReportForADate = logReportList.stream()
						.filter(rec -> rec.getSpentOn().equals(spentOnDate)).collect(Collectors.toList());

				Float loggedHours = logReportForADate.stream().map(RedmineLogReportEntity::getHours).reduce(Float::sum)
						.get();

				List<Integer> redmineLogReportIds = logReportForADate.stream().map(RedmineLogReportEntity::getId)
						.distinct().collect(Collectors.toList());

				BeanUtils.copyProperties(logReportForADate.get(0), entity);
				entity.setLoggedHours(loggedHours);
				entity.setRedmineLogReportIds(redmineLogReportIds.toString());
				entity.setProjectId(logReportForADate.get(0).getKairoUserProjectId());

				consolidateLogList.add(entity);

			});
		});

		consolidatedLogReportRepo.saveAll(consolidateLogList);
	}

	/**
	 * 
	 * @param logReportList
	 * @param odFragmentsEntityList
	 * @param type 
	 */
	private void updateNotLoggedDetails(List<RedmineLogReportEntity> logReportList,
			List<OnDutyRequestFragmentsEntity> odFragmentsEntityList, String type) {

		List<RedmineNotLoggedEntity> notLoggedEntityList = new ArrayList<>();

		int kairoUserId = logReportList.stream().distinct().map(RedmineLogReportEntity::getKairoUserId).findFirst()
				.orElse(null);
		
		List<LocalDate> flawDateList = new ArrayList<LocalDate>();
		if(type == "approve") {			
			flawDateList = odFragmentsEntityList.stream()
					.filter(cond -> DateUtils.convertToLocalDate(cond.getFragmentDate()).isBefore(LocalDate.now()))
					.map(rec -> DateUtils.convertToLocalDate(rec.getFragmentDate())).collect(Collectors.toList());
		}else {
			flawDateList = odFragmentsEntityList.stream()
					.map(rec -> DateUtils.convertToLocalDate(rec.getFragmentDate())).collect(Collectors.toList());
		}

		List<RedmineNotLoggedEntity> notLoggedList = notLoggedRepo.findByFlawDateInAndKairoUserId(flawDateList,
				kairoUserId);

		if (!notLoggedList.isEmpty()) {
			logReportList.stream().forEach(entity -> {
				RedmineNotLoggedEntity notLoggedEntity = notLoggedList.stream().filter(
						notlog -> notlog.getFlawDate().equals(DateUtils.convertToLocalDate(entity.getSpentOn())))
						.findFirst().orElse(null);

				if (Objects.nonNull(notLoggedEntity)) {
					Float insufficientHours = notLoggedEntity.getInsufficientHours();

					if (entity.getHours() >= insufficientHours) {
						notLoggedEntity.setIsHalfDay(true);
						notLoggedEntity.setIsLeaveApplied(true);
						notLoggedEntityList.add(notLoggedEntity);
					} else {
						if (insufficientHours >= 4.0 && insufficientHours <= 8.0) {
							if(insufficientHours - entity.getHours() == 0.0) {
								notLoggedEntity.setIsLeaveApplied(true);
								notLoggedEntityList.add(notLoggedEntity);
							}else {							
								notLoggedEntity.setInsufficientHours(insufficientHours - entity.getHours());
								notLoggedEntity.setIsHalfDay(true);
								notLoggedEntity.setIsFullDay(false);
								notLoggedEntityList.add(notLoggedEntity);
							}
						}
					}
				}
			});
		}

		if(!notLoggedEntityList.isEmpty()) {			
			notLoggedRepo.saveAll(notLoggedEntityList);
		}

	}

	/**
	 * method to calculate log time for on duty users
	 * 
	 * @param kairoUserId
	 * @param executionDate
	 * @param odReqFragmentsEntity
	 * @return Float
	 */

	private Float getTimeToLogForUser(Integer kairoUserId, LocalDate executionDate,
			OnDutyRequestFragmentsEntity odReqFragmentsEntity) {

		Float logTime = (float) 0;
		Boolean isLeave = false;

		RedmineConsolidatedLogEntity consolidatedLogEntryEntity = consolidatedLogReportRepo
				.findBySpentOnAndKairoUserId(DateUtils.convertToUtilDate(executionDate), kairoUserId);

		// scenarios // dont delete until testing completed

		// full day od - no leave requets - no logtime
		// full day od - no leave request - full day log time
		// full day od - no leave request - half day log time
		// half day od - half day leave - no log time
		// half day od - half day leave - full day log time
		// half day od - half day leave - hald day log time

		LeaveRequestFragmentsEntity leaveRequestFragmentsEntity = leaveRequestFragmentsRepo
				.getUserLeaveRequestsOnDate(kairoUserId, executionDate);

		Float logHoursNeeded = (float) (odReqFragmentsEntity.getIsFullDay() ? 8.0 : 4.0);
		
		if (Objects.nonNull(leaveRequestFragmentsEntity)) {
			if(logHoursNeeded == 8.0 && leaveRequestFragmentsEntity.getIsFullday()) {				
				isLeave = true;
			}else if(logHoursNeeded == 4.0 && !leaveRequestFragmentsEntity.getIsFullday()) {
				isLeave = true;
			}
		}

		if (Objects.isNull(consolidatedLogEntryEntity)) {
			logTime = logHoursNeeded;
		} else if (Objects.nonNull(consolidatedLogEntryEntity) && !odReqFragmentsEntity.getIsLogTimeCreated()) {
			Float redmineLoggedHours = consolidatedLogEntryEntity.getLoggedHours();

			// full day on duty
			if (logHoursNeeded == 8.0) {
				if (redmineLoggedHours > 0) {
					if (redmineLoggedHours >= 8.0) {
						logTime = (float) 0;
					} else if (redmineLoggedHours > 4.0 && redmineLoggedHours < 8.0) {
						if (isLeave) {
							logTime = (float) 0;
						} else {
							logTime = (float) (8.0 - redmineLoggedHours);
						}
					} else {
						logTime = (float) (8.0 - redmineLoggedHours);
					}
				} else {
					logTime = logHoursNeeded;
				}
			}

			// half day on duty
			else if (logHoursNeeded == 4.0) {
				if (redmineLoggedHours > 0) {
					if (redmineLoggedHours > 4.0 && redmineLoggedHours <= 8.0) {
						if(isLeave) {
							logTime = (float) 0;
						}else {					
							logTime = (float) 8.0 - redmineLoggedHours;
						}
					} else {
						if(isLeave) {							
							logTime = (float) 0;
						}else {							
							logTime = (float) 4.0;
						}
					}
				} else {
					logTime = logHoursNeeded;
				}
			}
		}

		return logTime;
	}

	/**
	 * Method to remove log entry details upon on duty request withdraw
	 * 
	 * @param leaveRequestId
	 */
	public void removeLogReportEntry(Integer leaveRequestId) {

		List<Date> spentOnDateList = new ArrayList<>();
		List<RedmineNotLoggedEntity> notLoggedEntityList = new ArrayList<>();
		List<RedmineConsolidatedLogEntity> consolidatedDeleteList = new ArrayList<>();
		List<RedmineConsolidatedLogEntity> consolidatedSaveList = new ArrayList<>();

		OnDutyRequestEntity odRequestEntity = odRequestRepo.findById(leaveRequestId).orElse(null);

		int kairoUserId = odRequestEntity.getApplicantId();

		List<OnDutyRequestFragmentsEntity> odFragmentsEntityList = odRequestFragmentsRepo
				.findAllByLeaveRequestIdAndIsLogTimeCreated(leaveRequestId, true);

		spentOnDateList = odFragmentsEntityList.stream().map(OnDutyRequestFragmentsEntity::getFragmentDate)
				.collect(Collectors.toList());

		List<RedmineLogReportEntity> logReportDeletedList = logReportRepo
				.deleteBySpentOnInAndKairoUserIdAndProjectName(spentOnDateList, kairoUserId, "ONDUTY");

		if (!spentOnDateList.isEmpty()) {

			List<RedmineConsolidatedLogEntity> consolidatedLogEntityList = consolidatedLogReportRepo
					.findBySpentOnInAndKairoUserId(spentOnDateList, kairoUserId);

			if (!logReportDeletedList.isEmpty()) {
				logReportDeletedList.stream().forEach(logEntity -> {
					RedmineConsolidatedLogEntity consolidatedLogEntity = consolidatedLogEntityList.stream()
							.filter(rec -> rec.getSpentOn().equals(logEntity.getSpentOn())).findFirst().orElse(null);

					if (Objects.nonNull(consolidatedLogEntityList)) {
						float loggedHours = consolidatedLogEntity.getLoggedHours() - logEntity.getHours();
						List<Integer> idList = Arrays
								.asList(consolidatedLogEntity.getRedmineLogReportIds().replace("[", "").replace("]", "")
										.split(","))
								.stream().map(id -> Integer.parseInt(id.trim())).collect(Collectors.toList());
						idList.remove(logEntity.getId());

						if (loggedHours > 0) {
							consolidatedLogEntity.setLoggedHours(loggedHours);
							consolidatedLogEntity.setRedmineLogReportIds(idList.toString());
							consolidatedSaveList.add(consolidatedLogEntity);
						} else {
							consolidatedDeleteList.add(consolidatedLogEntity);
						}
					}
				});
			}

			if (!consolidatedDeleteList.isEmpty()) {
				consolidatedLogReportRepo.deleteAll(consolidatedDeleteList);
			}

			if (!consolidatedSaveList.isEmpty()) {
				consolidatedLogReportRepo.saveAll(consolidatedSaveList);
			}

			odRequestEntity.setIsFullyLogged(false);
			odRequestRepo.save(odRequestEntity);

			odFragmentsEntityList.stream().forEach(frag -> {
				frag.setIsLogTimeCreated(false);
				frag.setLogTimeAdded((float) 0);
			});

			odRequestFragmentsRepo.saveAll(odFragmentsEntityList);
		}

		List<LocalDate> spentOnLocalDateList = spentOnDateList.stream().map(rec -> DateUtils.convertToLocalDate(rec))
				.collect(Collectors.toList());

		List<RedmineNotLoggedEntity> notLoggedList = notLoggedRepo.findByFlawDateInAndKairoUserId(spentOnLocalDateList,
				kairoUserId);

		if (!notLoggedList.isEmpty()) {
			logReportDeletedList.stream().forEach(logEntity -> {
				RedmineNotLoggedEntity notLoggedEntity = notLoggedList.stream().filter(
						notlog -> notlog.getFlawDate().equals(DateUtils.convertToLocalDate(logEntity.getSpentOn())))
						.findFirst().orElse(null);

				if (Objects.nonNull(notLoggedEntity)) {

					if (logEntity.getHours() >= 8.0) {
						notLoggedEntity.setIsFullDay(true);
						notLoggedEntity.setIsHalfDay(false);
						notLoggedEntity.setInsufficientHours((float) 8.0);
					} else {
						notLoggedEntity.setIsFullDay(false);
						notLoggedEntity.setIsHalfDay(true);
						notLoggedEntity.setInsufficientHours(logEntity.getHours());
					}
					notLoggedEntity.setIsLeaveApplied(false);
					notLoggedEntityList.add(notLoggedEntity);
				}
			});

			if (!notLoggedEntityList.isEmpty()) {
				notLoggedRepo.saveAll(notLoggedEntityList);
			}
		}
	}

	/**
	 * Method to check if for an OD Request all OD Request fragments are Logged
	 */
	private void checkIfFullyLogged() {

		List<OnDutyRequestEntity> odRequestEntityList = odRequestRepo.getOnDutyEntityList();

		List<Integer> odRequestIdList = odRequestEntityList.stream().map(OnDutyRequestEntity::getId)
				.collect(Collectors.toList());

		List<OnDutyRequestFragmentsEntity> odRequestFragmentEntityList = odRequestFragmentsRepo
				.findAllByLeaveRequestIdIn(odRequestIdList);

		if (!odRequestEntityList.isEmpty()) {
			odRequestEntityList.stream().forEach(entity -> {
				
				 List<OnDutyRequestFragmentsEntity> loggedODFragmemts = odRequestFragmentEntityList.stream()
						.filter(cond -> cond.getLeaveRequestId() == entity.getId())
						.filter(cond -> cond.getIsLogTimeCreated().equals(true))
						.collect(Collectors.toList());
				
				 if(!loggedODFragmemts.isEmpty()) {
					 	Float totalDays = loggedODFragmemts.stream()
						.map(OnDutyRequestFragmentsEntity::getNoOfDays)
						.reduce(Float::sum).get();
					 	
						if (entity.getNoOfDays().equals(totalDays)) {
							entity.setIsFullyLogged(true);
						}
				 }
				
			});

			odRequestRepo.saveAll(odRequestEntityList);
		}

	}
}
