package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Table(name = "leave_request_fragments")
public class LeaveRequestFragmentsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Temporal(TemporalType.DATE)
	private Date fragmentDate;
	
	private Integer year;
	
	private String month;
	
	private Integer dayNo;
	
	private String dayName;
	
	private String dayType;
	
	private String noonType;
	
	private Boolean isFullday;
	
	private Boolean isConflict;
	
	private Boolean isUtilizationUpdated;
	
	@Column(name = "leave_request_id")
	private Integer leaveRequestId;
	
	private Float noOfDays;
	
}
