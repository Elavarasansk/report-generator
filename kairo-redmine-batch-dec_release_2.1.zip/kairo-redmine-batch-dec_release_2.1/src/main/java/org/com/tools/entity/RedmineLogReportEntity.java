package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "redmine_log_report")
public class RedmineLogReportEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private Integer logEntryId;
	
	private Integer activityId;
	
	private Integer issueId;
	
	private Integer projectId;
	
	private Integer redmineUserId;
	
	@Column(name = "redmine_url_master_id")
	private Integer redmineUrlMasterId;
	
	private Float hours;
	
	private String userName;
	
	private String projectName;
	
	private String activityName;
	
	@Temporal(TemporalType.DATE)
	private Date createdOn;
	
	@Temporal(TemporalType.DATE)
	private Date updatedOn;
	
	@Temporal(TemporalType.DATE)
	private Date spentOn;
	
	@Column(name = "kairo_user_id")
	private Integer kairoUserId;
	
	@Column(name = "kairo_user_project_id")
	private Integer kairoUserProjectId;
	
	@Column(name = "project_allocation_id")
	private Integer projectAllocId;
	
	private String dayName;
	
	private String month;
	
	private Integer year;
	
	private Integer dayNo;
	
	private String dayType;

}
