package org.com.tools.enums;

public enum LeaveType {

	 SICK_LEAVE, CASUAL_LEAVE, EARNED_LEAVE, SPECIAL_LEAVE, MATERNITY_LEAVE, PATERNITY_LEAVE
     
}
