package org.com.tools.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.com.tools.entity.OnDutyRequestFragmentsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OnDutyRequestFragmentsRepository extends JpaRepository<OnDutyRequestFragmentsEntity, Integer> {

	OnDutyRequestFragmentsEntity findByFragmentDateAndLeaveRequestId(Date fragmentDate, Integer leaveRequestId);

	List<OnDutyRequestFragmentsEntity> findAllByLeaveRequestIdAndIsLogTimeCreated(int leaveRequestId,
			Boolean isLogTimeCreated);

	@Query(value = "SELECT odfrag.* FROM od_request_fragments AS odfrag " + 
			"INNER JOIN od_request AS odreq ON odreq.id = odfrag.leave_request_id " + 
			"WHERE odreq.isFullyLogged = FALSE AND odfrag.isLogTimeCreated = FALSE AND odreq.status = \"APPROVED\"", nativeQuery = true)
	List<OnDutyRequestFragmentsEntity> getOnDutyFragmentsForApproved();

	List<OnDutyRequestFragmentsEntity> findAllByLeaveRequestIdIn(List<Integer> odRequestIdList);
	
	@Query(value="SELECT * FROM od_request_fragments WHERE leave_request_id IN "
			+ "(SELECT id FROM od_request WHERE applicant_id IN (SELECT id FROM kairo_user WHERE id=:id) "
			+ "AND status = \"APPROVED\") AND fragmentDate=:fragmentDate", nativeQuery = true)
	List<OnDutyRequestFragmentsEntity> getUserODRequestsOnDate(@Param("id") Integer id,
			@Param("fragmentDate") LocalDate fragmentDate);
	
	@Query(value="SELECT * FROM od_request_fragments as odreqfrag "
			+ " INNER JOIN od_request as odreq on odreq.id = odreqfrag.leave_request_id "
			+ " WHERE leave_request_id IN "
			+ "(SELECT id FROM od_request WHERE applicant_id IN (?1) "
			+ "AND status = \"APPROVED\") AND fragmentDate = ?2", nativeQuery = true)
	List<OnDutyRequestFragmentsEntity> getAllUserODFragmentsOnADate(List<Integer> idList, LocalDate fragmentDate);

}
