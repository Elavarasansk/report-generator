package org.com.tools.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.com.tools.entity.HolidaysEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface HolidaysRepository extends JpaRepository<HolidaysEntity, Integer> {

	HolidaysEntity findByActiveAndOccasionDate(boolean active, LocalDate today);
	
	@Query(value = "SELECT pa.id AS projectAllocId,ku.id AS kairoUserId,shift.id AS shiftId,shift.hoursPerDay,ct.id AS locationId," +
			"st.id AS stateId,st.country_id AS countryId,org.id AS organisationId,pa.project_id AS projectId FROM project_allocation pa " + 
			"INNER JOIN kairo_shift_configuration shift ON shift.id = pa.shift_id " + 
			"INNER JOIN city ct ON ct.id = pa.city_id " +
			"INNER JOIN state st ON st.id = ct.state_id " +
			"INNER JOIN kairo_user ku ON ku.id = pa.employee_id " +
			"INNER JOIN project prj ON prj.id = pa.project_id " +
			"INNER JOIN organisation_division orgdiv ON orgdiv.id = prj.organisation_division_id " + 
			"INNER JOIN organisation org ON org.id = orgdiv.organisation_id " + 
			"WHERE ku.active = TRUE AND pa.current = TRUE " +
			"ORDER BY kairoUserId ", nativeQuery = true)
	List<Map<String, Object>> getAllActiveUser();
}
