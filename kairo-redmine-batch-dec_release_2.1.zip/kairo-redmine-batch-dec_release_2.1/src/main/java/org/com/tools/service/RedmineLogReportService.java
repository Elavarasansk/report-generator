package org.com.tools.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.dto.DailyActiveUsersDto;
import org.com.tools.dto.KairoDailyBatchUsersListDto;
import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.ProjectAllocationEntity;
import org.com.tools.entity.RedmineLogReportEntity;
import org.com.tools.entity.RedmineMasterSettings;
import org.com.tools.entity.RedmineUserDetailsEntity;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.ProjectAllocationRepository;
import org.com.tools.repository.RedmineLogReportRepositiory;
import org.com.tools.repository.RedmineMasterSettingsRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.DateUtils;
import org.com.tools.utility.HolidaysManager;
import org.com.tools.utility.KairoRedmineManager;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taskadapter.redmineapi.bean.TimeEntry;

/**
 * RedmineLogReportService gets all the log entry of each user. Daily entry of
 * user(issues wise log wll be fetched).
 *
 */
@Service
public class RedmineLogReportService {
	
	@Autowired
	KairoUserRepository kairoUserRepo;

	@Autowired
	RedmineUserDetailsRepository redmineUserRepo;

	@Autowired
	RedmineLogReportRepositiory logReportRepo;

	@Autowired
	ProjectAllocationRepository projectAllocRepo;

	private KairoRedmineManager redmineManager;
	
	@Autowired
	RedmineMasterSettingsRepository redmineMasterSettingsRepo;
	
	@Autowired
	HolidaysManager holidayManager;
	
	@Autowired
	KairoDailyBatchService dailyService;

	/**
	 * getRedmineLogReport triggers log entry fetch from redmine.
	 * 
	 * @return status
	 */
	public String getRedmineLogReport(LocalDate executionDate) {
		List<DailyActiveUsersDto> activeUser = holidayManager.getTodayActiveUsers(executionDate);
		
		if(!activeUser.isEmpty()) {
			Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = getRedmineUrlDetails();
			
			List<Integer> kairoUserList = activeUser.stream().map(DailyActiveUsersDto::getKairoUserId)
					.distinct().collect(Collectors.toList());
			
			List<String> activeUsersMailList = kairoUserRepo.findAllByIdIn(kairoUserList)
					.stream().map(KairoUserEntity::getEmail).collect(Collectors.toList());

			List<RedmineUserDetailsEntity> dbRedmineUsers = getRedmineUserEntity(activeUsersMailList);
			Map<Integer, List<RedmineUserDetailsEntity>> groupByRedmineUrlId = dbRedmineUsers.stream()
					.collect(Collectors.groupingBy(RedmineUserDetailsEntity::getRedmineUrlMasterId));

			groupByRedmineUrlId.entrySet().forEach(e -> {
				int redmineUrlId = e.getKey();
				List<RedmineUserDetailsEntity> redmineUsers = e.getValue();

				RedmineMasterSettings masterData = redmineUrlDetailsMap.get(redmineUrlId).get(0);
				this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
				fetchRedmineTimeEntriesManager(executionDate, redmineUsers, redmineUrlId);
			});
			
			KairoDailyBatchUsersListDto activeUserList = KairoDailyBatchUsersListDto.builder()
					 .date(executionDate.toString()).mailId(activeUsersMailList).build();
			
			dailyService.preCheckCumulativeBatch(executionDate, activeUserList, false);
			return "Log Report Migrated";
		} else {
			return "Log Repor Not Migrated - Weekend or Holiday";
		}
	}

	/**
	 * getRedmineLogReportForSpecifiedUsers triggers log entry fetch
	 * for specified user from redmine.
	 * 
	 * @return status
	 */
	public String getRedmineLogReportForSpecifiedUsers(KairoDailyBatchUsersListDto userList) {
		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = getRedmineUrlDetails();
		
		List<RedmineUserDetailsEntity> dbRedmineUsers = getRedmineUserEntity(userList.getMailId());
		Map<Integer, List<RedmineUserDetailsEntity>> groupByRedmineUrlId = dbRedmineUsers.stream()
				.collect(Collectors.groupingBy(RedmineUserDetailsEntity::getRedmineUrlMasterId));
		
		groupByRedmineUrlId.entrySet().forEach(e -> {
			int redmineUrlId = e.getKey();
			List<RedmineUserDetailsEntity> redmineUsers = e.getValue();
			
			RedmineMasterSettings masterData = redmineUrlDetailsMap.get(redmineUrlId).get(0);
			this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
			fetchRedmineTimeEntriesManager(LocalDate.parse(userList.getDate()), redmineUsers, redmineUrlId);
		});
		return "Log Report Migrated";
	}
	

	private List<RedmineUserDetailsEntity> getRedmineUserEntity(List<String> usersMaidIdList) {

		List<RedmineUserDetailsEntity> dbRedmineUsers = new ArrayList<>();

		if(Objects.nonNull(usersMaidIdList)) {
			dbRedmineUsers = redmineUserRepo.findAllByMailIdIn(usersMaidIdList);
		} else {
			dbRedmineUsers = redmineUserRepo.findAll();
		}
		return dbRedmineUsers;
	}


	/**
	 * fetchRedmineTimeEntriesManager fetches redmine log entry and inserts in
	 * redmine_log_report table
	 */
	private void fetchRedmineTimeEntriesManager(LocalDate executionDate, List<RedmineUserDetailsEntity> dbRedmineUsers, int redmineUrlMasterId) {
		
		Map<Integer, Integer> usersMap = dbRedmineUsers.stream()
				.collect(Collectors.toMap(RedmineUserDetailsEntity::getRedmineUserId,
				RedmineUserDetailsEntity::getKairoUserId));

		List<Integer> userList = usersMap.values().stream().collect(Collectors.toList());
		List<ProjectAllocationEntity> projectAllocList = projectAllocRepo.findByCurrentAndEmployeeIdIn(true, userList);

		List<TimeEntry> timeEntryList = redmineManager.getTodayTimeEntries(executionDate).stream()
				.filter(entry -> usersMap.keySet().contains(entry.getUserId())).collect(Collectors.toList());

		List<RedmineLogReportEntity> logReportList = new ArrayList<>();
		timeEntryList.stream().forEach(entry -> {
			RedmineLogReportEntity entity = RedmineLogReportEntity.builder().build();

			RedmineUserDetailsEntity userEntity = dbRedmineUsers.stream()
					.filter(user -> user.getRedmineUserId().equals(entry.getUserId())).findFirst().orElse(null);

			ProjectAllocationEntity projectAllocId = projectAllocList.stream()
					.filter(prj -> prj.getEmployeeId().equals(userEntity.getKairoUserId())).findFirst().orElse(null);

			BeanUtils.copyProperties(entry, entity);
			
			LocalDate spentOn = DateUtils.convertToLocalDate(entry.getSpentOn());

			entity.setId(null);
			entity.setRedmineUserId(entry.getUserId());
			entity.setProjectId(entry.getProjectId());
			entity.setLogEntryId(entry.getId());
			entity.setRedmineUrlMasterId(redmineUrlMasterId);
			entity.setKairoUserId(userEntity.getKairoUserId());
			entity.setKairoUserProjectId(userEntity.getKairoUserProjectId());
			entity.setProjectAllocId(projectAllocId.getId());
			entity.setDayName(spentOn.getDayOfWeek().toString().toUpperCase());
			entity.setMonth(spentOn.getMonth().toString().toUpperCase());
			entity.setDayNo(spentOn.getDayOfMonth());
			entity.setYear(spentOn.getYear());
			entity.setDayType(spentOn.getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY");

			logReportList.add(entity);
		});
		List<Integer> kairoUserIdList = dbRedmineUsers.stream().map(RedmineUserDetailsEntity::getKairoUserId).collect(Collectors.toList());
		logReportRepo.deleteBySpentOnAndRedmineUrlMasterIdAndKairoUserIdIn(DateUtils.convertToUtilDate(executionDate), redmineUrlMasterId, kairoUserIdList);
		
		if (!logReportList.isEmpty()) {
//			logReportRepo.deleteBySpentOn(DateUtils.convertToUtilDate(executionDate));
//			List<Integer> kairoUserIdList = logReportList.stream().map(RedmineLogReportEntity::getKairoUserId).collect(Collectors.toList());
//			logReportRepo.deleteBySpentOnAndKairoUserIdIn(DateUtils.convertToUtilDate(executionDate), kairoUserIdList);
			
			//Redmine Migration issue - issueId is null
			List<RedmineLogReportEntity> validLogReportList = logReportList.stream()
					.filter(data -> Objects.nonNull(data.getIssueId())).collect(Collectors.toList());
			logReportRepo.saveAll(validLogReportList);
		}
	}

	/**
	 * insertLogEntriesIntoLogReport , to insert altered and updated logged entries
	 * into Redmine log report table
	 * 
	 * @param redmineKairoUserIdMap
	 * @param loggedList
	 * 
	 */

	public void insertPreviousNotLoggedEntries(List<TimeEntry> loggedList,
			Map<Integer, Integer> redmineKairoUserIdMap, int redmineUrlMasterId) {
		if (!redmineKairoUserIdMap.isEmpty()) {

			List<RedmineLogReportEntity> logReportEntityList = new ArrayList<RedmineLogReportEntity>();

			List<Integer> userIdList = redmineKairoUserIdMap.values().stream().collect(Collectors.toList());

			List<ProjectAllocationEntity> projectAllocList = projectAllocRepo.findByCurrentAndEmployeeIdIn(true,userIdList);

			List<RedmineLogReportEntity> logReportFromDBList = logReportRepo.findByKairoUserIdIn(userIdList);

			loggedList.stream().forEach(data -> {

				ProjectAllocationEntity projectAllocId = projectAllocList.stream()
						.filter(prj -> userIdList.contains(prj.getEmployeeId())).findFirst().orElse(null);

				Map<Integer, List<RedmineLogReportEntity>> logReportMapByIssueId = logReportFromDBList.stream()
						.filter(entry -> entry.getLogEntryId().equals(data.getId()))
						.filter(entry -> entry.getKairoUserId().equals(redmineKairoUserIdMap.get(data.getUserId())))
						.filter(entry -> entry.getSpentOn().equals(data.getSpentOn()))
						.filter(entry -> entry.getRedmineUrlMasterId().equals(redmineUrlMasterId))
						.collect(Collectors.groupingBy(RedmineLogReportEntity::getIssueId));

				if (!logReportMapByIssueId.isEmpty()) {
					RedmineLogReportEntity currentIssue = logReportMapByIssueId.get(data.getIssueId()).get(0);
					if (Objects.nonNull(currentIssue)) {
						currentIssue.setHours(data.getHours());
						currentIssue.setRedmineUrlMasterId(redmineUrlMasterId);
						logReportEntityList.add(currentIssue);
					}
				} else {
					RedmineLogReportEntity entity = RedmineLogReportEntity.builder().build();

					BeanUtils.copyProperties(data, entity);

					LocalDate spentOn = DateUtils.convertToLocalDate(entity.getSpentOn());
					
					entity.setId(null);
					entity.setRedmineUserId(data.getUserId());
					entity.setRedmineUrlMasterId(redmineUrlMasterId);
					entity.setProjectId(data.getProjectId());
					entity.setLogEntryId(data.getId());
					entity.setKairoUserId(redmineKairoUserIdMap.get(data.getUserId()));
					entity.setKairoUserProjectId(projectAllocId.getProjectId());
					entity.setProjectAllocId(projectAllocId.getId());
					entity.setDayName(spentOn.getDayOfWeek().toString().toUpperCase());
					entity.setMonth(spentOn.getMonth().toString().toUpperCase());
					entity.setDayNo(spentOn.getDayOfMonth());
					entity.setYear(spentOn.getYear());
					entity.setDayType(spentOn.getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY");

					logReportEntityList.add(entity);
				}
			});
			
			for(RedmineLogReportEntity e:logReportEntityList) {
				logReportRepo.deleteBySpentOnAndKairoUserId(e.getSpentOn(),e.getKairoUserId());
			}

			if (!logReportEntityList.isEmpty()) {
				logReportRepo.saveAll(logReportEntityList);
			}
		}
	}
	
	private Map<Integer, List<RedmineMasterSettings>> getRedmineUrlDetails() {
		List<RedmineMasterSettings> redmineMasterSettingsList = redmineMasterSettingsRepo.findByActive(true);
		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = redmineMasterSettingsList.stream()
				.collect(Collectors.groupingBy(RedmineMasterSettings::getId));
		
		return redmineUrlDetailsMap;
	}

}
