package org.com.tools.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.com.tools.entity.KairoShiftConfigurationEntity;
import org.com.tools.entity.LeaveRequestEntity;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.entity.RedmineLogReportEntity;
import org.com.tools.entity.RedmineMasterSettings;
import org.com.tools.entity.RedmineNotLoggedEntity;
import org.com.tools.entity.RedmineUserDetailsEntity;
import org.com.tools.repository.KairoShiftConfigurationRepository;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.repository.RedmineLogReportRepositiory;
import org.com.tools.repository.RedmineMasterSettingsRepository;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.DateUtils;
import org.com.tools.utility.KairoRedmineManager;
import org.com.tools.utility.LeaveRequestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taskadapter.redmineapi.bean.TimeEntry;

@Service
public class KairoPreviousNotLoggedService {

	@Autowired
	RedmineLogReportRepositiory logReportRepo;

	@Autowired
	RedmineNotLoggedRepository redmineNotLoggedRepo;

	@Autowired
	RedmineConsolidatedLogRepository consolidatedRepo;

	@Autowired
	KairoShiftConfigurationRepository shiftRepo;

	@Autowired
	KairoRedmineManager redmineManager;

	@Autowired
	LeaveRequestUtils leaveReqUtils;

	@Autowired
	RedmineLogReportService redmineLogReportService;

	@Autowired
	KairoDailyBatchService kairoDailyBatchService;
	
	@Autowired
	RedmineUserDetailsRepository redmineUserRepo;

	@Autowired
	RedmineMasterSettingsRepository redmineMasterSettingsRepo;

	/**
	 * TriggerPreviousNotLoggedBatch initiate Previous Not Logged Check Daily Batch
	 * for Redmine - checkes for previous days not logged entires have been logged
	 * and update in redmine_notlogged table
	 */
	public void triggerPreviousNotLoggedBatch() {
		// Check for Previous Not Logged Entries
		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = getRedmineUrlDetails();
		redmineUrlDetailsMap.entrySet().forEach(e -> {
			int redmineUrlId = e.getKey();
			RedmineMasterSettings masterData = redmineUrlDetailsMap.get(redmineUrlId).get(0);
			this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
			
			List<RedmineNotLoggedEntity> previousNotLogged = redmineNotLoggedRepo.findAll();
			previousNotLogged = previousNotLogged.stream().filter(nLog -> ((nLog.getRedmineUrlMasterId() == 0) || 
					(nLog.getRedmineUrlMasterId() == redmineUrlId))).collect(Collectors.toList());
			
			if (!previousNotLogged.isEmpty()) {
				verifyPreviousNotLoggedEntries(previousNotLogged, redmineUrlId);
			}
		});
	}
	
	
//	public void triggerPreviousNotLoggedBatch() {
//		// Check for Previous Not Logged Entries
//		List<RedmineNotLoggedEntity> previousNotLogged = redmineNotLoggedRepo.findAll();
//		if (!previousNotLogged.isEmpty()) {
//			
//			/*
//			 * Split into two different sections
//			 * 1. With redmine-url-mappings partial logged
//			 * 2. Without redmine-mappinigs {run in all redmine servers.}
//			 * */
////			verifyPreviousNotLoggedEntries(previousNotLogged);
//			iterateAndClassifyLoggedUsers(previousNotLogged);
//		}
//	}
	
//	private void iterateAndClassifyLoggedUsers(List<RedmineNotLoggedEntity> previousNotLogged) {
//		List<Integer> kairoUserList = previousNotLogged.stream().map(e -> e.getKairoUserId()).collect(Collectors.toList());
//		List<RedmineUserDetailsEntity> redmineUserList = redmineUserRepo.findAllByKairoUserIdIn(kairoUserList);
//		
//		Map<Integer, List<RedmineUserDetailsEntity>> groupByRedmineUrlId = redmineUserList.stream()
//				.collect(Collectors.groupingBy(RedmineUserDetailsEntity::getRedmineUrlMasterId));
//	
//		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = getRedmineUrlDetails();
//		groupByRedmineUrlId.entrySet().forEach(e -> {
//			int redmineUrlId = e.getKey();
//			RedmineMasterSettings masterData = redmineUrlDetailsMap.get(redmineUrlId).get(0);
//			this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
//			
//			List<Integer> urlMappedUserList = e.getValue().stream().map(redmineUser -> redmineUser.getKairoUserId()).collect(Collectors.toList());
//			List<RedmineNotLoggedEntity> notLoggedByUrl = previousNotLogged.stream().filter(notLogged -> urlMappedUserList.contains(notLogged.getKairoUserId()) &&
//			     ((notLogged.getRedmineUserId() == 0) || (notLogged.getRedmineUrlMasterId() == redmineUrlId))
//					).collect(Collectors.toList());;
//			
//			verifyPreviousNotLoggedEntries(notLoggedByUrl,redmineUrlId);
//		});
//	}
	
	private Map<Integer, List<RedmineMasterSettings>> getRedmineUrlDetails() {
		List<RedmineMasterSettings> redmineMasterSettingsList = redmineMasterSettingsRepo.findByActive(true);
		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = redmineMasterSettingsList.stream()
				.collect(Collectors.groupingBy(RedmineMasterSettings::getId));
		
		return redmineUrlDetailsMap;
	}

	/**
	 * verifyPreviousNotLoggedEntries checks for previous not logged or
	 * insucfficient logged users present in redmine_notlogged table and
	 * update/delete the data daily before Daily batch triggers
	 * 
	 * @param notLoggedList
	 *            (not logged or insufficent logged user form redmine_notlogged
	 *            table)
	 */
	private void verifyPreviousNotLoggedEntries(List<RedmineNotLoggedEntity> notLoggedList, int redmineUrlMasterId) {

		List<KairoShiftConfigurationEntity> shiftList = shiftRepo.findByActive(true);

		LocalDate minDate = notLoggedList.stream().map(RedmineNotLoggedEntity::getFlawDate)
				.min(Comparator.comparing(LocalDate::toEpochDay)).get();
		LocalDate maxDate = notLoggedList.stream().map(RedmineNotLoggedEntity::getFlawDate)
				.max(Comparator.comparing(LocalDate::toEpochDay)).get();

		
		Map<Integer, List<LocalDate>> userDateMap = formRedminUserDateMap(notLoggedList,redmineUrlMasterId);
//		Map<Integer, List<LocalDate>> userDateMap = notLoggedList.stream()
//				.collect(Collectors.groupingBy(RedmineNotLoggedEntity::getRedmineUserId,
//						Collectors.mapping(RedmineNotLoggedEntity::getFlawDate, Collectors.toList())));
		
		
		// need to check list of userId could be passed to REST API or not.
		List<TimeEntry> loggedList = redmineManager.getTimeEntriesRange(minDate, maxDate).stream()
				.filter(user -> Objects.nonNull(userDateMap.get(user.getUserId())))
				.filter(user -> userDateMap.keySet().contains(user.getUserId()))
				.filter(user -> userDateMap.get(user.getUserId()).contains(DateUtils.convertToLocalDate(user.getSpentOn())))
				.collect(Collectors.toList());

		List<Integer> loggedlistUserIdList = loggedList.stream().map(rec -> rec.getUserId()).distinct()
				.collect(Collectors.toList());

        List<RedmineUserDetailsEntity> redmineUserList = redmineUserRepo.findByRedmineUrlMasterIdAndRedmineUserIdIn(redmineUrlMasterId, loggedlistUserIdList);
		Map<Integer, Integer> redmineKairoUserIdMap = redmineUserList.stream().collect(Collectors.toMap(RedmineUserDetailsEntity::getRedmineUserId, RedmineUserDetailsEntity::getKairoUserId));
		Map<Integer, Integer> kairoToRedmineUserIdMap = redmineUserList.stream().collect(Collectors.toMap(RedmineUserDetailsEntity::getKairoUserId, RedmineUserDetailsEntity::getRedmineUserId));
		
//		Map<Integer, Integer> redmineKairoUserIdMap = notLoggedList.stream()
//				.filter(rec -> loggedlistUserIdList.contains(rec.getRedmineUserId()))
//				.collect(Collectors.toMap(RedmineNotLoggedEntity::getRedmineUserId, p -> p, (p, q) -> p)).values()
//				.stream().collect(Collectors.toMap(RedmineNotLoggedEntity::getRedmineUserId, RedmineNotLoggedEntity::getKairoUserId));

		if (!loggedList.isEmpty()) {
			List<RedmineNotLoggedEntity> deleteList = new ArrayList<>();
			List<RedmineNotLoggedEntity> updateList = new ArrayList<>();
			redmineLogReportService.insertPreviousNotLoggedEntries(loggedList, redmineKairoUserIdMap, redmineUrlMasterId);
			notLoggedList.stream().forEach(rec -> {
				List<TimeEntry> currentUserEntry = loggedList.stream()
						.filter(entry -> entry.getUserId().equals(kairoToRedmineUserIdMap.get(rec.getKairoUserId())))
						.filter(date -> DateUtils.convertToLocalDate(date.getSpentOn()).equals(rec.getFlawDate()))
						.collect(Collectors.toList());

				Float currentUserShiftHours = shiftList.stream().filter(shift -> shift.getId().equals(rec.getShiftId()))
						.findFirst().get().getHoursPerDay();

				if (!currentUserEntry.isEmpty()) {
					Float loggedHours = currentUserEntry.stream().map(TimeEntry::getHours).reduce(Float::sum).get();
					Float estimatedHours = rec.getEstimatedHours();
					if (loggedHours >= estimatedHours) {
						deleteList.add(rec);
					} else if (loggedHours < estimatedHours) {
						Float errorHours = roundOff(estimatedHours - loggedHours);
						if (!errorHours.equals(rec.getInsufficientHours())) {
							rec.setInsufficientHours(errorHours);
							if (rec.getIsFullDay() && loggedHours >= estimatedHours / 2) {
								rec.setIsHalfDay(true);
								rec.setIsFullDay(false);
							} else if (rec.getIsHalfDay() && estimatedHours.equals(currentUserShiftHours)
									&& loggedHours < estimatedHours / 2) {
								rec.setIsHalfDay(false);
								rec.setIsFullDay(true);
							}
							updateList.add(rec);
						}
					}
				} else {
					if (!rec.getEstimatedHours().equals(rec.getInsufficientHours())) {
						if (rec.getEstimatedHours().equals(currentUserShiftHours)) {
							rec.setIsHalfDay(false);
							rec.setIsFullDay(true);
						} else {
							rec.setIsHalfDay(true);
							rec.setIsFullDay(false);
						}
						updateList.add(rec);
					}
				}
			});
			
			List<RedmineNotLoggedEntity> consolidatedUpdateList = Stream
					.concat(deleteList.stream(), updateList.stream()).collect(Collectors.toList());

			if (!consolidatedUpdateList.isEmpty()) {
				updateConsolidatedLogDetails(consolidatedUpdateList, redmineUrlMasterId);
				redmineNotLoggedRepo.deleteAll(deleteList);
			}

			if (!updateList.isEmpty()) {
				redmineNotLoggedRepo.saveAll(updateList);
			}
		}

		checkIfPreviousLeaveApplied();
	}

	/**
	 * checkIfPreviousLeaveApplied verifies if not logged or insufficent logged user
	 * present in redine_notlogged table have applied leave for particular flaw day.
	 */
	private void checkIfPreviousLeaveApplied() {
		List<RedmineNotLoggedEntity> notLoggedList = redmineNotLoggedRepo.findByIsLeaveApplied(false);

		Map<LocalDate, List<Integer>> userLeaveCheckMap = notLoggedList.stream()
				.collect(Collectors.groupingBy(RedmineNotLoggedEntity::getFlawDate,
						Collectors.mapping(RedmineNotLoggedEntity::getKairoUserId, Collectors.toList())));

		Map<Integer, List<LeaveRequestEntity>> resMap = leaveReqUtils.getUserLeaveRequest(userLeaveCheckMap);
		if (!resMap.isEmpty()) {
			List<Integer> kairoUserIds = resMap.keySet().stream().collect(Collectors.toList());
			notLoggedList = redmineNotLoggedRepo.findByKairoUserIdInAndIsLeaveApplied(kairoUserIds, false);
			kairoDailyBatchService.checkIfLeaveApplied(resMap, notLoggedList);
		}
	}

	/**
	 * updateConsolidatedLogDetails creates or updates entry in
	 * redmine_consolidate_logdetails table before deleting entry in
	 * redmin_notlogged table, for previous not logged or insufficient logged users.
	 * 
	 * @param notLoggedDeleteList
	 * @param loggedList
	 */
	private void updateConsolidatedLogDetails(List<RedmineNotLoggedEntity> consolidatedNotLoggedList,int redmineUrlMasterId) {

		List<Integer> kairoUserList = consolidatedNotLoggedList.stream().map(RedmineNotLoggedEntity::getKairoUserId)
				.collect(Collectors.toList());

		List<RedmineConsolidatedLogEntity> resultList = new ArrayList<>();

		List<RedmineConsolidatedLogEntity> consolidateUserList = consolidatedRepo.findByKairoUserIdIn(kairoUserList);

		List<RedmineLogReportEntity> logReportRepoList = logReportRepo.findByKairoUserIdIn(kairoUserList);

		consolidatedNotLoggedList.stream().forEach(entry -> {

			List<RedmineLogReportEntity> currentReportList = logReportRepoList.stream()
					.filter(rec -> rec.getKairoUserId().equals(entry.getKairoUserId()))
					.filter(rec -> rec.getSpentOn().equals(DateUtils.convertToUtilDate(entry.getFlawDate())))
					.collect(Collectors.toList());

		if(!currentReportList.isEmpty()) {				
			RedmineConsolidatedLogEntity currentUser = consolidateUserList.stream()
					.filter(rec -> rec.getKairoUserId().equals(entry.getKairoUserId()))
					.filter(rec -> rec.getSpentOn().equals(DateUtils.convertToUtilDate(entry.getFlawDate())))
					.findFirst().orElse(null);

			List<Integer> redmineLogReportIds = currentReportList.stream().map(RedmineLogReportEntity::getId)
					.collect(Collectors.toList());

				Float loggedHours = currentReportList.stream().map(RedmineLogReportEntity::getHours)
						.collect(Collectors.toList()).stream().reduce(Float::sum).get();

				if (Objects.nonNull(currentUser)) {
					currentUser.setLoggedHours(loggedHours);
					currentUser.setRedmineLogReportIds(redmineLogReportIds.toString());
					resultList.add(currentUser);
				} else {

					RedmineConsolidatedLogEntity entity = RedmineConsolidatedLogEntity.builder()
							.redmineUserId(entry.getRedmineUserId())
							.redmineUrlMasterId(redmineUrlMasterId)
							.spentOn(DateUtils.convertToUtilDate(entry.getFlawDate())).month(entry.getMonth())
							.dayName(entry.getDayName()).loggedHours(loggedHours)
							.redmineLogReportIds(redmineLogReportIds.toString()).kairoUserId(entry.getKairoUserId())
							.projectId(entry.getProjectId()).projectAllocId(entry.getProjectAllocId())
							.dayNo(entry.getFlawDate().getDayOfMonth())
							.year(entry.getFlawDate().getYear())
							.dayType(entry.getFlawDate().getDayOfWeek().getValue() > 5 ? "WEEKEND" : "WEEKDAY")
							.build();
				
						resultList.add(entity);
				}
			}
		});

		if (!resultList.isEmpty()) {
			consolidatedRepo.saveAll(resultList);
		}
	}
	
	private Map<Integer, List<LocalDate>> formRedminUserDateMap (List<RedmineNotLoggedEntity> notLoggedList, int redmineUrlMasterId) {
		List<Integer> kairoUserList = notLoggedList.stream().map(RedmineNotLoggedEntity::getKairoUserId).collect(Collectors.toList());
		List<RedmineUserDetailsEntity> redmineUserList = redmineUserRepo.findByRedmineUrlMasterIdAndKairoUserIdIn(redmineUrlMasterId, kairoUserList);
		
		Map<Integer, Integer> redmineToKairoMap = redmineUserList.stream().collect(Collectors.toMap(RedmineUserDetailsEntity::getKairoUserId, RedmineUserDetailsEntity::getRedmineUserId));
		
		Map<Integer, List<LocalDate>> kairoUserDateMap = notLoggedList.stream()
				.collect(Collectors.groupingBy(RedmineNotLoggedEntity::getKairoUserId,
						Collectors.mapping(RedmineNotLoggedEntity::getFlawDate, Collectors.toList())));
		
		Map<Integer, List<LocalDate>> redmineUserDateMap = new HashMap<Integer, List<LocalDate>>();
		kairoUserDateMap.entrySet().stream().forEach(e -> redmineUserDateMap.put(redmineToKairoMap.get(e.getKey()), e.getValue()));
		
		return redmineUserDateMap;
	}
	
	private Float roundOff(Float value) {
		return Float.valueOf(Math.round(value * 100)/100);
	}
}
