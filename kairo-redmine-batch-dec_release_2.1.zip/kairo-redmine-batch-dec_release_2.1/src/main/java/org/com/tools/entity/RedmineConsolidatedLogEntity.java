package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Table(name = "redmine_consolidated_logdetails")
public class RedmineConsolidatedLogEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private Integer redmineUserId;
	
	@Column(name = "redmine_url_master_id")
	private Integer redmineUrlMasterId;
	
	@Column(name = "kairo_user_id")
	private Integer kairoUserId;
	
	@Column(name = "project_allocation_id")
	private Integer projectAllocId;
	
	@Temporal(TemporalType.DATE)
	private Date spentOn;
	
	private Float loggedHours;
	
	private String month;
	
	private String dayName;
	
	@Column(name = "redmine_log_report_ids")
	private String redmineLogReportIds;
	
	@Column(name = "kairo_user_project_id")
	private Integer projectId;
	
	@Builder.Default
	private Boolean active = true;
	
	private Integer year;
	
	private Integer dayNo;
	
	private String dayType;
	

}
