package org.com.tools.repository;

import java.util.Date;
import java.util.List;

import org.com.tools.entity.RedmineLogReportEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface RedmineLogReportRepositiory extends JpaRepository<RedmineLogReportEntity, Integer> {

	List<RedmineLogReportEntity> findBySpentOn(Date today);

	List<RedmineLogReportEntity> findBySpentOnAndKairoUserIdIn(Date today, List<Integer> userIds);

	List<RedmineLogReportEntity> findByIdIn(List<Integer> userIds);

	@Transactional
	List<RedmineLogReportEntity> deleteBySpentOn(Date date);
	
	@Transactional
	List<RedmineLogReportEntity> deleteBySpentOnAndKairoUserId(Date date, int kairoUserId);

	@Transactional
	List<RedmineLogReportEntity> deleteBySpentOnAndKairoUserIdIn(Date date, List<Integer> userIdList);

	@Transactional
	List<RedmineLogReportEntity> deleteBySpentOnAndRedmineUrlMasterIdAndKairoUserIdIn(Date date, int redmineUrlMasterId,
			List<Integer> userIdList);

	List<RedmineLogReportEntity> findByKairoUserIdIn(List<Integer> userIdList);

	@Transactional
	List<RedmineLogReportEntity> deleteBySpentOnAndIdIn(Date date, List<Integer> logReportIdsList);

	@Transactional
	List<RedmineLogReportEntity> deleteBySpentOnInAndKairoUserIdAndProjectName(List<Date> spentOnDateList, Integer kairoUserId, String projectName);

	List<RedmineLogReportEntity> findBySpentOnInAndKairoUserId(List<Date> spentOnDateList, Integer kairoUserId);

}
