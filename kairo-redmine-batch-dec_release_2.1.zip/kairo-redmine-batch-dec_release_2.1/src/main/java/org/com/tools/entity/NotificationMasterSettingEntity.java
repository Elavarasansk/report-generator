package org.com.tools.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Table(name = "notification_master_setting")
public class NotificationMasterSettingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private String moduleName;

	@Builder.Default
	private Boolean isMobileChangeAllowed = false;

	@Builder.Default
	private Boolean isWebChangeAllowed = false;

	@Builder.Default
	private Boolean isMailChangeAllowed = false;

	@Builder.Default
	private Boolean isServiceWorkerChangeAllowed = false;

	@Builder.Default
	private Boolean isMobilePush = false;

	@Builder.Default
	private Boolean isWebPush = false;

	@Builder.Default
	private Boolean isMailPush = false;

	@Builder.Default
	private Boolean isServiceWorkerPush = false;

	private String mobileTemplate;

	private String webTemplate;

	private String serviceWorkerTemplate;

	private String mailTemplate;

	private String modelName;

	private String methodlName;

	private String fieldsList;

}
