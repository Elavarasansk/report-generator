package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.KairoShiftConfigurationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface KairoShiftConfigurationRepository extends JpaRepository<KairoShiftConfigurationEntity, Integer> {

	List<KairoShiftConfigurationEntity> findByActive(Boolean active);
	
	@Query(value="SELECT* FROM kairo_shift_configuration WHERE "
			+ "id=(SELECT shift_id FROM project_allocation WHERE "
			+ "employee_id=(SELECT id FROM kairo_user WHERE id=:id) AND current=true)", nativeQuery=true)
	KairoShiftConfigurationEntity getUserProjectShiftDetails(@Param("id") Integer id);
	
}
