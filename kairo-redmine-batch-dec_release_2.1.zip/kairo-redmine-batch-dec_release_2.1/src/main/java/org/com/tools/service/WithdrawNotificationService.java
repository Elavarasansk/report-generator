package org.com.tools.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.constant.NotificationConstants;
import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.LeaveLogtimeConflictEntity;
import org.com.tools.entity.NotificationMasterSettingEntity;
import org.com.tools.entity.UserNotificationMessageEntity;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.NotificationMasterSettingRepository;
import org.com.tools.repository.UserNotificationMessageRepository;
import org.com.tools.repository.UserNotificationSettingRepository;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WithdrawNotificationService {

	@Autowired
	NotificationMasterSettingRepository notificationMasterSettingRepo;

	@Autowired
	UserNotificationMessageRepository userNotificationMessageRepo;

	@Autowired
	UserNotificationSettingRepository userNotificationSettingRepo;

	@Autowired
	KairoUserRepository kairoUserRepo;

	@Autowired
	NotLoggedNotificationService notLoggedService;
	
	@Autowired
	UserNotificationMailService userNotificationMailService;

	public void triggerWithdrawNotification(List<LeaveLogtimeConflictEntity> partialChangedEntryList) {
		sendWithdrawRevokedNotification(partialChangedEntryList);
	}

	/**
	 * @param partialChangedEntryList
	 * 
	 */
	private void sendWithdrawRevokedNotification(List<LeaveLogtimeConflictEntity> partialChangedEntryList) {
		
		NotificationMasterSettingEntity withdrawMasterSettingEntity = notificationMasterSettingRepo
				.findByModuleName(NotificationConstants.CONFLICT_WITHDRAW_REVOKED);

		NotificationMasterSettingEntity withdrawMasterSettingHeirarchyEntity = notificationMasterSettingRepo
				.findByModuleName(NotificationConstants.CONFLICT_WITHDRAW_REVOKED_HIERARCHY);

		List<Integer> applicantIdList = partialChangedEntryList.stream().map(LeaveLogtimeConflictEntity::getApplicantId)
				.collect(Collectors.toList());

		List<KairoUserEntity> kairoUserList = kairoUserRepo.findAllByIdIn(applicantIdList);

		if (!partialChangedEntryList.isEmpty()) {
			createNotificationForWithdrawRevoke(withdrawMasterSettingEntity, partialChangedEntryList, kairoUserList);
			createNotificationForWithdrawRevokeHeirarchy(withdrawMasterSettingHeirarchyEntity, partialChangedEntryList,
					kairoUserList);
		}
	}

	/**
	 * Create withdraw revoke notification message in web and mail for users and insert in notification message table
	 *  
	 * @param withdrawMasterSettingEntity
	 * @param partialChangedEntryList
	 * @param kairoUserList
	 */
	private void createNotificationForWithdrawRevoke(NotificationMasterSettingEntity withdrawMasterSettingEntity,
			List<LeaveLogtimeConflictEntity> partialChangedEntryList, List<KairoUserEntity> kairoUserList) {
		
		String mailTemplate = withdrawMasterSettingEntity.getMailTemplate();
		String webTemplate = withdrawMasterSettingEntity.getWebTemplate();
		Integer id = withdrawMasterSettingEntity.getId();

		List<Integer> applicantIdList = partialChangedEntryList.stream().map(LeaveLogtimeConflictEntity::getApplicantId)
				.collect(Collectors.toList());

		Map<Integer, Map<String, Boolean>> userSubscribedModulesMap = notLoggedService
				.getUserSubscribedModel(withdrawMasterSettingEntity, applicantIdList);

		if (!userSubscribedModulesMap.isEmpty()) {
			List<UserNotificationMessageEntity> userNotificationMsgEntityList = new ArrayList<>();

			partialChangedEntryList.stream().forEach(rec -> {
				KairoUserEntity kairoUser = kairoUserList.stream()
						.filter(predicate -> predicate.getId().toString().equals(rec.getApplicantId().toString())).findFirst().orElse(null);

				JSONObject fieldJSONObject = getMessageValues(rec, kairoUser);

				String mailMessage = Objects.nonNull(rec) ? replaceTemplate(mailTemplate, rec, kairoUser, "") : "";
				String webMessage = Objects.nonNull(rec) ? replaceTemplate(webTemplate, rec, kairoUser, "") : "";

				Map<String, Boolean> subscribeMap = Objects.nonNull(userSubscribedModulesMap.get(rec.getApplicantId()))
						? userSubscribedModulesMap.get(rec.getApplicantId())
						: notLoggedService.getDeafultSubscribeMap();

				JSONObject mailMessageNotifiaction = getNotificationMessage(mailMessage);
				JSONObject webMessageNotifiaction = getNotificationMessage(webMessage);

				UserNotificationMessageEntity messageEntity = UserNotificationMessageEntity.builder().id(null)
						.isWebSubscribed(Objects.nonNull(subscribeMap.get(NotificationConstants.IS_WEB_SUBSCRIBED))
								? subscribeMap.get(NotificationConstants.IS_WEB_SUBSCRIBED)
								: false)
						.isMobileSubscribed(
								Objects.nonNull(subscribeMap.get(NotificationConstants.IS_MOBILE_SUBSCRIBED))
										? subscribeMap.get(NotificationConstants.IS_MOBILE_SUBSCRIBED)
										: false)
						.isMailSubscribed(Objects.nonNull(subscribeMap.get(NotificationConstants.IS_MAIL_SUBSCRIBED))
								? subscribeMap.get(NotificationConstants.IS_MAIL_SUBSCRIBED)
								: false)
						.isServiceWorkerSubscribed(
								Objects.nonNull(subscribeMap.get(NotificationConstants.IS_SERVICE_WORKER_SUBSCRIBED))
										? subscribeMap.get(NotificationConstants.IS_SERVICE_WORKER_SUBSCRIBED)
										: false)
						.messageValues(fieldJSONObject.toString()).mailMessage(Arrays.asList(mailMessageNotifiaction).toString()).webMessage(Arrays.asList(webMessageNotifiaction).toString())
						.notification_type(id).recipientId(rec.getApplicantId()).isHr("false").build();

				userNotificationMsgEntityList.add(messageEntity);
			});
			
			List<UserNotificationMessageEntity> savedNotificationMessagesList = userNotificationMessageRepo.saveAll(userNotificationMsgEntityList);
			if(!savedNotificationMessagesList.isEmpty()) {				
				List<Integer> notificationMessageIdList = savedNotificationMessagesList.stream().map(UserNotificationMessageEntity::getId).distinct().collect(Collectors.toList());
				userNotificationMailService.sendMail(notificationMessageIdList);
			}
		}
	}

	/**
	 * Create withdraw revoke notification message in web and mail for heirarchy users and insert in notification message table
	 * 
	 * @param withdrawMasterSettingHeirarchyEntity
	 * @param partialChangedEntryList
	 * @param kairoUserList
	 */
	private void createNotificationForWithdrawRevokeHeirarchy(
			NotificationMasterSettingEntity withdrawMasterSettingHeirarchyEntity,
			List<LeaveLogtimeConflictEntity> partialChangedEntryList, List<KairoUserEntity> kairoUserList) {
		
		String mailTemplate = withdrawMasterSettingHeirarchyEntity.getMailTemplate();
		String webTemplate = withdrawMasterSettingHeirarchyEntity.getWebTemplate();
		Integer id = withdrawMasterSettingHeirarchyEntity.getId();

		List<Integer> applicantIdList = partialChangedEntryList.stream().map(LeaveLogtimeConflictEntity::getApplicantId)
				.collect(Collectors.toList());

		Map<Integer, List<String>> reportToDataMap = this.notLoggedService.getReportToMap(applicantIdList);

		List<Integer> reportToIdList = new ArrayList<>();

		reportToDataMap.entrySet().stream().forEach(rec -> {
			if (Objects.nonNull(rec) && !rec.getValue().isEmpty()) {
				reportToIdList.add(Integer.parseInt(rec.getValue().get(0)));
			}
		});

		Map<Integer, Map<String, Boolean>> userSubscribedModulesMap = notLoggedService
				.getUserSubscribedModel(withdrawMasterSettingHeirarchyEntity, reportToIdList);

		if (!userSubscribedModulesMap.isEmpty()) {
			List<UserNotificationMessageEntity> userNotificationMsgEntityList = new ArrayList<>();
			Map<Integer, Map<String, Boolean>> userSubscribedsMap = userSubscribedModulesMap;

			partialChangedEntryList.stream().forEach(rec -> {

				KairoUserEntity kairoUser = kairoUserList.stream()
						.filter(predicate -> predicate.getId().toString().equals(rec.getApplicantId().toString())).findFirst().orElse(null);

				JSONObject fieldJSONObject = getMessageValues(rec, kairoUser);

				if (!reportToDataMap.isEmpty() && !reportToDataMap.get(rec.getApplicantId()).isEmpty()) {

					List<String> reportToDetails = reportToDataMap.get(rec.getApplicantId());

					String recipientName = Objects.nonNull(reportToDetails.get(1)) ? reportToDetails.get(1) : "";

					fieldJSONObject.put("report_to",
							Objects.nonNull(reportToDetails.get(0)) ? reportToDetails.get(0) : "");
					fieldJSONObject.put("recipientName", recipientName);
					fieldJSONObject.put("email", Objects.nonNull(reportToDetails.get(1)) ? reportToDetails.get(2) : "");

					String mailMessage = Objects.nonNull(rec)
							? replaceTemplate(mailTemplate, rec, kairoUser, recipientName)
							: "";
					String webMessage = Objects.nonNull(rec)
							? replaceTemplate(webTemplate, rec, kairoUser, recipientName)
							: "";

					Map<String, Boolean> subscribeMap = Objects.nonNull(userSubscribedsMap.get(Integer.parseInt(reportToDetails.get(0))))
							? userSubscribedsMap.get(Integer.parseInt(reportToDetails.get(0)))
							: notLoggedService.getDeafultSubscribeMap();
									
					JSONObject mailMessageNotifiaction = getNotificationMessage(mailMessage);
					JSONObject webMessageNotifiaction = getNotificationMessage(webMessage);

					UserNotificationMessageEntity messageEntity = UserNotificationMessageEntity.builder().id(null)
							.isWebSubscribed(Objects.nonNull(subscribeMap.get(NotificationConstants.IS_WEB_SUBSCRIBED))
									? subscribeMap.get(NotificationConstants.IS_WEB_SUBSCRIBED)
									: false)
							.isMobileSubscribed(
									Objects.nonNull(subscribeMap.get(NotificationConstants.IS_MOBILE_SUBSCRIBED))
											? subscribeMap.get(NotificationConstants.IS_MOBILE_SUBSCRIBED)
											: false)
							.isMailSubscribed(
									Objects.nonNull(subscribeMap.get(NotificationConstants.IS_MAIL_SUBSCRIBED))
											? subscribeMap.get(NotificationConstants.IS_MAIL_SUBSCRIBED)
											: false)
							.isServiceWorkerSubscribed(Objects
									.nonNull(subscribeMap.get(NotificationConstants.IS_SERVICE_WORKER_SUBSCRIBED))
											? subscribeMap.get(NotificationConstants.IS_SERVICE_WORKER_SUBSCRIBED)
											: false)
							.messageValues(fieldJSONObject.toString()).mailMessage(Arrays.asList(mailMessageNotifiaction).toString()).webMessage(Arrays.asList(webMessageNotifiaction).toString())
							.notification_type(id)
							.recipientId(Integer.parseInt(reportToDataMap.get(rec.getApplicantId()).get(0)))
							.isHr("false").build();

					userNotificationMsgEntityList.add(messageEntity);
				}
			});

			List<UserNotificationMessageEntity> savedNotificationMessagesList = userNotificationMessageRepo.saveAll(userNotificationMsgEntityList);
			if(!savedNotificationMessagesList.isEmpty()) {				
				List<Integer> notificationMessageIdList = savedNotificationMessagesList.stream().map(UserNotificationMessageEntity::getId).distinct().collect(Collectors.toList());
				userNotificationMailService.sendMail(notificationMessageIdList);
			}
		}
	}

	/**
	 * Creates JSON object for message values to insert in notification message table
	 * 
	 * @param rec
	 * @param kairoUser
	 * @return JSON object as String
	 */
	private JSONObject getMessageValues(LeaveLogtimeConflictEntity rec, KairoUserEntity kairoUser) {
		// ["id","firstName","email","applicant_id","conflictDate"]
		JSONObject fieldJSONObject = new JSONObject();
		fieldJSONObject.put("id", rec.getId());
		fieldJSONObject.put("firstName", Objects.nonNull(kairoUser.getFirstName()) ? kairoUser.getFirstName() : "");
		fieldJSONObject.put("email", Objects.nonNull(kairoUser.getEmail()) ? kairoUser.getEmail() : "");
		fieldJSONObject.put("applicant_id", rec.getApplicantId());
		fieldJSONObject.put("conflictDate", rec.getConflictDate());
		fieldJSONObject.put("applicantEmail", Objects.nonNull(kairoUser.getEmail()) ? kairoUser.getEmail() : "");
		fieldJSONObject.put("modifiedOn", LocalDateTime.now());
		return fieldJSONObject;
	}

	/**
	 * Replace template strings with username and email
	 * 
	 * @param template
	 * @param rec
	 * @param kairoUser
	 * @param recipientName
	 * @return String
	 */
	private String replaceTemplate(String template, LeaveLogtimeConflictEntity rec, KairoUserEntity kairoUser,
			String recipientName) {
		template = template.toString();

		template = template.replace("[conflictDate]", rec.getConflictDate().toString());
		if (template.contains("[firstName]")) {
			template = template.replace("[firstName]", kairoUser.getFirstName().toString());
		}
		if (template.contains("[recipientName]")) {
			template = template.replace("[recipientName]", recipientName);
		}

		return template;
	}
	
	/**
	 * 
	 * @param rec
	 * @param message
	 * @return
	 */
	private JSONObject getNotificationMessage(String message) {
		JSONObject fieldJSONObject = new JSONObject();
		fieldJSONObject.put("message", message);
		fieldJSONObject.put("createdOn",LocalDateTime.now());
		return fieldJSONObject;
	}



}
