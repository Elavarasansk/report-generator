package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.UserNotificationSettingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserNotificationSettingRepository extends JpaRepository<UserNotificationSettingEntity, Integer>{

	List<UserNotificationSettingEntity> findAllByUserIdIn(List<Integer> kairoUserIdList);

}
