package org.com.tools.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "kairo_shift_configuration")
public class KairoShiftConfigurationEntity {

	@Id
	private Integer id;
	
	private String shiftName;
	
	private Float hoursPerDay;
	
	@Column(name = "workingDays")
	private String workingDays; 
	
	private Boolean active;
	
}
