package org.com.tools.utility;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.com.tools.repository.SchedulerConfigurationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.taskadapter.redmineapi.RedmineException;
import com.taskadapter.redmineapi.RedmineManager;
import com.taskadapter.redmineapi.RedmineManagerFactory;
import com.taskadapter.redmineapi.bean.TimeEntry;
import com.taskadapter.redmineapi.bean.User;

/**
 * KairoRedmineManager interacts with redmine REST API and fetches data based on
 * fileter Note: Redmine REST API KEY should have admin privilege to access the
 * redmineUserManager.
 *
 */
@Component
public class KairoRedmineManager {

	RedmineManager redmineManager;

	@Autowired
	SchedulerConfigurationRepository schedulerConfigRepo;

	public KairoRedmineManager() {
	}

	public KairoRedmineManager(String redmineUrl, String apiKey) {
		checkHostAvailability(redmineUrl);
		try {
			this.redmineManager = RedmineManagerFactory.createWithApiKey(redmineUrl, apiKey);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}

	/**
	 * getAllUsersList fetches all redmine users irrespection of the status and
	 * project Note: Redmine REST API key should have admin privilege.
	 * 
	 * @return List of User
	 */
	public List<User> getAllUsersList() {
		List<User> userManager = new ArrayList<>();
		try {
			List<User> offsetUserManager = new ArrayList<>();
			final Map<String, String> parameter = new HashMap<>();
			int offset = 0;
			parameter.put("limit", "100");
			parameter.put("active", "true");

			do {
				offsetUserManager = redmineManager.getUserManager().getUsers(parameter).getResults();
				userManager.addAll(offsetUserManager);
				parameter.put("offset", String.valueOf(offset = offset + 100));
			} while (offsetUserManager.size() == 100);
		} catch (RedmineException e) {
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
		return userManager;
	}

	/**
	 * getTodayTimeEntries fetches today times entries from redmine for all redmine
	 * users.
	 * 
	 * @return List of TimeEntry
	 */
	public List<TimeEntry> getTodayTimeEntries(LocalDate date) {
		final Map<String, String> parameter = new HashMap<>();

		parameter.put("from", String.valueOf(date));
		parameter.put("to", String.valueOf(date));
		parameter.put("limit", "100");

		return getTimeEntryFromRedmineRest(parameter);
	}

	/**
	 * getTimeEntriesWithUser fetched all time entries for particular date and user
	 * 
	 * @param date
	 * @param userId
	 * @return List of TimeEntry
	 */
	public List<TimeEntry> getTimeEntriesWithUser(LocalDate date, Integer userId) {
		final Map<String, String> parameter = new HashMap<>();

		parameter.put("from", date.toString());
		parameter.put("user_id", userId.toString());
		parameter.put("limit", "100");

		return getTimeEntryFromRedmineRest(parameter);
	}

	/**
	 * getTimeEntriesRange fetches time entries of all users by specified date
	 * range.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @return List of TimeEntry
	 */
	public List<TimeEntry> getTimeEntriesRange(LocalDate fromDate, LocalDate toDate) {
		final Map<String, String> parameter = new HashMap<>();

		parameter.put("from", fromDate.toString());
		parameter.put("to", toDate.toString());
		parameter.put("limit", "100");

		return getTimeEntryFromRedmineRest(parameter);
	}

	/**
	 * getTimeEntriesRangeWithUser fetches time entries of specified user by
	 * specified date range.
	 * 
	 * @param fromDate
	 * @param toDate
	 * @param userId
	 * @return List of TimeEntry
	 */
	public List<TimeEntry> getTimeEntriesRangeWithUser(LocalDate fromDate, LocalDate toDate, Integer userId) {
		final Map<String, String> parameter = new HashMap<>();

		parameter.put("from", fromDate.toString());
		parameter.put("to", toDate.toString());
		parameter.put("user_id", userId.toString());
		parameter.put("limit", "100");

		return getTimeEntryFromRedmineRest(parameter);
	}

	/**
	 * getTimeEntriesRangeWithUserOnSameDate fetches time entries of specified user
	 * by single date range.
	 * 
	 * @param date
	 * @param userId
	 * @return List of TimeEntry
	 */
	public List<TimeEntry> getTimeEntriesRangeWithUserOnSameDate(LocalDate date, Integer userId) {
		final Map<String, String> parameter = new HashMap<>();

		parameter.put("from", date.toString());
		parameter.put("to", date.toString());
		parameter.put("user_id", userId.toString());
		parameter.put("limit", "100");

		return getTimeEntryFromRedmineRest(parameter);
	}

	/**
	 * getTimeEntriesByUserList fetches time entries of user list by single date
	 * range.
	 * 
	 * @param date
	 * @param userList
	 * @return List of TimeEntry
	 */
	public List<TimeEntry> getTimeEntriesByDateAndUserList(LocalDate date, List<Integer> userList) {
		final Map<String, String> parameter = new HashMap<>();

		parameter.put("spent_on", date.toString());
		parameter.put("user_id", parseRedmineUsers(userList));
		parameter.put("limit", "100");

		return getTimeEntryFromRedmineRest(parameter);
	}

	private List<TimeEntry> getTimeEntryFromRedmineRest(Map<String, String> parameter) {
		List<TimeEntry> resultList = new ArrayList<>();
		try {
			int offset = 0;
			List<TimeEntry> offsetTimeEntries = new ArrayList<>();
			do {
				offsetTimeEntries = redmineManager.getTimeEntryManager().getTimeEntries(parameter).getResults();
				resultList.addAll(offsetTimeEntries);
				parameter.put("offset", String.valueOf(offset = offset + 100));
			} while (offsetTimeEntries.size() == 100);
		} catch (RedmineException e) {
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
		return resultList;
	}

	private void checkHostAvailability(String URL) {
		try {
			URL url = new URL(URL);
			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
			if (connection.getResponseCode() != HttpsURLConnection.HTTP_OK) {
				throw new Error("Redmine URL - " + URL + " could not be accessed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Error(e.getMessage());
		}
	}

	private String parseRedmineUsers(List<Integer> userList) {
		return userList.toString().replaceAll("[", "").replaceAll("]", "").replaceAll(",", "|").trim();
	}
}