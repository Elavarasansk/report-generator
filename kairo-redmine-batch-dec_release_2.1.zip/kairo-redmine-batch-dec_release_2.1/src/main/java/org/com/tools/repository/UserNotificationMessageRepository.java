package org.com.tools.repository;

import org.com.tools.entity.UserNotificationMessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserNotificationMessageRepository extends JpaRepository<UserNotificationMessageEntity, Integer>{

}
