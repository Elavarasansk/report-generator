package org.com.tools.utility;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.com.tools.repository.HolidaysRepository;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * DateUtils utility for LocalDate, util.date and sql.date processing and conversion
 *
 */
public class DateUtils {
	
	@Autowired
	HolidaysRepository holidaysRepo;

	/**
	 * isTodayBetween returns today between date range
	 * @param start
	 * @param end
	 * @return boolean
	 */
	public static boolean isTodayBetween(Date start, Date end) {
		Date today = java.sql.Date.valueOf(LocalDate.now());
		return (start.before(today) || start.equals(today)) && (end.after(today) || end.equals(today));
	}
	
	/**
	 * isFilterDateBetween return filter date between date range
	 * @param start
	 * @param end
	 * @param filter
	 * @return boolean
	 */
	public static boolean isFilterDateBetween(Date start, Date end, Date filter) {
		return (start.before(filter) || start.equals(filter)) && (end.after(filter) || end.equals(filter));
	}
	
	/**
	 * convertToLocalDate converts based on system default zone.
	 * @param date
	 * @return boolean
	 */
	public static LocalDate convertToLocalDate(Date date) {
		return LocalDate.from(Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate());
	}
	
	/**
	 * convertToUtilDate converts based on system default zone.
	 * @param date
	 * @return boolaen
	 */
	public static Date convertToUtilDate(LocalDate date) {
		return Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
	}
	
	/**
	 * get all dates between two given dates including startdate and enddate
	 * also set if holidays included or not and is end date included or not
	 * @param startDate
	 * @param endDate
	 * @param isEndDateIncluded
	 * @param isHolidaysIncluded
	 * @return
	 */
	public static List<LocalDate> getDatesBetweenTwoDates(LocalDate startDate, LocalDate endDate, Boolean isEndDateIncluded, Boolean isHolidaysIncluded) {
		long noOfDays = isEndDateIncluded ? Period.between(startDate, endDate).getDays() + 1 : Period.between(startDate, endDate).getDays();
		List<LocalDate> localDateList = IntStream.iterate(0, i -> i+1)
				.limit(noOfDays)
				.mapToObj(i -> startDate.plusDays(i))
				.collect(Collectors.toList());
		
		return localDateList;
	}
	
}
