package org.com.tools.dto;

import java.util.Date;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LeaveLogTimeConflictUserListDto {
	
	private Date date;
	private List<Integer> applicantIdList;

}
