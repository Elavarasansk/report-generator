package org.com.tools.aspects.concerns;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class ErrorLoggingConcern
 *
 */
@Aspect
@Component("ErrorLoggingConcern")
@Slf4j

public class ErrorLoggingConcern {
	
	@Value("${logs.delimiter}")
	private String delimiter;

	/**
	 * Log controller calls
	 */
	@Pointcut("execution(* org.com.tools.*.*.*(..))")
	private void logControllerCalls() {
	}

	/**
	 * Log method error
	 * 
	 * @param jp the jp
	 * 
	 */
	@AfterThrowing("logControllerCalls()")
	public void logMethodError(JoinPoint jp) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
		HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
		String ip = request.getRemoteHost();
		String method = request.getMethod();
		String browser = request.getHeader("user-agent");
		String path = request.getRequestURI();
		int statusCode= response.getStatus();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		String date = dtf.format(now);
		String logs = date + delimiter + ip + delimiter + method + delimiter + path + delimiter 
				+ statusCode + delimiter + browser;
		writeLogFile(logs);
		log.error(logs);

	}
	
	private void writeLogFile(String log) {
		String directory = System.getProperty("user.dir");
		File dir = new File(directory + "\\\\logs");
		File errorLogFile = new File(directory + "\\\\logs\\error_log.txt");
		try {
			if(!dir.exists()) {				
				Files.createDirectories(Paths.get(dir.toString()));
				Files.createFile(Paths.get(errorLogFile.toString()));
			}
			FileWriter writer = new FileWriter(directory + "\\\\logs\\error_log.txt", true);
			writer.write(log);
			writer.write("\r\n"); 
			writer.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}