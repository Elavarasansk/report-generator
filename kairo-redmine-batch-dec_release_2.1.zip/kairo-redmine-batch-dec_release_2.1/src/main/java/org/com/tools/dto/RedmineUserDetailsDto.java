package org.com.tools.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RedmineUserDetailsDto {

	private Integer id;
	
	private String userName;
	
	private String emailId;
	
	private String login;
	
	private String createdOn;
	
	private String lastLoginOn;
	
	private Boolean status;
	
	private Integer kairoUserId;
	
	private Integer projectId;
	
	
	
}
