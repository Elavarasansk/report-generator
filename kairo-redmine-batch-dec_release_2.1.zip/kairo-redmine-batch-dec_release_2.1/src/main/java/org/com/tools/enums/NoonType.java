package org.com.tools.enums;

public enum NoonType {
	
	FULLDAY, HALFDAY, FORENOON, AFTERNOON

}
