package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.ProjectAllocationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectAllocationRepository extends JpaRepository<ProjectAllocationEntity, Integer> {

	List<ProjectAllocationEntity> findByCurrent(boolean status);
	
	List<ProjectAllocationEntity> findByCurrentAndEmployeeIdIn(boolean status, List<Integer> ids);

	ProjectAllocationEntity findByCurrentAndEmployeeId(boolean current, int kairoUserId);

}
