package org.com.tools.entity;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Table(name = "user_notification_message")
public class UserNotificationMessageEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Builder.Default
	private Boolean isWebRead = false;

	@Builder.Default
	private Boolean isWebSubscribed = false;

	@Builder.Default
	private Boolean isMobileSubscribed = false;

	@Builder.Default
	private Boolean isMailSubscribed = false;

	@Builder.Default
	private Boolean isServiceWorkerSubscribed = false;

	@Builder.Default
	private Boolean isWebSent = false;

	@Builder.Default
	private Boolean isMailSent = false;

	@Builder.Default
	private Boolean isServiceWorkerSent = false;

	@Builder.Default
	private Boolean isMobileSent = false;

	private String webMessage;

	private String mailMessage;

	private String serviceWorkerMessage;

	private String mobileMessage;

	private String messageValues;

	@Column(name = "recipient_id")
	private Integer recipientId;

	private Integer notification_type;
	
	@Builder.Default
	private String isHr = "false"; 
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	@UpdateTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedOn;

}
