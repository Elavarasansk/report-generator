package org.com.tools.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "project_allocation")
public class ProjectAllocationEntity {

	@Id
	private Integer id;
	
	private Boolean current;
	
	private String department;
	
	@Column(name = "employee_id")
	private Integer employeeId;
	
	@Column(name = "project_id")
	private Integer projectId;
	
	@Column(name = "manager_id")
	private Integer managerId;
	
	@Column(name = "report_to")
	private Integer reporterId;
	
	@Column(name = "city_id")
	private Integer cityId;
	
	@Column(name = "role_id")
	private Integer roleId;
	
	@Column(name = "shift_id")
	private Integer shiftId;
	
}
