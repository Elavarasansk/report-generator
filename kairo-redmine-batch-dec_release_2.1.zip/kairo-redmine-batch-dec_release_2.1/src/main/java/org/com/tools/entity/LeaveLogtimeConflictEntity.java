package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Table(name = "leave_logtime_conflict")
public class LeaveLogtimeConflictEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Temporal(TemporalType.DATE)
	private Date conflictDate;

	private Integer year;

	private String month;

	private Integer dayNo;

	private String dayName;

	private String dayType;

	private String noonType;

	private String status;

	@Column(name = "leave_request_id")
	private Integer leaveRequestId;

	@Column(name = "leave_request_fragment_id")
	private Integer leaveRequestFragmentId;

	@Column(name = "redmine_consolidated_logdetails_id")
	private Integer redmineConsolidatedLogdetailsId;

	@Column(name = "applicant_id")
	private Integer applicantId;

	private Boolean isWithdrawApproved;
}
