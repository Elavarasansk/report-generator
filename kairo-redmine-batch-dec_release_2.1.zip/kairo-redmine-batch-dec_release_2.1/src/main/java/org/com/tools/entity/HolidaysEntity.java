package org.com.tools.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "holidays")
public class HolidaysEntity {
	
	@Id
	private Integer id;
	
	private String occasion;
	
	private LocalDate occasionDate;
	
	private Boolean active;
	
	private Boolean isInternational;
	
	private Boolean isCountrySpecific;
	
	private Boolean isStateSpecific;
	
	private Boolean isCitySpecific;
	
	private Boolean isOrgSpecific;
	
	private Boolean isShiftSpecific;
	
	private String noonType;
	
	private String dayName;
	
	private String dayType;
	
	private Integer year;
	
	private String month;
	
	@Column(name = "country_ids")
	private String countryIds;

	@Column(name = "state_ids")
	private String stateIds;
	
	@Column(name = "city_ids")
	private String cityIds;
	
	@Column(name = "organisation_ids")
	private String organisationIds;
	
	@Column(name = "shift_ids")
	private String shiftIds;

}
