package org.com.tools.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="redmine_notlogged")
public class RedmineNotLoggedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private Integer redmineUserId;
	
	@Column(name = "redmine_url_master_id")
	private Integer redmineUrlMasterId;

	private LocalDate flawDate;

	private Float insufficientHours;

	@Builder.Default
	private Boolean isFullDay = false;

	@Builder.Default
	private Boolean isHalfDay = false;

	private Float estimatedHours;

	@Builder.Default
	private Integer warningDays = 1;

	@Column(name = "shift_id")
	private Integer shiftId;

	@Column(name = "kairo_user_id")
	private Integer kairoUserId; 
	
	@Column(name = "kairo_user_project_id")
	private Integer projectId;
	
	@Column(name = "project_allocation_id")
	private Integer projectAllocId;

	private String dayName;

	private String month;
	
	@Builder.Default
	private Boolean isLeaveApplied = false;
	
	private Integer year;
	
	private Integer dayNo;
	
	private String dayType;

	@Builder.Default
	private Boolean isNotificationSent = false; 

}
