package org.com.tools.constant;

public class KairoRedmineConstants {
	
	//Scheduler Type
	public static final String REDMINE = "REDMINE";
	
	public static final String ON_DUTY = "ON-DUTY";

	//Scheduler Names
	public static final String USER_DETAILS = "REDMINE_USER_DETAILS_FETCH";
	
	public static final String LOG_ENTRIES = "REDMINE_LOG_ENTRIES_FETCH";

	public static final String DAILY_BATCH = "REDMINE_CALCULATE_DAILY_NOT_LOGGED";
	
	public static final String PREVIOUS_NOT_LOGGED = "REDMINE_PREVIOUS_NOT_LOGGED";

	public static final String LEAVE_CONFLICT = "LEAVE_CONFLICT_LOG_ENTRY_VALIDATE";
	
	public static final String SPECIFIC_USER_LOG_ENTRY = "REDMINE_USER_LOG_ENTRY";
	
	public static final String SPECIFIC_USER_CONSOLIDATED = "REDMINE_USER_LOG_CONSOLIDATED";
	
	public static final String LEAVE_CONFLICT_USER_DATE_LIST = "CONFLICT_LOG_VALIDATE_USER_DATE_LIST";
	
	public static final String LEAVE_CONFLICT_SPECIFIC_DATE_USER_LIST = "CONFLICT_LOG_VALIDATE_SPECIFIC_DATE_USER_LIST";
	
	public static final String LEAVE_CONFLICT_SPECIFIC_DATE_SPECIFIC_USER = "CONFLICT_LOG_VALIDATE_SPECIFIC_DATE_SPECIFIC_USER";
	
	public static final String ON_DUTY_LOG_ENTRY_CREATION = "ON_DUTY_LOG_ENTRY_CREATION";

	//Status
	public static final String INPROGRESS = "IN_PROGRESS";

	public static final String SUCCESS = "SUCCESS";

	public static final String FAILED = "FAILED";

}
