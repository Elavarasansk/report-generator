package org.com.tools.controller;

import java.util.Map;

import org.com.tools.service.KairoApiPreValidationService;
import org.com.tools.service.OnDutyLogReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class OnDutyLogReportController {

	@Autowired
	OnDutyLogReportService onDutyService;
	
	@Autowired
	KairoApiPreValidationService apiPreValidationService;

	/**
	 * Method to create Log Entry for one particular requestId - upon approval
	 * @param requestId
	 */
	@GetMapping("/on-duty/approve/create/logentry")
	public String createLogReportEntry(@RequestParam String requestId) {		
		onDutyService.triggerLogReportEntry(Integer.parseInt(requestId));
		return "On Duty Log Report Created Successfully";
	}

	/**
	 * Method to remove Log Entry for one particular requestId - upon withdrawal
	 * @param requestId
	 */
	@GetMapping("/on-duty/withdraw/remove/logentry")
	public String removeLogReportEntry(@RequestParam String requestId) {
		onDutyService.removeLogReportEntry(Integer.parseInt(requestId));
		return "On Duty Log Report Removed Successfully";
	}
	
	/**
	 * Method to create log entries for all approved  on duty requests
	 *  
	 */
	@GetMapping("/on-duty/approve/create/logentry/batch")
	public Map<String, String> triggerOnDutyBatch(@RequestHeader(value = "userId", required = false) Integer triggeredBy) {
		return apiPreValidationService.triggerOnDutyBatch(triggeredBy);
	}
}
