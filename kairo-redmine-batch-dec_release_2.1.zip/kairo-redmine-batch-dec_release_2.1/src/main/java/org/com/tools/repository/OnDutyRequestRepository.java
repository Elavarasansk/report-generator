package org.com.tools.repository;

import java.util.Date;
import java.util.List;

import org.com.tools.entity.OnDutyRequestEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OnDutyRequestRepository extends JpaRepository<OnDutyRequestEntity, Integer> {

	OnDutyRequestEntity findByApplicantIdAndFromDate(Integer applicantId, Date date);

	OnDutyRequestEntity findByApplicantIdAndFromDateAndToDate(Integer kairoUserId, Date fromDate, Date toDate);

	@Query(value = "SELECT * FROM od_request WHERE status = \"APPROVED\" AND isFullyLogged = false", nativeQuery = true)
	List<OnDutyRequestEntity> getOnDutyEntityList();
	
	List<OnDutyRequestEntity> findAllByIdIn(List<Integer> leaveRequestIdList);

}
