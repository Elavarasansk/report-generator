package org.com.tools.repository;

import org.com.tools.entity.NotificationMasterSettingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationMasterSettingRepository extends JpaRepository<NotificationMasterSettingEntity, Integer> {

	NotificationMasterSettingEntity findByModuleName(String modulename);
}
