package org.com.tools.repository;

import java.util.List;

import org.com.tools.entity.RedmineUserDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RedmineUserDetailsRepository extends JpaRepository<RedmineUserDetailsEntity, Integer> {

	List<RedmineUserDetailsEntity> findAllByIdIn(List<Integer> applicantIdList);

	List<RedmineUserDetailsEntity> findAllByKairoUserIdIn(List<Integer> applicantIdList);

	List<RedmineUserDetailsEntity> findAllByMailIdIn(List<String> mailIdList);

	List<RedmineUserDetailsEntity> findAllByRedmineUrlMasterId(Integer redmineUrlMasterId);

	List<RedmineUserDetailsEntity> findByRedmineUrlMasterIdAndKairoUserIdIn(Integer redmineUrlMasterId,
			List<Integer> kairoUserIdList);
	
	List<RedmineUserDetailsEntity> findByRedmineUrlMasterIdAndRedmineUserIdIn(Integer redmineUrlMasterId,
			List<Integer> redmineList);
	
	List<RedmineUserDetailsEntity> findByKairoUserId(Integer kairoUserId);

}
