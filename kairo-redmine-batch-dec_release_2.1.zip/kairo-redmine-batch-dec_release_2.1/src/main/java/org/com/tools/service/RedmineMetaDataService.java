package org.com.tools.service;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.entity.RedmineNotLoggedEntity;
import org.com.tools.entity.RedmineUserDetailsEntity;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.KairoRedmineManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RedmineMetaDataService {

	private String userPath = "\\Redmine_User_List\\Redmine_Users_List_" + LocalDate.now() + ".xlsx";
	private String timeEntryPath = "\\Redmine_Log_Report\\Redmine_Log_Report_" + LocalDate.now() + ".xlsx";
	private String notLogedPath = "\\Redmine_Log_Report\\Redmine_Not_Logged_Report_" + LocalDate.now() + ".xlsx";

	private XSSFWorkbook workBook = new XSSFWorkbook();
	private XSSFSheet sheet;

	@Autowired
	RedmineUserDetailsRepository redmineUserRepo;

	@Autowired
	RedmineNotLoggedRepository notLoggedRepo;

//	@Autowired
//	KairoRedmineManager redmineManager;

	@Autowired
	RedmineConsolidatedLogRepository redmineDailyBatchRepo;

	/**
	 * createRedmineMetaData method generates reports for redmine_user_details table
	 * and redmine_consolidated_logdetails table
	 * 
	 * @param path
	 * @return
	 */
	public String createRedmineMetaData(String path) {
		List<RedmineUserDetailsEntity> userEntryList = redmineUserRepo.findAll();
		if (!userEntryList.isEmpty()) {
			createUserReport(userEntryList);
			generateReport(path, "User");
		}

		// List<RedmineLogReportEntity> logEntriesList =
		// redmineDailyBatchRepo.findBySpentOn(DateUtils.convertToUtilDate(LocalDate.now()));
		List<RedmineConsolidatedLogEntity> timeEntryList = redmineDailyBatchRepo.findAll();
		if (!timeEntryList.isEmpty()) {
			createTimeEntriesReport(timeEntryList);
			generateReport(path, "Logged");
		}
		return "Report Generated";
	}

	/**
	 * createUserReport , creates a entity of userdetails and pass entity as param
	 * to createUserData method
	 * 
	 * @param entityList
	 */
	private void createUserReport(List<RedmineUserDetailsEntity> entityList) {
		sheet = workBook.createSheet("RedmineUserDetails");
		IntStream.range(1, entityList.size()).forEach(index -> {
			RedmineUserDetailsEntity entity = entityList.get(index);
			if (index == 1) {
				createUserData(entity, 0);
			}
			createUserData(entity, index);
		});
	}

	/**
	 * createUserData , creates rows of excel sheets with user data inserted in the
	 * rows
	 * 
	 * @param entity
	 * @param index
	 */
	private void createUserData(RedmineUserDetailsEntity entity, Integer index) {
		Row row = sheet.createRow(index);
		Boolean header = index > 0 ? false : true;
		for (int idx = 0; idx <= 8; idx++) {
			Cell cell = row.createCell(idx);
			switch (idx) {
			case 0:
				cell.setCellValue(header ? "id" : entity.getId().toString());
				break;
			case 1:
				cell.setCellValue(header ? "redmineUserId" : entity.getRedmineUserId().toString());
				break;
			case 2:
				cell.setCellValue(header ? "userName"
						: Objects.nonNull(entity.getUserName()) ? entity.getUserName().toString() : "");
				break;
			case 3:
				cell.setCellValue(
						header ? "mailId" : Objects.nonNull(entity.getMailId()) ? entity.getMailId().toString() : "");
				break;
			case 4:
				cell.setCellValue(header ? "userCreatedOn"
						: Objects.nonNull(entity.getUserCreatedOn()) ? entity.getUserCreatedOn().toString() : "");
				break;
			case 5:
				cell.setCellValue(header ? "active" : entity.getActive().toString());
				break;
			case 6:
				cell.setCellValue(header ? "kairo_user_id"
						: Objects.nonNull(entity.getKairoUserId()) ? entity.getKairoUserId().toString() : "");
				break;
			case 7:
				cell.setCellValue(header ? "lastLogin"
						: Objects.nonNull(entity.getLastLogin()) ? entity.getLastLogin().toString() : "");
				break;
			case 8:
				cell.setCellValue(header ? "kairo_user_project_id"
						: Objects.nonNull(entity.getKairoUserProjectId()) ? entity.getKairoUserProjectId().toString()
								: "");
				break;
			}
		}
	}

	/**
	 * createTimeEntriesReport creates workbook sheet for redmineLogEntries
	 * 
	 * @param entityList
	 */
	private void createTimeEntriesReport(List<RedmineConsolidatedLogEntity> entityList) {
		workBook = new XSSFWorkbook();
		sheet = workBook.createSheet("RedmineLogEntries");
		IntStream.range(1, entityList.size()).forEach(index -> {
			RedmineConsolidatedLogEntity entity = entityList.get(index);
			if (index == 1) {
				createTimeData(entity, 0);
			}
			createTimeData(entity, index);
		});

	}

	/**
	 * createTimeData, creates rows with log entity data inserted in the rows
	 *
	 * @param entity
	 * @param index
	 */
	private void createTimeData(RedmineConsolidatedLogEntity entity, Integer index) {
		Row row = sheet.createRow(index);
		Boolean header = index > 0 ? false : true;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(Date.valueOf(entity.getSpentOn().toString()));
		for (int idx = 0; idx <= 9; idx++) {
			Cell cell = row.createCell(idx);
			switch (idx) {
			case 0:
				cell.setCellValue(header ? "Id" : entity.getId().toString());
				break;
			case 1:
				cell.setCellValue(header ? "redmineUserId" : entity.getRedmineUserId().toString());
				break;
			case 2:
				cell.setCellValue(header ? "spentOn"
						: Objects.nonNull(entity.getSpentOn()) ? entity.getSpentOn().toString() : "");
				break;
			case 3:
				cell.setCellValue(header ? "kairo_user_id"
						: Objects.nonNull(entity.getKairoUserId()) ? entity.getKairoUserId().toString() : "");
				break;
			case 4:
				cell.setCellValue(header ? "project_allocation_id"
						: Objects.nonNull(entity.getProjectAllocId()) ? entity.getProjectAllocId().toString() : "");
				break;
			case 5:
				cell.setCellValue(
						header ? "month" : Objects.nonNull(entity.getMonth()) ? entity.getMonth().toString() : "");
				break;
			case 6:
				cell.setCellValue(header ? "dayName"
						: Objects.nonNull(entity.getDayName()) ? entity.getDayName().toString() : "");
				break;
			case 7:
				cell.setCellValue(header ? "loggedHours"
						: Objects.nonNull(entity.getLoggedHours()) ? entity.getLoggedHours().toString() : "");
				break;
			case 8:
				cell.setCellValue(header ? "redmine_log_report_ids"
						: Objects.nonNull(entity.getRedmineLogReportIds()) ? entity.getRedmineLogReportIds().toString()
								: "");
				break;
			case 9:
				cell.setCellValue(header ? "kairo_user_project_id"
						: Objects.nonNull(entity.getProjectId()) ? entity.getProjectId().toString() : "");
				break;
			}
		}
	}

	/**
	 * generateReport creates report for log details and user details and output
	 * workbook written in a API directory
	 * 
	 * @param dirPath
	 * @param report
	 */
	private void generateReport(String dirPath, String report) {
		String append = "";
		if (report.equals("User")) {
			append = userPath;
		} else if (report.equals("Logged")) {
			append = timeEntryPath;
		} else {
			append = notLogedPath;
		}
		try {
			File dir = new File(dirPath + append);
			if (!dir.getParentFile().exists()) {
				dir.getParentFile().mkdirs();
			}
			FileOutputStream outputStream = new FileOutputStream(new File(dir.getAbsolutePath()));
			workBook.write(outputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * generateNotLoggedReport , make a notlogged entity , pass as argument to
	 * createNotLoggedReport method
	 * 
	 * @param path
	 * @return
	 */
	public String generateNotLoggedReport(String path) {

		List<RedmineNotLoggedEntity> notLoggedUserList = notLoggedRepo.findAll();
		if (Objects.nonNull(notLoggedUserList)) {
			createNotLoggedReport(notLoggedUserList);
			generateReport(path, "NotLogged");
		}
		return "Report Generated";
	}

	/**
	 * 
	 * @param notLoggedUserList
	 */
	private void createNotLoggedReport(List<RedmineNotLoggedEntity> notLoggedUserList) {
		workBook = new XSSFWorkbook();
		sheet = workBook.createSheet("RedmineNotLoggedUsers");
		IntStream.range(1, notLoggedUserList.size()).forEach(index -> {
			RedmineNotLoggedEntity entity = notLoggedUserList.get(index);
			if (index == 1) {
				createNotLoggedUserData(entity, 0);
			}
			createNotLoggedUserData(entity, index);
		});
	}

	private void createNotLoggedUserData(RedmineNotLoggedEntity entity, int index) {
		Row row = sheet.createRow(index);
		Boolean header = index > 0 ? false : true;
		for (int idx = 0; idx <= 13; idx++) {
			Cell cell = row.createCell(idx);
			switch (idx) {
			case 0:
				cell.setCellValue(header ? "id" : entity.getId().toString());
				break;
			case 1:
				cell.setCellValue(header ? "redmineUserId" : entity.getRedmineUserId().toString());
				break;
			case 2:
				cell.setCellValue(header ? "flawDate"
						: Objects.nonNull(entity.getFlawDate()) ? entity.getFlawDate().toString() : "");
				break;
			case 3:
				cell.setCellValue(header ? "insufficientHours"
						: Objects.nonNull(entity.getInsufficientHours()) ? entity.getInsufficientHours().toString()
								: "");
				break;
			case 4:
				cell.setCellValue(header ? "estimatedHours"
						: Objects.nonNull(entity.getEstimatedHours()) ? entity.getEstimatedHours().toString() : "");
				break;
			case 5:
				cell.setCellValue(header ? "isFullDay"
						: Objects.nonNull(entity.getIsFullDay()) ? entity.getIsFullDay().toString().toUpperCase() : "");
				break;
			case 6:
				cell.setCellValue(header ? "isHalfDay"
						: Objects.nonNull(entity.getIsHalfDay()) ? entity.getIsHalfDay().toString().toUpperCase() : "");
				break;
			case 7:
				cell.setCellValue(header ? "warningDays"
						: Objects.nonNull(entity.getWarningDays()) ? entity.getWarningDays().toString() : "");
				break;
			case 8:
				cell.setCellValue(header ? "kairo_user_id"
						: Objects.nonNull(entity.getKairoUserId()) ? entity.getKairoUserId().toString() : "");
				break;
			case 9:
				cell.setCellValue(header ? "kairo_user_project_id"
						: Objects.nonNull(entity.getProjectId()) ? entity.getProjectId().toString() : "");
				break;
			case 10:
				cell.setCellValue(header ? "project_allocation_id"
						: Objects.nonNull(entity.getProjectAllocId()) ? entity.getProjectAllocId().toString() : "");
				break;
			case 11:
				cell.setCellValue(header ? "shift_id"
						: Objects.nonNull(entity.getShiftId()) ? entity.getShiftId().toString() : "");
				break;
			case 12:
				cell.setCellValue(header ? "dayName"
						: Objects.nonNull(entity.getFlawDate())
								? entity.getFlawDate().getDayOfWeek().toString().toUpperCase()
								: "");
				break;
			case 13:
				cell.setCellValue(header ? "month"
						: Objects.nonNull(entity.getFlawDate())
								? entity.getFlawDate().getMonth().toString().toUpperCase()
								: "");
				break;
			}
		}
	}

}
