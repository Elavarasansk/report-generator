package org.com.tools.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "scheduler_history")
public class SchedulerHistoryEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private String schedulerName;

	private String schedulerType;

	private Boolean isExecuting;

	private String status;

	private LocalDate actualScheduledDate;
	
	private LocalDateTime startDateTime;

	private LocalDateTime endDateTime;

	private Integer durationMinutes;
	
	private String triggeredBy;
	
	@Column(name = "scheduler_configuration_id")
	private Integer schedulerConfigurationId;
	
	private LocalDateTime createdOn;
	
	private LocalDateTime modifiedOn;
	
}
