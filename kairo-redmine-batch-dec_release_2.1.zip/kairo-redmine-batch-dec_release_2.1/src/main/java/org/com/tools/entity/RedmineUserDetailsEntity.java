package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "redmine_user_details")
public class RedmineUserDetailsEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private Integer redmineUserId;
	
	@Column(name = "redmine_url_master_id")
	private Integer redmineUrlMasterId;
	
	private String userName;
	
	private String mailId;
	
	@Temporal(TemporalType.DATE)
	private Date userCreatedOn;
	
	@Temporal(TemporalType.DATE)
	private Date lastLogin;
	
	private Boolean active;
	
	@Column(name = "kairo_user_id")
	private Integer kairoUserId;
	
	@Column(name = "kairo_user_project_id")
	private Integer kairoUserProjectId;

}
