package org.com.tools.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.dto.DailyActiveUsersDto;
import org.com.tools.entity.HolidaysEntity;
import org.com.tools.enums.NoonType;
import org.com.tools.repository.HolidaysRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * HolidaysManager filters Daily active users of organisation based on shift and holidays.
 *
 */
@Component
public class HolidaysManager {
	
	@Autowired
	private HolidaysRepository holidayRepo;
	
	
	/**
	 * getTodayActiveUsers fetched all users in organisation and filters based on holidays
	 * @return List of active users
	 */
	public List<DailyActiveUsersDto> getTodayActiveUsers(LocalDate executionDate) {
		HolidaysEntity entity = holidayRepo.findByActiveAndOccasionDate(true, executionDate);
		
		List<Map<String, Object>> activeUserRecords = holidayRepo.getAllActiveUser();
		List<DailyActiveUsersDto> activeUserList = parseActiveUsers(activeUserRecords);
		
		if(Objects.nonNull(entity)) {
			if(entity.getNoonType().equalsIgnoreCase(NoonType.FULLDAY.toString())) {
				if(!entity.getIsInternational()) {
					filterActiveUsers(entity, activeUserList, true);
				} else {
					activeUserList = new ArrayList<>();
				}
			} else {
				if(!entity.getIsInternational()) {
					filterActiveUsers(entity, activeUserList, false);
				} else {
					activeUserList.stream().forEach(usr -> usr.setHolidayNoonType(entity.getNoonType()));
				}
			}
		}
		return activeUserList;
	}
	
	private List<DailyActiveUsersDto> filterActiveUsers(HolidaysEntity entity, 
			List<DailyActiveUsersDto> activeUserList, boolean isFullDay){
		if(entity.getIsCountrySpecific()) {
			if(isFullDay) {
				activeUserList = activeUserList.stream()
						.filter(user -> !parseDataSource(entity.getCountryIds()).contains(user.getCountryId()))
						.collect(Collectors.toList());
			} else {
				activeUserList.stream()
				.filter(user -> parseDataSource(entity.getCountryIds()).contains(user.getCountryId()))
				.forEach(user -> user.setHolidayNoonType(entity.getNoonType()));
			}
		}
		if(entity.getIsStateSpecific()) {
			if(isFullDay) {
				activeUserList = activeUserList.stream()
						.filter(user -> !parseDataSource(entity.getStateIds()).contains(user.getStateId()))
						.collect(Collectors.toList());
			} else {
				activeUserList.stream()
				.filter(user -> parseDataSource(entity.getStateIds()).contains(user.getStateId()))
				.forEach(user -> user.setHolidayNoonType(entity.getNoonType()));
			}
		}
		if(entity.getIsCitySpecific()) {
			if(isFullDay) {
			activeUserList = activeUserList.stream()
					.filter(user -> !parseDataSource(entity.getCityIds()).contains(user.getLocationId()))
					.collect(Collectors.toList());
			} else {
				activeUserList.stream()
				.filter(user -> parseDataSource(entity.getCityIds()).contains(user.getLocationId()))
				.forEach(user -> user.setHolidayNoonType(entity.getNoonType()));
			}
		}
		if(entity.getIsOrgSpecific()) {
			if(isFullDay) {
				activeUserList = activeUserList.stream()
						.filter(user -> !parseDataSource(entity.getOrganisationIds()).contains(user.getOrganisationId()))
						.collect(Collectors.toList());
			} else {
				activeUserList.stream()
				.filter(user -> parseDataSource(entity.getOrganisationIds()).contains(user.getOrganisationId()))
				.forEach(user -> user.setHolidayNoonType(entity.getNoonType()));
			}
		}
		if(entity.getIsShiftSpecific()) {
			if(isFullDay) {
				activeUserList = activeUserList.stream()
						.filter(user -> !parseDataSource(entity.getShiftIds()).contains(user.getShiftId()))
						.collect(Collectors.toList());
			} else {
				activeUserList.stream()
				.filter(user -> parseDataSource(entity.getShiftIds()).contains(user.getShiftId()))
				.forEach(user -> user.setHolidayNoonType(entity.getNoonType()));
			}
		}
		return activeUserList;
	}
	
	/**
	 * parseDataSource parse the text data type to integer
	 * @param ids
	 * @return Lsit of Ids
	 */
	private List<Integer> parseDataSource(String ids){
		return Arrays.asList(ids.replace("[", "").replace("]", "").split(",")).stream()
				.map(id -> Integer.parseInt(id.trim())).collect(Collectors.toList());
	}
	
	private List<DailyActiveUsersDto> parseActiveUsers(List<Map<String, Object>> activeUserData){
		List<DailyActiveUsersDto> activeUsersList = new ArrayList<>();
		activeUserData.stream().forEach(user -> {
			DailyActiveUsersDto activeUsersDto = DailyActiveUsersDto.builder()
					.kairoUserId(Integer.valueOf(user.get("kairoUserId").toString()))
					.shiftId(Integer.valueOf(user.get("shiftId").toString()))
					.hoursPerDay(Float.valueOf(user.get("hoursPerDay").toString()))
					.locationId(Integer.valueOf(user.get("locationId").toString()))
					.stateId(Integer.valueOf(user.get("stateId").toString()))
					.countryId(Integer.valueOf(user.get("countryId").toString()))
					.projectAllocId(Integer.valueOf(user.get("projectAllocId").toString()))
					.projectId(Integer.valueOf(user.get("projectId").toString()))
					.organisationId(Integer.valueOf(user.get("organisationId").toString()))
					.build();
			activeUsersList.add(activeUsersDto);
		});
		return activeUsersList;
	}
	
}
