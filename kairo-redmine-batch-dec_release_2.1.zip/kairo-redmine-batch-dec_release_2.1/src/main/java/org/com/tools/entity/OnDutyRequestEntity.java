package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "od_request")
public class OnDutyRequestEntity {

	@Id
	@Column(name = "id")
	private Integer id;
	
	@Temporal(TemporalType.DATE)
	private Date fromDate;
	
	@Temporal(TemporalType.DATE)
	private Date toDate;
	
	private String startNoon;
	
	private String endNoon;
	
	@Temporal(TemporalType.DATE)
	private Date actionDueDate;
	
	private String status;
	
	@Column(name = "applicant_id")
	private Integer applicantId;
	
	@Column(name = "project_id")
	private Integer projectId;
	
	@Column(name = "project_allocation_id")
	private Integer projectAllocationId;
	
	private Boolean isFullyLogged;
	
	private Float noOfDays;
	
}
