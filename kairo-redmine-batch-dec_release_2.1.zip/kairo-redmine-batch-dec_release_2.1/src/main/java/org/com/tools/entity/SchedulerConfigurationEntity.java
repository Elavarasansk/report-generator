package org.com.tools.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "scheduler_configuration")
public class SchedulerConfigurationEntity {
	
	@Id
	private Integer id;
	
	private String schedulerName;
	
	private String schedulerType;
	
	private Integer order;
	
	private String cronDescription;
	
	private String cron;
	
	private String apiPath;
	
	private Boolean isServerCronJobScheduled;
	
	private Boolean hasScreenTrigger;

}
