package org.com.tools.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "od_request_fragments")
public class OnDutyRequestFragmentsEntity {

	@Id
	@Column(name = "id")
	private Integer id;

	@Temporal(TemporalType.DATE)
	private Date fragmentDate;

	private String noonType;

	private Boolean isFullDay;

	private Float noOfDays;

	private Boolean isLogTimeCreated;

	private Float logTimeAdded;

	@Column(name = "leave_request_id")
	private Integer leaveRequestId;
	
}
