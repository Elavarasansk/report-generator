package org.com.tools.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Table(name = "leave_logtime_conflict_approval")
public class LeaveLogtimeConflictApprovalEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	private Boolean isHr;

	private String actionStatus;

	private String comments;

	private String negativeActionReason;

	private Integer levelFlow;

	private Boolean isFinal;

	@Column(name = "applicant_id")
	private Integer applicantId;

	@Column(name = "current_approver_id")
	private Integer currentApproverId;

	@Column(name = "previous_approver_id")
	private Integer previousApproverId;

	@Column(name = "next_approver_id")
	private Integer nextApproverId;

	@Column(name = "leave_logtime_conflict_id")
	private Integer leaveLogtimeConflictId;

}
