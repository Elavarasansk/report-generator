package org.com.tools.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RedmineTimeEntriesDto {

	private Integer id;
	private Integer activityId;
	private Integer issueId;
	private Integer userId;
	private Integer kairoUserId;
	private Integer projectId;
	private Integer organisationId;
	
	private Float hours;
	
	private String userName;
	private String projectName;
	private String activityName;
	private String comment;
	
	private String createdOn;
	private String spentOn;
	private String updatedOn;
	
}
