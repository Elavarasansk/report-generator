package org.com.tools.repository;

import java.util.Date;
import java.util.List;

import org.com.tools.entity.LeaveLogtimeConflictEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface LeaveLogTimeConflictRepository extends JpaRepository<LeaveLogtimeConflictEntity, Integer> {

	List<LeaveLogtimeConflictEntity> findByStatusAndIsWithdrawApproved(String status, Boolean iswithdrawn);

	List<LeaveLogtimeConflictEntity> findByStatusAndIsWithdrawApprovedAndConflictDateAndApplicantIdIn(String string,
			boolean b, Date date, List<Integer> userIdList);

	List<LeaveLogtimeConflictEntity> findByStatusAndIsWithdrawApprovedAndConflictDateAndApplicantId(String string,
			boolean b, Date date, Integer userId);

	List<LeaveLogtimeConflictEntity> findByStatusAndIsWithdrawApprovedAndApplicantIdIn(String string, boolean b,
			List<Integer> userId);
	
	
	@Query(value = " SELECT llc.* " + 
			" FROM leave_logtime_conflict as llc " + 
			" Inner join redmine_consolidated_logdetails as rcl on rcl.id = llc.redmine_consolidated_logdetails_id " + 
			" where llc.isWithdrawApproved=false and llc.status=\"WITHDRAWN\" and rcl.redmine_url_master_id = ?1  and llc.id in (?2)", nativeQuery = true)
	List<LeaveLogtimeConflictEntity> fetchMyRedmineSpecificLogEntries(int redmineUrlId, List<Integer> conflictIds);
	
	List<LeaveLogtimeConflictEntity> findByConflictDate(Date conflictDate);
}
