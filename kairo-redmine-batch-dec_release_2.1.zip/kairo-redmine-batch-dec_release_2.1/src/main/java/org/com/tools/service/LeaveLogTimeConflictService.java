package org.com.tools.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.com.tools.dto.KairoDailyBatchUsersListDto;
import org.com.tools.dto.LeaveLogTimeConflictUserDto;
import org.com.tools.dto.LeaveLogTimeConflictUserListDto;
import org.com.tools.entity.KairoUserEntity;
import org.com.tools.entity.LeaveLogtimeConflictApprovalEntity;
import org.com.tools.entity.LeaveLogtimeConflictEntity;
import org.com.tools.entity.LeaveRequestFragmentsEntity;
import org.com.tools.entity.RedmineConsolidatedLogEntity;
import org.com.tools.entity.RedmineMasterSettings;
import org.com.tools.entity.RedmineUserDetailsEntity;
import org.com.tools.enums.NoonType;
import org.com.tools.repository.KairoUserRepository;
import org.com.tools.repository.LeaveLogTimeConflictRepository;
import org.com.tools.repository.LeaveLogtimeConflictApprovalRepository;
import org.com.tools.repository.LeaveRequestFragmentsRepository;
import org.com.tools.repository.LeaveRequestRepository;
import org.com.tools.repository.RedmineConsolidatedLogRepository;
import org.com.tools.repository.RedmineLogReportRepositiory;
import org.com.tools.repository.RedmineMasterSettingsRepository;
import org.com.tools.repository.RedmineNotLoggedRepository;
import org.com.tools.repository.RedmineUserDetailsRepository;
import org.com.tools.utility.DateUtils;
import org.com.tools.utility.KairoRedmineManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.taskadapter.redmineapi.bean.TimeEntry;

@Service
public class LeaveLogTimeConflictService {

	@Autowired
	LeaveLogTimeConflictRepository leaveConflictRepo;

	@Autowired
	KairoRedmineManager redmineManager;

	@Autowired
	RedmineConsolidatedLogRepository consolidatedLogRepo;

	@Autowired
	RedmineLogReportRepositiory logReportRepo;

	@Autowired
	RedmineNotLoggedRepository notLoggedRepo;

	@Autowired
	RedmineUserDetailsRepository userDetailsRepo;

	@Autowired
	LeaveRequestRepository leaveRequestRepo;

	@Autowired
	LeaveRequestFragmentsRepository leaveReqFragmentsRepo;

	@Autowired
	LeaveLogtimeConflictApprovalRepository leaveConflictApprovalRepo;

	@Autowired
	RedmineMasterSettingsRepository redmineMasterSettingsRepo;
	
	@Autowired
	WithdrawNotificationService withdrawNotificationService;

	@Autowired
	RedmineLogReportService logReportService;
	
	@Autowired
	KairoDailyBatchService dailyService;
	
	@Autowired
	KairoUserRepository kairoUserRepo;
	
	private static final String WITHDRAWN = "WITHDRAWN";

	private static final String AUTO_APPLIED = "AUTO_APPLIED";

	private static final String AWAITING_MY_APPROVAL = "AWAITING_MY_APPROVAL";

	private static final String WAITING_FOR_PREVIOUS_APPROVERS = "WAITING_FOR_PREVIOUS_APPROVERS";

	/**
	 * executes batch for all data in leave_logtime_conflict table data and removes
	 * consecutives data from remine_log_report, redmine_consolidated_logdetails and
	 * updates data in leave_logtime_conflict and leave_request_fragments table
	 * 
	 */
	public void triggerLeaveLogTimeConflictBatch() {
		List<LeaveLogtimeConflictEntity> logTimeConflictEntityList = leaveConflictRepo
				.findByStatusAndIsWithdrawApproved(WITHDRAWN, false);

		if (!logTimeConflictEntityList.isEmpty()) {
			getRedmineLogEntires(logTimeConflictEntityList);
		}
	}

	/**
	 * executes batch for selected userList data in leave_logtime_conflict table
	 * data and removes consecutives data from remine_log_report,
	 * redmine_consolidated_logdetails and updates data in leave_logtime_conflict
	 * and leave_request_fragments table
	 * 
	 * @param userListDto
	 */
	public void triggerLeaveLogTimeConflictBatch(LeaveLogTimeConflictUserListDto userListDto) {

		List<LeaveLogtimeConflictEntity> logTimeConflictEntityList = leaveConflictRepo
				.findByStatusAndIsWithdrawApprovedAndConflictDateAndApplicantIdIn(WITHDRAWN, false,
						userListDto.getDate(), userListDto.getApplicantIdList());

		if (!logTimeConflictEntityList.isEmpty()) {
			getRedmineLogEntires(logTimeConflictEntityList);
		}
	}

	/**
	 * executes batch for selected user, data in leave_logtime_conflict table data
	 * and removes consecutives data from remine_log_report,
	 * redmine_consolidated_logdetails and updates data in leave_logtime_conflict
	 * and leave_request_fragments table
	 * 
	 * @param userDto
	 */
	public void triggerLeaveLogTimeConflictBatch(LeaveLogTimeConflictUserDto userDto) {
		List<LeaveLogtimeConflictEntity> logTimeConflictEntityList = leaveConflictRepo
				.findByStatusAndIsWithdrawApprovedAndConflictDateAndApplicantId(WITHDRAWN, false, userDto.getDate(),
						userDto.getApplicantId());

		if (!logTimeConflictEntityList.isEmpty()) {
			getRedmineLogEntires(logTimeConflictEntityList);
		}
	}

	/**
	 * executes batch for list of selected user data in leave_logtime_conflict table
	 * data and removes consecutives data from remine_log_report,
	 * redmine_consolidated_logdetails and updates data in leave_logtime_conflict
	 * and leave_request_fragments table
	 * 
	 * @param userDateDtoList
	 */
	public void triggerLeaveLogTimeConflictBatch(List<LeaveLogTimeConflictUserDto> userDateDtoList) {
		List<LeaveLogtimeConflictEntity> logTimeConflictEntityList = new ArrayList<>();
		// native query or findAll needs to be used
		userDateDtoList.stream().forEach(rec -> {
			logTimeConflictEntityList
					.addAll(leaveConflictRepo.findByStatusAndIsWithdrawApprovedAndConflictDateAndApplicantId(WITHDRAWN,
							false, rec.getDate(), rec.getApplicantId()));
		});
		if (!logTimeConflictEntityList.isEmpty()) {
			getRedmineLogEntires(logTimeConflictEntityList);
		}
	}

	/**
	 * get Redmine log entries for data in leave conflict table
	 * 
	 * @param logTimeConflictEntityList
	 */
//	private void getRedmineLogEntires(List<LeaveLogtimeConflictEntity> logTimeConflictEntityList) {
//
//		List<Integer> applicantIdList = logTimeConflictEntityList.stream().map(LeaveLogtimeConflictEntity::getApplicantId).distinct().collect(Collectors.toList());
////		Map<Integer, Integer> kairoRedmineUserIdMap = userDetailsRepo.findAllByKairoUserIdIn(applicantIdList).stream()
////				.collect(Collectors.toMap(RedmineUserDetailsEntity::getKairoUserId,
////						RedmineUserDetailsEntity::getRedmineUserId));
////
////		if (!kairoRedmineUserIdMap.isEmpty()) {
////			getNotLoggedMap(logTimeConflictEntityList, kairoRedmineUserIdMap);
////		}
//		
//		List<RedmineUserDetailsEntity> redmineUserList = userDetailsRepo.findAllByKairoUserIdIn(applicantIdList);
//		Map<Integer, List<RedmineUserDetailsEntity>> groupByRedmineUrlId = redmineUserList.stream()
//				.collect(Collectors.groupingBy(RedmineUserDetailsEntity::getRedmineUrlMasterId));
//		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = getRedmineUrlDetails();
//		
//		groupByRedmineUrlId.entrySet().forEach(e -> {
//			int redmineUrlId = e.getKey();
//			RedmineMasterSettings masterData = redmineUrlDetailsMap.get(redmineUrlId).get(0);
//			this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
//			
//			List<Integer> urlMappedUserList = e.getValue().stream().map(redmineUser -> redmineUser.getKairoUserId()).collect(Collectors.toList());
//			List<LeaveLogtimeConflictEntity> logConflictList = logTimeConflictEntityList.stream()
//					.filter(logConflict -> urlMappedUserList.contains(logConflict.getApplicantId())).collect(Collectors.toList());;
//					
//		    Map<Integer, Integer> kairoRedmineUserIdMap = e.getValue().stream().collect(Collectors.toMap(RedmineUserDetailsEntity::getKairoUserId, RedmineUserDetailsEntity::getRedmineUserId));
//			getNotLoggedMap(logConflictList, kairoRedmineUserIdMap);
//		});
//	}
	
	private void getRedmineLogEntires(List<LeaveLogtimeConflictEntity> logTimeConflictEntityList) {
		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = getRedmineUrlDetails();
		redmineUrlDetailsMap.entrySet().forEach(e -> {
			int redmineUrlId = e.getKey();
			RedmineMasterSettings masterData = e.getValue().get(0);
			this.redmineManager = new KairoRedmineManager(masterData.getRedmineUrl(), masterData.getApiKey());
						
			List<Integer> conflictIds = logTimeConflictEntityList.stream().map(LeaveLogtimeConflictEntity::getId).collect(Collectors.toList());			
			List<LeaveLogtimeConflictEntity> updatedConflictList = leaveConflictRepo.fetchMyRedmineSpecificLogEntries(redmineUrlId, conflictIds);			

			List<Integer> urlMappedUserList = updatedConflictList.stream().map(LeaveLogtimeConflictEntity::getApplicantId).distinct().collect(Collectors.toList());
		    Map<Integer, Integer> kairoRedmineUserIdMap = userDetailsRepo.findByRedmineUrlMasterIdAndKairoUserIdIn(redmineUrlId, urlMappedUserList).stream()
		    		.collect(Collectors.toMap(RedmineUserDetailsEntity::getKairoUserId, RedmineUserDetailsEntity::getRedmineUserId));

		    getNotLoggedMap(updatedConflictList, kairoRedmineUserIdMap);
		});
		
		checkConsolidatedEntryExists(logTimeConflictEntityList);
		
	}
	
	private void checkConsolidatedEntryExists(List<LeaveLogtimeConflictEntity> logTimeConflictEntityList) {
		
		List<Integer> ConsolidateLogEntryIds = logTimeConflictEntityList.stream()
				.map(LeaveLogtimeConflictEntity::getRedmineConsolidatedLogdetailsId)
				.collect(Collectors.toList());
		
		List<RedmineConsolidatedLogEntity> LogEntryList = consolidatedLogRepo.findByIdIn(ConsolidateLogEntryIds);
		
		if(LogEntryList.isEmpty()) {
			logTimeConflictEntityList.stream().forEach(e -> e.setIsWithdrawApproved(true));
			leaveConflictRepo.saveAll(logTimeConflictEntityList);
		} else {
			List<Integer> existingEntryIds = LogEntryList.stream().map(RedmineConsolidatedLogEntity::getId)
					.collect(Collectors.toList());
			logTimeConflictEntityList.stream()
			.filter(e -> !existingEntryIds.contains(e.getRedmineConsolidatedLogdetailsId()))
			.forEach(e -> e.setIsWithdrawApproved(true));
			leaveConflictRepo.saveAll(logTimeConflictEntityList);
		}
	}

	private Map<Integer, List<RedmineMasterSettings>> getRedmineUrlDetails() {
		List<RedmineMasterSettings> redmineMasterSettingsList = redmineMasterSettingsRepo.findByActive(true);
		Map<Integer, List<RedmineMasterSettings>> redmineUrlDetailsMap = redmineMasterSettingsList.stream()
				.collect(Collectors.groupingBy(RedmineMasterSettings::getId));
		return redmineUrlDetailsMap;
	}

	/**
	 * get Redmine log entries for data in leave conflict table and prepares a
	 * deleteList
	 * 
	 * @param logTimeConflictEntityList
	 * @param kairoRedmineUserIdMap
	 * @return List<LeaveLogtimeConflictEntity>
	 */
	private void getNotLoggedMap(List<LeaveLogtimeConflictEntity> logTimeConflictEntityList,
			Map<Integer, Integer> kairoRedmineUserIdMap) {

		List<LeaveLogtimeConflictEntity> deleteLogEntryList = new ArrayList<>();
		List<LeaveLogtimeConflictEntity> partialChangedEntryList = new ArrayList<>();
		List<LeaveLogtimeConflictEntity> halfDayConflictFixedList = new ArrayList<>();

		List<Integer> conflictLeaveRequestFragmentIds = logTimeConflictEntityList.stream()
				.map(LeaveLogtimeConflictEntity::getLeaveRequestFragmentId).collect(Collectors.toList());

		Map<Integer, Boolean> leaveReqFullDayMap = leaveReqFragmentsRepo
				.findAllByIdIn(conflictLeaveRequestFragmentIds).stream().collect(Collectors
						.toMap(LeaveRequestFragmentsEntity::getId, LeaveRequestFragmentsEntity::getIsFullday));

		logTimeConflictEntityList.stream().forEach(rec -> {

			Integer redmineUserId = kairoRedmineUserIdMap.get(rec.getApplicantId());

			//kairo_user_id - 6, not present in redmine_user_details table
			//Since mailId in kairo_user table is different form the redmine mailId
			//Need to check and confirm with live data.
			if(Objects.nonNull(redmineUserId)) {

				LocalDate localDate =  DateUtils.convertToLocalDate(rec.getConflictDate());

				List<TimeEntry> redmineLogEntryList = redmineManager.getTimeEntriesRangeWithUserOnSameDate(localDate,
						redmineUserId);

				if (redmineLogEntryList.isEmpty()) {
					deleteLogEntryList.add(rec);
				} else {
					Boolean isFullDay = leaveReqFullDayMap.get(rec.getLeaveRequestFragmentId());
					Float loggedHours = redmineLogEntryList.stream().map(TimeEntry::getHours).reduce(Float::sum).get();
					Boolean isHalfDay = loggedHours >= 4 && loggedHours < 8;

					if(!(isHalfDay && !isFullDay)) {
						String noonType = isHalfDay ? NoonType.HALFDAY.toString() : NoonType.FULLDAY.toString();
						rec.setNoonType(noonType);
						partialChangedEntryList.add(rec);
					} else {
						//Implemented - Not Tested
						//Update isWithdrawApproved(conflict) and isConflict(fragment).
						//Update Log Report and Consolidated Log Details
						rec.setIsWithdrawApproved(true);
						halfDayConflictFixedList.add(rec);
					}
				}
			}
		});

		if (!deleteLogEntryList.isEmpty()) {
			updateTableEntries(deleteLogEntryList);
		}

		if (!partialChangedEntryList.isEmpty()) {
			updateLeavePartChangeEntries(partialChangedEntryList);
			updateLogEntriesForPartialChanged(partialChangedEntryList);
		}
		
		if (!halfDayConflictFixedList.isEmpty()) {
			updateLogEntriesForPartialChanged(halfDayConflictFixedList);
			updateFixedUsersFragments(halfDayConflictFixedList);
			leaveConflictRepo.saveAll(halfDayConflictFixedList);
		}
	}

	private void updateLogEntriesForPartialChanged(List<LeaveLogtimeConflictEntity> partialChangedEntryList) {
		
		List<Integer> applicantList = partialChangedEntryList.stream()
				.map(LeaveLogtimeConflictEntity::getApplicantId)
				.collect(Collectors.toList());
		 Map<Integer, String> UserMailMap = kairoUserRepo.findAllByIdIn(applicantList)
				 .stream().collect(Collectors.toMap(KairoUserEntity::getId, 
						 KairoUserEntity::getEmail));
		 
		 Map<LocalDate, List<String>> specificUserMap = new HashMap<>();
		 partialChangedEntryList.stream().forEach(data -> {
			 
			 LocalDate date =  DateUtils.convertToLocalDate(data.getConflictDate());
			 List<String> existsList = specificUserMap.get(date);
			 
			 if(Objects.nonNull(existsList)) {
				 existsList.add(UserMailMap.get(data.getApplicantId()));
			 } else {
				 List<String> mailList = new ArrayList<>(); 
				 mailList.add(UserMailMap.get(data.getApplicantId()));
				 specificUserMap.put(date, mailList);
			 }
		 });
		 
		 specificUserMap.entrySet().stream().forEach(data -> {
			 KairoDailyBatchUsersListDto userSpecificData = KairoDailyBatchUsersListDto.builder()
					 .date(data.getKey().toString()).mailId(data.getValue()).build();
			 
			 logReportService.getRedmineLogReportForSpecifiedUsers(userSpecificData);
			 dailyService.preCheckCumulativeBatch(data.getKey(), userSpecificData, true);
		 });
	}

	/**
	 * updates data in leave_logtime_conflict and leave_request_fragments table
	 * deletes data in remine_log_report, redmine_consolidated_logdetails table
	 * 
	 * @param deleteLogEntryList
	 */
	private void updateTableEntries(List<LeaveLogtimeConflictEntity> deleteLogEntryList) {

		List<Date> conflictDateList = deleteLogEntryList.stream().distinct()
				.map(LeaveLogtimeConflictEntity::getConflictDate).collect(Collectors.toList());

		conflictDateList.stream().forEach(rec -> {
			List<Integer> userIdList = deleteLogEntryList.stream().filter(entry -> entry.getConflictDate().equals(rec))
					.map(LeaveLogtimeConflictEntity::getApplicantId).collect(Collectors.toList());

			// delete entries from consolidated log details table
			List<Integer> logReportIdsList = new ArrayList<>();
			List<String> logReportIdsStringList = consolidatedLogRepo.deleteBySpentOnAndKairoUserIdIn(rec, userIdList)
					.stream().map(RedmineConsolidatedLogEntity::getRedmineLogReportIds).collect(Collectors.toList());

			logReportIdsStringList.stream().forEach(entry -> logReportIdsList.addAll(parseDataSource(entry)));

			// delete entries from redmine log report table
			if (!logReportIdsList.isEmpty()) {
				logReportRepo.deleteBySpentOnAndIdIn(rec, logReportIdsList);
			}
		});

		// update leave logtime conflict table
		deleteLogEntryList.stream().forEach(rec -> rec.setIsWithdrawApproved(true));
		leaveConflictRepo.saveAll(deleteLogEntryList);

		List<Integer> leaveRequestIdList = deleteLogEntryList.stream()
				.map(LeaveLogtimeConflictEntity::getLeaveRequestId).collect(Collectors.toList());

		// update conflict fragments table
		List<LeaveRequestFragmentsEntity> leaveReqFragmentsList = leaveReqFragmentsRepo
				.findAllByLeaveRequestIdIn(leaveRequestIdList);
		leaveReqFragmentsList.stream().forEach(rec -> rec.setIsConflict(false));
		leaveReqFragmentsRepo.saveAll(leaveReqFragmentsList);

	}

	/**
	 * 
	 * @param partialChangedEntryList
	 */
	private void updateLeavePartChangeEntries(List<LeaveLogtimeConflictEntity> partialChangedEntryList) {

		// update leave logtime conflict table
		partialChangedEntryList.stream().forEach(rec -> {
			rec.setIsWithdrawApproved(false);
			rec.setStatus(AUTO_APPLIED);
		});

		// update leave logtime conflict approval table
		List<Integer> leaveConflictApplicantIdMap = partialChangedEntryList.stream()
				.map(LeaveLogtimeConflictEntity::getId).collect(Collectors.toList());

		List<Integer> applicantIdList = partialChangedEntryList.stream()
				.map(LeaveLogtimeConflictEntity::getApplicantId)
				.distinct().collect(Collectors.toList());

		List<LeaveLogtimeConflictApprovalEntity> leaveConflictApprovalEntityList = leaveConflictApprovalRepo
				.findAllByApplicantIdIn(applicantIdList);

		List<LeaveLogtimeConflictApprovalEntity> leaveConflictFilterList = leaveConflictApprovalEntityList.stream()
				.filter(entry -> leaveConflictApplicantIdMap.contains(entry.getLeaveLogtimeConflictId()))
				.collect(Collectors.toList());

		if (!leaveConflictFilterList.isEmpty()) {
			leaveConflictFilterList.stream().forEach(rec -> {
				if (rec.getLevelFlow() == 1) {
					rec.setActionStatus(AWAITING_MY_APPROVAL);
				} else {
					rec.setActionStatus(WAITING_FOR_PREVIOUS_APPROVERS);
				}
			});

			leaveConflictRepo.saveAll(partialChangedEntryList);
			leaveConflictApprovalRepo.saveAll(leaveConflictFilterList);
		}
		
		//send withdraw notification
		withdrawNotificationService.triggerWithdrawNotification(partialChangedEntryList);
	}
	
	private void updateFixedUsersFragments(List<LeaveLogtimeConflictEntity> halfDayConflictFixedList) {

		List<Integer> fragmentIdList = halfDayConflictFixedList.stream()
				.map(LeaveLogtimeConflictEntity::getLeaveRequestFragmentId)
				.collect(Collectors.toList());
		
		List<LeaveRequestFragmentsEntity> fragmentsList = leaveReqFragmentsRepo.findAllByIdIn(fragmentIdList);
		
		fragmentsList.forEach(fragment -> fragment.setIsConflict(false));
		leaveReqFragmentsRepo.saveAll(fragmentsList);
	}

	/**
	 * parseDataSource parse the text data type to integer
	 * 
	 * @param ids
	 * @return Lsit of Ids
	 */
	private List<Integer> parseDataSource(String ids) {
		return Arrays.asList(ids.replace("[", "").replace("]", "").split(",")).stream()
				.map(id -> Integer.parseInt(id.trim())).collect(Collectors.toList());
	}

}
