package org.com.tools.controller;

import org.com.tools.service.NotLoggedNotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class NotLoggedNotificationController {

	@Autowired
	NotLoggedNotificationService insufficientLogTimeNotificationService;
	
	@PostMapping("/notification/insufficientlogtime")
	public String triggerInsufficientLogTimeBatch() {
		insufficientLogTimeNotificationService.triggerNotLoggedNotificationBatch();
		return "Success";
	}
}
