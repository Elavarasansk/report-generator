package org.com.tools.controller;

import java.util.Map;

import org.com.tools.service.KairoApiPreValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/kairo-redmine")
public class RedmineUserDetailsController {
	
	@Autowired
	KairoApiPreValidationService apiPreValidationService;
	
	@GetMapping("/user/details")
	public Map<String, String> getRedmineUserDetails(@RequestHeader(value = "userId", required = false) Integer triggeredBy){
		return apiPreValidationService.fetchUserDetails(triggeredBy);
	}
	
	
}
