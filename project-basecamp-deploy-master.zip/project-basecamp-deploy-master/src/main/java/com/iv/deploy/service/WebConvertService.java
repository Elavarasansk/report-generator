package com.iv.deploy.service;



import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.iv.deploy.utility.CommonUtils;
import com.iv.deploy.utility.GITConstants;

public class WebConvertService {

	
	public void convert(List<String> dprPath) throws Exception {
		for( String path   : dprPath) {
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			processBuilder.directory(new File(GITConstants.JAR_PATH_TARGET));
			processBuilder.command("java", "-jar" ,"-Xmx1024m", "web-converter-jar-with-dependencies.jar","1",path);					
			p = processBuilder.start();
			System.out.println("WebConvert started for "+path);
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
		List<String> linesList = new ArrayList<>();
		String line;
		while ((line = reader.readLine()) != null) {
			linesList.add(line);
		}
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception("Web convert failed for- "+path);
		}finally {
			if(Objects.nonNull(p)) {
					p.destroy();
			}
		}
		};
	}
	
	public void convertModule(List<String> dprPath) throws Exception {
		for( String path   : dprPath) {
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			processBuilder.directory(new File(GITConstants.JAR_PATH_TARGET));
			processBuilder.command("java", "-jar" ,"-Xmx1024m", "web-converter-jar-with-dependencies.jar","1",path);					
			p = processBuilder.start();
			System.out.println("WebConvert started for "+path);
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
		List<String> linesList = new ArrayList<>();
		String line;
		while ((line = reader.readLine()) != null) {
			linesList.add(line);
		}
		} catch (IOException e) {
			System.out.println("Web convert failed for- "+path);
		}finally {
		p.destroy();
		}
		};
	}
	
	
	
	public void convertModule( String module) {
		String dirPath = CommonUtils.findSvnPath(module);
		dirPath = dirPath+"\\"+"hue_client\\delphi";
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			processBuilder.directory(new File(GITConstants.JAR_PATH_TARGET));
			processBuilder.command("java", "-jar", "-Xmx1024m", "web-converter-jar-with-dependencies.jar","2",dirPath);					
			p = processBuilder.start();
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
		List<String> linesList = new ArrayList<>();
		String line;
		while ((line = reader.readLine()) != null) {
			linesList.add(line);
		}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
		p.destroy();
		}
	}
	
	


}
