package com.iv.deploy.service;



import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.iv.deploy.entity.DprDetailsEntity;

public class CompilerService {
	
	
	
	public static  void singleBuild(String dprName, Boolean isStatic) throws Exception {
		
		MainService mainService = new MainService();
		DprDetailsEntity dprDetails = mainService.getAllDprs("").stream()
				.filter(mapper->mapper.getDprName().equals(dprName)).findFirst().orElse(null);
		
		 if(Objects.isNull(dprDetails)) {
				throw new Exception("DPR Not found.");
		 }
		 
		
		 // 1.SVN SYNC
//		try {
//			SvnSyncService svnSyncService = new SvnSyncService();
//			svnSyncService.prepareForSvnUpdate("SVN", dprDetails.getModule());
//			}catch (SVNException e) {
//				throw new Exception("SVN SYNC failed.");
//			}		

		
		//2.WEB CONVERT
		WebConvertService convertService = new WebConvertService();
		convertService.convert(Arrays.asList(dprDetails.getDprPath()));
		System.out.println("WebConvert completed - "+dprDetails.getDprPath());

		//3. DLL GENERATION && IIS DEPLOY
		mainService.execute(dprDetails.getDprPath(),isStatic);
		System.out.println("DLL Deploy completed - "+dprDetails.getDprPath());

	

		
	}

	public static void groupBuild(String[] split, Boolean isStatic) throws Exception{
		
		MainService mainService = new MainService();
		List<String> dataList = Arrays.asList(split); 
		List<DprDetailsEntity> dprDetailsList = mainService.getAllDprs("").stream()
				.filter(mapper->dataList.contains(mapper.getDprName())).collect(Collectors.toList());
		
		 if(CollectionUtils.isEmpty(dprDetailsList)) {
				throw new Exception("DPR Not found.");
		 }
		 
		List<String> moduleList = dprDetailsList.stream().map(DprDetailsEntity::getModule).collect(Collectors.toList());
		List<String> dprPathList = dprDetailsList.stream().map(DprDetailsEntity::getDprPath).collect(Collectors.toList());

		// 1.SVN SYNC
//		try {
//			SvnSyncService svnSyncService = new SvnSyncService();
//			for ( String module : moduleList) { 
//			svnSyncService.prepareForSvnUpdate("SVN", module);
//				};
//			}catch (SVNException e) {
//				throw new Exception("SVN SYNC failed.");
//			}		

		
		//2.WEB CONVERT
		WebConvertService convertService = new WebConvertService();
		convertService.convert(dprPathList);
		System.out.println("WebConvert completed");

		//3. DLL GENERATION && IIS DEPLOY
		mainService.executeMultiple(dprPathList,isStatic);
		System.out.println("DLL Deploy completed");
	

		
	}

	public static void moduleBuild(String moduleData, Boolean isStatic) throws Exception {
		
		MainService mainService = new MainService();
		List<DprDetailsEntity> dprDetailsList = mainService.getAllDprs(moduleData);
		
		 if(CollectionUtils.isEmpty(dprDetailsList)) {
				throw new Exception("DPR Not found.");
		 }
		 
		List<String> dprPathList = dprDetailsList.stream().map(DprDetailsEntity::getDprPath).collect(Collectors.toList());

		// 1.SVN SYNC
//		try {
//			SvnSyncService svnSyncService = new SvnSyncService();
//			svnSyncService.prepareForSvnUpdate("SVN", moduleData);
//			}catch (SVNException e) {
//				throw new Exception("SVN SYNC failed.");
//			}		

		
		//2.WEB CONVERT
		WebConvertService convertService = new WebConvertService();
		convertService.convertModule(dprPathList);

		//3. DLL GENERATION && IIS DEPLOY
		mainService.executeModule(dprPathList,isStatic);
	

		
	
		
	}





}
