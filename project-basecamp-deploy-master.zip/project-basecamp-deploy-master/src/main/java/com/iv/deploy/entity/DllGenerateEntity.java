package com.iv.deploy.entity;


import java.util.Date;
import java.util.List;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DllGenerateEntity {
	
	private String dprName;
	private String dprPath;
	private List<String> compileLog;
	private Boolean isDllGenerated;
	private Boolean isDllDeployed;
	private Date lastCompiled;
	
}
