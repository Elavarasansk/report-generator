package com.iv.deploy.utility;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BuildPackage {
	
	public static void build(String path) throws Exception {

			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			System.out.println(path);
			processBuilder.command("cmd.exe","/c","dir "+new File(path).getParentFile());
			processBuilder.command(path);
			try {
				p = processBuilder.start();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(p.getInputStream()));
				String line;
				while ((line = reader.readLine()) != null) {
					System.out.println(line);
				}	
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Cfw tool build failed.");
			}finally {
				if(Objects.nonNull(p)) {
		 			p.destroy();
				}
			}
			
			
		
	}

}
