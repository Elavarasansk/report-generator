package com.iv.deploy.service;


import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;

import com.iv.deploy.constants.MainConstants;
import com.iv.deploy.entity.DllGenerateEntity;
import com.iv.deploy.entity.DprDetailsEntity;
import com.iv.deploy.utility.GITConstants;

public class MainService {
	

	public List<String> getDprList(String repo) {
		String format[] = { "dpr" };
		List<String> fileList = new ArrayList<>();
		
		String repoPath = new String();
		
		switch(repo.toUpperCase()) {
			case "COM":
				repoPath = MainConstants.SVN41_COM;
				break;
			case "CAM":
				repoPath = MainConstants.SVN41_CAM;
				break;
			case "CBM":
				repoPath = MainConstants.SVN41_CBM;
				break;
			case "CCM":
				repoPath = MainConstants.SVN41_CCM;
				break;
			case "CFM":
				repoPath = MainConstants.SVN41_CFM;
				break;
			default:
				repoPath = null;
				break;
		}
		
		if(Objects.isNull(repoPath) || !new File(repoPath).exists()) {
			return null;
		}
		
		fileList = FileUtils.listFiles(new File(repoPath), format, true).stream()
				.filter(file-> !file.getAbsolutePath().toLowerCase().contains("renderingcomponents"))
				.filter(file-> !file.getAbsolutePath().toLowerCase().contains("accommon"))
				.filter(file -> !((File) file).getName().contains("_FORDEV"))
				.map(file -> file.getPath()).collect(Collectors.toList());
		return fileList;
	}
	

	
	public void executeMultiple(List<String> dprList, boolean isStatic) throws Exception {
		
		for( String dpr : dprList ){
			DllGenerateEntity entity = DllGenerateEntity.builder().build();
			List<File> dllFilesList = compileDpr(dpr, entity,isStatic);
			moveDllToIIS(dllFilesList,isStatic);
			if(Objects.isNull(entity.getIsDllGenerated()) || !entity.getIsDllGenerated()) {
				entity.getCompileLog().stream().forEach(action ->System.out.println(action));
				throw new Exception("DLL generation failed - "+dpr);
			}	
		}
	}
	
	public void execute(String dprName , boolean isStatic) throws Exception {
		DllGenerateEntity entity = DllGenerateEntity.builder().build();
		List<File> dllFilesList = compileDpr(dprName, entity,isStatic);
		moveDllToIIS(dllFilesList,isStatic);
		if(Objects.isNull(entity.getIsDllGenerated()) || !entity.getIsDllGenerated()) {
			entity.getCompileLog().stream().forEach(action ->System.out.println(action));
			throw new Exception("DLL generation failed - "+dprName);
		}

	}

	public void executeModule(List<String> dprList,boolean isStatic) {
		
		for( String dpr : dprList ){
			DllGenerateEntity entity = DllGenerateEntity.builder().build();
			List<File> dllFilesList = compileDpr(dpr, entity,isStatic);
			moveDllToIIS(dllFilesList,isStatic);
			if(Objects.isNull(entity.getIsDllGenerated()) || !entity.getIsDllGenerated()) {
				entity.getCompileLog().stream().forEach(action ->System.out.println(action));
				System.out.println("DLL generation failed - "+dpr);
			}	
		}
	}
	
	
	
	public List<DprDetailsEntity> getAllDprs(String module) {
		List<DprDetailsEntity> allDprList = new ArrayList<>();
		
		List<DprDetailsEntity> comList = new ArrayList<>();
		List<DprDetailsEntity> camList = new ArrayList<>();
		List<DprDetailsEntity> ccmList = new ArrayList<>();
		List<DprDetailsEntity> cfmList = new ArrayList<>();
		List<DprDetailsEntity> cbmList = new ArrayList<>();
		
		switch(module) {
		case MainConstants.SVN41_COM:
			getDprForModule(MainConstants.SVN41_COM, "COM", comList);
			return comList;
		case MainConstants.SVN41_CAM:
			getDprForModule(MainConstants.SVN41_CAM, "CAM", camList);
			return camList;
		case MainConstants.SVN41_CBM:
			getDprForModule(MainConstants.SVN41_CBM, "CBM", cbmList);
			return cbmList;
		case MainConstants.SVN41_CCM:
			getDprForModule(MainConstants.SVN41_CCM, "CCM", ccmList);
			return ccmList;
		case MainConstants.SVN41_CFM:
			getDprForModule(MainConstants.SVN41_CFM, "CFM", cfmList);
			return cfmList;
			
		}
		
		getDprForModule(MainConstants.SVN41_COM, "COM", comList);
		getDprForModule(MainConstants.SVN41_CAM, "CAM", camList);
		getDprForModule(MainConstants.SVN41_CBM, "CBM", cbmList);
		getDprForModule(MainConstants.SVN41_CCM, "CCM", ccmList);
		getDprForModule(MainConstants.SVN41_CFM, "CFM", cfmList);
	
		allDprList.addAll(comList);
		allDprList.addAll(camList);
		allDprList.addAll(ccmList);
		allDprList.addAll(cfmList);
		allDprList.addAll(cbmList);
		
		return allDprList;
	}
	
	private void getDprForModule(String modulePath, String module, List<DprDetailsEntity> allDprList) {
		String format[] = { "dpr" };
		if(!new File(modulePath).exists()) {
			return;
		}
		List<DprDetailsEntity> dprList = FileUtils.listFiles(new File(modulePath), format, true).stream()
				.filter(file-> !file.getAbsolutePath().toLowerCase().contains("renderingcomponents"))
				.filter(file-> !file.getAbsolutePath().toLowerCase().contains("accommon"))
				.filter(file -> !((File) file).getName().contains("_FORDEV"))				.map(dpr -> DprDetailsEntity.builder().dprName(dpr.getName()).dprPath(dpr.getPath()).module(module).build()).collect(Collectors.toList());
		allDprList.addAll(dprList);
	}
	
	private List<File> compileDpr(String dprPath, DllGenerateEntity entity,boolean isStatic) {
		try {
			dprPath = dprPath.replace("hue_client", "hue_web");
			File dpr = new File(dprPath);
			List<String> compileLog = new ArrayList<>();
			
			entity.setDprName(dpr.getName());
			entity.setDprPath(dpr.getPath());
			
			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			processBuilder.directory(dpr.getParentFile());
			if(isStatic) {
				processBuilder.command(GITConstants.DCC32_COMPILER, dpr.getName());
			}else {
				processBuilder.command(GITConstants.DCC32_COMPILER,"-LU"+GITConstants.DYNAMIC_DLL_PARAM, dpr.getName());
			}
			processBuilder.redirectErrorStream(true);
			p = processBuilder.start();

			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}

			linesList.stream().forEach(lne -> {
				compileLog.add(lne);
			});
			
			entity.setCompileLog(compileLog);
			
			String[] format = { "dll" };
			List<File> dllFilesList = FileUtils.listFiles(dpr.getParentFile(), format, true).stream().map(file -> (File) file).collect(Collectors.toList());
			if(dllFilesList.size() > 0) {
				entity.setIsDllDeployed(true);
				entity.setIsDllGenerated(true);
			}
			return dllFilesList;
			
		} catch(Exception e) {
			entity.setIsDllDeployed(false);
			entity.setIsDllGenerated(false);
			e.printStackTrace();
			return new ArrayList<>();
		}
	}
	
	
	
	private void moveDllToIIS(List<File> dllFilesList, boolean isStatic) {
		dllFilesList.stream().forEach(file -> {
			try {
				String location = isStatic ? MainConstants.IIS_STATIC : MainConstants.IIS_DYNAMIC;
				File dllFile = new File(location + "\\" + file.getName());
				if(dllFile.exists()) {
					dllFile.delete();
				}
				FileUtils.copyFileToDirectory(file, new File(location), true);
			} catch(Exception e) {
				e.printStackTrace();
			}
		});
	}

	
	


	
}
