package com.iv.deploy.service;



import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullResult;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.TextProgressMonitor;
import org.eclipse.jgit.transport.TrackingRefUpdate;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

import com.iv.deploy.entity.GitPullResponse;
import com.iv.deploy.entity.RefsTrackingUpdate;
import com.iv.deploy.utility.BuildPackage;
import com.iv.deploy.utility.GITConstants;

public class GitSyncService {

	private static String acgitUrl = "http://192.168.179.25/cfw/hue-ac-cfw-tool.git";

	private static String acgitUserName = "vairavan.u";

	private static String acgitPassword = "Vairavan@6";



	public static void updateCfwTool() throws Exception {
		cacGitPull();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream inStream  = loader.getResourceAsStream("mvn_cfw.bat");
		String filePath  = FileUtils.getTempDirectoryPath()+"mvn_cfw.bat";
		new File(filePath).deleteOnExit();	
		if(!(new File(filePath).exists())) {
			File newFile = new File(filePath);
			FileUtils.copyInputStreamToFile(inStream, newFile);
			filePath= newFile.getAbsolutePath();
		}
		BuildPackage.build(filePath);

	}

	
	public static GitPullResponse cacGitPull() throws Exception {
		GitPullResponse response = GitPullResponse.builder().build();
		File cacRepoPath = new File(GITConstants.HUE_DEVELOP+GITConstants.CFW_TOOL_REPO);
		if(cacRepoPath.exists()) {
			pullExistingRepo(cacRepoPath);
		} else {
			cloneNonExistingRepo(GITConstants.CFW_TOOL_REPO);
		}
		return response;
	}

	private static void cloneNonExistingRepo(String repo) throws Exception {
		UsernamePasswordCredentialsProvider credsProvider = new UsernamePasswordCredentialsProvider(acgitUserName, acgitPassword);
		System.out.println("Cloning the repo - "+repo+" Started @" + new Date(System.currentTimeMillis()));
		try {
			Git.cloneRepository()
			.setURI(acgitUrl)
			.setCredentialsProvider(credsProvider)
			.setDirectory(new File(GITConstants.HUE_DEVELOP))
			.call();
			System.out.println("Cloning the repo - "+repo+" Completed @" + new Date(System.currentTimeMillis()));
		} catch (GitAPIException e) {
			e.printStackTrace();
			System.out.println("Cloning the repo - "+repo+" failed " + new Date(System.currentTimeMillis()));
			throw new Exception("Git Clone failed.");
		}
	}

	private static GitPullResponse pullExistingRepo(File repoPath) throws Exception {
		GitPullResponse response = GitPullResponse.builder().build();
		String repoName = repoPath.getPath();

		File lockFile = new File(repoName + "\\" + GITConstants.INDEX_LOCK_FILE);
		if(lockFile.exists()) {
			lockFile.delete();
		}

		UsernamePasswordCredentialsProvider credsProvider = new UsernamePasswordCredentialsProvider(acgitUserName, acgitPassword);
		System.out.println("Started @ git pull - "+repoName+" " + new Date(System.currentTimeMillis()));
		try {
			Git localGit = Git.open(repoPath);
			PullResult pullRes = localGit.pull()
					.setProgressMonitor(new TextProgressMonitor(new PrintWriter(System.out)))
					.setRemote(GITConstants.ORIGIN)
					.setCredentialsProvider(credsProvider).call();
			System.out.println("Result "+ pullRes.getMergeResult());
			System.out.println("Completed @ git pull - "+repoName+" " + new Date(System.currentTimeMillis()));
			localGit.close();
			response = processPullResult(pullRes);
		} catch (GitAPIException | IOException e) {
			System.out.println("Error Fetching the repo "+ e.getMessage());
			throw new Exception("Git update failed.");
		}
		return response;
	}

	private static GitPullResponse processPullResult(PullResult pullResult) {
		Collection<TrackingRefUpdate> trackingRef = pullResult.getFetchResult().getTrackingRefUpdates();

		List<RefsTrackingUpdate> trackingUpdate = trackingRef.stream().map(y ->RefsTrackingUpdate.builder()
				.remoteName(y.getRemoteName())
				.trackResult(y.getResult().toString())
				.build()).collect(Collectors.toList());

		return GitPullResponse.builder()
				.fetchFrom(pullResult.getFetchedFrom())
				.mergeSuccess(pullResult.getMergeResult().getMergeStatus().isSuccessful())
				.pullSuccess(pullResult.isSuccessful())
				.remoteUri(pullResult.getFetchResult().getURI().toString())
				.trackingUpdate(trackingUpdate)
				.build();
	}

}
