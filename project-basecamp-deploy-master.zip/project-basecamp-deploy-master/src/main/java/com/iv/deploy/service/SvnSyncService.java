package com.iv.deploy.service;



import java.io.File;

import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNUpdateClient;
import org.tmatesoft.svn.core.wc.SVNWCClient;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.iv.deploy.utility.CommonUtils;
import com.iv.deploy.utility.GITConstants;


public class SvnSyncService {

	private String COM = "http://com-prm/svn/prm/branches/COM";

	private String CAM = "http://cam-prm/svn/prm/branches/CAM";

	private String CBM = "http://cbm-prm/svn/prm/branches/CBM";

	private String CCM = "http://ccm-prm/svn/prm/branches/CCM";

	private String CFM = "http://cfm-prm/svn/prm/branches/CFM";

	private String svnLogin = "vairavan.u";

	private String svnPassword = "vairavan.u";
	
	private String formSvnFilePath = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V41";


	public void prepareForSvnUpdate(String svnType, String module) throws SVNException {
		String svnUrl="";
		String svnNum = "41/hue_client";

		switch (module) {
		case GITConstants.COM:
			svnUrl = COM+svnNum;
			break;

		case GITConstants.CAM:
			svnUrl = CAM+svnNum;
			break;

		case GITConstants.CBM:
			svnUrl = CBM+svnNum;
			break;

		case GITConstants.CCM:
			svnUrl = CCM+svnNum;
			break;

		case GITConstants.CFM:
			svnUrl = CFM+svnNum;
			break;
	}
		formSvnFilePath = CommonUtils.findSvnPath(module);
		updateSvn(svnUrl, formSvnFilePath,svnType,module);

	}
	
	
	public void updateSvn(String url, String formSvnFilePath,String verType, String module) throws SVNException {
		SVNRepository repository = SVNRepositoryFactory.create(SVNURL.parseURIDecoded(url));
		ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(svnLogin, svnPassword);
		repository.setAuthenticationManager(authManager);

		SVNClientManager ourClientManager = SVNClientManager.newInstance();
		ourClientManager.setAuthenticationManager(authManager);

		SVNUpdateClient updateClient = ourClientManager.getUpdateClient();
		updateClient.setIgnoreExternals(true);

		SVNWCClient workingCopy = ourClientManager.getWCClient();
		long latestRevision = repository.getLatestRevision();

		workingCopy.doCleanup(new File(formSvnFilePath), false, true, false, false, false, true);
		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);
		//		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);

		System.out.print("revision info "+ latestRevision +"-------->"+ updatedRevision);
}

	public void prepareForSvnUpdateAll() {
		
		String svnNum = "41";
		Thread cacThread = new Thread(new Runnable() {
			@Override
			public void run() {
				String svnUrl = "COM"+svnNum;
				try {
					updateSvn(svnUrl, svnUrl, "SVN", "COM");
				} catch (SVNException e) {
					e.printStackTrace();
				}
			}
		});

		Thread camThread = new Thread(new Runnable() {
			@Override
			public void run() {
				String svnUrl = "CAM"+svnNum;
				try {
					updateSvn(svnUrl, svnUrl, "SVN", "CAM");
				} catch (SVNException e) {
					e.printStackTrace();
				}			
			}
		});

		Thread cbmThread = new Thread(new Runnable() {
			@Override
			public void run() {		
				String svnUrl = "CCM"+svnNum;
			try {
				updateSvn(svnUrl, svnUrl, "SVN", "CCM");
			} catch (SVNException e) {
				e.printStackTrace();
			}			
		}
		});

		Thread ccmThread = new Thread(new Runnable() {
			@Override
			public void run() {
			String svnUrl = "CFM"+svnNum;
			try {
				updateSvn(svnUrl, svnUrl, "SVN", "CFM");
			} catch (SVNException e) {
				e.printStackTrace();
			}			
		}
		});

		Thread cfmThread = new Thread(new Runnable() {
			@Override
			public void run() {
				String svnUrl = "CBM"+svnNum;
				try {
					updateSvn(svnUrl, svnUrl, "SVN", "CBM");
				} catch (SVNException e) {
					e.printStackTrace();
				}			
			}			
		});

		cacThread.start();
		camThread.start();
		cbmThread.start();
		ccmThread.start();
		cfmThread.start();
	}



}
