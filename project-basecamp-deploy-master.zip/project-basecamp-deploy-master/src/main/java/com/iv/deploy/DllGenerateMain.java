package com.iv.deploy;

import com.iv.deploy.controller.CompilerController;

public class DllGenerateMain {

	public static void main(String[] args) throws Exception {
		
		int mode = Integer.parseInt(args[0]);

		
		switch(mode) {
		
		case 1:
			singleBuild(args[2],Boolean.valueOf(args[1]));
			break;
			
		case 2:
			groupBuild(args[2],Boolean.valueOf(args[1]));
			break;
			
		case 3:
			moduleBuid(args[2],Boolean.valueOf(args[1]));
			break;
			
		case 4:
			updateCfwTool();
			break;
			
		default:
			break;
		}
		
		
	}

	private static void updateCfwTool() throws Exception {
		CompilerController.updateCfwTool();
		
	}

	private static void moduleBuid(String args, Boolean isStatic) throws Exception {
		CompilerController.moduleBuild(args,isStatic);
	}

	private static void groupBuild(String args, Boolean isStatic) throws Exception {
		CompilerController.groupBuild(args,isStatic);
		
	}

	private static void singleBuild(String args, Boolean isStatic) throws Exception {
		CompilerController.singleBuild(args,isStatic);
	}
}
