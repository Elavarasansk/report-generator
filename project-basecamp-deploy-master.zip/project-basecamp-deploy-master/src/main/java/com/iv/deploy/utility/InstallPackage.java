package com.iv.deploy.utility;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Objects;

public class InstallPackage {
	
	public static void main(String args[]) throws Exception {

			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			processBuilder.command("D:\\Borland\\Delphi7\\Bin\\DCC32.EXE","accommon.dpk");
			processBuilder.command("D:\\HUE\\Workspace\\Develop\\hue-ac-chennai-cac\\hue_client\\delphi\\accommon\\Packages\\");
			try {
				p = processBuilder.start();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(p.getInputStream()));
				String line;
				while ((line = reader.readLine()) != null) {
					System.out.println(line);
				}	
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Cfw tool build failed.");
			}finally {
				if(Objects.nonNull(p)) {
		 			p.destroy();
				}
			}
			
			
		
	}

}
