package com.iv.deploy.controller;

import com.iv.deploy.service.CompilerService;
import com.iv.deploy.service.GitSyncService;

public class CompilerController {
	
	public static void singleBuild(String args, Boolean isStatic) throws Exception{
		CompilerService.singleBuild(args,isStatic);
	}
	

	public static void groupBuild(String args, Boolean isStatic) throws Exception{
		CompilerService.groupBuild(args.split(","),isStatic);
	}
	
	public static void  moduleBuild(String module, Boolean isStatic) throws Exception{
		CompilerService.moduleBuild(module,isStatic);
	}


	public static void updateCfwTool() throws Exception{
		GitSyncService.updateCfwTool();

	}
	



}
