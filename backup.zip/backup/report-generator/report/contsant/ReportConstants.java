package com.report.contsant;

public class ReportConstants {
	
	public static final String RIGHT_ANSWER = "Right Answer";
	public static final String WRONG_ANSWER = "Wrong Answer";


}
