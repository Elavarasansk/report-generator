package com.infoview.admin.asset.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infoview.admin.asset.dto.entity.UserDetails;
import com.infoview.admin.asset.dto.vo.UserDetailVo;
import com.infoview.admin.asset.service.UserDetailService;

import javassist.NotFoundException;

@RestController
@RequestMapping("/user/details/")
public class UserDetailController {
	
	@Autowired
	private UserDetailService userDetailService;

	@GetMapping("all")
	public List<UserDetails> fetchAllUserInfo(){
		return userDetailService.fetchUserDetails();
	}
	
	@GetMapping
	public UserDetails fetchUserInfo(){
		return userDetailService.fetchUserInfo();
	}
	
	@GetMapping("/{empId}")
	public UserDetails fetchTargetUser(@PathVariable String empId){
		return userDetailService.fetchTargetUser(empId);
	}
	
	@PostMapping
	public UserDetails updateUserInfo(@RequestBody UserDetailVo userDetailVo){
		return userDetailService.saveUserInfo(userDetailVo);
	}
	
	@DeleteMapping("/{empId}")
	public String removeUserInfo(@PathVariable String empId) throws NotFoundException{
		return userDetailService.deleteUser(empId);
	}
}


/*@PutMapping
public UserDetails updateUserInfo(@RequestBody UserDetailVo userDetailVo){
	return userDetailService.saveUserInfo(userDetailVo);
}*/	