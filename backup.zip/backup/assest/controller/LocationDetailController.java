package com.infoview.admin.asset.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infoview.admin.asset.dto.entity.LocationDetails;
import com.infoview.admin.asset.service.LocationDetailService;

@RestController
@RequestMapping("/location/details/")
public class LocationDetailController {

	@Autowired
	private LocationDetailService locationDetailService;
	
	@GetMapping("/{locationId}")
	public LocationDetails getLocationDetails(@PathVariable(value="locationId") long locationId) {
	    return locationDetailService.getLocationInfo(locationId);
	}
	
}
