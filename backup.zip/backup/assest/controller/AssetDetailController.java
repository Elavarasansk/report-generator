package com.infoview.admin.asset.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infoview.admin.asset.dto.entity.AssetDetails;
import com.infoview.admin.asset.dto.vo.AssetDetailVo;
import com.infoview.admin.asset.dto.vo.DistinctAssetDetailVo;
import com.infoview.admin.asset.service.AssetDetailService;

import javassist.NotFoundException;

@RestController
@RequestMapping("/asset/details/")
public class AssetDetailController {
	
	@Autowired
	private AssetDetailService assetDetailService;

//	@GetMapping
//	public List<AssetDetails> fetchAllAssets(){
//		return assetDetailService.fetchAssetDetails();
//	}
	
	@GetMapping
	public List<AssetDetails> fetchAssetInfo(){
		return assetDetailService.fetchUserAssetDetail();
	}
	
	@GetMapping("distinct")
	public List<DistinctAssetDetailVo> findDistinctAssetType(){
		return assetDetailService.findDistinctAssetType();
	}

	@GetMapping("/{assetType}")
	public List<AssetDetails> fetchByAssetType(@PathVariable String assetType){
		return assetDetailService.fetchByAssetType(assetType);
	}
	
	@PostMapping
	public List<AssetDetails> addAssetInfo(@RequestBody AssetDetailVo assetDetailList){
		return assetDetailService.saveAssetDetail(assetDetailList);
	}
	
	@PutMapping
	public List<AssetDetails> updateAssetInfo(@RequestBody AssetDetailVo assetDetailList){
		return assetDetailService.saveAssetDetail(assetDetailList);
	}
	
	@DeleteMapping("/{id}")
	public String removeAsset(@PathVariable Long id) throws NotFoundException{
		return assetDetailService.deleteAssetInfo(id);
	}
}
