package com.infoview.admin.asset.dto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.infoview.admin.asset.dto.entity.VirtualResources;

@Transactional
public interface VirtualResourcesRepository extends JpaRepository<VirtualResources, Long> {

	VirtualResources findByTypeAndIpAddressAndPort(String type, String ipAddress, String port);
	
}
