package com.infoview.admin.asset.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.VirtualResources;
import com.infoview.admin.asset.dto.repository.VirtualResourcesRepository;
import com.infoview.admin.asset.dto.vo.VirtualResourcesVo;
import com.infoview.admin.asset.utils.storage.CookieSessionStorage;

@Service
public class VirtualResourcesService {

	@Autowired
	private VirtualResourcesRepository virtualResourcesRepo;


	public VirtualResources checkResourceExists(VirtualResourcesVo virtualResourcesVo) {
		return virtualResourcesRepo.findByTypeAndIpAddressAndPort(virtualResourcesVo.getType(),
				virtualResourcesVo.getIpAddress(),virtualResourcesVo.getPort());
	}

	public VirtualResources saveResourceInfo(VirtualResourcesVo virtualResourcesVo) {
		String sessionUser = CookieSessionStorage.get().getUserName();
		VirtualResources virtualResources = checkResourceExists(virtualResourcesVo);
		
		if(ObjectUtils.isEmpty(virtualResources)) {
			virtualResources = VirtualResources.builder().build();
			BeanUtils.copyProperties(virtualResourcesVo, virtualResources);
			return virtualResourcesRepo.save(virtualResources);
		}
		return virtualResources;
	}

}
