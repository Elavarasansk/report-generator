package com.infoview.admin.asset.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.EmployeeProjectInfo;
import com.infoview.admin.asset.dto.repository.EmployeeProjectInfoRepository;
import com.infoview.admin.asset.dto.repository.ProjectRepository;
import com.infoview.admin.asset.dto.repository.RoleRepository;
import com.infoview.admin.asset.dto.vo.EmployeeProjectInfoVo;
import com.infoview.admin.asset.utils.storage.CookieSessionStorage;

@Service
public class EmployeeProjectInfoService {

    @Autowired
    private EmployeeProjectInfoRepository empProjectInfoRepo;

    @Autowired
    private ProjectRepository projectRepo;

    @Autowired
    private RoleRepository roleRepo;

    public List<EmployeeProjectInfo> getEmployeeProjectInfoList(){
        return empProjectInfoRepo.findAll();   
    }

    public EmployeeProjectInfo saveEmployeeProjectInfo(EmployeeProjectInfoVo empProjectInfoForm) {
        String sessionUser = CookieSessionStorage.get().getUserName();

        EmployeeProjectInfo empProjectInfoBuilder = EmployeeProjectInfo.builder().build();
        BeanUtils.copyProperties(empProjectInfoForm, empProjectInfoBuilder);

        empProjectInfoBuilder.setProject(projectRepo.findOne(empProjectInfoForm.getProjectId()));
        empProjectInfoBuilder.setRole(roleRepo.findOne(empProjectInfoForm.getRoleId()));
        
        this.filterExisting(empProjectInfoForm, empProjectInfoBuilder);
        empProjectInfoBuilder.setUpdateUser(sessionUser);
        
        return empProjectInfoRepo.save(empProjectInfoBuilder);
    }

    public void filterExisting(EmployeeProjectInfoVo empProjectInfoForm, EmployeeProjectInfo empProjectInfoBuilder) {
        EmployeeProjectInfo duplicateEmployeeInfo = empProjectInfoRepo.findByMailIdAndProjectAndRole(empProjectInfoForm.getMailId(),
                empProjectInfoBuilder.getProject(), empProjectInfoBuilder.getRole());

        if(!ObjectUtils.isEmpty(duplicateEmployeeInfo)) {
            String sessionUser = CookieSessionStorage.get().getUserName();
            empProjectInfoBuilder.setId(duplicateEmployeeInfo.getId());
            empProjectInfoBuilder.setCreateUser(sessionUser);
        }
    }

    public void removeEmployeeProjectInfo(long empProjectInfoId){
        empProjectInfoRepo.delete(empProjectInfoId);   
    }
}
