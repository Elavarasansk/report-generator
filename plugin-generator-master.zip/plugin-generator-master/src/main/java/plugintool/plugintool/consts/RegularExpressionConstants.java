package plugintool.plugintool.consts;

import java.util.regex.Pattern;

public class RegularExpressionConstants {

  public static final String DOT_CHARACTER_REGEX = "\\.";

  public static final String FILE_SEPERATOR_REGEX = "\\\\";

  public static final String DOUBLE_SLASH_REGEX = "\\\\\\\\";

  public static final String UNDERSCORE_REGEX = "\\_";

  public static final Pattern DIGIT_MATCHER_REGEX = Pattern.compile("^[0-9]$");

  public static final Pattern PARAMETER_MATCHER_REGEX = Pattern.compile("(\\{)(.+)(INT|STR|DATE|LONG)([0-9]*)(\\})");

  public static final Pattern DYNAMIC_TABLE_NAME_REGEX = Pattern.compile("^(\\{)(.+)(\\})$");

  public static final Pattern DYNAMIC_WORD_REGEX = Pattern.compile("^(.+)(\\{)(.+)(\\})(.*)$");

  public static final Pattern JAVA_REGISTER_FILE_END_MATCHER = Pattern.compile("\\s\\}+");

  public static final Pattern XML_REGISTER_FILE_END_MATCHER = Pattern.compile("\\</registers\\>");

  public static final Pattern TYPE_NAME_MATCHER_REGEX = Pattern.compile("(.+)(= class)(.+)");

  private RegularExpressionConstants() {
  }

}
