package plugintool.plugintool.consts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PluginGenerationConstants {

  public static final String REGISTER_XML_FILE_PATH = "hue-ac-chennai-cac\\company_server\\WEB-INF\\src_common\\jp\\co\\worksap\\companyac\\share\\plugin";

  public static final String DATABASE_NAME = "intraweb-tools";

  public static final String SQL_TAG_MAPPER_COLLECTION_NAME = "sql-tag-mapper";

  public static final String SQL_FILE_MAPPER_COLLECTION_NAME = "sql-file-mapper";

  public static final String FILE_PATH_MAPPER_COLLECTION_NAME = "file-path-mapper";

  public static final String SQL_TAG_FILE_COLUMN_NAME = "sql_tag_files";

  public static final String FILE_PATH_COLUMN_NAME = "file_path";

  public static final String PLUGIN_FOLDER_PATH = "\\company_server\\WEB-INF\\src_ap\\jp\\co\\worksap\\companyac\\hue_plugin";

  public static final String FILE_ENCODING = "UTF-8";

  public static final String PAS_FILE_EXTENSION = "pas";

  public static final String DFM_FILE_EXTENSION = "dfm";

  public static final String XLS_FILE_EXTENSION = ".xls";

  public static final String WORKBOOK_EXTENSION = "_wk";

  public static final String JAVA_EXTENSION = ".java";

  public static final String CLASS_EXTENSION = ".class";

  public static final String FILE_SEPERATOR = "\\";

  public static final String DOT_CHARACTER = ".";

  public static final String COMMA_DELIMITER = ", ";

  public static final String BACKUP_FILE_DIRECTORY = "D:\\PluginGeneratorFiles";

  public static final String LINE_SEPERATOR_SPLITTER = "[\\\\|\\\\\\\\]";

  public static final String HUE_CLIENT = "hue_client";

  public static final String COMPANY_AC = "companyac";

  public static final String NO_SQL_TAG_FOUND_MESSAGE = "\nNo SQL TAG Found. ";

  public static final String BACKUP_DATE_FROMAT = "yyyyMMdd_HHmmss";

  public static final String BACKUP_PREFIX = "BACKUP_";

  public static final String SUGGEST_PLUGIN_FILE_SUFFIX = "SuggestPlugin.java";

  public static final String SOCIAL_PLUGIN_FILE_SUFFIX = "SocialPlugin.java";

  public static final String SUGGEST_PLUGIN_REGISTER_FILE_SUFFIX = "SuggestPluginRegister.java";

  public static final String SOCIAL_PLUGIN_REGISTER_FILE_SUFFIX = "SocialPluginRegister.java";

  public static final String SUGGEST_PLUGIN_XML_SUFFIX = "suggestPlugin.xml";

  public static final String SOCIAL_PLUGIN_XML_SUFFIX = "socialPlugin.xml";

  public static final String INPUT_FILE_SHEET = "Input_File_Template";

  public static final String LOG_REPORT_SHEET = "Log_Report";

  public static final String OUTPUT_FILE_TEMPLATE = "PluginToolResult_template_20190217.xls";

  public static final String SQL_FILE_NOT_FOUND_MESSAGE = "No SQL File found for this SQL TAG.";

  public static final String DUPLICATE_SQL_TAG_MESSAGE = "NO CHANGES IN PLUGIN : SQL TAG has already been processed in the above steps.";

  public static final String SQL_TAG = "SQL TAG: ";

  public static final String SQL_FILE = "SQL File: ";

  public static final String PLUGIN_ID = "pluginId";

  public static final String PLUGIN_FILE_NAME = "pluginFileName";

  public static final String PLUGIN_REGISTER_FILE_NAME = "pluginRegisterFileName";

  public static final String PLUGIN_DIRECTORY = "pluginDirectory";

  public static final String MODULE = "module";

  public static final String PLUGIN_ID_CONTENT = "pluginIdContent";

  public static final String FOLDER_PATH = "folderPath";

  public static final String PACKAGE_NAME_KEYWORD = "PKGNAME";

  public static final String CLASS_NAME_KEYWORD = "CLSNAME";

  public static final String CONDITION_KEYWORD = "CONDITION";

  public static final String KEYS_KEYWORD = "KEYS";

  public static final String ARGUMENTS_KEYWORD = "ARGUMENTS";

  public static final String PARAMETERS_KEYWORD = "PARAMETERS";

  public static final String TABLENAME_KEYWORD = "TABLENAME";

  public static final String OPTIONAL_KEYWORD = "Optional :";

  public static final String CONCAT_KEYWORD = "CONCAT";

  public static final String CODE_COLUMNS_KEYWORD = "CODE_COLUMNS";

  public static final String NAME_COLUMNS_KEYWORD = "NAME_COLUMNS";

  public static final String FROM_CLAUSE_VALUES_KEYWORD = "FROM_CLAUSE_VALUES";

  public static final String FILE_CREATED_MESSAGE = " has been created.";

  public static final String FILE_ALREADY_PRESENT_MESSAGE = " is already present.";

  public static final String FROM_CLAUSE = "fromClause";

  public static final String WHERE_CLAUSE = "whereClause";

  public static final String FROM_CONDITION_KEY_CLAUSE = "fromConditionKeyClause";

  public static final String WHERE_CONDITION_KEY_CLAUSE = "whereConditionkeyClause";

  public static final String KEY_PARAMETER = "keyParameter";

  public static final String PARAMETER = "parameter";

  public static final String SELECT = "SELECT";

  public static final String FROM = "FROM";

  public static final String WHERE = "WHERE";

  public static final String ORDER = "ORDER";

  public static final String SQL_FILE_COMMENTS = "#";

  public static final String ARGUMENTS_PREFIX = "$";

  public static final String SPACE = " ";

  public static final String DOTTED_LINES = "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ";

  public static List<String> FIELD_LIST = new ArrayList<String>(
      Arrays.asList(PluginGenerationConstants.SQL_TAG_FILE_COLUMN_NAME));

  public static List<String> FILE_MAPPER_FIELD_LIST = new ArrayList<String>(
      Arrays.asList(PluginGenerationConstants.FILE_PATH_COLUMN_NAME));

  public static List<String> queryKeyWords = new ArrayList<>();
  static {
    queryKeyWords.add("AND");
    queryKeyWords.add("OR");
    queryKeyWords.add("BETWEEN");
    queryKeyWords.add("=");
    queryKeyWords.add("SELECT");
    queryKeyWords.add("FROM");
    queryKeyWords.add("WHERE");
    queryKeyWords.add("<=");
    queryKeyWords.add(">=");
    queryKeyWords.add("<>");
    queryKeyWords.add("LIKE");
    queryKeyWords.add("ON");
    queryKeyWords.add("UNION");
    queryKeyWords.add("UNION ALL");
  }

  public static List<String> argumentQueryKeyWords = new ArrayList<>();
  static {
    argumentQueryKeyWords.add("=");
    argumentQueryKeyWords.add("BETWEEN");
    argumentQueryKeyWords.add("IN");
    argumentQueryKeyWords.add("<=");
    argumentQueryKeyWords.add(">=");
    argumentQueryKeyWords.add("<>");
    argumentQueryKeyWords.add("LIKE");
  }

  public static List<String> modifiers = new ArrayList<>();
  static {
    modifiers.add("private");
    modifiers.add("public");
    modifiers.add("protected");
  }

  public static List<String> excludingKeywords = new ArrayList<>();
  static {
    excludingKeywords.add("ORDER");
    excludingKeywords.add("BY");
  }

  public static List<String> omittedcontentList = new ArrayList<>();
  static {
    omittedcontentList.add("//METHOD DECLARATION");
    omittedcontentList.add("//METHOD DEFINITION");
    omittedcontentList.add("//##BEFORESEARCH");
    omittedcontentList.add("//##BEFORESEARCH END");
    omittedcontentList.add("//##SUGGESTSELECT");
    omittedcontentList.add("//##SUGGESTSELECT END");
    omittedcontentList.add("//METHOD DEFINITION END");
  }

  private PluginGenerationConstants() {
  }

}
