package plugintool.plugintool.converter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import javafx.util.Pair;
import plugintool.plugintool.consts.PluginGenerationConstants;
import plugintool.plugintool.consts.RegularExpressionConstants;
import plugintool.plugintool.entity.QueryBuilderEntity;

public class QueryBuilder {

  /**
   * parseQuery is to split the query into every word.
   * 
   * @param sqlFile
   * @param sqlTag
   * @return
   */
  public List<String> parseQuery(File sqlFile, String sqlTag) {
    List<String> queryResultList = new ArrayList<>();
    boolean isSqlStarted = false;
    String line;
    Pattern sqlTagWithSelectMatcherRegex = Pattern.compile("(.*)(" + sqlTag + ")(\\^)(SELECT)");
    Pattern sqlTagMatcherRegex = Pattern.compile("(.*)(" + sqlTag + ")(\\^)(.*)");
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader(sqlFile));
      while (((line = bufferedReader.readLine()) != null && isSqlStarted && !line.equals(StringUtils.EMPTY))
          || !isSqlStarted) {
        if (line.contains(PluginGenerationConstants.SQL_FILE_COMMENTS)) {
          continue;
        }
        if (sqlTagMatcherRegex.matcher(line).find()) {
          isSqlStarted = true;
        }
        if (isSqlStarted) {
          Arrays.asList(line.split(PluginGenerationConstants.SPACE)).forEach(word -> {
            if (!word.isEmpty() && !word.equals("\\")) {
              word = word.contains("\\") ? word.split("\\\\")[0] : word;
              if (sqlTagWithSelectMatcherRegex.matcher(word).find()) {
                word = word.split("(.*)(" + sqlTag + ")(\\^)")[1];
              }
              queryResultList.add(word.trim());
            }
          });
        }
      }
      bufferedReader.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return queryResultList;
  }

  /**
   * getQueryBuilderEntity is to form the queryBuilderEntity for the given sqlTag
   * 
   * @param queryResultList
   * @param sqlTag
   * @return
   */
  public QueryBuilderEntity getQueryBuilderEntity(List<String> queryResultList, String sqlTag) {
    QueryBuilderEntity queryBuilderEntity = new QueryBuilderEntity();
    Pair<Integer, Integer> fromAndWhereIndex = getFromAndWhereIndex(queryResultList);
    int orderByindex = queryResultList.lastIndexOf(PluginGenerationConstants.ORDER);
    int whereStartIndex = fromAndWhereIndex.getValue().intValue() + 1;
    int whereEndIndex = orderByindex != -1 ? orderByindex : queryResultList.size();
    getFROMClauseList(queryResultList, fromAndWhereIndex, queryBuilderEntity);
    getConditionalClauseList(queryResultList, whereStartIndex, whereEndIndex, false, queryBuilderEntity);
    getArgumentsMap(queryResultList, fromAndWhereIndex, queryBuilderEntity);
    getSelectedColumnMap(queryResultList, fromAndWhereIndex, queryBuilderEntity);
    return queryBuilderEntity;
  }

  /**
   * getFromAndWhereIndex is to get the from and where Index of Main query
   * 
   * @param queryResultList
   * @return
   */
  private Pair<Integer, Integer> getFromAndWhereIndex(List<String> queryResultList) {
    Stack<String> queryStack = new Stack<>();
    int currentIndex = 0;
    int fromIndex = 0;
    int whereIndex = 0;
    for (String queryWord : queryResultList) {
      if (queryWord.contains(PluginGenerationConstants.SELECT)) {
        queryStack.push(queryWord);
      }
      if (queryWord.equals(PluginGenerationConstants.FROM) && queryStack.size() == 1) {
        fromIndex = currentIndex;
      }
      if (queryWord.equals(PluginGenerationConstants.WHERE) && queryStack.size() == 1) {
        whereIndex = currentIndex;
        queryStack.pop();
        break;
      } else if (queryWord.equals(PluginGenerationConstants.WHERE) && queryStack.size() > 1) {
        queryStack.pop();
      }
      currentIndex++;
    }
    if (whereIndex == 0) {
      int orderByIndex = queryResultList.lastIndexOf(PluginGenerationConstants.ORDER);
      whereIndex = orderByIndex != -1 ? orderByIndex - 1 : queryResultList.size() - 1;
    }
    return new Pair<>(new Integer(fromIndex), new Integer(whereIndex));
  }

  /**
   * getFROMClauseList is to get the FROM CLAUSE List from query
   * 
   * @param queryResultList
   * @param fromAndWhereIndex
   * @param queryBuilderEntity
   */
  private void getFROMClauseList(List<String> queryResultList, Pair<Integer, Integer> fromAndWhereIndex,
      QueryBuilderEntity queryBuilderEntity) {
    boolean isFrom = true;
    int fromStartIndex = fromAndWhereIndex.getKey().intValue();
    int fromEndIndex = fromAndWhereIndex.getValue().intValue();
    getConditionalClauseList(queryResultList, fromStartIndex, fromEndIndex, isFrom, queryBuilderEntity);
  }

  /**
   * getConditionalClauseList is to get the WHERE CLAUSE List from query
   * 
   * @param queryResultList
   * @param fromIndex
   * @param whereIndex
   * @param isFrom
   * @param queryBuilderEntity
   */
  private void getConditionalClauseList(List<String> queryResultList, int fromIndex, int whereIndex, boolean isFrom,
      QueryBuilderEntity queryBuilderEntity) {
    List<String> filteredConditionList = new ArrayList<>();
    Map<String, String> keyAndDatatypeMap = new HashMap<>();
    List<String> conditionList = queryResultList.subList(fromIndex, whereIndex);
    int[] visitedList = new int[conditionList.size()];
    int fromIndexInQuery = 99999;
    for (int iterator = 0; iterator < conditionList.size(); iterator++) {
      String currentWord = conditionList.get(iterator);
      if (currentWord.equals("(") || currentWord.equals(")")) {
        filteredConditionList.add(currentWord);
        visitedList[iterator] = 1;
        continue;
      }
      if (currentWord.equals(PluginGenerationConstants.FROM)) {
        fromIndexInQuery = iterator;
      }
      if (currentWord.equals(PluginGenerationConstants.WHERE)) {
        fromIndexInQuery = 99999;
      }
      // If current word is Query Keyword , check the previous and next word of it
      if (PluginGenerationConstants.queryKeyWords.contains(currentWord) || (currentWord.contains("(")
          && PluginGenerationConstants.queryKeyWords.contains(currentWord.split("\\(")[1]))) {
        if (isIgnoreCondition(iterator, visitedList, conditionList, filteredConditionList)) {
          continue;
        } else {
          checkConditionForQueryKeyword(iterator, conditionList, visitedList, filteredConditionList, currentWord);
        }
      }
      // To Find cases like VALUE{ETERNALCHANGE}. Not an Argument and
      // DynamicTableName.
      else if (visitedList[iterator] != 1
          && RegularExpressionConstants.DYNAMIC_WORD_REGEX.matcher(currentWord).find()) {
        filteredConditionList.add(currentWord);
        visitedList[iterator] = 1;
      }
      // To find the Optional keys like {SEG_NO_INT1}
      else if (visitedList[iterator] != 1
          && RegularExpressionConstants.PARAMETER_MATCHER_REGEX.matcher(currentWord).find()
          && (iterator == 0
              || !PluginGenerationConstants.argumentQueryKeyWords.contains(conditionList.get(iterator - 1)))
          && (iterator == conditionList.size() - 1
              || !PluginGenerationConstants.argumentQueryKeyWords.contains(conditionList.get(iterator + 1)))) {
        Pair<String, String> argumentAndDataTypePair = getArgumentAndDataType(currentWord);
        if (!argumentAndDataTypePair.getKey().isEmpty()) {
          keyAndDatatypeMap.put(argumentAndDataTypePair.getKey(), argumentAndDataTypePair.getValue());
        }
        visitedList[iterator] = 1;
      }
      // To find the column names & static table names
      else if (!RegularExpressionConstants.DYNAMIC_TABLE_NAME_REGEX.matcher(currentWord).find()
          && visitedList[iterator] != 1) {
        filteredConditionList.add(currentWord);
        visitedList[iterator] = 1;
      }
      // To find the dynamic table Names {AC_CORP_MST_VIEW}
      else if (RegularExpressionConstants.DYNAMIC_TABLE_NAME_REGEX.matcher(currentWord).find()
          && visitedList[iterator] != 1 && iterator > fromIndexInQuery) {
        filteredConditionList.add(currentWord);
        visitedList[iterator] = 1;
      }
    }
    setResult(queryBuilderEntity, filteredConditionList, keyAndDatatypeMap, isFrom);
  }

  /**
   * getArgumentsMap is to get the parameters present in query
   * 
   * @param queryResultList
   * @param fromAndWhereIndex
   * @param queryBuilderEntity
   */
  private void getArgumentsMap(List<String> queryResultList, Pair<Integer, Integer> fromAndWhereIndex,
      QueryBuilderEntity queryBuilderEntity) {
    Map<String, String> argumentsMap = new LinkedHashMap<>();
    int fromIndex = fromAndWhereIndex.getKey().intValue();
    List<String> conditionList = queryResultList.subList(fromIndex + 1, queryResultList.size());
    for (int iterator = 0; iterator < conditionList.size(); iterator++) {
      String currentWord = conditionList.get(iterator);
      String argument = StringUtils.EMPTY;
      if (PluginGenerationConstants.argumentQueryKeyWords.contains(currentWord)) {
        // Assumption: if current word is "BETWEEN", then there is a chance for previous
        // word to be argument
        if (iterator - 1 > 0) {
          Matcher matcher = RegularExpressionConstants.PARAMETER_MATCHER_REGEX.matcher(conditionList.get(iterator - 1));
          if (matcher.find()) {
            argument = matcher.group();
          }
        }
        // Assumption: if current word is "=", then there is a chance for next word to
        // be argument
        if (iterator + 1 < conditionList.size()) {
          Matcher matcher1 = RegularExpressionConstants.PARAMETER_MATCHER_REGEX
              .matcher(conditionList.get(iterator + 1));
          if (matcher1.find()) {
            argument = matcher1.group();
          }
        }
        Pair<String, String> argumentAndDataTypePair = getArgumentAndDataType(argument);
        if (!argumentAndDataTypePair.getKey().isEmpty()) {
          argumentsMap.put(argumentAndDataTypePair.getKey(), argumentAndDataTypePair.getValue());
        }
      }
    }
    queryBuilderEntity.setArgumentMap(argumentsMap);
  }

  /**
   * getSelectedColumnMap is to get column whose fieldName contains name or column
   * 
   * @param queryResultList
   * @param fromAndWhereIndex
   * @param queryBuilderEntity
   */
  private void getSelectedColumnMap(List<String> queryResultList, Pair<Integer, Integer> fromAndWhereIndex,
      QueryBuilderEntity queryBuilderEntity) {
    Map<String, List<String>> columnFilterMap = new HashMap<>();
    List<String> codeList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();
    int beforeTableNameIndex = queryResultList.indexOf(PluginGenerationConstants.SELECT);
    List<String> filteredQueryResult = queryResultList.subList(beforeTableNameIndex + 1, queryResultList.size() - 1);
    int nextSelectIndex = filteredQueryResult.indexOf(PluginGenerationConstants.SELECT);
    int fromIndex = fromAndWhereIndex.getKey().intValue();
    int afterTableNameIndex = ((nextSelectIndex != -1) && (nextSelectIndex < fromIndex)) ? nextSelectIndex : fromIndex;
    List<String> filteredColumnQueries = queryResultList.subList(beforeTableNameIndex + 1, afterTableNameIndex);
    filteredColumnQueries.forEach(column -> {
      if (column.contains("CODE") || column.contains("CD")) {
        column = column.replaceAll(",", StringUtils.EMPTY);
        codeList.add(column);
      }
      if (column.contains("NAME") || column.contains("NM")) {
        column = column.replaceAll(",", StringUtils.EMPTY);
        nameList.add(column);
      }
    });
    columnFilterMap.put("code", codeList);
    columnFilterMap.put("name", nameList);
    queryBuilderEntity.setCodeAndNameColumnMap(columnFilterMap);
  }

  /**
   * getArgumentandDataType is to split SQLFile Argument into argument & datatype.
   * 
   * @param argumentWord
   * @return
   */
  private Pair<String, String> getArgumentAndDataType(String argumentWord) {
    String argumentWordWithoutDatatype = StringUtils.EMPTY;
    String datatype = StringUtils.EMPTY;
    // Split the braces around parameters
    argumentWord = argumentWord.replaceAll("\\{", "");
    argumentWord = argumentWord.replaceAll("\\}", "");
    // split the argument field
    // Assumption: Example- CORP_ID_INT2 , CORP_ID is argument, INT is datatype
    int endIndex = argumentWord.lastIndexOf("_");
    argumentWordWithoutDatatype = argumentWord;
    if (endIndex != -1) {
      argumentWordWithoutDatatype = argumentWord.substring(0, endIndex);
      datatype = argumentWord.substring(endIndex + 1, argumentWord.length() - 1);
    }
    return new Pair<>(argumentWordWithoutDatatype, datatype);
  }

  /**
   * isIgnoreCondition is to omit condition like 0 = 0 in query
   * 
   * @param iterator
   * @param visitedList
   * @param conditionList
   * @param filteredConditionList
   * @return
   */
  private boolean isIgnoreCondition(int iterator, int[] visitedList, List<String> conditionList,
      List<String> filteredConditionList) {
    // To omit condition like 0=0
    if (iterator > 0 && iterator < conditionList.size() - 1 && visitedList[iterator] != 1
        && RegularExpressionConstants.DIGIT_MATCHER_REGEX.matcher(conditionList.get(iterator - 1)).find()
        && RegularExpressionConstants.DIGIT_MATCHER_REGEX.matcher(conditionList.get(iterator + 1)).find()) {
      visitedList[iterator] = 1;
      if (visitedList[iterator - 1] == 1) {
        filteredConditionList.remove(conditionList.get(iterator - 1));
      }
      if (visitedList[iterator + 1] == 1) {
        filteredConditionList.remove(conditionList.get(iterator + 1));
      }
      visitedList[iterator - 1] = 1;
      visitedList[iterator + 1] = 1;
      return true;
    }
    return false;
  }

  /**
   * checkConditionForQueryKeyword is to check the condition for nearest word of
   * query keyword
   * 
   * @param iterator
   * @param conditionList
   * @param visitedList
   * @param filteredConditionList
   * @param currentWord
   */
  private void checkConditionForQueryKeyword(int iterator, List<String> conditionList, int[] visitedList,
      List<String> filteredConditionList, String currentWord) {
    // If the previous word is argument, then remove braces & append $ symbol to it
    if (iterator > 0) {
      formatArgumentWord(conditionList, filteredConditionList, visitedList, iterator - 1, currentWord);
    }

    filteredConditionList.add(conditionList.get(iterator));
    visitedList[iterator] = 1;

    // if next word is argument, then remove braces & append $ symbol to it.
    if (iterator < conditionList.size() - 1) {
      formatArgumentWord(conditionList, filteredConditionList, visitedList, iterator + 1, currentWord);
    }
  }

  /**
   * setResult is to set the Result into queryBuilderEntity
   * 
   * @param queryBuilderEntity
   * @param filteredConditionList
   * @param keyDatatypeMap
   * @param isFrom
   */
  private void setResult(QueryBuilderEntity queryBuilderEntity, List<String> filteredConditionList,
      Map<String, String> keyDatatypeMap, boolean isFrom) {
    // Set the Result to corresponding fields
    if (isFrom) {
      queryBuilderEntity.setFromClauseList(filteredConditionList);
      queryBuilderEntity.setFromClauseKeyMap(keyDatatypeMap);
    } else {
      queryBuilderEntity.setConditionClauseList(filteredConditionList);
      queryBuilderEntity.setConditionClauseKeyMap(keyDatatypeMap);
    }
  }

  /**
   * formatArgumentWord is to format the argument word present in query
   * 
   * @param conditionList
   * @param filteredConditionList
   * @param visitedList
   * @param iterator
   * @param word
   */
  private void formatArgumentWord(List<String> conditionList, List<String> filteredConditionList, int[] visitedList,
      int iterator, String queryKeyword) {
    // If word is argument, then remove braces & append $ symbol to it
    String currentWord = conditionList.get(iterator);
    StringBuilder currentWordAppender = new StringBuilder();
    Matcher matcher = RegularExpressionConstants.PARAMETER_MATCHER_REGEX.matcher(currentWord);
    if (PluginGenerationConstants.argumentQueryKeyWords.contains(queryKeyword) && matcher.find()) {
      String argumentword = matcher.group();
      int matcher_startindex = matcher.start();
      int matcher_endindex = matcher.end();
      Pair<String, String> argumentAndDataTypePair = getArgumentAndDataType(argumentword);
      if (matcher_startindex > 0) {
        currentWordAppender.append(currentWord.substring(0, matcher_startindex));
      }
      currentWordAppender.append(PluginGenerationConstants.ARGUMENTS_PREFIX.concat(argumentAndDataTypePair.getKey()));
      if (matcher_endindex < currentWord.length()) {
        currentWordAppender.append(currentWord.substring(matcher_endindex));
      }
      if (visitedList[iterator] == 1 && filteredConditionList.contains(conditionList.get(iterator))) {
        filteredConditionList.remove(conditionList.get(iterator));
      }
      filteredConditionList.add(currentWordAppender.toString());
      visitedList[iterator] = 1;
    }
  }

}
