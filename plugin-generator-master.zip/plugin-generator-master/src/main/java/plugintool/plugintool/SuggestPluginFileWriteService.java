package plugintool.plugintool;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.StringUtils;

import plugintool.plugintool.consts.PluginGenerationConstants;
import plugintool.plugintool.consts.RegularExpressionConstants;
import plugintool.plugintool.entity.LogReportEntity;
import plugintool.plugintool.entity.PluginRecordEntity;
import plugintool.utils.CommonMethodUtils;
import plugintool.utils.FileReadUtils;

public class SuggestPluginFileWriteService {

  ClassLoader classLoader = this.getClass().getClassLoader();

  InputStream SUGGEST_PLUGIN_PAS_TEMPLATE_PATH = classLoader.getResourceAsStream("SuggestPluginPasTemplate.txt");

  List<String> suggestPluginContents = FileReadUtils.readFile(SUGGEST_PLUGIN_PAS_TEMPLATE_PATH);

  /**
   * addSuggestPluginContents is to add SuggestPlugin Related Content in PAS & DFM
   * File.
   * 
   * @param pluginRecordEntity
   * @param parametersMap
   * @param resultLog
   * @param productDirectory
   * @param subDirectory
   * @param logReportEntity
   * @param isBackupChecked
   * @param backupFolderName
   * @return
   */
  public List<String> addSuggestPluginContents(PluginRecordEntity pluginRecordEntity,
      Map<String, Set<String>> parametersMap, List<String> resultLog, String productDirectory, String subDirectory,
      LogReportEntity logReportEntity, boolean isBackupChecked, String backupFolderName) {
    if (pluginRecordEntity.getSqlFilePath().isEmpty()) {
      return resultLog;
    }
    readDFMFile(pluginRecordEntity, parametersMap, resultLog, logReportEntity, isBackupChecked, backupFolderName);
    readPASFile(pluginRecordEntity, parametersMap, resultLog, suggestPluginContents, logReportEntity, isBackupChecked,
        backupFolderName);
    return resultLog;
  }

  /**
   * readDFMFile is to read DFM file and check whether content exists already.
   * 
   * @param pluginRecordEntity
   * @param parametersMap
   * @param resultLog
   * @param logReportEntity
   * @param isBackupChecked
   * @param backupFolderName
   */
  private void readDFMFile(PluginRecordEntity pluginRecordEntity, Map<String, Set<String>> parametersMap,
      List<String> resultLog, LogReportEntity logReportEntity, boolean isBackupChecked, String backupFolderName) {
    String pluginId = pluginRecordEntity.getPluginId();
    String filePath = pluginRecordEntity.getPasFilePath();
    String editString = pluginRecordEntity.getEditName();
    String dfmExtensionFile = filePath.replace(PluginGenerationConstants.PAS_FILE_EXTENSION,
        PluginGenerationConstants.DFM_FILE_EXTENSION);
    File dfmFilePath = new File(dfmExtensionFile);
    String editStringMethodStartRegex = "object " + editString + ":";
    String contentCheck = "PluginId = '" + pluginId + "'";
    AtomicBoolean contentPresentFlag = new AtomicBoolean(false);
    logReportEntity.setDfmFile(dfmFilePath.toString());
    logReportEntity.setDfmFileChanged("NO");
    if (!dfmFilePath.exists()) {
      return;
    }
    List<String> dfmFileLines = FileReadUtils.readFileLinesAndCheckContent(dfmFilePath, contentPresentFlag,
        editStringMethodStartRegex, contentCheck);
    logReportEntity.setDfmFile(dfmFilePath.toString());
    if (!contentPresentFlag.get()) {
      writeDFMFile(dfmFileLines, pluginRecordEntity, parametersMap, resultLog, logReportEntity, isBackupChecked,
          backupFolderName);
    } else {
      logReportEntity.setDfmFileChanged("NO");
      resultLog.add("\nDFM FILE CHANGES : Content is already present. DFM File " + dfmFilePath + " is not changed.");
    }
  }

  /**
   * writeDFMFile is to write the suggest Plugin related contents into DFM File.
   * 
   * @param dfmFileLines
   * @param pluginRecordEntity
   * @param parametersMap
   * @param resultLog
   * @param logReportEntity
   * @param isBackupChecked
   * @param backupFolderName
   */
  private void writeDFMFile(List<String> dfmFileLines, PluginRecordEntity pluginRecordEntity,
      Map<String, Set<String>> parametersMap, List<String> resultLog, LogReportEntity logReportEntity,
      boolean isBackupChecked, String backupFolderName) {
    String pluginId = pluginRecordEntity.getPluginId();
    String filePath = pluginRecordEntity.getPasFilePath();
    String editString = pluginRecordEntity.getEditName();
    String sqlTag = pluginRecordEntity.getSqlTag();
    String dfmExtensionFile = filePath.replace(PluginGenerationConstants.PAS_FILE_EXTENSION,
        PluginGenerationConstants.DFM_FILE_EXTENSION);
    File dfmFilePath = new File(dfmExtensionFile);
    String editStringMethodStartRegex = "object " + editString + ":";
    String imeModeRegex = "object " + editString + ":" + " THueSuggestEdit";
    List<String> contents = makeContentForDfmFile(pluginId, sqlTag, editString, parametersMap);
    String folderPath = CommonMethodUtils.getFolderPathFromPasFile(pluginRecordEntity.getPasFilePath(),
        pluginRecordEntity.getRepository());
    if (isBackupChecked) {
      CommonMethodUtils.backupFile(backupFolderName, dfmFilePath.toString(), folderPath, dfmFilePath);
    }
    if (FileReadUtils.writeDFMFile(dfmFilePath, dfmFileLines, contents, editStringMethodStartRegex, imeModeRegex)) {
      logReportEntity.setDfmFileChanged("YES");
      resultLog.add(CommonMethodUtils.getDFmFileChangedMessage(editString, dfmFilePath));
    }
  }

  /**
   * makeContentForDfmFile is to make the Suggest Plugin related DFM Contents.
   * 
   * @param pluginId
   * @param sqlTag
   * @param editString
   * @param parametersMap
   * @return
   */
  private List<String> makeContentForDfmFile(String pluginId, String sqlTag, String editString,
      Map<String, Set<String>> parametersMap) {
    List<String> contentString = new ArrayList<>();
    String pluginIdContent = "PluginId = '" + pluginId + "'";
    contentString.add(pluginIdContent);
    if (parametersMap.containsKey(sqlTag) && !parametersMap.get(sqlTag).isEmpty()) {
      String beforeSearchContent = "BeforeSearch = " + editString + "BeforeSearch";
      contentString.add(beforeSearchContent);
    }
    String onSuggestSelectContent = "OnSuggestSelect = " + editString + "SuggestSelect";
    contentString.add(onSuggestSelectContent);
    return contentString;
  }

  /**
   * readPASFile is to read PAS file and check whether content exists already.
   * 
   * @param pluginRecordEntity
   * @param parametersMap
   * @param resultLog
   * @param suggestSelectContents
   * @param logReportEntity
   * @param isBackupChecked
   * @param backupFolderName
   */
  private void readPASFile(PluginRecordEntity pluginRecordEntity, Map<String, Set<String>> parametersMap,
      List<String> resultLog, List<String> suggestSelectContents, LogReportEntity logReportEntity,
      boolean isBackupChecked, String backupFolderName) {
    String filePath = pluginRecordEntity.getPasFilePath();
    String editString = pluginRecordEntity.getEditName();
    File pasFilePath = new File(filePath);
    String contentCheck = "procedure " + editString + "SuggestSelect";
    AtomicBoolean contentCheckFlag = new AtomicBoolean(false);
    if (!pasFilePath.exists()) {
      return;
    }
    List<String> pasFileLines = FileReadUtils.readFileLinesAndCheckContent(pasFilePath, contentCheckFlag, "",
        contentCheck);
    logReportEntity.setPasFile(pasFilePath.toString());
    if (!contentCheckFlag.get()) {
      writePASFile(pasFileLines, pluginRecordEntity, parametersMap, resultLog, suggestSelectContents, logReportEntity,
          isBackupChecked, backupFolderName);
    } else {
      logReportEntity.setPasFileChanged("NO");
      resultLog.add("\nPAS FILE CHANGES : Content is already present. PAS File " + pasFilePath + " is not changed.");
    }
  }

  /**
   * writePASFile is to write the Suggest Plugin related contents into PAS file
   * 
   * @param pasFileContents
   * @param pluginRecordEntity
   * @param parametersMap
   * @param resultLog
   * @param suggestSelectContents
   * @param logReportEntity
   * @param isBackupChecked
   * @param backupFolderName
   */
  private void writePASFile(List<String> pasFileContents, PluginRecordEntity pluginRecordEntity,
      Map<String, Set<String>> parametersMap, List<String> resultLog, List<String> suggestSelectContents,
      LogReportEntity logReportEntity, boolean isBackupChecked, String backupFolderName) {
    String filePath = pluginRecordEntity.getPasFilePath();
    String editString = pluginRecordEntity.getEditName();
    String sqlTag = pluginRecordEntity.getSqlTag();
    File pasFilePath = new File(filePath);
    List<String> suggestSelectCopy = new ArrayList<>(suggestSelectContents);
    logReportEntity.setPasFile(pasFilePath.toString());
    logReportEntity.setPasFileChanged("NO");
    String folderPath = CommonMethodUtils.getFolderPathFromPasFile(pluginRecordEntity.getPasFilePath(),
        pluginRecordEntity.getRepository());
    if (isBackupChecked) {
      CommonMethodUtils.backupFile(backupFolderName, pasFilePath.toString(), folderPath, pasFilePath);
    }
    List<String> methodDeclarationContent = makeMethodDeclarationPart(editString, parametersMap, sqlTag,
        suggestSelectCopy);
    List<String> methodDefinitionContent = makeMethodDefinitionPart(editString, parametersMap, sqlTag,
        getTypeName(pasFileContents), suggestSelectCopy);
    if (FileReadUtils.writePASFile(pasFilePath, pasFileContents, methodDeclarationContent, methodDefinitionContent)) {
      logReportEntity.setPasFileChanged("YES");
      resultLog.add("\nPAS File Changes : " + filePath + " has been changed.");
    }
  }

  /**
   * makeMethodDeclarationPart is to make the suggest Plugin related method
   * declaration
   * 
   * @param editString
   * @param parametersMap
   * @param sqlTag
   * @param suggestSelectContents
   * @return
   */
  private List<String> makeMethodDeclarationPart(String editString, Map<String, Set<String>> parametersMap,
      String sqlTag, List<String> suggestSelectContents) {
    int declarationstartindex = suggestSelectContents.indexOf("//METHOD DECLARATION");
    int declarationendindex = suggestSelectContents.indexOf("//METHOD DEFINITION");
    List<String> declarationContent = new ArrayList<>();
    if (parametersMap.containsKey(sqlTag) && !parametersMap.get(sqlTag).isEmpty()) {
      declarationContent = suggestSelectContents.subList(declarationstartindex + 1, declarationendindex);
    } else {
      declarationContent = suggestSelectContents.subList(declarationstartindex + 3, declarationendindex);
    }
    for (int iterator = 0; iterator < declarationContent.size(); iterator++) {
      if (declarationContent.get(iterator).contains("FIELDNAME")) {
        String formattedContent = declarationContent.get(iterator).replaceAll("FIELDNAME", editString);
        declarationContent.set(iterator, formattedContent);
      }
    }
    return declarationContent;
  }

  /**
   * makeMethodDefinitionPart is to make the Suggest Plugin related method content
   * 
   * @param editString
   * @param parametersMap
   * @param sqlTag
   * @param typeName
   * @param suggestSelectContents
   * @return
   */
  private List<String> makeMethodDefinitionPart(String editString, Map<String, Set<String>> parametersMap,
      String sqlTag, String typeName, List<String> suggestSelectContents) {
    int definitionstartindex = suggestSelectContents.indexOf("//METHOD DEFINITION");
    int definitionendindex = suggestSelectContents.indexOf("//METHOD DEFINITION END");
    int suggestSelectStartIndex = suggestSelectContents.indexOf("//##SUGGESTSELECT");
    List<String> definitionContent = new ArrayList<>();
    if (parametersMap.containsKey(sqlTag) && !parametersMap.get(sqlTag).isEmpty()) {
      definitionContent = suggestSelectContents.subList(definitionstartindex + 1, definitionendindex);
    } else {
      definitionContent = suggestSelectContents.subList(suggestSelectStartIndex + 1, definitionendindex);
    }
    for (int iterator = 0; iterator < definitionContent.size(); iterator++) {
      if (definitionContent.get(iterator).contains("FIELDNAME")) {
        String formattedContent = definitionContent.get(iterator).replaceAll("FIELDNAME", editString);
        definitionContent.set(iterator, formattedContent);
      }
      if (definitionContent.get(iterator).contains("CLASSNAME")) {
        String formattedContent = definitionContent.get(iterator).replaceAll("CLASSNAME", typeName);
        definitionContent.set(iterator, formattedContent);
      }
    }
    return definitionContent;
  }

  /**
   * getTypeName is to get the type name of PAS File.
   * 
   * @param pasFileLines
   * @return
   */
  private String getTypeName(List<String> pasFileLines) {
    String className = StringUtils.EMPTY;
    for (String line : pasFileLines) {
      if (RegularExpressionConstants.TYPE_NAME_MATCHER_REGEX.matcher(line).find()) {
        className = line.split("= class")[0];
        className = className.replaceAll(" ", "");
        break;
      }
    }
    return className;
  }

}
