package plugintool.plugintool;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.bson.Document;

import plugintool.dao.PluginGeneratorDao;
import plugintool.plugintool.consts.PluginGenerationConstants;
import plugintool.plugintool.consts.RegularExpressionConstants;
import plugintool.plugintool.converter.QueryBuilder;
import plugintool.plugintool.entity.LogReportEntity;
import plugintool.plugintool.entity.PluginRecordEntity;
import plugintool.plugintool.entity.QueryBuilderEntity;
import plugintool.utils.CommonMethodUtils;
import plugintool.utils.FileReadUtils;
import plugintool.utils.WorkSheetUtils;

public class PluginGeneratorService {

  PluginGeneratorDao pluginGeneratorDao = new PluginGeneratorDao();

  SuggestPluginFileWriteService suggestPluginWrite = new SuggestPluginFileWriteService();

  QueryBuilder queryBuilder = new QueryBuilder();

  ClassLoader classLoader = this.getClass().getClassLoader();

  List<String> resultLog = new ArrayList<>();

  List<PluginRecordEntity> pluginRecordEntityList = new ArrayList<>();

  List<LogReportEntity> logReportEntityList = new ArrayList<>();

  Map<String, LogReportEntity> logReportEntityMap = new HashMap<>();

  Map<String, Set<String>> parametersMap = new HashMap<>();

  List<String> pluginFileLines = new ArrayList<>();

  List<String> registerFileLines = new ArrayList<>();

  List<String> xmlRegisterfileLines = new ArrayList<>();

  Set<String> sqlTagSet = new HashSet<>();

  Set<String> processedSqlTagSet = new HashSet<>();

  InputStream SOCIAL_PLUGIN_TEMPLATE_PATH = classLoader.getResourceAsStream("SocialPluginGeneral.txt");

  InputStream SOCIAL_PLUGIN_XML_TEMPLATE_PATH = classLoader.getResourceAsStream("socialPlugin.txt");

  InputStream SUGGEST_PLUGIN_XML_TEMPLATE_PATH = classLoader.getResourceAsStream("suggestPlugin.txt");

  InputStream SOCIAL_PLUGIN_REGISTER_TEMPLATE_PATH = classLoader.getResourceAsStream("SocialPluginRegisterGeneral.txt");

  InputStream SUGGEST_PLUGIN_REGSITER_TEMPLATE_PATH = classLoader
      .getResourceAsStream("SuggestPluginRegisterGeneral.txt");

  InputStream SUGGEST_PLUGIN_TEMPLATE_PATH = classLoader.getResourceAsStream("SuggestPluginGeneral.txt");

  InputStream SUGGEST_PLUGIN_PAS_TEMPLATE_PATH = classLoader.getResourceAsStream("SuggestPluginPasTemplate.txt");

  String productDirectory = StringUtils.EMPTY;

  String subDirectory = StringUtils.EMPTY;

  private static final SimpleDateFormat dateFormat = new SimpleDateFormat(PluginGenerationConstants.BACKUP_DATE_FROMAT);

  public List<String> startPluginGenerator(String inputFilePath, String sqlTag, String componentName,
      String pasFilePath, boolean isManualInput, boolean isSuggest, boolean isBackupChecked) {
    makePluginRecordEntityAndSqlTagSet(inputFilePath, sqlTag, componentName, pasFilePath, isManualInput, isSuggest);
    if (CollectionUtils.isEmpty(sqlTagSet)) {
      resultLog.add(PluginGenerationConstants.NO_SQL_TAG_FOUND_MESSAGE);
      return resultLog;
    }
    findSqlTagFile(sqlTagSet);
    readTemplateFileLinesContent(isSuggest);
    Calendar calendar = Calendar.getInstance();
    String currentDateAndTime = dateFormat.format(calendar.getTime());
    String backupfolderName = PluginGenerationConstants.BACKUP_PREFIX + currentDateAndTime;
    for (PluginRecordEntity pluginRecordEntity : pluginRecordEntityList) {
      LogReportEntity logReportEntity = new LogReportEntity();
      logReportEntity.setSqlTag(pluginRecordEntity.getSqlTag());
      logReportEntity.setEditString(pluginRecordEntity.getEditName());
      logReportEntity = createFilesForPlugin(pluginRecordEntity, isSuggest, isBackupChecked, logReportEntity,
          backupfolderName);
      if (isSuggest) {
        suggestPluginWrite.addSuggestPluginContents(pluginRecordEntity, parametersMap, resultLog, productDirectory,
            subDirectory, logReportEntity, isBackupChecked, backupfolderName);
      }
      logReportEntityList.add(logReportEntity);
    }
    return resultLog;
  }

  /**
   * makePluginRecordEntityAndSqlTagSet is to form PluginRecordEntityList &
   * SqlTagSet
   * 
   * @param inputFilePath
   * @param sqlTag
   * @param componentName
   * @param pasFilePath
   * @param isManualInput
   * @param isSuggest
   */
  private void makePluginRecordEntityAndSqlTagSet(String inputFilePath, String sqlTag, String componentName,
      String pasFilePath, boolean isManualInput, boolean isSuggest) {
    File inputFile = new File(inputFilePath);
    sqlTagSet = isManualInput ? makeSqlTagFromManualInput(sqlTag, componentName, pasFilePath)
        : makeSqlTagFromFile(inputFile, isSuggest);
  }

  /**
   * makeSqlTagFromFile is to get SQL Tag from input file
   * 
   * @param inputFilePath
   * @param isSuggest
   * @return
   */
  private Set<String> makeSqlTagFromFile(File inputFilePath, boolean isSuggest) {
    Set<String> sqlTagSet = new HashSet<>();
    try (FileInputStream fileInputStream = new FileInputStream(inputFilePath)) {
      Workbook inputWorksheet;
      inputWorksheet = WorkbookFactory.create(fileInputStream);
      int readStartRow = 2;
      Sheet sheet = inputWorksheet.getSheet(PluginGenerationConstants.INPUT_FILE_SHEET);
      for (int counter = readStartRow; counter < sheet.getLastRowNum(); counter++) {
        Row row = sheet.getRow(counter);
        if (Objects.isNull(row)) {
          break;
        }
        pluginRecordEntityList
            .add(PluginRecordEntity.builder().editName(WorkSheetUtils.getStringValue(row.getCell(3)).trim())
                .sqlTag(WorkSheetUtils.getStringValue(row.getCell(2)).trim())
                .pasFilePath(WorkSheetUtils.getStringValue(row.getCell(4)).trim()).build());
        sqlTagSet.add(WorkSheetUtils.getStringValue(row.getCell(2)).trim());
      }
      return sqlTagSet;
    } catch (EncryptedDocumentException | IOException e) {
      resultLog.add(System.lineSeparator() + e.getMessage());
      e.printStackTrace();
    }
    return sqlTagSet;
  }

  /**
   * makeSqlTagFromManualInput is to get SQL TAG from user input
   * 
   * @param sqlTag
   * @param componentName
   * @param pasFilePath
   * @return
   */
  private Set<String> makeSqlTagFromManualInput(String sqlTag, String componentName, String pasFilePath) {
    pluginRecordEntityList.add(PluginRecordEntity.builder().editName(componentName.trim()).sqlTag(sqlTag.trim())
        .pasFilePath(pasFilePath.trim()).build());
    Set<String> sqlTagSet = new HashSet<>();
    sqlTagSet.add(sqlTag.trim());
    return sqlTagSet;
  }

  /**
   * makeSqlTagFileMap is to get SQL Files for SQL TAG
   * 
   * @param sqlTagSet
   */
  private void findSqlTagFile(Set<String> sqlTagSet) {
    pluginRecordEntityList.stream().forEach(entity -> {
      Map<String, String> filter = new HashMap<>();
      filter.put("_id", entity.getSqlTag());
      List<Document> documentList = pluginGeneratorDao.getDocumentsList(PluginGenerationConstants.DATABASE_NAME,
          PluginGenerationConstants.SQL_TAG_MAPPER_COLLECTION_NAME, filter, PluginGenerationConstants.FIELD_LIST);
      List<String> fileList = documentList.isEmpty() ? new ArrayList<>()
          : (List<String>) documentList.get(0).get(PluginGenerationConstants.SQL_TAG_FILE_COLUMN_NAME);
      entity.setSqlFilePath(fileList);
    });
  }

  /**
   * createFilesForPlugin method is to create all Plugin Related Files
   * 
   * @param pluginRecordEntity
   * @param isSuggest
   * @param isBackupChecked
   * @param logReportEntity
   * @param backupFolderName
   */
  private LogReportEntity createFilesForPlugin(PluginRecordEntity pluginRecordEntity, boolean isSuggest,
      boolean isBackupChecked, LogReportEntity logReportEntity, String backupFolderName) {
    if (Objects.isNull(pluginRecordEntity.getSqlFilePath()) || pluginRecordEntity.getSqlFilePath().isEmpty()) {
      logReportEntity.setSqlFile(PluginGenerationConstants.SQL_FILE_NOT_FOUND_MESSAGE);
      resultLog.add(PluginGenerationConstants.DOTTED_LINES);
      resultLog.add(System.lineSeparator() + PluginGenerationConstants.SQL_TAG + pluginRecordEntity.getSqlTag());
      resultLog.add(System.lineSeparator() + PluginGenerationConstants.SQL_FILE
          + PluginGenerationConstants.SQL_FILE_NOT_FOUND_MESSAGE);
      return logReportEntity;
    }
    File sqlFile = getSqlFileFromEntity(pluginRecordEntity);
    String sqlTag = pluginRecordEntity.getSqlTag();
    Map<String, String> filesNameMap = makeFilesName(sqlFile, pluginRecordEntity, isSuggest);
    pluginRecordEntity.setPluginId(filesNameMap.get(PluginGenerationConstants.PLUGIN_ID));
    logReportEntity.setSqlFile(sqlFile.toString());
    logReportEntity.setPluginId(filesNameMap.get(PluginGenerationConstants.PLUGIN_ID));
    resultLog.add(PluginGenerationConstants.DOTTED_LINES);
    resultLog.add(System.lineSeparator() + PluginGenerationConstants.SQL_TAG + sqlTag);
    resultLog.add(System.lineSeparator() + PluginGenerationConstants.SQL_FILE + sqlFile);
    if (processedSqlTagSet.contains(sqlTag)) {
      LogReportEntity processedSqlEntity = logReportEntityMap.get(sqlTag);
      logReportEntity = new LogReportEntity(processedSqlEntity);
      logReportEntity.setEditString(pluginRecordEntity.getEditName());
      resultLog.add(System.lineSeparator() + PluginGenerationConstants.DUPLICATE_SQL_TAG_MESSAGE);
      return logReportEntity;
    }
    processedSqlTagSet.add(sqlTag);
    makePluginFile(filesNameMap, isSuggest, sqlTag, sqlFile, logReportEntity);
    makeRegisterEntry(filesNameMap, isSuggest, isBackupChecked, logReportEntity, backupFolderName);
    checkXmlRegisterFile(filesNameMap, isSuggest, isBackupChecked, logReportEntity, backupFolderName);
    logReportEntityMap.put(sqlTag, logReportEntity);
    return logReportEntity;
  }

  /**
   * getLogOutputResult is to get the LogOutputResultList
   * 
   * @return
   */
  public List<LogReportEntity> getLogOutputResult() {
    return logReportEntityList;
  }

  /**
   * makeLogReport is to generate the log report file
   * 
   * @param logReportList
   */
  public void makeLogReport(List<LogReportEntity> logReportList) {
    InputStream templatePath = classLoader.getResourceAsStream(PluginGenerationConstants.OUTPUT_FILE_TEMPLATE);
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
    String today = dateFormat.format(calendar.getTime());
    FileOutputStream outputStream = null;
    String outputpath = PluginGenerationConstants.BACKUP_FILE_DIRECTORY + "\\PluginToolResult_" + today
        + PluginGenerationConstants.XLS_FILE_EXTENSION;
    try {
      FileUtils.copyInputStreamToFile(templatePath,
          new File(outputpath + PluginGenerationConstants.WORKBOOK_EXTENSION));
      File wkFile = new File(outputpath + PluginGenerationConstants.WORKBOOK_EXTENSION);
      Workbook book = WorkbookFactory.create(wkFile);
      Sheet logSheet = book.getSheet(PluginGenerationConstants.LOG_REPORT_SHEET);
      writeLogResult(book, logSheet, logReportList);
      book.setForceFormulaRecalculation(true);
      outputStream = new FileOutputStream(outputpath);
      book.write(outputStream);
      book.close();
      wkFile.delete();
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        outputStream.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  /**
   * makeFilesName is to form the file name for all Plugin files
   * 
   * @param sqlFile
   * @param pluginRecordEntity
   * @param isSuggest
   * @return
   */
  private Map<String, String> makeFilesName(File sqlFile, PluginRecordEntity pluginRecordEntity, boolean isSuggest) {
    Map<String, String> fileNameMap = new HashMap<>();
    StringBuilder pluginRegisterFileName = new StringBuilder();
    StringBuilder pluginFileName = new StringBuilder();
    StringBuilder pluginIdContent = new StringBuilder();
    StringBuilder pluginId = new StringBuilder();
    String sqlTag = pluginRecordEntity.getSqlTag();
    productDirectory = sqlFile.getPath().split(PluginGenerationConstants.COMPANY_AC)[1]
        .split(RegularExpressionConstants.FILE_SEPERATOR_REGEX)[1];
    subDirectory = sqlFile.getPath().split(PluginGenerationConstants.COMPANY_AC)[1]
        .split(RegularExpressionConstants.FILE_SEPERATOR_REGEX)[2];
    String repository = pluginRecordEntity.getRepository();
    String folderPath = CommonMethodUtils.getFolderPathFromPasFile(pluginRecordEntity.getPasFilePath(), repository);
    String module = subDirectory.contains(PluginGenerationConstants.DOT_CHARACTER) ? productDirectory
        : (productDirectory + PluginGenerationConstants.DOT_CHARACTER + subDirectory);
    String pluginDirectory = folderPath + PluginGenerationConstants.FILE_SEPERATOR + repository
        + PluginGenerationConstants.PLUGIN_FOLDER_PATH + PluginGenerationConstants.FILE_SEPERATOR + module.replaceAll(
            RegularExpressionConstants.DOT_CHARACTER_REGEX, RegularExpressionConstants.FILE_SEPERATOR_REGEX);
    if (!new File(pluginDirectory).exists()) {
      new File(pluginDirectory).mkdirs();
    }
    List<String> fileName = Arrays.asList(sqlTag.split(RegularExpressionConstants.DOT_CHARACTER_REGEX));
    for (int i = 0; i < fileName.size(); i++) {
      Arrays.asList(fileName.get(i).split("_"))
          .forEach(word -> pluginFileName.append(WordUtils.capitalize(word.toLowerCase())));
    }
    pluginIdContent.append(module.toUpperCase());
    pluginIdContent.append(PluginGenerationConstants.DOT_CHARACTER);
    pluginIdContent.append(sqlTag);
    pluginId.append(module.toUpperCase());
    pluginId.append(PluginGenerationConstants.DOT_CHARACTER);
    pluginId.append(formatSqlTag(sqlTag));
    pluginRegisterFileName.append(WordUtils.capitalize(productDirectory.toLowerCase()));
    if (!subDirectory.contains(PluginGenerationConstants.DOT_CHARACTER)) {
      pluginRegisterFileName.append(WordUtils.capitalize(subDirectory.toLowerCase()));
    }
    if (isSuggest) {
      pluginFileName.append(PluginGenerationConstants.SUGGEST_PLUGIN_FILE_SUFFIX);
      pluginRegisterFileName.append(PluginGenerationConstants.SUGGEST_PLUGIN_REGISTER_FILE_SUFFIX);
    } else {
      pluginFileName.append(PluginGenerationConstants.SOCIAL_PLUGIN_FILE_SUFFIX);
      pluginRegisterFileName.append(PluginGenerationConstants.SOCIAL_PLUGIN_REGISTER_FILE_SUFFIX);
    }
    fileNameMap.put(PluginGenerationConstants.PLUGIN_FILE_NAME, pluginFileName.toString());
    fileNameMap.put(PluginGenerationConstants.PLUGIN_REGISTER_FILE_NAME, pluginRegisterFileName.toString());
    fileNameMap.put(PluginGenerationConstants.PLUGIN_DIRECTORY, pluginDirectory);
    fileNameMap.put(PluginGenerationConstants.MODULE, module.toUpperCase());
    fileNameMap.put(PluginGenerationConstants.PLUGIN_ID_CONTENT, pluginIdContent.toString());
    fileNameMap.put(PluginGenerationConstants.PLUGIN_ID, pluginId.toString());
    fileNameMap.put(PluginGenerationConstants.FOLDER_PATH, folderPath);
    return fileNameMap;
  }

  /**
   * makePluginFile is to create and update the plugin Files
   * 
   * @param fileNameMap
   * @param isSuggest
   * @param sqlTag
   * @param sqlFile
   * @param logReportEntity
   */
  private void makePluginFile(Map<String, String> fileNameMap, boolean isSuggest, String sqlTag, File sqlFile,
      LogReportEntity logReportEntity) {
    List<String> pluginFileLinesCopy = new ArrayList<>(pluginFileLines);
    String pluginDirectory = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_DIRECTORY, StringUtils.EMPTY);
    String pluginFileName = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_FILE_NAME, StringUtils.EMPTY);
    File pluginFilePath = new File(pluginDirectory + PluginGenerationConstants.FILE_SEPERATOR + pluginFileName);
    logReportEntity.setPluginFile(pluginFilePath.toString());
    QueryBuilderEntity queryBuilderEntity = new QueryBuilderEntity();
    Map<String, String> queryContentMap = new HashMap<>();
    if (pluginFilePath.exists()) {
      if (isSuggest) {
        makeParametersMapFromExistingFile(sqlTag, pluginFilePath);
      }
      logReportEntity.setPluginFileCreated("NO");
      resultLog.add(CommonMethodUtils.getFileAlreadyPresentMessage(pluginFilePath));
      return;
    }
    try {
      pluginFilePath.createNewFile();
      logReportEntity.setPluginFileCreated("YES");
      if (isSuggest) {
        List<String> queryResult = queryBuilder.parseQuery(sqlFile, sqlTag);
        queryBuilderEntity = queryBuilder.getQueryBuilderEntity(queryResult, sqlTag);
        queryContentMap = makeQueryContent(queryBuilderEntity, sqlTag);
      }
      BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(pluginFilePath));
      int jpIndex = pluginDirectory.indexOf("jp");
      String packageName = pluginDirectory.substring(jpIndex)
          .replaceAll(RegularExpressionConstants.FILE_SEPERATOR_REGEX, PluginGenerationConstants.DOT_CHARACTER);
      for (String fileLine : pluginFileLinesCopy) {
        try {
          if (fileLine.contains(PluginGenerationConstants.PACKAGE_NAME_KEYWORD)) {
            fileLine = fileLine.replace(PluginGenerationConstants.PACKAGE_NAME_KEYWORD, packageName);
          }
          if (fileLine.contains(PluginGenerationConstants.CLASS_NAME_KEYWORD)) {
            fileLine = fileLine.replace(PluginGenerationConstants.CLASS_NAME_KEYWORD,
                pluginFileName.split(PluginGenerationConstants.JAVA_EXTENSION)[0]);
          }
          if (isSuggest) {
            if (ignoreConditionInPluginFile(queryContentMap, queryBuilderEntity, fileLine)) {
              continue;
            }
            fileLine = updateQueryForSuggestPlugin(fileLine, queryBuilderEntity, queryContentMap);
          }
          bufferedWriter.write(fileLine);
          bufferedWriter.newLine();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
      bufferedWriter.close();
      resultLog.add(CommonMethodUtils.getFileCreatedMessage(pluginFilePath));
    } catch (IOException e) {
      resultLog.add(System.lineSeparator() + e.getMessage());
      e.printStackTrace();
    }
  }

  /**
   * ignoreConditionInPluginFile is to check whether fileLine need to ignore.
   * 
   * @param queryContentMap
   * @param queryBuilderEntity
   * @param fileLine
   * @return
   */
  private boolean ignoreConditionInPluginFile(Map<String, String> queryContentMap,
      QueryBuilderEntity queryBuilderEntity, String fileLine) {
    if (queryBuilderEntity.getArgumentMap().isEmpty()
        && (fileLine.contains(PluginGenerationConstants.ARGUMENTS_KEYWORD))) {
      return true;
    }
    if (queryContentMap.get(PluginGenerationConstants.WHERE_CLAUSE).isEmpty()
        && (fileLine.contains(PluginGenerationConstants.CONCAT_KEYWORD)
            || fileLine.contains(PluginGenerationConstants.CONDITION_KEYWORD))) {
      return true;
    }
    if (queryContentMap.get(PluginGenerationConstants.WHERE_CONDITION_KEY_CLAUSE).isEmpty()
        && (fileLine.contains(PluginGenerationConstants.KEYS_KEYWORD))) {
      return true;
    }
    if (queryContentMap.get(PluginGenerationConstants.FROM_CONDITION_KEY_CLAUSE).isEmpty()
        && (fileLine.contains(PluginGenerationConstants.FROM_CLAUSE_VALUES_KEYWORD))) {
      return true;
    }
    if (queryBuilderEntity.getFromClauseKeyMap().isEmpty() && queryBuilderEntity.getConditionClauseKeyMap().isEmpty()
        && (fileLine.contains(PluginGenerationConstants.PARAMETERS_KEYWORD))) {
      return true;
    }
    return false;
  }

  /**
   * makeQueryContent is to form the queryContent from queryBuilderEntity
   * 
   * @param queryBuilderEntity
   * @param sqlTag
   * @return
   */
  private Map<String, String> makeQueryContent(QueryBuilderEntity queryBuilderEntity, String sqlTag) {
    String fromClause = StringUtils.EMPTY;
    String whereClause = StringUtils.EMPTY;
    String whereConditionkeyClause = StringUtils.EMPTY;
    String fromConditionKeyClause = StringUtils.EMPTY;
    StringBuilder parameter = new StringBuilder();
    String keyParameter = makeParameterForOptionalValue(queryBuilderEntity);
    if (!queryBuilderEntity.getFromClauseList().isEmpty()) {
      fromClause = String.join(PluginGenerationConstants.SPACE, queryBuilderEntity.getFromClauseList());
    }
    if (!queryBuilderEntity.getConditionClauseList().isEmpty()) {
      String commaAppendedList = String.join(PluginGenerationConstants.SPACE,
          queryBuilderEntity.getConditionClauseList());
      whereClause = PluginGenerationConstants.queryKeyWords.contains(queryBuilderEntity.getConditionClauseList().get(0))
          ? commaAppendedList
          : "AND " + commaAppendedList;
    }
    if (!queryBuilderEntity.getConditionClauseKeyMap().isEmpty()) {
      Set<String> sqlTagKeySet = new HashSet<>();
      if (parametersMap.containsKey(sqlTag)) {
        sqlTagKeySet = parametersMap.get(sqlTag);
      }
      sqlTagKeySet.addAll(queryBuilderEntity.getConditionClauseKeyMap().keySet());
      parametersMap.put(sqlTag, sqlTagKeySet);
      String commaAppendedList = String.join(" + ", queryBuilderEntity.getConditionClauseKeyMap().keySet());
      whereConditionkeyClause = "+ " + commaAppendedList;
    }
    if (!queryBuilderEntity.getFromClauseKeyMap().isEmpty()) {
      Set<String> sqlTagKeySet = new HashSet<>();
      if (parametersMap.containsKey(sqlTag)) {
        sqlTagKeySet = parametersMap.get(sqlTag);
      }
      sqlTagKeySet.addAll(queryBuilderEntity.getFromClauseKeyMap().keySet());
      parametersMap.put(sqlTag, sqlTagKeySet);
      String commaAppendedList = String.join(" + ", queryBuilderEntity.getFromClauseKeyMap().keySet());
      fromConditionKeyClause = "+ " + commaAppendedList;
    }
    if (!queryBuilderEntity.getArgumentMap().isEmpty()) {
      Set<String> sqlTagKeySet = new HashSet<>();
      if (parametersMap.containsKey(sqlTag)) {
        sqlTagKeySet = parametersMap.get(sqlTag);
      }
      sqlTagKeySet.addAll(queryBuilderEntity.getArgumentMap().keySet());
      parametersMap.put(sqlTag, sqlTagKeySet);
      queryBuilderEntity.getArgumentMap().entrySet().forEach(param -> {
        parameter.append(PluginGenerationConstants.COMMA_DELIMITER);
        parameter.append("param(\"" + param.getKey() + "\", parameters.get(\"" + param.getKey() + "\")" + "."
            + findDataTypeMethod(param.getValue()) + ")");
      });
    }
    Map<String, String> queryContentMap = new HashMap<>();
    queryContentMap.put(PluginGenerationConstants.FROM_CLAUSE, fromClause);
    queryContentMap.put(PluginGenerationConstants.WHERE_CLAUSE, whereClause);
    queryContentMap.put(PluginGenerationConstants.WHERE_CONDITION_KEY_CLAUSE, whereConditionkeyClause);
    queryContentMap.put(PluginGenerationConstants.FROM_CONDITION_KEY_CLAUSE, fromConditionKeyClause);
    queryContentMap.put(PluginGenerationConstants.KEY_PARAMETER, keyParameter);
    queryContentMap.put(PluginGenerationConstants.PARAMETER, parameter.toString());
    return queryContentMap;
  }

  /**
   * updateQueryForSuggestPlugin is to replace original query content in template.
   * 
   * @param fileLine
   * @param queryBuilderEntity
   * @param queryContentMap
   * @return
   */
  private String updateQueryForSuggestPlugin(String fileLine, QueryBuilderEntity queryBuilderEntity,
      Map<String, String> queryContentMap) {

    if (fileLine.contains(PluginGenerationConstants.TABLENAME_KEYWORD)) {
      return fileLine.replace(PluginGenerationConstants.TABLENAME_KEYWORD,
          queryContentMap.get(PluginGenerationConstants.FROM_CLAUSE));
    }
    if (fileLine.contains(PluginGenerationConstants.FROM_CLAUSE_VALUES_KEYWORD)) {
      return fileLine.replace(PluginGenerationConstants.FROM_CLAUSE_VALUES_KEYWORD,
          queryContentMap.get(PluginGenerationConstants.FROM_CONDITION_KEY_CLAUSE));
    }
    if (fileLine.contains(PluginGenerationConstants.KEYS_KEYWORD)) {
      return fileLine.replace(PluginGenerationConstants.KEYS_KEYWORD,
          queryContentMap.get(PluginGenerationConstants.WHERE_CONDITION_KEY_CLAUSE));
    }
    if (fileLine.contains(PluginGenerationConstants.ARGUMENTS_KEYWORD)) {
      return fileLine.replace(PluginGenerationConstants.ARGUMENTS_KEYWORD,
          queryContentMap.get(PluginGenerationConstants.PARAMETER));
    }
    if (fileLine.contains("//") && fileLine.contains(PluginGenerationConstants.CODE_COLUMNS_KEYWORD)) {
      return fileLine.replace(PluginGenerationConstants.CODE_COLUMNS_KEYWORD, String
          .join(PluginGenerationConstants.COMMA_DELIMITER, queryBuilderEntity.getCodeAndNameColumnMap().get("code")));
    }
    if (fileLine.contains("//") && fileLine.contains(PluginGenerationConstants.NAME_COLUMNS_KEYWORD)) {
      return fileLine.replace(PluginGenerationConstants.NAME_COLUMNS_KEYWORD, String
          .join(PluginGenerationConstants.COMMA_DELIMITER, queryBuilderEntity.getCodeAndNameColumnMap().get("name")));
    }
    if (fileLine.contains(PluginGenerationConstants.PARAMETERS_KEYWORD)) {
      return queryContentMap.get(PluginGenerationConstants.KEY_PARAMETER);
    }
    if (fileLine.contains(PluginGenerationConstants.CONDITION_KEYWORD)) {
      fileLine = fileLine.replace(PluginGenerationConstants.CONDITION_KEYWORD,
          "\"" + queryContentMap.get(PluginGenerationConstants.WHERE_CLAUSE) + "\"");
    }
    if (fileLine.contains(PluginGenerationConstants.CONCAT_KEYWORD)
        && !queryContentMap.get(PluginGenerationConstants.WHERE_CLAUSE).isEmpty()) {
      return fileLine.replace(PluginGenerationConstants.CONCAT_KEYWORD, "+");
    }
    return fileLine;
  }

  /**
   * makeRegisterEntry is to register the plugin in the PluginRegister File
   * 
   * @param fileNameMap
   * @param isSuggest
   * @param isBackupChecked
   * @param logReportEntity
   * @param backupFolderName
   */
  private void makeRegisterEntry(Map<String, String> fileNameMap, boolean isSuggest, boolean isBackupChecked,
      LogReportEntity logReportEntity, String backupFolderName) {
    List<String> registerFileLinesCopy = new ArrayList<>(registerFileLines);
    String pluginDirectory = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_DIRECTORY, StringUtils.EMPTY);
    String pluginFileName = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_FILE_NAME, StringUtils.EMPTY);
    String pluginId = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_ID, StringUtils.EMPTY);
    String folderPath = fileNameMap.getOrDefault(PluginGenerationConstants.FOLDER_PATH, StringUtils.EMPTY);
    String pluginRegisterFileName = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_REGISTER_FILE_NAME,
        StringUtils.EMPTY);
    File pluginRegisterFile = new File(
        pluginDirectory + PluginGenerationConstants.FILE_SEPERATOR + pluginRegisterFileName);
    String newContents = "\t\tregister(\"" + pluginId + "\"," + System.lineSeparator() + "\t\t\t\t"
        + pluginFileName.toString().split(PluginGenerationConstants.JAVA_EXTENSION)[0]
        + PluginGenerationConstants.CLASS_EXTENSION + ");";
    logReportEntity.setPluginJavaRegisterFile(pluginRegisterFile.toString());
    try {
      if (!pluginRegisterFile.exists()) {
        createPluginRegisterFile(pluginRegisterFile, registerFileLinesCopy,
            RegularExpressionConstants.JAVA_REGISTER_FILE_END_MATCHER, newContents, pluginDirectory,
            pluginRegisterFileName);
        logReportEntity.setPluginJavaRegisterFileCreated("YES");
        resultLog.add(CommonMethodUtils.getFileCreatedandRegisteredMessage(pluginRegisterFile, pluginFileName));
      } else {
        if (overwritePluginRegisterFile(pluginRegisterFile, RegularExpressionConstants.JAVA_REGISTER_FILE_END_MATCHER,
            newContents, pluginDirectory, pluginFileName, isBackupChecked, backupFolderName, folderPath)) {
          logReportEntity.setPluginJavaRegisterFileChanged("YES");
          resultLog.add(CommonMethodUtils.getFileRegisteredMessage(pluginRegisterFile, pluginFileName));
        } else {
          logReportEntity.setPluginJavaRegisterFileChanged("NO");
          resultLog.add(CommonMethodUtils.getFileAlreadyRegisteredMessage(pluginRegisterFile, pluginFileName));
        }
      }
    } catch (IOException e) {
      resultLog.add(System.lineSeparator() + e.getMessage());
      e.printStackTrace();
    }
  }

  /**
   * createPluginRegisterFile is to create the Plugin Java Register File
   * 
   * @param pluginRegisterFile
   * @param registerFileLinesCopy
   * @param regexPattern
   * @param newContents
   * @param pluginDirectory
   * @param pluginRegisterFileName
   * @throws IOException
   */
  private void createPluginRegisterFile(File pluginRegisterFile, List<String> registerFileLinesCopy,
      Pattern regexPattern, String newContents, String pluginDirectory, String pluginRegisterFileName)
      throws IOException {
    pluginRegisterFile.createNewFile();
    List<String> modifiedFileLines = new ArrayList<>();
    registerFileLinesCopy.forEach(line -> {
      if (line.contains(PluginGenerationConstants.PACKAGE_NAME_KEYWORD)) {
        int index = pluginDirectory.indexOf("jp");
        String packageName = pluginDirectory.substring(index)
            .replaceAll(RegularExpressionConstants.FILE_SEPERATOR_REGEX, PluginGenerationConstants.DOT_CHARACTER);
        modifiedFileLines.add(line.replace(PluginGenerationConstants.PACKAGE_NAME_KEYWORD, packageName));
      } else if (line.contains(PluginGenerationConstants.CLASS_NAME_KEYWORD)) {
        modifiedFileLines.add(line.replace(PluginGenerationConstants.CLASS_NAME_KEYWORD,
            pluginRegisterFileName.toString().split(PluginGenerationConstants.JAVA_EXTENSION)[0]));
      } else {
        modifiedFileLines.add(line);
      }
    });
    if (!(modifiedFileLines.contains(newContents))) {
      FileReadUtils.writeRegisterFile(modifiedFileLines, newContents, pluginRegisterFile, regexPattern);
    }
  }

  /**
   * overwritePluginRegisterFile is to append content in Plugin Java Register File
   * 
   * @param pluginRegisterFile
   * @param regexPattern
   * @param newContents
   * @param pluginDirectory
   * @param pluginFileName
   * @param isBackupChecked
   * @param backupFolderName
   * @param folderPath
   * @return
   * @throws IOException
   */
  private boolean overwritePluginRegisterFile(File pluginRegisterFile, Pattern regexPattern, String newContents,
      String pluginDirectory, String pluginFileName, boolean isBackupChecked, String backupFolderName,
      String folderPath) throws IOException {
    List<String> fileLines = FileUtils.readLines(pluginRegisterFile, PluginGenerationConstants.FILE_ENCODING);
    AtomicBoolean contentPresent = new AtomicBoolean(false);
    fileLines.forEach(line -> {
      if (line.contains(pluginFileName.toString().split(PluginGenerationConstants.JAVA_EXTENSION)[0])) {
        contentPresent.set(true);
        return;
      }
    });
    if (!contentPresent.get()) {
      if (isBackupChecked) {
        CommonMethodUtils.backupFile(backupFolderName, pluginDirectory, folderPath, pluginRegisterFile);
      }
      FileReadUtils.writeRegisterFile(fileLines, newContents, pluginRegisterFile, regexPattern);
      return true;
    }
    return false;
  }

  /**
   * checkXmlRegisterFile is to register pluginRegister File in Plugin XML file
   * 
   * @param fileNameMap
   * @param isSuggest
   * @param isBackupChecked
   * @param logReportEntity
   * @param backupfolderName
   */
  private void checkXmlRegisterFile(Map<String, String> fileNameMap, boolean isSuggest, boolean isBackupChecked,
      LogReportEntity logReportEntity, String backupfolderName) {
    List<String> xmlRegisterFileLinesCopy = new ArrayList<>(xmlRegisterfileLines);
    String pluginDirectory = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_DIRECTORY, StringUtils.EMPTY);
    String folderPath = fileNameMap.getOrDefault(PluginGenerationConstants.FOLDER_PATH, StringUtils.EMPTY);
    String registerXmlDirectory = folderPath + PluginGenerationConstants.FILE_SEPERATOR
        + PluginGenerationConstants.REGISTER_XML_FILE_PATH;
    String pluginRegisterFileName = fileNameMap.getOrDefault(PluginGenerationConstants.PLUGIN_REGISTER_FILE_NAME,
        StringUtils.EMPTY);
    String module = fileNameMap.getOrDefault(PluginGenerationConstants.MODULE, StringUtils.EMPTY);
    File pluginRegisterDirectory = new File(registerXmlDirectory);
    if (!pluginRegisterDirectory.exists()) {
      pluginRegisterDirectory.mkdirs();
    }
    String pluginXmlFileSuffix = isSuggest ? PluginGenerationConstants.SUGGEST_PLUGIN_XML_SUFFIX
        : PluginGenerationConstants.SOCIAL_PLUGIN_XML_SUFFIX;
    File pluginXmlFile = new File(
        registerXmlDirectory + PluginGenerationConstants.FILE_SEPERATOR + pluginXmlFileSuffix);
    String pluginRegisterFilePath = pluginDirectory + PluginGenerationConstants.FILE_SEPERATOR + pluginRegisterFileName;
    int index = pluginRegisterFilePath.indexOf("jp");
    String formattedPluginRegisterFilePath = pluginRegisterFilePath.substring(index)
        .split(PluginGenerationConstants.JAVA_EXTENSION)[0];
    String maincontents = formattedPluginRegisterFilePath.replaceAll(RegularExpressionConstants.FILE_SEPERATOR_REGEX,
        PluginGenerationConstants.DOT_CHARACTER);
    String newContents = "\t<register id=\"" + module + "\">" + System.lineSeparator() + maincontents + "</register>";
    logReportEntity.setPluginXmlRegisterFile(pluginXmlFile.toString());
    try {
      if (!pluginXmlFile.exists()) {
        pluginXmlFile.createNewFile();
        logReportEntity.setPluginXmlRegisterFileCreated("YES");
        FileReadUtils.writeRegisterFile(xmlRegisterFileLinesCopy, newContents, pluginXmlFile,
            RegularExpressionConstants.XML_REGISTER_FILE_END_MATCHER);
        resultLog.add(CommonMethodUtils.getFileCreatedandRegisteredMessage(pluginXmlFile, module));
      } else {
        List<String> fileLines = FileUtils.readLines(pluginXmlFile, PluginGenerationConstants.FILE_ENCODING);
        AtomicBoolean contentPresent = new AtomicBoolean(false);
        fileLines.forEach(line -> {
          if (line.contains(module)) {
            contentPresent.set(true);
            return;
          }
        });
        if (!contentPresent.get()) {
          if (isBackupChecked) {
            CommonMethodUtils.backupFile(backupfolderName, pluginXmlFile.toString(), folderPath, pluginXmlFile);
          }
          FileReadUtils.writeRegisterFile(fileLines, newContents, pluginXmlFile,
              RegularExpressionConstants.XML_REGISTER_FILE_END_MATCHER);
          logReportEntity.setPluginXmlRegisterFileChanged("YES");
          resultLog.add(CommonMethodUtils.getFileRegisteredMessage(pluginXmlFile, module));
        } else {
          logReportEntity.setPluginXmlRegisterFileChanged("NO");
          resultLog.add(CommonMethodUtils.getFileAlreadyRegisteredMessage(pluginXmlFile, module));
        }
      }
    } catch (IOException e) {
      resultLog.add(System.lineSeparator() + e.getMessage());
      e.printStackTrace();
    }
  }

  /**
   * writeLogResult is to write log into Report File
   * 
   * @param book
   * @param logSheet
   * @param logReportEntityList
   */
  private void writeLogResult(Workbook book, Sheet logSheet, List<LogReportEntity> logReportEntityList) {
    int currentRowIndex = 2;
    for (LogReportEntity entity : logReportEntityList) {
      Row currentRow = logSheet.getRow(currentRowIndex);
      if (currentRow == null) {
        currentRow = WorkSheetUtils.addRowWithStyle(logSheet, currentRowIndex - 1, currentRowIndex, 0, 18);
      }
      int serialNumber = currentRowIndex - 1;
      WorkSheetUtils.setRowItems(entity, currentRow, book, serialNumber);
      currentRowIndex++;
    }
  }

  /**
   * makeParameterForOptionalValue is to get the parameter value from map for
   * optional Keys in Query.
   * 
   * @param queryBuilderEntity
   * @return
   */
  private String makeParameterForOptionalValue(QueryBuilderEntity queryBuilderEntity) {
    StringBuilder fileLine = new StringBuilder();
    Map<String, String> argumentAndDataTypeMap = new HashMap<>();
    argumentAndDataTypeMap.putAll(queryBuilderEntity.getFromClauseKeyMap());
    argumentAndDataTypeMap.putAll(queryBuilderEntity.getConditionClauseKeyMap());
    argumentAndDataTypeMap.entrySet().forEach(map -> {
      String variableNameForArgument = map.getKey();
      if (map.getKey().contains(PluginGenerationConstants.DOT_CHARACTER)) {
        variableNameForArgument = map.getKey().split(RegularExpressionConstants.DOT_CHARACTER_REGEX)[1];
      }
      variableNameForArgument = formatVarName(variableNameForArgument);
      if (queryBuilderEntity.getConditionClauseKeyMap().containsKey(map.getKey())) {
        Map<String, String> conditionalClauseKeyMap = queryBuilderEntity.getConditionClauseKeyMap();
        String datatype = conditionalClauseKeyMap.get(map.getKey());
        conditionalClauseKeyMap.remove(map.getKey());
        conditionalClauseKeyMap.put(variableNameForArgument, datatype);
        queryBuilderEntity.setConditionClauseKeyMap(conditionalClauseKeyMap);
      }
      if (queryBuilderEntity.getFromClauseKeyMap().containsKey(map.getKey())) {
        Map<String, String> fromClauseMap = queryBuilderEntity.getFromClauseKeyMap();
        String datatype = fromClauseMap.get(map.getKey());
        fromClauseMap.remove(map.getKey());
        fromClauseMap.put(variableNameForArgument, datatype);
        queryBuilderEntity.setFromClauseKeyMap(fromClauseMap);
      }
      fileLine.append("\t\tString " + variableNameForArgument + " = parameters.containsKey(\"" + map.getKey()
          + "\")? \"AND " + map.getKey() + "= \" + parameters.get(\"" + map.getKey() + "\")."
          + findDataTypeMethod(map.getValue()) + " : StringUtils.EMPTY;");
      fileLine.append(System.lineSeparator());
    });
    return fileLine.toString();
  }

  /**
   * readTemplateFileLinesContent is to read Generic Templates file
   * 
   * @param isSuggest
   */
  private void readTemplateFileLinesContent(boolean isSuggest) {
    pluginFileLines = isSuggest ? FileReadUtils.readFile(SUGGEST_PLUGIN_TEMPLATE_PATH)
        : FileReadUtils.readFile(SOCIAL_PLUGIN_TEMPLATE_PATH);
    registerFileLines = isSuggest ? FileReadUtils.readFile(SUGGEST_PLUGIN_REGSITER_TEMPLATE_PATH)
        : FileReadUtils.readFile(SOCIAL_PLUGIN_REGISTER_TEMPLATE_PATH);
    xmlRegisterfileLines = isSuggest ? FileReadUtils.readFile(SUGGEST_PLUGIN_XML_TEMPLATE_PATH)
        : FileReadUtils.readFile(SOCIAL_PLUGIN_XML_TEMPLATE_PATH);
  }

  /**
   * findDataTypeMethod is to find the datatype method
   * 
   * @param license
   * @return
   */
  private String findDataTypeMethod(String datatype) {
    switch (datatype) {
    case "INT":
      return "integerValue()";
    case "LONG":
      return "longValue()";
    case "DOUBLE":
      return "doubleValue()";
    default:
      return "stringValue()";
    }
  }

  /**
   * formatVarName is to format the variable Name from argument
   * 
   * @param varName
   * @return
   */
  private String formatVarName(String varName) {
    StringBuilder formattedName = new StringBuilder();
    List<String> varNameList = Arrays.asList(varName.split(RegularExpressionConstants.UNDERSCORE_REGEX));
    varNameList.forEach(name -> formattedName.append(WordUtils.capitalize(name.toLowerCase())));
    return WordUtils.uncapitalize(formattedName.toString());
  }

  /**
   * formatSqlTag is to find the pluginId
   * 
   * @param sqlTag
   * @return
   */
  private String formatSqlTag(String sqlTag) {
    StringBuilder formatSqlTag = new StringBuilder();
    Arrays.asList(sqlTag.split(RegularExpressionConstants.DOT_CHARACTER_REGEX)).forEach(sql -> {
      formatSqlTag.append(sql);
      formatSqlTag.append("_");
    });
    return formatSqlTag.substring(0, formatSqlTag.length() - 1).toString();
  }

  /**
   * makeParametersMapFromExistingFile is to check whether the parameter is passed
   * or not in query of existing plugin files.
   * 
   * @param sqlTag
   * @param pluginFile
   */
  private void makeParametersMapFromExistingFile(String sqlTag, File pluginFile) {
    String methodDefinition = "public SqlKeyParameter keywordSql";
    StringBuilder fourthParameterOfKeywordSal = new StringBuilder();
    String fourthArgumentNameInKeywordSql = StringUtils.EMPTY;
    boolean isMethodStarted = false;
    boolean isParametersPresent = false;
    try {
      List<String> fileLines = FileReadUtils.readFile(pluginFile);
      for (int iterator = 0; iterator < fileLines.size(); iterator++) {
        if (fileLines.get(iterator).contains(methodDefinition)) {
          isMethodStarted = true;
        }
        if (isMethodStarted && fileLines.get(iterator).contains("Map<String, Parameter>")) {
          while (!fileLines.get(iterator).contains(")")) {
            fourthParameterOfKeywordSal.append(fileLines.get(iterator).trim());
            iterator++;
          }
          fourthParameterOfKeywordSal.append(fileLines.get(iterator).trim());
          fourthArgumentNameInKeywordSql = fourthParameterOfKeywordSal.toString().split("Map<String, Parameter>")[1];
          fourthArgumentNameInKeywordSql = fourthArgumentNameInKeywordSql.split("\\)")[0].trim();
        }
        if (isMethodStarted && fileLines.get(iterator).contains(fourthArgumentNameInKeywordSql + ".get(")) {
          isParametersPresent = true;
          break;
        }
        if (isMethodStarted && fileLines.get(iterator).contains("}")) {
          isMethodStarted = false;
        }
      }
      if (isParametersPresent) {
        Set<String> argumentSet = new HashSet<>();
        argumentSet.add("CORP_ID");
        parametersMap.put(sqlTag, argumentSet);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * getSqlFileFromEntity is to select appropriate sqlFile for sqlTag
   * 
   * @param pluginRecordEntity
   * @return
   */
  private File getSqlFileFromEntity(PluginRecordEntity pluginRecordEntity) {
    List<String> sqlFilesPath = pluginRecordEntity.getSqlFilePath();
    String repositoryName = getRepoFromPasFile(pluginRecordEntity.getPasFilePath());
    String module = getModuleFromPasFile(pluginRecordEntity.getPasFilePath());
    pluginRecordEntity.setRepository(repositoryName);
    repositoryName = repositoryName.contains("hue-ac-chennai-") ? repositoryName.split("hue-ac-chennai-")[1]
        : repositoryName;
    File sqlFile = new File(StringUtils.EMPTY);
    for (String filepath : sqlFilesPath) {
      if (filepath.split(PluginGenerationConstants.COMPANY_AC)[1]
          .split(RegularExpressionConstants.FILE_SEPERATOR_REGEX)[1].equalsIgnoreCase(repositoryName)) {
        return new File(filepath);
      } else {
        if (filepath.split(PluginGenerationConstants.COMPANY_AC)[1]
            .split(RegularExpressionConstants.FILE_SEPERATOR_REGEX)[1].equalsIgnoreCase(module)) {
          sqlFile = new File(filepath);
        }
      }
    }
    return sqlFile.isFile() ? sqlFile : new File(sqlFilesPath.stream().findFirst().get());
  }

  /**
   * getRepoFromPasFile is to find the Repository Name from PAS file
   * 
   * @param pasFilePath
   * @return
   */
  private String getRepoFromPasFile(String pasFilePath) {
    List<String> pasFilePathList = Arrays.asList(pasFilePath.split(PluginGenerationConstants.LINE_SEPERATOR_SPLITTER));
    int hueClientIndex = pasFilePathList.indexOf(PluginGenerationConstants.HUE_CLIENT);
    String repo = (hueClientIndex > 0) ? pasFilePathList.get(hueClientIndex - 1) : StringUtils.EMPTY;
    return repo;
  }

  /**
   * getModuleFromPasFile is to get the module name from PAS file
   * 
   * @param pasFilePath
   * @return
   */
  private String getModuleFromPasFile(String pasFilePath) {
    List<String> pasFilePathList = Arrays.asList(pasFilePath.split(PluginGenerationConstants.LINE_SEPERATOR_SPLITTER));
    int hueClientIndex = pasFilePathList.indexOf(PluginGenerationConstants.HUE_CLIENT);
    String module = (hueClientIndex != -1) ? pasFilePathList.get(hueClientIndex + 2) : StringUtils.EMPTY;
    return module;
  }

}
