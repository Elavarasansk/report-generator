package plugintool.plugintool.entity;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PluginRecordEntity {
  private String fileName;
  private String editName;
  private String pluginId;
  private String sqlTag;
  private String pasFilePath;
  private String listOrDetail;
  private String repository;
  private List<String> sqlFilePath;
}
