package plugintool.plugintool.entity;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class QueryBuilderEntity {

  /* fromClauseList contains query between from and where Clause */
  private List<String> fromClauseList;

  /* conditionClauseList contains query between where Clause and argument phase */
  private List<String> conditionClauseList;

  /*
   * fromClauseKeyMap contains OptionalValues like {SEG_NO_INT1} and its datatype
   * present in from Clause
   */
  private Map<String, String> fromClauseKeyMap;
  
  /*
   * conditionClauseKeyMap contains OptionalValues like {SEG_NO_INT1} and its
   * datatype present in where Clause
   */
  private Map<String, String> conditionClauseKeyMap;
  
  /* argumentMap contains arguments and its datatype */
  private Map<String, String> argumentMap;

  /* codeAndNameColumnMap contains code and Name column List for suggestion */
  private Map<String, List<String>> codeAndNameColumnMap;
}
