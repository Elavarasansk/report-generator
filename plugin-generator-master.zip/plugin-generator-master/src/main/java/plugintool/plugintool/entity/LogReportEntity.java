package plugintool.plugintool.entity;

import lombok.Data;

@Data
public class LogReportEntity {

  private String sqlTag;
  private String editString;
  private String pluginId;
  private String sqlFile;
  private String pluginFile;
  private String pluginFileCreated;
  private String pluginJavaRegisterFile;
  private String pluginJavaRegisterFileCreated;
  private String pluginJavaRegisterFileChanged;
  private String pluginXmlRegisterFile;
  private String pluginXmlRegisterFileCreated;
  private String pluginXmlRegisterFileChanged;
  private String dfmFile;
  private String dfmFileChanged;
  private String pasFile;
  private String pasFileChanged;

  public LogReportEntity() {
    this.sqlTag = "-";
    this.sqlFile = "-";
    this.editString = "-";
    this.pluginId = "-";
    this.dfmFile = "-";
    this.dfmFileChanged = "NO";
    this.pasFile = "-";
    this.pasFileChanged = "NO";
    this.pluginFile = "-";
    this.pluginFileCreated = "NO";
    this.pluginJavaRegisterFile = "-";
    this.pluginJavaRegisterFileChanged = "NO";
    this.pluginJavaRegisterFileCreated = "NO";
    this.pluginXmlRegisterFile = "-";
    this.pluginXmlRegisterFileChanged = "NO";
    this.pluginXmlRegisterFileCreated = "NO";
  }

  public LogReportEntity(LogReportEntity entity) {
    this.sqlTag = entity.getSqlTag();
    this.sqlFile = entity.getSqlFile();
    this.pluginId = entity.getPluginId();
    this.pluginFile = entity.getPluginFile();
    this.pluginFileCreated = entity.getPluginFileCreated();
    this.pluginJavaRegisterFile = entity.getPluginJavaRegisterFile();
    this.pluginJavaRegisterFileChanged = entity.getPluginJavaRegisterFileChanged();
    this.pluginJavaRegisterFileCreated = entity.getPluginJavaRegisterFileCreated();
    this.pluginXmlRegisterFile = entity.getPluginXmlRegisterFile();
    this.pluginXmlRegisterFileChanged = entity.getPluginXmlRegisterFileChanged();
    this.pluginXmlRegisterFileCreated = entity.getPluginXmlRegisterFileCreated();
  }

}
