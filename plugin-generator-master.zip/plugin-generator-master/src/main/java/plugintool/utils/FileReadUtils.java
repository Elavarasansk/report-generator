package plugintool.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import plugintool.plugintool.consts.PluginGenerationConstants;

public class FileReadUtils {

  private FileReadUtils() {
  }

  public static List<String> readFile(File file) throws IOException {
    return readFile(new FileInputStream(file), "UTF-8");
  }

  public static List<String> readFile(InputStream inputStreamFile) {
    return readFile(inputStreamFile, "UTF-8");
  }

  public static List<String> readFile(File file, String enc) throws IOException {
    return readFile(new FileInputStream(file), enc);
  }

  public static List<String> readFile(InputStream inputStreamFile, String enc) {
    List<String> fileLines = new ArrayList<>();
    String line;
    try (BufferedReader inputFile = new BufferedReader(new InputStreamReader(inputStreamFile, enc))) {
      while ((line = inputFile.readLine()) != null) {
        fileLines.add(line);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return fileLines;
  }

  public static void copyFile(String directory, File srcfile) {
    File dest_directory = new File(directory);
    if (!dest_directory.exists()) {
      dest_directory.mkdirs();
    }
    File dest_directory_file = new File(dest_directory + "\\" + srcfile.getName());
    if (!dest_directory_file.exists()) {
      try {
        dest_directory_file.createNewFile();
        FileUtils.copyFile(srcfile, dest_directory_file);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  public static String getFileExtension(File file) {
    String name = file.getName();
    int lastIndexOf = name.lastIndexOf(".");
    if (lastIndexOf == -1) {
      return "";
    }
    return name.substring(lastIndexOf);
  }

  /**
   * writeRegisterFile is to write the contents into file
   * 
   * @param fileLines
   * @param newContents
   * @param pluginRegisterFile
   * @param regexPattern
   */
  public static void writeRegisterFile(List<String> fileLines, String newContents, File pluginRegisterFile,
      Pattern regexPattern) {
    AtomicBoolean writtenFlag = new AtomicBoolean(false);
    BufferedWriter bufferedWriter;
    try {
      bufferedWriter = new BufferedWriter(new FileWriter(pluginRegisterFile));
      fileLines.forEach(fileLine -> {
        try {
          Matcher linesMatcher = regexPattern.matcher(fileLine);
          if (linesMatcher.find() && !writtenFlag.get()) {
            bufferedWriter.write(newContents);
            bufferedWriter.newLine();
            writtenFlag.set(true);
          }
          bufferedWriter.write(fileLine);
          bufferedWriter.newLine();
        } catch (IOException e) {
          e.printStackTrace();
        }
      });
      bufferedWriter.close();
    } catch (IOException e1) {
      e1.printStackTrace();
    }
  }

  /**
   * readFileLinesAndCheckContent is to read file Lines & check content already
   * exists
   * 
   * @param inputFile
   * @param contentPresentFlag
   * @param regexPattern
   * @param content
   * @return
   */
  public static List<String> readFileLinesAndCheckContent(File inputFile, AtomicBoolean contentPresentFlag,
      String regexPattern, String content) {
    List<String> fileLines = new ArrayList<>();
    try {
      BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), "MS932"));
      AtomicBoolean componentFlag = new AtomicBoolean(false);
      String line;
      while ((line = br.readLine()) != null) {
        if (line.contains(regexPattern) || StringUtils.isEmpty(regexPattern)) {
          componentFlag.set(true);
        }
        if (componentFlag.get() && line.contains(content)) {
          contentPresentFlag.set(true);
        }
        if (componentFlag.get() && !contentPresentFlag.get() && line.contains("end")
            && StringUtils.isNotEmpty(regexPattern)) {
          componentFlag.set(false);
        }
        fileLines.add(line);
      }
      br.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return fileLines;
  }

  /**
   * writeDFM file is to write the content into DFM File
   * 
   * @param filePath
   * @param fileLines
   * @param contents
   * @param regexPattern
   * @param imeModeRegex
   * @return
   */
  public static boolean writeDFMFile(File filePath, List<String> fileLines, List<String> contents, String regexPattern,
      String imeModeRegex) {
    String imeModeString = "ImeMode = imDisable";
    boolean imeModeFlag = false;
    boolean writtenFlag = false;
    try {
      BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath), "MS932"));
      AtomicBoolean componentFlag = new AtomicBoolean(false);
      StringBuilder whiteSpace = new StringBuilder("  ");
      for (String line : fileLines) {
        if (line.contains(regexPattern)) {
          whiteSpace.append(getWhiteSpace(line));
          componentFlag.set(true);
        }
        if (line.contains(imeModeRegex)) {
          imeModeFlag = true;
        }
        if (componentFlag.get() && imeModeFlag && line.contains(imeModeString)) {
          continue;
        }
        if (componentFlag.get() && line.contains("end")) {
          for (String lineContent : contents) {
            bw.write(whiteSpace + lineContent);
            bw.newLine();
          }
          writtenFlag = true;
          componentFlag.set(false);
        }
        bw.write(line);
        bw.newLine();
      }
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return writtenFlag;
  }

  /**
   * writePASFile file is to write the content into PAS File
   * 
   * @param filePath
   * @param fileContents
   * @param methodDeclarationContent
   * @param methodDefinitionContent
   * @return
   */
  public static boolean writePASFile(File filePath, List<String> fileContents, List<String> methodDeclarationContent,
      List<String> methodDefinitionContent) {
    boolean writtenFlag = false;
    boolean methodDeclarationStart = false;
    try {
      int lastindex = fileContents.lastIndexOf("end.");
      BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filePath), "MS932"));
      for (int iterator = 0; iterator < fileContents.size(); iterator++) {
        if (fileContents.get(iterator).equals("type")) {
          methodDeclarationStart = true;
        }
        if (methodDeclarationStart && PluginGenerationConstants.modifiers.contains(fileContents.get(iterator).trim())) {
          writtenFlag = true;
          for (String declarationContent : methodDeclarationContent) {
            try {
              bw.write(declarationContent);
              bw.newLine();
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
          methodDeclarationStart = false;
        }
        if (iterator == lastindex - 1) {
          for (String definition : methodDefinitionContent) {
            try {
              if (!PluginGenerationConstants.omittedcontentList.contains(definition)) {
                bw.write(definition);
                bw.newLine();
              }
            } catch (IOException e) {
              e.printStackTrace();
            }
          }
        }
        bw.write(fileContents.get(iterator));
        bw.newLine();
      }
      bw.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return writtenFlag;
  }

  /**
   * getWhiteSpace is to get the leading whitespace of the given string
   * 
   * @param string
   * @return
   */
  private static String getWhiteSpace(String input) {
    input = input.toLowerCase();
    StringBuilder sb = new StringBuilder();
    int i = 0;
    while (i < input.length() && !(input.charAt(i) >= 97 && input.charAt(i) <= 123)) {
      sb.append(input.charAt(i));
      i++;
    }
    return sb.toString();
  }

}
