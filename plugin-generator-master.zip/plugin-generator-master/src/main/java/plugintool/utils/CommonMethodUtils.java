package plugintool.utils;

import java.io.File;

import org.apache.commons.lang3.StringUtils;

import plugintool.plugintool.consts.PluginGenerationConstants;
import plugintool.plugintool.consts.RegularExpressionConstants;

public class CommonMethodUtils {

  private CommonMethodUtils() {
  }

  public static String getFileCreatedMessage(File fileName) {
    return System.lineSeparator() + "File " + fileName + PluginGenerationConstants.FILE_CREATED_MESSAGE;
  }

  public static String getFileAlreadyPresentMessage(File fileName) {
    return System.lineSeparator() + "File " + fileName + PluginGenerationConstants.FILE_ALREADY_PRESENT_MESSAGE;
  }

  public static String getFileCreatedandRegisteredMessage(File createdfileName, String registerFileName) {
    return System.lineSeparator() + "File " + createdfileName + " has been created  and " + registerFileName
        + " has been registered.";
  }

  public static String getFileRegisteredMessage(File fileName, String registerFileName) {
    return System.lineSeparator() + registerFileName + " has been registered in the File " + fileName
        + PluginGenerationConstants.DOT_CHARACTER;
  }

  public static String getFileAlreadyRegisteredMessage(File fileName, String registerFileName) {
    return System.lineSeparator() + registerFileName + " has  already registered in the File " + fileName
        + PluginGenerationConstants.DOT_CHARACTER;
  }

  public static String getFolderPathFromPasFile(String pasFilePath, String repo) {
    return pasFilePath.contains(repo) ? pasFilePath.split(RegularExpressionConstants.FILE_SEPERATOR_REGEX + repo)[0]
        : StringUtils.EMPTY;
  }

  public static String getDFmFileChangedMessage(String methodName, File fileName) {
    return System.lineSeparator() + "DFM File Changes : Method " + methodName + " has been changed in the DFM File "
        + fileName + PluginGenerationConstants.DOT_CHARACTER;
  }

  public static void backupFile(String backupFolderName, String directory, String folderPath, File originalFile) {
    FileReadUtils.copyFile(PluginGenerationConstants.BACKUP_FILE_DIRECTORY + PluginGenerationConstants.FILE_SEPERATOR
        + backupFolderName + directory.split(folderPath.replaceAll(RegularExpressionConstants.FILE_SEPERATOR_REGEX,
            RegularExpressionConstants.DOUBLE_SLASH_REGEX))[1],
        originalFile);
  }

}
