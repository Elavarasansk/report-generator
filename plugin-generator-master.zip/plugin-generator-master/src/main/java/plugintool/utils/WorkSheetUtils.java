package plugintool.utils;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import plugintool.plugintool.entity.LogReportEntity;

public class WorkSheetUtils {

  private WorkSheetUtils() {
  }

  public static Row addRowWithStyle(Sheet sheet, int originalRowIndex, int newRowIndex, int startCell, int endCell) {
    Row originalRow = sheet.getRow(originalRowIndex);
    Row newRow = createNewRowWithCell(sheet, newRowIndex, startCell, endCell);
    copyCellStyle(originalRow, newRow, startCell, endCell);
    return newRow;
  }

  public static Row createNewRowWithCell(Sheet sheet, int rowNum, int startCell, int endCell) {
    Row newRow = sheet.getRow(rowNum);
    if (Objects.isNull(newRow)) {
      newRow = sheet.createRow(rowNum);
    }
    for (int iterator = startCell; iterator <= endCell; iterator++) {
      if (Objects.isNull(newRow.getCell(iterator))) {
        newRow.createCell(iterator);
      }
    }
    return newRow;
  }

  public static void copyCellStyle(Row copyFrom, Row copyTo, int startCell, int endCell) {
    for (int iterator = startCell; iterator <= endCell; iterator++) {
      if (Objects.nonNull(copyFrom.getCell(iterator))) {
        copyTo.getCell(iterator).setCellStyle(copyFrom.getCell(iterator).getCellStyle());
        copyTo.getCell(iterator).setCellType(copyFrom.getCell(iterator).getCellType());
      }
    }
  }

  public static String getStringValue(Cell cell) {
    if (Objects.isNull(cell)) {
      return StringUtils.EMPTY;
    }
    switch (cell.getCellType()) {
    case NUMERIC:
      return Double.toString(cell.getNumericCellValue());
    case STRING:
      return cell.getStringCellValue();
    case FORMULA:
      Workbook wb = cell.getSheet().getWorkbook();
      CreationHelper crateHelper = wb.getCreationHelper();
      FormulaEvaluator evaluator = crateHelper.createFormulaEvaluator();
      return getStringValue(evaluator.evaluateInCell(cell));
    case BOOLEAN:
      return Boolean.toString(cell.getBooleanCellValue());
    case ERROR:
      return "ERROR";
    case BLANK:
    default:
      return StringUtils.EMPTY;
    }
  }

  public static void setRowItems(LogReportEntity logReportEntity, Row row, Workbook book, int serialNo) {
    row.setHeightInPoints((short) 50);
    row.getCell(1).setCellValue(serialNo);
    row.getCell(2).setCellValue(logReportEntity.getSqlTag());
    row.getCell(3).setCellValue(logReportEntity.getEditString());
    row.getCell(4).setCellValue(logReportEntity.getPluginId());
    row.getCell(5).setCellValue(logReportEntity.getSqlFile());
    row.getCell(6).setCellValue(logReportEntity.getPluginFile());
    row.getCell(7).setCellValue(logReportEntity.getPluginFileCreated());
    row.getCell(8).setCellValue(logReportEntity.getPluginJavaRegisterFile());
    row.getCell(9).setCellValue(logReportEntity.getPluginJavaRegisterFileCreated());
    row.getCell(10).setCellValue(logReportEntity.getPluginJavaRegisterFileChanged());
    row.getCell(11).setCellValue(logReportEntity.getPluginXmlRegisterFile());
    row.getCell(12).setCellValue(logReportEntity.getPluginXmlRegisterFileCreated());
    row.getCell(13).setCellValue(logReportEntity.getPluginXmlRegisterFileChanged());
    row.getCell(14).setCellValue(logReportEntity.getDfmFile());
    row.getCell(15).setCellValue(logReportEntity.getDfmFileChanged());
    row.getCell(16).setCellValue(logReportEntity.getPasFile());
    row.getCell(17).setCellValue(logReportEntity.getPasFileChanged());
  }

}
