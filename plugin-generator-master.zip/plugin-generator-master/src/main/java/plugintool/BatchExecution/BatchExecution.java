package plugintool.BatchExecution;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class BatchExecution {

  private static List<File> chennaiRepoFiles = new ArrayList<>();

  private static MongoClient mongoClient = new MongoClient("192.168.57.68", 27017);

  private static final String Chennai_Search_Repo_Path = "C:\\HUE\\Workspace\\Develop\\chennairesearch\\sqlfiles";

  private static Map<String, Set<String>> sqlTagFilesMap = new HashMap<String, Set<String>>();

  private static final String sqlTagRegex = "(.+)(\\^)(.*)";

  private static final String DATABASE_NAME = "intraweb-tools";

  private static final String TABLE_NAME = "sql-tag-mapper";

  private static final String SQL_TAG_COLUMN_NAME = "_id";

  private static final String SQL_FILE_COLUMN_NAME = "sql_tag_files";

  private static final String RESULT_MESSAGE = "SQL FILES INSERTED";

  public static void main(String[] args) {
    insertSqlTagMapper();
  }

  private static void insertSqlTagMapper() {
    String[] format = new String[1];
    format[0] = "sql";
    chennaiRepoFiles.addAll(FileUtils.listFiles(new File(Chennai_Search_Repo_Path), format, true));
    chennaiRepoFiles.stream().forEach(file -> {
      try {
        List<String> fileLines = FileUtils.readLines(file, "UTF-8");
        fileLines.stream().forEach(line -> {
          Pattern regex = Pattern.compile(sqlTagRegex);
          if (!line.contains("#") && regex.matcher(line).find()) {
            String formatSqlTag = line.split("\\^")[0];
            Set<String> sqlFileList = sqlTagFilesMap.containsKey(formatSqlTag) ? sqlTagFilesMap.get(formatSqlTag)
                : new HashSet<>();
            sqlFileList.add(file.toString());
            sqlTagFilesMap.put(formatSqlTag, sqlFileList);

          }
        });
      } catch (Exception e) {
        e.printStackTrace();
      }
    });
    List<Document> documentList = new ArrayList<>();
    sqlTagFilesMap.entrySet().stream().forEach(sqlTagMap -> {
      Document document = new Document();
      document.put(SQL_TAG_COLUMN_NAME, sqlTagMap.getKey());
      document.put(SQL_FILE_COLUMN_NAME, sqlTagMap.getValue());
      documentList.add(document);
    });
    if (!documentList.isEmpty()) {
      insert(documentList, TABLE_NAME);
    }
  }

  private static void insert(List<Document> documentList, String tableName) {

    MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);

    MongoCollection<Document> collection = database.getCollection(tableName);

    collection.drop();

    collection.insertMany(documentList);

    System.out.println(RESULT_MESSAGE);
  }

}
