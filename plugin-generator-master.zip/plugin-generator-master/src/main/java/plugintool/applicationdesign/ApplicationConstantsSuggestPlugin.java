package plugintool.applicationdesign;

import plugintool.plugintool.consts.PluginGenerationConstants;

public class ApplicationConstantsSuggestPlugin {

  public static final String PLUGIN_GENERATOR_TITLE = "Plugin Generator";

  public static final String INPUT_FILE_PATH = "FILE PATH";

  public static final String INPUT_TYPE = "Input Type";

  public static final String PLUGIN_TYPE = "Plugin Type";

  public static final String BACKUP = "Backup";

  public static final String FILE_INPUT = "File Input";

  public static final String MANUAL_INPUT = "Manual Input";

  public static final String LOG_OUTPUT = "Log Output";

  public static final String BACK_UP_CHECK_BOX = "Take Backup of Existing Files";

  public static final String SUGGEST_PLUGIN = "Suggest Plugin";

  public static final String SOCIAL_PLUGIN = "Social Plugin";

  public static final String SQL_TAG = "SQL TAG";

  public static final String PAS_FILE_PATH = "PAS FILE PATH";

  public static final String COMPONENT_NAME = "COMPONENT NAME";

  public static final String NOTE_LABEL = "NOTE :";

  public static final String EXECUTE = "EXECUTE";

  public static final String SUBMIT = "SUBMIT";

  public static final String FONT_STYLE = "Italian";

  public static final double MAXIMUM_FONT_SIZE = 15;

  public static final double MINIMUM_FONT_SIZE = 13;

  public static final String TEXTBOX_COLOR_CODE = "#000080";

  public static final String EXECUTION_STARTED_MESSAGE = "Execution Started.";

  public static final String EXECUTION_FINISHED_MESSAGE = "Execution Finished.";

  public static final String NO_CHANGES_MESSAGE = "No Changes.";

  public static final String INPUT_SCREEN_TITLE = "Input Screen";

  public static final String XLS_EXTENSION = ".xls";

  public static final String PAS_EXTENSION = ".pas";

  public static final String INFORMATION = "Information";

  public static final String WARNING = "Warning";

  public static final String DOWNLOAD_REPORT_ALERT_TITLE = "REPORT FILE GENERATED";

  public static final String BACKUP_INFO_DIALOG_TITLE = "BACK UP FILE INFORMATION";

  public static final String BACKUP_INFO_DIALOG_MAIN_CONTENT = "Files which are overwriting by the tool will be taken as backup";

  public static final String AUTOMATION_SUCESS_MESSAGE = "Plugin Automation Success";

  public static final String EMPTY_FILE_PATH_MESSAGE = "FILE PATH can not be empty";

  public static final String INVALID_FILE_FORMAT_MESSAGE = "File Format - Error";

  public static final String INVALID_FILE_FORMAT_CONTENT = "Please Input Valid .xls File";

  public static final String INVALID_FILE_PATH_MESSAGE = "File Not Found - Error";

  public static final String INVALID_FILE_PATH_CONTENT = "File does not exists in the specified location";

  public static final String EMPTY_SQLTAG_MESSAGE = "SQL TAG can not be empty";

  public static final String EMPTY_COMPONENT_NAME_MESSAGE = "COMPONENT NAME can not be empty";

  public static final String EMPTY_PAS_FILE_PATH_MESSAGE = "PAS FILE PATH can not be empty";

  public static final String INVALID_PAS_FILE_PATH_MESSAGE = "PAS File does not exists";

  public static final String INFORMATION_ICON = "Info_Icon.png";

  public static final String DOWNLOAD_ICON = "Download_Icon.jpg";

  public static final String FILE_PATH_PROMPT_TEXT = "C:\\HUE\\WORKSPACE\\DEVELOP\\hue-ac-chennai-cam\\hue_client\\delphi\\CAM\\sharing\\form\\frame\\fa\\search\\FaAssetSearchFrm.pas";

  public static final String NOTE_MESSAGE = "Developers need to clone \"Chennai Research\" Respository";

  public static final String DOWNLOAD_REPORT_ALERT_CONTENT = "LOG REPORT OUTPUT PATH :  "
      + PluginGenerationConstants.BACKUP_FILE_DIRECTORY;

  public static final String BACKUP_INFO_DIALOG_HEADER_CONTENT = "Backup Files will be generated in  "
      + PluginGenerationConstants.BACKUP_FILE_DIRECTORY;

  private ApplicationConstantsSuggestPlugin() {

  }

}
