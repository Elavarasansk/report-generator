package plugintool.applicationdesign;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import plugintool.plugintool.PluginGeneratorService;
import plugintool.plugintool.entity.LogReportEntity;

public class SuggestPluginDesign extends Application {

  private String inputFilePath = StringUtils.EMPTY;

  private String componentName = StringUtils.EMPTY;

  private String sqlTag = StringUtils.EMPTY;

  private String pasFilePath = StringUtils.EMPTY;

  private TextArea logOutputTextFiled = new TextArea();

  private List<LogReportEntity> logOutputResultList = new ArrayList<>();

  private boolean isBackupChecked = true;

  private boolean isSuggestPlugin = true;

  private boolean isManualInput = true;

  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage primaryStage) throws Exception {
    Scene scene = setSceneConfiguration();
    setPrimaryStageConfiguration(primaryStage, scene);
  }

  private Scene setSceneConfiguration() {
    GridPane suggestPluginGrid = new GridPane();
    setGridPaneConfiguration(suggestPluginGrid);
    Scene scene = new Scene(suggestPluginGrid, 800, 650);
    return scene;
  }

  private void setPrimaryStageConfiguration(Stage primaryStage, Scene scene) {
    primaryStage.setTitle(ApplicationConstantsSuggestPlugin.PLUGIN_GENERATOR_TITLE);
    primaryStage.setScene(scene);
    primaryStage.setResizable(false);
    primaryStage.show();
  }

  public void toggleGroupListener(ToggleGroup toggleGroup, String compareValue) {
    toggleGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
      RadioButton selectedRadioButton = (RadioButton) toggleGroup.getSelectedToggle();
      if (selectedRadioButton != null) {
        switch (selectedRadioButton.getId()) {
        case ApplicationConstantsSuggestPlugin.MANUAL_INPUT:
        case ApplicationConstantsSuggestPlugin.FILE_INPUT:
          isManualInput = selectedRadioButton.getText().equals(compareValue);
          break;
        case ApplicationConstantsSuggestPlugin.SUGGEST_PLUGIN:
        case ApplicationConstantsSuggestPlugin.SOCIAL_PLUGIN:
          isSuggestPlugin = selectedRadioButton.getText().equals(compareValue);
          break;
        }
      }
    });
  }

  public void checkBoxListener(CheckBox backUpCheckBox) {
    backUpCheckBox.selectedProperty().addListener((observable, oldValue, newValue) -> {
      isBackupChecked = backUpCheckBox.isSelected();
    });
  }

  public void textFieldListener(TextField textField) {
    textField.textProperty().addListener((observable, oldValue, newValue) -> {
      switch (textField.getId()) {
      case ApplicationConstantsSuggestPlugin.INPUT_FILE_PATH:
        inputFilePath = newValue;
        break;
      case ApplicationConstantsSuggestPlugin.SQL_TAG:
        sqlTag = newValue;
        break;
      case ApplicationConstantsSuggestPlugin.COMPONENT_NAME:
        componentName = newValue;
        break;
      case ApplicationConstantsSuggestPlugin.PAS_FILE_PATH:
        pasFilePath = newValue;
        break;
      }
    });
  }

  public void showAlertDialog(AlertType alertType, String title, String headerText) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(headerText);
    alert.show();
  }

  public void showAlertDialog(AlertType alertType, String title, String headerText, String contentText) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(headerText);
    alert.setContentText(contentText);
    alert.show();
  }

  public void downloadButtonListener(Button downloadButton) {
    downloadButton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        downloadReport();
      }

      private void downloadReport() {
        PluginGeneratorService pluginGeneratorService = new PluginGeneratorService();
        pluginGeneratorService.makeLogReport(logOutputResultList);
        showAlertDialog(AlertType.INFORMATION, ApplicationConstantsSuggestPlugin.DOWNLOAD_REPORT_ALERT_TITLE,
            ApplicationConstantsSuggestPlugin.DOWNLOAD_REPORT_ALERT_CONTENT);
      }
    });
  }

  public void detailButtonListener(Button detailButton) {
    detailButton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        showAlertDialog(AlertType.INFORMATION, ApplicationConstantsSuggestPlugin.BACKUP_INFO_DIALOG_TITLE,
            ApplicationConstantsSuggestPlugin.BACKUP_INFO_DIALOG_HEADER_CONTENT,
            ApplicationConstantsSuggestPlugin.BACKUP_INFO_DIALOG_MAIN_CONTENT);
      }
    });
  }

  public void submitButtonListener(Button submitButton) {
    submitButton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        logOutputTextFiled.setText(StringUtils.EMPTY);
        validation(inputFilePath, componentName, sqlTag, pasFilePath, isManualInput);
      }

      private void validation(String inputFilePath, String componentName, String sqlTag, String pasFilePath,
          boolean isManualInput) {
        boolean isValidateSuccess = !isManualInput ? fileInputValidation() : manualInputValidation();
        if (!isValidateSuccess) {
          return;
        }
        Stage stage = (Stage) submitButton.getScene().getWindow();
        stage.close();
        logOutputTextFiled
            .setText(ApplicationConstantsSuggestPlugin.EXECUTION_STARTED_MESSAGE + System.lineSeparator());
        PluginGeneratorService pluginGeneratorService = new PluginGeneratorService();
        List<String> resultLog = pluginGeneratorService.startPluginGenerator(inputFilePath, sqlTag, componentName,
            pasFilePath, isManualInput, isSuggestPlugin, isBackupChecked);
        logOutputResultList = pluginGeneratorService.getLogOutputResult();
        logOutputTextFiled.appendText(String.join(System.lineSeparator(), resultLog));
        if (resultLog.isEmpty()) {
          logOutputTextFiled.appendText(System.lineSeparator() + ApplicationConstantsSuggestPlugin.NO_CHANGES_MESSAGE);
        }
        logOutputTextFiled.appendText(System.lineSeparator() + System.lineSeparator()
            + ApplicationConstantsSuggestPlugin.EXECUTION_FINISHED_MESSAGE);

        showAlertDialog(AlertType.INFORMATION, ApplicationConstantsSuggestPlugin.INFORMATION,
            ApplicationConstantsSuggestPlugin.AUTOMATION_SUCESS_MESSAGE);
      }
    });
  }

  public void executeButtonListener(Button executeButton) {
    executeButton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        Button submitButton = new Button(ApplicationConstantsSuggestPlugin.SUBMIT);
        submitButton.setDefaultButton(true);
        submitButton.setFont(new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE,
            ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
        submitButtonListener(submitButton);

        GridPane inputPane = new GridPane();
        inputPane.setHgap(15);
        inputPane.setVgap(15);
        inputPane.setPadding(new Insets(20, 20, 20, 20));
        Scene secondScene = new Scene(inputPane, 850, 350);

        if (!isManualInput) {
          inputPane.add(getFileInputGridPane(), 0, 0);
        } else {
          inputPane.add(getManualInputGridPane(), 0, 0);
        }
        inputPane.add(submitButton, 0, 1);
        Stage newWindow = new Stage();
        newWindow.setTitle(ApplicationConstantsSuggestPlugin.INPUT_SCREEN_TITLE);
        newWindow.setScene(secondScene);
        newWindow.show();
      }
    });
  }

  private boolean fileInputValidation() {
    if (StringUtils.isBlank(inputFilePath)) {
      showAlertDialog(AlertType.WARNING, ApplicationConstantsSuggestPlugin.WARNING,
          ApplicationConstantsSuggestPlugin.EMPTY_FILE_PATH_MESSAGE);
      return false;
    }
    File inputFile = new File(inputFilePath);
    if (!inputFile.getAbsolutePath().contains(ApplicationConstantsSuggestPlugin.XLS_EXTENSION)) {
      showAlertDialog(AlertType.ERROR, ApplicationConstantsSuggestPlugin.INVALID_FILE_FORMAT_MESSAGE,
          ApplicationConstantsSuggestPlugin.INVALID_FILE_FORMAT_CONTENT);
      return false;
    }
    if (!inputFile.exists()) {
      showAlertDialog(AlertType.ERROR, ApplicationConstantsSuggestPlugin.INVALID_FILE_PATH_MESSAGE,
          ApplicationConstantsSuggestPlugin.INVALID_FILE_PATH_CONTENT);
      return false;
    }
    return true;
  }

  private boolean manualInputValidation() {
    if (StringUtils.isBlank(sqlTag)) {
      showAlertDialog(AlertType.WARNING, ApplicationConstantsSuggestPlugin.WARNING,
          ApplicationConstantsSuggestPlugin.EMPTY_SQLTAG_MESSAGE);
      return false;
    }
    if (StringUtils.isBlank(componentName)) {
      showAlertDialog(AlertType.WARNING, ApplicationConstantsSuggestPlugin.WARNING,
          ApplicationConstantsSuggestPlugin.EMPTY_COMPONENT_NAME_MESSAGE);
      return false;
    }
    if (StringUtils.isBlank(pasFilePath)) {
      showAlertDialog(AlertType.WARNING, ApplicationConstantsSuggestPlugin.WARNING,
          ApplicationConstantsSuggestPlugin.EMPTY_PAS_FILE_PATH_MESSAGE);
      return false;
    }
    File pasFile = new File(pasFilePath);
    if (!pasFile.exists() || !pasFile.getAbsolutePath().contains(ApplicationConstantsSuggestPlugin.PAS_EXTENSION)) {
      showAlertDialog(AlertType.WARNING, ApplicationConstantsSuggestPlugin.WARNING,
          ApplicationConstantsSuggestPlugin.INVALID_PAS_FILE_PATH_MESSAGE);
      return false;
    }
    return true;
  }

  private void setGridPaneConfiguration(GridPane suggestPluginGrid) {

    Button executeButton = new Button(ApplicationConstantsSuggestPlugin.EXECUTE);
    executeButton.setDefaultButton(true);
    executeButton.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
    executeButtonListener(executeButton);

    suggestPluginGrid.setPadding(new Insets(20, 20, 20, 20));
    suggestPluginGrid.setVgap(15);
    suggestPluginGrid.setHgap(5);
    suggestPluginGrid.add(getInputTypeGridPane(), 0, 0);
    suggestPluginGrid.add(getPluginTypeGridPane(), 0, 1);
    suggestPluginGrid.add(getBackupGridPane(), 0, 2);
    suggestPluginGrid.add(executeButton, 0, 3);
    suggestPluginGrid.add(getLogGridPane(), 0, 4);
    suggestPluginGrid.add(getNotesGridPane(), 0, 5);
  }

  private GridPane getInputTypeGridPane() {

    GridPane inputTypeGridPane = new GridPane();
    Label inputType = new Label(ApplicationConstantsSuggestPlugin.INPUT_TYPE);
    inputType.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    inputType.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    ToggleGroup togglegroup = new ToggleGroup();
    RadioButton manualInput = new RadioButton(ApplicationConstantsSuggestPlugin.MANUAL_INPUT);
    manualInput.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
    manualInput.setSelected(true);
    manualInput.setId(ApplicationConstantsSuggestPlugin.MANUAL_INPUT);
    manualInput.setToggleGroup(togglegroup);

    RadioButton fileInput = new RadioButton(ApplicationConstantsSuggestPlugin.FILE_INPUT);
    fileInput.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
    fileInput.setToggleGroup(togglegroup);
    fileInput.setId(ApplicationConstantsSuggestPlugin.FILE_INPUT);
    toggleGroupListener(togglegroup, ApplicationConstantsSuggestPlugin.MANUAL_INPUT);

    HBox hBox = new HBox();
    hBox.setSpacing(100);
    hBox.getChildren().add(manualInput);
    hBox.getChildren().add(fileInput);

    inputTypeGridPane.add(inputType, 0, 0);
    inputTypeGridPane.add(hBox, 0, 1);
    inputTypeGridPane.setHgap(5);
    inputTypeGridPane.setVgap(15);
    return inputTypeGridPane;
  }

  private GridPane getPluginTypeGridPane() {

    GridPane pluginTypeGridPane = new GridPane();
    Label pluginType = new Label(ApplicationConstantsSuggestPlugin.PLUGIN_TYPE);
    pluginType.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    pluginType.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    ToggleGroup toggleGroup = new ToggleGroup();
    RadioButton suggestPlugin = new RadioButton(ApplicationConstantsSuggestPlugin.SUGGEST_PLUGIN);
    suggestPlugin.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
    suggestPlugin.setSelected(true);
    suggestPlugin.setId(ApplicationConstantsSuggestPlugin.SUGGEST_PLUGIN);
    suggestPlugin.setToggleGroup(toggleGroup);

    RadioButton socialPlugin = new RadioButton(ApplicationConstantsSuggestPlugin.SOCIAL_PLUGIN);
    socialPlugin.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
    socialPlugin.setToggleGroup(toggleGroup);
    socialPlugin.setId(ApplicationConstantsSuggestPlugin.SOCIAL_PLUGIN);
    toggleGroupListener(toggleGroup, ApplicationConstantsSuggestPlugin.SUGGEST_PLUGIN);

    HBox hBox = new HBox();
    hBox.setSpacing(90);
    hBox.getChildren().add(suggestPlugin);
    hBox.getChildren().add(socialPlugin);

    pluginTypeGridPane.add(pluginType, 0, 0);
    pluginTypeGridPane.add(hBox, 0, 1);
    pluginTypeGridPane.setHgap(5);
    pluginTypeGridPane.setVgap(15);
    return pluginTypeGridPane;
  }

  private GridPane getBackupGridPane() {

    GridPane backupGridPane = new GridPane();

    Label backup = new Label(ApplicationConstantsSuggestPlugin.BACKUP);
    backup.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    backup.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    CheckBox backupCheckBox = new CheckBox(ApplicationConstantsSuggestPlugin.BACK_UP_CHECK_BOX);
    backupCheckBox.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MINIMUM_FONT_SIZE));
    backupCheckBox.setSelected(true);
    checkBoxListener(backupCheckBox);

    Image detailImage = new Image(
        this.getClass().getClassLoader().getResourceAsStream(ApplicationConstantsSuggestPlugin.INFORMATION_ICON), 20,
        20, false, false);
    Button detailButton = new Button();
    detailButton.setGraphic(new ImageView(detailImage));
    detailButtonListener(detailButton);

    backupGridPane.add(backup, 0, 0);
    backupGridPane.add(backupCheckBox, 0, 1);
    backupGridPane.add(detailButton, 1, 1);
    backupGridPane.setHgap(15);
    backupGridPane.setVgap(15);
    return backupGridPane;
  }

  private GridPane getLogGridPane() {

    GridPane logGridPane = new GridPane();

    Label logLabel = new Label(ApplicationConstantsSuggestPlugin.LOG_OUTPUT);
    logLabel.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    logLabel.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    Image imageDownload = new Image(
        this.getClass().getClassLoader().getResourceAsStream(ApplicationConstantsSuggestPlugin.DOWNLOAD_ICON), 30, 30,
        false, false);
    Button downloadButton = new Button();
    downloadButton.setGraphic(new ImageView(imageDownload));
    downloadButtonListener(downloadButton);

    logOutputTextFiled.setMinWidth(700);
    logOutputTextFiled.setMinHeight(250);
    logOutputTextFiled.setStyle("-fx-font-size: 11;-fx-font-weight: bold;");

    logGridPane.add(logLabel, 0, 0);
    logGridPane.add(downloadButton, 1, 0);
    logGridPane.add(logOutputTextFiled, 0, 1);
    logGridPane.setHgap(5);
    logGridPane.setVgap(15);
    return logGridPane;
  }

  private GridPane getManualInputGridPane() {

    GridPane manualInputGridPane = new GridPane();

    Label sqlTagLabel = new Label(ApplicationConstantsSuggestPlugin.SQL_TAG);
    sqlTagLabel.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    sqlTagLabel.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    TextField sqlTagInputTextFiled = new TextField();
    sqlTagInputTextFiled.setMinWidth(750);
    sqlTagInputTextFiled.setId(ApplicationConstantsSuggestPlugin.SQL_TAG);
    textFieldListener(sqlTagInputTextFiled);

    Label componentNameLabel = new Label(ApplicationConstantsSuggestPlugin.COMPONENT_NAME);
    componentNameLabel.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    componentNameLabel.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    TextField componentInputTextFiled = new TextField();
    componentInputTextFiled.setMinWidth(750);
    componentInputTextFiled.setId(ApplicationConstantsSuggestPlugin.COMPONENT_NAME);
    textFieldListener(componentInputTextFiled);

    Label pasFileLabel = new Label(ApplicationConstantsSuggestPlugin.PAS_FILE_PATH);
    pasFileLabel.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    pasFileLabel.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    TextField pasFileInputTextFiled = new TextField();
    pasFileInputTextFiled.setMinWidth(750);
    pasFileInputTextFiled.setId(ApplicationConstantsSuggestPlugin.PAS_FILE_PATH);
    pasFileInputTextFiled.setPromptText(ApplicationConstantsSuggestPlugin.FILE_PATH_PROMPT_TEXT);
    textFieldListener(pasFileInputTextFiled);

    manualInputGridPane.add(sqlTagLabel, 0, 0);
    manualInputGridPane.add(sqlTagInputTextFiled, 0, 1);
    manualInputGridPane.add(componentNameLabel, 0, 2);
    manualInputGridPane.add(componentInputTextFiled, 0, 3);
    manualInputGridPane.add(pasFileLabel, 0, 4);
    manualInputGridPane.add(pasFileInputTextFiled, 0, 5);
    manualInputGridPane.setHgap(5);
    manualInputGridPane.setVgap(15);
    return manualInputGridPane;
  }

  private GridPane getFileInputGridPane() {

    GridPane fileInputGridPane = new GridPane();

    Label filePath = new Label(ApplicationConstantsSuggestPlugin.INPUT_FILE_PATH);
    filePath.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    filePath.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    TextField filePathTextFiled = new TextField();
    filePathTextFiled.setMinWidth(750);
    filePathTextFiled.setId(ApplicationConstantsSuggestPlugin.INPUT_FILE_PATH);
    textFieldListener(filePathTextFiled);

    fileInputGridPane.add(filePath, 0, 0);
    fileInputGridPane.add(filePathTextFiled, 0, 1);
    fileInputGridPane.setHgap(5);
    fileInputGridPane.setVgap(15);
    return fileInputGridPane;
  }

  private GridPane getNotesGridPane() {

    GridPane notesGridPane = new GridPane();

    Label noteLabel = new Label(ApplicationConstantsSuggestPlugin.NOTE_LABEL);
    noteLabel.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    noteLabel.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    Label noteMessage = new Label(ApplicationConstantsSuggestPlugin.NOTE_MESSAGE);
    noteMessage.setFont(
        new Font(ApplicationConstantsSuggestPlugin.FONT_STYLE, ApplicationConstantsSuggestPlugin.MAXIMUM_FONT_SIZE));
    noteMessage.setTextFill(Color.web(ApplicationConstantsSuggestPlugin.TEXTBOX_COLOR_CODE));

    notesGridPane.add(noteLabel, 0, 0);
    notesGridPane.add(noteMessage, 1, 0);
    notesGridPane.setHgap(15);
    notesGridPane.setVgap(15);
    return notesGridPane;
  }

}
