package plugintool.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;

public class PluginGeneratorDao {

  MongoClient mongoClient = new MongoClient("192.168.57.68", 27017);

  public List<Document> getDocumentsList(String databaseName, String collectionName, Map<String, String> Filter,
      List<String> fields) {

    MongoDatabase database = mongoClient.getDatabase(databaseName);

    MongoCollection<Document> collection = database.getCollection(collectionName);

    if (Filter.isEmpty()) {
      return collection.find().projection(Projections.include(fields)).into(new ArrayList<Document>());
    }
    List<String> fieldName = new ArrayList<String>(Filter.keySet());
    return collection.find(Filters.eq(fieldName.get(0), Filter.get(fieldName.get(0))))
        .projection(Projections.include(fields)).into(new ArrayList<Document>());
  }

}
