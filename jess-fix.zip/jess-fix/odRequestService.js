'use strict';
const { models, resource } = require('../../server/server');
const DateUtils = require('../utils/dateUtils');
const LeaveRequestService = require('../services/leaveRequestService.js');
const ModelDateFilterUtility = require('../utils/modelDateFilterUtility');

const APPROVAL_FLOW_META = require('../metadata/approvalFlowMeta.json');
const { NOON_TYPE, LEAVE_TYPE } = require('../metadata/leaveRequestMeta.json');
const GeneralUtility = require('../utils/generalUtility');

const { APPROVAL_FLOW_SELECTION_TYPE, APPROVAL_REQUEST_STATUS, APPROVAL_FLOW_ACTION_STATUS } = APPROVAL_FLOW_META;

module.exports = class OdRequestService {
  constructor(){
    const occasionDateCol = "occasionDate";
    const fromDate = "fromDate";
    const toDate = "toDate";
    const { OdRequest, Holidays, LeaveRequest, OdRequestFragments, OdRequestApprovalFlow} = models;
    this.OdRequest = OdRequest;
    this.LeaveRequest = LeaveRequest;
    this.OdRequestFragments = OdRequestFragments;
    this.OdRequestApprovalFlow = OdRequestApprovalFlow;
    this.du = new DateUtils();
    this.gu = new GeneralUtility();
    this.mdfuHoliday = new ModelDateFilterUtility(Holidays, occasionDateCol);
    this.mdfuOdRequest = new ModelDateFilterUtility(OdRequest, fromDate, toDate);
    this.mdfuLeaveRequest = new ModelDateFilterUtility(LeaveRequest, fromDate, toDate);
  }
  createOdRequest = async (dataMap) => {
    return await this.OdRequest.upsert(dataMap);
  }

  calculateNoOfLeaveDays = async (userId, fromDate, toDate, startNoon, endNoon) => {

    const appliedDaysList = this.du.enumerateDaysBetweenDates(fromDate, toDate);
    const immutableAppliedDays = JSON.parse(JSON.stringify(appliedDaysList));

    await this.checkLeaveAlreadyExists(userId, appliedDaysList, fromDate, toDate, startNoon, endNoon)
    await this.checkNormalLeaveAlreadyExists(userId, appliedDaysList, fromDate, toDate, startNoon, endNoon);

    const holidaysInAppliedRange = await this.mdfuHoliday.findSingleColDatesInSpecifiedList(appliedDaysList, { active: true });
    const holidayDateStringList = holidaysInAppliedRange.map(e => this.du.getSqlFormatDatedString(e.occasionDate))
    let indexToRemove = [];
    for (let i = 0; i < holidayDateStringList.length; i++) {
        const index = immutableAppliedDays.findIndex(e => e === holidayDateStringList[i]);
        if (index !== -1) {
            indexToRemove.push(index);
        }
    }
    indexToRemove = indexToRemove.sort((a, b) => a - b).reverse();
    for (let i = 0; i < indexToRemove.length; i++) {
        appliedDaysList.splice(indexToRemove[i], 1);
    }

    let noOfDays = appliedDaysList.length;
    if (fromDate !== toDate) {
        if (startNoon === NOON_TYPE.AFTERNOON) {
            noOfDays = noOfDays - 0.5;
        }
        if (endNoon === NOON_TYPE.FORENOON) {
            noOfDays = noOfDays - 0.5;
        }
    } else if (fromDate === toDate && (startNoon === NOON_TYPE.AFTERNOON || endNoon === NOON_TYPE.FORENOON)) {
        noOfDays = noOfDays - 0.5;
    }
    return noOfDays;
  }

  checkLeaveAlreadyExists = async (applicant_id, dateList, fromDate, toDate, startNoon, endNoon) => {
    const fields = ["type", "noOfDays", "fromDate", "toDate", "leaveReason", "status", "startNoon", "endNoon"];
    const { APPLIED, IN_FLOW, APPROVED } = APPROVAL_REQUEST_STATUS;


    let existingLeaveRequests = await this.mdfuOdRequest.findDateListBetweenTwoColumns(applicant_id, dateList, null, { fields });
    existingLeaveRequests = existingLeaveRequests.filter(e => e.status === APPLIED || e.status === IN_FLOW || e.status === APPROVED);

    const intermediateLeaveRequestList = existingLeaveRequests.filter(e => this.du.getSqlFormatDatedString(e.fromDate) != fromDate && this.du.getSqlFormatDatedString(e.fromDate) != toDate)
        .filter(e => this.du.getSqlFormatDatedString(e.toDate) != fromDate && this.du.getSqlFormatDatedString(e.toDate) != toDate);
    if (intermediateLeaveRequestList.length > 0) {
        throw new Error(`On Duty Leave Requests already exists in the specified date range`);
    }

    existingLeaveRequests.filter(e => this.du.getSqlFormatDatedString(e.fromDate) === fromDate).forEach(e => {
        if (e.startNoon === startNoon || startNoon === NOON_TYPE.FULLDAY || e.startNoon === NOON_TYPE.FULLDAY) {
            throw new Error(`On Duty Leave Requests already exists in the specified date range`);
        }
    });

    existingLeaveRequests.filter(e => this.du.getSqlFormatDatedString(e.toDate) === toDate).forEach(e => {
        if (e.endNoon === endNoon || endNoon === NOON_TYPE.FULLDAY || e.endNoon === NOON_TYPE.FULLDAY) {
            throw new Error(`On Duty Leave Requests already exists in the specified date range`);
        }
    });
  }

  checkNormalLeaveAlreadyExists = async (applicant_id, dateList, fromDate, toDate, startNoon, endNoon) => {
    const fields = ["type", "noOfDays", "fromDate", "toDate", "leaveReason", "status", "startNoon", "endNoon"];
    const additionalFilter = { nin: { status: [APPROVAL_REQUEST_STATUS.WITHDRAWN] } };
    const { APPLIED, IN_FLOW, APPROVED } = APPROVAL_REQUEST_STATUS;


    let existingLeaveRequests = await this.mdfuLeaveRequest.findDateListBetweenTwoColumns(applicant_id, dateList, null, { fields });
    existingLeaveRequests = existingLeaveRequests.filter(e => e.status === APPLIED || e.status === IN_FLOW || e.status === APPROVED);

    const intermediateLeaveRequestList = existingLeaveRequests.filter(e => this.du.getSqlFormatDatedString(e.fromDate) != fromDate && this.du.getSqlFormatDatedString(e.fromDate) != toDate)
        .filter(e => this.du.getSqlFormatDatedString(e.toDate) != fromDate && this.du.getSqlFormatDatedString(e.toDate) != toDate);
    if (intermediateLeaveRequestList.length > 0) {
        throw new Error(`Leave Requests already exists in the specified date range`);
    }

    existingLeaveRequests.filter(e => this.du.getSqlFormatDatedString(e.fromDate) === fromDate).forEach(e => {
        if (e.startNoon === startNoon || startNoon === NOON_TYPE.FULLDAY || e.startNoon === NOON_TYPE.FULLDAY) {
            throw new Error(`Leave Requests already exists in the specified date range`);
        }
    });

    existingLeaveRequests.filter(e => this.du.getSqlFormatDatedString(e.toDate) === toDate).forEach(e => {
        if (e.endNoon === endNoon || endNoon === NOON_TYPE.FULLDAY || e.endNoon === NOON_TYPE.FULLDAY) {
            throw new Error(`Leave Requests already exists in the specified date range`);
        }
    });
  }

  myAppliedLeaves = async (applicant_id, paging, conditions) => {
    const { OdRequest } = this;
    const { num, size } = paging;
    const skip = num * size;

    const where = conditions ? { ...conditions } : {}
    let options = {
        include : [{
            relation:"proxy_applicant",
            scope:{fields:["firstName"]}
          }],
        order: 'fromDate DESC',
        limit: size,
        skip
    }

    let response = {
        records: [],
        totalCount: 0
    }
    const { fromDate, toDate } = where;

    delete where.fromDate;
    delete where.toDate;
    if (fromDate && toDate) {
        response = await this.mdfuOdRequest.findDualRangeDateBetweenDualColumns(fromDate, toDate, { ...where, applicant_id }, options);
    } else if (fromDate) {
        response = await new ModelDateFilterUtility(OdRequest, "fromDate").findGreaterDatesFromGivenDate(fromDate, { ...where, applicant_id }, options);
    } else if (toDate) {
        response = await new ModelDateFilterUtility(OdRequest, "toDate").findLesserDatesFromGivenDate(toDate, { ...where, applicant_id }, options);
    } else {
        response.totalCount = await OdRequest.count({ ...where, applicant_id });
        options.skip = options.skip ? this.gu.fixPageCountBySkipLimit(response.totalCount, options) : 0;
        response.records = await OdRequest.find({ where: { ...where, applicant_id }, ...options });
    }
    response.records.forEach(r=> {
      r['type'] = 'ON-DUTY_LEAVE'
    })
    return response;
  }

  withDrawLeaveRequest = async (userId, details,req) => {
    const { request_id, withdrawReason } = details;
    const { OdRequest, OdRequestApprovalFlow, KairoUser } = models;
    const { AWAITING_MY_APPROVAL, WAITING_FOR_PREVIOUS_APPROVERS, WITHDRAWN_BY_USER } = APPROVAL_FLOW_ACTION_STATUS;

    const leaveRequestInfo = await OdRequest.upsertWithWhere({ id: request_id, applicant_id: userId },
        { status: APPROVAL_REQUEST_STATUS.WITHDRAWN, withdrawReason });

    await OdRequestApprovalFlow.updateAll({ request_id, actionStatus: AWAITING_MY_APPROVAL },
        { actionStatus: WITHDRAWN_BY_USER });

    await OdRequestApprovalFlow.updateAll({ request_id, actionStatus: WAITING_FOR_PREVIOUS_APPROVERS },
        { actionStatus: WITHDRAWN_BY_USER });

    this.triggerRedmineLogUpdate(request_id,req)

    return leaveRequestInfo;
  }

  getLeaveFragments = async (leave_request_id) => {
    const { OdRequestFragments } = models;
    const argConditions = {
        where: { leave_request_id },
        order: 'fragmentDate',
        fields: ["fragmentDate", "dayName", "noonType"]
    }
    return await OdRequestFragments.find(argConditions);
  }

  checkLeaveType = async (type) => {
    const { OdAllotmentSettings } = models;

    const leaveSettings = (await OdAllotmentSettings.find({
        where: { leaveType: type },
        fields: ["considerHolidaysInCount","noOfPastMonths","currentMonthBuffer"]
    }))[0];

    return leaveSettings;
  }

  splitLeaveRequest = async (fragmentDate, noonType) => {

    const argConditions = {
        where: { fragmentDate }, order: "id asc",
        include: ["leaveRequest"]
    }

    let leaveRequestList = await this.OdRequestFragments.find(argConditions);

    leaveRequestList = leaveRequestList.filter(e => e.toJSON().leaveRequest.status === APPROVAL_REQUEST_STATUS.APPROVED
        || e.toJSON().leaveRequest.status === APPROVAL_REQUEST_STATUS.APPLIED
        || e.toJSON().leaveRequest.status === APPROVAL_REQUEST_STATUS.IN_FLOW)


    const isHalfDay = noonType !== NOON_TYPE.FULLDAY;

    for (let i = 0; leaveRequestList && i < leaveRequestList.length; i++) {
        const { leave_request_id, leaveRequest } = leaveRequestList[i].toJSON();
        const leave_request_fragment_id = leaveRequestList[i].id;
        const { applicant_id } = leaveRequest;
        const leaveFragmentList = await this.OdRequestFragments.find({ where: { leave_request_id }, order: "fragmentDate ASC" });

        if (leaveFragmentList.length === 1) {


            if (!isHalfDay || !leaveFragmentList[0].isFullday) {
                await this.withdrawSingleLeaveRequest(leave_request_id);
            } else {
                let fragmentInfoData = Object.assign(leaveFragmentList[0], { isFullday: false });
                await this.updateExistingRequestToHalfDay(leave_request_id, fragmentInfoData, noonType);
                await this.createNewWithdrawRequest(leave_request_id, fragmentInfoData, noonType);
            }
            continue;
        }

        const holidayIndex = leaveFragmentList.findIndex(e => e.id === leave_request_fragment_id);

        const fragmentInfo = leaveFragmentList[holidayIndex];

        if (isHalfDay) {
            await this.createNewHalfDayRequest(leave_request_id, Object.assign(fragmentInfo, { isFullday: false }), noonType);
        }

        const existingRequestDays = await this.createNewWithdrawRequest(leave_request_id, fragmentInfo, noonType);

        const noOfDays = existingRequestDays - 1;

        const totalFragments = leaveFragmentList.length - 1;
        switch (holidayIndex) {
            case 0:
                await this.upgradeFromDateOfRequest(leave_request_id, leaveFragmentList[1], noOfDays);
                break;

            case totalFragments:
                await this.upgradeToDateOfRequest(leave_request_id, leaveFragmentList[totalFragments - 1], noOfDays);
                break;

            default:
                const firstPartIndex = holidayIndex - 1, secondPartIndex = holidayIndex + 1;
                await this.processMultiRangeLeaveRequest(leave_request_id, leaveFragmentList, firstPartIndex, secondPartIndex);
                break;
        }
    }

  }

  withdrawSingleLeaveRequest = async (id) => {
    await this.OdRequest.upsertWithWhere({ id }, { status: APPROVAL_REQUEST_STATUS.WITHDRAWN });
    await this.withdrawLeaveRequestApprovalFlow(id);
  }

  withdrawLeaveRequestApprovalFlow = async (request_id) => {
    const { AWAITING_MY_APPROVAL, WAITING_FOR_PREVIOUS_APPROVERS, WITHDRAWN_BY_USER, APPROVED } = APPROVAL_FLOW_ACTION_STATUS;

    await this.OdRequestApprovalFlow.updateAll({ request_id, actionStatus: AWAITING_MY_APPROVAL },
        { actionStatus: WITHDRAWN_BY_USER });

    await this.OdRequestApprovalFlow.updateAll({ request_id, actionStatus: WAITING_FOR_PREVIOUS_APPROVERS },
        { actionStatus: WITHDRAWN_BY_USER });

    await this.OdRequestApprovalFlow.updateAll({ request_id, actionStatus: APPROVED },
        { actionStatus: WITHDRAWN_BY_USER });
  }

  updateExistingRequestToHalfDay = async (leave_request_id, fragmentInfo, noonType) => {
    const noonTypeValue = noonType === NOON_TYPE.AFTERNOON ? NOON_TYPE.FORENOON : NOON_TYPE.AFTERNOON;

    const dataToUpdate = {
        noOfDays: 0.5,
        startNoon: noonTypeValue,
        endNoon: noonTypeValue
    }
    await this.OdRequest.upsertWithWhere({ id: leave_request_id }, dataToUpdate);

    const insertFragmentData = {
        ...fragmentInfo.toJSON(),
        isFullDay: false,
        noOfDays: 0.5,
        isConflict: false,
        noonType: noonTypeValue,
    }
    delete insertFragmentData.id;

    await this.OdRequestFragments.create(insertFragmentData);
  }

  createNewWithdrawRequest = async (leave_request_id, fragmentInfo, noonType) => {
    const existingRequest = await this.OdRequest.findById(leave_request_id);
    const { id, isFullday, fragmentDate } = fragmentInfo;
    const noonTypeValue = isFullday ? fragmentInfo.noonType : noonType;

    const dataToInsert = {
        ...existingRequest.toJSON(),
        noOfDays: isFullday ? 1 : 0.5,
        fromDate: fragmentDate,
        toDate: fragmentDate,
        startNoon: noonTypeValue,
        endNoon: noonTypeValue,
        status: APPROVAL_REQUEST_STATUS.WITHDRAWN
    };
    delete dataToInsert.id;
    const newRequest = await this.OdRequest.create(dataToInsert);

    const upsertData = {
        leave_request_id: newRequest.id,
        noonType: noonTypeValue,
        isFullday,
        noOfDays: isFullday ? 1 : 0.5
    }
    await this.OdRequestFragments.upsertWithWhere({ id }, upsertData);
    await this.createApprovalFlowForRequest(leave_request_id, newRequest.id);

    await this.withdrawLeaveRequestApprovalFlow(newRequest.id);
    return existingRequest.noOfDays;
  }

  createApprovalFlowForRequest = async (old_request_id, new_request_id) => {
    const existingApprovalFlow = await this.OdRequestApprovalFlow.find({ where: { request_id: old_request_id } });

    const dataToInsert = [];
    for (let i = 0; i < existingApprovalFlow.length; i++) {
        const newApprovalData = existingApprovalFlow[i].toJSON();
        delete newApprovalData.id;
        newApprovalData.request_id = new_request_id;
        dataToInsert.push(newApprovalData);
    }
    await this.OdRequestApprovalFlow.create(dataToInsert);
  }

  createNewHalfDayRequest = async (leave_request_id, fragmentInfo, noonType) => {
    const existingRequest = await this.OdRequest.findById(leave_request_id);
    const { fragmentDate } = fragmentInfo;
    const noonTypeValue = noonType === NOON_TYPE.AFTERNOON ? NOON_TYPE.FORENOON : NOON_TYPE.AFTERNOON;

    const dataToInsert = {
        ...existingRequest.toJSON(),
        noOfDays: 0.5,
        fromDate: fragmentDate,
        toDate: fragmentDate,
        startNoon: noonTypeValue,
        endNoon: noonTypeValue
    }
    delete dataToInsert.id;
    const newRequest = await this.OdRequest.create(dataToInsert);

    const dataToInsertFragment = {
        ...fragmentInfo.toJSON(),
        leave_request_id: newRequest.id,
        noOfDays: 0.5,
        isConflict: false,
        noonType: noonTypeValue,
    }
    delete dataToInsertFragment.id;

    await this.OdRequestFragments.create(dataToInsertFragment);
    await this.createApprovalFlowForRequest(leave_request_id, newRequest.id);

  }

  upgradeFromDateOfRequest = async (leave_request_id, newFragmentInfo, noOfDays) => {
    const { fragmentDate, noonType } = newFragmentInfo;
    await this.OdRequest.upsertWithWhere({ id: leave_request_id }, {
        fromDate: fragmentDate, startNoon: noonType, noOfDays
    });
  }


upgradeToDateOfRequest = async (leave_request_id, newFragmentInfo, noOfDays) => {
    const { fragmentDate, noonType } = newFragmentInfo;
    await this.OdRequest.upsertWithWhere({ id: leave_request_id }, {
        toDate: fragmentDate, endNoon: noonType, noOfDays
    });
  }

processMultiRangeLeaveRequest = async (leave_request_id, leaveFragmentList, firstPartIndex, secondPartIndex) => {
    //Second Part for new Request
    let noOfDays = 0;
    const secondPartFragmentIds = [], fragmentLength = leaveFragmentList.length;
    for (let i = secondPartIndex; i < fragmentLength; i++) {
        const { id, isFullday } = leaveFragmentList[i];
        noOfDays += isFullday ? 1 : 0.5;
        secondPartFragmentIds.push(id);
    }

    const existingRequest = await this.OdRequest.findById(leave_request_id);
    const dataToInsert = {
        ...existingRequest.toJSON(),
        noOfDays,
        fromDate: leaveFragmentList[secondPartIndex].fragmentDate,
        startNoon: leaveFragmentList[secondPartIndex].noonType,
        toDate: leaveFragmentList[fragmentLength - 1].fragmentDate,
        endNoon: leaveFragmentList[fragmentLength - 1].noonType
    };
    delete dataToInsert.id;
    const newRequest = await this.OdRequest.create(dataToInsert);
    // Async function but can be triggered independently.
    this.createApprovalFlowForRequest(leave_request_id, newRequest.id);
    secondPartFragmentIds.forEach(fragment_id => this.OdRequestFragments.upsertWithWhere({ id: fragment_id }, { leave_request_id: newRequest.id }));


    //First part of request upgradation
    noOfDays = 0;
    for (let i = 0; i <= firstPartIndex; i++) {
        const { isFullday } = leaveFragmentList[i];
        noOfDays += isFullday ? 1 : 0.5;
    }
    await this.upgradeToDateOfRequest(leave_request_id, leaveFragmentList[firstPartIndex], noOfDays);
  }

  checkWhetherRoleIsHR = async (userId) => {
    let hasHrRole = false;
    const { RoleMapping, ProjectAllocation, KairoRole } = models;
    const userRoleDetails = await RoleMapping.find({
        where: { principalId: userId }, fields: ["principalId", "roleId"],
        include: [{
            relation: "user",
            scope: { fields: ["name", "domain", "id"] }
        }]
    });

    for (let i = 0; i < userRoleDetails.length; i++) {
        const userRoleInfo = userRoleDetails[i].toJSON();
        if (userRoleInfo.user.name.toLowerCase().includes('hr')) {
            hasHrRole = true;
            break;
        }
    }

    const myProjectRoles = (await ProjectAllocation.find({
        where: { employee_id: userId },
        fields: ["role_id"]
    })).map(e => parseInt(e.role_id));

    const userRoleDetailsList = await KairoRole.find({ where: { id: { inq: myProjectRoles }}} );

    for (let i = 0; i < userRoleDetailsList.length; i++) {
        const userRoleInfo = userRoleDetailsList[i];
        if (userRoleInfo.name.toLowerCase().includes('hr')) {
            hasHrRole = true;
            break;
        }
    }

    return hasHrRole;
}

  triggerRedmineLogUpdate = async (request_id,req) => {
    try {
        const gu = new GeneralUtility();
        const axiosBase  = await gu.getAxiosBase(req);
        axiosBase.defaults.headers['Content-Type'] = 'application/json';
        await axiosBase.post('/on-duty/withdraw/logreport/remove/',request_id.toString());
    } catch (err) {
        console.log(err);
        return err;
    }
  }

}
