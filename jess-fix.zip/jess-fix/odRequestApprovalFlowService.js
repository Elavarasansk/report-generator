'use strict';
const { models } = require('../../server/server');
const moment = require('moment');
const GeneralUtility = require('../utils/generalUtility');
const ModelDateFilterUtility = require('../utils/modelDateFilterUtility');
const APPROVAL_FLOW_META = require('../metadata/approvalFlowMeta.json');
const KairouserService = require('./kairouserService');
const DateUtility = require('../utils/dateUtils');
const { APPROVAL_REQUEST_STATUS, APPROVAL_FLOW_ACTION_STATUS } = APPROVAL_FLOW_META;
module.exports = class OdRequestApprovalFlowService {
  constructor(){
    const { OdRequest } = models;
    const fromDate = "fromDate";
    const toDate = "toDate";
    this.mdfuOdRequest = new ModelDateFilterUtility(OdRequest, fromDate, toDate);
    this.gu = new GeneralUtility();
    this.kus = new KairouserService();
    this.du = new DateUtility();
  }
  myRequestDetails = async (applicant_id, request_id) => {
    const { OdRequestApprovalFlow } = models;
    const fields = ["empId", "email", "username"];
    return await OdRequestApprovalFlow.find({
        where: { applicant_id, request_id },
        order: 'levelFlow ASC',
        fields: ["actionStatus", "comments", "negativeActionReason", "levelFlow", "isFinal",
            "current_approver_id", "modifiedOn"],
        include: [{
            relation: "currentApprover",
            scope: { fields }
        }]
    });
  }
  requestsGivenToMe = async (current_approver_id, filter, nestedFilter) => {
    const { OdRequestApprovalFlow } = models;
    const { actionStatus, isFinalString } = filter.where ? filter.where : {};
    let where = {};
    where.actionStatus = actionStatus;
    if (isFinalString) {
        where.isFinal = (isFinalString === "true");
    }
    if (!actionStatus) {
        where.actionStatus = APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL;
    }

    const idList = await this.filterForNestedRequests(current_approver_id, filter, nestedFilter);
    where.request_id = { inq: idList }

    where.current_approver_id = current_approver_id;

    console.log('*** dont remove unless regression testing done ***', where);

    const totalCount = await OdRequestApprovalFlow.count({ ...where });

    const { num, size } = filter.paging ? this.gu.fixPageCount(totalCount, filter.paging) : filter.paging;

    const skip = num * size ;
    let records = await OdRequestApprovalFlow.find({
        where,
        order: 'createdOn DESC',
        skip,
        limit: size,
        include: [{
            relation: "leaveRequest",
            scope: {
                fields: ["fromDate", "toDate", "startNoon", "endNoon", "noOfDays",
                    "applicant_id", "actionDueDate", "status", "leaveReason", "withdrawReason"],
                include: [{
                    relation: "applicant",
                    scope: {
                        fields: ["email", "username","firstName","lastName","fileProfileImage", "empId","isProbation","probationId","probationPrefix"]
                    }
                }]
            }
        }]
    });
    return {
        totalCount,
        records,
    }
  }

  filterForNestedRequests = async (current_approver_id, filter, nestedFilter) => {
    const { OdRequestApprovalFlow, OdRequest, KairoUser } = models;
    const { fromDate, toDate,mixedUserSearch } = nestedFilter;
    const { actionStatus, isFinalString } = filter.where;

    let where = {};
    // const hasHrRole = await this.checkWhetherRoleIsHR(current_approver_id);
    // if (hasHrRole && (!actionStatus || actionStatus === APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL)) {
    //     where.isHr = true;
    // } else {
    //     where.current_approver_id = current_approver_id;
    // }
    where.actionStatus = actionStatus;
    if (isFinalString) {
        where.isFinal = (isFinalString === "true");
    }

    console.log('*** dont remove unless regression testing done ***');
    where.current_approver_id = current_approver_id;
    console.log('*** dont remove unless regression testing done ***');
    const requestedIdList = (await OdRequestApprovalFlow.find({
        where,
        fields: ["request_id"]
    })).map(e => e.request_id);

    if (nestedFilter.email) {
        const pattern = new RegExp('.*' + nestedFilter.email + '.*', "i");
        const employeeIdList = (await KairoUser.find({
            where: { email: { like: pattern } },
            fields: ["id"]
        })).map(e => e.id);
        nestedFilter.applicant_id = { inq: employeeIdList };
        delete nestedFilter.email;
    }

    if (nestedFilter.applicantEmail) {
        const pattern = new RegExp('.*' + nestedFilter.applicantEmail + '.*', "i");
        const employeeIdList = (await KairoUser.find({
            where: { email: pattern },
            fields: ["id"]
        })).map(e => e.id);
        nestedFilter.applicant_id = { inq: employeeIdList };
        delete nestedFilter.applicantEmail;
    }

    if (mixedUserSearch) {
        const userSearch = mixedUserSearch ? mixedUserSearch.startsWith("P-") ? mixedUserSearch.split('-')[1] : mixedUserSearch : '';
        const serachCondition = [
            { firstName: { like: `${mixedUserSearch}%` } },
            { email: { like: `${mixedUserSearch}%` } },
            { username: { like: `${mixedUserSearch}%` } }];
        if (mixedUserSearch.startsWith("P-")) {
            serachCondition.push({ probationId: { like: `${userSearch}%` } });
        }else if (userSearch) {
            serachCondition.push({ empId: { like: `${userSearch}%` } });
        }
        const employeeIdList = (await KairoUser.find({
            where: {
                and: [{ or: serachCondition }, { active: true }]
            },
            fields: ["id"]
        })).map(e => e.id);

        nestedFilter.applicant_id = { inq: employeeIdList };
        delete nestedFilter.mixedUserSearch;
    }
    delete nestedFilter.fromDate;
    delete nestedFilter.toDate;

    const additionalFilter = { id: { inq: requestedIdList }, ...nestedFilter };
    const options = { fields: ["id"] };
    let response;

    if (fromDate && toDate) {
        response = await this.mdfuOdRequest.findDualRangeDateBetweenDualColumns(fromDate, toDate, additionalFilter, options);
    } else if (fromDate) {
        response = await new ModelDateFilterUtility(OdRequest, "fromDate").findGreaterDatesFromGivenDate(fromDate, additionalFilter, options);
    } else if (toDate) {
        response = await new ModelDateFilterUtility(OdRequest, "toDate").findLesserDatesFromGivenDate(toDate, additionalFilter, options);
    } else {
        return await OdRequest.find({ where: { ...additionalFilter, ...options } }).map(e => e.id);
    }

    return response.records && response.records.map(e => e.id);
  }

  takeActionOnRequestGiven = async (current_approver_id, details,req) => {
    const { OdRequestApprovalFlow, OdRequest } = models;
    const { request_id, actionStatus, comments, negativeActionReason } = details;

    console.log('details--------', details);

    // Perform Action on the ApprovalRequest.
    let upsertCondition = {};

    upsertCondition = { current_approver_id, request_id, actionStatus: APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL }

    const reqFlowDetails = await OdRequestApprovalFlow.upsertWithWhere(upsertCondition, {
        current_approver_id, actionStatus,
        comments, negativeActionReason
    });
    console.log('upsertCondition, reqFlowDetails--------', upsertCondition, reqFlowDetails);

    // Update Request Status.
    const { APPLIED, IN_FLOW, APPROVED, REJECTED } = APPROVAL_REQUEST_STATUS;
    let status = (actionStatus !== APPROVED) ? REJECTED : APPLIED;
    if (actionStatus === APPROVAL_FLOW_ACTION_STATUS.APPROVED) {
        status = reqFlowDetails.isFinal ? APPROVED : IN_FLOW;
    }
    await OdRequest.upsertWithWhere({ id: request_id }, { status });

    console.log('request_id--------', request_id);
    // Audit Leaves & details.
    const { applicant_id, type, noOfDays,fromDate } = await OdRequest.findById(request_id);

    console.log('applicant_id--------', applicant_id);
    // Update Nextlevel approvalflow.
    if (!reqFlowDetails.isFinal) {
        const { AWAITING_MY_APPROVAL, REJECTED_BY_ME, REJECTED_BY_OTHERS, WAITING_FOR_PREVIOUS_APPROVERS } = APPROVAL_FLOW_ACTION_STATUS;
        if (actionStatus === REJECTED_BY_ME) {
            await OdRequestApprovalFlow.updateAll({ request_id, actionStatus: WAITING_FOR_PREVIOUS_APPROVERS },
                { actionStatus: REJECTED_BY_OTHERS });
            // await this.removeLeaveFromApplied(applicant_id, type, noOfDays);
        }

        if (actionStatus === APPROVAL_FLOW_ACTION_STATUS.APPROVED) {
            await OdRequestApprovalFlow.upsertWithWhere({ request_id, levelFlow: (reqFlowDetails.levelFlow + 1) },
                { actionStatus: AWAITING_MY_APPROVAL });
        }
    }
    if(reqFlowDetails.isFinal){
      const notAddLogTime = this.du.isDateTodayOrFutureDate(fromDate);
      if(!notAddLogTime){
        this.triggerRedmineLogUpdate(request_id,req);
      }
    }

    console.log('final--------', reqFlowDetails);
    return reqFlowDetails;
  }

  detailsOfRequestGivenToMe = async (userId, request_id) => {
    const { OdRequestApprovalFlow } = models;
    let reqDetails = await OdRequestApprovalFlow.find({
        where: { request_id },
        order: 'levelFlow ASC',
        include: [{
            relation: "currentApprover",
            scope: {
                fields: ["email", "username", "fileProfileImage"]
            }
        }, {
            relation: "leaveRequest",
            scope: {
                fields: ["applicant_id"]
            }
        }]
    });
    if(reqDetails.length === 0){
      throw new Error(`Can't find details of Requesst`);
    }
    const approversList = reqDetails.map(e => e.current_approver_id);
    reqDetails = JSON.parse(JSON.stringify(reqDetails));

    const userLeaveBalance = await this.kus.getLeaveBalance(reqDetails[0].leaveRequest.applicant_id);
    return approversList.includes(userId)? { reqDetails, userLeaveBalance } : [];
  }

  takeActionOnMultipleRequests = async (current_approver_id, details) => {
    const { requestIdList, actionStatus, comments, negativeActionReason } = details;
    const updatedDate = [];
    for (let i = 0; i < requestIdList.length; i++) {
        const request_id = requestIdList[i];
        updatedDate.push(await this.takeActionOnRequestGiven(current_approver_id, { request_id, actionStatus, comments, negativeActionReason }));
    }
    return updatedDate;
  }

  triggerRedmineLogUpdate = async (request_id,req) => {
    try {
        const gu = new GeneralUtility();
        const axiosBase  = await gu.getAxiosBase(req);
        axiosBase.defaults.headers['Content-Type'] = 'application/json';
        await axiosBase.post('/on-duty/approval/create/logreport/entry/',request_id.toString());
    } catch (err) {
        console.log(err);
        return err;
    }
  }

}
