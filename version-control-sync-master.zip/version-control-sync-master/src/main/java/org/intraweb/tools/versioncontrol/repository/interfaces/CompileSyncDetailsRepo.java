package org.intraweb.tools.versioncontrol.repository.interfaces;

import org.intraweb.tools.versioncontrol.entity.CompileSyncDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface CompileSyncDetailsRepo extends MongoRepository<CompileSyncDetails, String>{
	
	CompileSyncDetails findByModuleAndVcsType(String module, String vcsType);

}
