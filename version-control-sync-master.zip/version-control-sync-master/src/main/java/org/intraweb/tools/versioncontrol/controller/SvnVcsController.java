package org.intraweb.tools.versioncontrol.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.IOUtils;
import org.intraweb.tools.versioncontrol.entity.FilterDataEntity;
import org.intraweb.tools.versioncontrol.service.MailService;
import org.intraweb.tools.versioncontrol.service.SvnBatchCompileService;
import org.intraweb.tools.versioncontrol.service.SvnFileSearch;
import org.intraweb.tools.versioncontrol.service.SvnSyncService;
import org.intraweb.tools.versioncontrol.utils.GITConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("vcs/svn/")
@CrossOrigin
@EnableScheduling
public class SvnVcsController {

	@Autowired
	private SvnSyncService svnSyncService;

	@Autowired
	private SvnFileSearch svnFileSearch;

	@Autowired
	private SvnBatchCompileService svnBatchCompileService;
	
	@Autowired
	private MailService mailService;

	@GetMapping("svn41/fail/list")
    public void getFailedDprs(@RequestParam("module") String module,HttpServletResponse response) throws IOException {
        File file = svnBatchCompileService.getFailedDprs(module);        
        InputStream inputStream = new FileInputStream(file);       
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename="+file.getName()); 
        IOUtils.copy(inputStream, response.getOutputStream());
        response.flushBuffer();
        inputStream.close();
        FileUtils.deleteQuietly(file);
    }
	
	@GetMapping("sync/all")
	public void requestSvnSyncAll() {
		svnSyncService.updateAllSvnRepos();
	}

	@GetMapping("sync/svn")
	public void requestSvnSync(@RequestParam("svnType") String svnType, @RequestParam("module") String module) {
		svnSyncService.prepareForSvnUpdate(svnType, module);
	}
	
	@PostMapping("/svn41/check")
    @CrossOrigin
    public List<List<String>> checkExistingFilesSvn41(@RequestParam("file") MultipartFile[] uploadFiles) 
            throws Exception  {
        return svnFileSearch.searchFilesInRepo(uploadFiles[0], GITConstants.AC_SVN41);
    }

	@PostMapping("/svn40/check")
    @CrossOrigin
    public List<List<String>> checkExistingFilesSvn40(@RequestParam("file") MultipartFile[] uploadFiles) 
            throws Exception {
        return svnFileSearch.searchFilesInRepo(uploadFiles[0], GITConstants.AC_SVN40);
    }
	
/*	@PostMapping("build/svn")
	public void batchBuildSvn(@RequestBody	FilterDataEntity filterEntity) {
		svnBatchCompileService.fetchModules(filterEntity.getModule(),filterEntity.getDprStatus(),filterEntity.getVsc(),false);

	}	
	
	@PostMapping("build/svn40")
	public void batchBuildSvn40(@RequestBody	FilterDataEntity filterEntity) {
		svnBatchCompileService.fetchModules(filterEntity.getModule(),filterEntity.getDprStatus(),filterEntity.getVsc(),false);

	}
	
	@PostMapping("build/svn41")
	public void batchBuildSvn41(@RequestBody	FilterDataEntity filterEntity) {
		svnBatchCompileService.fetchModules(filterEntity.getModule(),filterEntity.getDprStatus(),filterEntity.getVsc(),false);

	}*/
	
/*	@PostMapping("svn40/groupbuild/test")
	public void svn40groupBuildSchedulerTest() {
		List<String> moduleList = Arrays.asList("COM", "CAM", "CBM", "CCM", "CFM", "common", "share");
		List<String> dprStatus = Arrays.asList("InProgress", "Resolved");
		svnBatchCompileService.fetchModules(moduleList, dprStatus, "AC_SVN40",true);
	}
	
    @PostMapping("svn41/groupbuild/test")
	public void svn41groupBuildSchedulerTest() {
		List<String> moduleList = Arrays.asList("COM", "CAM", "CBM", "CCM", "CFM", "common", "share");
		List<String> dprStatus = Arrays.asList("InProgress", "Resolved");
		svnBatchCompileService.fetchModules(moduleList, dprStatus, "AC_SVN41",true);
	}
	*/
	
/*
	@Scheduled(cron="0 30 13,1 * * *")
	@PostMapping("svn40/groupbuild")
	public void svn40GroupBuildScheduler() {
		List<String> moduleList = Arrays.asList("COM", "CAM", "CBM", "CCM", "CFM", "common", "share");
		List<String> dprStatus = Arrays.asList("InProgress", "Resolved");
		mailService.announceSvnGroupBuildTriggered("AC_SVN40");
		svnBatchCompileService.fetchModules(moduleList, dprStatus, "AC_SVN40",true);
	}*/
	
	/*@Scheduled(cron="0 0 13,1 * * *")
	@PostMapping("svn41/groupbuild")
	public void svn41GroupBuildScheduler() {
		List<String> moduleList = Arrays.asList("COM", "CAM", "CBM", "CCM", "CFM", "common", "share");
		List<String> dprStatus = Arrays.asList("InProgress", "Resolved");
		mailService.announceSvnGroupBuildTriggered("AC_SVN41");
		svnBatchCompileService.fetchModules(moduleList, dprStatus, "AC_SVN41",true);
	}*/
	
/*	
	@Scheduled(cron="0 0 19,7 * * *")
	@GetMapping("build/summary/mail")
	public void sendSvnSummaryMail() {
		mailService.sendSvnSummaryMail();
	}
*/
	
	
	
}
