package org.intraweb.tools.versioncontrol.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="cortex_dpr_details")
public class CortexDprDetails{
	
	@Id
	private ObjectId id;
	
	String dprname;
	String dprstatus;
	String enddate;
	String storyid;
	String gittype;
	String gitmergestatus;
	
}