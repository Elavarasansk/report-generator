package org.intraweb.tools.versioncontrol;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class JavaTest {
	public static void main(String[] args) {
		ProcessBuilder pb = new ProcessBuilder();
		pb.command("cmd.exe", "/c", "svn log D:\\HUE\\Workspace\\Develop\\SVN\\V40\\CBM40\\company_client\\delphi\\CBM\\CBMcommon\\CbmProc\\CbmProcReclalcDlg.dfm");
		try {
			List<String> res = streamExecutedResult(pb.start());
			res.stream().forEach(line -> {
				if(line.contains("|")) {
					System.out.println(line);
				}
			});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static List<String> streamExecutedResult(Process result) {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(result.getInputStream()));
		List<String> linesList = new ArrayList<>();
		String line;
		try {
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return linesList;
	}
}
