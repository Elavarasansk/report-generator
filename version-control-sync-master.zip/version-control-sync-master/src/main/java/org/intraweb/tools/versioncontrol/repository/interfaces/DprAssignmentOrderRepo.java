package org.intraweb.tools.versioncontrol.repository.interfaces;

import java.util.List;

import org.intraweb.tools.versioncontrol.entity.DprAssignmentOrder;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface DprAssignmentOrderRepo extends MongoRepository<DprAssignmentOrder, String>{
	
	DprAssignmentOrder findByDprNameAndModule(String dprName, String module);
	
	DprAssignmentOrder findByDprNameAndModuleIn(String dprName, List<String> moduleList);
	
	List<DprAssignmentOrder> findByModuleIn(List<String> moduleList);

}
