package org.intraweb.tools.versioncontrol.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SvnCommitLog {
	private String userId;
	private String userName;
	private String commitTime;
	private String changes;
}
