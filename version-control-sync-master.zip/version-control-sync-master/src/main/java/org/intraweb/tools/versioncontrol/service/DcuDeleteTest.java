package org.intraweb.tools.versioncontrol.service;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.versioncontrol.entity.CompileResultEntity;
import org.intraweb.tools.versioncontrol.utils.CompilerConstants;

public class DcuDeleteTest {


	private static final String ERROR = "Error:";	
	private static final String HINT = "Hint:";	
	private static final String FATAL = "Fatal:";
	private static final String WARNING = "Warning:";
	private static final String NAMESPACE_DCU = "-NSsystem;vcl";

	private static final String DELETE = "del";
	private static final String RECURSIVE = "/s";

	private static final String DCU = "*.dcu";

	private static final String OBJECT_FILE = "*.obj";




	public static void cleanRepo(String repo) {
		repo = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V41\\COM41\\hue_client\\delphi\\";
		File[] fileList = new File(repo).listFiles();
		for(File file : fileList ) {
			findAndDelete(file.listFiles());
		}
	}

	public static void findAndDelete(File[] fileList) {
		for(File file : fileList ) {
			if(file.isDirectory()) {
				findAndDelete(file.listFiles());
			}
			if(FilenameUtils.isExtension(file.getName(),"dcu") || FilenameUtils.isExtension(file.getName(),"cfg")) {
				System.out.println(file.getAbsolutePath());
				file.deleteOnExit();
			}

		}
	}


	public static void main(String[] args) throws InterruptedException  {


		cleanRepo("");
	}

}