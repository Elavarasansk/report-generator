package org.intraweb.tools.versioncontrol.repository.interfaces;

import java.util.List;

import org.intraweb.tools.versioncontrol.entity.Svn40CompileResult;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface Svn40CompileResultRepo extends MongoRepository<Svn40CompileResult, String>{

	Svn40CompileResult findByDprNameAndModule(String dprName, String module);
	
	Svn40CompileResult findByDprNameAndModuleIn(String dprName, List<String> moduleList);
	
	Svn40CompileResult findByStatus(String status);
	
	void deleteByModuleIn(String module);

	
}
