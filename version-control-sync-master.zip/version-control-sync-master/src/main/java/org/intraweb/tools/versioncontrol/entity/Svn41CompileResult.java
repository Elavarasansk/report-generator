package org.intraweb.tools.versioncontrol.entity;

import java.util.Date;
import java.util.List;

import org.hibernate.validator.constraints.ParameterScriptAssert;
import org.springframework.data.annotation.Persistent;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="svn41_compile_result")
public class Svn41CompileResult {
	
	private String dprName;
	private String module;
	private String status;
	private boolean dprExistsInPath;
	private boolean dprExists;
	private String failReason;
	private List<String> compiledResult;

	//@CreatedDate
	private Date createDate;
	
	
}
