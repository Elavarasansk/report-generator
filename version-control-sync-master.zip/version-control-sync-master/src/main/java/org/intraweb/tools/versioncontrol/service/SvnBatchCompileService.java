package org.intraweb.tools.versioncontrol.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.versioncontrol.entity.CompileResultEntity;
import org.intraweb.tools.versioncontrol.entity.CompileSyncDetails;
import org.intraweb.tools.versioncontrol.entity.DprAssignmentOrder;
import org.intraweb.tools.versioncontrol.entity.Svn40CompileResult;
import org.intraweb.tools.versioncontrol.entity.Svn41CompileResult;
import org.intraweb.tools.versioncontrol.repository.interfaces.CompileSyncDetailsRepo;
import org.intraweb.tools.versioncontrol.repository.interfaces.DprAssignmentOrderRepo;
import org.intraweb.tools.versioncontrol.repository.interfaces.Svn40CompileResultRepo;
import org.intraweb.tools.versioncontrol.repository.interfaces.Svn41CompileResultRepo;
//import org.intraweb.tools.versioncontrol.repository.interfaces.MongoDataService;
import org.intraweb.tools.versioncontrol.utils.CompilerConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;


import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SvnBatchCompileService {

	private static final String ERROR = "Error:";	
	private static final String HINT = "Hint:";	
	private static final String FATAL = "Fatal:";
	private static final String WARNING = "Warning:";
	private static final String FILE_NOT_FOUND = "File not found";
	private static final String AC_GIT = "AC_GIT";	
	private static final String AC_SVN40 = "AC_SVN40";
	private static final String AC_SVN41 = "AC_SVN41";
	private static final String DPR = ".dpr";
	private static final String OPTION_2 = "-Q";
	private static final String OPTION_1 = "-I";
	private static final String COMPILER = "C:\\Borland\\Delphi7\\Bin\\DCC32.EXE";
	private static final String SPLIT = ";";
	private static final String BUILD = "-B";
	private static final String ASSIGNABLE_TYPED_CONSTANT = "-$J+";
	private static final String FAIL="fail";
	private static final String SUCCESS="success";
	private static final String GENERATE_OBJ = "-J";
	private static final String OPTIMIZATION = "-$O+";
	private static final String NAMESPACE_DCU = "-NSsystem;vcl";
	private static final String FATAL_JA = "�v���I�G���[";
	private static final String ERROR_JA = "�G���[";




	@Autowired
	private DprAssignmentOrderRepo dprAssignmentOrderRepo;

	@Autowired
	private Svn40CompileResultRepo svn40CompileResultRepo;

	@Autowired
	private Svn41CompileResultRepo svn41CompileResultRepo;

	@Autowired
	private SvnCleanService svnCleanService;

	@Autowired
	private SvnSyncService svnSyncService;

	@Autowired
	private CompileSyncDetailsRepo compileSyncDetailsRepo;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${mail.url}")
	private String mailUrl;

	public void fetchModules(List<String> moduleList,List<String> statusList,String vcsType,boolean isTest) {
		List<DprAssignmentOrder> dprList = dprAssignmentOrderRepo.findByModuleIn(moduleList);		
		//List<String> cortexStatusList = cortexDprDetailsRepo.findByDprstatusIn(statusList).stream().map(CortexDprDetails::getDprname).collect(Collectors.toList());
		//List<DprAssignmentOrder> resultList = dprList.stream().filter(dpr->cortexStatusList.contains(dpr.getDprName())).collect(Collectors.toList());
		fetchModulesFromBatch(dprList, vcsType,isTest);
	}

	public void fetchModulesFromBatch(List<DprAssignmentOrder> dprList , String vcsType, boolean isTest) {
		dprList = dprList.stream().filter(dprDetails -> {
			String dprPath = formSVNFilePath(dprDetails.getDprPath(), dprDetails.getModule(), vcsType);
			return checkIfDprExists(dprPath+"\\"+dprDetails.getDprName()+".dpr");
		}).collect(Collectors.toList());

		dprList.forEach(x -> {
			String moduleName = x.getModule();
			if(moduleName.equals("common") || moduleName.equals("share")) {
				x.setModule("com");
			}
		});

		Map<String, List<DprAssignmentOrder>> moduleBasedDprList = dprList.stream().collect(Collectors.groupingBy(dprData -> dprData.getModule()));
		for(Map.Entry<String, List<DprAssignmentOrder>> x: moduleBasedDprList.entrySet()) {

			truncateSvnCompileTables(vcsType, x.getKey(), x.getValue());
			svnSyncService.prepareForSvnUpdate(vcsType, x.getKey());

			Thread dprBasedExeThread = new Thread(new Runnable() {
				@Override
				public void run() {
					batchBuildThread(x.getValue(), vcsType,isTest);
				}
			});
			dprBasedExeThread.start();
		}
	}

	private void truncateSvnCompileTables(String vcsType, String module, List<DprAssignmentOrder> dprList) {
		switch(vcsType) {
			case AC_SVN40:
				svn40CompileResultRepo.deleteByModuleIn(module);
				break;
			case AC_SVN41:
				svn41CompileResultRepo.deleteByModuleIn(module);
				break;
		}

		CompileSyncDetails compileSyncDetails = compileSyncDetailsRepo.findByModuleAndVcsType(module, vcsType);

		if(ObjectUtils.isEmpty(compileSyncDetails)) {
			compileSyncDetails = CompileSyncDetails.builder()
					.vcsType(vcsType)
					.module(module)
					.dprListSize(dprList.size())
					.syncInProgress(true)
					.build();
		}

		compileSyncDetails.setDprListSize(dprList.size());
		compileSyncDetails.setSyncInProgress(true);
		compileSyncDetails.setCreateDate(new Date());
		compileSyncDetailsRepo.save(compileSyncDetails);
	}


	public void batchBuildThread(List<DprAssignmentOrder> dprList, String vcsType,boolean isTest) {		
		
		for (   DprAssignmentOrder dprData  : dprList ) {
			executeDprBatch(dprData.getDprName(), dprData.getModule(), vcsType, dprData,isTest);
		}
		
	//TODO subthreading is removed.
		
/*		
		int subThreadCount = 4;

		int totalDprInThread = dprList.size()/subThreadCount;
		int totalDprSize = dprList.size();

		if(totalDprInThread==0) {
			dprList.forEach(dprData -> {
				executeDprBatch(dprData.getDprName(), dprData.getModule(), vcsType, dprData,isTest);
			});
			return;
		}

		for(int i=0; i< subThreadCount; i++){
			int dprStartCount = totalDprInThread*i;
			int dprEndCount = totalDprInThread*(i+1) > totalDprSize ? totalDprSize: totalDprInThread*(i+1);

			Thread dprBasedExeThread = new Thread(new Runnable() {
				@Override
				public void run() {
					dprList.subList(dprStartCount, dprEndCount).forEach(dprData -> {
						executeDprBatch(dprData.getDprName(), dprData.getModule(), vcsType, dprData,isTest);
					});
				}
			});
			dprBasedExeThread.start();
		}

		int skippedDprs = dprList.size()-(totalDprInThread*subThreadCount);
		if(skippedDprs>0) {
			dprList.subList(totalDprInThread*subThreadCount, totalDprSize).forEach(dprData -> {
				executeDprBatch(dprData.getDprName(), dprData.getModule(), vcsType, dprData,isTest);
			});
		}*/
		
		
	}

	public void persistEmptyDprCompilation(String dprName,String module) {
		Svn40CompileResult existingDpr = svn40CompileResultRepo.findByDprNameAndModule(dprName, module);

		if(ObjectUtils.isEmpty(existingDpr)) {
			existingDpr = Svn40CompileResult.builder()
					.dprName(dprName)
					.build();
		}

		existingDpr.setCompiledResult(null);
		existingDpr.setDprExists(false);
		existingDpr.setDprExistsInPath(false);
		existingDpr.setStatus(null);
		existingDpr.setFailReason("File not found");
		existingDpr.setCreateDate(new Date());
		svn40CompileResultRepo.save(existingDpr);
	}

	public void persistSvn40CompiledDprResult(String dprName, String module, String status, List<String> compiledResult, boolean dprExists,  boolean dprExistsInpath,boolean isTest) {
		Svn40CompileResult existingDpr = Svn40CompileResult.builder().build();
		if(module.equals("com")) {
			existingDpr = svn40CompileResultRepo.findByDprNameAndModuleIn(dprName, Arrays.asList("common","share"));
		}else {
			existingDpr = svn40CompileResultRepo.findByDprNameAndModule(dprName, module);
		}
		if(ObjectUtils.isEmpty(existingDpr)) {
			existingDpr = Svn40CompileResult.builder()
					.dprName(dprName)
					.module(module)
					.build();
		}

		existingDpr.setCompiledResult(compiledResult);
		existingDpr.setDprExists(dprExists);
		existingDpr.setDprExistsInPath(dprExistsInpath);
		existingDpr.setStatus(status);
		existingDpr.setCreateDate(new Date());
		svn40CompileResultRepo.save(existingDpr);
		if(!isTest) {
		try {
			if(status.equalsIgnoreCase("Fail")){
				existingDpr.setVersionType("svn40");
				existingDpr.setRequestType("Java");
				HttpHeaders headers = new HttpHeaders();
				headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				HttpEntity<Svn40CompileResult> entity = new HttpEntity<Svn40CompileResult>(existingDpr,headers);
				restTemplate.exchange(mailUrl+"intraweb/mailsend", HttpMethod.POST, entity, String.class).getBody(); 
			}			
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Failed to send mail for "+ existingDpr);
		}	
	}

	}

	public void persistSvn41CompiledDprResult(String dprName, String module, String status, List<String> compiledResult, boolean dprExists,  boolean dprExistsInpath,boolean isTest) {
		Svn41CompileResult existingDpr = Svn41CompileResult.builder().build();
		if(module.equals("com")) {
			existingDpr = svn41CompileResultRepo.findByDprNameAndModuleIn(dprName, Arrays.asList("common","share"));
		}else {
			existingDpr = svn41CompileResultRepo.findByDprNameAndModule(dprName, module);
		}
		if(ObjectUtils.isEmpty(existingDpr)) {
			existingDpr = Svn41CompileResult.builder()
					.dprName(dprName)
					.module(module)
					.build();
		}

		existingDpr.setCompiledResult(compiledResult);
		existingDpr.setDprExists(dprExists);
		existingDpr.setDprExistsInPath(dprExistsInpath);
		existingDpr.setStatus(status);
		existingDpr.setCreateDate(new Date());		
		svn41CompileResultRepo.save(existingDpr);
		if(!isTest) {
			try {
				if(status.equalsIgnoreCase("Fail")){
					//existingDpr.setVersionType("svn41");
					//existingDpr.setRequestType("Java");
					HttpHeaders headers = new HttpHeaders();
					headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
					HttpEntity<Svn41CompileResult> entity = new HttpEntity<Svn41CompileResult>(existingDpr,headers);
					restTemplate.exchange(mailUrl+"intraweb/mailsend", HttpMethod.POST, entity, String.class).getBody(); 
				}
			}catch(Exception e) {
				e.printStackTrace();
				log.error("Failed to send mail for "+ existingDpr);
			}
		}

	}


	public CompileResultEntity executeDprBatch(String dprName,String module,String versionControl, DprAssignmentOrder dprDetails,boolean isTest) {
		String execDprName = FilenameUtils.isExtension(dprName, DPR.replace(".", "")) ? dprName : dprName.concat(DPR);

		if(Objects.isNull(dprDetails)) {
			//persistEmptyDprCompilation(dprName, module);
			CompileResultEntity result =  formCompileResult(Arrays.asList("File Not Found"),execDprName,"",module);
			result.setCompiledList("File Not Found");
			result.setStatus(false);
			return result;
		}

		String dprPath = formSVNFilePath(dprDetails.getDprPath(), dprDetails.getModule(),versionControl);
		if(!checkIfDprExists(dprPath+"\\"+execDprName)) {
			return null;
		};		
		
		//TODO clean .dcu files.
		svnCleanService.cleanRepo(module.toUpperCase() , versionControl);
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		String pathList = StringUtils.EMPTY;
		switch(versionControl) {
			case AC_SVN40:
				pathList = CompilerConstants.SVN40_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
				pathList = module.equals("com") ?  pathList   : pathList.replace("COM40", module+40)   ;   
				break;
			case AC_SVN41:
				pathList = CompilerConstants.SVN41_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
				pathList = module.equals("com") ?  pathList   : pathList.replace("COM41", module+41)   ;   
				break;
		}
		try {
			Date compilerStartTime = new Date();
			processBuilder.directory(new File(dprPath));
			/*To generate DCU.*/
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),BUILD,execDprName);
			processBuilder.start();
			/*To execute DPR.*/
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),OPTIMIZATION,ASSIGNABLE_TYPED_CONSTANT,GENERATE_OBJ,OPTION_1,OPTION_2,execDprName);
			processBuilder.redirectErrorStream(true);
			p =processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
			Date compilerEndTime = new Date();

			switch(versionControl) {
				case AC_SVN40:
					persistSvn40CompiledDprResult(dprName, module, parsePasInfo(linesList)? SUCCESS:FAIL, linesList, true, true,isTest);
					break;
				case AC_SVN41:
					persistSvn41CompiledDprResult(dprName, module, parsePasInfo(linesList)? SUCCESS:FAIL, linesList, true, true,isTest);
					break;
			}
			return formCompileResult(linesList,execDprName,dprPath,module);
		} catch (IOException e) {	
			log.error("Exception occured while processing :",e.getMessage());
			CompileResultEntity result =  formCompileResult(Arrays.asList(e.getMessage()),execDprName,dprPath,module);
			result.setCompiledList(e.getMessage());
			result.setStatus(false);
			//persistCompiledDprResult(dprName, module, "Failed", null, false, false);
			return result;
		}finally {
			try {
				p.destroy();
			}catch(Exception e) {
				log.error("Prcoess failed "+e.getMessage());
			}
		}
	}

	private boolean checkIfDprExists(String dprPath) {
		File dprLocation = new File(dprPath);
		return dprLocation.exists();
	}

	private boolean parsePasInfo(List<String> linesList) {
		List<String> errorList = new ArrayList<>();			
		List<String> fatalList =  new ArrayList<>();		
		List<String> hintList =  new ArrayList<>();					
		List<String> warningList =  new ArrayList<>();		
		StringBuilder compiledList = new StringBuilder();
		Collections.reverse(linesList);
		linesList.stream().forEach(lne->{
			compiledList.append(lne);
			compiledList.append("\n");
			if(StringUtils.isNotEmpty(lne)){
				if(StringUtils.contains(lne, FATAL) || StringUtils.contains(lne, FATAL_JA) ){
					fatalList.add(lne);
				}else if(StringUtils.contains(lne, ERROR) || ( StringUtils.containsIgnoreCase(lne, FILE_NOT_FOUND) &&  StringUtils.containsIgnoreCase(lne, "dfm") ) || StringUtils.contains(lne, ERROR_JA) ) {
					errorList.add(lne);
				}else if(StringUtils.contains(lne, WARNING)) {
					warningList.add(lne);
				}else if(StringUtils.contains(lne, HINT)) {
					hintList.add(lne);

				}
			}			
		});
		return fatalList.isEmpty() && errorList.isEmpty() ;
	}

	private CompileResultEntity formCompileResult(List<String> linesList,String dprName,String dprPath,String module) {
		List<String> errorList = new ArrayList<>();			
		List<String> fatalList =  new ArrayList<>();		
		List<String> hintList =  new ArrayList<>();					
		List<String> warningList =  new ArrayList<>();		
		StringBuilder compiledList = new StringBuilder();
		Collections.reverse(linesList);
		linesList.stream().forEach(lne->{
			compiledList.append(lne);
			compiledList.append("\n");
			if(StringUtils.isNotEmpty(lne)){
				if(StringUtils.contains(lne, FATAL) || StringUtils.contains(lne, FATAL_JA) ){
					fatalList.add(lne);
				}else if(StringUtils.contains(lne, ERROR) || ( StringUtils.containsIgnoreCase(lne, FILE_NOT_FOUND) &&  StringUtils.containsIgnoreCase(lne, "dfm") ) || StringUtils.contains(lne, ERROR_JA) ) {
					errorList.add(lne);
				}else if(StringUtils.contains(lne, WARNING)) {
					warningList.add(lne);
				}else if(StringUtils.contains(lne, HINT)) {
					hintList.add(lne);

				}
			}			
		});		
		return CompileResultEntity
				.builder()
				.dprName(dprName)
				.dprPath(dprPath)
				.module(module)
				.fatalList(fatalList)
				.errorList(errorList)
				.warningList(warningList)
				.hintList(hintList)
				.compiledList(compiledList.toString())
				.status(fatalList.isEmpty() && errorList.isEmpty() )
				.build();
	}


	public String formSVNFilePath(String dprPath,String module, String versionControl) {
		String formSvnFilePath = "\\D:\\HUE\\WorkSpace\\Develop\\SVN\\V";
		String svnNum = "40";
		if(versionControl.equals(AC_SVN41)) {
			svnNum = "41";
		}	
		svnNum+="\\";
		if(module.toLowerCase().startsWith("cam")) {
			formSvnFilePath += svnNum+"CAM"+svnNum;
		} else if(module.toLowerCase().startsWith("cbm")) {
			formSvnFilePath += svnNum+"CBM"+svnNum;
		} else if(module.toLowerCase().startsWith("ccm")) {
			formSvnFilePath += svnNum+"CCM"+svnNum;
		} else if(module.toLowerCase().startsWith("cfm")) {
			formSvnFilePath += svnNum+"CFM"+svnNum;
		} else if(module.toLowerCase().startsWith("share") || module.toLowerCase().startsWith("common") || 
				module.toLowerCase().startsWith("com")) {
			formSvnFilePath += svnNum+"COM"+svnNum;
		}

		String replacePath = dprPath.replace("/", "\\");
		formSvnFilePath += "hue_client\\delphi\\"+replacePath;
		return FilenameUtils.getPath(formSvnFilePath);
	}

	public File getFailedDprs(String module) throws IOException {      
        List<String> resultList = new ArrayList<>();
        List<Svn41CompileResult> failedList = new ArrayList<>();
        if(StringUtils.equalsIgnoreCase(module,"All")) {
            failedList = svn41CompileResultRepo.findAll();
        }else {
            failedList = svn41CompileResultRepo.findByModuleAndStatus(module.toUpperCase(), "fail");
        }
        failedList.stream().forEach(action->{   
            StringBuilder sb = new StringBuilder();
            sb.append("\n");
            sb.append(action.getDprName()).append(",");
            sb.append(action.getModule()).append(",");
            sb.append(formCompileResult(action.getCompiledResult())).append(",");
            resultList.add(sb.toString());
        });
        String headers = "DPR NAME,Module,CompiledResult";
        List<String> headerList = new ArrayList<>();
        headerList.add(headers);           
        List<List<String>> rows = new ArrayList<>();
        rows.add(headerList);
        rows.add(resultList);
        return writeToCsvFile(rows);
    }
	
	public File writeToCsvFile(List<List<String>> rows) throws IOException {
        File file = File.createTempFile("temp", ".csv");
        file.createNewFile();
        PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

        for (List<String> row : rows) {
            pw.print(StringUtils.join(row,',') + ",");
            pw.println();
        }
        pw.close();
        return file;
    }
	
	private String formCompileResult(List<String> linesList) {
        StringBuilder compiledList = new StringBuilder();
        linesList.stream().forEach(lne->{
            if(StringUtils.isNotEmpty(lne)){
                if(StringUtils.contains(lne, FATAL) || StringUtils.contains(lne, FATAL_JA) ){
                    compiledList.append(lne);
                }else if(StringUtils.contains(lne, ERROR) || ( StringUtils.containsIgnoreCase(lne, FILE_NOT_FOUND) &&  StringUtils.containsIgnoreCase(lne, "dfm") ) || StringUtils.contains(lne, ERROR_JA) ) {
                    compiledList.append(lne);
                }
            }           
        });     
        return StringEscapeUtils.escapeCsv(compiledList.toString());
    }

}
