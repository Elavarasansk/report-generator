package org.intraweb.tools.versioncontrol.dto;

import java.util.Collection;
import java.util.List;

import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Ref;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GitPullResponse {

	private String fetchFrom;
	
	private boolean pullSuccess;
	
	private boolean mergeSuccess;
	
	private List<RefsTrackingUpdate> trackingUpdate;
	
	private Collection<Ref> advertisedRefs;
	
	private String remoteUri;
	
	private ObjectId[] mergedCommits;
	
}
