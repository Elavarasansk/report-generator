package org.intraweb.tools.versioncontrol.repository.interfaces;

import org.intraweb.tools.versioncontrol.entity.CompileStatusEntity;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface CompilerRepo extends MongoRepository<CompileStatusEntity, String>{
	public CompileStatusEntity findByDprName(String dprName); 
}
