package org.intraweb.tools.versioncontrol.utils;

import com.google.common.collect.ImmutableList;
import com.mongodb.annotations.Immutable;

public class GITConstants{

	public static final String ORIGIN = "origin";
	public static final String HUE_DEVELOP = "C:\\HUE\\WorkSpace\\Develop\\";
	public static final String HUE_DEVELOP_AC = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-";
	public static final String GIT_INDEX = "\\.git";
	public static final String CAC_REPO = "cac" + GIT_INDEX;
	public static final String CAM_REPO = "cam" + GIT_INDEX;
	public static final String CBM_REPO = "cbm" + GIT_INDEX;
	public static final String CCM_REPO = "ccm" + GIT_INDEX;
	public static final String CFM_REPO = "cfm" + GIT_INDEX;
	public static final String DOCUMENT_REPO = "document" + GIT_INDEX;
	public static final String INDEX_LOCK_FILE = "index.lock";
	
	
	public static final String AC_GIT = "AC_GIT";
	public static final String AC_SVN40 = "AC_SVN40";
	public static final String AC_SVN41 = "AC_SVN41";
	
	public static final String CAC = "CAC";
	public static final String COM = "COM";
	public static final String CAM = "CAM";
	public static final String CBM = "CBM";
	public static final String CCM = "CCM";
	public static final String CFM = "CFM";
	public static final String DOCUMENT = "DOCUMENT";	
	
	public static final ImmutableList<String> SVN_CLEAN_LIST = ImmutableList.of(COM,CAM,CBM,CCM,CFM);
	
	
	public static final ImmutableList<String> GIT_PRUNE_LIST = ImmutableList.of(CAC_REPO,CAM_REPO,CBM_REPO,CCM_REPO,CFM_REPO,DOCUMENT_REPO);


}
