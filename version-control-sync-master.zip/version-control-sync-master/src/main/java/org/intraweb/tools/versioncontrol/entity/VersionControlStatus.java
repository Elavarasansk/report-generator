package org.intraweb.tools.versioncontrol.entity;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.intraweb.tools.versioncontrol.dto.GitPullResponse;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="version_control_status")
public class VersionControlStatus {
	
	@Id
	private ObjectId id;

	private String versionType;
	
	private String module;

	private boolean syncInProgress;

	private Date lastSyncStartTime;

	private Date lastSyncEndTime;
	
	private GitPullResponse gitPullResponse;
	
	private List<String> svnUpdateResult;

}
