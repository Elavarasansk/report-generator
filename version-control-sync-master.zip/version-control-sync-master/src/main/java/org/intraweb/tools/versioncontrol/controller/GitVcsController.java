package org.intraweb.tools.versioncontrol.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("vcs/git")
@CrossOrigin
public class GitVcsController {

	/*@Autowired
	private GitSyncService gitSyncService;
	
	@GetMapping("sync/all")
	public void syncAllRepos() {
		gitSyncService.multiRepoSyncThread();
	}
	
	@GetMapping("sync/cac")
	public GitPullResponse requestCacSync() {
		return gitSyncService.cacGitPull();
	}
	
	@GetMapping("sync/cam")
	public GitPullResponse requestCamSync() {
		return gitSyncService.camGitPull();
	}
	
	@GetMapping("sync/cbm")
	public GitPullResponse requestCbmSync() {
		return gitSyncService.cbmGitPull();
	}
	
	@GetMapping("sync/ccm")
	public GitPullResponse requestCcmSync () {
		return gitSyncService.ccmGitPull();
	}
	
	@GetMapping("sync/cfm")
	public GitPullResponse requestCfmSync() {
		return gitSyncService.cfmGitPull();
	}
	
	@GetMapping("sync/document")
	public GitPullResponse requestDocumentSync() {
		return gitSyncService.documentGitPull();
	}
*/	
/*	@GetMapping("prune")
	@Scheduled(cron= "0 0 0/2 * * *" )
	public void executeGitPrune() {
		 gitSyncService.executeGitPrune();
	}*/
	
}
