package org.intraweb.tools.versioncontrol.entity;

import java.util.List;

import lombok.Data;

@Data
public class FilterDataEntity {
	private List<String> module;

	private List<String> dprStatus;

	private String vsc;

	private String startDate;

	private String endDate;
}
