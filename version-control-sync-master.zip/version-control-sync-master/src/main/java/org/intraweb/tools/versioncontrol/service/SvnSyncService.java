package org.intraweb.tools.versioncontrol.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.intraweb.tools.versioncontrol.entity.SvnCommitLogData;
import org.intraweb.tools.versioncontrol.entity.VersionControlStatus;
import org.intraweb.tools.versioncontrol.repository.interfaces.SvnCommitLogDataRepo;
import org.intraweb.tools.versioncontrol.repository.interfaces.VersionControlStatusRepo;
import org.intraweb.tools.versioncontrol.utils.GITConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SvnSyncService {

	@Value("${svn.user.name}")
	private String svnLogin;

	@Value("${svn.user.password}")
	private String svnPassword;

	@Value("${svn.executable}")
	private String SVN_EXE;

	@Autowired
	private VersionControlStatusRepo versionControlStatusRepo; 
	
	@Autowired
	private SvnCommitLogDataRepo svnCommitLogDataRepo;

	final String SVN_CLEAN = "cleanup";
	final String SVN_UPDATE = "update";

	@Scheduled(cron = "0 0/15 * * * *")
	public void updateAllSvnRepos() {

		List<String> svnList = new ArrayList<>();
		svnList.add(GITConstants.AC_SVN40);
		svnList.add(GITConstants.AC_SVN41);

		List<String> moduleList = new ArrayList<>();
		moduleList.add(GITConstants.COM);
		moduleList.add(GITConstants.CAM);
		moduleList.add(GITConstants.CBM);
		moduleList.add(GITConstants.CCM);
		moduleList.add(GITConstants.CFM);

		svnList.forEach(svnType -> {
			moduleList.forEach(moduleType -> {
				Thread svnThread = new Thread(new Runnable() {
					@Override
					public void run() {					
						prepareForSvnUpdate(svnType, moduleType);

					}
				});
				svnThread.start();
			});
		});
	}

	public VersionControlStatus syncServiceStart(String verType, String module) {
		VersionControlStatus existingVersionInfo = versionControlStatusRepo.findByVersionTypeAndModule(verType, module);
		if(!ObjectUtils.isEmpty(existingVersionInfo)) {
			existingVersionInfo.setSyncInProgress(true);
			existingVersionInfo.setLastSyncStartTime(new Date());
			return versionControlStatusRepo.save(existingVersionInfo);
		}

		VersionControlStatus newVcsBuilder = VersionControlStatus.builder()
				.versionType(verType)
				.module(module)
				.syncInProgress(true)
				.lastSyncStartTime(new Date())
				.lastSyncEndTime(null)
				.build();
		return versionControlStatusRepo.save(newVcsBuilder);
	}

	public void syncServiceEnd(VersionControlStatus vcs, List<String> svnUpdateResult) {
		vcs.setSyncInProgress(false);
		vcs.setLastSyncEndTime(new Date());
		vcs.setSvnUpdateResult(svnUpdateResult);
		versionControlStatusRepo.save(vcs);
	}

	public List<String> prepareForSvnUpdate(String svnType, String module) {
		log.info("Starting Svn Update for ---->" +svnType +"//"+ module);
		String svnUrl="";
		String formSvnFilePath = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V";

		String svnNum = "40";
		if(svnType.equals(GITConstants.AC_SVN41)) {
			svnNum = "41";
		}

		switch (module.toUpperCase()) {
			case "COMMON":
			case "SHARE":
			case GITConstants.COM:
			case GITConstants.CAC:
				formSvnFilePath += svnNum+"\\"+GITConstants.COM+svnNum;
				break;

			case GITConstants.CAM:
				formSvnFilePath += svnNum+"\\"+GITConstants.CAM+svnNum;
				break;

			case GITConstants.CBM:
				formSvnFilePath += svnNum+"\\"+GITConstants.CBM+svnNum;
				break;

			case GITConstants.CCM:
				formSvnFilePath += svnNum+"\\"+GITConstants.CCM+svnNum;
				break;

			case GITConstants.CFM:
				formSvnFilePath += svnNum+"\\"+GITConstants.CFM+svnNum;
				break;
		}
		formSvnFilePath += "\\hue_client";
		
		//List<SvnCommitLogData> resData = new ArrayList<>();
		//SvnCommitLogger commitLog = new SvnCommitLogger();
		//commitLog.perfomrSvnLogUpdate(svnType, formSvnFilePath, resData);
		//svnCommitLogDataRepo.saveAll(resData);

		//VersionControlStatus vcs = syncServiceStart(svnType, module);

		List<String> svnUpdateResult = updateSvnCommandLine(formSvnFilePath);
		
		log.info("Sucessfully Updated  ---->" +svnType +"//"+ module);

	//	syncServiceEnd(vcs, svnUpdateResult);
		return svnUpdateResult;
	}

	
	private List<String> updateSvnCommandLine(String formSvnFilePath) {
		List<String> svnExecutionResult = new ArrayList<>();
		try {
			ProcessBuilder processBuilder = new ProcessBuilder();
			processBuilder.command("cmd.exe", "/c", "dir "+formSvnFilePath);
			processBuilder.start();
			processBuilder.directory(new File(formSvnFilePath));
			processBuilder. redirectErrorStream(true);

			processBuilder.command(SVN_EXE, SVN_CLEAN);
			Process cleanupResult = processBuilder.start();
			log.info(streamExecutedResult("CLEAN", cleanupResult).toString());

			processBuilder.command(SVN_EXE, SVN_UPDATE);
			Process updateResult = processBuilder.start();
			svnExecutionResult = streamExecutedResult("UPDATE", updateResult);
		} catch (IOException e) {
			e.printStackTrace();
			log.error("SVN process failed - "+ formSvnFilePath +"----"+ e.getMessage());
		}
		return svnExecutionResult;
	}

	public static List<String> streamExecutedResult(String type, Process result) {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(result.getInputStream()));
		List<String> linesList = new ArrayList<>();
		String line;
		try {
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		log.info(linesList.toString());
		return linesList;
	}

	//TODO: svnkit api to clean and update the code.
	/*private void updateSvn(String url, String formSvnFilePath) throws SVNException {

	  	@Value("${svn.url.com}")
		private String COM;

		@Value("${svn.url.cam}")
		private String CAM;

		@Value("${svn.url.cbm}")
		private String CBM;

		@Value("${svn.url.ccm}")
		private String CCM;

		@Value("${svn.url.cfm}")
		private String CFM;


	  switch (module) {
		case GITConstants.COM:
			svnUrl = COM+svnNum;
			break;

		case GITConstants.CAM:
			svnUrl = CAM+svnNum;
			break;

		case GITConstants.CBM:
			svnUrl = CBM+svnNum;
			break;

		case GITConstants.CCM:
			svnUrl = CCM+svnNum;
			break;

		case GITConstants.CFM:
			svnUrl = CFM+svnNum;
			break;
		}

		SVNRepository repository = SVNRepositoryFactory.create(SVNURL.parseURIDecoded(url));
		ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(svnLogin, svnPassword);
		repository.setAuthenticationManager(authManager);

		SVNClientManager ourClientManager = SVNClientManager.newInstance();
		ourClientManager.setAuthenticationManager(authManager);

		SVNUpdateClient updateClient = ourClientManager.getUpdateClient();
		updateClient.setIgnoreExternals(true);

		SVNWCClient workingCopy = ourClientManager.getWCClient();
		long latestRevision = repository.getLatestRevision();

		try {
			workingCopy.doCleanup(new File(formSvnFilePath), true);
		} catch (Exception e) {
			workingCopy.doCleanup(new File(formSvnFilePath));
		}

		//		workingCopy.doCleanup(new File(formSvnFilePath), false, true, false, false, false, true);
		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);
		//		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);

		System.out.print("revision info "+ latestRevision +"-------->"+ updatedRevision);
	}
	 */

}
