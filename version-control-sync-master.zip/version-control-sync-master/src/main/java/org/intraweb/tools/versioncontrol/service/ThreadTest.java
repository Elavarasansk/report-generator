package org.intraweb.tools.versioncontrol.service;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.versioncontrol.entity.CompileResultEntity;
import org.intraweb.tools.versioncontrol.utils.CompilerConstants;

public class ThreadTest {
	

	private static final String ERROR = "Error:";	
	private static final String HINT = "Hint:";	
	private static final String FATAL = "Fatal:";
	private static final String WARNING = "Warning:";
	private static final String FILE_NOT_FOUND = "File not found";
    private static final String NAMESPACE_DCU = "-NSsystem;vcl";

	public static void main(String[] args) throws InterruptedException  {
	
		
		
		Map<String,String> map = new HashMap<>();
		map.put("CbmJournalInput.dpr", "D:\\HUE\\WorkSpace\\Develop\\SVN\\V40\\CBM40\\hue_client\\delphi\\CBM\\CBMcommon\\Jnl\\Jnl20\\CbmJournal\\Input");
		map.put("CbmProc.dpr", "D:\\HUE\\WorkSpace\\Develop\\SVN\\V40\\CBM40\\hue_client\\delphi\\CBM\\CBMcommon\\CbmProc");
	//	map.put("CamLaIndecATermTtl03Neo.dpr", "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cam\\hue_client\\delphi\\CAM\\LA2\\Report\\IndecATermTotal\\03_AssetKind");

		map.entrySet().stream().forEach(data->{
		
		Thread t = new Thread(new Runnable() {

			@Override
			public void run() {
				ProcessBuilder processBuilder = new ProcessBuilder();
				
				try {
					DcuDeleteTest.cleanRepo("");
					Process p = null;
					processBuilder.directory(new File(data.getValue()));
					//		processBuilder.command("dcc32","-u","'C:\\\\Borland\\\\Delphi7\\\\lib';'C:\\\\Borland\\\\Delphi7\\\\lib\\\\Obj';'C:\\\\Borland\\\\Delphi7\\\\Bin';'C:\\\\Borland\\\\Delphi7\\\\Projects\\\\Bpl';'C:\\\\Borland\\\\Delphi7\\\\Rave5\\\\Lib';'C:\\\\Borland\\\\Delphi7\\\\Source\\\\Vcl';'C:\\\\Borland\\\\Delphi7\\\\Source\\\\ToolsAPI';'C:\\\\Borland\\\\Delphi7\\\\IntraWeb XI\\\\LibD7';'C:\\\\Borland\\\\Delphi7\\\\IntraWeb XI\\\\LibD7\\\\DUnit';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\company_client\\\\delphi';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\IntraWeb\\\\Lib';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\CfwClasses';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\ServerAccess';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\ServerAccess\\\\ZlibEx';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\ServerAccess\\\\Zlib';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Packages';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Packages\\\\Lib';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Packages\\\\_obj';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\AutoTest';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\Common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\Error';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\Defin';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\CommonComponents';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\CommonComponents\\\\Overwrite';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Common\\\\CommonHUEElements';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\common\\\\Misc';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Misc';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Recognition\\\\Common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Security';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Security\\\\BlowFish';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Security\\\\Hash';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Security\\\\Hash\\\\Hashes';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\Workflow';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_client\\\\delphi\\\\accommon\\\\ReportManager';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Class\\\\AP';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Class\\\\AR';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Class\\\\Common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Dialog';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Function';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\SearchFrm';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Frame';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Search';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Util';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_client\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Search\\\\Edt';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\CfwClasses';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\ServerAccess';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\ServerAccess\\\\ZlibEx';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\ServerAccess\\\\Zlib';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Packages';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Packages\\\\Lib';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Packages\\\\_obj';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\AutoTest';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\Common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\Error';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\Defin';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\CommonComponents';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\CommonComponents\\\\Overwrite';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Common\\\\CommonHUEElements';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\common\\\\Misc';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Misc';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Recognition\\\\Common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Security';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Security\\\\BlowFish';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Security\\\\Hash';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Security\\\\Hash\\\\Hashes';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Workflow';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\ReportManager';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Vcl';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Utils';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Resource\\\\icon';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\UserSession';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Form';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Rtl\\\\Win';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Rtl\\\\Sys';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cac\\\\hue_web\\\\delphi\\\\cvcommon\\\\Lib\\\\Rtl\\\\common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Class\\\\AP';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Class\\\\AR';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Class\\\\Common';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Dialog';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Function';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\SearchFrm';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Frame';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Search';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Util';'C:\\\\HUE\\\\WorkSpace\\\\Develop\\\\hue-ac-chennai-cbm\\\\hue_web\\\\delphi\\\\CBM\\\\Common\\\\Renovation\\\\Search\\\\Edt'");
					String pathList  = CompilerConstants.SVN40_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(";"));
					System.out.println(pathList);
					pathList = pathList.replace("COM40", "CBM40");
					processBuilder.command("dcc32","-u".concat(pathList),"-r".concat(pathList),"-B",data.getKey());
					processBuilder.start();
			    	 processBuilder.command("dcc32","-u".concat(pathList),"-r".concat(pathList),"-B",NAMESPACE_DCU,"-$O+","-$J+","-J","-I","-Q", data.getKey());
					processBuilder.redirectErrorStream(true);
					p =processBuilder.start();


					BufferedReader reader = new BufferedReader(
							new InputStreamReader(p.getInputStream()));
					List<String> linesList = new ArrayList<>();
					String line;
					while ((line = reader.readLine()) != null) {
						linesList.add(line);
					//	System.out.println(line);
					}
					List<String> errorList = new ArrayList<>();			
					List<String> fatalList = new ArrayList<>();			
					List<String> hintList = new ArrayList<>();			
					List<String> warningList = new ArrayList<>();

					linesList.stream().forEach(lne->{
						if(StringUtils.isNotEmpty(lne)){
							if(StringUtils.contains(lne, FATAL)){
								fatalList.add(lne);
							}else if(StringUtils.contains(lne, ERROR) || ( StringUtils.containsIgnoreCase(lne, FILE_NOT_FOUND) &&  StringUtils.containsIgnoreCase(lne, "dfm") )) {
								errorList.add(lne);
							}else if(StringUtils.contains(lne, WARNING)) {
								warningList.add(lne);
							}else if(StringUtils.contains(lne, HINT)) {
								hintList.add(lne);
							}
						}			
					});
					CompileResultEntity resultEntity  = CompileResultEntity
							.builder()
							.dprName(data.getKey())
							.dprPath("")
							.fatalList(fatalList)
							.errorList(errorList)
							.warningList(warningList)
							.hintList(hintList)
							.status(fatalList.isEmpty() && errorList.isEmpty())
							.build();

					System.out.println(resultEntity);
					p.destroy();
				} catch (IOException e) {	
					System.out.println("exception..");
					System.out.println(e.getMessage());
				}finally {
					//p.destroyForcibly();
				}
				
			}
			
		});	

		t.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	});
		
	}

}
