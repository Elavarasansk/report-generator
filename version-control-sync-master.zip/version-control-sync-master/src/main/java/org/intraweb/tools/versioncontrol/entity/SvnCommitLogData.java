package org.intraweb.tools.versioncontrol.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="svn_commit_log")
public class SvnCommitLogData {
	@Id
	private ObjectId id;
	
	@Indexed(unique=true)
	private String filePath;
	
	private String vcsType;
	private String fileName;
	private List<SvnCommitLog> commitLogData;
}
