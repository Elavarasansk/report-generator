package org.intraweb.tools.versioncontrol.repository.interfaces;

import java.util.List;

import org.intraweb.tools.versioncontrol.entity.Svn41CompileResult;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface Svn41CompileResultRepo extends MongoRepository<Svn41CompileResult, String>{

	Svn41CompileResult findByDprNameAndModule(String dprName, String module);
	
	Svn41CompileResult findByDprNameAndModuleIn(String dprName, List<String> moduleList);
	
	Svn41CompileResult findByStatus(String status);
	
	void deleteByModuleIn(String module);

	List<Svn41CompileResult> findByModuleAndStatus(String module, String status);
}
