package org.intraweb.tools.versioncontrol.repository.interfaces;

import org.intraweb.tools.versioncontrol.entity.VersionControlStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface VersionControlStatusRepo extends MongoRepository<VersionControlStatus, String> {
	
	VersionControlStatus findByVersionTypeAndModule(String version, String moduleName);

}
