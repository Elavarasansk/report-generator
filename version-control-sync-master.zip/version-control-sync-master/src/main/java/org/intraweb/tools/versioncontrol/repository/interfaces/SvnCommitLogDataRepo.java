package org.intraweb.tools.versioncontrol.repository.interfaces;

import org.intraweb.tools.versioncontrol.entity.SvnCommitLogData;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SvnCommitLogDataRepo extends MongoRepository<SvnCommitLogData, String> {
	
}
