package org.intraweb.tools.versioncontrol.repository.interfaces;


import java.util.List;

import org.intraweb.tools.versioncontrol.entity.CortexDprDetails;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CortexDprDetailsRepo extends MongoRepository<CortexDprDetails, String>{
	
	List<CortexDprDetails> findByDprstatusIn(List<String> cortexStatusList);

}