package org.intraweb.tools.versioncontrol.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.versioncontrol.entity.CompileResultEntity;
import org.intraweb.tools.versioncontrol.entity.CompileStatusEntity;
import org.intraweb.tools.versioncontrol.entity.CompilerDetails;
import org.intraweb.tools.versioncontrol.entity.DprAssignmentOrder;
import org.intraweb.tools.versioncontrol.repository.interfaces.CompilerRepo;
import org.intraweb.tools.versioncontrol.repository.interfaces.DprAssignmentOrderRepo;
//import org.intraweb.tools.versioncontrol.repository.interfaces.MongoDataService;
import org.intraweb.tools.versioncontrol.utils.CompilerConstants;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DelphiPostCompileService {

	private static final String ERROR = "Error:";	
	private static final String HINT = "Hint:";	
	private static final String FATAL = "Fatal:";
	private static final String WARNING = "Warning:";
	private static final String FILE_NOT_FOUND = "File not found";
	private static final String AC_GIT = "AC_GIT";	
	private static final String AC_SVN40 = "AC_SVN40";
	private static final String AC_SVN41 = "AC_SVN41";
	private static final String DPR = ".dpr";
	private static final String OPTION_2 = "-Q";
	private static final String OPTION_1 = "-I";
	private static final String COMPILER = "C:\\Borland\\Delphi7\\Bin\\DCC32.EXE";
	private static final String SPLIT = ";";
	private static final String BUILD = "-B";
	private static final String ASSIGNABLE_TYPED_CONSTANT = "-$J+";
	private static final String GENERATE_OBJ = "-J";
	private static final String OPTIMIZATION = "-$O+";
    private static final String NAMESPACE_DCU = "-NSsystem;vcl";
    private static final String FATAL_JA = "�v���I�G���[";
	private static final String ERROR_JA = "�G���[";


    @Autowired
	private SvnCleanService svnCleanService;

	@Autowired
	private DprAssignmentOrderRepo dprAssignmentOrderRepo;

	@Autowired
	private CompilerRepo compilerRepo;

	@Autowired
	private SvnSyncService svnSyncService;

	@Autowired
	private GitSyncService gitSyncService;


	public CompileResultEntity executeDprFromGit(String dprName,String module,String versionControl) {	
		String execDprName = FilenameUtils.isExtension(dprName, DPR.replace(".", "")) ? dprName : dprName.concat(DPR) ;

		List<String> moduleList = new ArrayList<>();
		moduleList.add(module.toUpperCase());
		if(module.toUpperCase().equals("CAC") || module.toUpperCase().equals("COM")) {
			moduleList.add("common");
			moduleList.add("share");
		}

		DprAssignmentOrder dprDetails = dprAssignmentOrderRepo.findByDprNameAndModuleIn(dprName.replace(DPR, ""), moduleList);

		if(Objects.isNull(dprDetails)) {
			CompileResultEntity result =  formCompileResult(Arrays.asList("File Not Found"),execDprName,"",module);
			result.setCompiledList("File Not Found");
			result.setStatus(false);
			return result;
		}
		String dprPath = formGitFilePath(dprDetails.getDprPath(), dprDetails.getModule());

		if(!checkIfDprExists(dprPath+"\\"+execDprName)) {
			if(module.toLowerCase().startsWith("cam")) {
				gitSyncService.camGitPull();
			} else if(module.toLowerCase().startsWith("cbm")) {
				gitSyncService.cbmGitPull();
			} else if(module.toLowerCase().startsWith("ccm")) {
				gitSyncService.ccmGitPull();
			} else if(module.toLowerCase().startsWith("cfm")) {
				gitSyncService.cfmGitPull();
			} else if(module.toLowerCase().startsWith("share") || module.toLowerCase().startsWith("common") || 
					module.toLowerCase().startsWith("com")) {
				gitSyncService.cacGitPull();
			}
		};

		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			Date compilerStartTime = new Date();
			processBuilder.directory(new File(dprPath));
			String pathList  = CompilerConstants.GIT_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
			/*To generate DCU.*/
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),BUILD,execDprName);
			processBuilder.start();
			/*To execute DPR.*/
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),OPTIMIZATION,ASSIGNABLE_TYPED_CONSTANT,GENERATE_OBJ,OPTION_1,OPTION_2,execDprName);
			processBuilder.redirectErrorStream(true);
			p =processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
			Date compilerEndTime = new Date();
			//TODO need fix
			//insertCompilerExec(execDprName, dprPath, module, versionControl, linesList, compilerStartTime, compilerEndTime);
			return formCompileResult(linesList,execDprName,dprPath,module);
		} catch (IOException e) {	
			log.error("Exception occured while processing :",e.getMessage());
			CompileResultEntity result =  formCompileResult(Arrays.asList(e.getMessage()),execDprName,dprPath,module);
			result.setCompiledList(e.getMessage());
			result.setStatus(false);
			return result;

		}finally {
			try {
				p.destroy();
			}catch(Exception e) {
				log.error("Prcoess failed "+e.getMessage());
			}
		}
	}

	private boolean checkIfDprExists(String dprPath) {
		File dprLocation = new File(dprPath);
		return dprLocation.exists();
	}


	public CompileResultEntity executeDprFromSvn(String dprName,String module,String versionControl) {
		String execDprName = FilenameUtils.isExtension(dprName, DPR.replace(".", "")) ? dprName : dprName.concat(DPR) ;

		List<String> moduleList = new ArrayList<>();
		moduleList.add(module.toUpperCase());
		if(module.toUpperCase().equals("CAC") || module.toUpperCase().equals("COM")) {
			moduleList.add("common");
			moduleList.add("share");
			moduleList.add("COM");
			module = "COM";
		}

		DprAssignmentOrder dprDetails = dprAssignmentOrderRepo.findByDprNameAndModuleIn(dprName.replace(DPR, ""), moduleList);

		if(Objects.isNull(dprDetails)) {
			CompileResultEntity result =  formCompileResult(Arrays.asList("File Not Found"),execDprName,"",module);
			result.setCompiledList("File Not Found");
			result.setStatus(false);
			return result;
		}
		
		String dprPath = formSVNFilePath(dprDetails.getDprPath(), dprDetails.getModule(),versionControl);
		log.info("DPR Path :",dprPath);
		
		if(!checkIfDprExists(dprPath+"\\"+execDprName)) {
			svnSyncService.prepareForSvnUpdate(versionControl, module);
		};

		
		//TODO clean .dcu files.
		svnCleanService.cleanRepo(module.toUpperCase() , versionControl);
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		String pathList = StringUtils.EMPTY;
		switch(versionControl) {
			case AC_SVN40:
				pathList = CompilerConstants.SVN40_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
				pathList = module.equals("com") ?  pathList   : pathList.replace("COM40", module+40);  
				break;
			case AC_SVN41:
				pathList = CompilerConstants.SVN41_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
				pathList = module.equals("com") ?  pathList   : pathList.replace("COM41", module+41);   
				break;
		}
		try {
			Date compilerStartTime = new Date();
			processBuilder.directory(new File(dprPath));
			/*To generate DCU.*/
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),BUILD,execDprName);
			processBuilder.start();
			/*To execute DPR.*/
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),OPTIMIZATION,ASSIGNABLE_TYPED_CONSTANT,GENERATE_OBJ,OPTION_1,OPTION_2,execDprName);
			processBuilder.redirectErrorStream(true);
			p =processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
			Date compilerEndTime = new Date();
			//TODO need fix
			//insertCompilerExec(execDprName, dprPath, module, versionControl, linesList, compilerStartTime, compilerEndTime);
			return formCompileResult(linesList,execDprName,dprPath,module);
		} catch (IOException e) {	
			log.error("Exception occured while processing :",e.getMessage());
			CompileResultEntity result =  formCompileResult(Arrays.asList(e.getMessage()),execDprName,dprPath,module);
			result.setCompiledList(e.getMessage());
			result.setStatus(false);
			return result;

		}finally {
			try {
				p.destroy();
			}catch(Exception e) {
				log.error("Prcoess failed "+e.getMessage());
			}
		}
	}


	public void insertCompilerExec(String dprName,String dprPath,String module,String versionControl,List<String> linesList,Date compilerStartTime,Date compilerEndTime) {

		CompileStatusEntity  compilerEntity=compilerRepo.findByDprName(dprName);
		List<CompilerDetails> resultList = Arrays.asList(CompilerDetails.builder().compilerEndTime(compilerEndTime).compilerStartTime(compilerStartTime).linesList(linesList).build());
		CompileStatusEntity entity = CompileStatusEntity.builder()
				.dprName(dprName)
				.dprPath(dprPath)
				.module(module).build();
		if(Objects.nonNull(compilerEntity)) {
			BeanUtils.copyProperties(compilerEntity, entity);
		}
		switch(versionControl.toUpperCase()) {
			case AC_GIT:
				List<CompilerDetails> gitList = CollectionUtils.isNotEmpty(entity.getGitList()) ? entity.getGitList() : new ArrayList<>();
				gitList.addAll(resultList);
				entity.setGitList(gitList);
				break;
			case AC_SVN40:
				List<CompilerDetails> svn40List =  CollectionUtils.isNotEmpty(entity.getSvn40List()) ? entity.getSvn40List() : new ArrayList<>();
				svn40List.addAll(resultList);
				entity.setSvn40List(svn40List);
				break;
			case AC_SVN41:
				List<CompilerDetails> svn41List =  CollectionUtils.isNotEmpty(entity.getSvn41List()) ? entity.getSvn41List() : new ArrayList<>();
				svn41List.addAll(resultList);
				entity.setSvn40List(svn41List);
				break;
			default:
				break;
		}
		compilerRepo.save(entity);
	}




	public CompileResultEntity formCompileResult(List<String> linesList,String dprName,String dprPath,String module) {
		List<String> errorList = new ArrayList<>();			
		List<String> fatalList =  new ArrayList<>();		
		List<String> hintList =  new ArrayList<>();					
		List<String> warningList =  new ArrayList<>();		
		StringBuilder compiledList = new StringBuilder();
		Collections.reverse(linesList);
		linesList.stream().forEach(lne->{
			compiledList.append(lne);
			compiledList.append("\n");
			if(StringUtils.isNotEmpty(lne)){
				if(StringUtils.contains(lne, FATAL) || StringUtils.contains(lne, FATAL_JA) ){
					fatalList.add(lne);
				}else if(StringUtils.contains(lne, ERROR) || ( StringUtils.containsIgnoreCase(lne, FILE_NOT_FOUND) &&  StringUtils.containsIgnoreCase(lne, "dfm") ) || StringUtils.contains(lne, ERROR_JA) ) {
					errorList.add(lne);
				}else if(StringUtils.contains(lne, WARNING)) {
					warningList.add(lne);
				}else if(StringUtils.contains(lne, HINT)) {
					hintList.add(lne);

				}
			}			
		});		
		return CompileResultEntity
				.builder()
				.dprName(dprName)
				.dprPath(dprPath)
				.module(module)
				.fatalList(fatalList)
				.errorList(errorList)
				.warningList(warningList)
				.hintList(hintList)
				.compiledList(compiledList.toString())
				.status(fatalList.isEmpty() && errorList.isEmpty() )
				.build();

	}


	public String formSVNFilePath(String dprPath,String module, String versionControl) { 
		String formSvnFilePath = "\\D:\\HUE\\WorkSpace\\Develop\\SVN\\V";
		String svnNum = "40";
		if(versionControl.equals(AC_SVN41)) {
			svnNum = "41";
		}	
		svnNum+="\\";
		if(module.toLowerCase().startsWith("cam")) {
			formSvnFilePath += svnNum+"CAM"+svnNum;
		} else if(module.toLowerCase().startsWith("cbm")) {
			formSvnFilePath += svnNum+"CBM"+svnNum;
		} else if(module.toLowerCase().startsWith("ccm")) {
			formSvnFilePath += svnNum+"CCM"+svnNum;
		} else if(module.toLowerCase().startsWith("cfm")) {
			formSvnFilePath += svnNum+"CFM"+svnNum;
		} else if(module.toLowerCase().startsWith("share") || module.toLowerCase().startsWith("common") || 
				module.toLowerCase().startsWith("com")) {
			formSvnFilePath += svnNum+"COM"+svnNum;
		}

		String replacePath = dprPath.replace("/", "\\");
		formSvnFilePath += "hue_client\\delphi\\"+replacePath;
		return FilenameUtils.getPath(formSvnFilePath);

	}



	public String formGitFilePath(String dprPath,String module) {
		String searchPath = "\\C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-";		
		if(module.toLowerCase().startsWith("cam")) {
			searchPath += "cam\\";
		} else if(module.toLowerCase().startsWith("cbm")) {
			searchPath += "cbm\\";
		} else if(module.toLowerCase().startsWith("ccm")) {
			searchPath += "ccm\\";
		} else if(module.toLowerCase().startsWith("cfm")) {
			searchPath += "cfm\\";
		} else if(module.toLowerCase().startsWith("share") || module.toLowerCase().startsWith("common") || 
				module.toLowerCase().startsWith("com")) {
			searchPath += "cac\\";
		}
		String replacePath = dprPath.replace("/", "\\");
		searchPath += "hue_client\\delphi\\"+replacePath;
		return FilenameUtils.getPath(searchPath);
	}


}
