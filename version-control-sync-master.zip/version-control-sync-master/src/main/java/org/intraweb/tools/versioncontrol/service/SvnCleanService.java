package org.intraweb.tools.versioncontrol.service;

import java.io.File;
import java.util.Arrays;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.versioncontrol.utils.GITConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class SvnCleanService {

	@Value("${svn40.path}")
	private String svn40Url;


	@Value("${svn41.path}")
	private String svn41Url;



	public void cleanRepo(String repo, String versionControl) {
		//	repo = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V40\\CBM40\\hue_client\\delphi\\CBM";
		repo = Arrays.asList("COMMON,SHARE","CAC","COM").contains(repo) ? "COM" : repo ; 
		String absoluteRepoPath = formPath(repo, versionControl); 
		File[] fileList = new File(absoluteRepoPath).listFiles();
		for(File file : fileList ) {
			findAndDelete(file.listFiles());
		}
	}

	private  void findAndDelete(File[] fileList) {
		for(File file : fileList ) {
			if(file.isDirectory()) {
				findAndDelete(file.listFiles());
			}
			if(FilenameUtils.isExtension(file.getName(),"dcu") || FilenameUtils.isExtension(file.getName(),"cfg")) {
				FileUtils.deleteQuietly(file);
			}

		}
	}
	
	
	
	private String formPath(String repo, String versionControl ) {
		String absolutePath = StringUtils.EMPTY ;
		switch(versionControl) {
		case GITConstants.AC_SVN40:
			absolutePath = svn40Url+repo+"40\\hue_client\\delphi\\";
			break;
		case GITConstants.AC_SVN41:
			absolutePath = svn41Url+repo+"41\\hue_client\\delphi\\";
			break;
		}
		
		return absolutePath; 
		
	}
	

}



/*public void cleanAllSvn40Repo() {
	for(String repo:GITConstants.SVN_CLEAN_LIST ) {
		switch(repo) {
		case GITConstants.COM:
			cleanRepo(svn40Url+repo+"40\\hue_client\\delphi\\common\\");
			cleanRepo(svn40Url+repo+"40\\hue_client\\delphi\\share\\");
			break;
		default:
			String repoPath = svn40Url+repo+"40\\hue_client\\delphi\\"+repo;
			cleanRepo(repoPath);
			break;
		}
	}
}

public void cleanAllSvn41Repo() {
	for(String repo:GITConstants.SVN_CLEAN_LIST ) {
		switch(repo) {
		case GITConstants.COM:
			cleanRepo(svn41Url+repo+"41\\hue_client\\delphi\\common\\");
			cleanRepo(svn41Url+repo+"41\\hue_client\\delphi\\share\\");
			break;
		default:
			String repoPath = svn41Url+repo+"41\\hue_client\\delphi\\"+repo;
			cleanRepo(repoPath);
			break;
		}
	}
}


*/
