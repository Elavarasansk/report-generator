package org.intraweb.tools.versioncontrol.utils;

public class FileWriteUtils {
	
	
	/*public void prepareFormsToTest() {
		List<Svn41CompileResult> formsToTest = dprDuplicateFormTestingRepo.findAll({"status":"fail"});

		List<List<String>> rows = new ArrayList<>();
		rows.add(Arrays.asList("dprName,module,status,dprExistsInPath,dprExists,compiledResult));
		formsToTest.forEach(x -> {
			List<String> row = new ArrayList<>();
			row.add(x.getDprName());
			row.add(x.getMoudle());
			row.add(x.getStatus());
			row.add(x.getDprExistsInPath());
			row.add(x.getDprExists());
			row.add(x.getCompiledResult());
			
			rows.add(row);
		});

		try {
			fileReadWriteService.writeToCsvFile("D:\\ToolOuput\\", "formsToTestLocalExe", rows);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}*/

	

}
