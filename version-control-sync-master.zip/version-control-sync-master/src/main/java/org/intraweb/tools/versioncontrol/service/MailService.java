package org.intraweb.tools.versioncontrol.service;

import java.util.Arrays;

import org.intraweb.tools.versioncontrol.entity.Svn40CompileResult;
import org.intraweb.tools.versioncontrol.utils.GITConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class MailService {

	@Value("${mail.url}")
	private String mailUrl;

	@Autowired
	private RestTemplate restTemplate;


	public void announceSvnGroupBuildTriggered(String versionControl){
		Svn40CompileResult existingDpr = Svn40CompileResult.builder().build();
		try {
			existingDpr.setVersionType( versionControl.equals(GITConstants.AC_SVN40 ) ?  "svn40" : "svn41" );
			existingDpr.setRequestType("React");
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<Svn40CompileResult> entity = new HttpEntity<Svn40CompileResult>(existingDpr,headers);
			restTemplate.exchange(mailUrl+"intraweb/mailsend", HttpMethod.POST, entity, String.class).getBody(); 
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Failed to send mail for "+ existingDpr);
		}	

	}


	public void sendSvnSummaryMail() {		
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			restTemplate.exchange(mailUrl+"intraweb/svn/build/summary/mail", HttpMethod.POST, null , String.class).getBody(); 

		}catch(Exception e) {
			e.printStackTrace();
			log.error("Failed to send summary mail "+e.getMessage());
		}	

	}





}
