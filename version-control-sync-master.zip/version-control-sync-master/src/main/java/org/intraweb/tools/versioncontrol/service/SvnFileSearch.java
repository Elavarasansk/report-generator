package org.intraweb.tools.versioncontrol.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.versioncontrol.utils.GITConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SvnFileSearch {
	
	@Value("${svn40.path}")
	private String svn40Path;

	@Value("${svn41.path}")
	private String svn41Path;
	
	public File multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException {
		String fileName = multipart.getOriginalFilename();
		File convFile = new File(System.getProperty("java.io.tmpdir")+"/"+fileName);
	    multipart.transferTo(convFile);
	    return convFile;
	}

	public List<List<String>> searchFilesInRepo(MultipartFile multipart, String gitType) throws InvalidFormatException, IOException {
		File worksheetFile = multipartToFile(multipart);

		List<List<String>> filesToCommit = new ArrayList<>();
		
		Workbook workbook = WorkbookFactory.create(worksheetFile);

		try {
			for(Sheet worksheet : workbook) {
				String sheetName = worksheet.getSheetName();
				switch (sheetName) {
					case "FileList":
						filesToCommit = getMyFileList(worksheet, gitType);
						break;	
					case "EditList":
						break;
					case "Otherimplements":
						break;
				}
			}
		} finally {
			workbook.close();
			worksheetFile.delete();
		}
		return filesToCommit;
	}

	private List<List<String>> getMyFileList(Sheet fileListSheet,String gitType) {
		DataFormatter dataFormatter = new DataFormatter();

		int fileNameCol = 3;
		int filePathCol = 34;
		int startRowIndex = 12;
		int endRowIndex = fileListSheet.getLastRowNum();

		List<String> commonFileNameList = new ArrayList<>();
		List<String> commonFilePathList = new ArrayList<>();

		List<String> fileNameList = new ArrayList<>();
		List<String> filePathList = new ArrayList<>();

		for(int i=startRowIndex; i<=endRowIndex; i++) {
			Cell fileNameCell = fileListSheet.getRow(i).getCell(fileNameCol);
			Cell filePathCell = fileListSheet.getRow(i).getCell(filePathCol);

			String pasFileName = dataFormatter.formatCellValue(fileNameCell);
			String pasFilePath = dataFormatter.formatCellValue(filePathCell);
			
			if(pasFilePath.isEmpty()) {
				continue;
			}

			if(pasFilePath.startsWith("accommon")) {
				commonFileNameList.add(pasFileName);
				commonFilePathList.add(pasFilePath);
			} else {
				fileNameList.add(pasFileName);
				filePathList.add(pasFilePath);
			}
		}
		return checkFileExists(fileNameList, filePathList, gitType);
	}

	private List<List<String>> checkFileExists(List<String> nameList, List<String> pathList, String gitType) {
		List<String> gitFilePathAdder = new ArrayList<>();
		List<String> existingGitFiles = new ArrayList<>();
		for(String actualFilePath: pathList) {
			
			String searchPath = svn40Path;
			if(gitType.equals(GITConstants.AC_SVN41)) {
				searchPath = svn41Path;
			}
			
			if(actualFilePath.toLowerCase().startsWith("cam")) {
				searchPath += "cam";
			} else if(actualFilePath.toLowerCase().startsWith("cbm")) {
				searchPath += "cbm";
			} else if(actualFilePath.toLowerCase().startsWith("ccm")) {
				searchPath += "ccm";
			} else if(actualFilePath.toLowerCase().startsWith("cfm")) {
				searchPath += "cfm";
			} else if(actualFilePath.toLowerCase().startsWith("cfm")) {
				searchPath += "cfm";
			} else if(actualFilePath.toLowerCase().startsWith("share")) {
				searchPath += "com";
			}
			
			if(gitType.equals(GITConstants.AC_SVN40)) {
				searchPath += "40\\";
			} else {
				searchPath += "41\\";
			}
			
			searchPath += "hue_client\\delphi\\"+actualFilePath;
			File gitFiles = new File(searchPath);

			if (!gitFiles.exists()) {
				gitFilePathAdder.add("git add hue_client\\delphi\\"+actualFilePath); // hue-client changed to hue_client
			} else {
				existingGitFiles.add(actualFilePath);
			}
		}
		List<List<String>> allFiles = new ArrayList<>();
		allFiles.add(gitFilePathAdder);
		allFiles.add(existingGitFiles);
		log.info(gitType + " File Check success");
		return allFiles;
	}
}
