package org.intraweb.tools.versioncontrol.dto.entity;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Entity
@Table(name = "test_result_details")
public class TestResultDetails implements Serializable {

	private static final long serialVersionUID = -1L;

	@Id
	private Long id;
	
	private String testerId;
	private String questionId;
	private String category;
	private String rightAnswer;
	private String wrongAnswer;
	private String unanswer;
	
	@Column(unique = true)
	private int autoId;
	private String percent;
	private String resper;
	
	@CreationTimestamp
	private Date testDate;
	private String testName;
	private String actionMode;
}
