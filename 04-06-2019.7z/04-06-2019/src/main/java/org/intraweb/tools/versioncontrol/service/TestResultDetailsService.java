package org.intraweb.tools.versioncontrol.service;


import org.intraweb.tools.versioncontrol.dto.entity.TestResultDetails;
import org.intraweb.tools.versioncontrol.dto.repository.TestResultDetailsRepository;
import org.intraweb.tools.versioncontrol.dto.vo.TestResultDetailsVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestResultDetailsService {

	@Autowired
	private TestResultDetailsRepository testResultDetailsRepository;
	
	public void getTestResultDetails(TestResultDetailsVo testResultDetailsVo) {
		TestResultDetails resultData = testResultDetailsRepository.findByAutoId(testResultDetailsVo.getAutoId());
		
		
		
	}
	
}
