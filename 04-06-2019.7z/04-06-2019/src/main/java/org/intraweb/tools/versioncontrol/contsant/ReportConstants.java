package org.intraweb.tools.versioncontrol.contsant;



public class ReportConstants {
	
	public static final String RIGHT_ANSWER = "Right Answer";
	public static final String WRONG_ANSWER = "Wrong Answer";
	public static final String RESOURCES = "src/main/resources/";	
	public static final String MAIN_REPORT = RESOURCES+"design/report.jrxml";
	public static final String SUB_REPORT = RESOURCES+"design/sub_report.jrxml";
	public static final String PDF = ".pdf";
	public static final String PDF_NAME = "doc"+PDF;









}
