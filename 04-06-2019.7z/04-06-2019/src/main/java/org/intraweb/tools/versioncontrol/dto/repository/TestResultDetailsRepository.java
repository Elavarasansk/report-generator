package org.intraweb.tools.versioncontrol.dto.repository;


import org.intraweb.tools.versioncontrol.dto.entity.TestResultDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface TestResultDetailsRepository extends JpaRepository<TestResultDetails, String> {

	TestResultDetails findById(Long testId);
	
	TestResultDetails findByAutoId(int autoId);
	
}