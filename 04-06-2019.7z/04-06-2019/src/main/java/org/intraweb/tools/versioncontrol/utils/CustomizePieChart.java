package org.intraweb.tools.versioncontrol.utils;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

import org.intraweb.tools.versioncontrol.contsant.ReportConstants;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.general.PieDataset;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRAbstractChartCustomizer;
import net.sf.jasperreports.engine.JRChart;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;

@Slf4j
//Specify the package name for customizerClass property in the report.jrxml file.
public class CustomizePieChart extends JRAbstractChartCustomizer  {

	public static JasperReport getJasperReport() {
		JasperReport jasperReport = null;		try {
			jasperReport = JasperCompileManager.compileReport(ReportConstants.MAIN_REPORT);
			return jasperReport;
		}catch(Exception e) {
			log.error("Exception while generating report "+e.getMessage());
		}
		return jasperReport;

	}

	@Override
	public void customize(JFreeChart chart, JRChart jasperChart) {
		// Check the type of plot
		Plot plot = chart.getPlot();
		if (plot instanceof PiePlot) {
			PiePlot piePlot = (PiePlot) plot;   
			Map<String, Color> colorMap = new HashMap<>();
			colorMap.put(ReportConstants.RIGHT_ANSWER,Color.GREEN);
			colorMap.put(ReportConstants.WRONG_ANSWER, Color.RED);     
			PieDataset dataset = piePlot.getDataset();   
			//Assign color to each section of pie chart based on value of key
			for (int i = 0; i < dataset.getItemCount(); i++) {				
				setSectionColor(piePlot, dataset.getKey(i),ReportConstants.RIGHT_ANSWER,colorMap);
				setSectionColor(piePlot, dataset.getKey(i),ReportConstants.WRONG_ANSWER,colorMap);
			}

		}

	}

	private void setSectionColor(PiePlot piePlot, Comparable key, String parterName, Map<String, Color> colorMap) {			
		if(key.toString().contains(parterName)) {
			piePlot.setSectionPaint(key, colorMap.get(parterName));
		}  					
	}
}
