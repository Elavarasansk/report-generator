package org.intraweb.tools.versioncontrol.dto.vo;


import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestResultDetailsVo {
	private Long id;
	private String testerId;
	private String questionId;
	private String category;
	private String rightAnswer;
	private String wrongAnswer;
	private String unanswer;
	private int autoId;
	private String percent;
	private String resper;
	private Date testDate;
	private String testName;
	private String actionMode;
}
