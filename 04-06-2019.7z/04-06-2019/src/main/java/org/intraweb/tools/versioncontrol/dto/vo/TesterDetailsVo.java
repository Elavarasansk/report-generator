package org.intraweb.tools.versioncontrol.dto.vo;


import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TesterDetailsVo {

	private Long id;

	private String testId;

	private String testerName;

	private String password;

	private String emailId;

	private String category;

	private Date expiryDate;

	private Date createdDate;	

	private String createdBy;

	private String questionId;

	private String testName;	

	private Long questionNo;	

	private Long status;






}
