package org.intraweb.tools.versioncontrol.dto.vo;



import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestAttendDetailsVo {

	private Long id;
	
	private String testId;

	private Long questionId;
	
	private String categoryName;
	
	private Date attendDate;

	private String question;

	private String answer;
	
	private String actionMode;

}