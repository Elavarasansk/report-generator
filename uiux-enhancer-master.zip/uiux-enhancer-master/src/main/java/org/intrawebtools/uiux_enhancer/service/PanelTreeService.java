package org.intrawebtools.uiux_enhancer.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.intrawebtools.uiux_enhancer.consts.SelfCheckConst;
import org.intrawebtools.uiux_enhancer.entity.ObjectTreeEntity;
import org.intrawebtools.uiux_enhancer.entity.ObjectTreeListEntity;
import org.intrawebtools.uiux_enhancer.entity.TreeEntity;
import org.intrawebtools.uiux_enhancer.enums.ComponentType;
import org.intrawebtools.uiux_enhancer.utils.UIUXEnhancementUtils;

public class PanelTreeService extends UIUXEnhancementUtils {

  public TreeEntity rootNode = null;

  public void makePanelTree(Map<ComponentType, ObjectTreeListEntity> componentMap,
      Map<String, Map<String, Integer>> panelPositionMap) {
    List<ObjectTreeEntity> panelComponents = new ArrayList<>();
    List<ComponentType> componentsTypeList = Arrays.asList(ComponentType.PANEL, ComponentType.COOLBAR,
        ComponentType.TOOLBAR, ComponentType.STATUSBAR, ComponentType.SCROLLBOX, ComponentType.TAB);
    for (ComponentType type : componentsTypeList) {
      panelComponents.addAll(
          componentMap.containsKey(type) ? componentMap.get(type).getObjectTreeList() : Collections.emptyList());
    }
    Collections.sort(panelComponents, (component1, component2) -> {
      return component1.getLevel() - component2.getLevel();
    });
    for (ObjectTreeEntity panel : panelComponents) {
      String parent = getParentComponentName(panel.getParents(), panel.getLevel());
      Map<String, Object> propertiesMap = panel.getComponentPropertyEntity().getProperties();
      int top = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
      int left = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_LEFT);
      makeTree(parent, panel.getName(), top, left, panelPositionMap);
    }
  }

  private void makeTree(String parentPanel, String panelName, int panelTopValue, int panelLeftValue,
      Map<String, Map<String, Integer>> panelPositionMap) {
    TreeEntity panelNode = new TreeEntity(panelName, new Integer(panelTopValue), new Integer(panelLeftValue));
    TreeEntity parentPanelNode = new TreeEntity(parentPanel, new Integer(0), new Integer(0));
    if (rootNode == null) {
      List<TreeEntity> childPanelList = new ArrayList<>();
      Map<String, Integer> positionMap = new HashMap<>();
      panelNode.top = new Integer(parentPanelNode.top.intValue() + panelNode.top.intValue());
      panelNode.left = new Integer(parentPanelNode.left.intValue() + panelNode.left.intValue());
      childPanelList.add(panelNode);
      parentPanelNode.childPanel = childPanelList;
      rootNode = parentPanelNode;
      positionMap.put("Top", parentPanelNode.top);
      positionMap.put("Left", parentPanelNode.left);
      panelPositionMap.put(parentPanelNode.panelName, positionMap);
      positionMap = new HashMap<>();
      positionMap.put("Top", panelNode.top);
      positionMap.put("Left", panelNode.left);
      panelPositionMap.put(panelNode.panelName, positionMap);
    } else {
      TreeEntity currentNode = rootNode;
      alreadyParentNodePresent(currentNode, parentPanelNode, panelNode, false, panelPositionMap);
    }
  }

  private boolean alreadyParentNodePresent(TreeEntity currentNode, TreeEntity parentPanelNode,
      TreeEntity panelNode, boolean findFlag, Map<String, Map<String, Integer>> panelPositionMap) {
    if (findFlag) {
      return true;
    }
    while (currentNode != null) {
      if (currentNode.panelName.equals(parentPanelNode.panelName)) {
        Map<String, Integer> positionMap = new HashMap<>();
        List<TreeEntity> childPanelList = currentNode.childPanel != null ? currentNode.childPanel : new ArrayList<>();
        panelNode.top = new Integer(currentNode.top.intValue() + panelNode.top.intValue());
        panelNode.left = new Integer(currentNode.left.intValue() + panelNode.left.intValue());
        childPanelList.add(panelNode);
        currentNode.childPanel = childPanelList;
        positionMap.put("Top", panelNode.top);
        positionMap.put("Left", panelNode.left);
        panelPositionMap.put(panelNode.panelName, positionMap);
        findFlag = true;
        return true;
      } else {
        List<TreeEntity> childPanelList = currentNode.childPanel != null ? currentNode.childPanel : new ArrayList<>();
        for (TreeEntity childPanel : childPanelList) {
          alreadyParentNodePresent(childPanel, parentPanelNode, panelNode, findFlag, panelPositionMap);
        }
        return false;
      }
    }
    return false;
  }

}
