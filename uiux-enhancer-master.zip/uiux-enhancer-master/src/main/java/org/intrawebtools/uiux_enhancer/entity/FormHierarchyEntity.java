package org.intrawebtools.uiux_enhancer.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.intrawebtools.uiux_enhancer.enums.LayoutPattern;
import org.intrawebtools.uiux_enhancer.enums.LayoutType;
import org.intrawebtools.uiux_enhancer.utils.PoiUtils;

import lombok.Data;

@Data
public class FormHierarchyEntity {
	private String no;
	private String directory;
	private String fileName;
	private boolean isForm;
	private String formLink;
	private String formAssignee;
	private boolean isFormTarget;
	private String formStatus;
	private String pluginId;
	private String pluginLink;
	private String pluginAssignee;
	private boolean isPluginTarget;
	private String pluginStatus;
	private String listDetailFlg;
	private String sqlTag;
	private String className;
	private String frameWork;
	private LayoutType layoutType;
	private LayoutPattern layoutPattern;
	private String filePath;

	// Edit
	private Map<String, EditSheetEntity> editMap;
	
	// Business Source
	private BusinessSourceEntity businessSourceEntity;
	
	// Hierarchy
	private int level;
	private String parentFormPathKey;
	private boolean isChild;
	
	public FormHierarchyEntity(List<String> row) {
		this.no = row.get(1).trim();
		this.directory = row.get(2).trim();
		this.fileName = row.get(3).trim();
		this.isForm = PoiUtils.parseCellValueToBool(row.get(4).trim());
		this.formLink = row.get(5).trim();
		this.formAssignee = row.get(6).trim();
		this.isFormTarget = PoiUtils.parseCellValueToBool(row.get(7).trim());
		this.formStatus = row.get(8).trim();
		this.pluginId = row.get(9).trim();
		this.pluginLink = row.get(10).trim();
		this.pluginAssignee = row.get(11).trim();
		this.isPluginTarget = PoiUtils.parseCellValueToBool(row.get(12).trim());
		this.pluginStatus = row.get(13).trim();
		this.listDetailFlg = row.get(14).trim();
		this.sqlTag = row.get(15).trim();
		this.className = row.get(16).trim();
		this.frameWork = row.get(17).trim();
		this.layoutType = LayoutType.getEnum(row.get(18).trim());
		this.layoutPattern = LayoutPattern.getEnum(row.get(19).trim());
		this.filePath = row.get(34).trim();

		this.editMap = new HashMap<String, EditSheetEntity>();
		this.businessSourceEntity = null;
		
		this.level = 0;
		this.isChild = false;
		this.parentFormPathKey = null;
		
		for (int i = 20; i < 34; i++) {
			if (row.get(i).trim().toLowerCase().equals(this.className.toLowerCase())) {
				this.level = i - 20;
				break;
			}
		}
	}
}
