package org.intrawebtools.uiux_enhancer.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.bson.Document;
import org.intrawebtools.uiux_enhancer.entity.ObjectTreeListEntity;
import org.intrawebtools.uiux_enhancer.entity.ResultEntity;
import org.intrawebtools.uiux_enhancer.enums.LayoutType;
import org.intrawebtools.uiux_enhancer.enums.License;
import org.intrawebtools.uiux_enhancer.service.FileWriteService;
import org.intrawebtools.uiux_enhancer.service.OutputService;
import org.intrawebtools.uiux_enhancer.service.UiUxEnhancementFileService;
import org.intrawebtools.uiux_enhancer.service.UiUxEnhancementService;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UiUxEnhancerMainController {

	public void start(String inputPath, String folderPath, String inputType, String formType, String licenseField) {

		if (inputType.equals("worksheet")) {

			log.info("******************************** Execution Started ****************************************");

			Map<String, File> targetMap = new HashMap<String, File>();

			UiUxEnhancementService service = new UiUxEnhancementService();

			// targetMap.put("one", new File(
			// "C:\\Users\\kasthuva\\Documents\\FundCompCmItemIoView\\Worksheet_LaAssetListNeo_20190214.xls"));

			targetMap.put("one", new File(inputPath));

			service.doChange(targetMap, folderPath);

			log.info("****************************** Execution Finished********************************************");

			log.info("Output Sheet will be generated in  the same directory of tool");

			log.info("New DFM File will be generated in the same directory of Old DFM file");

		} else if (inputType.equals("dfm")) {

			performSingleDfmValidation(inputPath, formType, licenseField);

		} else if (inputType.equals("dpr")) {

			MongoClient client = new MongoClient("192.168.57.67", 27017);
			MongoDatabase database = client.getDatabase("intraweb-tools");

			MongoCollection<Document> collection = database.getCollection("dpr_pasfile_details_paused");

			try {
				File inputFile = new File(inputPath);

				if (!inputFile.exists()) {
					log.error(inputFile.getName() + " does not exists");
					return;
				}

				Document query = new Document("dprName", inputFile.getName().replaceAll(".dpr", ""));
				List<Document> records = collection.find(query).into(new ArrayList<Document>());

				Optional<Document> firstRecord = records.stream().findFirst();

				if (firstRecord.isPresent()) {
					List<String> targetPasList = (List<String>) firstRecord.get().get("targetPasFiles");
					System.out.println(targetPasList);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				client.close();
			}

		} else {
			log.info("As of now, Only Worksheet Input Type is Supported. Other Input types are not supported");
		}
	}

	private void performSingleDfmValidation(String inputPath, String formType, String licenseField) {

		try {
			ObjectTreeListEntity objectTree = new ObjectTreeListEntity();
			UiUxEnhancementFileService fileService = new UiUxEnhancementFileService();
			FileWriteService fileWriteService = new FileWriteService();
			OutputService outputService = new OutputService();

			File file = new File(inputPath);

			if (!file.exists()) {
				log.error(file.getName() + " does not exists.");
				return;
			}

			fileService.readComponentsTreeFromDfm(objectTree, inputPath, file, false, true);

			List<ResultEntity> resultEntity = new ArrayList<ResultEntity>();
			LayoutType layoutType = LayoutType.getEnum(formType);
			License license = License.getEnum(licenseField);

			fileService.checkComponentsProperty(objectTree, new ObjectTreeListEntity(), resultEntity, inputPath, layoutType,
			    license);
			fileWriteService.setEntityToDFMFile(resultEntity);
			outputService.writeResultToFile(resultEntity);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
