package org.intrawebtools.uiux_enhancer.enums;

import lombok.Getter;

@Getter
public enum ButtonColorType {
	LINK_GRAY_BUTTON("8355711","$007F7F7F","","","","","",""),
	LINK_BLUE_BUTTON("12608789","$00C06515","","","","","",""),
	ICON_BUTTON("3355443","$00333333","","","","","",""),
	RAISED_DEFAULT_BUTTON("3355443","$00333333","8355711","$00D3D0CD","12434877","$00BDBDBD","15921648","$00F2F1F0"),
	RAISED_PRIMARY_BUTTON("clWhite","$00FFFFFF","16024898","$00F48542","clWhite","$00FFFFFF","15921648","$00F2F1F0"),
	RAISED_DANGER_BUTTON("clWhite","$00FFFFFF","6495977","$00631EE9","clWhite","$00FFFFFF","15921648","$00F2F1F0"),
	FLAT_DEFAULT_BUTTON("8355711","$007F7F7F","","","14210257","$00D8D4D1","",""),
	FLAT_PRIMARY_BUTTON("16024898","$00F48542","","","16367774","$00F9C09E","",""),
	FLAT_DANGER_BUTTON("6495977","$00631EE9","","","11504628","$00AF8BF4","",""),
	NON_COMPONENT("","","","","","","","");
	
	
	private String textColorDecimal;//font color 十進数
	private String textColorHexadecimal;//font color 十六進数
	private String backgroundColorDecimal;//background color
	private String backgroundColorHexadecimal;//background color
	private String textColorDecimalDisabled;//disabled font color
	private String textColorHexadecimalDisabled;//disabled background color
	private String backgroundColorDecimalPanelColor;//background color
	private String backgroundColorHexadecimalPanelColor;//background color

	private ButtonColorType(String textColorDecimal, String textColorHexadecimal, String backgroundColorDecimal, String backgroundColorHexadecimal, String textColorDecimalDisabled, String textColorHexadecimalDisabled, String backgroundColorDecimalPanelColor, String backgroundColorHexadecimalPanelColor) {
		this.textColorDecimal = textColorDecimal;
		this.textColorHexadecimal = textColorHexadecimal;
		this.backgroundColorDecimal = backgroundColorDecimal;
		this.backgroundColorHexadecimal = backgroundColorHexadecimal;
		this.textColorDecimalDisabled = textColorDecimalDisabled;
		this.textColorHexadecimalDisabled = textColorHexadecimalDisabled;
		this.backgroundColorDecimalPanelColor = backgroundColorDecimalPanelColor;
		this.backgroundColorHexadecimalPanelColor = backgroundColorHexadecimalPanelColor;
	}
}
