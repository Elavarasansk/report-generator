package org.intrawebtools.uiux_enhancer.applicationDesign;

public class UiuxEnhancerConsts {

  public static final String Css_File = "uiux-enhancer.css";

  public static final String Tool_Image = "iw_tools.png";

  public static final String Title = "UI/UX Enhancer";

  public static final String Checkbox = "checkbox";

  public static final String DFM = "DFM";

  public static final String DFM_Path = "DFM Path";

  public static final String CSS = "uiux-enhancer.css";

  public static final String Input_Type = "Input Type";

  public static final String inputTypeLabel = "inputTypeLabel";

  public static final String WORKSPACE_PATH = "Workspace Path";

  public static final String WORKSPACE_PATH_LABEL = "workspacePathLabel";

  public static final String Radio = "radio";

  public static final String DPR = "DPR";

  public static final String Worksheet = "Worksheet";

  public static final String DFM_Input_File = "DFM Input File";

  public static final String DPR_PATH = "DPR Path";

  public static final String Worksheet_PATH = "Worksheet Path";

  public static final String DFM_Input_File_Path = "DFM Input File";

  public static final String DisplayLabel = "displayLabel";

  public static final String SUBMIT = "SUBMIT";

  public static final String MainGrid = "mainGrid";

  public static final String ERROR = "ERROR";

  public static final String InputPath_Message = "Input Path should not be empty";

  public static final String FolderPath_Message = "Workspace Path should not be empty";

  public static final String Invalid_FolderPath_Message = "Enter the valid Workspace path";

  public static final String Empty_String = "";

  public static final String DFM_Extension = "dfm";

  public static final String DFM_Path_Error_Message = "Enter the proper DFM path";

  public static final String DPR_Extension = "dpr";

  public static final String DPR_Path_Error_Message = "Enter the proper DPR path";

  public static final String File_Extension = "xls";

  public static final String DFM_File_Path_Error_Message = "Enter the proper DFM file input path";

  public static final String Worksheet_File_Path_Error_Message = "Enter the proper Worksheet path";

  public static final String iw_tools = "iw_tools.png";

  public static final String WORKSPACE_SAMPLE_PATH = "C:\\\\HUE\\\\Workspace\\\\Develop";

  public static final String NOTE_MESSAGE = "Note: Currently, Only WorkSheet Input Type is Supported";

  public static final String LOG_MESSAGE = "Log Message";

  public static final String NOTE_LABEL = "Note";

  public static final String LICENSE_LABEL = "License";

  public static final String FORM_TYPE = "Form Type";

  public static final String LICENSE_Error_Message = "License Field Should not be Empty";

  public static final String FORM_TYPE_Error_Message = "FormType Field Should not be Empty";
}
