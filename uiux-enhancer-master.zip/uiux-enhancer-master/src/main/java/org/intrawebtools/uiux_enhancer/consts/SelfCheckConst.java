package org.intrawebtools.uiux_enhancer.consts;

public class SelfCheckConst {
	// for autocheck - component property check
	public static final String con_OBJECT = "object";
	public static final String con_EQUAL = "=";
	public static final String reg_COMPONENT_OBJECT_2 = "object (.*): (.*)";
	public static final String reg_COMPONENT_INHERITED_2 = "inherited (.*): (.*)";
	public static final String reg_COMPONENT_PROPERTY_2 = "= (.*)";
	public static final String reg_COMPONENT_LISTVIEW_START = "Columns = <";
	public static final String reg_COMPONENT_LISTVIEW_END = "end>";
	public static final String reg_COMPONENT_LISTVIEW_EMPTY = "Columns = <>";
	public static final String reg_COMPONENT_PROPERTY_ARRAYS_START = " = <";
	public static final String reg_COMPONENT_PROPERTY_EMPTY_ARRAYS = " = <>";

	public static final String con_PATH_EXTENSION_PAS = "pas";
	public static final String con_PATH_EXTENSION_DFM = "dfm";
	public static final String con_BACKSLASH = "\\";

	// for Java logic
	public static final String con_JAVA_TYPE_STRING = "String";
	public static final String con_JAVA_TYPE_INT = "int";
	public static final String con_JAVA_STRING_EMPTY = "";
	public static final String con_JAVA_STRING_ZERO = "0";
	public static final String con_JAVA_STRING_FALSE = "False";
	public static final String con_JAVA_STRING_TRUE= "True";
	public static final String con_JAVA_STRING_SPACE = " ";
	public static final String con_JAVA_STRING_SPACE_DOUBLE = "　";
  public static final String con_JAVA_STRING_HEADER_PREFIX = "[－\\.\\・\\+]";

	public static final String con_COMPONENT_CHECKTYPE_LABEL = "label";
	public static final String con_COMPONENT_CHECKTYPE_BUTTON = "button";
	public static final String con_COMPONENT_CHECKTYPE_PANEL = "panel";

	public static final String con_COMPONENT_NAME_HUE = "hue";

	//DELPHI : component name
	public static final String con_COMPONENT_NAME_TWASCROLLBOX = "TWAScrollBox";
	public static final String con_COMPONENT_NAME_TWATABCONTROL = "TWATabControl";
	public static final String con_COMPONENT_NAME_TWAPAGECONTROL = "TWAPageControl";
	public static final String con_COMPONENT_NAME_TVISUALBUTTONEX = "TVisualButtonEx";
	public static final String con_COMPONENT_NAME_TINILABEL2 = "TIniLabel2";
	public static final String con_COMPONENT_NAME_TLINKLABEL= "TLinkLabel";
	public static final String con_COMPONENT_NAME_HUEPNLSEARCHCONDBASE = "huePnlSearchCondBase";
	public static final String con_COMPONENT_NAME_HUEPNLDIALOGFOOTERBASE = "huePnlDialogFooterBase";
	public static final String con_COMPONENT_NAME_HUEPNLGRIDBASE = "huePnlGridBase";
	public static final String con_COMPONENT_NAME_HUEPNLGRIDFOOTER = "huePnlGridFooter";
	public static final String con_COMPONENT_NAME_PNLFOOTER = "pnlFooter";
	public static final String con_COMPONENT_NAME_HUEPNLSEARCHHEADER = "huePnlSearchHeader";



	//DELPHI : in pas file
	public static final String con_COMPONENT_PROPERTY_PAS_CAPTION = ".Caption:=";

	//DELPHI :  property
	public static final String con_COMPONENT_PROPERTY_WIDTH = "Width";
	public static final String con_COMPONENT_PROPERTY_HEIGHT = "Height";
	public static final String con_COMPONENT_PROPERTY_LEFT = "Left";
	public static final String con_COMPONENT_PROPERTY_TOP = "Top";
	public static final String con_COMPONENT_PROPERTY_VISIBLE = "Visible";	
	public static final String con_COMPONENT_PROPERTY_CAPTION = "Caption";
	public static final String con_COMPONENT_PROPERTY_GLYPHDATA = "Glyph.Data";
	public static final String con_COMPONENT_PROPERTY_HUEBUTTONTYPE = "HueButtonType";
	public static final String con_COMPONENT_PROPERTY_FONTHEIGHT = "Font.Height";
	public static final String con_COMPONENT_PROPERTY_FONTCOLOR = "Font.Color";
	public static final String con_COMPONENT_PROPERTY_FONTCHARSET = "Font.Charset";
	public static final String con_COMPONENT_PROPERTY_FONTNAME = "Font.Name";
	public static final String con_COMPONENT_PROPERTY_BACKGROUNDCOLOR = "Color";
	public static final String con_COMPONENT_PROPERTY_COLORSTYLE = "ColorStyle";
	public static final String con_COMPONENT_PROPERTY_LABELTYPE= "LabelType";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE= "LabelStyleType";
	public static final String con_COMPONENT_PROPERTY_REQUIREMARK = "RequiredMark";
	public static final String con_COMPONENT_PROPERTY_WORDWRAP = "WordWrap";
	public static final String con_COMPONENT_PROPERTY_HEADERFONTSIZE = "HeaderFontSize";
	public static final String con_COMPONENT_PROPERTY_PENCOLOR = "Pen.Color";
	public static final String con_COMPONENT_PROPERTY_BRUSHCOLOR = "Brush.Color";
	public static final String con_COMPONENT_PROPERTY_PENSTYLE = "Pen.Style";
	public static final String con_COMPONENT_PROPERTY_COLOR = "Color";
	public static final String con_COMPONENT_PROPERTY_CUSTOMCOLOR= "CustomColor";
	public static final String con_COMPONENT_PROPERTY_FONTSTYLE = "Font.Style";
	public static final String con_COMPONENT_PROPERTY_HEADERTYPE = "HeaderType";
	public static final String con_COMPONENT_PROPERTY_HEADERLABELTYPE = "HeaderLabelType";
	public static final String con_COMPONENT_PROPERTY_FONTSIZE = "FontSize";
	public static final String con_COMPONENT_PROPERTY_ACTION = "Action";
	public static final String con_COMPONENT_PROPERTY_ENABLED = "Enabled";
	public static final String con_COMPONENT_PROPERTY_BOLD = "fsBold";
	public static final String con_COMPONENT_PROPERTY_DOWN = "Down";
	public static final String con_COMPONANT_PROPERTY_HUEPNL = "huePnl";
	public static final String con_COMPONANT_PROPERTY_PARENT_COLOR = "ParentColor";
	public static final String con_COMPONENT_PROPERTY_HORZSCROLLBAR = "HorzScrollBar.Position";
	public static final String con_COMPONENT_PROPERTY_VERTSCROLLBAR = "VertScrollBar.Position";
	public static final String con_COMPONENT_RPOPERTY_ACTIVEPAGE = "ActivePage";
	public static final String con_COMPONENT_RPOPERTY_TABINDEX = "TabIndex";
	public static final String con_COMPONENT_RPOPERTY_COLUMNS = "Columns";
  public static final String con_COMPONENT_PRPOPERTY_LAYOUT = "Layout";

	//DELPHI : property - value
	public static final String con_COMPONENT_PROPERTY_HUEBUTTONTYPE_BTICON = "btIcon";
	public static final String con_COMPONENT_PROPERTY_HUEBUTTONTYPE_BTLINKBLUE = "btLinkLabelBlue";
	public static final String con_COMPONENT_PROPERTY_HUEBUTTONTYPE_BTLINKGRAY = "btLinkLabelGray";
	public static final String con_COMPONENT_PROPERTY_HUEBUTTONTYPE_BTFLAT = "btFlat";
	public static final String con_COMPONENT_PROPERTY_HUEBUTTONTYPE_BTRAISED = "btRaised";
	public static final String con_COMPONENT_PROPERTY_FONTCOLOR_ERROR = "6495977";//For Error
	public static final String con_COMPONENT_PROPERTY_FONTCOLOR_LINK = "C06515";//For Link
	public static final String con_COMPONENT_PROPERTY_FONTCHARSET_JIS = "SHIFTJIS_CHARSET";
	public static final String con_COMPONENT_PROPERTY_FONTCHARSET_DEFAULT = "DEFAULT_CHARSET";
	public static final String con_COMPONENT_PROPERTY_FONTNAME_MEIRYO = "メイリオ";
	public static final String con_COMPONENT_PROPERTY_COLORSTYLE_DAFAULT = "csDefault";
	public static final String con_COMPONENT_PROPERTY_COLORSTYLE_PRIMARY = "csPrimary";
	public static final String con_COMPONENT_PROPERTY_COLORSTYLE_DANGER = "csDanger";
	public static final String con_COMPONENT_PROPERTY_LABELTYPE_HEADER= "ltHeaderLabel";
	public static final String con_COMPONENT_PROPERTY_LABELTYPE_INPUT= "ltInputLabel";
	public static final String con_COMPONENT_PROPERTY_LABELTYPE_TEXT= "ltTextLabel";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE_HEADER= "lstHeaderLabel";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE_INPUT= "lstInputLabel";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE_TEXT= "lstTextLabel";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE_LINK= "lstLinkLabel";
	public static final String con_COMPONENT_PROPERTY_TEXT_BLACK_1 = "clWindowText";
	public static final String con_COMPONENT_PROPERTY_TEXT_BLACK_2 = "clBlack";
	public static final String con_COMPONENT_PROPERTY_TEXT_WHITE_1 = "clWindow";
	public static final String con_COMPONENT_PROPERTY_TEXT_WHITE_2 = "clWhite";
	public static final String con_COMPONENT_PROPERTY_PENSTYLE_PSSOLID = "psSolid";
	public static final String con_COMPONENT_PROPERTY_PENSTYLE_PSCLEAR = "psClear";
	public static final String con_COMPONENT_PROPERTY_PENSTYLE_NOBORDER = "noBorder";
	public static final String con_COMPONENT_PROPERTY_LABELTYPE_HEADERFONTSIZE = "hfsSubhead";
	public static final String con_COMPONENT_PROPERTY_LABELTYPE_FONTSIZE = "hfsTitle";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE_HEADFONTSIZE= "fsSubhead";
	public static final String con_COMPONENT_PROPERTY_LABELSTYLETYPE_FONTSIZE = "fsTitle";
	public static final String con_COMPONENT_PROPERTY_COLUMNS_ITEM = "item";
	public static final String con_COMPONENT_PROPERTY_HUELISTVIEWSTYLE_LVSLIST = "lvsList";
	public static final String con_COMPONENT_PROPERTY_VALUE_UNDERLINE = "Underline";
	public static final String con_COMPONENT_PROPERTY_VALUE_BOLD = "Bold";
  public static final String con_COMPONENT_PROPERTY_VALUE_ITALIC = "Italic";

	//For button, checkbox, radiobutton to calculate
	public static final int con_BUTTON_PADDING_DOUBLESIDE = 24;
	public static final int con_ICON_BUTTON_WIDTH = 32;
	public static final int con_RAISEDBUTTON_BORDER_DOUBLESIDE = 2;
	public static final int con_ICON_BUTTON_MAX_WIDTH = 51;
	public static final int con_ICON_ON_BUTTON = 16;
	public static final int con_SPACE_ON_BUTTON = 8;
	public static final int con_CHECKBOX_MAX_WIDTH = 26;
	public static final int con_CHECKBOX_WIDTH = 16;
	public static final int con_RADIOBUTTON_WIDTH = 24;

	//for label name
	public static final String con_LABELNAME_INPUT = "Input Label";
	public static final String con_LABELNAME_LINK = "Link Label";

	//for transform decimal caption 
	public static final String con_DECIMAL_HASHMARK = "#";
	public static final String con_DOUBLE_AMPERSAND = "&&";
	public static final String con_AMPERSAND = "&";
	public static final String con_TEMPORARYAMPERSAND = "tempampersand";

	//for add zero to color code
	public static final String con_COLORCODE_DOLLAR_0000000 =  "$0000000";
	public static final String con_COLORCODE_DOLLAR_000000 = "$000000";
	public static final String con_COLORCODE_DOLLAR_00000 = "$00000";
	public static final String con_COLORCODE_DOLLAR_0000 = "$0000";
	public static final String con_COLORCODE_DOLLAR_000 = "$000";
	public static final String con_COLORCODE_DOLLAR_00 = "$00";
	public static final String con_COLORCODE_DOLLAR_0 = "$0";
	public static final String con_COLORCODE_DOLLAR = "$";

	//for color font map
	public static final String con_COLOR_FONT_MAP_INPUTLABEL = "InputLabel";
	public static final String con_COLOR_FONT_MAP_NORMAL = "Normal";

	//other around color code
	public static final String con_COLORCODE_CL = "cl";
	public static final String con_COLORCODE_000000 = "000000";
	public static final String con_COLORCODE_333333 = "333333";
	public static final String con_COLORCODE_INPUTLABEL = "7F7F7F";
	public static final String con_COLORCODE_PANEL = "15921648";
	public static final String con_COLORCODE_d0d0d0 = "d0d0d0";

	//for order check
	public static final String con_POSITION_VERTICAL = "vertical";
	public static final String con_POSITION_HORIZONTAL = "horizontal";
	public static final String con_POSITION_SAME = "same line";
	public static final String con_POSITION_LEFT = "left";
	public static final String con_POSITION_RIGHT = "right";
	public static final String con_POSITION_TOP = "top";
	public static final String con_POSITION_BOTTOM = "bottom";

	public static final String con_ISFORMELEMENTS_LABEL = "Label";
	public static final String con_ISFORMELEMENTS_OTHERS = "Others";

	public static final String con_PARENT_COMPONENT_NAME = "Parent component name: ";
	public static final String con_MULTIPLE_COMPONENTTYPE = "---";

	//for write result format
	public static final String con_PERIOD = ".";
	public static final String con_OPEN_PARENTHESES = "(";
	public static final String con_CLOSE_PARENTHESES = ")";
	public static final String con_PERIOD_AND_WRAP = ".\n";
	public static final String con_PERIOD_SPACE_WRAP = ". \n";
	public static final String con_WRAP = "\n";
	public static final String con_PERIOD_AND_DOUBLE_WRAP = ".\n\n";
	public static final String con_DOUBLE_WRAP = "\n\n";
	public static final String con_OK_MESSAGE = "OK for this component.";
	public static final String con_COMPONENT_LABEL_STRING = "The label of this component is: ";
	public static final String con_COMPONENT_UNVISIBLE = "[Warning(component is not visible)] ";
	public static final String con_CURRENT_SPACE = "Current ";
	public static final String con_AND_LABELCOLOR_IS = ", and label color is ";
	public static final String con_AND_LABELCOLOR_IS_DOLLAR00 = ", and label color is $00";
	public static final String con_COMMON_CAPTION_CUTOFF_CHECK_MESSAGE1 = "Current width is Width = ";
	public static final String con_COMMON_CAPTION_CUTOFF_CHECK_MESSAGE2 = "Please set Width more than ";

	public static final String con_TOOCHARATERFORONECELL_ERROR = " ... (AND MORE)\nThere are too many errors, please compare this part with Company screen and correct them.";

	public static final String con_FC_10_10_20 = "FC_10_10_20";
	public static final String con_FC_10_10_20_WRONGORDER_0 = "[Wrong Order]The realstionship between ''";
	public static final String con_FC_10_10_20_WRONGORDER_1 = "' and '";
	public static final String con_FC_10_10_20_WRONGORDER_2 = "' is changed.\n";
	public static final String con_FC_10_10_20_WRONGORDER_VERTICAL = "Vertical relationship:\n";
	public static final String con_FC_10_10_20_WRONGORDER_HORIZONTAL = "Horizontal relationship:\n";
	public static final String con_FC_10_10_20_WRONGORDER_V36 = "V36: '";
	public static final String con_FC_10_10_20_WRONGORDER_V40 = "V40: '";
	public static final String con_FC_10_10_20_WRONGORDER_ISONTHE = "' is on the ";
	public static final String con_FC_10_10_20_WRONGORDER_ISON= "' is on ";
	public static final String con_FC_10_10_20_WRONGORDER_OF = " of '";
	public static final String con_FC_10_10_20_WRONGORDER_PERIOD = "'.";

	public static final String con_FC_10_10_20_WRONGORDER_ADDITION_0 = "[Wrong Order]The order between ''";
	public static final String con_FC_10_10_20_WRONGORDER_ADDITION_1="Because between '";
	public static final String con_FC_10_10_20_WRONGORDER_ADDITION_2 = "', there are components which are not supposed to be there or their order is reversed.";
	public static final String con_FC_10_10_20_WRONGORDER_ADDITION_FIRST_0 = "[Wrong Order]The order of''";
	public static final String con_FC_10_10_20_WRONGORDER_ADDITION_FIRST_1 = "' is wrong.\nCheck if it is in the right place in '";

	public static final String con_FC_10_10_30 = "FC_10_10_30";
	public static final String con_FC_10_10_30_NOCOMPONENT_1 = "[Not Found]'";
	public static final String con_FC_10_10_30_NOCOMPONENT_2 = "' can't be found in '";
	public static final String con_FC_10_10_30_NOCOMPONENT_3 = "'(parent component).";

	public static final String con_FC_20_20_10 = "FC_20_20_10";
	public static final String con_FC_20_20_10_MESSAGE1 = "Width of Label is not correct.";

	public static final String con_FC_20_30_10 = "FC_20_30_10";
	public static final String con_FC_20_30_10_MESSAGE1 = "The width of label is not enough: ";
	public static final String con_FC_20_30_10_MESSAGE2 = "Current Font color is Font.Color = ";
	public static final String con_FC_20_30_10_MESSAGE3 = "Please set Font.Color = $00333333 according to the Guideline.";
	public static final String con_FC_20_30_10_MESSAGE4 = "Current Font style is Font.Style.fsBold = True.";
	public static final String con_FC_20_30_10_MESSAGE5 = "Please set \"Font.Style.fsBold = False\".";
	public static final String con_FC_20_30_10_MESSAGE6 = "Current Font size is ";
	public static final String con_FC_20_30_10_MESSAGE7 = "Please set ";
	public static final String con_FC_20_30_10_MESSAGE8 = " = ";
	public static final String con_FC_20_30_10_MESSAGE9 = "Font color of Header Label is not correct.";
	public static final String con_FC_20_30_10_MESSAGE10 = "Font style of Header Label is not correct.";
	public static final String con_FC_20_30_10_MESSAGE11 = "Font size of Header Label is not correct.";

	public static final String con_FC_20_40_10 = "FC_20_40_10";
	public static final String con_FC_20_40_10_MESSAGE1 = "Current Font color is Font.Color = ";
	public static final String con_FC_20_40_10_MESSAGE2 = "Please set Font.Color = $007F7F7F according to the Guideline.";
	public static final String con_FC_20_40_10_MESSAGE3 = "Current Font style is Font.Style.fsBold = True.";
	public static final String con_FC_20_40_10_MESSAGE4 = "Please set \"Font.Style.fsBold = False\".";
	public static final String con_FC_20_40_10_MESSAGE5 = "Current Font style is Font.Style.fsUnderline = True.";
	public static final String con_FC_20_40_10_MESSAGE6 = "Please set \"Font.Style.fsUnderline = False\".";
	public static final String con_FC_20_40_10_MESSAGE7 = "However, if you would like to use as Text Label";
	public static final String con_FC_20_40_10_MESSAGE8 = "No need to fix the label color, but change ";
	public static final String con_FC_20_40_10_MESSAGE9 = "Font color of Input Label";
	public static final String con_FC_20_40_10_MESSAGE10 = "Font style of ";
	public static final String con_FC_20_40_10_MESSAGE11 = " is not correct.";
	public static final String con_FC_20_40_10_MESSAGE12 = "No need to fix the label style, but change ";

	public static final String con_FC_20_10_10 = "FC_20_10_10";
	public static final String con_FC_20_10_10_MESSAGE1 = "Width of Button is not correct.";
	public static final String con_FC_20_10_10_MESSAGE2 = "Please set Width more than 32.";//just icon
	public static final String con_FC_20_10_10_EXCEPTION_1 ="」";
	public static final String con_FC_20_10_10_EXCEPTION_2 ="。";

	public static final String con_FC_20_110_20 = "FC_20_110_20";
	public static final String con_FC_20_110_20_MESSAGE1 = "Current background color is Color = ";
	public static final String con_FC_20_110_20_MESSAGE2 = "Please use the most similar background color defined by the Guideline.";
	public static final String con_FC_20_110_20_MESSAGE3 = "Background color of Panel is not correct.";
	public static final String con_FC_20_110_20_MESSAGE4 = "Background color of Shape is not correct.";
	public static final String con_FC_20_110_20_MESSAGE5 = "Current background color is Brush.Color = ";

	public static final String con_FC_20_130_10 = "FC_20_130_10";
	public static final String con_FC_20_130_10_MESSAGE1 = "Current border color is Pen.Color = ";
	public static final String con_FC_20_130_10_MESSAGE2 = "Please use available border color defined by the Guideline.";
	public static final String con_FC_20_130_10_MESSAGE3 = "Border color of Shape is not correct.";

	public static final String con_FC_20_20_50 = "FC_20_20_50";
	public static final String con_FC_20_20_50_CAPTION_NG1 = "■";
	public static final String con_FC_20_20_50_CAPTION_NG2 = "◆";
	public static final String con_FC_20_20_50_CAPTION_NG3 = "▼";
	public static final String con_FC_20_20_50_CAPTION_NG4 = "【";
	public static final String con_FC_20_20_50_CAPTION_NG5 = "】";
	public static final String con_FC_20_20_50_CAPTION_EXCEPTION = "【画面名称】";
	public static final String con_FC_20_20_50_MESSAGE_COMMON_MESSAGE1 = "Caption of Label is not correct.";
	public static final String con_FC_20_20_50_MESSAGE_COMMON_MESSAGE2 = "Current Caption is Caption =";
	public static final String con_FC_20_20_50_MESSAGE1 = "Please set Caption which is not starting with a ■.";
	public static final String con_FC_20_20_50_MESSAGE2 = "Please set Caption which is not starting with a ◆.";
	public static final String con_FC_20_20_50_MESSAGE3 = "Please set Caption which is not starting with a ▼.";
	public static final String con_FC_20_20_50_MESSAGE4 = "Please set Caption which is not starting with a 【 and ending with 】.";

	//Label - Text Label Check
	public static final String con_FC_20_50_10= "FC_20_50_10";
	public static final String con_FC_20_50_10_MESSAGE1_1 = "Font color of Label is not correct.";
	public static final String con_FC_20_50_10_MESSAGE1_2 = "Label type of Label is not correct, since this color is for Link label.";
	public static final String con_FC_20_50_10_MESSAGE2 = "Current Font color is Font.Color=";
	public static final String con_FC_20_50_10_MESSAGE3_1 = "Please use available font color defined by the Guideline.";
	public static final String con_FC_20_50_10_MESSAGE3_2 = "Please set LabelStyleType=lstLinkLabel(Font.Color will be $00C06515) according to the Guideline.";

	public static final String con_FC_20_50_20= "FC_20_50_20";
	public static final String con_FC_20_50_20_COLORRED_COMPANYRED = "clRed";//COMPANYの赤
	public static final String con_FC_20_50_20_COLORRED_HUERED = "$00631EE9";//Guideline指定の赤
	public static final String con_FC_20_50_20_MESSAGE1_1 = "Font color of Label is not correct, since clRed is not available in HUE.";
	public static final String con_FC_20_50_20_MESSAGE1_2 = "Font color of Label is not correct, since it was colored Red in the original screen.";
	public static final String con_FC_20_50_20_MESSAGE2 = "Current Font color is Font.Color=";
	public static final String con_FC_20_50_20_MESSAGE3 = "Please set LabelStyleType=lstTextLabel and MessageType=mtErrorT(Font.Color will be $00631EE9) according to the Guideline.";

	public static final String con_FC_20_55_10= "FC_20_55_10";
	public static final String con_FC_20_55_10_MESSAGE1 = "Font color of Label is not correct.";
	public static final String con_FC_20_55_10_MESSAGE2 = "Current Font color is Font.Color=";	
	public static final String con_FC_20_55_10_MESSAGE3 = "Please set ColorType=ctBlueT(Font.Color will be $00631EE9) according to the Guideline.";

	public static final String con_FC_20_80_10 = "FC_20_80_10";
	public static final String con_FC_20_80_10_MESSAGE1 = "Width of Checkbox is not correct.";

	public static final String con_FC_20_90_10 = "FC_20_90_10";
	public static final String con_FC_20_90_10_MESSAGE1 = "Width of Radio Button is not correct.";

	public static final String con_FC_20_100_10 = "FC_20_100_10";
	public static final String con_FC_20_100_10_MESSAGE1 = "Style of ListView is not correct.\r\nCurrent style is HueListViewStyle = lvsGrid.\r\nPlease set HueListViewStyle = lvsList.";
	public static final String con_FC_20_100_10_MESSAGE2 = "Style of ListView is not correct.\r\nCurrent Style is HueListViewStyle = lvsList.\r\nPlease set HueListViewStyle = lvsGrid.";
	public static final String con_FC_20_100_10_URL = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E3.82.AB.E3.83.A9.E3.83.A0.E3.81.8C1.E5.88.97.E3.81.97.E3.81.8B.E5.88.A9.E7.94.A8.E3.81.95.E3.82.8C.E3.81.A6.E3.81.84.E3.81.AA.E3.81.84.E5.A0.B4.E5.90.88_.2F_If_onlt_1_column_is_used_on_the_listview";

	public static final String con_FC_20_10_20 = "FC_20_10_20";
	public static final String con_FC_20_10_20_WRONG = " is not correct.";
	public static final String con_FC_20_10_20_CURRENT = "Current color is ";
	public static final String con_FC_20_10_20_CORRECT = "Please set ";
	public static final String con_FC_20_10_20_BUTTONFONTCOLOR = "Button font color";
	public static final String con_FC_20_10_20_BUTTONBACKGROUNDCOLOR = "Button background color";
	public static final String con_FC_20_10_20_CURRENT_FONTCOLOR = "Font.Color = ";
	public static final String con_FC_20_10_20_CURRENT_COLOR = "Color = ";
	public static final String con_FC_20_10_20_BOLD = "Font style of Button is not correct.\r\nCurrent Font style is Font.Style.fsBold=True.\r\nPlease set Font.Style.fsBold=False.";
	public static final String con_FC_20_10_20_URL = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Button";
	public static final String con_FC_20_10_20_PARENT = "Background color of Button is not correct.\r\nCurrent Background Color is same as parent component because current style is ParentColor = true .\r\nPlease set ParentColor = false . \r\n\r\nWhen you change the propertiy, please follow following steps.\r\n(1)Change property ParentColor to False from True.\r\n(2)Set ColorStyle property again.(Please select same as current one.)";

	public static final String con_COMPONENT_CURRENT_CHARSET = "The charset of this component is ";
	public static final String con_COMPONENT_WRONG_CHARSET = ". Change it to SHIFTJIS_CHARSET.";
	public static final String con_COMPONENT_CURRENT_FONTFAMILY = "The font-family of this component is ";
	public static final String con_COMPONENT_WRONG_FONTFAMILY = ". Change it to Meriyo(メイリオ).";
	public static final String con_COMPONENT_CURRENT_FONTSIZE = "The font-size of this component is ";
	public static final String con_COMPONENT_WRONG_FONTSIZE = ". Font size is wrong. Check the fontsize relate options.";

	public static final String con_REFERENCEURL_BACKGROUNDCOLOR = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Background_Color";
	public static final String con_REFERENCEURL_BORDERCOLOR = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Border_Color";
	public static final String con_REFERENCEURL_FONTCOLOR = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Font_Color";
	public static final String con_REFERENCEURL_HEADERLABEL = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Label_Specification#1._Header_Label.E3.81.AE.E8.A8.AD.E5.AE.9A.E6.96.B9.E6.B3.95_How_to_set_Header_Label";
	public static final String con_REFERENCEURL_INPUTLABEL = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Label_Specification#2._Input_Label.E3.81.AE.E8.A8.AD.E5.AE.9A.E6.96.B9.E6.B3.95_How_to_set_Input_Label";
	public static final String con_REFERENCEURL_INPUTTEXTDIFFERENCE = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Label_Specification#.E3.82.B9.E3.82.BF.E3.82.A4.E3.83.AB.E3.81.AE.E5.A4.89.E6.9B.B4_Change_in_style";
	public static final String con_REFERENCEURL_BUTTON_CAPTION = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E6.96.87.E5.AD.97.E3.81.AE.E5.85.A5.E3.81.A3.E3.81.9F.E3.83.9C.E3.82.BF.E3.83.B3.E3.81.AE.E5.A0.B4.E5.90.88_.2F_When_the_button_is_with_caption";
	public static final String con_REFERENCEURL_LABEL_SPECIALCHARACTER = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E3.83.A9.E3.83.99.E3.83.AB.E3.81.AE.E6.96.87.E5.AD.97.E3.81.AE.E5.85.88.E9.A0.AD.E3.81.AB.E3.80.8C.E2.96.A0.E3.80.8D.E3.82.84.E3.80.8C.E2.97.86.E3.80.8D.E3.81.8C.E5.90.AB.E3.81.BE.E3.82.8C.E3.81.A6.E3.81.84.E3.82.8B.E5.A0.B4.E5.90.88_.2F_When_.22.E2.96.A0.22_or_.22.E2.97.86.22_is_included_at_the_head_of_the_label_character";
	public static final String con_REFERENCEURL_LABEL_CAPTION = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#Input_Label.E3.81.AE.E4.BD.99.E7.99.BD.E3.81.8C.E4.B8.8D.E8.B6.B3.E3.81.97.E3.81.A6.E3.81.84.E3.82.8B_or_.E9.95.B7.E3.81.99.E3.81.8E.E3.81.A6.E5.85.A8.E3.81.A6.E3.81.AE.E9.A0.85.E7.9B.AE.E3.81.8C.E8.A6.8B.E3.81.88.E3.81.AA.E3.81.84.E5.A0.B4.E5.90.88_.2F_When_the_vacancy_of_Input_Label_is_not_enough_or_width_is_too_big_to_show_all_the_item";
	public static final String con_REFERENCEURL_CHECKBOX_CAPTION = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E5.B9.85.E3.81.8C.E5.8D.81.E5.88.86.E3.81.A7.E3.81.AA.E3.81.8F.E6.96.87.E5.AD.97.E3.81.8C.E8.A6.8B.E5.88.87.E3.82.8C.E3.81.A6.E3.81.84.E3.82.8B.E5.A0.B4.E5.90.88_.2F_When_the_width_is_not_enough_and_the_letters_are_overlooked";
	public static final String con_REFERENCEURL_RADIOBUTTON_CAPTION = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E5.B9.85.E3.81.8C.E5.8D.81.E5.88.86.E3.81.A7.E3.81.AA.E3.81.8F.E6.96.87.E5.AD.97.E3.81.8C.E8.A6.8B.E5.88.87.E3.82.8C.E3.81.A6.E3.81.84.E3.82.8B.E5.A0.B4.E5.90.88_.2F_When_the_width_is_not_enough_and_the_letters_are_overlooked_2";
	public static final String con_REFERENCEURL_SEARCHCONDITION_PANEL = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E6.A4.9C.E7.B4.A2.E6.9D.A1.E4.BB.B6.E3.82.A8.E3.83.AA.E3.82.A2.E7.94.A8.E3.81.AE.E3.83.91.E3.83.8D.E3.83.AB.E3.81.AE.E4.B8.8A.E3.81.AB.E7.95.B0.E3.81.AA.E3.82.8B.E8.83.8C.E6.99.AF.E8.89.B2.E3.81.AE.E3.83.91.E3.83.8D.E3.83.AB.E3.81.8C.E7.BD.AE.E3.81.8B.E3.82.8C.E3.81.A6.E3.81.84.E3.82.8B.E5.A0.B4.E5.90.88_.2F_When_panels_with_different_background_colors_are_placed_on_the_panel_for_the_search_condition_area";
	public static final String con_REFERENCEURL_DIALOG_FOOTER = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E3.83.9C.E3.82.BF.E3.83.B3.E3.81.8C.E3.83.80.E3.82.A4.E3.82.A2.E3.83.AD.E3.82.B0.E3.81.AE.E3.83.95.E3.83.83.E3.82.BF.E3.83.BC.E3.82.A8.E3.83.AA.E3.82.A2.E4.B8.8A.E3.81.AB.E9.85.8D.E7.BD.AE.E3.81.95.E3.82.8C.E3.81.A6.E3.81.84.E3.82.8B.E5.A0.B4.E5.90.88_.2F_When_the_button_is_on_dialog_footer_area";
	public static final String con_REFERENCEURL_GRID_HEADER = "http://huewiki/mediawiki/index.php/List_Frame#Grid_Header_-_.E3.82.B0.E3.83.AA.E3.83.83.E3.83.89.E3.83.98.E3.83.83.E3.83.80.E3.83.BC";
	public static final String con_REFERENCEURL_DUPLICATE_CAPTION = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Move_Components#.E4.B8.8D.E8.A6.81.E3.81.AA.E3.82.B3.E3.83.B3.E3.83.9D.E3.83.BC.E3.83.8D.E3.83.B3.E3.83.88.E3.82.92.E5.89.8A.E9.99.A4.E3.81.99.E3.82.8B_.2F_Delete_no_need_components";
	public static final String con_REFERENCEURL_DIALOG_BUTTON = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Component_Property_Setting#.E5.85.A5.E5.8A.9B.E7.94.BB.E9.9D.A2.2F.E3.83.80.E3.82.A4.E3.82.A2.E3.83.AD.E3.82.B0.E4.B8.8A.E3.81.A7.E3.83.9C.E3.82.BF.E3.83.B3.E4.B8.8A.E3.81.AB.E3.80.8COK.E3.80.8D.E3.81.A8.E8.A8.98.E8.BC.89.E3.81.95.E3.82.8C.E3.81.A6.E3.81.84.E3.82.8B.E5.A0.B4.E5.90.88_.2F_Caption_is_.22OK.22_on_the_input_screen_or_dialog";
	public static final String con_REFERENCEURL_LABEL_EXIST_CHECK = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_10_030:The_label_in_COMPANY.28V3.6.29_should_exist_in_browser._.2F_COMPANY.28V3.6.29.E3.81.AB.E5.AD.98.E5.9C.A8.E3.81.99.E3.82.8B.E3.83.A9.E3.83.99.E3.83.AB.E3.81.8C.E3.83.96.E3.83.A9.E3.82.A6.E3.82.B6.E3.81.AB.E5.AD.98.E5.9C.A8.E3.81.99.E3.82.8B.E3.81.8B";
	public static final String con_REFERENCEURL_HORIZONTAL_BUTTON_HEIGHT = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_20_080:_The_upper_edge_of_buttons_ordered_horizontally_should_be_aligned._.2F_.E6.A8.AA.E3.81.AB.E4.B8.A6.E3.82.93.E3.81.A0.E3.80.81.E3.83.9C.E3.82.BF.E3.83.B3.E3.81.AE.E4.B8.8A.E3.81.AE.E7.AB.AF.E3.81.8C.E6.8F.83.E3.81.A3.E3.81.A6.E3.81.84.E3.82.8B.E3.81.8B";
	public static final String con_COMPONENT_RESULT_KEY = "summarizedData";
	public static final String con_REFERENCEURL_RADIO_BUTTON = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_RadioButton_Specification#.E4.BF.AE.E6.AD.A3.E5.86.85.E5.AE.B9.E8.A9.B3.E7.B4.B0_Modification_Details";
	public static final String con_REFERENCEURL_BUTTON_TYPE = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_30_090:_The_style_of_buttons_.5Bexcept_for.5D_.22.E6.A4.9C.E7.B4.A2_button.22_on_.22Search_Condition.22_panel.2F.22OK_Button.22_displayed_at_screen_should_be_.22Raised_.26_Default.22._.2F_.E7.94.BB.E9.9D.A2.E4.B8.8A.E3.81.AE.E6.A4.9C.E7.B4.A2.E6.9D.A1.E4.BB.B6.E3.83.91.E3.83.8D.E3.83.AB.E3.81.AB.E4.B9.97.E3.81.A3.E3.81.9F.22.E6.A4.9C.E7.B4.A2.22.E3.83.9C.E3.82.BF.E3.83.B3.E3.81.A8.22OK.E3.83.9C.E3.82.BF.E3.83.B3.22.E3.80.8C.E4.BB.A5.E5.A4.96.E3.80.8D.E3.81.AE.E3.83.9C.E3.82.BF.E3.83.B3.E3.81.8C.22Raised_.26_Default.22.E3.82.B9.E3.82.BF.E3.82.A4.E3.83.AB.E3.81.AB.E3.81.AA.E3.81.A3.E3.81.A6.E3.81.84.E3.82.8B.E3.81.8B";
	public static final String con_REFERENCEURL_OK_BUTTON_TYPE = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_30_100:_The_style_of_.22OK_Button.22_displayed_at_screen_should_be_.22Raised_.26_Primary.22._.2F_.E7.94.BB.E9.9D.A2.E4.B8.8A.E3.81.AB.E9.85.8D.E7.BD.AE.E3.81.95.E3.82.8C.E3.81.9F_.22OK.E3.83.9C.E3.82.BF.E3.83.B3.22.E3.81.8C.22Raised_.26_Primary.22.E3.82.B9.E3.82.BF.E3.82.A4.E3.83.AB.E3.81.AB.E3.81.AA.E3.81.A3.E3.81.A6.E3.81.84.E3.82.8B.E3.81.8B";
	public static final String con_REFERENCEURL_TAB_ICON = "http://ac-conv-redmine.internal.worksap.com/redmine/issues/134393";
	public static final String con_REFERENCEURL_HEADER_LABEL_SPACING = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Space";
	public static final String con_REFERENCEURL_DIALOG_FOOTER_PANEL = "http://huewiki/mediawiki/index.php/Plain_Dialog#Dialog_Footer_-_.E3.83.80.E3.82.A4.E3.82.A2.E3.83.AD.E3.82.B0.E3.83.95.E3.83.83.E3.82.BF.E3.83.BC";
	public static final String con_REFERENCEURL_COPY_RIGHT = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_30_170:_Footer_panel_which_displays_Copy_right_is_not_displayed._.2F.E3.82.B3.E3.83.94.E3.83.BC.E3.83.A9.E3.82.A4.E3.83.88.E3.82.92.E8.A1.A8.E7.A4.BA.E3.81.99.E3.82.8B.E3.83.95.E3.83.83.E3.82.BF.E3.83.BC.E3.83.91.E3.83.8D.E3.83.AB.E3.81.8C.E8.A1.A8.E7.A4.BA.E3.81.95.E3.82.8C.E3.81.A6.E3.81.84.E3.81.AA.E3.81.84.E3.81.8B";
	public static final String con_REFERENCEURL_ACTION_BUTTON_SPACING = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_20_120:_The_place_of_Action_Button_is_right-align._.2F_.E3.82.A2.E3.82.AF.E3.82.B7.E3.83.A7.E3.83.B3.E3.83.9C.E3.82.BF.E3.83.B3.E3.81.AE.E9.85.8D.E7.BD.AE.E3.81.AF.E5.8F.B3.E5.AF.84.E3.81.9B.E3.81.AB.E3.81.AA.E3.81.A3.E3.81.A6.E3.81.84.E3.82.8B";
	public static final String con_REFERENCEURL_DECORATION_SPACE = "http://huewiki/mediawiki/index.php/AC_HUE_Conversion_Test_Viewpoints/Supplement_Info:_UI/UX#U_30_070:_The_text_style_of_label_should_not_have_unnecessary_decoration._.2F_.E3.83.A9.E3.83.99.E3.83.AB.E3.81.AE.E3.83.86.E3.82.AD.E3.82.B9.E3.83.88.E3.81.AE.E3.82.B9.E3.82.BF.E3.82.A4.E3.83.AB.E3.81.AB.E4.BD.99.E8.A8.88.E3.81.AA.E5.8A.A0.E5.B7.A5.E3.81.8C.E5.AD.98.E5.9C.A8.E3.81.97.E3.81.AA.E3.81.84.E3.81.8B";
    public static final String con_REFERENCEURL_INPUT_FIELD_DESIGN = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Alignment";
    public static final String con_REFERENCEURL_INPUT_FIELD_ALIGNMENT = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Quick_Reference#Space";
    public static final String con_REFERENCEURL_RADIOGROUP_COLOR = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_RadioButton_Specification#.E4.BF.AE.E6.AD.A3.E5.86.85.E5.AE.B9.E8.A9.B3.E7.B4.B0_Modification_Details";

	//ScrollBar Check
	public static final String con_FC_20_110_50 = "FC_20_110_50";
	public static final String con_FC_20_110_50_MESSAGE1 = "The postion of scrollbar is not corret.\r\n";
	public static final String con_FC_20_110_50_MESSAGE2_1 = "Current HorzScrollBar.Position is ";
	public static final String con_FC_20_110_50_MESSAGE2_2 = "Current VertScrollBar.Position is ";
	public static final String con_FC_20_110_50_MESSAGE3 = "Set the scrollbar position to 0.";

	//PageControl Check
	public static final String con_FC_120_10_10 = "FC_120_10_10";
	public static final String con_FC_120_10_10_MESSAGE1_1 = "The ActivePage of tab is not corret.\r\n";
	public static final String con_FC_120_10_10_MESSAGE1_2 = "The TabIndex of tab is not corret.\r\n";
	public static final String con_FC_120_10_10_MESSAGE2_1 = "Current ActivePage is ";
	public static final String con_FC_120_10_10_MESSAGE2_2 = "Current TabIndex is ";
	public static final String con_FC_120_10_10_MESSAGE3_1 = "Set the ActivePage same as V36 to ";
	public static final String con_FC_120_10_10_MESSAGE3_2 = "Set the TabIndex same as V36 to ";

	//Output File 
	public static final String con_TEMPLATE_FOLDER = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-selfcheck\\src\\main\\resource\\template\\";

	//Toolbar Button properties check
	public static final String con_COMPONENT_NAME_HUETOOLBARCONTENTS = "huePnlToolBarContents";
	public static final String con_FC_30_20_20_MESSAGE = "The ColorStyle of the Button is not correct.\r\nCurrent ColorStyle = csPrimary.\r\nPlease Set ColorStyle = csDefault";
	public static final String con_FC_30_20_20 = "FC_30_20_20";
	public static final String con_REFERENCEURL_TOOLBAR_BUTTONS = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_Button_Specification#1._Raised_.26_Primary";

	//DateTime Input Component Width check
	public static final String con_FC_20_150_10 = "FC_20_150_10";
	public static final String con_FC_20_150_10_MESSAGE = "The width of the DateTime component is not correct.";
	public static final String con_FC_20_150_10_MESSAGE_1 = "\r\nPlease set width = 60";
	public static final String con_FC_20_150_10_MESSAGE_2 = "\r\nPlease set width = 120";
	public static final String con_FC_20_150_10_MESSAGE_3 = "\r\nPlease set width = 240";
	public static final String con_FC_20_150_10_MESSAGE_4 = "\r\nPlease set width = 480";
	public static final String con_FC_20_150_10_MESSAGE_5 = "\r\nPlease set width = 720";
	public static final String con_REFERENCEURL_DATE_TIME_COMPONENT = "http://huewiki/mediawiki/index.php/AC_HUE_Base_Design_-_DateTime_Specification";

	//SearchCondtion Panel check	
	public static final String con_FC_50_10_20 = "FC_50_10_20";
	public static final String con_FC_50_10_20_MESSAGE1 = "Panels with different background colors are placed.";
	public static final String con_FC_50_10_20_MESSAGE2 = "\n\nPlease set the Color = $00F2F1F0";

	//DialogFooter Check
	public static final String con_FC_80_10_10 = "FC_80_10_10";
	public static final String con_FC_80_10_10_MESSAGE1 = "HueButtonType = ";
	public static final String con_FC_80_10_10_MESSAGE2 = " is not correct.\n\nPlease set HueButtonType = btFlat";	

	//GridHeader Check
	public static final String con_FC_60_10_10 = "FC_60_10_10";
	public static final String con_FC_60_10_10_MESSAGE1 = "End of the button above the grid not correct";
	public static final String con_FC_60_10_10_MESSAGE2 = " The end of buttons on the grid should be aligned with the end of grid.";

	//checking Duplicate caption
	public static final String con_FC_50_20_20 = "FC_50_20_20";
	public static final String con_FC_50_20_20_MESSAGE1 = "Duplicate caption is present ";
	public static final String con_FC_50_20_20_MESSAGE2 = "Remove the Label for which caption is ";

	//checking dialog button
	public static final String con_FC_70_10_10 = "FC_70_10_10";
	public static final String con_FC_70_10_10_MESSAGE1 = "Button Type of Ok Button is not correct.\r\n ";
	public static final String con_FC_70_10_10_MESSAGE2 = "Current Button Type is ";
	public static final String con_FC_70_10_10_MESSAGE3 = "Set Button Type to ";
	public static final String con_FC_70_10_10_MESSAGE4 = "Color style of Ok Button is not correct.\r\n ";
	public static final String con_FC_70_10_10_MESSAGE5 = "Current Color Style is ";
	public static final String con_FC_70_10_10_MESSAGE6 = "Set Color Style to ";

  // checking Label
  public static final String con_U_10_030 = "U_10_030";
  public static final String con_U_10_030_MESSAGE1 = "Label Should be same as per Company.\r\n ";
  public static final String con_U_10_030_MESSAGE2 = "Label is not same for component ";
  public static final String con_U_10_030_MESSAGE3 = "Current Label is  ";
  public static final String con_U_10_030_MESSAGE4 = "Correct Label is  ";
  public static final String con_U_10_030_MESSAGE5 = "Label Component not exists: ";
  public static final String con_U_10_030_CAPTION_NG1 = "・";
  public static final String con_U_10_030_CAPTION_NG4 = ".";
  public static final String con_U_10_030_CAPTION_NG2 = "+";
  public static final String con_U_10_030_CAPTION_NG3 = "－";

	// checking Horizontal Buttons
	public static final String con_U_20_080 = "U_20_080";
	public static final String con_U_20_080_MESSAGE1 = "Upper edge of buttons ordered horizontally should be aligned. ";
	public static final String con_U_20_080_MESSAGE2 = "Top of the button  ";

	//checking radiobutton font color
	public static final String con_U_10_010 = "U_10_010";
	public static final String con_U_10_010_MESSAGE1 = "The Radio button Color is not correct.";
	public static final String con_U_10_010_MESSAGE2 = "Current Color of the radio button is : ";
	public static final String con_U_10_010_MESSAGE3 = "Set the radio button color to : ";

	// checking the color of all the buttons except ok and search button
	public static final String con_U_30_090 = "U_30_090";
	public static final String con_U_30_090_MESSAGE1 = "Button Type is not correct.";
	public static final String con_U_30_090_MESSAGE2 = "Current Button Type is : ";
	public static final String con_U_30_090_MESSAGE3 = "Set Button Type to : ";
	public static final String con_U_30_090_MESSAGE4 = "Color style of Button is not correct.";
	public static final String con_U_30_090_MESSAGE5 = "Current Color Style is ";
	public static final String con_U_30_090_MESSAGE6 = "Set Color Style to :  ";

	public static final String con_U_30_100 = "U_30_100";
	public static final String con_U_30_100_MESSAGE1 = "OK Button Type is not correct.";
	public static final String con_U_30_100_MESSAGE2 = "Current Button Type is : ";
	public static final String con_U_30_100_MESSAGE3 = "Set Button Type to : ";
	public static final String con_U_30_100_MESSAGE4 = "Color style of OK Button is not correct.";
	public static final String con_U_30_100_MESSAGE5 = "Current Color Style is ";
	public static final String con_U_30_100_MESSAGE6 = "Set Color Style to :  ";

	//checking the count of radio button in company and hue
	public static final String con_U_10_050 = "U_10_050";
	public static final String con_U_10_050_MESSAGE1 = "The count of radiobuttons doesnot match with the company";
	public static final String con_U_10_050_MESSAGE2 = "The count of radiobuttons in hue is : ";
	public static final String con_U_10_050_MESSAGE3 = "The count of radiobuttons in company is : ";
	public static final String con_U_10_050_MESSAGE4 = "RadioGroup color is not correct.\r\n";
	public static final String con_U_10_050_MESSAGE5 = "Please set the Color = clWhite.\r\n";
	public static final String con_U_10_050_MESSAGE6 = "Please set the Color = d0d0d0.\r\n";



	//checking the icon in tab
	public static final String con_U_10_060 = "U_10_060";
	public static final String con_U_10_060_MESSAGE1 = "The tab : ";
	public static final String con_U_10_060_MESSAGE2 = " is having Icon";
	public static final String con_U_10_060_MESSAGE3 = "Remove the Icon present in Tab component.\r\n ";
	public static final String con_U_10_060_MESSAGE4 = "Kindly refer the Redmine Inquiry mentioned in Reference URL column.";

	//checking the header label spacing
	public static final String con_U_10_010_HEADER_LABEL_MESSAGE1 = "The Header Label spacing is not correct.";
	public static final String con_U_10_010_HEADER_LABEL_MESSAGE2 = "Current Spacing is : ";
	public static final String con_U_10_010_HEADER_LABEL_MESSAGE3 = "Maintain 8px between Header Label and next component.";
	
	 
	  //checking the Ok/Cancel button panel
	  public static final String con_U_10_020 = "U_10_020";
	  public static final String con_U_10_020_MESSAGE1 = "Dialog Footer button placed in a wrong panel.\r\n";
	  public static final String con_U_10_020_MESSAGE2 = " Button should be moved under "+con_COMPONENT_NAME_HUEPNLDIALOGFOOTERBASE+" Panel.\r\n";

  // checking Unnecessary Decorations
  public static final String con_U_30_070 = "U_30_070";
  public static final String con_U_30_070_MESSAGE1 = "No need to show symbols (+ / -) only in Header label. ";
  public static final String con_U_30_070_MESSAGE2 = "Current Label is ";
  public static final String con_U_30_070_MESSAGE3 = "Remove Unnecessary Symbols in Header Label";
  public static final String con_U_30_070_MESSAGE4 = "Font style  ";
  public static final String con_U_30_070_MESSAGE5 = " is not correct.";
  public static final String con_U_30_070_MESSAGE6 = "Current Font style is Font.Style.fsItalic = True.";
  public static final String con_U_30_070_MESSAGE7 = "Please set \"Font.Style.fsItalic = False\".";
  public static final String con_U_30_070_MESSAGE8 = "Remove the unnecessary space in the label.\r\n ";
  public static final String con_U_30_070_MESSAGE9 = "Example : \r\n";
  public static final String con_U_30_070_MESSAGE10 = "(  銀行名   ) , Extra space is removed at the front (銀行名)  \r\n";
  public static final String con_U_30_070_MESSAGE11 = "Current Font style is Font.Style.fsUnderline = True.";
  public static final String con_U_30_070_MESSAGE12 = "Please set \"Font.Style.fsUnderline = False\".";
  
  
  // checking Header Label
  public static final String con_U_30_170 = "U_30_170";
  public static final String con_U_30_170_MESSAGE1 = "Footer panel which displays Copy right should is not be displayed.\r\n";
  public static final String con_U_30_170_MESSAGE2 = "Set Visible to False.\r\n";
  public static final String con_U_30_170_MESSAGE3 = "Set Height to 0.\r\n";

  // checking Label Center Alignment
  public static final String con_U_10_040 = "U_10_040";
  public static final String con_U_10_040_MESSAGE1 = "Label should be center aligned with field ";
  public static final String con_U_10_040_MESSAGE2 = "Layout Type for Label is  ";
  public static final String con_U_10_040_MESSAGE3 = "Set the Layout Type to ";
  public static final String con_U_10_040_MESSAGE4 = "Label is not center aligned with the field ";
  public static final String con_U_10_040_MESSAGE5 = "Label should be center aligned with the field ";

  // checking Input Field
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE1 = "Right Ends of all Input Labels should be aligned in vertical Direction";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE2 = "Input Label ";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE3 = "are not aligned in Vertical Direction";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE4 = "Left ends of all Edit should be aligned in the vertical direction";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE5 = "Edit Field ";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE6 = " are  not aligned in Vertical Direction";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE7 = "Left end of Input label should be aligned with the left end of Edit.";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE8 = "Left end of Input label ";
  public static final String con_U_10_010_INPUT_FIELD_MESSAGE9 = " is not algned with the left end of Edit ";

  // checking whether space exists in action buttons
  public static final String con_U_20_120 = "U_20_120";
  public static final String con_U_20_120_MESSAGE1 = "The space between action buttons is not correct.\r\n";
  public static final String con_U_20_120_MESSAGE2 = "Keep the space between action buttons as 8px as per standard";

  //checking whether space exists in action buttons
  public static final String con_U_20_010 = "U_20_010";
  public static final String con_U_20_010_MESSAGE1 = "The space between the components ";
  public static final String con_U_20_010_MESSAGE2 = " and ";
  public static final String con_U_20_010_MESSAGE3 = " is not correct.\r\n";
  public static final String con_U_20_010_MESSAGE4 = "Keep the horizontal space between Label and the components as 16px as per standard.";
  public static final String con_U_20_010_MESSAGE5 = "Keep the horizontal space between components as 8px as per standard.";
  public static final String con_U_20_010_MESSAGE6 = "Keep the horizontal space between Components and the Label as 32px as per standard.";
  public static final String con_U_20_010_MESSAGE7 = "Keep the vertical space between components as 8px as per standard.";
}
