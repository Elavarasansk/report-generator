package org.intrawebtools.uiux_enhancer.entity;

import org.intrawebtools.uiux_enhancer.enums.ComponentType;
import org.intrawebtools.uiux_enhancer.enums.License;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResultEntity {
  private String filePath;

  private License license;

  private ComponentType componentType;

  private String component;

  private String name;

  private String property;

  private String propertyValue;

  private String beforeChanges;

  private String afterChanges;

  private String comment;

}
