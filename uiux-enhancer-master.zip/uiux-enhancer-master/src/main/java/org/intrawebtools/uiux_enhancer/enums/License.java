package org.intrawebtools.uiux_enhancer.enums;

import lombok.Getter;

@Getter
public enum License {
	CAC("Common Module"),
	CFM("Financial Management"),
	CBM("Business Management"),
	CAM("Assets Management"),
	CCM("Cash Management");
	
	private String name;
	
	private License(String name) {
		this.name = name;
	}
	
  public static License getEnum(String name) {
    for (License en : License.values()) {
      if (name.equals(en.getName())) {
        return en;
      }
    }
    return null;
  }
}
