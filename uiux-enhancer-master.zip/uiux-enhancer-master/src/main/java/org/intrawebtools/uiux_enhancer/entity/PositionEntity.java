package org.intrawebtools.uiux_enhancer.entity;

import java.util.HashMap;
import java.util.Map;

public class PositionEntity {
  String name;
  int level;
  Map<String, Integer> positionMap;
  Map<Integer, String> parentsMap;
  ComponentPropertyEntity component;

  public PositionEntity(String name, int level, Map<Integer, String> parentsMap, ComponentPropertyEntity component) {
    this.name = name;
    this.level = level;
    this.parentsMap = parentsMap;
    this.component = component;
    this.positionMap = new HashMap<>();
  }

  public void setRect(int left, int top, int width, int height) {
    this.positionMap.put("Left", left);
    this.positionMap.put("Top", top);
    this.positionMap.put("Width", width);
    this.positionMap.put("Height", height);
  }

  public void setRect(int left, int top, int width, int height, int oldTop, int oldLeft) {
    this.positionMap.put("Left", left);
    this.positionMap.put("Top", top);
    this.positionMap.put("Width", width);
    this.positionMap.put("Height", height);
    this.positionMap.put("OldTop", oldTop);
    this.positionMap.put("OldLeft", oldLeft);
  }

  public int getSortKey() {
    int left = this.positionMap.get("Left");
    int top = this.positionMap.get("Top");
    return (top * 1000) + left;
  }

  public ComponentPropertyEntity getComponentProperties() {
    return this.component;
  }

  public String getName() {
    return this.name;
  }

  public Map<String, Integer> getPositionMap() {
    return positionMap;
  }

  public Map<Integer, String> getParents() {
    return parentsMap;
  }

  public int getLevel() {
    return level;
  }
}
