package org.intrawebtools.uiux_enhancer.entity;

import java.util.ArrayList;
import java.util.List;

public class ComponentCheckOrderResultEntity {
	List<String> wrongPositionRelationshipTargets;
  List<ResultEntity> outputResult;
	
	public ComponentCheckOrderResultEntity(){
		this.wrongPositionRelationshipTargets = new ArrayList<>();
		this.outputResult = new ArrayList<>();
	}
	
  public List<ResultEntity> getOutputResult() {
		return this.outputResult;
	}
	
	public List<String> getWrongPositionRelationshipTargets(){
		return this.wrongPositionRelationshipTargets;
	}
	
	public void putInWrongPositionRelationshipTargets(String name){
		boolean isInWrongPositionRelationshipTargets = true;
		if(this.wrongPositionRelationshipTargets.indexOf(name) == -1){
			isInWrongPositionRelationshipTargets = false;
		}
		if(!isInWrongPositionRelationshipTargets){
			this.wrongPositionRelationshipTargets.add(name);
		}
	}
}
