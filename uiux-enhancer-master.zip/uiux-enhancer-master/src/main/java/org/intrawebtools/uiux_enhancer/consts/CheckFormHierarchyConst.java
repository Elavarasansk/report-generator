package org.intrawebtools.uiux_enhancer.consts;

import java.util.HashMap;
import java.util.Map;

public class CheckFormHierarchyConst {
	
	public static boolean getWhiteList(String formName) {
		switch(formName){
			case "accommon\\CfwClasses\\CfwRootFrm.pas": return true;
			case "accommon\\CfwClasses\\CfwBaseFrm.pas": return true;
			case "accommon\\CfwClasses\\CfwBaseFrmExCool.pas": return true;
			case "accommon\\CfwClasses\\CfwReportFrm.pas": return true;
			case "accommon\\CfwClasses\\CfwDlg.pas": return true;
			case "accommon\\CfwClasses\\ReportPreviewDlg.pas": return true;
			case "accommon\\CfwClasses\\CfwReadDlg.pas": return true;
			default: return false;
		}
	}

	//HUEで新しく追加されたファイル
	public static Map<String, String> HUE_ORIGINAL_FORMS = new HashMap<String, String>();
	static{
		HUE_ORIGINAL_FORMS.put("TCfwRootPlainFrame", "CfwRootPlainFrm");
		HUE_ORIGINAL_FORMS.put("TCfwRootDetailFrame", "CfwRootDetailFrm");
		HUE_ORIGINAL_FORMS.put("TCfwRootPlainDialog", "CfwRootPlainDlg");
		HUE_ORIGINAL_FORMS.put("TCfwRootSearchDialog", "CfwRootSearchDlg");
		HUE_ORIGINAL_FORMS.put("TCfwBasePlainFrame", "CfwBasePlainFrm");
		HUE_ORIGINAL_FORMS.put("TCfwBaseListFrame", "CfwBaseListFrm");
		HUE_ORIGINAL_FORMS.put("TCfwBasePlainFrameExCool", "CfwBasePlainFrmExCool");
		HUE_ORIGINAL_FORMS.put("TCfwBaseListFrameExCool", "CfwBaseListFrmExCool");
		HUE_ORIGINAL_FORMS.put("TCfwReportMainFrame", "CfwReportMainFrm");
		HUE_ORIGINAL_FORMS.put("TCfwReportDialog", "CfwReportDlg");
		HUE_ORIGINAL_FORMS.put("TCfwBasePlainDialog", "CfwBasePlainDlg");
		HUE_ORIGINAL_FORMS.put("TCfwBaseSearchDialog", "CfwBaseSearchDlg");
		HUE_ORIGINAL_FORMS.put("TCfwPlainFrame", "CfwPlainFrm");
		HUE_ORIGINAL_FORMS.put("TCfwDetailFrame", "CfwDetailFrm");
		HUE_ORIGINAL_FORMS.put("TCfwPlainDialog", "CfwPlainDlg");
	};

	//WhiteList(継承元を必ず取得できるフォーム = HUEで新しく追加されたクラスよりも上位のクラス）
	public static Map<String, String> PARENT_FORMS = new HashMap<String, String>();
	static{
		PARENT_FORMS.put("TCfwRootFrame", "CfwRootFrm");
		PARENT_FORMS.put("TCfwBaseFrame", "CfwBaseFrm");
		PARENT_FORMS.put("TCfwBaseFrameExCool", "CfwBaseFrmExCool");
		PARENT_FORMS.put("TCfwReportFrame", "CfwReportFrm");
		PARENT_FORMS.put("TCfwDialog", "CfwDlg");
		PARENT_FORMS.put("TCfwReportPreviewDialog", "ReportPreviewdlg");
		PARENT_FORMS.put("TCfwReadDialog", "CfwReadDlg");
		PARENT_FORMS.put("TForm", "tform");
		PARENT_FORMS.put("tform", "tform");
	};

	//CBM Common WhiteList
	public static Map<String, String> CBM_COMMON_FORMES = new HashMap<String, String>();
	static{
		CBM_COMMON_FORMES.put("TCbmProcFrame", "CBM\\CBMcommon\\CbmProc\\CbmProcFrm.pas");
		CBM_COMMON_FORMES.put("TCbmProcRecalcDialog", "CBM\\CBMcommon\\CbmProc\\CbmProcReclalcDlg.pas");
		CBM_COMMON_FORMES.put("TCbmProcModeSelectDialog", "CBM\\CBMcommon\\CbmProc\\Dlg_CbmProcModeSelect.pas");
		CBM_COMMON_FORMES.put("TfrmCheckJob", "CBM\\CBMcommon\\ClosingTerm\\CheckJob\\CheckJobMainFrm.pas");
		CBM_COMMON_FORMES.put("TfrmArbitarlityClosing", "CBM\\CBMcommon\\ClosingTerm\\Common\\CTArbitarlityClosingDig.pas");
		CBM_COMMON_FORMES.put("TfrmCTComMain", "CBM\\CBMcommon\\ClosingTerm\\Common\\CTComFrm.pas");
		CBM_COMMON_FORMES.put("TfrmCTErrInfo", "CBM\\CBMcommon\\ClosingTerm\\Common\\CTErrInfoFrm.pas");
		CBM_COMMON_FORMES.put("TfrmSetLayoutManager", "CBM\\CBMcommon\\ClosingTerm\\Common\\CTLayoutManagerSetFrm.pas");
		CBM_COMMON_FORMES.put("TFrmViewJobContents", "CBM\\CBMcommon\\ClosingTerm\\Common\\ViewJobContents.pas");
		CBM_COMMON_FORMES.put("TfrmCopyDSec", "CBM\\CBMcommon\\ClosingTerm\\Job\\ClosingJobCopyDSec.pas");
		CBM_COMMON_FORMES.put("TfrmCopyJob", "CBM\\CBMcommon\\ClosingTerm\\Job\\ClosingJobCopyJob.pas");
		CBM_COMMON_FORMES.put("TfrmDeleteJob", "CBM\\CBMcommon\\ClosingTerm\\Job\\ClosingJobDeleteJob.pas");
		CBM_COMMON_FORMES.put("TfrmClosingJobDlg", "CBM\\CBMcommon\\ClosingTerm\\Job\\ClosingJobDlg.pas");
		CBM_COMMON_FORMES.put("TfrmClosingJobMain", "CBM\\CBMcommon\\ClosingTerm\\Job\\ClosingJobMain.pas");
		CBM_COMMON_FORMES.put("TfrmMakeJob", "CBM\\CBMcommon\\ClosingTerm\\Job\\ClosingJobMakeJob.pas");
		CBM_COMMON_FORMES.put("TfrmHistOptCloseMain", "CBM\\CBMcommon\\ClosingTerm\\Optional\\HistOptCloseMain.pas");
		CBM_COMMON_FORMES.put("TfrmOptionalClosingTermMain", "CBM\\CBMcommon\\ClosingTerm\\Optional\\OptionalClosingTermMain.pas");
		CBM_COMMON_FORMES.put("TfrmChangeActStr", "CBM\\CBMcommon\\ClosingTerm\\Ptn\\ChangeActStr.pas");
		CBM_COMMON_FORMES.put("TfrmChangePtnNm", "CBM\\CBMcommon\\ClosingTerm\\Ptn\\ChangePtnNm.pas");
		CBM_COMMON_FORMES.put("TfrmClosingPtnMain", "CBM\\CBMcommon\\ClosingTerm\\Ptn\\ClosingPtnMain.pas");
		CBM_COMMON_FORMES.put("TfrmDtlAct", "CBM\\CBMcommon\\ClosingTerm\\Ptn\\DetailAct.pas");
		CBM_COMMON_FORMES.put("TfrmDtlPtn", "CBM\\CBMcommon\\ClosingTerm\\Ptn\\DetailPtn.pas");
		CBM_COMMON_FORMES.put("TCbmCollAdjustComFrame", "CBM\\CBMcommon\\Collation\\Common\\Adjust\\CbmCollAdjustComFrm.pas");
		CBM_COMMON_FORMES.put("TCbmCollLumpAdjustDialog", "CBM\\CBMcommon\\Collation\\Common\\Adjust\\CbmCollLumpAdjustDlg.pas");
		CBM_COMMON_FORMES.put("TAutoLoadTimeDialog", "CBM\\CBMcommon\\Collation\\Common\\AutoLoad\\AutoLoadTimeDlg.pas");
		CBM_COMMON_FORMES.put("TCbmComCollViewComFrame", "CBM\\CBMcommon\\Collation\\Common\\ViewCommon\\CbmComCollViewComFrm.pas");
		CBM_COMMON_FORMES.put("TCbmArCollProcDataViewFrame", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\CbmArCollProcDataViewFrm.pas");
		CBM_COMMON_FORMES.put("TCbmArCollProcDialog", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\CbmArCollProcDlg.pas");
		CBM_COMMON_FORMES.put("TCbmArCollProcResViewFrame", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\CbmArCollProcResViewFrm.pas");
		CBM_COMMON_FORMES.put("TCbmComCollConvProcFrame", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\CbmComCollConvProcFrm.pas");
		CBM_COMMON_FORMES.put("TFormInDataManualComplete", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\RegProcManualComp\\FrmInDataManualComplete.pas");
		CBM_COMMON_FORMES.put("TFormInDataManualCompleteDate", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\RegProcManualComp\\FrmInDataManualCompleteDate.pas");
		CBM_COMMON_FORMES.put("TFormInDataManualCompleteNumber", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\RegProcManualComp\\FrmIndataManualCompleteNumber.pas");
		CBM_COMMON_FORMES.put("TFormInDataManualCompleteString", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\RegProcManualComp\\FrmInDataManualCompleteString.pas");
		CBM_COMMON_FORMES.put("TInDataManualCompleteFormBuilder", "CBM\\CBMcommon\\Collation\\Proc\\CbmComCollConvProc\\RegProcManualComp\\InDataManualCompleteFrmBuilder.pas");
		CBM_COMMON_FORMES.put("TCbmCollReportFrm", "CBM\\CBMcommon\\Collation\\Report\\CbmCollReport.pas");
		CBM_COMMON_FORMES.put("TCbmComCollInDataViewFrame", "CBM\\CBMcommon\\Collation\\View\\InDataView\\CbmComCollInDataView\\CbmComCollInDataViewFrm.pas");
		CBM_COMMON_FORMES.put("TCbmComCollResViewDebtDtlFrame", "CBM\\CBMcommon\\Collation\\View\\ResView\\AP\\CbmComCollResViewDebtDtl\\CbmComCollResViewDebtDtlFrm.pas");
		CBM_COMMON_FORMES.put("TCbmComCollResViewDebtHdFrame", "CBM\\CBMcommon\\Collation\\View\\ResView\\AP\\CbmComCollResViewDebtHd\\CbmComCollResViewDebtHdFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalCommonListFrame", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalCommonListFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalCommonSearchDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalCommonSearchDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalCrdtDtlReferenceFrame", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalCrdtDtlReferenceFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalCrdtDtlSearchDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalCrdtDtlSearchDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalDebtDtlReferenceFrame", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalDebtDtlReferenceFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalDebtDtlSearchDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalDebtDtlSearchDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalDtlReferenceFrame", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalDtlReferenceFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalDtlSearchDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalDtlSearchDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalHdSearchDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalHdSearchDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalOmitPtnDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalOmitPtnDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalOmitPtnFrame", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalOmitPtnFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalTargetCondDialog", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalTargetCondDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalTargetCondFrame", "CBM\\CBMcommon\\Confbalance\\Common\\ConfbalTargetCondFrm.pas");
		CBM_COMMON_FORMES.put("TDictManager", "CBM\\CBMcommon\\Confbalance\\Common\\Dict.pas");
		CBM_COMMON_FORMES.put("TJobDataFrame", "CBM\\CBMcommon\\Confbalance\\Common\\JobDataFrm.pas");
		CBM_COMMON_FORMES.put("TOmitTargetCondSearchFrame", "CBM\\CBMcommon\\Confbalance\\Common\\OmitTargetCondSearchFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalInputMemoDialog", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalInputMemoDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalIssueFrame", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalIssueFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalListReportFrame", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalListReportFrm.pas");
		CBM_COMMON_FORMES.put("TConfbalManualOmitMemoDialog", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalManualOmitMemoDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalRefPreDateDialog", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalRefPreDateDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalReIssueReasonDialog", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalReIssueReasonDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalSettingOption", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalSettingOptionDlg.pas");
		CBM_COMMON_FORMES.put("TConfbalUpdateAddressDialog", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\ConfbalUpdateAddressDlg.pas");
		CBM_COMMON_FORMES.put("TJobListFrame", "CBM\\CBMcommon\\Confbalance\\ConfbalIsManager\\JobListFrm.pas");
		CBM_COMMON_FORMES.put("TCusupGrpSearchFrame", "CBM\\CBMcommon\\Confbalance\\ConfbalSetMst\\CusupGrpSearchFrm.pas");
		CBM_COMMON_FORMES.put("TItemGrpSearchFrame", "CBM\\CBMcommon\\Confbalance\\ConfbalSetMst\\ItemGrpSearchFrm.pas");
		CBM_COMMON_FORMES.put("TFrmAdvanceUserDefaultSetting", "CBM\\CBMcommon\\Contract\\Advance\\Common\\AdvanceUserDefaultSetting.pas");
		CBM_COMMON_FORMES.put("TfrmAdvanceDrillDownBaseDlg", "CBM\\CBMcommon\\Contract\\Advance\\Frame\\AdvanceDrillDownBaseDlg.pas");
		CBM_COMMON_FORMES.put("TAdvanceMainListBaseFrame", "CBM\\CBMcommon\\Contract\\Advance\\Frame\\AdvanceMainListBaseFrm.pas");
		CBM_COMMON_FORMES.put("TDictManager", "CBM\\CBMcommon\\CrdtDebt\\SaveBalance\\Common\\Dict.pas");
		CBM_COMMON_FORMES.put("TSaveBalanceDialog", "CBM\\CBMcommon\\CrdtDebt\\SaveBalance\\Common\\SaveBalanceDlg.pas");
		CBM_COMMON_FORMES.put("TSaveBalanceListDlgFromRefFrame", "CBM\\CBMcommon\\CrdtDebt\\SaveBalance\\Common\\SaveBalanceListDlgFromRefFrm.pas");
		CBM_COMMON_FORMES.put("TGeneratorFilePreViewDialog", "CBM\\CBMcommon\\Generator\\Common\\FileOutput\\GeneratorFilePreViewDlg.pas");
		CBM_COMMON_FORMES.put("TGeneratorManagerLstDialog", "CBM\\CBMcommon\\Generator\\Common\\FileOutput\\GeneratorManagerLstDlg.pas");
		CBM_COMMON_FORMES.put("TGeneratorManagerLstFileNameDialog", "CBM\\CBMcommon\\Generator\\Common\\FileOutput\\GeneratorManagerLstFileNameDlg.pas");
		CBM_COMMON_FORMES.put("TGeneratorManagerLstSearchDialog", "CBM\\CBMcommon\\Generator\\Common\\FileOutput\\GeneratorManagerLstSearchDlg.pas");
		CBM_COMMON_FORMES.put("TJnlWorkFlowPreviewDlgImpl", "CBM\\CBMcommon\\Jnl\\Jnl20\\BasicJnl\\Common\\JnlWorkFlowMultiDlgFrm.pas");
		CBM_COMMON_FORMES.put("TJnlWorkFlowDlg", "CBM\\CBMcommon\\Jnl\\Jnl20\\Frame\\JnlWorkFlowDlgFrm.pas");
		CBM_COMMON_FORMES.put("TJnlWorkFlowDlgInternal", "CBM\\CBMcommon\\Jnl\\Jnl20\\Frame\\JnlWorkFlowDlgLayoutMngFrm.pas");
		CBM_COMMON_FORMES.put("TFe_JrnlEditDlg", "CBM\\CBMcommon\\Jnl\\JnlEdit\\Fe_JrnlEditDlgFrm.pas");
		CBM_COMMON_FORMES.put("TFe_JrnlEditDlgNeo", "CBM\\CBMcommon\\Jnl\\JnlEdit\\Fe_JrnlEditDlgFrmNeo.pas");
		CBM_COMMON_FORMES.put("TJrnlEditDlg", "CBM\\CBMcommon\\Jnl\\JnlEdit\\JrnlEditDlgFrm.pas");
		CBM_COMMON_FORMES.put("TJrnlEditDlgNeo", "CBM\\CBMcommon\\Jnl\\JnlEdit\\JrnlEditDlgFrmNeo.pas");
		CBM_COMMON_FORMES.put("TJnlPreviewDlg", "CBM\\CBMcommon\\Jnl\\JnlPreview\\JnlDlgFrm.pas");
		CBM_COMMON_FORMES.put("TJnlPreviewExtraDlg", "CBM\\CBMcommon\\Jnl\\JnlPreview\\JnlExtraDlgFrm.pas");
		CBM_COMMON_FORMES.put("TJnlPreviewSegDlg", "CBM\\CBMcommon\\Jnl\\JnlPreview\\JnlSegDlgFrm.pas");
		CBM_COMMON_FORMES.put("TMainFrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Apply\\CbmCustomerApplyMainList.pas");
		CBM_COMMON_FORMES.put("TNewMainfrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Apply\\CbmCustomerApplyNewMainList.pas");
		CBM_COMMON_FORMES.put("TMainFrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Approval\\CbmCustomerApplyApprovalMainList.pas");
		CBM_COMMON_FORMES.put("TModifyMainFrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Approval\\CbmCustomerApplyModifyApprovalMain.pas");
		CBM_COMMON_FORMES.put("TNewMainFrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Approval\\CbmCustomerApplyNewApprovalMain.pas");
		CBM_COMMON_FORMES.put("TFrmApDealCond", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\ApDealCondDlg.pas");
		CBM_COMMON_FORMES.put("TFrmArDealCond", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\ArDealCondDlg.pas");
		CBM_COMMON_FORMES.put("TCbmCusAppOutputCsvDlgFrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CbmCusAppOutputCsvFrm.pas");
		CBM_COMMON_FORMES.put("TMainDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CbmCustomerApplyDlg.pas");
		CBM_COMMON_FORMES.put("TSetReasonDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CbmCustomerApplySetReasonDlg.pas");
		CBM_COMMON_FORMES.put("TNewApplyDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CbmCustomerNewApplyDlg.pas");
		CBM_COMMON_FORMES.put("TCusAppCautionDialog", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CusAppCautionDlg.pas");
		CBM_COMMON_FORMES.put("TfrmCustomerApplyOption", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CustomerApplyOption.pas");
		CBM_COMMON_FORMES.put("TShowModifyDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CustomerApplyShowModifyDlg.pas");
		CBM_COMMON_FORMES.put("TfrmCustomerCorp", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CustomerCorpDlg.pas");
		CBM_COMMON_FORMES.put("TModifyApplyDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CustomerModifyApplyDlg.pas");
		CBM_COMMON_FORMES.put("TFrmCustomerOpt", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\CustomerOptDlg.pas");
		CBM_COMMON_FORMES.put("TfrmDeliverySeg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\DeliverySegDlg.pas");
		CBM_COMMON_FORMES.put("TFrmDemandSeg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\DemandSegDlg.pas");
		CBM_COMMON_FORMES.put("TFrmError", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\ErrorDlg.pas");
		CBM_COMMON_FORMES.put("TSearchOldHistoryFrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\SearchCustomerOldHistory.pas");
		CBM_COMMON_FORMES.put("TSelectApptypeDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\SelectApplyTypeDlg.pas");
		CBM_COMMON_FORMES.put("TCustomerApplyDisUseDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\SelectDisUseMstDlg.pas");
		CBM_COMMON_FORMES.put("TInputStartDateDlg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\StartDateKicker.pas");
		CBM_COMMON_FORMES.put("TFrmSupplierOpt", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\SupplierOptDlg.pas");
		CBM_COMMON_FORMES.put("TFrmSupplierSeg", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\Dlg\\SupplierSegDlg.pas");
		CBM_COMMON_FORMES.put("TModifyMainfrm", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\ModifyApply\\CbmCustomerApplyModifyMainList.pas");
		CBM_COMMON_FORMES.put("TModifyMain", "CBM\\CBMcommon\\MstMaint\\CustomerApply\\ModifyApproval\\CbmCustomerApplyModifyApprovalMain.pas");
		CBM_COMMON_FORMES.put("TfrmCbmMyNumDlg", "CBM\\CBMcommon\\MyNumber\\CbmMyNumDlg.pas");
		CBM_COMMON_FORMES.put("TfrmMyNumberLumpInput", "CBM\\CBMcommon\\MyNumber\\LumpInput.pas");
		CBM_COMMON_FORMES.put("TfrmMyNumberErrorDlg", "CBM\\CBMcommon\\MyNumber\\MyNumberErrorDlg.pas");
		CBM_COMMON_FORMES.put("TfrmHandOffsetMain", "CBM\\CBMcommon\\Offset\\HandOffset\\frmHandOffsetMainU.pas");
		CBM_COMMON_FORMES.put("TdmDictMng", "CBM\\CBMcommon\\Offset\\OffsetCommon\\OffsetDictMng.pas");
		CBM_COMMON_FORMES.put("TfrmSetDtlOrder", "CBM\\CBMcommon\\Offset\\OffsetCommon\\SetDtlOrderU.pas");
		CBM_COMMON_FORMES.put("TfrmViewOffsetDtl", "CBM\\CBMcommon\\Offset\\OffsetCommon\\ViewOffsetDtlU.pas");
		CBM_COMMON_FORMES.put("TfrmOffsetDSecMstDlg", "CBM\\CBMcommon\\Offset\\OffsetDSecMst\\frmOffsetDSecMstDlgU.pas");
		CBM_COMMON_FORMES.put("TfrmOffsetDSecMst", "CBM\\CBMcommon\\Offset\\OffsetDSecMst\\frmOffsetDSecMstU.pas");
		CBM_COMMON_FORMES.put("TCbmSlipRepFrm20", "CBM\\CBMcommon\\Report\\JNL\\CbmSlipReport20\\CbmSlipReportFrm20.pas");
		CBM_COMMON_FORMES.put("TJnlWorkFlowDlgInternalAbst", "CBM\\CBMcommon\\Jnl\\Jnl20\\Frame\\JnlWorkFlowDlgFrm.pas");
		CBM_COMMON_FORMES.put("TPayReqListCondCommonFrm", "CBM\\AP\\PayRequest2\\Common\\Frm\\PayReqListCondCommon.pas");
		CBM_COMMON_FORMES.put("TCBMInputCommonDlgDtlFrm", "CBM\\Common\\Frame\\Input\\CBMInputCommonDlgDtl.pas");
		CBM_COMMON_FORMES.put("TDuepaymentCommonFrm", "CBM\\Common\\Request\\DuePay\\Frm\\DuepaymentCommon.pas");
		CBM_COMMON_FORMES.put("TPayReqHdCommonFrm", "CBM\\Common\\Request\\PayReq\\Frm\\PayReqHdCommon.pas");
	};
}
