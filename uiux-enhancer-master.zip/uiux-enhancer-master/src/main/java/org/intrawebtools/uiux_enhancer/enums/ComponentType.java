package org.intrawebtools.uiux_enhancer.enums;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;

@Getter
public enum ComponentType {
	LABEL("Label"),
	BUTTON("Button"),
	PANEL("Panel"),
	SHAPE("Shape"),
	CHECKBOX("CheckBox"),
	RADIOBUTTON("RadioButton"),
	LIST_VIEW("ListView"),
	ACTION("Action"),
	TAB("Tab"),
	EDIT("Edit"),
	COMBO("Combo"),
	MEMO("Memo"),
	CURRENCYCTRL("CurrencyCtrl"),
	DATE_TIME("DateTime"),
	MASK("Mask"),
	ZIPCODE("ZipCode"),
	CALENDAR("Calendar"),
	GRID("Grid"),
	LISTBOX("ListBox"),
	BEVEL("Bevel"),
	SPLITTER("Splitter"),
	MULTIPLE(""),
	IMAGE("Image"),
  COOLBAR("CoolBar"),
  TOOLBAR("ToolBar"),
  STATUSBAR("StatusBar"),
  SCROLLBOX("ScrollBox"),
	NON_COMPONENT("");
	
	private String name;
	
	private ComponentType(String name) {
		this.name = name;
	}
	
	public static ComponentType getEnum(String name) {
		for (ComponentType en : ComponentType.values()) {
			if (name.equals(en.getName())) {
				return en;
			}
		}
		return null;
	}
	
	public static Map<String, ComponentType> COMPONENT_TYPE_MAP = new HashMap<>();
	static{
		COMPONENT_TYPE_MAP.put("TButton",BUTTON);
		COMPONENT_TYPE_MAP.put("TWAButton",BUTTON);
		COMPONENT_TYPE_MAP.put("TBitBtn",BUTTON);
		COMPONENT_TYPE_MAP.put("TWABitBtn",BUTTON);
		COMPONENT_TYPE_MAP.put("TSpeedButton",BUTTON);
		COMPONENT_TYPE_MAP.put("TWASpeedButton",BUTTON);
		COMPONENT_TYPE_MAP.put("TVisualButton",BUTTON);
		COMPONENT_TYPE_MAP.put("TVisualButtonEx",BUTTON);
		COMPONENT_TYPE_MAP.put("TWAToolButton",BUTTON);
		COMPONENT_TYPE_MAP.put("TVisualButtonNeo",BUTTON);
		COMPONENT_TYPE_MAP.put("TWAToolButton", BUTTON);
		COMPONENT_TYPE_MAP.put("TIniLabel2",LABEL);
		COMPONENT_TYPE_MAP.put("TSmartLabel",LABEL);
		COMPONENT_TYPE_MAP.put("TWALabel",LABEL);
		COMPONENT_TYPE_MAP.put("TWACustomLabel",LABEL);
		COMPONENT_TYPE_MAP.put("TLinkLabel",LABEL);
		COMPONENT_TYPE_MAP.put("TWAStaticText",LABEL);
		COMPONENT_TYPE_MAP.put("TLabel",LABEL);
		COMPONENT_TYPE_MAP.put("TWAPanel",PANEL);
		COMPONENT_TYPE_MAP.put("TPanel",PANEL);
		COMPONENT_TYPE_MAP.put("TWAScrollBox",PANEL);
		COMPONENT_TYPE_MAP.put("TWANoteBook",PANEL);
		COMPONENT_TYPE_MAP.put("TCfwPanel",PANEL);
		COMPONENT_TYPE_MAP.put("TShape",SHAPE);
		COMPONENT_TYPE_MAP.put("TCheckBox",CHECKBOX);
		COMPONENT_TYPE_MAP.put("TDivCheckBox",CHECKBOX);
		COMPONENT_TYPE_MAP.put("TSpecialCheckBox",CHECKBOX);
		COMPONENT_TYPE_MAP.put("TRadioButton",RADIOBUTTON);
		COMPONENT_TYPE_MAP.put("TDivRadioButton",RADIOBUTTON);
		COMPONENT_TYPE_MAP.put("TRadioGroup",RADIOBUTTON);
		COMPONENT_TYPE_MAP.put("TWARadioGroup",RADIOBUTTON);
		COMPONENT_TYPE_MAP.put("TListViewAC",LIST_VIEW);
		COMPONENT_TYPE_MAP.put("TWAListView",LIST_VIEW);
		COMPONENT_TYPE_MAP.put("TAction",ACTION);
		COMPONENT_TYPE_MAP.put("TWAPageControl",TAB);
		COMPONENT_TYPE_MAP.put("TPageControl",TAB);
		COMPONENT_TYPE_MAP.put("TTabControl",TAB);
    COMPONENT_TYPE_MAP.put("TTabSheet", TAB);
		COMPONENT_TYPE_MAP.put("TWATabControl",TAB);
		COMPONENT_TYPE_MAP.put("TEdit",EDIT);
		COMPONENT_TYPE_MAP.put("TEcoEdit",EDIT);
		COMPONENT_TYPE_MAP.put("TSpEdit2",EDIT);
		COMPONENT_TYPE_MAP.put("TSpEdit2Color",EDIT);
		COMPONENT_TYPE_MAP.put("TSpEditAc",EDIT);
		COMPONENT_TYPE_MAP.put("THistoryEdit",EDIT);
		COMPONENT_TYPE_MAP.put("TListEdit",EDIT);
		COMPONENT_TYPE_MAP.put("TFillEdit",EDIT);
		COMPONENT_TYPE_MAP.put("TSpinEdit",EDIT);
		COMPONENT_TYPE_MAP.put("THueSuggestEdit",EDIT);
		COMPONENT_TYPE_MAP.put("TIniCombo2",COMBO);
		COMPONENT_TYPE_MAP.put("TComboBoxEx",COMBO);
		COMPONENT_TYPE_MAP.put("TCorpComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TCorpComboBox2",COMBO);
		COMPONENT_TYPE_MAP.put("THistoryComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TLightComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TModuleComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TProductComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TWAComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TComboBox",COMBO);
		COMPONENT_TYPE_MAP.put("TTCurrencyCtrl",CURRENCYCTRL);
		COMPONENT_TYPE_MAP.put("TMoneyCtrl2",CURRENCYCTRL);
		COMPONENT_TYPE_MAP.put("TMoneyCtrlAC",CURRENCYCTRL);
		COMPONENT_TYPE_MAP.put("TMemo",MEMO);
		COMPONENT_TYPE_MAP.put("TRichEdit",MEMO);
		COMPONENT_TYPE_MAP.put("TWARichEdit",MEMO);
		COMPONENT_TYPE_MAP.put("TCompanyMemo2",MEMO);
		COMPONENT_TYPE_MAP.put("TLinkMemo2",MEMO);
		COMPONENT_TYPE_MAP.put("TDateTimeCtl2", DATE_TIME);
		COMPONENT_TYPE_MAP.put("TCompanyMask", MASK);
		COMPONENT_TYPE_MAP.put("TMaskEdit", MASK);
		COMPONENT_TYPE_MAP.put("TZipCodeEdit", ZIPCODE);
		COMPONENT_TYPE_MAP.put("TDateTimePicker", CALENDAR);
		COMPONENT_TYPE_MAP.put("TMonthCalendar", CALENDAR);
		COMPONENT_TYPE_MAP.put("TTControlGrid", GRID);
		COMPONENT_TYPE_MAP.put("TTMultilineControlGrid", GRID);
		COMPONENT_TYPE_MAP.put("TWAStringGrid0", GRID);
		COMPONENT_TYPE_MAP.put("TDrawGrid", GRID);
		COMPONENT_TYPE_MAP.put("TStringGrid", GRID);
		COMPONENT_TYPE_MAP.put("TListBox", LISTBOX);
		COMPONENT_TYPE_MAP.put("TWAListBox", LISTBOX);
		COMPONENT_TYPE_MAP.put("TCheckListBox", LISTBOX);
		COMPONENT_TYPE_MAP.put("TBevel", BEVEL);
		COMPONENT_TYPE_MAP.put("TWABevel", BEVEL);
		COMPONENT_TYPE_MAP.put("TSplitter", SPLITTER);
		COMPONENT_TYPE_MAP.put("TImage", IMAGE);
        COMPONENT_TYPE_MAP.put("TCoolBar", COOLBAR);
        COMPONENT_TYPE_MAP.put("TToolBar", TOOLBAR);
        COMPONENT_TYPE_MAP.put("TWAToolBar", TOOLBAR);
        COMPONENT_TYPE_MAP.put("TStatusBar", STATUSBAR);
        COMPONENT_TYPE_MAP.put("TWAStatusBar", STATUSBAR);
        COMPONENT_TYPE_MAP.put("TScrollBox", SCROLLBOX);
	}
	
	public static ComponentType getComponent(String componentName) {	
		ComponentType componentType;
		
		if(COMPONENT_TYPE_MAP.containsKey(componentName)){
			componentType = COMPONENT_TYPE_MAP.get(componentName);
		}else{
			componentType = NON_COMPONENT;
		}
		
		return componentType;
	}
	
	public static boolean isPanel(String componentName){
		return componentName.equals("TWAPanel") || componentName.equals("TWAScrollBox") || componentName.equals("TWANoteBook") || componentName.equals("TCfwPanel");
	}
	
	public static boolean isNotOrderCheckTarget(String componentName){
		ComponentType componentType = getComponent(componentName);
		return componentType.equals(SHAPE) || componentType.equals(BEVEL) || componentType.equals(SPLITTER) || componentType.equals(IMAGE);
	}
	
	public static boolean isFormElements(String componentName){
		ComponentType componentType = getComponent(componentName);
		return isFormElements(componentType);
	}
	
	public static boolean isFormElements(ComponentType componentType){
		return componentType.equals(BUTTON) || componentType.equals(CALENDAR) || componentType.equals(CHECKBOX) || componentType.equals(COMBO) || componentType.equals(CURRENCYCTRL) || componentType.equals(DATE_TIME)
				 || componentType.equals(EDIT) || componentType.equals(LABEL) || componentType.equals(MEMO) || componentType.equals(MASK) || componentType.equals(RADIOBUTTON);
	}
}
