package org.intrawebtools.uiux_enhancer.enums;

import lombok.Getter;

@Getter
public enum LayoutPattern {
	LIST_FRAME("List Frame"),
	DETAIL_FRAME("Detail Frame"),
	REPORT_FRAME("Report Frame"),
	PLAIN_FRAME("Plain Frame"),
	SEARCH_DIALOG("Search Dialog"),
	REPORT_DIALOG("Report Dialog"),
	CSV_INPUT_DIALOG("CSV Input Dialog"),
	HEADER_LESS_DIALOG("Header Less Dialog"),
	PLAIN_DIALOG("Plain Dialog"),
	PARTS_FRAME("Parts Frame"),
	NOT_FORM("");
	
	private String name;
	
	private LayoutPattern(String name) {
		this.name = name;
	}
	
  public static LayoutPattern getEnum(String name) {
    for (LayoutPattern en : LayoutPattern.values()) {
      if (name.equals(en.getName())) {
        return en;
      }
    }
    return NOT_FORM;
  }
}
