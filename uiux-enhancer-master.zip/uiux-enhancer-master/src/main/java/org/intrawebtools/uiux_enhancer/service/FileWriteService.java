
package org.intrawebtools.uiux_enhancer.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.intrawebtools.uiux_enhancer.consts.ConvertConst;
import org.intrawebtools.uiux_enhancer.consts.SelfCheckConst;
import org.intrawebtools.uiux_enhancer.entity.ResultEntity;
import org.intrawebtools.uiux_enhancer.utils.FileReadUtils;

public class FileWriteService {

  public void setEntityToDFMFile(List<ResultEntity> resultEntityList) {
    try {
      Map<String, List<ResultEntity>> filesGroup = resultEntityList.stream()
          .collect(Collectors.groupingBy(ResultEntity::getFilePath));
      for (Entry<String, List<ResultEntity>> group : filesGroup.entrySet()) {
        String filePath = group.getKey();
        File inputDfmFile = new File(filePath);
        List<String> inputDfmLines = FileReadUtils.fileRead(inputDfmFile);
        List<String> outputDfmLines = new ArrayList<>();
        outputDfmLines.addAll(inputDfmLines);
        for (ResultEntity entity : resultEntityList) {
          String entityComponentName = entity.getName();
          String entityPropertyName = entity.getProperty();
          String entityPropertyValue = entity.getPropertyValue();
          List<Map<Integer, String>> fileComponentProperties = findComponentProperties(entityComponentName,
              inputDfmLines);
          for (Map<Integer, String> prop : fileComponentProperties) {
            for (Map.Entry<Integer, String> entry : prop.entrySet()) {
              String filePropertyName = entry.getValue().trim().split(" = ")[0].trim();
              if (filePropertyName.equalsIgnoreCase(entityPropertyName)) {
                String resLine = entry.getValue().split(" = ")[0] + " = " + entityPropertyValue;
                Integer lineNumber = entry.getKey() - 1;
                outputDfmLines.remove(lineNumber.intValue());
                outputDfmLines.add(lineNumber.intValue(), resLine);
              }
            }
          }
        }
        FileUtils.writeLines(new File(filePath.substring(0, filePath.lastIndexOf(".")) + "_new.dfm"), outputDfmLines);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private List<Map<Integer, String>> findComponentProperties(String componentName, List<String> inputDfmLines) {
    List<Map<Integer, String>> componentProperties = new ArrayList<>();
    Pattern patternObject = Pattern.compile(SelfCheckConst.reg_COMPONENT_OBJECT_2, Pattern.CASE_INSENSITIVE);
    Pattern patternInherited = Pattern.compile(SelfCheckConst.reg_COMPONENT_INHERITED_2, Pattern.CASE_INSENSITIVE);
    Pattern patternEnd = Pattern.compile(ConvertConst.reg_COMPONENT_END, Pattern.CASE_INSENSITIVE);

    boolean componentFound = false;
    for (int c = 0; c < inputDfmLines.size(); c++) {
      if (!componentFound) {
        Matcher objectMatcher;
        Matcher inheritedMatcher;
        String currentLine = inputDfmLines.get(c);
        objectMatcher = patternObject.matcher(currentLine);
        inheritedMatcher = patternInherited.matcher(currentLine);
        boolean objectExists = objectMatcher.find();
        boolean inheritedExists = inheritedMatcher.find();
        if ((objectExists || inheritedExists) && currentLine.contains(componentName)) {
          while (true) {
            Matcher endMatcher;
            c++;
            String propLine = inputDfmLines.get(c);
            objectMatcher = patternObject.matcher(propLine);
            inheritedMatcher = patternInherited.matcher(propLine);
            endMatcher = patternEnd.matcher(propLine);
            objectExists = objectMatcher.find();
            inheritedExists = inheritedMatcher.find();
            if (objectExists || inheritedExists) {
              while (true) {
                c++;
                endMatcher = patternEnd.matcher(inputDfmLines.get(c));
                if (endMatcher.find()) {
                  break;
                }
                continue;
              }
            } else {
              if (propLine.contains("{")) {
                while (true) {
                  c++;
                  if (inputDfmLines.get(c).contains("}")) {
                    break;
                  }
                  continue;
                }
              }
              if (endMatcher.find()) {
                componentFound = true;
                break;
              }

              Map<Integer, String> resMap = new HashMap<>();
              Integer lineNumber = new Integer(c);
              lineNumber = lineNumber + 1;
              resMap.put(lineNumber, propLine);
              componentProperties.add(resMap);
            }
          }
        }
      } else {
        break;
      }
    }
    return componentProperties;
  }

}
