package org.intrawebtools.uiux_enhancer.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intrawebtools.uiux_enhancer.entity.ResultEntity;

public class OutputService {

  public void writeResultToFile(List<ResultEntity> resultEntityList) {
    InputStream templatePath = this.getClass().getClassLoader()
        .getResourceAsStream("UIUX_Enhancement_Changes_Template.xls");
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
    String currentTime = dateFormat.format(calendar.getTime());
    FileOutputStream outputStream = null;
    String outputpath = System.getProperty("user.dir") + "\\UIUX_Enhancement_Changes_Result_" + currentTime + ".xls";
    File wkFile = new File(outputpath + "_wk");
    try {
      FileUtils.copyInputStreamToFile(templatePath, new File(outputpath + "_wk"));
      Workbook book = WorkbookFactory.create(wkFile);
      Sheet inputsheet = book.getSheet("UIUX_Enhancement_Changes");
      writeLogResult(book, inputsheet, resultEntityList);
      book.setForceFormulaRecalculation(true);
      outputStream = new FileOutputStream(outputpath);
      book.write(outputStream);
      book.close();
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      wkFile.delete();
      try {
        outputStream.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  private void writeLogResult(Workbook book, Sheet inputSheet, List<ResultEntity> resultEntityList) {
    int idx = 2;
    for (ResultEntity resultEntity : resultEntityList) {
      Row row = inputSheet.getRow(idx);
      if (row == null) {
        Row previousRow = inputSheet.getRow(idx - 1);
        row = inputSheet.createRow(idx);
        for (int i = 1; i < 9; i++) {
          if (row.getCell(i) == null) {
            row.createCell(i);
            row.getCell(i).setCellStyle(previousRow.getCell(i).getCellStyle());
            row.getCell(i).setCellType(previousRow.getCell(i).getCellType());
          }
        }
      }
      row.getCell(1).setCellValue(String.valueOf(idx - 1));
      row.getCell(2).setCellValue(resultEntity.getFilePath());
      row.getCell(3).setCellValue(String.valueOf(resultEntity.getComponentType()));
      row.getCell(4).setCellValue(resultEntity.getComponent());
      row.getCell(5).setCellValue(resultEntity.getName());
      row.getCell(6).setCellValue(resultEntity.getBeforeChanges());
      row.getCell(7).setCellValue(resultEntity.getAfterChanges());
      row.getCell(8).setCellValue(resultEntity.getComment());
      idx++;
    }
  }

}
