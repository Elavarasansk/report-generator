package org.intrawebtools.uiux_enhancer.enums;

import lombok.Getter;

@Getter
public enum LayoutType {
	MAIN_FRAME("Main Frame"),
	DIALOG("Dialog"),
	PARTS_FRAME("Parts Frame"),
	NOT_FORM("");
	
	private String name;
	
	private LayoutType(String name) {
		this.name = name;
	}

  public static LayoutType getEnum(String name) {
    for (LayoutType en : LayoutType.values()) {
      if (name.equals(en.getName())) {
        return en;
      }
    }
    return NOT_FORM;
  }

}
