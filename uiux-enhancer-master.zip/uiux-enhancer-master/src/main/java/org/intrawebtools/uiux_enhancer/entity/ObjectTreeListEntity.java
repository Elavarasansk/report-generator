package org.intrawebtools.uiux_enhancer.entity;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class ObjectTreeListEntity{
	private boolean isAcceptDirectComponentForm;
	private List<ObjectTreeEntity> objectTreeList;

	public ObjectTreeListEntity() {
		isAcceptDirectComponentForm = true;
		objectTreeList = new ArrayList<ObjectTreeEntity>();
	}
	
  public ObjectTreeListEntity(ObjectTreeListEntity objectTreeListEntity) {
    isAcceptDirectComponentForm = objectTreeListEntity.isAcceptDirectComponentForm;
    List<ObjectTreeEntity> objectTreeEntityList = new ArrayList<>();
    for (ObjectTreeEntity objectTreeEntity : objectTreeListEntity.getObjectTreeList()) {
      objectTreeEntityList.add(new ObjectTreeEntity(objectTreeEntity));
    }
    objectTreeList = new ArrayList<ObjectTreeEntity>(objectTreeEntityList);
  }

	public ObjectTreeListEntity copy(){
		ObjectTreeListEntity result = new ObjectTreeListEntity();
		result.isAcceptDirectComponentForm = this.isAcceptDirectComponentForm;
        for (ObjectTreeEntity entry : this.objectTreeList) {
        	result.objectTreeList.add(entry.copy());
        }
		return result;
	}
}
