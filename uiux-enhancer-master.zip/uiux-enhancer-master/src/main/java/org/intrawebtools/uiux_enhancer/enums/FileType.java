package org.intrawebtools.uiux_enhancer.enums;

import lombok.Getter;

@Getter
public enum FileType {
	DPR(".dpr"),
	DFM(".dfm"),
	PAS(".pas"),
	DOF(".dof"),
	XLSX(".xlsx");
	
	private String extension;
	
	private FileType(String extension) {
		this.extension = extension;
	}
}
