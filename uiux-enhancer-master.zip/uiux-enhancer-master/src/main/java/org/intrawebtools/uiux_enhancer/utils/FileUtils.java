package org.intrawebtools.uiux_enhancer.utils;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FileUtils {

  public static String getPath(URL url) {
    String path = null;
    try {
      File file = new File(url.toURI());
      path = file.getCanonicalPath();
    } catch (IOException e) {
      System.out.println("[ERROR]" + e);
    } catch (URISyntaxException e) {
      System.out.println("[ERROR]" + e);
    }
    return path;
  }

  public static void fileCopy(String oldDir, String newDir) {
    try {
      Path oldPath = Paths.get(oldDir);
      Path newPath = Paths.get(newDir);

      File parent = newPath.getParent().toFile();

      if (!parent.exists()) {
        parent.mkdirs();
      }

      Files.copy(oldPath, newPath, StandardCopyOption.REPLACE_EXISTING);
    } catch (IOException e) {
      System.out.println("[ERROR]" + e);
    }
  }

  public static List<File> grepFiles(File dir, String extension) {
    List<File> result = new ArrayList<File>();
    grepFiles(dir, result, extension);
    return result;
  }

  public static List<File> grepFiles(File dir) {
    List<File> result = new ArrayList<File>();
    grepFiles(dir, result, null);
    return result;
  }

  public static void grepFiles(File dir, List<File> result) {
    grepFiles(dir, result, null);
  }

  public static void grepFiles(File dir, List<File> result, String extension) {
    File[] filesArr = dir.listFiles();
    if (filesArr == null) {
      return;
    }
    List<File> files = Arrays.asList(filesArr);
    for (File file : files) {
      if (!file.exists()) {
        return;
      } else if (file.isDirectory()) {
        grepFiles(file, result, extension);
      } else if (file.isFile()) {
        if ((extension == null) || (file.getAbsolutePath().endsWith(extension))) {
          result.add(file);
        }
      }
    }
  }

  public static boolean checkIgnoreExtensionList(File file, List<String> ignoreExtensionList) {
    String fileName = file.getName();
    for (String extension : ignoreExtensionList) {
      if (fileName.endsWith(extension)) {
        return false;
      }
    }

    return true;
  }
}
