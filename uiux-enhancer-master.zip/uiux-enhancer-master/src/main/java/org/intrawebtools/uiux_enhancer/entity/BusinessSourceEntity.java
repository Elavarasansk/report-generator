package org.intrawebtools.uiux_enhancer.entity;

import java.util.List;

import org.intrawebtools.uiux_enhancer.utils.PoiUtils;

import lombok.Data;

@Data
public class BusinessSourceEntity {
	private boolean keyEvent;
	private boolean shellExecute;
	private boolean dlFileOpen;
	private boolean execAcrobat;
	private boolean excelStart;
	private boolean excelOleObject;
	private boolean saveToEss;
	private boolean driveCmb;
	private boolean folderDlg;
	private boolean openDlg;
	private boolean sendFileToClient;
	private boolean tmpDir;
	private boolean keyPreview;
	private boolean componentCount;

	public BusinessSourceEntity(List<String> row, boolean isMasterSheet) {
		if (isMasterSheet) {
			this.keyEvent = Boolean.parseBoolean(row.get(3));
			this.shellExecute = Boolean.parseBoolean(row.get(4));
			this.dlFileOpen = Boolean.parseBoolean(row.get(5));
			this.execAcrobat = Boolean.parseBoolean(row.get(6));
			this.excelStart = Boolean.parseBoolean(row.get(7));
			this.excelOleObject = Boolean.parseBoolean(row.get(8));
			this.saveToEss = Boolean.parseBoolean(row.get(9));
			this.driveCmb = Boolean.parseBoolean(row.get(10));
			this.folderDlg = Boolean.parseBoolean(row.get(11));
			this.openDlg = Boolean.parseBoolean(row.get(12));
			this.sendFileToClient = Boolean.parseBoolean(row.get(13));
			this.tmpDir = Boolean.parseBoolean(row.get(14));
			this.keyPreview = Boolean.parseBoolean(row.get(15));
			this.componentCount = Boolean.parseBoolean(row.get(16));
		} else {
			this.keyEvent = PoiUtils.parseCellValueToBool(row.get(7));
			this.shellExecute = PoiUtils.parseCellValueToBool(row.get(9));
			this.dlFileOpen = PoiUtils.parseCellValueToBool(row.get(10));
			this.execAcrobat = PoiUtils.parseCellValueToBool(row.get(11));
			this.excelStart = PoiUtils.parseCellValueToBool(row.get(12));
			this.excelOleObject = PoiUtils.parseCellValueToBool(row.get(14));
			this.saveToEss = PoiUtils.parseCellValueToBool(row.get(16));
			this.driveCmb = PoiUtils.parseCellValueToBool(row.get(18));
			this.folderDlg = PoiUtils.parseCellValueToBool(row.get(20));
			this.openDlg = PoiUtils.parseCellValueToBool(row.get(22));
			this.sendFileToClient = PoiUtils.parseCellValueToBool(row.get(24));
			this.tmpDir = PoiUtils.parseCellValueToBool(row.get(25));
			this.keyPreview = PoiUtils.parseCellValueToBool(row.get(27));
			this.componentCount = PoiUtils.parseCellValueToBool(row.get(29));
		}
	}
	
	public BusinessSourceEntity() {
		this.keyEvent = false;
		this.shellExecute = false;
		this.dlFileOpen = false;
		this.execAcrobat = false;
		this.excelStart = false;
		this.excelOleObject = false;
		this.saveToEss = false;
		this.driveCmb = false;
		this.folderDlg = false;
		this.openDlg = false;
		this.sendFileToClient = false;
		this.tmpDir = false;
		this.keyPreview = false;
		this.componentCount = false;
	}

	public boolean isFileIoCase() {
		return driveCmb || folderDlg;
	}
	
	public boolean isShellExecuteCase() {
		return shellExecute || dlFileOpen || execAcrobat || excelStart;
	}
	
	public boolean isKeyPreviewCase() {
		return keyPreview;
	}
	
	public boolean isKeyEventCase(){
		return keyEvent;
	}
	
	public boolean isEssCase() {
		return saveToEss;
	}
}
