package org.intrawebtools.uiux_enhancer.consts;

public class ConvertConst {
	// for common
	public static final String reg_TOP = "^";
	public static final String reg_USES = "^uses\\b(.*)";
	public static final String reg_SEMI_COLON = "(.*);";
	public static final String reg_SEMI_COLON_COMMENT = ";(.*)";
	public static final String reg_PERIOD = "\\.";
	public static final String reg_BEGIN = "^begin\\b(.*)";
	public static final String reg_END = "^end\\.";

	public static final String reg_COMPILE_OPTION = "^\\{\\$.*\\}";
	
	public static final String reg_QUAT = "(.*)('.*')(.*)";
	public static final String reg_SLASH_COMMENT = "(.*)(//.*)";
	public static final String reg_BRACKET_COMMENT = "(.*)(\\{.*\\})(.*)";
	public static final String reg_BRACKET_COMMENT_START = "(.*)(\\{.*)";
	public static final String reg_BRACKET_COMMENT_END = "(.*\\})(.*)";
	public static final String reg_STAR_COMMENT = "(.*)(\\(\\*.*\\*\\))(.*)";
	public static final String reg_STAR_COMMENT_START = "(.*)(\\(\\*.*)";
	public static final String reg_STAR_COMMENT_END = "(.*\\*\\))(.*)";

	public static final String con_BLANK = "";
	public static final String con_SPACE = " ";
	public static final String con_USES = "uses";
	public static final String con_INDENT = "  ";
	public static final String con_COMMA = ",";
	public static final String con_COMMA_WITH_BLANK = ", ";
	public static final String con_COLON_WITH_BLANK = ": ";
	public static final String con_SEMI_COLON = ";";
	public static final String con_NEWLINE = "\r\n  ";
	public static final String con_TFORM = "tform";
	public static final String con_TDATA_MODULE = "tdatamodule";
	
	// for v4
	public static final String reg_COMPONENT = ":\\s*([a-zA-Z0-9]*)";
	public static final String reg_COMPONENT_AREA = "^(.*)inherited ";
	public static final String con_HUE_EDIT = "THueSuggestEdit";
	public static final String con_HISTORY_EDIT = "THistoryEdit";
	public static final String con_HUE_EDIT_USES = "HueSuggestEdit";
	public static final String con_HISTORY_EDIT_USES = "HistoryEdit";
	
	// for dpr
	public static final String reg_PROGRAM_NAME = "^program\\b(.*);";
	public static final String reg_USES_FORM = "Forms,";
	public static final String reg_USES_CLASSES = "Classes,";
	public static final String reg_USES_IN = "(.*) in '(.*)'";
	public static final String reg_USES_IN_WITH_VAR = "(.*) in '(.*)' \\{(.*)\\}";
	public static final String reg_USES_ROOTFRM = "CfwRootFrm in '(.*)\\\\CfwRootFrm\\.pas' \\{CfwRootFrame\\}";
	public static final String reg_RES = "\\{\\$R \\*\\.RES\\}";
	public static final String reg_APPLICATION_INITIALIZE = "Application.Initialize;";
	public static final String reg_APPLICATION_CREATE_FORM = "Application.CreateForm\\((.*),(.*)\\);";
	public static final String reg_APPLICATION_RUN = "Application.Run;";
	public static final String con_USES_FORM_REPLACED = "Forms, CVForms, CVForm,";
	public static final String con_SERVER_CONTROLLER_PATH = "cvcommon\\Lib\\ServerController\\ServerController.pas";
	public static final String con_EXE_EXTENSION = "_FORDEV.dpr";
	public static final String con_ACCOMMON = "accommon";
	public static final String con_CVCOMMON = "cvcommon";
	public static final String con_CFW_PATH = "{CFW_PATH}";
	
	// for dfm
	public static final String reg_SPACE = "^\\s";
	public static final String reg_OBJECT = "^object\\b";
	public static final String reg_OBJECT_COMP = "^  object\\b";
	public static final String reg_OBJECT_COMP_AREA = "  object\\b";
	public static final String reg_END_COMP = "^  end";
	public static final String reg_END_COMP_AREA = "  end";
	public static final String reg_END_COMP_NO_BLANK = "end";
	public static final String reg_COOL_BAR = "^  inherited (.*): TCoolBar";
	public static final String reg_COOL_BAR_BANDS = "^    Bands = <";
	public static final String reg_COOL_BAR_BANDS_END = "^      end>";
	public static final String reg_COOL_BAR_COMP_I = "^    inherited";
	public static final String reg_COOL_BAR_COMP_O = "^    object";
	public static final String reg_COOL_BAR_END_COMP = "^    end";
	public static final String reg_DFM_END = "^end";
	public static final String reg_FORM_TOP = "^  Top = ";
	public static final String reg_FORM_LEFT = "^  Left = ";
	public static final String reg_FORM_HEIGHT = "^  Height = ";
	public static final String reg_FORM_WIDTH = "^  Width = ";
	public static final String reg_FORM_CLIENT_HEIGHT = "^  ClientHeight = ";
	public static final String reg_FORM_CLIENT_WIDTH = "^  ClientWidth = ";
	public static final String reg_RECT_TOP = "Top = ";
	public static final String reg_RECT_LEFT = "Left = ";
	public static final String reg_RECT_HEIGHT = "Height = ";
	public static final String reg_RECT_WIDTH = "Width = ";
	public static final String con_INHERITED = "inherited";
	public static final String con_FORM_TOP = "  Top = ";
	public static final String con_FORM_LEFT = "  Left = ";
	public static final String con_FORM_HEIGHT = "  Height = ";
	public static final String con_FORM_WIDTH = "  Width = ";
	public static final String con_INDENT_TOOL_BAR = "      ";
	public static final String con_COOL_BAR_1 = "CoolBar1";
	public static final String con_M_COOL_BAR = "m_CoolBar";
	
	// for pas
	public static final String reg_UNIT = "^unit\\b";
	public static final String reg_INTERFACE = "^interface\\b";
	public static final String reg_IMPLEMENTATION = "^implementation\\b";
	public static final String reg_INITIALIZASION = "^initialization\\b";
	public static final String reg_FINALIZASION = "^finalization\\b";
	public static final String reg_CLASS = "class\\((.*)\\)";
	public static final String con_UNIT = "unit ";
	public static final String con_INTERFACE = "interface";
	public static final String con_IMPLEMENTATION = "implementation";
	public static final String con_USES_FORM_PAS = "forms";
	public static final String con_USES_FORM_REPLACED_PAS = "Forms, CVForms, CVForm";
	public static final String con_END = "end.";
	
	// for v4 panel
	public static final String reg_TOOL_BAR_AREA = "(\\s*)\\{HUE_TOOL_BAR_AREA\\}";
	public static final String reg_MAIN_AREA = "(\\s*)\\{HUE_MAIN_AREA\\}";
	
	// for document
	public static final String reg_WORKSHEET_VERSION = "Worksheet_template_(.*).xls";
	public static final String reg_TESTCASE_VERSION = "TestCase_template_(.*).xlsx";
	public static final String reg_AUTOCHECK_RESULT_VERSION = "AutoCheckResult_template_(.*).xls";
	public static final String reg_SELFCHECK_RESULT_VERSION = "SelfCheckResult_template_(.*).xls";
	
	// for autocheck
	public static final String reg_COLOR_CHECK_DFM = "\\bColor\\s*=(.*)";
	public static final String reg_COLOR_CHECK_PAS = "\\bColor\\s*:=(.*)";
	public static final String reg_RECT_CHECK_START_COMP = "huePnlPlainBase";
	public static final String reg_RECT_CHECK_START = "^  inherited huePnlPlainBase";
	public static final String reg_RECT_CHECK_END = "^  end";
	public static final String reg_COMPONENT_OBJECT = "(.*)object (.*): (.*)";
	public static final String reg_COMPONENT_INHERITED = "(.*)inherited (.*): (.*)";
	public static final String reg_COMPONENT_PROPERTY = "\\b(.*) = (.*)";
	public static final String reg_COMPONENT_END = "end\\b";
	public static final String reg_COMPONENT_CONS = "(.*)\\[.*\\]";

}
