package org.intrawebtools.uiux_enhancer.entity;

import java.util.HashMap;
import java.util.Map;

import org.intrawebtools.uiux_enhancer.enums.ComponentType;

import lombok.Data;

@Data
public class ComponentPropertyEntity {

  private String componentName;
  private String name;
  private Map<String, Object> properties;
  private ComponentType componentType;

  public ComponentPropertyEntity() {
    this.componentName = null;
    this.name = null;
    this.properties = new HashMap<>();
    this.componentType = ComponentType.NON_COMPONENT;
  }

  public ComponentPropertyEntity(ComponentPropertyEntity componentPropertyEntity) {
    this.componentName = componentPropertyEntity.getComponentName();
    this.name = componentPropertyEntity.getName();
    this.properties = new HashMap<>(componentPropertyEntity.getProperties());
    this.componentType = componentPropertyEntity.getComponentType();
  }

  public ComponentPropertyEntity copy() {
    ComponentPropertyEntity result = new ComponentPropertyEntity();
    result.componentName = this.componentName;
    result.name = this.name;

    for (Map.Entry<String, Object> entry : this.properties.entrySet()) {
      result.properties.put(entry.getKey(), entry.getValue());
    }
    result.componentType = this.componentType;
    return result;
  }

  public void addProperties(Map<String, Object> addItems) {
    for (Map.Entry<String, Object> entry : addItems.entrySet()) {
      this.properties.put(entry.getKey(), entry.getValue());
    }
  }
}
