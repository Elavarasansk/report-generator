package org.intrawebtools.uiux_enhancer.setting;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.intrawebtools.uiux_enhancer.enums.License;
import org.intrawebtools.uiux_enhancer.utils.FileUtils;

public class ConvertSetting {
  public String DPR_LIST_FILE;
  public String COMPONENT_FILE;
  public String DELPHI_UNIT_FILE;
  public String COMPANY_UNIT_FILE;
  public String CBMCOMMON_DIR_FILE;
  public String IGNORE_EXTENSION_FILE;
  public String FRAMEWORK_LIST_FILE;

  public String BASE_DIR_CAC;
  public String BASE_DIR_CFM;
  public String BASE_DIR_CBM;
  public String BASE_DIR_CCM;
  public String BASE_DIR_CAM;

  public String V4_ORIGINAL_DIR;
  public String V4_TARGET_DIR;

  public String WEB_ORIGINAL_DIR;
  public String WEB_TARGET_DIR;

  public String ACCOMMON_DIR;
  public String CVCOMMON_DIR;
  public String PRODUCT_COMPONENT_DIR;
  public String HUE_ELEMENTS_DIR;

  public String BINARY_CONVERTER;
  public String V4_CONVERT_FILE_LIST;
  public String V4_CONVERT_CBM_COMMON_PAS_FILE_LIST;
  public String V4_CONVERT_ALL_ENTITY_LIST;
  public String V4_CONVERT_FRAMEWORK_MAP;
  public String V4_CONVERT_EDIT_LIST;
  public String V4_CONVERT_COMPONENT;
  public String V4_CONVERT_ADDED_USES;

  public String RESOURCE_BASE;
  public String TEMPLATE_BASE;
  public String DESIGNDOC_BASE;
  public String WORKSHEET_BASE;
  public String DPRLIST_BASE;

  public String AUTOCHECK_IGNORE_FILE;

  public Map<License, String> licenseDirMap;

  public ConvertSetting() {

    DPR_LIST_FILE = "dprList.txt";
    COMPONENT_FILE = "component.csv";
    DELPHI_UNIT_FILE = "delphi-unit.csv";
    COMPANY_UNIT_FILE = "company-unit.csv";
    CBMCOMMON_DIR_FILE = "cbmcommon-dirs.txt";
    IGNORE_EXTENSION_FILE = "ignoreExtensionList.txt";
    FRAMEWORK_LIST_FILE = "v4-framework-list.csv";

    BASE_DIR_CAC = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cac\\";
    BASE_DIR_CFM = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cfm\\";
    BASE_DIR_CBM = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cbm\\";
    BASE_DIR_CCM = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-ccm\\";
    BASE_DIR_CAM = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cam\\";

    V4_ORIGINAL_DIR = "company_client\\delphi";
    V4_TARGET_DIR = "hue_client\\delphi";

    WEB_ORIGINAL_DIR = "hue_client\\delphi";
    WEB_TARGET_DIR = "hue_web\\delphi";

    ACCOMMON_DIR = "\\accommon\\";
    CVCOMMON_DIR = "\\cvcommon\\";
    PRODUCT_COMPONENT_DIR = "\\renderingcomponents\\";
    HUE_ELEMENTS_DIR = BASE_DIR_CAC + WEB_ORIGINAL_DIR + ACCOMMON_DIR + "Common\\CommonHUEElements";

    BINARY_CONVERTER = "binary-convert.exe";
    V4_CONVERT_FILE_LIST = "v4-convert-file-list.csv";
    V4_CONVERT_CBM_COMMON_PAS_FILE_LIST = "v4-convert-file-list_cbmcommon.csv";
    V4_CONVERT_ALL_ENTITY_LIST = "v4-convert-all-entity-list.csv";
    V4_CONVERT_FRAMEWORK_MAP = "v4-framework-map.csv";
    V4_CONVERT_EDIT_LIST = "v4-convert-edit-list.csv";
    V4_CONVERT_COMPONENT = "v4-convert-component.csv";
    V4_CONVERT_ADDED_USES = "v4-convert-added-uses.csv";

    RESOURCE_BASE = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-cfw-tool\\src\\main\\resource\\";

//    ResourceBundle rb = ResourceBundle.getBundle("convert");
//
//    BASE_DIR_CAC = rb.getString("BASE_DIR_CAC");
//    BASE_DIR_CFM = rb.getString("BASE_DIR_CFM");
//    BASE_DIR_CBM = rb.getString("BASE_DIR_CBM");
//    BASE_DIR_CCM = rb.getString("BASE_DIR_CCM");
//    BASE_DIR_CAM = rb.getString("BASE_DIR_CAM");
//    RESOURCE_BASE = rb.getString("RESOURCE_BASE");

    TEMPLATE_BASE = RESOURCE_BASE + "template\\";
    DESIGNDOC_BASE = RESOURCE_BASE + "designdoc\\";
    WORKSHEET_BASE = RESOURCE_BASE + "worksheet\\";
    DPRLIST_BASE = RESOURCE_BASE + "dprlist\\";

    AUTOCHECK_IGNORE_FILE = RESOURCE_BASE + "autocheck\\autocheck-ignore-list.txt";

    licenseDirMap = new HashMap<License, String>();
    licenseDirMap.put(License.CAC, BASE_DIR_CAC);
    licenseDirMap.put(License.CFM, BASE_DIR_CFM);
    licenseDirMap.put(License.CBM, BASE_DIR_CBM);
    licenseDirMap.put(License.CCM, BASE_DIR_CCM);
    licenseDirMap.put(License.CAM, BASE_DIR_CAM);
  }

  public License getLicense(String path) {
    for (License license : License.values()) {
      if (path.toLowerCase().contains(licenseDirMap.get(license).toLowerCase())) {
        return license;
      }
    }

    return null;
  }

  public String getV4OriginalDir(License license) {
    return licenseDirMap.get(license) + V4_ORIGINAL_DIR;
  }

  public String getResourcePath(String fileName) {
    return RESOURCE_BASE + fileName;
  }

  public String getPath(String fileName) {
    String protocol = this.getClass().getResource("").getProtocol();
    String path = null;

    if (protocol.equals("jar")) {
      File jarFile = new File(System.getProperty("java.class.path"));
      path = jarFile.getParent() + File.separator + fileName;
    } else if (protocol.equals("file")) {
      path = FileUtils.getPath(ClassLoader.getSystemResource(fileName));
    }

    return path;
  }
}
