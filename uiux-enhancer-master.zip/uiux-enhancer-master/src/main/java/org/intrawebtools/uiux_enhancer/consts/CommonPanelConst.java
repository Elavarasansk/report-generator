package org.intrawebtools.uiux_enhancer.consts;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommonPanelConst {
	
	public static boolean isAcceptDirectChildComponent(String componentId) {
		switch(componentId){
			case "CfwBaseFrame": return true;
			case "CfwDisplayFileNameDlg": return true;
			case "CfwDialog": return true;
			case "CfwFileSaveQueryDialog": return true;
			case "CfwPropDialog": return true;
			case "CfwReadDialog": return true;
			case "cfwReportPreviewDialog": return true;
			case "CfwRootFrame": return true;
			case "CfwWizardDialog": return true;

			default: return false;
		}
	}
	
	public static boolean isExistInWhiteListForLevel1(String componentId){
		if ("huePnlPlainBase".equals(componentId)) {
			return true;
		}
		return false;
	}
	
	public static Map<String, List<String>> RESERVED_PARENT_PANELS = new HashMap<String, List<String>>();
	static{
		RESERVED_PARENT_PANELS.put("huePnlPlainBase", Arrays.asList("huePnlDialogFooterBase", "huePnlMainBase", "huePnlWidgetBase"));
		RESERVED_PARENT_PANELS.put("huePnlMainBase", Arrays.asList("huePnlMainBottomPadding", "huePnlMainConditionBase", "huePnlMainContents", "huePnlMainLeftPadding", "huePnlMainRightPadding", "huePnlMainTopPadding", "huePnlSideMenu", "huePnlSideMenuRightPadding", "huePnlToolButtonBase"));
		RESERVED_PARENT_PANELS.put("huePnlMainConditionBase", Arrays.asList("huePnlMainCondition", "huePnlMainConditionBottomPadding", "huePnlMainConditionLeftPadding", "huePnlMainConditionRightPadding"));
		RESERVED_PARENT_PANELS.put("huePnlToolButtonBase", Arrays.asList("huePnlToolButton", "huePnlToolButtonBottomPadding"));
		RESERVED_PARENT_PANELS.put("huePnlToolButton", Arrays.asList("hueBtnSwitchOmniPnl", "huePnlDetailPager", "huePnlMainBtnContents", "huePnlToolBarContents", "huePnlToolButtonLeftPadding", "huePnlToolButtonRightPadding"));
		RESERVED_PARENT_PANELS.put("huePnlWidgetBase", Arrays.asList("huePnlAddBtn", "huePnlOmniBase", "huePnlWidgetBottomPadding", "huePnlWidgetMain", "huePnlWidgetTopPadding"));
		RESERVED_PARENT_PANELS.put("huePnlOmniBase", Arrays.asList("hueOmniPnlSide"));
	};
	
}
