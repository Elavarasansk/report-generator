package org.intrawebtools.uiux_enhancer.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intrawebtools.uiux_enhancer.consts.CheckFormHierarchyConst;
import org.intrawebtools.uiux_enhancer.consts.ConvertConst;
import org.intrawebtools.uiux_enhancer.consts.SelfCheckConst;
import org.intrawebtools.uiux_enhancer.entity.DprEntity;
import org.intrawebtools.uiux_enhancer.entity.FormHierarchyEntity;
import org.intrawebtools.uiux_enhancer.entity.ObjectTreeListEntity;
import org.intrawebtools.uiux_enhancer.entity.ResultEntity;
import org.intrawebtools.uiux_enhancer.enums.FileType;
import org.intrawebtools.uiux_enhancer.enums.License;
import org.intrawebtools.uiux_enhancer.setting.ConvertSetting;
import org.intrawebtools.uiux_enhancer.utils.FileReadUtils;
import org.intrawebtools.uiux_enhancer.utils.PoiUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UiUxEnhancementService {

  ConvertSetting setting = new ConvertSetting();

  UiUxEnhancementFileService fileService = new UiUxEnhancementFileService();

  FileWriteService fileWriteService = new FileWriteService();

  OutputService outputService = new OutputService();

  public void doChange(Map<String, File> targetMap, String folderPath) {
    log.info("UiUxEnhancementService.doChange: start;");
    for (String path : targetMap.keySet()) {
      // log.info("[read file] " + path);
      File file = targetMap.get(path);
      try {
        Map<String, FormHierarchyEntity> map = new HashMap<String, FormHierarchyEntity>();
        Workbook book = WorkbookFactory.create(file);
        DprEntity dprEntity = new DprEntity();
        List<FormHierarchyEntity> formList = new ArrayList<FormHierarchyEntity>();
        readFormList(PoiUtils.readSheet(book.getSheet("FileList")), map, dprEntity, formList);
        License license = License.getEnum(dprEntity.getProductName());
        List<ResultEntity> resultEntityList = checkComponents(formList, license, folderPath);
        fileWriteService.setEntityToDFMFile(resultEntityList);
        outputService.writeResultToFile(resultEntityList);
      } catch (Exception e) {
        log.error(e.getMessage());
      }
    }
    log.info("UiUxEnhancementService.doChange: end;");
  }

  private boolean readFormList(List<List<String>> rows, Map<String, FormHierarchyEntity> map, DprEntity dprEntity,
      List<FormHierarchyEntity> formList) {
    log.info("UiUxEnhancementService.readFormList: start;");
    boolean isSuccess = true;

    // for dpr
    dprEntity.setTicket(rows.get(1).get(3).trim());
    dprEntity.setProductName(rows.get(2).get(3).trim());
    dprEntity.setModuleName(rows.get(3).get(3).trim());
    dprEntity.setFunctionName(rows.get(4).get(3).trim());
    dprEntity.setDprName(rows.get(5).get(3).trim());
    dprEntity.setDprPath(rows.get(6).get(3).trim());
    dprEntity.setArgument(rows.get(7).get(3).trim());
    dprEntity.setWebUrl(rows.get(8).get(3).trim());
    dprEntity.setDeveloper(rows.get(2).get(6).trim());
    dprEntity.setTester(rows.get(3).get(6).trim());
    dprEntity.setIconId(rows.get(5).get(6).trim());

    // for other file
    int startRowIdx = 12;
    int idx = startRowIdx;

    Map<Integer, String> levelMap = new HashMap<Integer, String>();
    while ((idx < rows.size()) && !rows.get(idx).get(3).trim().isEmpty()) {
      List<String> row = rows.get(idx);
      if (!checkFileListSheetError(row, idx - startRowIdx + 1)) {
        isSuccess = false;
      }

      if (row.size() > 34) {
        FormHierarchyEntity entity = new FormHierarchyEntity(row);
        String pathKey = entity.getFilePath().toLowerCase();

        if (Boolean.parseBoolean(row.get(4).trim())) {
          int level = entity.getLevel();
          levelMap.put(level, pathKey);

          if (levelMap.containsKey(level - 1)) {
            entity.setParentFormPathKey(levelMap.get(level - 1));
          }

          if (rows.size() == (idx + 1)) {
            entity.setChild(true);
          } else if ((rows.get(idx + 1) != null) && (rows.get(idx + 1).get(level + 20) != null)
              && !rows.get(idx + 1).get(level + 20).equals("->")) {

            entity.setChild(true);
          }
        }
        map.put(pathKey, entity);
        formList.add(entity);
      }
      idx++;
    }

    log.info("UiUxEnhancementService.readFormList: end;");
    return isSuccess;
  }

  private boolean checkFileListSheetError(List<String> row, int formNo) {
    final String ERROR_MESSAGE_FORMAT = "[ERROR][FileList Sheet(No.%d %s)] 'Target' is '%s' and 'Plugin ID' is '%s'. "
        + "Please check '%s'.";

    String pluginId = row.get(9).trim();
    String pluginTargetStr = row.get(12).trim();
    boolean isPluginTarget = PoiUtils.parseCellValueToBool(pluginTargetStr);
    String fileName = row.get(3).trim();

    if (isPluginTarget && pluginId.isEmpty()) {
      System.out.println(String.format(ERROR_MESSAGE_FORMAT, formNo, fileName, isPluginTarget, pluginId, "Plugin ID"));
      return false;
    } else if (!pluginId.isEmpty() && pluginTargetStr.isEmpty()) {
      System.out.println(String.format(ERROR_MESSAGE_FORMAT, formNo, fileName, isPluginTarget, pluginId, "Target"));
      return false;
    } else {
      return true;
    }
  }

  private List<ResultEntity> checkComponents(List<FormHierarchyEntity> formList, License license, String folderPath)
      throws IOException {
    List<ResultEntity> resultList = new LinkedList<>();
    Map<String, ObjectTreeListEntity> objectTreeMap = new HashMap<String, ObjectTreeListEntity>();
    Map<String, ObjectTreeListEntity> objectTreeMapCompany = new HashMap<String, ObjectTreeListEntity>();
    checkComponentsDetail(formList, license, resultList, objectTreeMap, objectTreeMapCompany, folderPath);
    return resultList;
  }

  public void checkComponentsDetail(List<FormHierarchyEntity> formList, License license,
      List<ResultEntity> resultEntity, Map<String, ObjectTreeListEntity> objectTreeMap,
      Map<String, ObjectTreeListEntity> objectTreeMapCompany, String folderPath) throws IOException {

    String dir = folderPath + getRepositoryName(license) + setting.V4_TARGET_DIR + "\\";
    String dirCompany = folderPath + getRepositoryName(license) + setting.V4_ORIGINAL_DIR + "\\";
    Map<String, String> cachedPath = new HashMap<String, String>();

    for (FormHierarchyEntity entity : formList) {
      if (!entity.isForm() || entity.getFileName().equals(ConvertConst.con_TFORM)
          || entity.getFileName().equals(ConvertConst.con_TDATA_MODULE)) {
        continue;
      }
      String path = entity.getFilePath().replace(FileType.PAS.getExtension(), FileType.DFM.getExtension());
      File file = new File(dir + path);
      if (!file.exists()) {
        continue;
      }

      // Check inherited relationship
      boolean isWhiteList = CheckFormHierarchyConst.getWhiteList(entity.getFilePath());// White list do not need to be
                                                                                       // checked
      List<String> skippedForm = null;

      // In case that parent information is missing
      if (!isWhiteList) {
        // Cached path information on worksheet
        cachedPath.put(entity.getClassName().toLowerCase(), entity.getFilePath());
        // List up every missing form
        skippedForm = getSkippedForms(entity, cachedPath, dir, entity.getFilePath());
      }

      boolean isFromCfw = entity.getFilePath().startsWith("accommon");
      ObjectTreeListEntity thisEntity = setComponentsProperty(objectTreeMap, entity.getFilePath(),
          entity.getParentFormPathKey(), dir, file, isFromCfw, skippedForm, true);
      ObjectTreeListEntity thisEntityCompany = setComponentsProperty(objectTreeMapCompany, entity.getFilePath(),
          entity.getParentFormPathKey(), dirCompany, new File(dirCompany + path), isFromCfw, skippedForm, false);

      // Run the check if form target = TRUE
      if (!isFromCfw && entity.isFormTarget()) {
        log.info("Validation check for file " + path);
        fileService.checkComponentsProperty(thisEntity, thisEntityCompany, resultEntity, dir + path,
            entity.getLayoutType(), license);
      }
    }
  }

  private List<String> getSkippedForms(FormHierarchyEntity entity, Map<String, String> cachedPath, String dir,
      String currentPath) {

    List<String> skippedForm = new ArrayList<String>();
    boolean needCheck = true;
    String nextFilePath = currentPath;

    // Search inherited form until it's in white list
    while (needCheck) {
      // Get inherited form from .pas file
      List<String> referredClasses = getClassesFromPasFile(new File(dir + nextFilePath));

      // Check all classes to find the right inherited class
      boolean isFindParent = false;
      for (int i = 0; i < referredClasses.size(); i++) {
        String parentClass = referredClasses.get(i);

        // In case current class is in white list
        if (CheckFormHierarchyConst.PARENT_FORMS.get(parentClass) != null) {
          needCheck = false;
          isFindParent = true;
          break;
        }

        // In case current class is written on worksheet
        String readFile = cachedPath.get(parentClass.toLowerCase());
        if (readFile != null) {
          nextFilePath = readFile;
          skippedForm.add(nextFilePath);
          isFindParent = true;
          break;
        }

        // In case current class is added for HUE
        if (CheckFormHierarchyConst.HUE_ORIGINAL_FORMS.get(parentClass) != null) {
          nextFilePath = "accommon\\CfwClasses\\" + CheckFormHierarchyConst.HUE_ORIGINAL_FORMS.get(parentClass)
              + FileType.PAS.getExtension();
          skippedForm.add(nextFilePath);
          isFindParent = true;
          break;
        }

        // In case current class is one of CBM common files
        String getFormFromCBM = CheckFormHierarchyConst.CBM_COMMON_FORMES.get(parentClass);
        if (getFormFromCBM != null) {
          nextFilePath = getFormFromCBM;
          skippedForm.add(nextFilePath);
          isFindParent = true;
          break;
        }
      }

      // In case that class form which written on .pas file cannot be found
      if (!isFindParent) {
        System.out.println("No parent file : Current file is \"" + currentPath + "\". ParentClass is \""
            + referredClasses.get(referredClasses.size() - 1) + "\".");
        needCheck = false;
      }
    }
    Collections.reverse(skippedForm);
    return skippedForm;
  }

  private List<String> getClassesFromPasFile(File pathFile) {

    List<String> parentFileList = new ArrayList<String>();
    try {
      StringBuffer pasFullText = FileReadUtils.fileReadFullText(pathFile);

      // Get inherited form name from .pas file
      int searchStartPosition = 1;
      int searchEndPosition = 1;

      while (searchStartPosition > 0) {
        searchStartPosition = pasFullText.indexOf("class(", searchEndPosition);
        searchEndPosition = pasFullText.indexOf(")", searchStartPosition);
        String parentFile = pasFullText.substring(searchStartPosition + 6, searchEndPosition);
        if (searchStartPosition > 0 && !parentFileList.contains(parentFile)) {
          parentFileList.add(parentFile);
        }
      }

      // Remove the Interface ( starts with (= and contains . )
      parentFileList.removeIf(e -> e.contains("."));

      // In case there are multiple inherited, get the first one and replace
      for (int i = 0; i < parentFileList.size(); i++) {
        String parentFile = parentFileList.get(i);
        int searchMultiPattern = parentFile.indexOf(",");
        if (searchMultiPattern != -1) {
          String firstParentFile = parentFile.substring(0, searchMultiPattern);
          parentFileList.set(i, firstParentFile);
        }
      }

    } catch (IOException e) {
      log.error("Error: " + e);
    }

    return parentFileList;
  }

  private ObjectTreeListEntity setComponentsProperty(Map<String, ObjectTreeListEntity> objectTreeMap, String filePath,
      String paretnFilePath, String dir, File file, boolean isFromCFW, List<String> skippedForm,
      boolean isCheckHueSource) {

    ObjectTreeListEntity thisEntity = new ObjectTreeListEntity();

    // Copy information of parent form
    ObjectTreeListEntity parentEntity = objectTreeMap.get(paretnFilePath);
    if (parentEntity != null) {
      thisEntity = parentEntity.copy();
    }

    // Get, copy and read the information of parent forms which are missing
    if (skippedForm != null && !skippedForm.isEmpty()) {
      for (String form : skippedForm) {
        String skippedFormPath = form.replace(FileType.PAS.getExtension(), FileType.DFM.getExtension());
        String skippedFormName = form.substring(form.lastIndexOf(SelfCheckConst.con_BACKSLASH) + 1)
            .replace(FileType.PAS.getExtension(), ConvertConst.con_BLANK);

        // Skip the form which is not exist in V36
        if (!isCheckHueSource && CheckFormHierarchyConst.HUE_ORIGINAL_FORMS.containsValue(skippedFormName)) {
          continue;
        }

        File skippedFormFile = new File(dir + skippedFormPath);
        ObjectTreeListEntity skippedEntity = objectTreeMap.get(form.toLowerCase());
        if (skippedEntity == null) {
          fileService.setComponentsProperty(thisEntity, dir + skippedFormPath, skippedFormFile,
              skippedFormPath.startsWith("accommon"), isCheckHueSource);// Add missing .dfm data in obejctTreeMap
          objectTreeMap.put(form.toLowerCase(), thisEntity);
          thisEntity = thisEntity.copy();// Use deep copy to prevent over write the information when reading the current
                                         // .dfm file
        } else {
          thisEntity = skippedEntity.copy();
        }
      }
    }

    // Read data in current .dfm file
    String path = filePath.replace(FileType.PAS.getExtension(), FileType.DFM.getExtension());
    fileService.setComponentsProperty(thisEntity, dir + path, file, isFromCFW, isCheckHueSource);
    objectTreeMap.put(filePath.toLowerCase(), thisEntity);

    return thisEntity;
  }

  private String getRepositoryName(License license) {
    switch (license) {
    case CAM:
      return "\\hue-ac-chennai-cam\\";
    case CBM:
      return "\\hue-ac-chennai-cbm\\";
    case CCM:
      return "\\hue-ac-chennai-ccm\\";
    case CFM:
      return "\\hue-ac-chennai-cfm\\";
    default:
      return "\\hue-ac-chennai-cac\\";
    }
  }

}
