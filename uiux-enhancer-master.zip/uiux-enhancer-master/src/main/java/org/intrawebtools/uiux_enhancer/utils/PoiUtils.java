package org.intrawebtools.uiux_enhancer.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidation.ErrorStyle;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;

public class PoiUtils {

  public static boolean parseCellValueToBool(String value) {
    if (NumberUtils.isNumber(value)) {
      if (NumberUtils.toDouble(value) != 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return Boolean.parseBoolean(value);
    }
  }

  public static int getRowCnt(Sheet sheet) {
    int cnt = 0;

    for (@SuppressWarnings("unused")
    Row row : sheet) {
      cnt++;
    }

    return cnt;
  }

  public static List<List<String>> readSheet(Sheet sheet) {
    List<List<String>> rows = new ArrayList<List<String>>();

    for (Row row : sheet) {
      List<String> cols = new ArrayList<String>();
      int len = row.getLastCellNum();
      for (int i = 0; i < len; i++) {
        Cell cell = row.getCell(i);
        cols.add(getStringValue(cell));
      }
      rows.add(cols);
    }

    return rows;
  }

  public static String getStringValue(Cell cell) {
    if (cell == null) {
      return "";
    }

    switch (cell.getCellType()) {
    case NUMERIC:
      return Double.toString(cell.getNumericCellValue());
    case STRING:
      return cell.getStringCellValue();
    case FORMULA:
      Workbook wb = cell.getSheet().getWorkbook();
      CreationHelper crateHelper = wb.getCreationHelper();
      FormulaEvaluator evaluator = crateHelper.createFormulaEvaluator();
      return getStringValue(evaluator.evaluateInCell(cell));
    case BOOLEAN:
      return Boolean.toString(cell.getBooleanCellValue());
    case ERROR:
      return "ERROR";
    case BLANK:
    default:
      return "";
    }
  }

  public static boolean checkExistanceNull(Row row, int startCell, int endCell) {
    if (row == null) {
      return true;
    }
    for (int i = startCell; i <= endCell; i++) {
      if (row.getCell(i) == null) {
        return true;
      }
    }
    return false;
  }

  public static void createNewRows(Sheet sheet, int startRow, int endRow) {
    for (int i = startRow; i <= endRow; i++) {
      sheet.createRow(i);
    }
  }

  public static void createNewRowsWithCell(Sheet sheet, int startRow, int endRow, int startCell, int endCell) {
    for (int i = startRow; i <= endRow; i++) {
      createNewRowWithCell(sheet, i, startCell, endCell);
    }
  }

  public static Row createNewRowWithCell(Sheet sheet, int rowNum, int startCell, int endCell) {
    Row newRow = sheet.getRow(rowNum);
    if (newRow == null) {
      newRow = sheet.createRow(rowNum);
    }
    for (int i = startCell; i <= endCell; i++) {
      if (newRow.getCell(i) == null) {
        newRow.createCell(i);
      }
    }
    return newRow;
  }

  public static void copyCellValue(Row copyFrom, Row copyTo, int startCell, int endCell) {
    for (int i = startCell; i <= endCell; i++) {
      if (copyFrom.getCell(i) != null) {
        copyTo.getCell(i).setCellValue(getStringValue(copyFrom.getCell(i)));
      }
    }
  }

  public static void copyCellStyle(Row copyFrom, Row copyTo, int startCell, int endCell) {
    for (int i = startCell; i <= endCell; i++) {
      if (copyFrom.getCell(i) != null) {
        copyTo.getCell(i).setCellStyle(copyFrom.getCell(i).getCellStyle());
        copyTo.getCell(i).setCellType(copyFrom.getCell(i).getCellType());
      }
    }
  }

  public static void copyCellValidation(Sheet sheet, int originalRow, int endRow, int startCell, int endCell) {
    copyCellValidation(sheet, originalRow, endRow, startCell, endCell, ErrorStyle.STOP);
  }

  public static void copyCellValidation(Sheet sheet, int originalRow, int endRow, int startCell, int endCell,
      int errorStyle) {
    List<? extends DataValidation> list = sheet.getDataValidations();
    DataValidationHelper helper = sheet.getDataValidationHelper();

    for (int i = startCell; i <= endCell; i++) {
      for (DataValidation validation : list) {
        CellRangeAddressList region = validation.getRegions();
        for (CellRangeAddress range : region.getCellRangeAddresses()) {
          if (range.isInRange(originalRow, i)) {
            range.setLastRow(endRow);
          }
        }

        DataValidation newValidation = helper.createValidation(validation.getValidationConstraint(), region);
        if (errorStyle == ErrorStyle.STOP || errorStyle == ErrorStyle.INFO || errorStyle == ErrorStyle.WARNING) {
          newValidation.setErrorStyle(errorStyle);
          newValidation.createErrorBox(validation.getErrorBoxTitle(), validation.getErrorBoxText());
          newValidation.setShowErrorBox(validation.getShowErrorBox());
          sheet.addValidationData(newValidation);
        } else {
          throw new RuntimeException("ErrorStyle value is incorrect.");
        }
      }
    }
  }

  public static void deleteRows(Sheet sheet, int startRow, int endRow) {
    int rawRow = sheet.getLastRowNum();
    if (rawRow == endRow) {
      rawRow++;
      sheet.createRow(rawRow);
    }
    for (int i = endRow; i >= startRow; i--) {
      sheet.shiftRows(i + 1, rawRow, -1);
    }
  }

  public static Row addRowWithStyle(Sheet sheet, int originalIdx, int insertIdx, int startCell, int endCell) {
    Row originalRow = sheet.getRow(originalIdx);
    Row newRow = createNewRowWithCell(sheet, insertIdx, startCell, endCell);
    copyCellStyle(originalRow, newRow, startCell, endCell);
    return newRow;
  }

  public static Row addRowsWithStyle(Sheet sheet, int rowCnt, int insertIdx, int startCell, int endCell) {

    Row firstRow = null;
    for (int i = 0; i < rowCnt; i++) {
      if (firstRow == null) {
        firstRow = addRowWithStyle(sheet, insertIdx + i - rowCnt, insertIdx + i, startCell, endCell);
      } else {
        addRowWithStyle(sheet, insertIdx + i - rowCnt, insertIdx + i, startCell, endCell);
      }
    }
    return firstRow;
  }

  public static Row copyRow(Sheet sheet, int originalIdx, int insertIdx, int startCell, int endCell) {
    Row originalRow = sheet.getRow(originalIdx);
    Row newRow = createNewRowWithCell(sheet, insertIdx, startCell, endCell);
    newRow.setHeight(originalRow.getHeight());
    copyCellStyle(originalRow, newRow, startCell, endCell);
    copyCellValue(originalRow, newRow, startCell, endCell);
    return newRow;
  }

  public static Row copyRows(Sheet sheet, int rowCnt, int insertIdx, int startCell, int endCell) {

    Row firstRow = null;
    for (int i = 0; i < rowCnt; i++) {
      if (firstRow == null) {
        firstRow = copyRow(sheet, insertIdx + i - rowCnt, insertIdx + i, startCell, endCell);
      } else {
        copyRow(sheet, insertIdx + i - rowCnt, insertIdx + i, startCell, endCell);
      }
    }
    return firstRow;
  }

  public static String fixSheetName(Workbook book, String formName) {
    if (formName.length() > 31) {
      formName = formName.substring(0, 31);
    }

    int tag = 1;
    while (book.getSheetIndex(formName) > 0) {
      tag++;
      int maxLength = 31 - (Integer.toString(tag).length() + 1);
      if (formName.length() > maxLength) {
        formName = formName.substring(0, maxLength) + "_" + Integer.toString(tag);
        ;
      } else {
        formName = formName + "_" + Integer.toString(tag);
      }
    }

    return formName;
  }
}
