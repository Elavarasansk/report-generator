package org.intrawebtools.uiux_enhancer.entity;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class ObjectTreeEntity{
	private String name;
	private int level;
	private Map<Integer, String> parents;//<Level, parentsId>
	private boolean visibleFromProperty;
	private boolean visibleFromeWidthOrHeight;
	private boolean isFromCfw;
	private ComponentPropertyEntity componentPropertyEntity;
	
	public ObjectTreeEntity() {
		this.name = null;
		this.level = -1;
		this.parents = new HashMap<>();
		this.visibleFromProperty = true;
		this.visibleFromeWidthOrHeight = true;
		this.componentPropertyEntity = null;
	}

  public ObjectTreeEntity(ObjectTreeEntity objectTreeEntity) {
    this.name = objectTreeEntity.getName();
    this.level = objectTreeEntity.getLevel();
    this.parents = objectTreeEntity.getParents();
    this.visibleFromProperty = objectTreeEntity.getVisibleFromProperty();
    this.visibleFromeWidthOrHeight = objectTreeEntity.getVisibleFromWidthOrHeight();
    this.isFromCfw = objectTreeEntity.getIsFromCfw();
    this.componentPropertyEntity = new ComponentPropertyEntity(objectTreeEntity.getComponentPropertyEntity());
  }

	public boolean getVisibleFromProperty(){
		return this.visibleFromProperty;
	}
	
	public boolean getVisibleFromWidthOrHeight(){
		return this.visibleFromeWidthOrHeight;
	}
	
	public boolean getInheritedVisibility(){
		return this.visibleFromProperty && this.visibleFromeWidthOrHeight;
	}
	
	public boolean getIsFromCfw(){
		return this.isFromCfw;
	}
	
	public void setIsFromCfw(boolean isFromCfw){
		this.isFromCfw = isFromCfw;
	}
	
	public ObjectTreeEntity copy(){
		ObjectTreeEntity result = new ObjectTreeEntity();
		result.name = this.name;
		result.level = this.level;	
		for(Map.Entry<Integer,String> entry : this.parents.entrySet()) {
			result.parents.put(entry.getKey(), entry.getValue());
		}
		
		result.visibleFromProperty = this.visibleFromProperty;
		result.visibleFromeWidthOrHeight = this.visibleFromeWidthOrHeight;
		result.isFromCfw = this.isFromCfw;
		result.componentPropertyEntity = this.componentPropertyEntity.copy();
		return result;
	}
	
	public void setComponentPropertyEntity(ComponentPropertyEntity target){
		if (this.componentPropertyEntity == null) {
			this.componentPropertyEntity = new ComponentPropertyEntity();
		}
    this.componentPropertyEntity.setComponentName(target.getComponentName());
    this.componentPropertyEntity.setName(target.getName());
    this.componentPropertyEntity.addProperties(target.getProperties());
    this.componentPropertyEntity.setComponentType(target.getComponentType());
	}
	
}
