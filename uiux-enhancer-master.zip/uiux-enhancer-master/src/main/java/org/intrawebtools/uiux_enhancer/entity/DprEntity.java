package org.intrawebtools.uiux_enhancer.entity;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DprEntity {
	private String productName;
	private String moduleName;
	private String functionName;
	private String dprName;
	private String iconId;
	private String priority;
	private String dprPath;
	
	private String ticket;
	private String developer;
	private String tester;
	private String argument;
	private String webUrl;

	public DprEntity(List<String> row) {
		this.productName = row.get(1).trim();
		this.moduleName = row.get(2).trim();
		this.functionName = row.get(3).trim();
		this.dprName = row.get(4).trim();
		this.iconId = row.get(5).trim();
		this.priority = row.get(6).trim();
		this.dprPath = row.get(14).trim();
	}
}
