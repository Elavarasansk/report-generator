package org.intrawebtools.uiux_enhancer.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FileReadUtils {
	private static final String COMMA = ",";

	public static List<String> fileRead(File file) throws IOException {
		return fileRead(file, "UTF-8");
	}

	public static List<String> fileRead(File file, String enc)
			throws IOException {
		return fileRead(new FileInputStream(file), enc);
	}

	public static List<String> fileRead(InputStream fileStream) throws IOException {
		return fileRead(fileStream, "UTF-8");
	}
	
	public static StringBuffer fileReadFullText(File file) throws IOException {
        return fileReadFullText(file, "UTF-8");
    }

    public static StringBuffer fileReadFullText(File file, String enc) throws IOException {
        return fileReadFullText(new FileInputStream(file), enc);
    }

    public static StringBuffer fileReadFullText(InputStream fileStream) throws IOException {
        return fileReadFullText(fileStream, "UTF-8");
    }

	public static List<String> fileRead(InputStream fileStream, String enc)
			throws IOException {
		ArrayList<String> result = new ArrayList<String>();

		String line;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(fileStream, enc));
			while ((line = br.readLine()) != null) {
				result.add(line);
			}
		} finally {
			if (br != null) {
				br.close();
			}
		}
		return result;
	}
	
	public static StringBuffer fileReadFullText(InputStream fileStream, String enc) throws IOException {
        StringBuffer fullText = new StringBuffer();

        String line;
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(fileStream, enc));
            while ((line = br.readLine()) != null) {
                fullText.append(line);
            }
        } finally {
            if (br != null) {
                br.close();
            }
        }
        return fullText;
    }

	public static List<List<String>> readCsvFile(File file) throws IOException {
		List<List<String>> result = fileRead(file).stream().map(line -> {
			List<String> list = new ArrayList<String>();
			String[] array = line.split(COMMA);
			for (String str : array) {
				list.add(str);
			}
			return list;
		}).collect(Collectors.toList());

		return result;
	}

	public static List<List<String>> readCsvFile(InputStream fileStream) throws IOException {
		List<List<String>> result = fileRead(fileStream).stream().map(line -> {
			List<String> list = new ArrayList<String>();
			String[] array = line.split(COMMA);
			for (String str : array) {
				list.add(str);
			}
			return list;
		}).collect(Collectors.toList());

		return result;
	}

}
