package org.intrawebtools.uiux_enhancer.entity;

import java.util.List;

import org.intrawebtools.uiux_enhancer.utils.PoiUtils;

import lombok.Data;

@Data
public class EditSheetEntity {
	private String no;
	private String directory;
	private String fileName;
	private boolean target;
	private String editClass;
	private String editName;
	private String pluginId;
	private String pluginLink;
	private String pluginAssignee;
	private boolean isReplace;
	private boolean isMasterSuggest;
	private boolean isPluginTarget;
	private String pluginStatus;
	private String sqlTag;
	private String codeColumn;
	private String nameColumn;
	private String filePath;
	
	public EditSheetEntity(List<String> row) {
		this.no = row.get(1).trim();
		this.directory = row.get(2).trim();
		this.fileName = row.get(3).trim();
		this.target = PoiUtils.parseCellValueToBool(row.get(4).trim());
		this.editClass = row.get(5).trim();
		this.editName = row.get(6).trim();
		this.pluginId = row.get(7).trim();
		this.pluginLink = row.get(8).trim();
		this.pluginAssignee = row.get(9).trim();
		this.isReplace = PoiUtils.parseCellValueToBool(row.get(10).trim());
		this.isMasterSuggest = PoiUtils.parseCellValueToBool(row.get(11).trim());
		this.isPluginTarget = PoiUtils.parseCellValueToBool(row.get(12).trim());
		this.pluginStatus = row.get(13).trim();
		this.sqlTag = row.get(14).trim();
		this.codeColumn = row.get(15).trim();
		this.nameColumn = row.get(16).trim();
		this.filePath = row.get(17).trim();
	}
}
