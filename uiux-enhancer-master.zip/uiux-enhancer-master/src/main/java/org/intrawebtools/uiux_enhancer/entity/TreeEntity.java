package org.intrawebtools.uiux_enhancer.entity;

import java.util.List;

public class TreeEntity {

  public String panelName;
  public Integer top;
  public Integer left;
  public List<TreeEntity> childPanel;
  
  public TreeEntity(String panelName, Integer top, Integer left) {
    this.panelName = panelName;
    this.top = top;
    this.left = left;
    this.childPanel = null;
  }

}
