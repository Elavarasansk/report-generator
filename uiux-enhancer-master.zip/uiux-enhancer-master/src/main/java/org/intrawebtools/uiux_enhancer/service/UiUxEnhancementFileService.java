package org.intrawebtools.uiux_enhancer.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.intrawebtools.uiux_enhancer.consts.CommonPanelConst;
import org.intrawebtools.uiux_enhancer.consts.ConvertConst;
import org.intrawebtools.uiux_enhancer.consts.SelfCheckConst;
import org.intrawebtools.uiux_enhancer.entity.ComponentPropertyEntity;
import org.intrawebtools.uiux_enhancer.entity.ObjectTreeEntity;
import org.intrawebtools.uiux_enhancer.entity.ObjectTreeListEntity;
import org.intrawebtools.uiux_enhancer.entity.PositionEntity;
import org.intrawebtools.uiux_enhancer.entity.ResultEntity;
import org.intrawebtools.uiux_enhancer.enums.ComponentType;
import org.intrawebtools.uiux_enhancer.enums.LayoutType;
import org.intrawebtools.uiux_enhancer.enums.License;
import org.intrawebtools.uiux_enhancer.setting.ConvertSetting;
import org.intrawebtools.uiux_enhancer.utils.FileReadUtils;
import org.intrawebtools.uiux_enhancer.utils.UIUXEnhancementUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UiUxEnhancementFileService extends UIUXEnhancementUtils {
  ConvertSetting setting = new ConvertSetting();
  private final String binaryConverterPath = setting.getResourcePath(setting.BINARY_CONVERTER);
  protected static final String CHAR_CODE = "MS932";
  public static Logger logger = LoggerFactory
      .getLogger("org.intrawebtools.uiux_enhancer.service.UiUxEnhancementFileService");

  public void setComponentsProperty(ObjectTreeListEntity objectTree, String path, File file, boolean isFromCFW,
      boolean isCheckHueSource) {
    readComponentsTreeFromDfm(objectTree, path, file, isFromCFW, isCheckHueSource);
  }

  public void checkComponentsProperty(ObjectTreeListEntity objectTree, ObjectTreeListEntity objectTreeCompany,
      List<ResultEntity> resultEntity, String path, LayoutType layoutType, License license) throws IOException {

    // Set ObjectTreeListEntity to Map<ComponentType, ComponentPropertyListEntity>
    Map<ComponentType, ObjectTreeListEntity> componentsObjectTreeMap = toComponentsPropertyMap(objectTree);
    Map<ComponentType, ObjectTreeListEntity> componentsObjectTreeMapCompany = toComponentsPropertyMap(
        objectTreeCompany);
    // Run all the checkpoints
    checkComponentsWithObjectTree(resultEntity, componentsObjectTreeMap, componentsObjectTreeMapCompany, path,
        layoutType, license);
  }

  private Map<ComponentType, ObjectTreeListEntity> toComponentsPropertyMap(ObjectTreeListEntity objectTree) {
    Map<ComponentType, ObjectTreeListEntity> result = new HashMap<ComponentType, ObjectTreeListEntity>();
    List<ObjectTreeEntity> objectTreeList = objectTree.getObjectTreeList();

    for (ObjectTreeEntity entity : objectTreeList) {

      ComponentType targetComponentType = ComponentType
          .getComponent(entity.getComponentPropertyEntity().getComponentName());
      ObjectTreeListEntity target = result.get(targetComponentType);
      if (target == null) {
        target = new ObjectTreeListEntity();
      }
      entity.getComponentPropertyEntity().setComponentType(targetComponentType);
      target.getObjectTreeList().add(entity);
      result.put(targetComponentType, target);
    }
    return result;
  }

  private boolean isFromCfwCheck(ObjectTreeEntity componentEntity, List<String> isFromCfwList, int version) {
    boolean checkTarget = true;
    if (version == 40 && componentEntity.getIsFromCfw()) {
      checkTarget = false;
      isFromCfwList.add(componentEntity.getName());
    }
    if (version == 36 && isFromCfwList.indexOf(componentEntity.getName()) != -1) {
      checkTarget = false;
    }
    return checkTarget;
  }

  public void readComponentsTreeFromDfm(ObjectTreeListEntity objectTree, String path, File file, boolean isFromCFW,
      boolean isCheckHueSource) {
    try {
      convertBinaryToText(path);
      List<String> lines = FileReadUtils.fileRead(file, CHAR_CODE);
      readLineForObjectTree(objectTree, lines, isFromCFW, isCheckHueSource);
    } catch (IOException e) {
      System.out.println("[ERROR]" + e);
    }
  }

  private int readLineForObjectTree(ObjectTreeListEntity objectTree, List<String> lines, boolean isFromCFW,
      boolean isCheckHueSource) {

    int idx = 0;
    Pattern patternObject = Pattern.compile(SelfCheckConst.reg_COMPONENT_OBJECT_2, Pattern.CASE_INSENSITIVE);
    Pattern patternInherited = Pattern.compile(SelfCheckConst.reg_COMPONENT_INHERITED_2, Pattern.CASE_INSENSITIVE);
    Pattern patternProperty = Pattern.compile(SelfCheckConst.reg_COMPONENT_PROPERTY_2, Pattern.CASE_INSENSITIVE);
    Pattern patternEnd = Pattern.compile(ConvertConst.reg_COMPONENT_END, Pattern.CASE_INSENSITIVE);

    Matcher m;

    ComponentPropertyEntity currentComponent = null;
    int currentLevel = -1;
    Map<Integer, String> currentTreeParents = new HashMap<Integer, String>();

    while (idx < lines.size()) {
      String line = lines.get(idx);
      idx++;

      // Check if it is the line which is the start of an object
      m = patternObject.matcher(line);
      if (m.find()) {
        if (currentComponent != null) {
          currentTreeParents = setComponentTreeInfomation(objectTree, currentTreeParents, currentComponent,
              currentLevel, isFromCFW, isCheckHueSource);
        }
        currentComponent = new ComponentPropertyEntity();
        int indexColon = line.indexOf(ConvertConst.con_COLON_WITH_BLANK);
        currentComponent.setName(line.substring(line.indexOf(SelfCheckConst.con_OBJECT) + 7, indexColon));
        currentComponent.setComponentName(trimComponentNumber(line.substring(indexColon + 2, line.length())));
        currentLevel = getIndentLevel(line, ConvertConst.con_SPACE.toCharArray()[0]);

        continue;
      }

      // Check if it is the line which is the start of an inherited
      m = patternInherited.matcher(line);
      if (m.find()) {
        if (currentComponent != null) {
          currentTreeParents = setComponentTreeInfomation(objectTree, currentTreeParents, currentComponent,
              currentLevel, isFromCFW, isCheckHueSource);
        }
        currentComponent = new ComponentPropertyEntity();
        int indexColon = line.indexOf(ConvertConst.con_COLON_WITH_BLANK);
        currentComponent.setName(line.substring(line.indexOf(ConvertConst.con_INHERITED) + 10, indexColon));
        currentComponent.setComponentName(trimComponentNumber(line.substring(indexColon + 2, line.length())));
        currentLevel = getIndentLevel(line, ConvertConst.con_SPACE.toCharArray()[0]);

        continue;
      }

      // Check if it is the line which represents a property
      m = patternProperty.matcher(line);
      if (m.find()) {
        if (currentComponent == null) {
          continue;
        }
        line = line.trim();

        // Skip all empty ListViews from check since most of them are changed by .pas
        // file
        boolean emptyColumn = line.matches(SelfCheckConst.reg_COMPONENT_LISTVIEW_EMPTY);
        if (emptyColumn) {
          continue;
        }

        // Since regular ListView's Property use multiple lines, branch different cases
        boolean indexColumns = line.matches(SelfCheckConst.reg_COMPONENT_LISTVIEW_START);
        if (indexColumns) {
          List<String> columnProperties = new ArrayList<String>();
          int columsEnd = Integer.MIN_VALUE;
          while (idx < lines.size() && columsEnd < 0) {
            idx++;// Skip "item" line which always in the front
            String columsLine = lines.get(idx);
            columsEnd = columsLine.indexOf(SelfCheckConst.reg_COMPONENT_LISTVIEW_END);
            columnProperties.add(columsLine);
          }
          currentComponent.getProperties().put(SelfCheckConst.con_COMPONENT_RPOPERTY_COLUMNS, columnProperties);
          idx++;
        } else {
          // Skip the non-check properties
          boolean ifArrays = (line.indexOf(SelfCheckConst.reg_COMPONENT_PROPERTY_ARRAYS_START) != -1);
          boolean ifEmptyArrays = (line.indexOf(SelfCheckConst.reg_COMPONENT_PROPERTY_EMPTY_ARRAYS) != -1);
          if (ifArrays && !ifEmptyArrays) {
            int columsEnd = Integer.MIN_VALUE;
            while (idx < lines.size() && columsEnd < 0) {
              columsEnd = lines.get(idx).indexOf(SelfCheckConst.reg_COMPONENT_LISTVIEW_END);
              idx++;// Skip "item" line which always in the front
            }
            idx++;
          }

          // For regular type of property
          int indexEqual = line.indexOf(SelfCheckConst.con_EQUAL);
          String propertyName = line.substring(0, indexEqual - 1);
          String propertyValue = null;
          if (indexEqual + 2 <= line.length()) {
            propertyValue = line.substring(indexEqual + 2, line.length());
          }
          currentComponent.getProperties().put(propertyName, propertyValue);
        }

        continue;
      }

      m = patternEnd.matcher(line);
      if (m.find()) {
        if (currentComponent != null) {
          currentTreeParents = setComponentTreeInfomation(objectTree, currentTreeParents, currentComponent,
              currentLevel, isFromCFW, isCheckHueSource);
        }
        currentComponent = null;
        continue;
      }
    }

    // Put last one in resultMap
    if (currentComponent != null) {
      currentTreeParents = setComponentTreeInfomation(objectTree, currentTreeParents, currentComponent, currentLevel,
          isFromCFW, isCheckHueSource);
    }

    return idx;

  }

  private String trimComponentNumber(String targetStr) {
    int idxNumberStart = targetStr.indexOf(" [");
    if (idxNumberStart != -1) {
      targetStr = targetStr.substring(0, idxNumberStart);
    }
    return targetStr;
  }

  private int getIndentLevel(String line, char target) {
    int count = 0;

    for (char x : line.toCharArray()) {
      if (x == target) {
        count++;
      } else {
        break;
      }
    }
    return (int) (count * 0.5);
  }

  private Map<Integer, String> setComponentTreeInfomation(ObjectTreeListEntity objectTree, Map<Integer, String> treeMap,
      ComponentPropertyEntity targetComponent, int currentLevel, boolean isFromCfw, boolean isCheckHueSource) {

    // Update informations of objectTree
    Map<Integer, String> newTreeMap = new HashMap<Integer, String>();
    Map<Integer, String> parents = new HashMap<>();
    for (Map.Entry<Integer, String> entry : treeMap.entrySet()) {
      if (entry.getKey().intValue() < currentLevel) {
        newTreeMap.put(entry.getKey(), entry.getValue());
        parents.put(entry.getKey(), entry.getValue());
      }
    }
    newTreeMap.put(currentLevel, targetComponent.getName());

    // Take over the Visible property of parent elements
    String parentName = treeMap.get(currentLevel - 1);
    ObjectTreeEntity parentInTree = getComponentFromTree(objectTree.getObjectTreeList(), parentName);
    boolean thisObjectTreeParentVisibleFromProperty = true;
    boolean thisObjectTreeParentVisibleFromWidthOrHeight = true;
    if (parentInTree != null) {
      thisObjectTreeParentVisibleFromProperty = parentInTree.getVisibleFromProperty();
      thisObjectTreeParentVisibleFromWidthOrHeight = parentInTree.getVisibleFromWidthOrHeight();
    }

    //

    // Skip components which are under the common HUE panel from the check
    boolean isNotBackSideComponent = true;
    if (isCheckHueSource) {
      isNotBackSideComponent = checkIsBacksideComponent(objectTree, targetComponent.getName(), parentName, currentLevel,
          isFromCfw);
    }

    // If the name of component is same in inheritance source, overwrite the
    // information of component
    ObjectTreeEntity entity = getComponentFromTree(objectTree.getObjectTreeList(), targetComponent.getName());
    if (entity != null) {
      setObjectTreeEntityInfo(entity, targetComponent, currentLevel, parents, thisObjectTreeParentVisibleFromProperty,
          thisObjectTreeParentVisibleFromWidthOrHeight, isNotBackSideComponent);
    } else {
      entity = new ObjectTreeEntity();
      entity = setObjectTreeEntityInfo(entity, targetComponent, currentLevel, parents,
          thisObjectTreeParentVisibleFromProperty, thisObjectTreeParentVisibleFromWidthOrHeight,
          isNotBackSideComponent);
      entity.setIsFromCfw(isFromCfw);
      objectTree.getObjectTreeList().add(entity);
    }
    return newTreeMap;
  }

  private boolean checkIsBacksideComponent(ObjectTreeListEntity objectTree, String targetComponentName,
      String paretComponentName, int currentLevel, boolean isFromCfw) {
    boolean isNotBackSideComponent = true;

    if (isFromCfw && currentLevel == 0) {
      objectTree.setAcceptDirectComponentForm(CommonPanelConst.isAcceptDirectChildComponent(targetComponentName));
    } else if (currentLevel == 1) {
      boolean isAcceptDirectCompoent = objectTree.isAcceptDirectComponentForm();
      if (!isAcceptDirectCompoent) {
        // Check if it is in white list for level 1 component
        isNotBackSideComponent = CommonPanelConst.isExistInWhiteListForLevel1(targetComponentName);
      }
    } else {
      // Check if it is in white list for others
      List<String> whiteList = CommonPanelConst.RESERVED_PARENT_PANELS.get(paretComponentName);
      if (whiteList != null) {
        boolean isVisible = false;
        for (String componentName : whiteList) {
          if (componentName.equals(targetComponentName)) {
            isVisible = true;
            break;
          }
        }
        isNotBackSideComponent = isVisible;
      }
    }

    return isNotBackSideComponent;
  }

  private ObjectTreeEntity setObjectTreeEntityInfo(ObjectTreeEntity entity, ComponentPropertyEntity targetComponent,
      int level, Map<Integer, String> parents, boolean thisObjectTreeParentVisibleFromProperty,
      boolean thisObjectTreeParentVisibleFromWidthOrHeight, boolean isNotBackSideComponent) {
    // Update Visible property from inherited source
    boolean visibilityFromProperty = entity.getVisibleFromProperty();
    boolean visibilityFromWidthOrHeight = entity.getVisibleFromWidthOrHeight();

    // Get own Visible property
    Map<String, Object> properties = targetComponent.getProperties();
    if (properties != null) {
      String visible = String.valueOf(properties.get("Visible"));
      if (visible != null) {
        if (visible.equals("False")) {
          visibilityFromProperty = false;
        } else if (visible.equals("True")) {
          visibilityFromProperty = true;
        }
      }

      String componentName = String.valueOf(targetComponent.getComponentName());
      if (ComponentType.isPanel(componentName)) {
        if (properties.get(SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH) != null) {
          int width = Integer.parseInt(properties.get(SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH).toString());
          if (width < 9) {
            visibilityFromWidthOrHeight = false;
          } else {
            visibilityFromWidthOrHeight = true;
          }
        }
        if (properties.get(SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT) != null) {
          int height = Integer.parseInt(properties.get(SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT).toString());
          if (height < 9) {
            visibilityFromWidthOrHeight = false;
          } else {
            visibilityFromWidthOrHeight = true;
          }
        }
      }
    }

    // Update Visible property by check parent components' Visible
    if (!thisObjectTreeParentVisibleFromProperty) {
      visibilityFromProperty = false;
    }
    if (!thisObjectTreeParentVisibleFromWidthOrHeight) {
      visibilityFromWidthOrHeight = false;
    }

    // Get if it is under the common panel
    if (!isNotBackSideComponent) {
      visibilityFromWidthOrHeight = false;
    }

    entity.setName(targetComponent.getName());
    entity.setLevel(level);
    entity.setParents(parents);
    entity.setVisibleFromProperty(visibilityFromProperty);
    entity.setVisibleFromeWidthOrHeight(visibilityFromWidthOrHeight);

    entity.setComponentPropertyEntity(targetComponent);
    return entity;
  }

  private ObjectTreeEntity getComponentFromTree(List<ObjectTreeEntity> objectTreeList, String name) {
    for (ObjectTreeEntity entity : objectTreeList) {
      if (entity.getName().equals(name)) {
        return entity;
      }
    }
    return null;
  }

  private Map<String, List<PositionEntity>> groupingFormElements(List<PositionEntity> componentsIsFormElements) {
    Map<String, List<PositionEntity>> result = new HashMap<>();
    result.put(SelfCheckConst.con_ISFORMELEMENTS_LABEL, new ArrayList<>());
    result.put(SelfCheckConst.con_ISFORMELEMENTS_OTHERS, new ArrayList<>());
    for (PositionEntity component : componentsIsFormElements) {
      ComponentType componentType = ComponentType.getComponent(component.getComponentProperties().getComponentName());
      if (componentType.equals(ComponentType.LABEL)) {
        result.get(SelfCheckConst.con_ISFORMELEMENTS_LABEL).add(component);
      } else {
        result.get(SelfCheckConst.con_ISFORMELEMENTS_OTHERS).add(component);
      }
    }
    return result;
  }

  private void checkComponentsWithObjectTree(List<ResultEntity> resultList,
      Map<ComponentType, ObjectTreeListEntity> componentsMap,
      Map<ComponentType, ObjectTreeListEntity> componentsMapCompany, String path, LayoutType layoutType,
      License license) throws IOException {
    logger.info("UiUxEnhancementFileService.checkComponentsWithObjectTree:start");
    PanelTreeService panelTreeService = new PanelTreeService();
    Map<String, Map<String, Integer>> panelPositionMap = new HashMap<>();
    panelTreeService.makePanelTree(componentsMap, panelPositionMap);
    List<PositionEntity> orderEntityList = formOrderEntityList(componentsMap, panelPositionMap);
    Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap = findHorizontallyAlignedComponents(
        orderEntityList);
		resultList.addAll(checkDateTimeInputComponentWidth(componentsMap.get(ComponentType.DATE_TIME), path, license,
		    horizontalAlignedComponentMap, panelPositionMap));
    resultList.addAll(validateBlueLink(componentsMap.get(ComponentType.LABEL), path, license));
    resultList.addAll(checkTextCenterAligned(componentsMap.get(ComponentType.LABEL), path, license));
    resultList.addAll(
        validateListViewComponentHeight(componentsMap, path, license, horizontalAlignedComponentMap, panelPositionMap));
    logger.info("UiUxEnhancementFileService.checkComponentsWithObjectTree:end");
  }

  protected static boolean checkNullProperty(Map<String, Object> properties, String... propertyNames) {
    boolean noNull = false;
    for (String propertyName : propertyNames) {
      Object propertyValue = properties.get(propertyName);
      if (propertyValue == null) {
        return noNull;
      }
    }
    noNull = true;
    return noNull;
  }

  /**
   * copy from old converter
   * 
   * @param filePath
   * @return
   */
  protected boolean convertBinaryToText(String filePath) {
    StringJoiner joiner = new StringJoiner(" ");

    joiner.add(binaryConverterPath);
    joiner.add("-i -s -t ");
    joiner.add(filePath);

    Runtime rt = Runtime.getRuntime();
    try {
      Process p = rt.exec(joiner.toString());
      p.waitFor();
      p.destroy();
    } catch (IOException | InterruptedException e) {
      System.out.println("[ERROR]" + e);
      return false;
    }
    return true;
  }

  private void makeOrderEntity(ObjectTreeEntity objectTree, List<PositionEntity> orderEntityList,
      Map<String, Map<String, Integer>> panelPositionMap) {
    String parentName = getParentComponentName(objectTree.getParents(), objectTree.getLevel());
    Map<String, Integer> positionMap = panelPositionMap.getOrDefault(parentName, new HashMap<>());
    Integer parentTopValue = positionMap.getOrDefault("Top", new Integer(0));
    Integer parentLeftValue = positionMap.getOrDefault("Left", new Integer(0));
    PositionEntity orderEntity = new PositionEntity(objectTree.getComponentPropertyEntity().getName(),
        objectTree.getLevel(), objectTree.getParents(), objectTree.getComponentPropertyEntity());
    Map<String, Object> propertiesMap = orderEntity.getComponentProperties().getProperties();
    int topValue = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
    int leftValue = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_LEFT);
    Integer newTopValue = new Integer(parentTopValue.intValue() + topValue);
    Integer newLeftValue = new Integer(parentLeftValue.intValue() + leftValue);
    propertiesMap.put("Top", newTopValue);
    propertiesMap.put("OldTop", topValue);
    propertiesMap.put("Left", newLeftValue);
    propertiesMap.put("OldLeft", leftValue);
    setRectInfo(orderEntity, propertiesMap);
    orderEntityList.add(orderEntity);
  }

  private void setRectInfo(PositionEntity component, Map<String, Object> propertiesMap) {
    int left = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_LEFT);
    int top = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
    int width = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH);
    int height = getIntValue(propertiesMap, SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT);
    int oldTop = getIntValue(propertiesMap, "OldTop");
    int oldLeft = getIntValue(propertiesMap, "OldLeft");
    component.setRect(left, top, width, height, oldTop, oldLeft);
  }

  private List<PositionEntity> formOrderEntityList(Map<ComponentType, ObjectTreeListEntity> componentsMap,
      Map<String, Map<String, Integer>> panelPositionMap) {

    List<ObjectTreeListEntity> objectTreeEntityList = new ArrayList<>();
    List<ObjectTreeEntity> objectTreeList = new ArrayList<>();

    componentsMap.entrySet().stream().forEach(component -> {
      objectTreeEntityList.add(new ObjectTreeListEntity(component.getValue()));
    });

    objectTreeEntityList.stream().forEach(objectTreeEntity -> {
      objectTreeEntity.getObjectTreeList().stream().forEach(objectTree -> {
        objectTreeList.add(new ObjectTreeEntity(objectTree));
      });
    });

    List<PositionEntity> orderEntityList = new ArrayList<>();
    for (ObjectTreeEntity objectTreeEntity : objectTreeList) {
      Map<String, Object> properties = objectTreeEntity.getComponentPropertyEntity().getProperties();
      boolean checkNullProperties = checkNullProperty(properties, SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH,
          SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT);
      if (!checkNullProperties) {
        continue;
      }
      makeOrderEntity(objectTreeEntity, orderEntityList, panelPositionMap);
    }
    return orderEntityList;
  }

  protected Map<Integer, List<PositionEntity>> findHorizontallyAlignedComponents(List<PositionEntity> orderEntityList) {
    Map<Integer, List<PositionEntity>> horizontallyAlignedComponents = new HashMap<>();
    orderEntityList.stream().forEach(positionEntity -> {
      Integer topValue = positionEntity.getPositionMap().get("Top");
      if (!horizontallyAlignedComponents.containsKey(topValue)) {
        horizontallyAlignedComponents.put(topValue, new ArrayList<>());
      }
      List<PositionEntity> components = horizontallyAlignedComponents.get(topValue);
      components.add(positionEntity);
    });
    return horizontallyAlignedComponents;
  }

  private List<ObjectTreeEntity> sortByTop(List<ObjectTreeEntity> objectTreeList, String parentName) {
    List<ObjectTreeEntity> filterList = objectTreeList.stream()
        .filter(objectTree -> objectTree.getInheritedVisibility())
        .filter(objectTree -> getParentComponentName(objectTree.getParents(), objectTree.getLevel()).equals(parentName))
        .collect(Collectors.toList());
    Collections.sort(filterList, new Comparator<ObjectTreeEntity>() {
      @Override
      public int compare(ObjectTreeEntity o1, ObjectTreeEntity o2) {
        int top1 = getIntValue(o1.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
        int top2 = getIntValue(o2.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
        return top1 - top2;
      }
    }.thenComparing(new Comparator<ObjectTreeEntity>() {
      @Override
      public int compare(ObjectTreeEntity o1, ObjectTreeEntity o2) {
        int top1 = getIntValue(o1.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_LEFT);
        int top2 = getIntValue(o2.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_LEFT);
        return top2 - top1;
      }
    }));
    return filterList;
  }

  private Integer getExactTop(List<ObjectTreeEntity> panelList, Integer compTop, Integer compHeight, String panelName) {
    int top = 0;
    int approx = compTop + compHeight;
    for (ObjectTreeEntity objectTree : panelList) {
      if (!objectTree.getName().trim().equals(panelName.trim())) {
        Integer panelTop = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
        Integer panelHeight = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT);
        Integer panelPos = panelTop + panelHeight;
        if (panelPos >= approx && approx <= panelPos) {
          top = panelTop;
          break;
        }
      }
    }
    return top;
  }

  private List<ResultEntity> checkDateTimeInputComponentWidth(ObjectTreeListEntity components, String path,
      License license, Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap,
      Map<String, Map<String, Integer>> panelPositionMap) {
    logger.info("UiUxEnhancementFileService.checkDateTimeInputComponentWidth:start");
    List<ResultEntity> resultList = new LinkedList<ResultEntity>();
    if (components == null) {
      return resultList;
    }
    List<ObjectTreeEntity> objectTreeList = components.getObjectTreeList();

    try {
      for (ObjectTreeEntity objectTree : objectTreeList) {
        Map<String, Object> properties = objectTree.getComponentPropertyEntity().getProperties();
        boolean checkNullProperties = checkNullProperty(properties, SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH,
            "Kind");
        if (!checkNullProperties) {
          continue;
        }
        String kindValue = getStrValue(properties, "Kind");
        if (kindValue.equals("dtkTimeOnly") || kindValue.equals("dtkBoth")) {
          continue;
        }
        String widthSize = properties.get("WidthSize").toString();
        if (widthSize.equals("wsS")) {
          resultList.add(ResultEntity.builder().filePath(path).componentType(ComponentType.DATE_TIME)
              .component(objectTree.getComponentPropertyEntity().getComponentName()).name(objectTree.getName())
              .propertyValue("wsDefault").beforeChanges("WidthSize = wsS").afterChanges("WidthSize=wsDefault")
              .comment("Changed widthSize").license(license).property("WidthSize").build());
          String parentName = getParentComponentName(objectTree.getParents(), objectTree.getLevel());
          int leftValue = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
              SelfCheckConst.con_COMPONENT_PROPERTY_LEFT);
          int topValue = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
              SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
          int componentTopValue = topValue + panelPositionMap.get(parentName).get("Top").intValue();
          int componentWidth = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
              SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH);
          properties.put("WidthSize", "wsM");
          objectTree.getComponentPropertyEntity().setProperties(properties);
          List<PositionEntity> sameRowComponents = horizontalAlignedComponentMap.get(new Integer(componentTopValue));
          Collections.sort(sameRowComponents, new Comparator<PositionEntity>() {
            @Override
            public int compare(PositionEntity o1, PositionEntity o2) {
              return o1.getPositionMap().get("Left").intValue() - o2.getPositionMap().get("Left").intValue();
            }
          });
          for (PositionEntity positionEntity : sameRowComponents) {
            if (positionEntity.getName().equals(objectTree.getName())
                || positionEntity.getPositionMap().get("Left").intValue() < leftValue) {
              continue;
            } else if ((positionEntity.getPositionMap().get("OldLeft").intValue())
                - (leftValue + componentWidth) <= 32) {
              int Oldleft = positionEntity.getPositionMap().get("OldLeft").intValue();
              int left = positionEntity.getPositionMap().get("Left").intValue();
              resultList.add(ResultEntity.builder().filePath(path)
                  .componentType(positionEntity.getComponentProperties().getComponentType())
                  .component(positionEntity.getComponentProperties().getComponentName())
                  .name(positionEntity.getComponentProperties().getName()).propertyValue(String.valueOf(left + 48))
                  .beforeChanges("Left = " + Oldleft).afterChanges("Left=" + (Oldleft + 48)).comment("Changed Left")
                  .license(license).property("Left").build());
              positionEntity.getPositionMap().put("OldLeft", new Integer(Oldleft + 48));
              positionEntity.getPositionMap().put("Left", new Integer(left + 48));
              leftValue = Oldleft;
              componentWidth = positionEntity.getPositionMap().get("Width").intValue();
              changeLeftInObjectTreeList(objectTreeList, positionEntity.getComponentProperties().getName(),
                  Oldleft + 48);
            }
          }
        }
      }
    } catch (Exception e) {
      logger.error("Error" + e);
    }
    logger.info("UiUxEnhancementFileService.checkDateTimeInputComponentWidth:end");
    return resultList;
  }

  private void changeLeftInObjectTreeList(List<ObjectTreeEntity> objectTreeList, String name, int newLeftValue) {
    for (ObjectTreeEntity objectTreeEntity : objectTreeList) {
      if (objectTreeEntity.getName().equals(name)) {
        Map<String, Object> propertiesMap = objectTreeEntity.getComponentPropertyEntity().getProperties();
        propertiesMap.put("Left", newLeftValue);
        objectTreeEntity.getComponentPropertyEntity().setProperties(propertiesMap);
      }
    }
  }

  private List<ResultEntity> validateBlueLink(ObjectTreeListEntity components, String path, License license) {
    logger.info("UiUxEnhancementFileService.validateBlueLink:start");
    List<ResultEntity> resultList = new LinkedList<ResultEntity>();

    List<ObjectTreeEntity> compList = components.getObjectTreeList().stream()
        .filter(component -> component.getComponentPropertyEntity().getComponentName().equalsIgnoreCase("TSmartLabel"))
        .collect(Collectors.toList());

    compList.stream().forEach(comp -> {
      Map<String, Object> propertiesMap = comp.getComponentPropertyEntity().getProperties();
      if (Objects.nonNull(propertiesMap)) {
        String stylePropValue = (String) propertiesMap.get("LabelStyleType");
        if (!stylePropValue.equalsIgnoreCase("lstLinkLabel")) {
          resultList.add(ResultEntity.builder().filePath(path).componentType(ComponentType.LABEL)
              .component(comp.getComponentPropertyEntity().getComponentName()).name(comp.getName())
              .property("LabelStyleType").propertyValue("lstLinkLabel")
              .beforeChanges("LabelStyleType = " + stylePropValue).afterChanges("LabelStyleType = lstLinkLabel")
              .comment("Changed component property value").license(license).build());
        }
        try {
          String fontStyleLine = Objects.nonNull(propertiesMap.get("Font.Style"))
              ? (String) propertiesMap.get("Font.Style")
              : new String();
          List<String> fontStyleList = Arrays.asList(fontStyleLine.substring(1, fontStyleLine.length() - 1).split(","));
          if (fontStyleList.contains("fsBold")) {
            List<String> fontStyleListCopy = new ArrayList<>();
            fontStyleListCopy.addAll(fontStyleList);
            fontStyleListCopy.remove("fsBold");
            resultList.add(ResultEntity.builder().filePath(path).componentType(ComponentType.LABEL)
                .component(comp.getComponentPropertyEntity().getComponentName()).name(comp.getName())
                .property("Font.Style").propertyValue(fontStyleListCopy.toString())
                .beforeChanges("Font.Style = " + fontStyleList).afterChanges("Font.Style = " + fontStyleListCopy)
                .comment("Changed component property value").license(license).build());
          }
        } catch (Exception e) {
          System.out.println(e);
        }
      }
    });

    logger.info("UiUxEnhancementFileService.validateBlueLink:end");
    return resultList;
  }

  private List<ResultEntity> validateListViewComponentHeight(Map<ComponentType, ObjectTreeListEntity> componentsMap,
      String path, License license, Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap,
      Map<String, Map<String, Integer>> panelPositionMap) {
    logger.info("UiUxEnhancementFileService.validateListViewComponentHeight:start");
    List<ResultEntity> resultList = new LinkedList<ResultEntity>();

    if (componentsMap.get(ComponentType.LIST_VIEW) == null) {
      return resultList;
    }

    List<ObjectTreeEntity> objectTreeList = componentsMap.get(ComponentType.LIST_VIEW).getObjectTreeList().stream()
        .filter(entity -> entity.getComponentPropertyEntity().getComponentName().equals("TWAListView"))
        .collect(Collectors.toList());

    List<String> tabNamesList = new ArrayList<>();
    if (componentsMap.get(ComponentType.TAB) != null) {
      tabNamesList = componentsMap.get(ComponentType.TAB).getObjectTreeList().stream()
          .filter(entity -> entity.getComponentPropertyEntity().getComponentName().equals("TTabSheet"))
          .map(entity -> entity.getComponentPropertyEntity().getName()).collect(Collectors.toList());
    }

    try {
      for (ObjectTreeEntity objectTree : objectTreeList) {

        Map<String, Object> properties = objectTree.getComponentPropertyEntity().getProperties();
        boolean checkNullProperties = checkNullProperty(properties, SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT,
            SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH);
        if (!checkNullProperties) {
          continue;
        }
        int width = getIntValue(properties, SelfCheckConst.con_COMPONENT_PROPERTY_WIDTH);
        int height = getIntValue(properties, SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT);
        if (width == 0 || height == 0) {
          continue;
        }
        if (height != 72) {
          resultList.add(ResultEntity.builder().filePath(path).componentType(ComponentType.LIST_VIEW)
              .component(objectTree.getComponentPropertyEntity().getComponentName()).name(objectTree.getName())
              .propertyValue("72").beforeChanges("Height = " + height).afterChanges("Height = 72")
              .comment("Changed Height").license(license).property("Height").build());
          int componentCurrentTopValue = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
              SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
          String componentParentName = getParentComponentName(objectTree.getParents(), objectTree.getLevel());
          int componentActualTopValue = componentCurrentTopValue
              + panelPositionMap.get(componentParentName).get("Top").intValue();
          int differenceFromCorrectHeight = 72 - height;
          List<String> tabNamesListCopy = new ArrayList<>(tabNamesList);
          tabNamesListCopy.retainAll(objectTree.getParents().values());
          String tabName = !tabNamesListCopy.isEmpty() ? tabNamesListCopy.get(0) : "";
          changeBelowComponentsTop(horizontalAlignedComponentMap, resultList, componentActualTopValue,
              differenceFromCorrectHeight, license, path, objectTreeList, tabName, tabNamesList);
        }
      }
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    logger.info("UiUxEnhancementFileService.validateListViewComponentHeight:end");
    return resultList;

  }

  private void changeBelowComponentsTop(Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap,
      List<ResultEntity> resultList, int componentActualTopValue, int differenceFromCorrectHeight, License license,
      String path, List<ObjectTreeEntity> objectTreeList, String tabName, List<String> tabNamesList) {
    List<PositionEntity> parentComponentsBelowTargetComponentList = findBelowParentComponent(
        horizontalAlignedComponentMap, componentActualTopValue, tabName, tabNamesList);
    Collections.sort(parentComponentsBelowTargetComponentList,
        (o1, o2) -> o1.getPositionMap().get("Top") - o2.getPositionMap().get("Top"));
    for (PositionEntity componentEntity : parentComponentsBelowTargetComponentList) {
      if (componentEntity.getComponentProperties().getComponentType().equals(ComponentType.PANEL)
          && getStrValue(componentEntity.getComponentProperties().getProperties(), "Align").equals("alBottom")) {
        continue;
      }
      int actualTopValueBeforeChange = componentEntity.getPositionMap().get("Top").intValue();
      int actualTopValueAfterChange = actualTopValueBeforeChange + differenceFromCorrectHeight;
      int topBeforeChange = componentEntity.getPositionMap().get("OldTop").intValue();
      int topAfterChange = topBeforeChange + differenceFromCorrectHeight;
      resultList.add(ResultEntity.builder().filePath(path)
          .componentType(componentEntity.getComponentProperties().getComponentType())
          .component(componentEntity.getComponentProperties().getComponentName())
          .name(componentEntity.getComponentProperties().getName()).propertyValue(String.valueOf(topAfterChange))
          .beforeChanges("Top = " + topBeforeChange).afterChanges("Top = " + topAfterChange).comment("Top Changed")
          .license(license).property("Top").build());
      changeComponentsInsideMap(horizontalAlignedComponentMap, actualTopValueBeforeChange, actualTopValueAfterChange,
          topBeforeChange, topAfterChange, componentEntity);
      changeObjectTreeList(objectTreeList, componentEntity);
    }
  }

  private List<PositionEntity> findBelowParentComponent(
      Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap, int componentActualTopValue, String tabName,
      List<String> tabNamesList) {
    Map<String, PositionEntity> componentsBelowTargetComponentMap = new HashMap<>();
    horizontalAlignedComponentMap.entrySet().stream().filter(map -> map.getKey().intValue() >= componentActualTopValue)
        .forEach(component -> {
          component.getValue().parallelStream().forEach(positionEntity -> {
            componentsBelowTargetComponentMap.put(positionEntity.getComponentProperties().getName(), positionEntity);
          });
        });
    List<PositionEntity> componentsBelowTargetComponentList = new ArrayList<>(
        componentsBelowTargetComponentMap.values());
    List<PositionEntity> parentComponentsBelowTargetComponentList = new ArrayList<>();
    Set<String> visitedParentsSet = new HashSet<>();
    componentsBelowTargetComponentList.stream().forEach(component -> {
      List<String> tabNamesListCopy = new ArrayList<>(tabNamesList);
      tabNamesListCopy.retainAll(component.getParents().values());
      int componentwidth = component.getPositionMap().get("Width").intValue();
      int componentheight = component.getPositionMap().get("Height").intValue();
      if (componentwidth == 0 || componentheight == 0
          || (!tabName.isEmpty() && !tabNamesListCopy.isEmpty() && !component.getParents().containsValue(tabName))) {
        return;
      }
      String parentComponent = getMainParentComponentName(component.getParents(), componentsBelowTargetComponentMap);
      if (visitedParentsSet.contains(parentComponent)
          || visitedParentsSet.contains(component.getComponentProperties().getName())) {
        return;
      }
      if (!parentComponent.isEmpty() && componentsBelowTargetComponentMap.containsKey(parentComponent)) {
        visitedParentsSet.add(parentComponent);
        parentComponentsBelowTargetComponentList.add(componentsBelowTargetComponentMap.get(parentComponent));
      } else if (!componentsBelowTargetComponentMap.containsKey(parentComponent)) {
        visitedParentsSet.add(component.getComponentProperties().getName());
        parentComponentsBelowTargetComponentList.add(component);
      }
    });
    return parentComponentsBelowTargetComponentList;
  }

  private void changeObjectTreeList(List<ObjectTreeEntity> objectTreeList, PositionEntity componentPositionEntity) {
    for (ObjectTreeEntity objectTreeEntity : objectTreeList) {
      if (objectTreeEntity.getName().equals(componentPositionEntity.getName())) {
        Map<String, Object> propertiesMap = objectTreeEntity.getComponentPropertyEntity().getProperties();
        propertiesMap.put("Top", componentPositionEntity.getPositionMap().get("OldTop"));
        objectTreeEntity.getComponentPropertyEntity().setProperties(propertiesMap);
      }
    }
  }

  private Pair<String, String> getLabelStyle(String componentName, Map<String, Object> properties) {
    String labelStyleType = "";
    Pair<String, String> pair = Pair.of("", "");
    labelStyleType = getStrValue(properties, SelfCheckConst.con_COMPONENT_PROPERTY_LABELTYPE);
    if (!labelStyleType.isEmpty()) {
      return Pair.of(SelfCheckConst.con_COMPONENT_PROPERTY_LABELTYPE, labelStyleType);
    }
    labelStyleType = getStrValue(properties, SelfCheckConst.con_COMPONENT_PROPERTY_LABELSTYLETYPE);
    if (!labelStyleType.isEmpty()) {
      return Pair.of(SelfCheckConst.con_COMPONENT_PROPERTY_LABELSTYLETYPE, labelStyleType);
    }
    return pair;
  }

  private List<ResultEntity> checkTextCenterAligned(ObjectTreeListEntity components, String path, License license) {
    logger.info("UiUxEnhancementFileService.checkTextCenterAligned:start");
    List<ResultEntity> resultList = new LinkedList<ResultEntity>();
    if (components == null) {
      return resultList;
    }
    List<ObjectTreeEntity> objectTreeList = components.getObjectTreeList().stream().collect(Collectors.toList());
    try {
      for (ObjectTreeEntity objectTree : objectTreeList) {
        if (!objectTree.getInheritedVisibility()) {
          continue;
        }
        String caption = getStrValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_CAPTION);
        if (!convertDecimalToCharater(caption).equals("～")) {
          continue;
        }
        Pair<String, String> pair = getLabelStyle(objectTree.getName(),
            objectTree.getComponentPropertyEntity().getProperties());
        String labelStyle = pair.getRight();
        String propertyValue = labelStyle.equals(SelfCheckConst.con_COMPONENT_PROPERTY_LABELSTYLETYPE_TEXT)
            ? SelfCheckConst.con_COMPONENT_PROPERTY_LABELSTYLETYPE_TEXT
            : SelfCheckConst.con_COMPONENT_PROPERTY_LABELTYPE_TEXT;
        Integer height = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT);
        Integer top = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_TOP);

        String parentName = getParentComponentName(objectTree.getParents(), objectTree.getLevel());
        List<ObjectTreeEntity> panelList = sortByTop(objectTreeList, parentName);
        Integer exactTop = getExactTop(panelList, top, height, objectTree.getName());

        if (!labelStyle.isEmpty() && !labelStyle.equals(propertyValue)) {
          resultList.add(ResultEntity.builder().filePath(path).componentType(ComponentType.LABEL)
              .component(objectTree.getComponentPropertyEntity().getComponentName()).name(objectTree.getName())
              .property(pair.getLeft()).propertyValue(pair.getRight())
              .beforeChanges(pair.getLeft() + " = " + labelStyle).afterChanges(pair.getLeft() + " = " + propertyValue)
              .comment("Changed " + pair.getLeft()).license(license).build());
        }

        if ((exactTop + 8) == top) {
          continue;
        }
        resultList.add(ResultEntity.builder().filePath(path).componentType(ComponentType.LABEL)
            .component(objectTree.getComponentPropertyEntity().getComponentName()).name(objectTree.getName())
            .property("Top").propertyValue(String.valueOf(exactTop + 8)).beforeChanges("Top = " + String.valueOf(top))
            .afterChanges("Top = " + String.valueOf(exactTop + 8)).comment("Changed Top").license(license).build());

      }

    } catch (NumberFormatException e) {
      System.out.println("Error");
    }
    logger.info("UiUxEnhancementFileService.checkTextCenterAligned:end");
    return resultList;
  }

  private List<ResultEntity> validateGridPagenation(Map<ComponentType, ObjectTreeListEntity> componentsMap, String path,
      License license, Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap,
      Map<String, Map<String, Integer>> panelPositionMap) {
    logger.info("UiUxEnhancementFileService.validateGridPagenation:start");
    List<ResultEntity> resultList = new LinkedList<ResultEntity>();

    if (componentsMap.get(ComponentType.LIST_VIEW) == null && componentsMap.get(ComponentType.GRID) == null) {
      return resultList;
    }
    List<ObjectTreeEntity> objectTreeList = new ArrayList<>();

    if (componentsMap.get(ComponentType.LIST_VIEW) != null) {
      componentsMap.get(ComponentType.LIST_VIEW).getObjectTreeList().stream()
          .filter(entity -> entity.getComponentPropertyEntity().getComponentName().equals("TListViewAC"))
          .forEach(entity -> objectTreeList.add(entity));
    }

    if (componentsMap.get(ComponentType.GRID) != null) {
      componentsMap.get(ComponentType.GRID).getObjectTreeList().stream().forEach(entity -> objectTreeList.add(entity));
    }

    if (objectTreeList.isEmpty()) {
      return resultList;
    }

    List<String> tabNamesList = new ArrayList<>();
    if (componentsMap.get(ComponentType.TAB) != null) {
      tabNamesList = componentsMap.get(ComponentType.TAB).getObjectTreeList().stream()
          .filter(entity -> entity.getComponentPropertyEntity().getComponentName().equals("TTabSheet"))
          .map(entity -> entity.getComponentPropertyEntity().getName()).collect(Collectors.toList());
    }
    try {
      Set<Integer> visitedComponentTopList = new HashSet<>();
      for (ObjectTreeEntity objectTree : objectTreeList) {
        int componentTopValue = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_TOP);
        int componentHeight = getIntValue(objectTree.getComponentPropertyEntity().getProperties(),
            SelfCheckConst.con_COMPONENT_PROPERTY_HEIGHT);
        String parentName = getParentComponentName(objectTree.getParents(), objectTree.getLevel());
        int actualComponentTopValue = componentTopValue + panelPositionMap.get(parentName).get("Top").intValue();
        if (visitedComponentTopList.contains(actualComponentTopValue + componentHeight)) {
          continue;
        }
        List<String> tabNamesListCopy = new ArrayList<>(tabNamesList);
        tabNamesListCopy.retainAll(objectTree.getParents().values());
        String tabName = !tabNamesListCopy.isEmpty() ? tabNamesListCopy.get(0) : "";
        List<PositionEntity> belowComponentsList = findBelowParentComponent(horizontalAlignedComponentMap,
            actualComponentTopValue + componentHeight, tabName, tabNamesList);
        visitedComponentTopList.add(new Integer(actualComponentTopValue + componentHeight));
        boolean isGridFooterPanelPresent = belowComponentsList.stream()
            .anyMatch(component -> component.getComponentProperties().getName().equals("huePnlGridFooter"));
        if (!isGridFooterPanelPresent) {
          continue;
        }
        List<PositionEntity> sortedComponentsList = belowComponentsList.stream().sorted((entity1,
            entity2) -> entity1.getPositionMap().get("Top").intValue() - entity2.getPositionMap().get("Top").intValue())
            .collect(Collectors.toList());
        List<PositionEntity> filteredComponentList = new ArrayList<>();
        for (PositionEntity entity : sortedComponentsList) {
          if (entity.getComponentProperties().getName().equals("huePnlGridFooter")) {
            filteredComponentList.add(entity);
            break;
          }
          filteredComponentList.add(entity);
        }

        ListIterator<PositionEntity> listIterator = filteredComponentList.listIterator(filteredComponentList.size());

        int newTopValue = -1;
        int newScreenwiseTopValue = -1;
        int iterator = 0;
        while (listIterator.hasPrevious()) {
          PositionEntity positionEntity = listIterator.previous();
          int oldTopValue = positionEntity.getPositionMap().get("OldTop").intValue();
          int oldScreenwiseTopValue = positionEntity.getPositionMap().get("Top").intValue();
          if (iterator > 0) {
            resultList.add(ResultEntity.builder().filePath(path)
                .componentType(positionEntity.getComponentProperties().getComponentType())
                .component(positionEntity.getComponentProperties().getComponentName()).name(positionEntity.getName())
                .property("Top").propertyValue(String.valueOf(newTopValue))
                .beforeChanges("Top = " + String.valueOf(oldTopValue))
                .afterChanges("Top = " + String.valueOf(newTopValue)).comment("Changed Top").license(license).build());
            changeComponentsInsideMap(horizontalAlignedComponentMap, oldScreenwiseTopValue, newScreenwiseTopValue,
                oldTopValue, newTopValue, positionEntity);
            changeObjectTreeList(objectTreeList, positionEntity);
          }
          newTopValue = oldTopValue;
          newScreenwiseTopValue = oldScreenwiseTopValue;
          iterator++;
        }
        PositionEntity huePanelGridFooterEntity = filteredComponentList.get(filteredComponentList.size() - 1);
        if (iterator > 0 && huePanelGridFooterEntity.getPositionMap().get("OldTop") != newTopValue) {
          resultList.add(ResultEntity.builder().filePath(path)
              .componentType(huePanelGridFooterEntity.getComponentProperties().getComponentType())
              .component(huePanelGridFooterEntity.getComponentProperties().getComponentName())
              .name(huePanelGridFooterEntity.getName()).property("Top").propertyValue(String.valueOf(newTopValue))
              .beforeChanges("Top = " + String.valueOf(huePanelGridFooterEntity.getPositionMap().get("OldTop")))
              .afterChanges("Top = " + String.valueOf(newTopValue)).comment("Changed Top").license(license).build());
          changeComponentsInsideMap(horizontalAlignedComponentMap, huePanelGridFooterEntity.getPositionMap().get("Top"),
              newScreenwiseTopValue, huePanelGridFooterEntity.getPositionMap().get("OldTop"), newTopValue,
              huePanelGridFooterEntity);
          changeObjectTreeList(objectTreeList, huePanelGridFooterEntity);
        }
      }
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    logger.info("UiUxEnhancementFileService.validateGridPagenation:end");
    return resultList;
  }

  private void changeComponentsInsideMap(Map<Integer, List<PositionEntity>> horizontalAlignedComponentMap,
      int oldScreenwiseTopValue, int newScreenwiseTopValue, int oldTopValue, int newTopValue,
      PositionEntity positionEntity) {
    List<PositionEntity> sameOldTopComponentsList = horizontalAlignedComponentMap
        .get(new Integer(oldScreenwiseTopValue));
    List<PositionEntity> componentRemovedPositionEntity = sameOldTopComponentsList.stream()
        .filter(entity -> !entity.getName().equals(positionEntity.getComponentProperties().getName()))
        .collect(Collectors.toList());
    List<PositionEntity> newPositionEntity = horizontalAlignedComponentMap
        .getOrDefault(new Integer(newScreenwiseTopValue), new ArrayList<>());
    positionEntity.getPositionMap().put("OldTop", newTopValue);
    positionEntity.getPositionMap().put("Top", newScreenwiseTopValue);
    newPositionEntity.add(positionEntity);
    if (componentRemovedPositionEntity.isEmpty()) {
      horizontalAlignedComponentMap.remove(new Integer(oldScreenwiseTopValue));
    } else {
      horizontalAlignedComponentMap.put(new Integer(oldScreenwiseTopValue), componentRemovedPositionEntity);
    }
    horizontalAlignedComponentMap.put(new Integer(newScreenwiseTopValue), newPositionEntity);
  }
}
