package org.intrawebtools.uiux_enhancer.applicationDesign;

import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.intrawebtools.uiux_enhancer.controller.UiUxEnhancerMainController;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class UiuxEnhancerDesign extends Application {

  ClassLoader classLoader = this.getClass().getClassLoader();
  GridPane dfmAdditionalInputGrid = new GridPane();
  Label pathLabel = new Label(UiuxEnhancerConsts.DFM_Path);
  String chosenButton = "Worksheet";
  String inputPath = null;
  String folderPath = "C:\\HUE\\Workspace\\Develop";
  String inputType = "worksheet";
  String license = "";
  String formType = "";
  TextArea logArea = new TextArea();

  @Override
  public void start(Stage primaryStage) throws Exception {
    GridPane mainGrid = setGridConfiguration();
    Scene scene = setSceneConfiguration(mainGrid);
    setPrimaryStageConfiguration(scene, primaryStage);
  }

  private Scene setSceneConfiguration(GridPane mainGrid) {
    Scene scene = new Scene(mainGrid, 850, 800);
    String styleSheetLayout = classLoader.getResource(UiuxEnhancerConsts.CSS).toExternalForm();
    scene.getStylesheets().addAll(styleSheetLayout);
    return scene;
  }

  public static void main(String[] args) {
    launch(args);
  }

  private void setPrimaryStageConfiguration(Scene scene, Stage primaryStage) {
    primaryStage.setScene(scene);
    InputStream setTitleImage = classLoader.getResourceAsStream(UiuxEnhancerConsts.Tool_Image);
    primaryStage.getIcons().add(new Image(setTitleImage, 150, 150, true, false));
    primaryStage.setResizable(false);
    primaryStage.setTitle(UiuxEnhancerConsts.Title);
    primaryStage.show();
  }

  private GridPane setGridConfiguration() {

    GridPane mainGrid = new GridPane();
    GridPane labelGrid = new GridPane();
    GridPane radiobutton = new GridPane();
    GridPane firstRowGrid = new GridPane();
    GridPane secondRowGrid = new GridPane();
    GridPane dfmPathInnerGrid = new GridPane();
    GridPane pathGrid = new GridPane();
    List<String> formTypeList = Arrays.asList("MAIN_FRAME", "DIALOG", "PARTS_FRAME", "NOT_FORM");
    List<String> licenseList = Arrays.asList("CAC", "CAM", "CFM", "CCM", "CBM");

    Label inputTypeLabel = new Label(UiuxEnhancerConsts.Input_Type);
    inputTypeLabel.setId(UiuxEnhancerConsts.inputTypeLabel);

    labelGrid.add(inputTypeLabel, 0, 0);
    labelGrid.setHgap(20);
    labelGrid.setPadding(new Insets(0, 0, 0, 20));

    ToggleGroup sourceToggle = new ToggleGroup();
    RadioButton dfmPathRadioButton = new RadioButton(UiuxEnhancerConsts.DFM);
    dfmPathRadioButton.setToggleGroup(sourceToggle);
    dfmPathRadioButton.setSelected(false);
    dfmPathRadioButton.setId(UiuxEnhancerConsts.Radio);

    RadioButton dprRadioButton = new RadioButton(UiuxEnhancerConsts.DPR);
    dprRadioButton.setToggleGroup(sourceToggle);
    dprRadioButton.setSelected(false);
    dprRadioButton.setId(UiuxEnhancerConsts.Radio);

    RadioButton worksheetRadioButton = new RadioButton(UiuxEnhancerConsts.Worksheet);
    worksheetRadioButton.setToggleGroup(sourceToggle);
    worksheetRadioButton.setSelected(true);
    worksheetRadioButton.setId(UiuxEnhancerConsts.Radio);

    RadioButton dfmFileInputRadioButton = new RadioButton(UiuxEnhancerConsts.DFM_Input_File);
    dfmFileInputRadioButton.setToggleGroup(sourceToggle);
    dfmFileInputRadioButton.setSelected(false);
    dfmFileInputRadioButton.setId(UiuxEnhancerConsts.Radio);

    toggleGroupListener(sourceToggle);

    firstRowGrid.add(dfmPathRadioButton, 0, 0);
    firstRowGrid.add(dprRadioButton, 1, 0);
    firstRowGrid.setVgap(50);
    firstRowGrid.setHgap(90);
    firstRowGrid.setPadding(new Insets(15, 0, 0, 40));

    secondRowGrid.add(worksheetRadioButton, 0, 0);
    secondRowGrid.add(dfmFileInputRadioButton, 1, 0);
    secondRowGrid.setVgap(50);
    secondRowGrid.setHgap(50);
    secondRowGrid.setPadding(new Insets(15, 0, 0, 40));

    radiobutton.setVgap(20);
    radiobutton.setHgap(80);
    radiobutton.add(firstRowGrid, 0, 0);
    radiobutton.add(secondRowGrid, 1, 0);

    pathLabel.setText(getLabel("worksheet"));
    pathLabel.setId(UiuxEnhancerConsts.DisplayLabel);

    TextField textPath = new TextField();
    textPath.setMinWidth(500);
    textFieldListener(textPath, 0);

    Label workspacePathLabel = new Label(UiuxEnhancerConsts.WORKSPACE_PATH);
    workspacePathLabel.setId(UiuxEnhancerConsts.DisplayLabel);

    TextField workspacePath = new TextField();
    workspacePath.setMinWidth(500);
    workspacePath.setPromptText(UiuxEnhancerConsts.WORKSPACE_SAMPLE_PATH);
    textFieldListener(workspacePath, 1);

    Label formType = new Label(UiuxEnhancerConsts.FORM_TYPE);
    formType.setId(UiuxEnhancerConsts.DisplayLabel);

    ComboBox formTypeField = new ComboBox(FXCollections.observableArrayList(formTypeList));
    formTypeField.setMinWidth(200);
    comboBoxListener(formTypeField, 0);

    Label licenseLabel = new Label(UiuxEnhancerConsts.LICENSE_LABEL);
    licenseLabel.setId(UiuxEnhancerConsts.DisplayLabel);

    ComboBox licenseField = new ComboBox(FXCollections.observableArrayList(licenseList));
    licenseField.setMinWidth(200);
    comboBoxListener(licenseField, 1);

    Button submitButton = new Button(UiuxEnhancerConsts.SUBMIT);
    submitButton.setTranslateX(300);
    submitButton.setTranslateY(0);
    submitButtonListener(submitButton);

    dfmPathInnerGrid.add(pathLabel, 0, 0);
    dfmPathInnerGrid.add(textPath, 0, 1);
    dfmPathInnerGrid.add(workspacePathLabel, 0, 2);
    dfmPathInnerGrid.add(workspacePath, 0, 3);
    dfmPathInnerGrid.setVgap(20);
    dfmPathInnerGrid.setHgap(20);
    dfmPathInnerGrid.setPadding(new Insets(20, 20, 20, 20));

    pathGrid.add(dfmPathInnerGrid, 0, 0);
    pathGrid.add(dfmAdditionalInputGrid, 1, 0);
    pathGrid.add(submitButton, 0, 1);
    pathGrid.setVgap(20);
    pathGrid.setHgap(20);
    pathGrid.setPadding(new Insets(20, 20, 20, 0));

    dfmAdditionalInputGrid.add(formType, 0, 0);
    dfmAdditionalInputGrid.add(formTypeField, 0, 1);
    dfmAdditionalInputGrid.add(licenseLabel, 0, 2);
    dfmAdditionalInputGrid.add(licenseField, 0, 3);
    dfmAdditionalInputGrid.setVgap(20);
    dfmAdditionalInputGrid.setHgap(80);
    dfmAdditionalInputGrid.setPadding(new Insets(20, 20, 20, 20));
    dfmAdditionalInputGrid.setVisible(false);

    Label logMessageLabel = new Label(UiuxEnhancerConsts.LOG_MESSAGE);
    logMessageLabel.setId(UiuxEnhancerConsts.DisplayLabel);

    TextAreaAppender.setTextArea(logArea);
    logArea.setMinHeight(300);

    Label noteLabel = new Label(UiuxEnhancerConsts.NOTE_MESSAGE);
    noteLabel.setId("noteLabel");

    mainGrid.setVgap(10);
    mainGrid.setHgap(80);
    mainGrid.add(labelGrid, 0, 0);
    mainGrid.add(radiobutton, 0, 1);
    mainGrid.add(pathGrid, 0, 2);
    mainGrid.add(logMessageLabel, 0, 3);
    mainGrid.add(logArea, 0, 4);
    mainGrid.add(noteLabel, 0, 5);
    mainGrid.setId(UiuxEnhancerConsts.MainGrid);
    mainGrid.setPadding(new Insets(20, 20, 20, 20));
    return mainGrid;
  }

  public void toggleGroupListener(ToggleGroup tg) {
    tg.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
      RadioButton radioButton = (RadioButton) tg.getSelectedToggle();
      if (radioButton != null) {
        chosenButton = radioButton.getText();
        pathLabel.setText(getLabel(chosenButton));
        dfmAdditionalInputGrid.setVisible(false);
      }
      if (chosenButton.equals(UiuxEnhancerConsts.DFM)) {
        dfmAdditionalInputGrid.setVisible(true);
      }
    });
  }

  void textFieldListener(TextField folderInputText, int isFolderPath) {
    folderInputText.textProperty().addListener((observable, oldValue, newValue) -> {
      switch (isFolderPath) {
      case 1:
        folderPath = newValue;
        break;
      case 2:
        formType = newValue;
        break;
      case 3:
        license = newValue;
        break;
      default:
        inputPath = newValue;
      }
    });
  }

  void comboBoxListener(ComboBox comboBox, int flag) {
    comboBox.valueProperty().addListener((ov, value, new_value) -> {
      // set the text for the label to the selected item
      switch (flag) {
      case 0:
        formType = getFormTypeName(new_value.toString());
        break;
      case 1:
        license = getLicenseName(new_value.toString());
        break;
      }
    });
  }

  public void submitButtonListener(Button button) {
    button.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        if (validateInputPath()) {
          UiUxEnhancerMainController uiUxEnhancerMainController = new UiUxEnhancerMainController();
          switch (chosenButton) {
          case UiuxEnhancerConsts.DFM:
            inputType = "dfm";
            break;
          case UiuxEnhancerConsts.DPR:
            inputType = "dpr";
            break;
          case UiuxEnhancerConsts.Worksheet:
            inputType = "worksheet";
            break;
          case UiuxEnhancerConsts.DFM_Input_File:
            inputType = "dfmFile";
            break;
          }

          new Thread(() -> {
            uiUxEnhancerMainController.start(inputPath, folderPath, inputType, formType, license);
          }).start();
        }
      }
    });
  }

  private boolean validateInputPath() {
    Alert errorAlert = new Alert(AlertType.ERROR);
    errorAlert.setTitle(UiuxEnhancerConsts.ERROR);

    boolean isPathValid = true;
    if ((inputPath == null) || (inputPath.equals(UiuxEnhancerConsts.Empty_String))) {
      errorAlert.setContentText(UiuxEnhancerConsts.InputPath_Message);
      errorAlert.showAndWait();
      isPathValid = false;
      return isPathValid;
    }

    if (!new File(folderPath).exists()) {
      errorAlert.setContentText(UiuxEnhancerConsts.Invalid_FolderPath_Message);
      errorAlert.showAndWait();
      isPathValid = false;
      return isPathValid;
    }

    switch (chosenButton) {
    case UiuxEnhancerConsts.DFM:
      if (!(inputPath.endsWith(UiuxEnhancerConsts.DFM_Extension))) {
        errorAlert.setContentText(UiuxEnhancerConsts.DFM_Path_Error_Message);
        isPathValid = false;
      }
      if (formType.isEmpty() || formType == null) {
        errorAlert.setContentText(UiuxEnhancerConsts.FORM_TYPE_Error_Message);
        isPathValid = false;
      }
      if (license.isEmpty() || license == null) {
        errorAlert.setContentText(UiuxEnhancerConsts.LICENSE_Error_Message);
        isPathValid = false;
      }
      break;
    case UiuxEnhancerConsts.DPR:
      if (!(inputPath.endsWith(UiuxEnhancerConsts.DPR_Extension))) {
        errorAlert.setContentText(UiuxEnhancerConsts.DPR_Path_Error_Message);
        isPathValid = false;
      }
      break;
    case UiuxEnhancerConsts.Worksheet:
      if (!(inputPath.endsWith(UiuxEnhancerConsts.File_Extension))) {
        errorAlert.setContentText(UiuxEnhancerConsts.Worksheet_File_Path_Error_Message);
        isPathValid = false;
      }
      break;
    case UiuxEnhancerConsts.DFM_Input_File:
      if (!(inputPath.endsWith(UiuxEnhancerConsts.File_Extension))) {
        errorAlert.setContentText(UiuxEnhancerConsts.DFM_File_Path_Error_Message);
        isPathValid = false;
      }
      break;
    default:
    }

    if (!isPathValid) {
      errorAlert.showAndWait();
    }
    return isPathValid;
  }

  private String getLabel(String radiobuttonText) {
    switch (radiobuttonText) {
    case UiuxEnhancerConsts.DFM:
      return UiuxEnhancerConsts.DFM_Path;
    case UiuxEnhancerConsts.DPR:
      return UiuxEnhancerConsts.DPR_PATH;
    case UiuxEnhancerConsts.DFM_Input_File:
      return UiuxEnhancerConsts.DFM_Input_File_Path;
    default:
      return UiuxEnhancerConsts.Worksheet_PATH;
    }
  }

  private String getLicenseName(String license) {
    switch (license) {
    case "CFM":
      return "Financial Management";
    case "CBM":
      return "Business Management";
    case "CAM":
      return "Assets Management";
    case "CCM":
      return "Cash Management";
    default:
      return "Common Module";
    }
  }

  private String getFormTypeName(String formType) {
    switch (formType) {
    case "MAIN_FRAME":
      return "Main Frame";
    case "DIALOG":
      return "Dialog";
    case "PARTS_FRAME":
      return "Parts Frame";
    default:
      return "";
    }
  }
}
