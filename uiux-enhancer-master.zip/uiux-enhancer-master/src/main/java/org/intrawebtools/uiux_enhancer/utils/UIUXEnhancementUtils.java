package org.intrawebtools.uiux_enhancer.utils;

import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.intrawebtools.uiux_enhancer.consts.SelfCheckConst;
import org.intrawebtools.uiux_enhancer.entity.PositionEntity;

public class UIUXEnhancementUtils {

  protected String getParentComponentName(Map<Integer, String> parents, int childLevel) {
    int parentLevel = childLevel - 1;
    if (!parents.containsKey(parentLevel)) {
      return SelfCheckConst.con_JAVA_STRING_EMPTY;
    }
    return parents.get(parentLevel);
  }

  protected String getMainParentComponentName(Map<Integer, String> parents,
      Map<String, PositionEntity> componentsBelowTargetComponentMap) {
    TreeMap<Integer, String> sortedParentsMap = new TreeMap<>(parents);
    for (Map.Entry<Integer, String> parent : sortedParentsMap.entrySet()) {
      if (componentsBelowTargetComponentMap.containsKey(parent.getValue())) {
        return parent.getValue();
      }
    }
    return StringUtils.EMPTY;
  }

  protected static int getIntValue(Map<String, Object> properties, String propertyName, String defaultVal) {
    return Integer.parseInt(Objects.toString(properties.get(propertyName), defaultVal));
  }

  protected static int getIntValue(Map<String, Object> properties, String propertyName) {
    return getIntValue(properties, propertyName, SelfCheckConst.con_JAVA_STRING_ZERO);
  }

  protected String getStrValue(Map<String, Object> properties, String propertyName, String defaultVal) {
    return Objects.toString(properties.get(propertyName), defaultVal);
  }

  protected String getStrValue(Map<String, Object> properties, String propertyName) {
    return getStrValue(properties, propertyName, SelfCheckConst.con_JAVA_STRING_EMPTY);
  }

//Convert Caption property from decimal to character
  protected String convertDecimalToCharater(String caption) {
    String result = SelfCheckConst.con_JAVA_STRING_EMPTY;

    int idx = 0;
    int captionLength = caption.length();

    boolean oneByte = false;
    boolean twoByte = false;
    String characterTwoByte = SelfCheckConst.con_JAVA_STRING_EMPTY;
    String characterTwoByteDecimal = SelfCheckConst.con_JAVA_STRING_EMPTY;

    while (idx < captionLength) {
      char character = caption.charAt(idx);
      String characterString = String.valueOf(character);
      idx++;

      if (characterString.equals("'")) {
        if (!oneByte) {
          oneByte = true;
          if (twoByte) {
            twoByte = false;
            characterTwoByte = characterConvert(characterTwoByteDecimal);
            result = result + characterTwoByte;
            characterTwoByteDecimal = SelfCheckConst.con_JAVA_STRING_EMPTY;
          }
        } else {
          oneByte = false;
        }
      } else if (characterString.equals(SelfCheckConst.con_DECIMAL_HASHMARK)) {
        if (oneByte) {
          result = result + characterString;
        } else {
          if (!twoByte) {
            twoByte = true;
          }
          characterTwoByte = characterConvert(characterTwoByteDecimal);
          result = result + characterTwoByte;
          characterTwoByteDecimal = SelfCheckConst.con_JAVA_STRING_EMPTY;
        }
      } else {
        if (oneByte) {
          result = result + characterString;
        }
        if (twoByte) {
          characterTwoByteDecimal = characterTwoByteDecimal + characterString;
        }
      }
    }
    if (!characterTwoByteDecimal.equals(SelfCheckConst.con_JAVA_STRING_EMPTY)) {
      characterTwoByte = characterConvert(characterTwoByteDecimal);
      result = result + characterTwoByte;
    }

    // "&" represents UNDERLINE case
    if (result.indexOf(SelfCheckConst.con_DOUBLE_AMPERSAND) != -1) {// If there is "&&" in Caption which will shown as
                                                                    // "&"
      result = result.replace(SelfCheckConst.con_DOUBLE_AMPERSAND, SelfCheckConst.con_TEMPORARYAMPERSAND);// Transform
                                                                                                          // "&&" to a
                                                                                                          // particular
                                                                                                          // word
                                                                                                          // temporary
      result = result.replace(SelfCheckConst.con_AMPERSAND, SelfCheckConst.con_JAVA_STRING_EMPTY);// Remove "&" in
                                                                                                  // Caption cause it
                                                                                                  // does not affect the
                                                                                                  // length
      result = result.replace(SelfCheckConst.con_TEMPORARYAMPERSAND, SelfCheckConst.con_AMPERSAND);// Transform the word
                                                                                                   // temporary to "&"
                                                                                                   // for actual shown
    } else {
      result = result.replace(SelfCheckConst.con_AMPERSAND, SelfCheckConst.con_JAVA_STRING_EMPTY);// Remove "&" in
                                                                                                  // Caption cause it
                                                                                                  // does not affect the
                                                                                                  // length
    }
    return result;
  }

  private String characterConvert(String code) {
    String character = SelfCheckConst.con_JAVA_STRING_EMPTY;
    if (!code.equals(SelfCheckConst.con_JAVA_STRING_EMPTY)) {
      int decimalNumber = Integer.parseInt(code);
      char[] charArray = Character.toChars(decimalNumber);
      character = new String(charArray);
    }

    return character;
  }

}
