import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Button, Classes, Icon, Drawer, Position } from "@blueprintjs/core";
import { WATCH_OPEN_PROFILE_DRAWER } from './reduxFlow/watcherActionTypes/internalWatchTypes.js';
import Header from './layout/header';

class App extends Component{

  
   handleUserDrawer = () => {
     const { reduxHandleHeaderDrawer } = this.props; 
     reduxHandleHeaderDrawer(false);
   }
  
   render(){
     
     const { openDrawer, children } = this.props;
     
      return(
          <React.Fragment>
            <Header />
            <div id="content">
              <Drawer
                icon={null}
                onClose={this.handleClose}
                title={<Icon icon={"user"} iconSize={"small"} />}
                autoFocus={true}
                canEscapeKeyClose={true}
                canOutsideClickClose={false}
                enforceFocus={false}
                hasBackdrop={false}
                isOpen={openDrawer}
                position={Position.LEFT}
                size={"242px"}
                usePortal={false}
                isCloseButtonShown={false}
                style={{ float:'left' }}
              >
                <div className={Classes.DRAWER_BODY} />
                <div className={Classes.DIALOG_BODY} />
                <div className={Classes.DRAWER_FOOTER}>
                  <Button className={`${Classes.MINIMAL} drawer-close`} icon="cross" onClick={this.handleUserDrawer}></Button>
                </div>
              </Drawer>
              {children}
            </div>
        </React.Fragment>
      );
   }
}

const mapStateToProps = (state) => {
  return {
    openDrawer: state.internal.getDrawerState
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    reduxHandleHeaderDrawer: (data) => dispatch({ type: WATCH_OPEN_PROFILE_DRAWER, data })
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(App));