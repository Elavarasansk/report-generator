import { all } from 'redux-saga/effects';
import { watchOpenProfileDrawer } from './sagas/internalSaga';


export default function* rootSaga() {
  yield all([
    watchOpenProfileDrawer()
  ]);
}
