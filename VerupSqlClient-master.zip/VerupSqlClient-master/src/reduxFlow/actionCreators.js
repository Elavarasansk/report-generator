
const loginWatcher = (authParams) => ({ type: 'LOGIN_WATCHER', payload: authParams });
const updateProfile = (profile) => ({ type: 'UPDATE_PROFILE', payload: authParams });


module.exports = {
    loginWatcher,
    updateProfile
}
