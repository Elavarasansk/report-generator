import { put, takeLatest } from 'redux-saga/effects';
import { WATCH_OPEN_PROFILE_DRAWER } from '../watcherActionTypes/internalWatchTypes.js';
import { PROFILE_DRAWER_STATE } from '../reducerActionTypes/internalReducerTypes.js';


function* watchOpenProfileDrawer() {
  yield takeLatest(WATCH_OPEN_PROFILE_DRAWER, function* (watchInfo){
    
    const { data } = watchInfo;
    yield put({ type: PROFILE_DRAWER_STATE, data });
  });
};




export {
  watchOpenProfileDrawer
}
