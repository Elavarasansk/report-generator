import { combineReducers } from 'redux';
import internal from './reducers/internalReducer';






export default combineReducers({
  internal
});
