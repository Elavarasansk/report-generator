import { combineReducers } from 'redux';
import { PROFILE_DRAWER_STATE } from '../reducerActionTypes/internalReducerTypes';

const getDrawerState = (state = false, action) => {
  const { type, data } = action;
  switch (type) {
    case PROFILE_DRAWER_STATE:
      return data;
    default:
      return state;
  }
};

export default combineReducers({
  getDrawerState
});;
