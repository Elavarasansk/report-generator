import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Alignment, Button, Classes } from "@blueprintjs/core";
import { Navbar, Divider, NavbarGroup, NavbarHeading } from "@blueprintjs/core";
import { WATCH_OPEN_PROFILE_DRAWER } from '../reduxFlow/watcherActionTypes/internalWatchTypes.js';
import '../styles/header.css';

const styles = {
    iw_header: {
      color: "burlywood",
      fontSize: 30,
      fontFamily: "initial"
    },
    divider: {
      height: 20,
      backgroundColor: 'blanchedalmond',
      width: 2
    }
}

class Header extends Component {
  
  constructor(props) {
    super(props);
    this.state= {
    }
  }
  
  handleUserDrawer = () => {
    const { openDrawer, reduxHandleHeaderDrawer } = this.props; 
    reduxHandleHeaderDrawer(!openDrawer);
  }
  
   render(){
      return(
        <Navbar style={{ position:'fixed' }}>
            <NavbarGroup align={Alignment.LEFT}>
              <div className={"iw_logo"}/>
              <NavbarHeading style={styles.iw_header}>Intraweb DC</NavbarHeading>
              
              <Divider style={styles.divider}/>
              
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="home" text="Dashboard" />
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="home" text="DB Config" />
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="document" text="Schema" />
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="automatic-updates" text="Schedule" />
            </NavbarGroup>
              
            <NavbarGroup align={Alignment.RIGHT}>
              <div className="bp3-input-group .modifier" style={{ marginRight: 10 }}>
                <span className="bp3-icon bp3-icon-search header-search"></span>
                <input className="bp3-input" type="search" placeholder="Find in App" dir="auto" />
              </div>
                
              <Divider style={styles.divider }/>
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="user" onClick={this.handleUserDrawer}/>
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="notifications" />
              <Button className={`${Classes.MINIMAL} header-button-text`} icon="cog"/>
            </NavbarGroup>
        </Navbar>
      );
   }
}

const mapStateToProps = (state) => {
  return {
    openDrawer: state.internal.getDrawerState
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    reduxHandleHeaderDrawer: (data) => dispatch({ type: WATCH_OPEN_PROFILE_DRAWER, data })
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));