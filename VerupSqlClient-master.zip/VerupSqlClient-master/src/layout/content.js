import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { Card, H5, Button, Classes } from "@blueprintjs/core";

const openDraw=false;

class Content extends Component {
  
   render(){
      return(
        <div id="content2" style={{ marginTop: 70, marginLeft: (openDraw? 242: 0) }}>
            <Card elevation={0} interactive={false} className={"chartCard"}>
                <H5>
                    <a href="#">Analytical applications</a>
                </H5>
                <p>
                    User interfaces that enable people to interact smoothly with data, ask better questions, and
                    make better decisions.
                </p>
                <Button text="Explore products" className={Classes.BUTTON} />
            </Card>
                
            <Card elevation={0} interactive={false} className={"chartCard"}>
                <H5>
                    <a href="#">Analytical applications</a>
                </H5>
                <p>
                    User interfaces that enable people to interact smoothly with data, ask better questions, and
                    make better decisions.
                </p>
                <Button text="Explore products" className={Classes.BUTTON} />
            </Card>
        </div >
      );
   }
}

export default withRouter(connect(null)(Content));