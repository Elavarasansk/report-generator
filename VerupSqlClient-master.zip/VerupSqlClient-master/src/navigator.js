import React, { Component } from 'react';
import { Route, Switch, HashRouter } from 'react-router-dom';
import App from './app.js';
import Content from './layout/content';

class Navigator extends Component{

   render(){
      return(
        <HashRouter>
            <App>
              <Switch>
                <Route path='/content' component={Content} />
              </Switch>
            </App>
        </HashRouter>
      );
   }
}
export default Navigator;