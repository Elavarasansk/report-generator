'use strict';
const { models } = require('../../server/server');

const fs = require('fs');
const path = require('path');
const multiparty = require('multiparty');
const xlsxHandler = require('read-excel-file/node');
const sheetById = path.join(__dirname, '../../resources/PROJECT_ALLOCATION_ID.xlsx');
const sheetByName = path.join(__dirname, '../../resources/PROJECT_ALLOCATION_NAME.xlsx');
const path_ = require('path');
const Excel = require('exceljs');
const resourceAllocTemplate = path.join(__dirname, '../../resources/Emp_project_alloc_template.xlsx');

module.exports = class ProjectAllocationService {

    downloadTemplate = async (type, res) => {
        const filePathToDownload = (type === 'id') ? sheetById : sheetByName;
        const files = fs.createReadStream(filePathToDownload);
        const pathSplit = filePathToDownload.split("\\");
        res.writeHead(200, { 'Content-disposition': `attachment; filename=${pathSplit[pathSplit.length - 1]}` });
        files.pipe(res);
    }

    async promisifyUpload(req) {
        return new Promise((resolve, reject) => {
            const form = new multiparty.Form();
            form.parse(req, function (err, fields, files) {
                if (err) {
                    throw new Error('Error is uploaded file');
                }
                return resolve([fields, files]);
            });
        });
    }

    projectAllocationFromDoc = async (req, isById) => {

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const { KairoUser, KairoRole, Project, ProjectAllocation } = models;
        const userIdList = [], roleIdList = [], projectIdList = [];
        const mailIdMapping = [], roleIdMapping = [], projectIdMapping = [];

        const userList = await KairoUser.find({ fields: ["email", "id"] });
        userList.forEach(e => {
            userIdList.push(e.id);
            mailIdMapping[e.email] = e.id;
        });

        const roleList = await KairoRole.find({ fields: ["name", "id"] });
        roleList.forEach(e => {
            roleIdList.push(e.id);
            roleIdMapping[e.name] = e.id;
        });

        const projectList = await Project.find({ fields: ["name", "id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
            projectIdMapping[e.name] = e.id;
        });

        //Validation and bulk insert to project allocation table.
        let schema = {};
        const metaData = { userIdList, roleIdList, projectIdList, mailIdMapping, roleIdMapping, projectIdMapping };
        if (isById) {
            schema = await this.batchInsertById(metaData);
        } else {
            schema = await this.batchInsertByName(metaData);
        }

        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            console.error('Project Allocation Upload sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet - ${originalFilename}`);
        }
        try {
            return await ProjectAllocation.create(rows);
        } catch (err) {
            console.log(err);
        }
    }

    batchInsertById = async (metaData) => {
        const { userIdList, roleIdList, projectIdList, cityIdList } = metaData;
        const schema = {
            project_id: {
                prop: 'project_id',
                required: true,
                type: Number,
                parse(cellData) {
                    const value = parseInt(cellData);
                    const checkExists = projectIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Project Doesn\'t exists');
                    }
                    return value
                }
            },
            employee_id: {
                prop: 'employee_id',
                required: true,
                type: Number,
                parse(cellData) {
                    const value = cellData;
                    const checkExists = userIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Employee Doesn\'t exists');
                    }
                    return value
                }
            },
            role_id: {
                prop: 'role_id',
                required: true,
                type: Number,
                parse(cellData) {
                    const value = parseInt(cellData);
                    const checkExists = roleIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Role Doesn\'t exists');
                    }
                    return value
                }
            },
            manager_id: {
                prop: 'manager_id',
                type: Number,
                parse(cellData) {
                    if (!cellData) {
                        return cellData;
                    }
                    const value = parseInt(cellData);
                    const checkExists = userIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Manager Doesn\'t exists');
                    }
                    return value
                }
            },
            report_to: {
                prop: 'report_to',
                type: Number,
                parse(cellData) {
                    if (!cellData) {
                        return cellData;
                    }
                    const value = parseInt(cellData);
                    const checkExists = userIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Report to Doesn\'t exists');
                    }
                    return value
                }
            },
            city_id: {
                prop: 'city_id',
                type: Number,
                parse(cellData) {
                    const value = parseInt(cellData);
                    const checkExists = cityIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('City Doesn\'t exists');
                    }
                    return value
                }
            },
            department: {
                prop: 'department',
                type: String
            },
            active: {
                prop: 'active',
                parse(value) {
                    switch (value) {
                        case 1:
                        case true:
                        case 'True':
                        case 'true':
                            return true;

                        default:
                            return 0;
                    }
                }
            },
            joiningDate: {
                prop: 'joiningDate',
                type: Date
            },
            relievingDate: {
                prop: 'relievingDate',
                type: Date
            }
        }
        return schema;
    }


    batchInsertByName = async (metaData) => {
        const { mailIdMapping, roleIdMapping, projectIdMapping } = metaData;
        const schema = {
            project_name: {
                prop: 'project_id',
                required: true,
                type: Number,
                parse(value) {
                    const id = projectIdMapping[value];
                    if (!id) {
                        throw new Error('Project Doesn\'t exists')
                    }
                    return id;
                }
            },
            employee_email: {
                prop: 'employee_id',
                required: true,
                type: Number,
                parse(value) {
                    const id = mailIdMapping[value];
                    if (!id) {
                        throw new Error('Employee Doesn\'t exists')
                    }
                    return id;
                }
            },
            role_type: {
                prop: 'role_id',
                required: true,
                type: Number,
                parse(value) {
                    const id = roleIdMapping[value];
                    if (!id) {
                        throw new Error('Role Doesn\'t exists')
                    }
                    return id;
                }
            },
            manager_email: {
                prop: 'manager_id',
                required: true,
                type: Number,
                parse(value) {
                    if (!value) {
                        return value;
                    }
                    const id = mailIdMapping[value];
                    if (!id) {
                        throw new Error('Manager Doesn\'t exists')
                    }
                    return id;
                }
            },
            report_to_email: {
                prop: 'report_to',
                required: true,
                type: Number,
                parse(value) {
                    if (!value) {
                        return value;
                    }
                    const id = mailIdMapping[value];
                    if (!id) {
                        throw new Error('Report to Doesn\'t exists')
                    }
                    return id;
                }
            },
            active: {
                prop: 'active',
                parse(value) {
                    switch (value) {
                        case 1:
                        case true:
                        case 'True':
                        case 'true':
                            return true;

                        default:
                            return 0;
                    }
                }
            },
            joiningDate: {
                prop: 'joiningDate',
                type: Date,
            },
            relievingDate: {
                prop: 'relievingDate',
                type: Date,
            }
        }
        return schema;
    }

    projectAllocBulkInsert = async (req) => {

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }
        const { Project, OrganisationDivision } = models;
        const finalResource = await xlsxHandler(fileInfo.path, { sheet: 1 });

        const projectObj = this.getProjectList(finalResource);
        const projects = [];
        const orgList = {};

        const orgDivision = await OrganisationDivision.find({ fields: ["name", "id"] });
        orgDivision.forEach(e => {
            orgList[e.name] = [e.id];
        });

        Object.entries(projectObj).forEach(([key, value]) => {
            const temp = { name: key, 'organisation_division_id': orgList[value] };
            projects.push(temp);
        });

        try {
            await Project.create(projects);
        } catch (err) {
            console.log(err);
        }
        const projectAllocList = await this.getProjectAllocList(finalResource);
        return await this.insertProjectTable(projectAllocList);
    }

    insertProjectTable = async (projectAllocList) => {

        const templatePath = path_.join(__dirname, '../../resources/PROJECT_ALLOCATION_ID.xlsx');
        const outputFilePath = __dirname + '/' + `PROJECT_ALLOCATION_ID${Date.now()}.xlsx`;
        const workbook = new Excel.Workbook();

        await workbook.xlsx.readFile(templatePath);
        let count = 2;
        let worksheet = workbook.getWorksheet('PROJECT_ALLOCATION_ID');
        projectAllocList.forEach(data => {
            const { employee_id, manager_id, project_id, report_to, role_id, department, city_id } = data;

            let row = worksheet.getRow(count);
            row.getCell(2).value = project_id;
            row.getCell(3).value = employee_id;
            row.getCell(4).value = role_id;
            row.getCell(5).value = manager_id;
            row.getCell(6).value = report_to;
            row.getCell(7).value = city_id;
            row.getCell(8).value = department;
            row.commit();
            count++;
        });
        await workbook.xlsx.writeFile(outputFilePath);

        const { KairoUser, KairoRole, ProjectAllocation, City, Project } = models;
        const userIdList = [], roleIdList = [], projectIdList = [], cityIdList = [];

        const userList = await KairoUser.find({ fields: ["id", "empId", "probationId"] });
        userList.forEach(e => {
            userIdList.push(e.id);
        });

        const roleList = await KairoRole.find({ fields: ["name", "id"] });
        roleList.forEach(e => {
            roleIdList.push(e.id);
        });

        const projectList = await Project.find({ fields: ["name", "id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
        });

        const cityList = await City.find({ fields: ["name", "id"] });
        cityList.forEach(e => {
            cityIdList.push(e.id);
        });

        //Validation and bulk insert to project allocation table.
        let schema = {};
        const metaData = { userIdList, roleIdList, projectIdList, cityIdList };
        schema = await this.batchInsertById(metaData);

        const { rows, errors } = await xlsxHandler(outputFilePath, { schema });
        fs.unlinkSync(outputFilePath);

        if (errors.length > 0) {
            console.error('Project Allocation Upload sheet error', errors);
        }
        if (rows.length === 0) {
            console.error(`You have uploaded empty sheet`);
        }
        try {
            return await ProjectAllocation.create(rows);
        } catch (err) {
            console.log(err);
        }
    }

    getProjectList = (finalResource) => {
        const projectObj = {};
        for (var c = 1; c < finalResource.length; c++) {
            let rec = finalResource[c];
            let name = rec[8];
            let divison = rec[7];
            if (!projectObj[name]) {
                projectObj[name] = divison.toUpperCase();
            }

        }
        return projectObj;
    }

    getProjectAllocList = async (finalResource) => {

        const { KairoUser, KairoRole, Project, RoleMapping, City } = models;
        const userIdList = {}, roleIdList = {}, projectIdList = [];
        const nameIdMapping = [], roleIdMapping = [], projectIdMapping = [], cityMapping = [];

        const userList = await KairoUser.find({ fields: ["firstName", "empId", "email", "id"] });
        userList.forEach(e => {
            userIdList[e.email] = e.id;
            nameIdMapping[e.firstName] = e.id;
        });

        const roleIdMappingList = await RoleMapping.find({ fields: ["principalId", "roleId"] });
        roleIdMappingList.forEach(e => {
            roleIdMapping[e.principalId] = e.roleId;
        });

        const projectList = await Project.find({ fields: ["name", "id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
            projectIdMapping[e.name] = e.id;
        });

        const cityList = await City.find({ fields: ["name", "id"] });
        cityList.forEach(e => {
            cityMapping[e.name] = e.id;
        });

        /* find duplicate user
         let duplicateList = [] , duplicateData = [] , duplicateMap = [];  
         finalResource.forEach(e =>{
             if(!duplicateList.includes(e[2])){
                 duplicateList.push(e[2]);
             }else{
                 duplicateMap.push(e[2]);
                 duplicateData.push(e)
             }
         })
         */

        const projectAllocList = [];
        for (var c = 1; c < finalResource.length; c++) {
            let rec = finalResource[c];
            let projectName = rec[8];
            let emailId = rec[9];
            let managerName = rec[3];
            let reportToName = rec[5] && rec[5] != "" ? rec[5] : rec[4] && rec[4] != "" ? rec[4] : managerName;
            if (emailId) {
                let employeeId = nameIdMapping[rec[2]];
                let reportTo = nameIdMapping[reportToName];

                /* find duplicate user

                if(duplicateData[rec[2]]){
                   const filterData = duplicateData.filter(e => e[2] == rec[2] && e[3] == managerName );
                   employeeId = filterData ? filterData[1] : employeeId ;
                }

                if(duplicateData[reportToName]){
                    const filterData = duplicateData.filter(e => e[2] == rec[2] && e[3] == managerName );
                    reportTo = filterData ? filterData[1] : reportTo ;
                }
                */

                let resouceData = {
                    project_id: projectIdMapping[projectName],
                    employee_id: employeeId,
                    role_id: roleIdMapping[userIdList[rec[9]]],
                    manager_id: nameIdMapping[managerName],
                    report_to: reportTo,
                    city_id: cityMapping[rec[13].toUpperCase()]
                }
                projectAllocList.push(resouceData);

            };
        }
        return projectAllocList;
    }


    projectAllocBulkUpdate = async (req) => {

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const finalResource = await xlsxHandler(fileInfo.path, { sheet: 1 });
        const projectAllocList = await this.getProjectAllocList(finalResource);
        let insertList = [];
        let oldProjectList = [];
        const { ProjectAllocation } = models;

        for (let data of projectAllocList) {
            let userList = await this.findProjectChange(data);
            if (!userList) {
                insertList.push(data);
                oldProjectList.push(data.employee_id);
            }
        };
        for (let oldData of oldProjectList) {
            await ProjectAllocation.updateAll({ employee_id: oldData }, { current: false });
        }
        return await this.insertProjectTable(insertList);
    }

    findProjectChange = async (data) => {
        const { ProjectAllocation } = models;
        const { employee_id, project_id } = data;
        let userList = await ProjectAllocation.findOne({ where: { and: [{ employee_id }, { project_id }, { current: true }] } });
        return userList;
    }

    changeEmployeeRole = async (options, employee_id, role_id, project_id) => {
        const { ProjectAllocation } = models;
        let allocRec = await ProjectAllocation.find({ where: { and: [{ employee_id: { inq: employee_id }, project_id }] } });

        for (let c = 0; c < allocRec.length; c++) {
            let rec = allocRec[c];
            let auditList = [];
            rec = rec['__data'];
            if (rec['audit']) {
                auditList = rec['audit'];
            }
            delete rec['audit'];
            auditList.push(rec);
            const updatedRec = await ProjectAllocation.upsertWithWhere({ employee_id: rec['employee_id'], project_id }, { report_to: null, manager_id: null, role_id, audit: auditList, current: true });
        }
    }

    changeEmployeeTeam = async (options, employee_id, project_id, report_to, manager_id) => {
        const { ProjectAllocation } = models;
        let allocRec = await ProjectAllocation.find({ where: { and: [{ employee_id: { inq: employee_id }, project_id }] } });

        for (let c = 0; c < allocRec.length; c++) {
            let rec = allocRec[c];
            let auditList = [];
            rec = rec['__data'];
            if (rec['audit']) {
                auditList = rec['audit'];
            }
            delete rec['audit'];
            auditList.push(rec);
            const updatedRec = await ProjectAllocation.upsertWithWhere({ employee_id: rec['employee_id'], project_id }, { report_to, manager_id, audit: auditList, current: true });
        }
    }

    changeEmployeeProject = async (options, employee_id, project_id, role_id) => {
        const { ProjectAllocation } = models;
        const resData = [];

        let allocRec = await ProjectAllocation.find({ where: { and: [{ employee_id: { inq: employee_id }, current: true }] } });
        for (let c = 0; c < allocRec.length; c++) {
            let rec = allocRec[c];
            rec = rec['__data'];

            let existingRec = await ProjectAllocation.findOne({ where: { and: [{ employee_id: rec['employee_id'], project_id }] } });
            if (existingRec) {
                await ProjectAllocation.upsertWithWhere({ id: existingRec['id'] }, { role_id, current: true, report_to: null, manager_id: null });
            } else {
                resData.push({ employee_id: rec['employee_id'], project_id, role_id, current: true });
            }
            await ProjectAllocation.upsertWithWhere({ id: rec['id'] }, { current: false });
        }
        try {
            await ProjectAllocation.create(resData);
        } catch (err) {
            console.log(err);
        }
    }

    downloadResourceAllocTemplate = async (res) => {
        const files = fs.createReadStream(resourceAllocTemplate);
        const pathSplit = resourceAllocTemplate.split("\\");
        res.writeHead(200, { 'Content-disposition': `attachment; filename=${pathSplit[pathSplit.length - 1]}` });
        files.pipe(res);
    }

    getProjAllocRecords = async (limit, skip, project_id, manager_id, report_to, empId, name) => {
        const { ProjectAllocation, KairoUser } = models;
        const conditions = [];
        conditions.push({ current: true });
        const empIdList = [];

        if (project_id) {
            conditions.push({ project_id });
        }
        if (manager_id) {
            conditions.push({ manager_id });
        }
        if (report_to) {
            conditions.push({ report_to });
        }
        if (empId) {
            empId = '%' + empId + '%';
            let empRec = await KairoUser.find({ where: { empId: { like: empId } } })
            empRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (name) {
            name = '%' + name + '%';
            let nameRec = await KairoUser.find({ where: { firstName: { like: name } } });
            nameRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (empIdList.length > 0) {
            conditions.push({ employee_id: { inq: empIdList } });
        }

        const filter = {
            where: { and: conditions },
            fields: ["employee_id","role_id","report_to","manager_id","project_id","city_id"],
            include: [
                {
                    relation: "employee",
                    scope: { fields: ["firstName", "empId", "username"] }
                }, {
                    relation: "kairoRole",
                    scope: { fields: ["name"] }
                }, {
                    relation: "reportTo",
                    scope: { fields: ["firstName"] }
                }, {
                    relation: "manager",
                    scope: { fields: ["firstName"] }
                }, {
                    relation: "project",
                    scope: {
                        fields: ["name", "organisation_division_id"],
                        include: {
                            relation: "organisationDivision",
                            scope: {
                                fields: ["name", "organisation_id"],
                                include: {
                                    relation: "organisation",
                                    scope: { fields: ["name", "displayName"] }
                                }
                            }
                        } 
                    } 
                }, {
                    relation: "city"
                }
            ]
        }

        const totalCount = await ProjectAllocation.count(filter);
        const records = await this.sortProjectAllocByEmpId(await ProjectAllocation.find({ ...filter, limit, skip }), true);
        return {
            totalCount,
            records
        };
    }

    getMyTeamResources = async (userId, limit, skip, manager_id, report_to, empId, name) => {
        const { ProjectAllocation, KairoUser } = models;
        const conditions = [];
        const empIdList = [];

        let whereCondition = { and: [{ current: true }, { or: [{ report_to: userId }, { manager_id: userId }] }] };

        if (manager_id) {
            conditions.push({ manager_id });
        }
        if (report_to) {
            conditions.push({ report_to });
        }
        if (empId) {
            empId = '%' + empId + '%';
            let empRec = await KairoUser.find({ where: { empId: { like: empId } } })
            empRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (name) {
            name = '%' + name + '%';
            let nameRec = await KairoUser.find({ where: { firstName: { like: name } } });
            nameRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (empIdList.length > 0) {
            conditions.push({ employee_id: { inq: empIdList } });
        }
        if (conditions.length > 0) {
            let andCond = whereCondition['and'];
            andCond.push({ and: conditions });
            whereCondition['and'] = andCond;
        }

        const filter = {
            where: whereCondition,
            fields: ["employee_id","role_id","report_to","manager_id","project_id","city_id"],
            include: [
                {
                    relation: "employee",
                    scope: { fields: ["firstName", "empId", "username", "email", "gender"] }
                }, {
                    relation: "kairoRole",
                    scope: { fields: ["name", "power"] }
                }, {
                    relation: "reportTo",
                    scope: { fields: ["empId", "firstName", "username", "email"] }
                }, {
                    relation: "manager",
                    scope: { fields: ["empId", "firstName", "username", "email"] }
                }, {
                    relation: "project",
                    scope: {
                        fields: ["name", "organisation_division_id"],
                        include: {
                            relation: "organisationDivision",
                            scope: {
                                fields: ["name", "organisation_id"],
                                include: {
                                    relation: "organisation",
                                    scope: { fields: ["name", "displayName"] }
                                }
                            }
                        } 
                    } 
                }, {
                    relation: "city"
                }
            ]
        }
        
        const totalCount = await ProjectAllocation.count(filter); 
        const records = await this.sortProjectAllocByEmpId(await ProjectAllocation.find({ ...filter, limit, skip }), true);
        return { 
            totalCount,
            records
        };
    }


    projectAllocBulkUpdateNew = async (req) => {
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const finalResource = await xlsxHandler(fileInfo.path, { sheet: 1 });
        const projectAllocList = await this.getProjectAllocList(finalResource);
        let insertList = [];
        let updateList = [];
        const empProjectMap = {};

        const { ProjectAllocation  } = models;
        const allRec = await ProjectAllocation.find({ 
            fields: ["employee_id","role_id","project_id","report_to","manager_id","city_id","current"], 
            current: true 
        });
        allRec.forEach(rec => empProjectMap[rec['employee_id']] = rec['project_id']);

        for (let data of projectAllocList) {
            const { employee_id, project_id } = data;
            const projectRec = await ProjectAllocation.findOne({ where: { employee_id, project_id }});
            let audit = [];

            if(!projectRec) {
                let isValid = empProjectMap[data['manager_id']] === data['project_id'] && empProjectMap[data['report_to']] === data['project_id'];
                const otherProjectRecords = await ProjectAllocation.find({ where: { employee_id }});
                if(otherProjectRecords.length > 0) {
                    for(let proj of otherProjectRecords) {
                        await ProjectAllocation.upsertWithWhere({ id: proj['id'] }, { current: false });
                    }
                }
                insertList.push({ ...data, isValidHierarchy: isValid, current: true, shift_id: 1 });
            } else {
                const { id, current } = projectRec;
                let insertRec = projectRec['__data'];
                let isAuditRequired = false;
                let isValidHierarchy = false;

                if(current) {
                    audit = insertRec['audit'] ? insertRec['audit'] : [];
                    isValidHierarchy = empProjectMap[data['manager_id']] === projectRec['project_id'] && empProjectMap[data['report_to']] === projectRec['project_id'];
                    if(data['manager_id'] !== projectRec['manager_id']) {
                        isAuditRequired = true;
                        insertRec = { ...insertRec, manager_id: data['manager_id'] };
                    } 
                    if(data['report_to'] !== projectRec['report_to']) {
                        isAuditRequired = true;
                        insertRec = { ...insertRec, report_to: data['report_to'] };
                    } 
                    if(data['city_id'] !== projectRec['city_id']) {
                        isAuditRequired = true;
                        insertRec = { ...insertRec, city_id: data['city_id'] };
                    } 
                    if(data['project_id'] !== projectRec['project_id']) {
                        insertRec = { ...insertRec, project_id: data['project_id'] };
                        updateList.push(insertRec);
                        await ProjectAllocation.upsertWithWhere({ employee_id, project_id }, { current: false });
                    }
                    if(isAuditRequired) {
                        let temp = projectRec['__data'];
                        delete temp['audit'];
                        audit.push(temp);
                        insertRec = { ...insertRec, audit };
                        updateList.push(insertRec);
                    }
                } else { 
                    isValidHierarchy = empProjectMap[data['manager_id']] === projectRec['project_id'] && empProjectMap[data['report_to']] === projectRec['project_id'];
                    audit = projectRec['audit'] ? projectRec['audit'] : [];
                    let temp = projectRec['__data'];
                    delete temp['audit'];
                    audit.push(temp);
                    const otherProjectRecords = await ProjectAllocation.find({ where: { employee_id }});
                    if(otherProjectRecords.length > 0) {
                        for(let proj of otherProjectRecords) {
                            await ProjectAllocation.upsertWithWhere({ id: proj['id'] }, { current: false });
                        }
                    }
                    await ProjectAllocation.upsertWithWhere({ id }, { 
                        ...temp, 
                        project_id: data['project_id'],
                        report_to: data['report_to'],
                        manager_id: data['manager_id'],
                        city_id: data['city_id'],
                        isValidHierarchy, 
                        audit, 
                        current: true });
                }
            }
        }        
        if(insertList.length > 0) {
            await ProjectAllocation.create(insertList);
        }
        for(let rec of updateList) {
            let upsertId = rec['id'];
            delete rec['id'];
            await ProjectAllocation.upsertWithWhere({ id: upsertId }, rec);
        }
    }

    sortProjectAllocByEmpId = async function(records, isAsc) {
        return await records.sort((a,b) => {
            let aEmpId = a['__data']['employee']['__data']['empId'];
            let bEmpId = b['__data']['employee']['__data']['empId'];
            if(isAsc) 
                return aEmpId - bEmpId;
            return bEmpId - aEmpId;
        });
    }

    
    
    addUserProject = async (result) => {
        const { ProjectAllocation,Project,KairoUser,RoleMapping } = models;
        const defaultMangerId = await Project.find({ fields: [ "default_manager_id"],where:{id: result.project} });
        const {default_manager_id} = defaultMangerId[0];
        const userExists =await KairoUser.findOne({where:{ id:default_manager_id,active:true}});
        let roleMapping=null;
        const projAllocData = {
            support: 0,
            current:1,
            project_id: result.project,
            employee_id: result.id,
            role_id: result.role,
            manager_id:default_manager_id,
            city_id:1
        }
        const createRoleMapping ={
            principalType:"USER",
            principalId:result.id,
            roleId:result.role
        }
        roleMapping = await RoleMapping.create(createRoleMapping);
        if(userExists){
            return await ProjectAllocation.create(projAllocData);
        }else{
            throw new Error('Please change the Manager whose is active');
        }
    }
}
