'use strict';
const KairouserHook = require('../../hooks/kairouserHook');
const KairouserService = require('../../services/kairouserService');
const LeaveRequestService = require('../../services/leaveRequestService');
const KairoUserMasterSettingsService = require('../../services/kairoUserMasterSettingsService');
const ProjectAllocationService = require('../../services/ProjectAllocationService');
const UserNotificationSettingService = require('../../services/userNotificationSettingService');
const MailService = require('../../services/mailService');


module.exports = function (Kairouser) {

    /*Remote Hooks */
    Kairouser.afterRemote('login', loginHook);
    Kairouser.afterRemote('logout', logOutHook);
    Kairouser.beforeRemote('create', createHook);

    Kairouser.observe('after save', afterInsertUpdateLeaveBalance);
    Kairouser.observe('after save', afterInsertUserNotificationSetting);


    /*Remote Hook Functions */
    async function createHook(ctx) {
        const kairouserHook = new KairouserHook();
        return kairouserHook.createHook(ctx);
    }

    async function loginHook(ctx) {
        const kairouserHook = new KairouserHook();
        return kairouserHook.loginHook(ctx);
    }

    async function logOutHook(ctx) {
        const kairouserHook = new KairouserHook();
        return kairouserHook.logOutHook(ctx);
    }

    async function myFCHook(ctx) {
        const kairouserHook = new KairouserHook();
        return kairouserHook.myFCHook(ctx);
    }

    /* AfterSave Hook*/
    async function afterInsertUpdateLeaveBalance(ctx) {
        const { instance, isNewInstance, data, options } = ctx;
        if (isNewInstance) {
            ctx.instance = instance;
            const kumss = new KairoUserMasterSettingsService();
            await kumss.afterCreatingNewUser(instance);
        }
    }

    /*Remote Methods Configuring*/
    Kairouser.remoteMethod('validateSession', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "get", path: "/validate/session" }
    });

    Kairouser.remoteMethod('getLeaveBalance', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "get", path: "/leave/balance" }
    });

    Kairouser.remoteMethod('exportUsers', {
        returns: { arg: "data", type: "object", root: true },
        accepts: [
            { arg: 'res', type: 'object', 'http': { source: 'res' } }
        ],
        http: { verb: "get", path: "/export" }
    });

    Kairouser.exportUsers = async function (res) {
        const kairouserService = new KairouserService();
        return await kairouserService.exportUser(res);
    }


    Kairouser.remoteMethod('getUsers', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "post", path: "/management" }
    });

    Kairouser.getUsers = async function (req) {
        const kairouserService = new KairouserService();
        return await kairouserService.getUsers(req);
    }

    Kairouser.remoteMethod('bulkInsert', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "post", path: "/bulk/insert" }
    });

    Kairouser.remoteMethod('myBasicDetails', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "get", path: "/basic/details" }
    });

    Kairouser.bulkInsert = async function (req) {
        const kairouserService = new KairouserService();
        return await kairouserService.bulkInsert(req);
    }

    /*Remote Methods*/
    Kairouser.validateSession = async function (req) {
        const kairouserService = new KairouserService();
        return await kairouserService.validateSession(req);
    }

    Kairouser.getLeaveBalance = async function (req) {
        const kairouserService = new KairouserService();
        const { userId } = req.accessToken;
        const { leaveAlloted, leaveApplied, leaveUtilized } = await kairouserService.getLeaveBalance(userId);
        return { leaveAlloted, leaveApplied, leaveUtilized };
    }

    /*Remote Methods*/
    Kairouser.remoteMethod('myHierarchy', {
        accepts: [{ arg: 'userId', type: 'string' }],
        returns: { arg: "response", type: Object, root: true },
        http: { verb: "get", path: "/my/hierarchy" }
    });


    Kairouser.myHierarchy = async function (userId) {
        const lrs = new LeaveRequestService();
        return await lrs.myApprovalFlowDetails(userId);
    }


    Kairouser.remoteMethod('bulkInsertLeaveBalance', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "post", path: "/bulk/insert/leavebalance" }
    });

    Kairouser.bulkInsertLeaveBalance = async function (req) {
        const kairouserService = new KairouserService();
        return await kairouserService.bulkInsertLeaveBalance(req);
    }

    Kairouser.remoteMethod('leaveMasterInfo', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "post", path: "/leave/master/info" }
    });

    Kairouser.leaveMasterInfo = async function (req) {
        const { userId } = req.accessToken;
        const kairouserService = new KairouserService();
        return await kairouserService.leaveMasterInfo(userId);
    }

    Kairouser.myBasicDetails = async function (req) {
        const { userId } = req.accessToken;
        const kairouserService = new KairouserService();
        return await kairouserService.myBasicDetails(userId);
    }

    /* AfterSave Hook*/
    async function afterInsertUserNotificationSetting(ctx) {
        const { instance, isNewInstance, data, options } = ctx;
        if (isNewInstance) {
            ctx.instance = instance;
            const unss = new UserNotificationSettingService();
            unss.afterCreatingNewUser(instance);
        }
    }

    Kairouser.remoteMethod('resetPassword', {
        accepts: [
            {
                arg: 'userDetail', type: {
                    email: { type: "string" },
                    username: {type: 'string' },
                    password: {type: 'string' },
                    otp: {type: 'number' },
                }, 'http': { source: 'query' }
            },
        ],
        returns: { arg: "response", type: Object, root: true },
        http: { verb: "post", path: "/reset/password" }
    });

    Kairouser.resetPassword = async function (userDetail) {
        const { email , username , otp , password } = userDetail;
        const kairouserService = new KairouserService();
        return await kairouserService.resetPassword(email , username , otp , password);
    }

    Kairouser.remoteMethod('forgotPassword', {
		accepts: [
			{
                arg: 'userDetail', type: {
                    email: { type: "string" },
                    username: {type: 'string' },
                }, 'http': { source: 'query' }
            },
			],
			http: { path: '/forgotPassword', verb: 'get' },
			returns: { arg: 'response', type: Object, root: true },
    });
    
    Kairouser.forgotPassword = async function (userDetail) {
        const { email , username } = userDetail;
        const kairouserService = new KairouserService();
        const mailService = new MailService();
		return await kairouserService.forgotPassword(email,username,mailService);
	};

    Kairouser.beforeRemote('addUser', createHook);

    Kairouser.remoteMethod('addUser', {
        accepts: { arg: 'req', type: 'object', 'http': { source: 'req' } },
        returns: { arg: "data", type: "object", root: true },
        http: { verb: "post", path: "/add/user" }
    });

    Kairouser.addUser =  async(req) => {
        const kairouserService = new KairouserService();
        return await kairouserService.addUser(req);
    }
    Kairouser.afterRemote('addUser', createNewUserHook);

    async function createNewUserHook(ctx) {
        const {  result } = ctx;
        const projectAllocationService = new ProjectAllocationService();
                 
        return await projectAllocationService.addUserProject(result);
        
    }

};