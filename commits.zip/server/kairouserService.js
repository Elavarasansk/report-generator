'use strict';
const { models } = require('../../server/server');
const fs = require('fs');
const path_ = require('path');
const Excel = require('exceljs');
const multiparty = require('multiparty');
const xlsxHandler = require('read-excel-file/node');
const KairoUserMasterSettingsService = require('./kairoUserMasterSettingsService');
const bcrypt = require('bcryptjs');
const moment = require('moment');

module.exports = class KairouserService {

	constructor(props) {
		this.kumss = new KairoUserMasterSettingsService();
	}

	validateSession = async (req) => {
		const { AccessToken, RoleMapping, KairoRole } = models;

		let response = {
			roleInfo: null,
			loginResponse: null
		}

		const { access_token } = req.signedCookies;
		const myToken = await AccessToken.find({ where: { id: { eq: access_token } } });

		if (myToken.length > 0) {
			const myRoleMapping = await RoleMapping.find({ where: { principalId: { eq: myToken[0].userId } } });
			const { roleId } = myRoleMapping[0];
			const myRoles = await KairoRole.find({ where: { id: { eq: roleId } } });
			response = {
				roleInfo: myRoles[0],
				loginResponse: myToken[0]
			}
		}
		return response;
	}

	getLeaveBalance = async (userId) => {
		const { KairoUser } = models;
		const fields = ["id", "leaveAlloted", "leaveApplied", "leaveUtilized"];
		const kairoUserList = await KairoUser.find({ where: { id: userId }, fields });
		if (kairoUserList.length === 0) {
			throw new Error(`User doen't exists`);
		}
		const kairoUserInfo = kairoUserList[0];
		return kairoUserInfo;
	}


	async promisifyUpload(req) {
		return new Promise((resolve, reject) => {
			const form = new multiparty.Form();
			form.parse(req, function (err, fields, files) {
				if (err) { new Error(`File upload failed.`) }
				return resolve([fields, files]);
			});
		});
	}

	bulkInsert = async (req) => {
		const [fields, files] = await this.promisifyUpload(req);
		const { file } = files;
		const { fieldName, path, size } = file[0];
		if (!path.includes('.xlsx')) {
			throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
		}
		console.log(`Uploaded content - 'FileName' : ${fieldName} , 'Size' : ${size} `);
		const timeStamp = Date.now();
		const outputFilePath = __dirname + '/' + `KAIRO_USER_${timeStamp}.xlsx`;
		const roleMappingPath = __dirname + '/' + `ROLE_MAPPING_${timeStamp}.xlsx`;
		const sheetData = await this.writeToUserSheet(path, outputFilePath);

		fs.unlinkSync(path)
		await this.migrateUserTableData(outputFilePath);
		fs.unlinkSync(outputFilePath);
		await this.writeToRoleMappingSheet(sheetData, roleMappingPath);
		await this.migrateRoleMappingTableData(roleMappingPath);
		fs.unlinkSync(roleMappingPath);
		return "Inserted Successfully.";
	}

	writeToRoleMappingSheet = async (sheetData, roleOutputMappingPath) => {
		const roleIdMapping = [], userMapping = [];

		const { KairoRole, KairoUser } = models;

		const userList = await KairoUser.find({ fields: ["id", "email"] });
		userList.forEach(e => {
			userMapping[e.email] = e.id;
		});

		let roleList = await KairoRole.find({ fields: ["name", "id"] });
		roleList.forEach(e => {
			roleIdMapping[e.name] = e.id;
		});

		const lableaderList = sheetData.filter(data => data.LL).map(data => data.LL);
		const pmoList = sheetData.filter(data => data.PMO).map(data => data.PMO);
		const clusterleaderList = sheetData.filter(data => data['Jr PMO/CL']).map(data => data['Jr PMO/CL']);

		sheetData.forEach(data => {
			const { Name, Company, Division, Project } = data;

			if (lableaderList.includes(Name)) {
				data['role_id'] = roleIdMapping['SOFTWARE_LL'];
			}

			if (clusterleaderList.includes(Name)) {
				data['role_id'] = roleIdMapping['SOFTWARE_CL'];
			}
			if (pmoList.includes(Name)) {
				data['role_id'] = roleIdMapping['SOFTWARE_MANAGER'];
			}

			if (pmoList.includes(Name) && Company.toUpperCase() == 'INFOVIEW' && Division.toUpperCase() == 'INFOVIEW') {
				switch (Project.toUpperCase()) {
					case "MANAGEMENT":
						data['role_id'] = roleIdMapping['SOFTWARE_MANAGER'];
						break;
					case "ADMIN":
						data['role_id'] = roleIdMapping['ADMIN_MANAGER'];
						break;
					case "SYSTEM ADMIN":
						data['role_id'] = roleIdMapping['ADMIN_SYSTEM'];
						break;
					case "HUMAN RESOURCE":
						data['role_id'] = roleIdMapping['HR_MANAGER'];
						break;
					case "ACCOUNTS":
						data['role_id'] = roleIdMapping['ACCOUNTS_MANAGER'];
						break;
					case "SOP":
						//data['role_id'] = roleIdMapping['SOFTWARE_CL'];
						break;
					default:
						break;
				}
			}
			if (!pmoList.includes(Name) && !lableaderList.includes(Name) && !clusterleaderList.includes(Name)) {
				data['role_id'] = roleIdMapping['SOFTWARE_MEMBER'];
			}

			if (!pmoList.includes(Name) && !lableaderList.includes(Name) && !clusterleaderList.includes(Name) &&
				Company.toUpperCase() == 'INFOVIEW' && Division.toUpperCase() == 'INFOVIEW') {
				switch (Project.toUpperCase()) {
					case "MANAGEMENT":
						data['role_id'] = roleIdMapping['SOFTWARE_MEMBER'];
						break;
					case "ADMIN":
						data['role_id'] = roleIdMapping['ADMIN_LEAD'];
						break;
					case "SYSTEM ADMIN":
						data['role_id'] = roleIdMapping['ADMIN_STAFF'];
						break;
					case "HUMAN RESOURCE":
						data['role_id'] = roleIdMapping['HR_LEAD'];
						break;
					case "ACCOUNTS":
						data['role_id'] = roleIdMapping['ACCOUNTS_LEAD'];
						break;
					case "SOP":
						//data['role_id'] = roleIdMapping['SOFTWARE_CL'];
						break;
					default:
						data['role_id'] = roleIdMapping['SOFTWARE_MEMBER'];
						break;
				}
			}
		});
		const dynamicTablePath = path_.join(__dirname, '../../resources/ROLE_MAPPING.xlsx');
		const workbook = new Excel.Workbook();

		await workbook.xlsx.readFile(dynamicTablePath);
		let count = 2;
		let worksheet = workbook.getWorksheet('ROLE_MAPPING');
		sheetData.forEach(data => {
			let { role_id } = data;
			const mailId = data['Email Id'];
			let row = worksheet.getRow(count);
			row.getCell(2).value = 'USER';
			row.getCell(3).value = userMapping[mailId];
			row.getCell(4).value = role_id;
			row.commit();
			count++;
		});
		await workbook.xlsx.writeFile(roleOutputMappingPath);
	}

	writeToUserSheet = async (path, outputFilePath) => {

		const workSheetList = await xlsxHandler(path, { getSheets: true });
		const sheets = workSheetList.map(sheet => sheet.name);
		const sheetName = sheets[0].toLowerCase().trim();

		const tabularData = await xlsxHandler(path, { sheet: sheets[0] });
		const dataToInsert = await this.extractDataFromArray(tabularData, sheetName.toLowerCase());
		const dynamicTablePath = path_.join(__dirname, '../../resources/KAIRO_USER.xlsx');
		const workbook = new Excel.Workbook();
		await workbook.xlsx.readFile(dynamicTablePath);
		let count = 2;
		let worksheet = workbook.getWorksheet('KAIRO_USER');
		dataToInsert.forEach(data => {
			const { No, Name, PMO, LL, Company, Division, Project, Gender, Location } = data;
			const empId = data['Emp ID'];
			const jrPMO_CL = data['Jr PMO/CL'];
			const emailId = data['Email Id'];
			const dateOfRelieving = data['Date Of Relieving'];
			const domainId = data['Domain Id'];
			let row = worksheet.getRow(count);
			if (!emailId) {
				console.error('Email Id not found - ', empId)
				return;
			}
			row.getCell(1).value = count - 1;
			row.getCell(2).value = domainId;
			row.getCell(3).value = emailId;
			row.getCell(4).value = emailId;
			row.getCell(9).value = Name;
			row.getCell(11).value = Gender.toUpperCase();
			row.getCell(12).value = true;
			row.getCell(13).value = true;
			row.getCell(19).value = dateOfRelieving;

			if (!empId) {
				return;
			}
			if (isNaN(empId) && empId.includes('-')) {
				let probation = empId.toString().split('-');
				row.getCell(6).value = true;
				row.getCell(7).value = probation[1];
				row.getCell(8).value = probation[0];
			} else {
				row.getCell(6).value = false;
				row.getCell(5).value = empId;
			}
			row.commit();
			count++;
		});
		await workbook.xlsx.writeFile(outputFilePath);
		return dataToInsert;
	}

	migrateUserTableData = async (tablePath) => {
		const workSheetList = await xlsxHandler(tablePath, { getSheets: true });
		const { kairo_user } = models;
		const sheets = workSheetList.map(sheet => sheet.name);
		const sheetName = sheets[0].toLowerCase().trim();

		console.log('Checking Initial Migration Data ------------> ', 'kairo_user');

		const tabularData = await xlsxHandler(tablePath, { sheet: sheets[0] });
		const dataToInsert = await this.extractDataFromArray(tabularData, sheetName.toLowerCase());

		try {
			console.table(dataToInsert);
			console.table('===================================================================');
			const insertedUserList = await kairo_user.create(dataToInsert);
			// To use below method comment after save operation in the 
			// this.kumss.afterBulkUserInsert(insertedUserList);
			return insertedUserList;
		} catch (err) {
			console.log(err);
			throw new Error(`Bulk insert failed.`);
		}

	}


	migrateRoleMappingTableData = async (tablePath) => {
		const workSheetList = await xlsxHandler(tablePath, { getSheets: true });
		const { RoleMapping } = models;
		const sheets = workSheetList.map(sheet => sheet.name);
		const sheetName = sheets[0].toLowerCase().trim();

		console.log('Checking Initial Migration Data ------------> ', 'RoleMapping');

		const tabularData = await xlsxHandler(tablePath, { sheet: sheets[0] });
		const dataToInsert = await this.extractDataFromArray(tabularData, sheetName.toLowerCase());

		try {
			console.table(dataToInsert);
			console.table('===================================================================');
			return await RoleMapping.create(dataToInsert);
		} catch (err) {
			console.log(err);
			throw new Error(`Bulk insert failed.`);
		}
	}

	extractDataFromArray = async (tabularData, modelName) => {
		const headerArray = tabularData[0];
		const jsonHeader = {}, jsonArray = [], modelFkeyMapping = {};

		let sheet_index = 0;

		for (let i = 0; i < headerArray.length; i++) {
			if (headerArray[i] === 'sheet_id') {
				sheet_index = i;
				continue;
			}
			const headPart = headerArray[i] ? headerArray[i].split('#') : [];
			jsonHeader[i] = headPart ? `${headPart[0]}` : [];
			if (headPart.length === 3) {
				modelFkeyMapping[i] = headPart[1].trim();
			}
		}

		for (let i = 1; i < tabularData.length; i++) {
			const jsonObject = {};
			tabularData[i].forEach((e, index) => {
				if (jsonHeader[index]) {
					const foreignTable = modelFkeyMapping[index];
					if (foreignTable) {
						jsonObject[jsonHeader[index]] = e ? collectiveTableData[foreignTable][e - 1].id : null;
					} else {
						jsonObject[jsonHeader[index]] = e;
					}
				}
			});
			jsonArray.push(jsonObject);
		}
		return jsonArray;
	}

	getUsers = async (req) => {
		const { KairoUser } = models;
		let { searchTxt, limit, page } = req.body;
		const skip = (page - 1) * limit;
		let condition = []
		if (searchTxt && searchTxt.includes('-')) {
			searchTxt = searchTxt.split('-')[1];
		}
		if (searchTxt) {
			condition.push({ 'empId': searchTxt }, { 'probationId': searchTxt });
		}
		const fields = ["id", "empId", "email", "isProbation", "probationPrefix", "probationId", "firstName", "lastName", "gender", "active", "username"];
		const kairoRoleMappingFields = ["id", "roleId", "principalId"];
		const kairoRoleFields = ["name"];
		const order = `empId ASC`;
		let kairoUserList = await KairoUser.find({
			limit, skip, order, where: { or: condition },
			include: [
				{
					relation: 'kairoRoleMapping', scope: { kairoRoleMappingFields, include: [{ relation: 'user', scope: { fields: kairoRoleFields } }] }
				}], fields
		});
		kairoUserList.forEach(data => {
			const { kairoRoleMapping, isProbation, probationPrefix, probationId } = data['__data'];
			if (isProbation) {
				data['__data']['empId'] = probationPrefix + '-' + probationId;
			}

			if (!kairoRoleMapping || kairoRoleMapping.length == 0) {
				data['role'] = '';
				return;
			}
			const { user } = kairoRoleMapping && kairoRoleMapping[0]['__data'];
			const { name } = user;
			data['role'] = name;

			delete data['__data'].kairoRoleMapping;
		});
		return kairoUserList;
	}

	exportUser = async (res) => {

		const { KairoUser } = models;
		const fields = ["id", "empId", "email", "isProbation", "probationPrefix", "probationId", "firstName", "lastName", "gender", "active", "username"];
		const kairoRoleMappingFields = ["id", "roleId", "principalId"];
		const kairoRoleFields = ["name"];
		let kairoUserList = await KairoUser.find({
			include: [
				{
					relation: 'kairoRoleMapping',
					scope: {
						kairoRoleMappingFields,
						include: [{ relation: 'user', scope: { fields: kairoRoleFields } }]
					}
				}], fields
		});
		kairoUserList.forEach(data => {
			const { kairoRoleMapping } = data['__data'];
			const { user } = kairoRoleMapping && kairoRoleMapping[0]['__data'];
			const { name } = user;
			data['role'] = name;
			delete data['__data'].kairoRoleMapping;
		});
		const dynamicTablePath = path_.join(__dirname, '../../resources/KAIRO_USER_EXPORT.xlsx');
		const workbook = new Excel.Workbook();
		await workbook.xlsx.readFile(dynamicTablePath);
		let count = 2;
		let worksheet = workbook.getWorksheet('KAIRO_USER_EXPORT');
		kairoUserList.forEach(data => {
			const { empId, email, role, username, isProbation, probationPrefix } = data;
			const { probationId, firstName, lastName, gender, active } = data;

			let row = worksheet.getRow(count);
			let emp_id = empId;
			if (isProbation) {
				emp_id = probationPrefix + '-' + probationId;
			}
			row.getCell(1).value = count - 1;
			row.getCell(2).value = emp_id;
			row.getCell(3).value = username;
			row.getCell(4).value = email;
			row.getCell(5).value = firstName;
			row.getCell(6).value = lastName;
			row.getCell(7).value = gender;
			row.getCell(8).value = role;
			row.getCell(9).value = active ? "ACTIVE" : "INACTIVE"
			row.commit();
			count++;
		});

		res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		res.setHeader('Content-Disposition', 'attachment; filename=' + 'USER_EXPORT.xlsx');
		return workbook.xlsx.write(res)
			.then(function () {
				res.status(200).end();
			});
	}


	bulkInsertLeaveBalance = async (req) => {
		const [field, files] = await this.promisifyUpload(req);
		const { file } = files;
		const { fieldName, path, size } = file[0];
		if (!path.includes('.xlsx')) {
			throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
		}
		const workSheetList = await xlsxHandler(path, { getSheets: true });
		const sheets = workSheetList.map(sheet => sheet.name);
		const sheetName = sheets[0].toLowerCase().trim();
		let sheetData = {}, userInfo = {}, insertList = [];
		const tabularData = await xlsxHandler(path, { sheet: sheets[0] });
		const dataToInsert = await this.extractDataFromArray(tabularData, sheetName.toLowerCase());
		dataToInsert.forEach(e => {
			sheetData[e['Employee Name']] = e;
		});
		const { KairoUser } = models;
		const idsList = Object.keys(sheetData);
		const fields = ["id", "empId", , "isProbation", "probationPrefix", "probationId", "leaveAlloted", "leaveApplied", "leaveUtilized"];
		const userData = await KairoUser.find({ where: { firstName: { inq: idsList } } }, fields);
		userData.forEach(e => {
			const { isProbation, probationPrefix, probationId, empId } = e;
			userInfo[(isProbation ? probationPrefix + '-' + probationId : empId)] = e;
		})
		dataToInsert.forEach(data => {
			const { DOJ, DOR, CL, SL, EL } = data;
			const empId = data['Employee ID'];
			let empData = userInfo[empId];
			if (empData) {
				let { leaveUtilized, leaveApplied, leaveAlloted } = empData;
				leaveUtilized['EARNED_LEAVE'] = leaveAlloted.EARNED_LEAVE - EL;
				leaveUtilized['SICK_LEAVE'] = leaveAlloted.SICK_LEAVE - SL;
				leaveUtilized['CASUAL_LEAVE'] = leaveAlloted.CASUAL_LEAVE - CL;

				leaveApplied['EARNED_LEAVE'] = leaveUtilized['EARNED_LEAVE'];
				leaveApplied['SICK_LEAVE'] = leaveUtilized['SICK_LEAVE'];
				leaveApplied['CASUAL_LEAVE'] = leaveUtilized['CASUAL_LEAVE'];

				empData['joiningDate'] = isNaN(new Date(DOJ)) ? null : new Date(DOJ);
				empData['relievingDate'] = isNaN(new Date(DOR)) ? null : new Date(DOR);
				insertList.push(empData);
			}
		});

		for (let data of insertList) {
			const { id, leaveApplied, leaveUtilized, joiningDate, relievingDate } = data;
			await KairoUser.updateAll({ id }, { leaveUtilized, leaveApplied, joiningDate, relievingDate });
		}

		fs.unlinkSync(path);
		return insertList;
	}

	leaveMasterInfo = async (kairo_user_id) => {
		const { KairoUserMasterSettings, LeaveAllotmentSettings } = models;

		const myMasterSettinigs = await KairoUserMasterSettings.find({
			where: { kairo_user_id },
			fields: ["leaveRequestAllotmentSettings"]
		})

	}

	addUser = async (req) => {
		const { kairo_user } = models;
		return await kairo_user.create(req.body);
	}

	myBasicDetails = async (id) => {
		const { KairoUser } = models;
		const userInfo = await KairoUser.find({
			where: { id },
			fields: ["firstName", "username", "gender", "email", "empId", "probationId"]
		});
		return userInfo[0];
	}

	forgotPassword = async (paramEmail, username, mailService) => {
		const { KairoUser } = models;
		let whereCondition;
		if (paramEmail) {
			whereCondition = { email: paramEmail };
		} else {
			whereCondition = { username };
		}
		const users = await KairoUser.find({
			where: whereCondition,
			fields: ["email", "id", "firstName", "email"]
		});
		let user = users[0];
		const { id, firstName, email } = user;
		if (users && users.length === 0) {
			throw new Error(`User not found - contact admin team`);
		}
		let otp = await this.generateOTP();
		mailService.sendOtpMail(id, email, firstName, otp);
		// await KairoUser.upsertWithWhere({ id }, {otp,'otp_created_at': moment().format() }); 
		return user;
	}

	async generateOTP() {
		return Math.floor(100000 + Math.random() * 900000);
	}

	resetPassword = async (email, username, verifyOtp, newPassword) => {
		const { KairoUser } = models;
		let whereCondition;
		if (email) {
			whereCondition = { email };
		} else {
			whereCondition = { username };
		}
		const users = await KairoUser.find({
			where: whereCondition,
			fields: ["email", "otp", "id"]
		});
		if (users && users.length === 0) {
			throw new Error(`User not found - contact admin team`);
		}
		let user = users[0];

		// const created = moment().format();
		// const minutesDiff = moment.duration(moment(created).diff(user.otp_created_at)).asMinutes();
		// if( minutesDiff > 5 ){
		// 	throw new Error(`Invalid OTP`);
		// }		
		if (user.otp === verifyOtp) {
			let hashedPassword = await this.hasPassword(newPassword);
			await KairoUser.upsertWithWhere({ id: user.id }, { password: hashedPassword, otp: null, otp_created_at: null });
			return user;
		} else {
			throw new Error(`Invalid OTP`);
		}

	}

	async hasPassword(plain) {
		const salt = bcrypt.genSaltSync(10);
		return bcrypt.hashSync(plain, salt);
	}
}

