import moment from 'moment';
import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import KEY from 'src/app/common/constants/storeKeys';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationStore } from 'src/app/common/reduxFlow/root.state';
import { NotificationFetch, NotificationUpdate } from 'src/app/common/reduxFlow/actions/notification.action';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  notificationList: Array<any>;
  notificationCount: number;
  isApprovalVisible: boolean = false;

  leaveDate: Date;
  errorhours: number;
  notificationId: number;
  isFullDay: boolean;
  isHalfDay: boolean;

  data = [
    'Racing car sprays burning fuel into crowd.',
    'Japanese princess to wed commoner.',
    'Australian walks 100km after outback crash.',
    'Man charged over missing wedding girl.',
    'Los Angeles battles huge wildfires.'
  ];


  constructor(private notifyStore: Store<NotificationStore>, private router: Router) {
    this.notificationSusbcription()
  }

  ngOnInit(): void {
  }


  notificationSusbcription = () => {
    this.notifyStore.select(KEY.NOTIFICATION_PAGE_STORE).subscribe(result => {
      const { notificationList } = result;
      this.notificationCount = notificationList && notificationList.length;
      this.notificationList = notificationList;
    });
  }


  markAllRead() {
    const idsList = this.notificationList.map(e => e.id)
    this.notifyStore.dispatch(new NotificationUpdate(idsList));
  }
  onView(item): void {
    this.notifyStore.dispatch(new NotificationUpdate([item.id]));
    const moduleType = item.notificationType.moduleName;
    let { type, noOfDays, fromDate, toDate, actionStatus, status, insufficientHours, flawDate } = item.messageValues;
    let param = { type, noOfDays, fromDate, toDate, status, insufficientHours, flawDate, selectActionStatus: actionStatus };
    switch (moduleType) {
      case "REDMINE_INSUFFICIENT_LOGTIME":
        this.router.navigate(['/smart/redmine-notlogged'], { queryParams: param });
        break;
      case "LEAVE_REQUEST_GIVEN_TO_ME":
        this.router.navigate([`/smart/approve/leave`], { queryParams: param });
        break;
      case "MY_APPROVED_REQUEST":
      case "MY_REJECTED_REQUEST":
      case "MY_STAGE_APPROVAL":
        this.router.navigate(['/smart/request/leave'], { queryParams: param });
        break;

    }
  }
  onLeaveViewClose(event): void {
    if (event) {
      this.isApprovalVisible = false;
    } else {
      this.notifyStore.dispatch(new NotificationFetch(null));
      this.isApprovalVisible = false;
    }
  }
  getAvatarPrefix(moduleName: string): string {
    switch (moduleName) {
      case "REDMINE_INSUFFICIENT_LOGTIME":
        return "IN";
      case "LEAVE_REQUEST_GIVEN_TO_ME":
        return "LR";
      case "MY_REJECTED_REQUEST":
        return "RJ";
      case "MY_APPROVED_REQUEST":
        return "AP";
      case "MY_STAGE_APPROVAL":
        return "AP";
      case "REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY":
        return "IN";
    }
  }
  formatDate(inDate): string {
    return moment(inDate).format('DD-MM-YYYY');
  }

}
