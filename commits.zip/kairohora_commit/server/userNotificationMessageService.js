'use strict';
const { models } = require('../../server/server');
const MailService = require('./mailService');
const NotificationMasterSettingService = require('./notificationMasterSettingService')

const DateUtils = require('../utils/dateUtils');

const NOTIFICATION_META = require('../metadata/notificationMeta.json');
const APPROVAL_FLOW_META = require('../metadata/approvalFlowMeta.json');

const { NOTIFICATION_MODULE } = NOTIFICATION_META;
const { LEAVE, LOGTIME, PROJECTION, ACCOUNT, NOON_TYPE } = NOTIFICATION_MODULE;
const { APPROVAL_FLOW_ACTION_STATUS } = APPROVAL_FLOW_META;



module.exports = class UserNotificationMessageService {

    constructor() {
        this.du = new DateUtils();
        this.mailService = new MailService();
        this.notificationMasterSettingService = new NotificationMasterSettingService();
    }

    sendNotification = async (ctx) => {
        const { instance, isNewInstance } = ctx;
        if (isNewInstance) {
            ctx.instance = instance;
        }
        const { actionStatus, id } = instance ? instance : {};
        if (!actionStatus) return;

        if (actionStatus == APPROVAL_FLOW_ACTION_STATUS.WAITING_FOR_PREVIOUS_APPROVERS
            || actionStatus == APPROVAL_FLOW_ACTION_STATUS.WITHDRAWN_BY_USER
            || actionStatus == APPROVAL_FLOW_ACTION_STATUS.REJECTED_BY_OTHERS) {
            return;
        }
        await this.createNotification(actionStatus, { id });
    }


    createNotification = async (notificationModuleName, options) => {

        switch (notificationModuleName) {

            case LOGTIME.REDMINE_INSUFFICIENT_LOGTIME:
                await this.createRedmineInsufficientLogTimeNotification(LOGTIME.REDMINE_INSUFFICIENT_LOGTIME, options.redmineNotLoggedList);
                break;
            case LOGTIME.REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY:
                await this.createRedmineInsufficientLogTimeNotificationToHierarchy(LOGTIME.REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY, options.redmineNotLoggedList);
                break;
            case LOGTIME.BIOMETRIC_INSUFFICIENT_LOGTIME:
                //TODO need to implement for biometric
                break;
            case APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL:
                await this.createLeaveNotification(LEAVE.REQUEST_GIVEN_TO_ME, options.id);
                break;
            case APPROVAL_FLOW_ACTION_STATUS.REJECTED_BY_ME:
                await this.createLeaveNotification(LEAVE.MY_REJECTED_REQUEST, options.id);
                break;
            case APPROVAL_FLOW_ACTION_STATUS.APPROVED:
                await this.createLeaveNotification(LEAVE.MY_APPROVED_REQUEST, options.id);
                break;
            case LEAVE.MY_STAGE_APPROVAL:
                await this.createLeaveNotification(LEAVE.MY_STAGE_APPROVAL, options.id);
                break;
            case ACCOUNT.PASSWORD_CHANGE:
                //TODO need to implement for password change
                break;
            case ACCOUNT.RESET_PASSWORD:
                //TODO need to implement for reset password
                break;
            case ACCOUNT.REGISTRATION:
                //TODO need to implement for regisration
                break;
            default:
                break;
        }

    }

    createRedmineInsufficientLogTimeNotification = async (notificationModuleName, redmineNotLoggedList) => {
        const { UserNotificationMessage } = models;
        const { mailTemplate, webTemplate, id } = await this.notificationMasterSettingService.getModule(notificationModuleName);

        const userIdList = redmineNotLoggedList.map(e => e.kairo_user_id);
        let userSubscribedModules = await this.getUserSubscribedModules(notificationModuleName, userIdList);
        let insertList = redmineNotLoggedList.map(e => {
            const { kairo_user_id } = e;
            let subcribeMap = userSubscribedModules[kairo_user_id];
            let dataMap = { recipient_id: kairo_user_id, messageValues: e, notification_type: id };
            const mailMessage = Buffer.from(this.replaceArray(mailTemplate, e));
            const webMessage = Buffer.from(this.replaceArray(webTemplate, e));
            return Object.assign(dataMap, subcribeMap, { mailMessage }, { webMessage });
        });

        try {
            const resultList = await UserNotificationMessage.create(insertList);
            const notificationIdList = resultList.map(e => e.id);
            this.mailService.sendMail(notificationIdList);
        } catch (e) {
            console.log(e)
        }

    }

    createRedmineInsufficientLogTimeNotificationToHierarchy = async (notificationModuleName, redmineNotLoggedList) => {
        const { mailTemplate, webTemplate, id } = await this.notificationMasterSettingService.getModule(notificationModuleName);
        const userIdList = redmineNotLoggedList.map(e => e.kairo_user_id);
        let reportToDataMap = await this.getReportToId(userIdList);
        const reportToIdList = [];
        userIdList.forEach(
            e => {
                if (reportToDataMap && reportToDataMap[e] && reportToDataMap[e].report_to) {
                    reportToIdList.push(reportToDataMap[e].report_to)
                }
            });
        let userSubscribedModules = await this.getUserSubscribedModules(notificationModuleName, reportToIdList);
        let insertList = redmineNotLoggedList.map(e => {
            const { kairo_user_id } = e;
            let reportToData = reportToDataMap[kairo_user_id];
            if (!reportToData || reportToData === null) {
                return
            }
            const { report_to, firstName, email } = reportToData;
            let subcribeMap = userSubscribedModules[report_to];
            e.recipientName = firstName;
            e.email = email;
            let dataMap = { recipient_id: report_to, messageValues: e, notification_type: id };
            const mailMessage = Buffer.from(this.replaceArray(mailTemplate, e));
            const webMessage = Buffer.from(this.replaceArray(webTemplate, e));
            return Object.assign(dataMap, subcribeMap, { mailMessage }, { webMessage });
        });
        await this.insertNotificationData(insertList);
    }

    insertNotificationData = async (insertList) => {

        try {
            const { UserNotificationMessage } = await models;
            const resultList = await UserNotificationMessage.create(insertList);
            const notificationIdList = [];
            resultList.forEach(e => notificationIdList.push(e.id));
            this.mailService.sendMail(notificationIdList);
        } catch (e) {
            console.log(e)
        }

    }

    createLeaveNotification = async (notificationModuleName, flowId) => {
        const { UserNotificationMessage, LeaveRequestApprovalFlow } = models;

        const where = { id: flowId };
        const fields = PROJECTION.LEAVE_REQUEST_FIELDS;
        const include = [{ relation: "applicant", scope: { fields } }, { relation: "leaveRequest", scope: { fields } }, { relation: "currentApprover", scope: { fields } }];

        const filter = { where, include, fields };
        const leaveRequestApprovalFlow = await LeaveRequestApprovalFlow.findOne(filter);
        let insertList = await this.formLeaveRequestInsertData(notificationModuleName, leaveRequestApprovalFlow.toJSON());

        try {
            const resultList = await UserNotificationMessage.create(insertList);
            const notificationIdList = resultList.map(e => e.id);
            this.mailService.sendMail(notificationIdList);
        } catch (e) {
            console.log(e)
        }

        if (LEAVE.MY_APPROVED_REQUEST == notificationModuleName) {
            const { applicant_id, isFinal, id } = leaveRequestApprovalFlow;
            let userSubscribedMap = await this.getUserSubscribedModules(notificationModuleName, applicant_id);
            const { isWebSubscribed, isMailSubscribed, isMobileSubscribed, isServiceWorkerSubscribed } = userSubscribedMap[applicant_id];
            if ((isWebSubscribed || isMailSubscribed || isMobileSubscribed || isServiceWorkerSubscribed) && !isFinal) {
                this.createNotification(LEAVE.MY_STAGE_APPROVAL, { id });
            }
        }

    }

    formLeaveRequestInsertData = async (notificationModuleName, params) => {

        const { applicant, leaveRequest, currentApprover } = params;
        let recipient_id;

        switch (notificationModuleName) {
            case LEAVE.REQUEST_GIVEN_TO_ME:
                params.email = currentApprover.email;
                recipient_id = params.current_approver_id;
                break;
            case LEAVE.MY_APPROVED_REQUEST:
            case LEAVE.MY_REJECTED_REQUEST:
            case LEAVE.MY_STAGE_APPROVAL:
                params.email = applicant.email;
                recipient_id = params.applicant_id;
                break;
            default:
                break;
        }

        params.applicantName = applicant.firstName;
        params.approverName = currentApprover.firstName;
        delete leaveRequest.id;
        params = Object.assign(params, leaveRequest);
        delete params.leaveRequest;
        delete params.applicant;
        delete params.currentApprover;

        let userSubscribedMap = await this.getUserSubscribedModules(notificationModuleName, recipient_id);
        let subcribeMap = userSubscribedMap[recipient_id];

        const { mailTemplate, webTemplate, id } = await this.notificationMasterSettingService.getModule(notificationModuleName);

        let insertList = [];
        let dataMap = { recipient_id, messageValues: params, notification_type: id };
        const mailMessage = Buffer.from(this.replaceArray(mailTemplate, params));
        const webMessage = Buffer.from(this.replaceArray(webTemplate, params));
        insertList.push(Object.assign(dataMap, subcribeMap, { mailMessage }, { webMessage }));

        return insertList;

    }

    replaceArray = (template, dataList) => {
        template = template.toString('utf8');
        for (let [key, value] of Object.entries(dataList)) {
            if (!value) {
                value = '';
            }
            if (this.du.isDate(value)) {
                value = this.du.getSqlFormatDatedString(value);
            }
            if (key == "type") {
                value = value.replace("_", " ");
            }
            if (key == "startNoon" || key == "endNoon") {
                switch (value) {
                    case NOON_TYPE.FORENOON.KEY:
                        value = NOON_TYPE.FORENOON.VALUE;
                        break;
                    case NOON_TYPE.AFTERNOON.KEY:
                        value = NOON_TYPE.AFTERNOON.VALUE;
                        break;
                }
            }
            const pattern = new RegExp("\\[" + key + "]", "g");
            template = template.replace(pattern, value);

            if (key == "noOfDays" && value <= 1) {
                template = template.replace("Days", "Day");
            }

        }
        return template;
    }

    getUserSubscribedModules = async (notificationModuleName, userIdList) => {

        if (!Array.isArray(userIdList)) {
            userIdList = [userIdList];
        }

        const { UserNotificationSetting } = models;
        const notificationMasterSetting = await this.notificationMasterSettingService.getModule(notificationModuleName);

        const fields = ["user_id", 'mobileNotificationModules', 'mailNotificationModules', 'webNotificationModules', 'serviceWorkerNotificationModules']
        let userNotificationSettingMap = {}, dataMap = {};
        const where = { user_id: { inq: userIdList } };
        const filter = { where, fields };
        const userNotificationSetting = await UserNotificationSetting.find(filter);
        userNotificationSetting.forEach(e => userNotificationSettingMap[e.user_id] = e);

        const { isMobileChangeAllowed, isWebChangeAllowed, isMailChangeAllowed, isServiceWorkerChangeAllowed } = notificationMasterSetting;
        const { isMobilePush, isWebPush, isMailPush, isServicePush, id } = notificationMasterSetting;

        userIdList.forEach(e => {

            let subcribeMap = { isMobileSubscribed: false, isServiceWorkerSubscribed: false };

            //setting web Subscribed
            if (!isWebChangeAllowed && isWebPush) {
                subcribeMap.isWebSubscribed = true;
            } else if (isWebChangeAllowed && isWebPush) {
                const { webNotificationModules } = userNotificationSettingMap[e] ? userNotificationSettingMap[e] : {};
                subcribeMap.isWebSubscribed = webNotificationModules && webNotificationModules.includes(id);
            }

            //setting Mail Subscribed
            if (!isMailChangeAllowed && isMailPush) {
                subcribeMap.isMailSubscribed = true;
            } else if (isMailChangeAllowed && isMailPush) {
                const { mailNotificationModules } = userNotificationSettingMap[e] ? userNotificationSettingMap[e] : {};
                subcribeMap.isMailSubscribed = mailNotificationModules && mailNotificationModules.includes(id);
            }
            dataMap[e] = subcribeMap;
        });
        return dataMap;
    }

    getReportToId = async (userIdList) => {
        const { ProjectAllocation } = models;
        const where = { employee_id: { inq: userIdList } };
        const fields = NOTIFICATION_MODULE.PROJECTION.HIERARCHY_INFO_FIELDS;
        const include = { relation: "reportTo", scope: { fields } };
        const filter = { where, fields, include };
        let UserHierarchyList = await ProjectAllocation.find(filter);
        let dataMap = {};
        UserHierarchyList.map(e => {
            e = e.toJSON();
            if (!e.report_to || !e.reportTo) {
                return null;
            }
            e.firstName = e.reportTo.firstName;
            e.email = e.reportTo.email;
            delete e.reportTo;
            dataMap[e.employee_id] = e;
        });
        return dataMap;
    }

    async getUnreadNotification(userId) {
        const { UserNotificationMessage } = models;
        const where = { recipient_id: userId, isWebRead: false, isWebSubscribed: true };
        const fields = ["id", "recipient_id", "isWebRead", "isWebSubscribed", "messageValues", "webMessage", "moduleName", "notification_type"]
        const include = { relation: "notificationType", scope: { fields } };
        const filter = { where, fields, include };

        let userNotificationMessageList = await UserNotificationMessage.find(filter);
        let returnList = userNotificationMessageList.map(e => {
            const message = e.webMessage.toString('utf8');
            delete e.webMessage;
            e.message = message;
            return Object.assign(e, message);
        });
        return returnList;
    }

}