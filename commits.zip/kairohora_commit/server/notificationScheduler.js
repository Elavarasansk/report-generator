'use strict';
const schedule = require('node-schedule');
const { models } = require('../../../server/server');
const { CRON } = require('../../metadata/schedulerMeta.json');
const UserNotificationMessageService = require('../../services/userNotificationMessageService');
const NOTIFICATION_META = require('../../metadata/notificationMeta.json');
const { NOTIFICATION_MODULE } = NOTIFICATION_META;

module.exports = class NotificationScheduler {

    constructor(props) {
        this.userNotificationMessageService = new UserNotificationMessageService();
        try {
            schedule.scheduleJob(CRON.EVERYDAY_4AM, this.sendRedmineInsufficientLogTimeNotification);
        } catch (err) {
            console.log(err);
        }
    }

    sendRedmineInsufficientLogTimeNotification = async () => {
        const { RedmineNotlogged } = models;
        const fields = NOTIFICATION_MODULE.PROJECTION.INSUFFICIENT_LOGTIME_FIELDS;
        const where = { isLeaveApplied: false, isLogged: false };
        const include = { relation: "applicant", scope: { fields } };
        const filter = { where, fields, include };
        const redmineNotlogged = await RedmineNotlogged.find(filter);
        let redmineNotLoggedList = redmineNotlogged.map(e => {
            e = e.toJSON();
            e.firstName = e.applicant.firstName;
            e.email = e.applicant.email;
            delete e.applicant;
            return e;
        });
        this.userNotificationMessageService.createNotification(NOTIFICATION_MODULE.LOGTIME.REDMINE_INSUFFICIENT_LOGTIME, { redmineNotLoggedList });
        this.userNotificationMessageService.createNotification(NOTIFICATION_MODULE.LOGTIME.REDMINE_INSUFFICIENT_LOGTIME_HIERARCHY, { redmineNotLoggedList });

    }



}