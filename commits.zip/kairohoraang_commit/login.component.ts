import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';

import KEY from '../../../common/constants/storeKeys';
import { SMART } from 'src/app/common/constants/restapi.config';
import { RootStore } from '../../../common/reduxFlow/root.state';

import { Login, BootLoginModal, OpenForgotPasswordModal, ForgotPasswordOtpGenerated } from '../../../common/reduxFlow/actions/auth.action';
import { UserReqDto } from '../../../common/reduxFlow/interfaces/req/auth.ireq';
import AuthService from '../../../common/reduxFlow/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isLoading: boolean = false;
  loadingTitle: string;
  openModal: boolean = false;
  forgotPassword: boolean = false;
  openForgotPasswordModal: boolean = false;
  validateForm!: FormGroup;

  constructor(private fb: FormBuilder, private store: Store<RootStore>, private router: Router, private authService: AuthService) {
    store.select(KEY.ROOT_REDUCER).subscribe(result => {
      const { isLoading, loadingTitle } = result[KEY.OVERALL_PAGE_STORE];
      this.isLoading = isLoading;
      this.loadingTitle = loadingTitle;

      const { openLoginModal, openForgotPasswordModal } = result[KEY.AUTH_PAGE_STORE];
      const currModalState = this.openModal;

      this.openModal = openLoginModal;
      this.openForgotPasswordModal = openForgotPasswordModal;
    });
  }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      email: [null, [Validators.required]],
      password: [null, [Validators.required]],
      remember: [true],
    });
  }

  afterSuccessFullLogin() {
    const { accessToken } = this.authService.routeGaurdCheck();
    if (accessToken) {
      this.router.navigate([`${SMART.PLAIN_ROUTE}/dashboard`]);
    }
  }

  validateEmail(email): boolean {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  submitForm(): void {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }

    const { store, validateForm } = this;
    const { email, password } = validateForm.controls;

    const isEmail = this.validateEmail(email.value);

    const loginParam: UserReqDto = {
      [isEmail ? "email" : "username"]: email.value,
      password: password.value
    }
    if (validateForm.status === `VALID`) {
      store.dispatch(new Login(loginParam));
    }
  }

  handleCancel(): void {
    this.store.dispatch(new BootLoginModal(false));
  }

  onForgotPasswordClick(): void {
    // this.router.navigate([`/forgotPassword`]);
    // this.forgotPassword = true;
    this.store.dispatch(new OpenForgotPasswordModal(true));
    this.store.dispatch(new ForgotPasswordOtpGenerated(false));
  }

  onBackClick(): void {
    // this.forgotPassword = false;
    this.store.dispatch(new OpenForgotPasswordModal(false));
  }

}

