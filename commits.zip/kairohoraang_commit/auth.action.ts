import { Action } from '@ngrx/store';
import { HttpErrorResponse } from '@angular/common/http';
import { UserReqDto, UserRegisterReqDto, PasswordChangeReqDto, RequestOtpDto, VerifyOtpDto } from '../interfaces/req/auth.ireq';
import { LoginRespDto, RegistrationRespDto, OverallMacRespDto, BasicUserInfoResDto } from '../interfaces/res/auth.ires';
import { LOGIN_ACT_TYPES, REGISTRATION_ACT_TYPES, ACCESS_CONTROL_ACT_TYPES, CHANGE_PASSWORD_ACT_TYPES, BASIC_INFO_ACT_TYPES, FORGOT_PASSWORD_ACT_TYPES } from '../actionTypes/auth.actionType';


class BootLoginModal implements Action {
    readonly type = LOGIN_ACT_TYPES.INVOKE_LOGIN_MODAL;
    constructor(public payload: any) { }
}

class BootRegistrationModal implements Action {
    readonly type = REGISTRATION_ACT_TYPES.INVOKE_REGISTRATION_MODAL;
    constructor(public payload: any) { }
}

class Login implements Action {
    readonly type = LOGIN_ACT_TYPES.LOGIN;
    constructor(public payload: UserReqDto) { }
}

class LoginSuccess implements Action {
    readonly type = LOGIN_ACT_TYPES.LOGIN_SUCCESS;
    constructor(public payload: LoginRespDto) { }
}

class CheckLogin implements Action {
    readonly type = LOGIN_ACT_TYPES.CHECK_LOGIN;
    constructor(public payload: LoginRespDto) { }
}

class Logout implements Action {
    readonly type = LOGIN_ACT_TYPES.LOGOUT;
    constructor(public payload: any) { }
}

class LogoutConfirmed implements Action {
    readonly type = LOGIN_ACT_TYPES.LOGOUT_CONFIRMED;
    constructor(public payload: any) { }
}

class Registration implements Action {
    readonly type = REGISTRATION_ACT_TYPES.REGISTRATION;
    constructor(public payload: UserRegisterReqDto) { }
}

class RegistrationSuccess implements Action {
    readonly type = REGISTRATION_ACT_TYPES.REGISTRATION_SUCCESS;
    constructor(public payload: RegistrationRespDto) { }
}

class AclFetch implements Action {
    readonly type = ACCESS_CONTROL_ACT_TYPES.ACL_FETCH;
    constructor(public payload: null) { }
}

class AclFetchSuccess implements Action {
    readonly type = ACCESS_CONTROL_ACT_TYPES.ACL_FETCH_SUCCESS;
    constructor(public payload: OverallMacRespDto) { }
}

class BootPasswordChangeModal implements Action {
    readonly type = CHANGE_PASSWORD_ACT_TYPES.PASSWORD_CHANGE_MODAL;
    constructor(public payload: boolean) { }
}

class PasswordChange implements Action {
    readonly type = CHANGE_PASSWORD_ACT_TYPES.PASSWORD_CHANGE;
    constructor(public payload: PasswordChangeReqDto) { }
}

class PasswordChangeSuccess implements Action {
    readonly type = CHANGE_PASSWORD_ACT_TYPES.PASSWORD_CHANGE_SUCCESS;
    constructor(public payload: null) { }
}

class FetchMyBasicInfo implements Action {
    readonly type = BASIC_INFO_ACT_TYPES.FETCH;
    constructor(public payload: OnErrorEventHandlerNonNull) { }
}

class FetchMyBasicInfoSuccess implements Action {
    readonly type = BASIC_INFO_ACT_TYPES.FETCH_SUCCESS;
    constructor(public payload: BasicUserInfoResDto) { }
}

class RequestOtpMail implements Action {
    readonly type = FORGOT_PASSWORD_ACT_TYPES.OTP_GENERATION;
    constructor(public payload: RequestOtpDto) { }
}

class ChangePassword implements Action {
    readonly type = FORGOT_PASSWORD_ACT_TYPES.OTP_VERIFICATION;
    constructor(public payload: VerifyOtpDto) { }
}

class ForgotPasswordOtpGenerated implements Action {
    readonly type = FORGOT_PASSWORD_ACT_TYPES.FORGOT_PASSWORD_OTP_GENERATED;
    constructor(public payload: boolean) { }
}

class OpenForgotPasswordModal implements Action {
    readonly type = FORGOT_PASSWORD_ACT_TYPES.OPEN_FORGOT_PASSWORD_MODAL;
    constructor(public payload: boolean) { }
}

export {
    CheckLogin,
    Registration,
    RegistrationSuccess,
    BootRegistrationModal,
    Login,
    LoginSuccess,
    BootLoginModal,
    Logout,
    LogoutConfirmed,
    AclFetch,
    AclFetchSuccess,
    BootPasswordChangeModal,
    PasswordChange,
    PasswordChangeSuccess,
    FetchMyBasicInfo,
    FetchMyBasicInfoSuccess,
    ChangePassword,
    RequestOtpMail,
    ForgotPasswordOtpGenerated,
    OpenForgotPasswordModal
}

export type LoginActions =
    | CheckLogin
    | Registration
    | RegistrationSuccess
    | BootRegistrationModal
    | Login
    | LoginSuccess
    | BootLoginModal
    | Logout
    | LogoutConfirmed
    | AclFetch
    | AclFetchSuccess
    | BootPasswordChangeModal
    | PasswordChange
    | PasswordChangeSuccess
    | FetchMyBasicInfo
    | FetchMyBasicInfoSuccess
    | ChangePassword
    | RequestOtpMail
    | ForgotPasswordOtpGenerated
    | OpenForgotPasswordModal
