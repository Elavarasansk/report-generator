import { Injectable } from '@angular/core';
import { Actions, Effect, ofType, createEffect } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { Store, Action } from '@ngrx/store';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { SMART } from 'src/app/common/constants/restapi.config';

import { UserReqDto, UserRegisterReqDto, PasswordChangeReqDto, RequestOtpDto, VerifyOtpDto } from '../interfaces/req/auth.ireq';
import AuthService from '../services/auth.service';
import * as AUTH_ACTIONS from '../actions/auth.action';
import * as OVERALL_ACTIONS from '../actions/overall.action';

import { SUCCESS_MESSAGES, ERROR_MESSAGES } from '../../constants/messages';
import { LOGIN_ACT_TYPES, REGISTRATION_ACT_TYPES, ACCESS_CONTROL_ACT_TYPES, CHANGE_PASSWORD_ACT_TYPES } from '../actionTypes/auth.actionType';
import { BASIC_INFO_ACT_TYPES, FORGOT_PASSWORD_ACT_TYPES } from '../actionTypes/auth.actionType';

@Injectable()
export default class AuthEffect {

    constructor(private actions$: Actions, private store: Store,
        private authService: AuthService, private router: Router) { }

    @Effect()
    loginUser$: Observable<Action> = this.actions$
        .pipe(
            ofType(LOGIN_ACT_TYPES.LOGIN), map((action: AUTH_ACTIONS.Login) => action.payload),
            mergeMap((user: UserReqDto) => this.authService.loginUser(user)
                .pipe(
                    map(response => {
                        const { email, username } = user;
                        const { userId, id } = response;
                        const loginResponse = {
                            email,
                            username,
                            userId: userId,
                            accessToken: id
                        }
                        this.authService.persistCookie(loginResponse);
                        this.store.dispatch(new AUTH_ACTIONS.LoginSuccess(loginResponse));
                        this.store.dispatch(new AUTH_ACTIONS.AclFetch(null));
                        this.router.navigate([`${SMART.PLAIN_ROUTE}/dashboard`]);
                        return new OVERALL_ACTIONS.SetSuccess({ successTitle: SUCCESS_MESSAGES.LOGIN, successMsg: `User - ${email ? email : username}` });
                    }),
                    catchError(error => of(new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.LOGIN, errorResponse: error, errorMsg: error.message })))
                )
            ));

    @Effect()
    registerUser$: Observable<Action> = this.actions$
        .pipe(
            ofType(REGISTRATION_ACT_TYPES.REGISTRATION), map((action: AUTH_ACTIONS.Registration) => action.payload),
            mergeMap((user: UserRegisterReqDto) => this.authService.registerUser(user)

                .pipe(

                    map(response => {
                        this.store.dispatch(new OVERALL_ACTIONS.SetSuccess({ successTitle: SUCCESS_MESSAGES.REGISTRATION, successMsg: `User - ${response.email}` }));
                        return new AUTH_ACTIONS.RegistrationSuccess(response);
                    }),
                    catchError(error => of(new OVERALL_ACTIONS.SetError({
                        errorTitle:
                            ERROR_MESSAGES.REGISTRATION, errorResponse: error, errorMsg: error.message
                    })))
                )
            ));

    @Effect()
    passwordChange$: Observable<Action> = this.actions$
        .pipe(
            ofType(CHANGE_PASSWORD_ACT_TYPES.PASSWORD_CHANGE), map((action: AUTH_ACTIONS.PasswordChange) => action.payload),
            mergeMap((param: PasswordChangeReqDto) => this.authService.changePassword(param)
                .pipe(
                    map(e => {
                        new AUTH_ACTIONS.BootPasswordChangeModal(false);
                        return new AUTH_ACTIONS.Logout(null);
                    }),
                    catchError(error => of(new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.LOGIN, errorResponse: error, errorMsg: error.message })))
                )
            ));

    @Effect()
    logoutUser$: Observable<Action> = this.actions$
        .pipe(
            ofType(LOGIN_ACT_TYPES.LOGOUT), map((action: AUTH_ACTIONS.Logout) => action.payload),
            mergeMap(() => this.authService.logout()
                .pipe(
                    map(() => {
                        this.authService.persistCookie(null);
                        // this.store.dispatch(new OVERALL_ACTIONS.SetSuccess({ successTitle: SUCCESS_MESSAGES.LOGOUT_SUCCESSFULL, successMsg: null }));
                        // this.store.dispatch(new AUTH_ACTIONS.LogoutConfirmed(null));
                        window.location.reload();
                        return new AUTH_ACTIONS.LogoutConfirmed(null);
                    }),
                    catchError(error => of(new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.LOGOUT, errorResponse: error, errorMsg: error.message })))
                )
            ));

    @Effect()
    fetchACL$: Observable<Action> = this.actions$
        .pipe(
            ofType(ACCESS_CONTROL_ACT_TYPES.ACL_FETCH), map((action: AUTH_ACTIONS.AclFetch) => action.payload),
            mergeMap(() => this.authService.getAllowedPages()
                .pipe(
                    map(response => {
                        // this.store.dispatch(new OVERALL_ACTIONS.SetSuccess({ successTitle: SUCCESS_MESSAGES.ACCESS_CONTROL, successMsg: null }));
                        return new AUTH_ACTIONS.AclFetchSuccess(response);
                    }),
                    catchError(error => of(new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.ACCESS_CONTROL, errorResponse: error, errorMsg: error.message })))
                )
            ));

    @Effect()
    fetchBasicInfo$: Observable<Action> = this.actions$
        .pipe(
            ofType(BASIC_INFO_ACT_TYPES.FETCH), map((action: AUTH_ACTIONS.FetchMyBasicInfo) => action.payload),
            mergeMap(() => this.authService.getMyBasicDetails()
                .pipe(
                    map(response => {
                        return new AUTH_ACTIONS.FetchMyBasicInfoSuccess(response);
                    }),
                    catchError(error => of(new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.ACCESS_CONTROL, errorResponse: error, errorMsg: error.message })))
                )
            ));

    @Effect()
    requestOtp$: Observable<any> = this.actions$
        .pipe(
            ofType(FORGOT_PASSWORD_ACT_TYPES.OTP_GENERATION), map((action: AUTH_ACTIONS.RequestOtpMail) => action.payload),
            mergeMap((request: RequestOtpDto) => this.authService.requestOtp(request)
                .pipe(
                    map(response => {
                        this.store.dispatch(new OVERALL_ACTIONS.SetSuccess({ successTitle: SUCCESS_MESSAGES.REQUEST_OTP, successMsg: null }));
                        return new AUTH_ACTIONS.ForgotPasswordOtpGenerated(true);
                    }),
                    catchError(error => of(
                        new AUTH_ACTIONS.ForgotPasswordOtpGenerated(false),
                        new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.REQUEST_OTP, errorResponse: error, errorMsg: ERROR_MESSAGES.REQUEST_OTP }))
                        )
                )
            ));

    @Effect()
    verifyOtp$: Observable<any> = this.actions$
        .pipe(
            ofType(FORGOT_PASSWORD_ACT_TYPES.OTP_VERIFICATION), map((action: AUTH_ACTIONS.ChangePassword) => action.payload),
            mergeMap((verify: VerifyOtpDto) => this.authService.verifyOtp(verify)
                .pipe(
                    map(response => {
                        this.store.dispatch(new OVERALL_ACTIONS.SetSuccess({ successTitle: SUCCESS_MESSAGES.VERIFY_OTP, successMsg: null }));
                        new AUTH_ACTIONS.ForgotPasswordOtpGenerated(false);
                        return new AUTH_ACTIONS.OpenForgotPasswordModal(false);
                    }),
                    catchError(error => of(
                        new AUTH_ACTIONS.ForgotPasswordOtpGenerated(false),
                        new OVERALL_ACTIONS.SetError({ errorTitle: ERROR_MESSAGES.VERIFY_OTP, errorResponse: error, errorMsg: ERROR_MESSAGES.VERIFY_OTP }))
                        )
                )
            ));

}