import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

import { CookieService } from 'ngx-cookie-service';

import { UserReqDto, RequestOtpDto, VerifyOtpDto } from '../interfaces/req/auth.ireq';
import { LoginRespDto } from '../interfaces/res/auth.ires';
import { Store } from '@ngrx/store';
import { LOADER_MESSAGES } from '../../constants/messages';
import { RootStore } from '../root.state';
import { TriggerAjaxCall } from '../actions/overall.action';
import { BASE_URL } from '../../constants/restapi.config';

@Injectable({
  providedIn: 'root'
})
export default class AuthService {

  dummySession: LoginRespDto = {
    userId: null,
    email: null,
    accessToken: null
  }

  private currentUserSubject: BehaviorSubject<LoginRespDto>;
  public currentUser: Observable<LoginRespDto>;

  constructor(private http: HttpClient, private store: Store<RootStore>, private cookieService: CookieService) {
    let loginResp = this.cookieService.get('loginResp');
    if (!loginResp || loginResp === 'undefined') {
      loginResp = JSON.stringify(this.dummySession);
    }

    this.currentUserSubject = new BehaviorSubject<LoginRespDto>(JSON.parse(loginResp));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public routeGaurdCheck(): LoginRespDto {
    let loginResp = this.cookieService.get('loginResp');
    if (!loginResp || loginResp === 'undefined') {
      loginResp = JSON.stringify(this.dummySession);
    }
    // this.currentUserSubject.value;
    return JSON.parse(loginResp);
  }

  public persistCookie(loginResp: LoginRespDto): void {
    this.cookieService.set('loginResp', JSON.stringify(loginResp ? loginResp : this.dummySession));
  }

  public logout(): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.LOGOUT));
    return this.http.post(`${BASE_URL}/kairo_users/logout`, {});
  }

  public changePassword(passwordParam): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.CHANGE_PASSWORD));
    return this.http.post(`${BASE_URL}/kairo_users/change-password`, passwordParam);
  }

  public loginUser(loginParam): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.LOGIN));
    return this.http.post<UserReqDto>(`${BASE_URL}/kairo_users/login`, loginParam);
  }

  public registerUser(registerParam): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.REGISTRATION));
    return this.http.post<UserReqDto>(`${BASE_URL}/kairo_users`, registerParam);
  }

  public getAllowedPages(): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.ACCESS_CONTROL));
    return this.http.get(`${BASE_URL}/menu_access_controls/mine`);
  }

  public getAllMac(): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.ALL_MAC));
    return this.http.get(`${BASE_URL}/menu_access_controls`);
  }

  public getAllMoc(): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.ALL_MAC));
    return this.http.get(`${BASE_URL}/menu_operation_controls`);
  }

  public getMyBasicDetails(): Observable<any> {
    // this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.BASIC_USER_INFO));
    return this.http.get(`${BASE_URL}/kairo_users/basic/details`);
  }

  public requestOtp(requestParam): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.REQUEST_OTP));
    return this.http.get(`${BASE_URL}/kairo_users/forgotPassword?userDetail=${JSON.stringify(requestParam)}`);
  }

  public verifyOtp(passwordParam): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.VERIFY_OTP));
    return this.http.post(`${BASE_URL}/kairo_users/reset/password?userDetail=${JSON.stringify(passwordParam)}`, passwordParam);
  }
}