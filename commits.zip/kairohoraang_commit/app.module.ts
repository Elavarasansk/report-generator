import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { en_US } from 'ng-zorro-antd/i18n';
import en from '@angular/common/locales/en';
import { NZ_I18N } from 'ng-zorro-antd/i18n';
import { CookieService } from 'ngx-cookie-service';
import DateUtility from '../app/common/utility/date.utility';
import DateUtils from '../app/common/utility/dateUtils';
import LazyLoadService from '../app/common/reduxFlow/services/lazyload.service';
import { registerLocaleData } from '@angular/common';
import { NgxSpinnerModule } from "ngx-spinner";

/* UI/UX framework module imports*/
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzBreadCrumbModule } from 'ng-zorro-antd/breadcrumb';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzDrawerModule } from 'ng-zorro-antd/drawer';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzCollapseModule } from 'ng-zorro-antd/collapse';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { NzPageHeaderModule } from 'ng-zorro-antd/page-header';
import { NzTimelineModule } from 'ng-zorro-antd/timeline';
import { NzSpaceModule } from 'ng-zorro-antd/space';
import { NzListModule } from 'ng-zorro-antd/list';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { NzStatisticModule } from 'ng-zorro-antd/statistic';
import { ChartsModule } from 'ng2-charts';
import { NzTimePickerModule } from 'ng-zorro-antd/time-picker';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { NzNotificationModule } from 'ng-zorro-antd/notification';


/* WYSIWYG Component*/
import { AngularEditorModule } from '@kolkov/angular-editor';

/* Entry Apps imports*/
import { AppComponent } from './app.component';
import RootModule from './common/reduxFlow/root.module';
import { AppRoutingModule, RoutingComponent } from './app-routing.module';
import { JwtInterceptor } from './common/request.interceptor';
import { ErrorInterceptor } from './common/error.interceptor';

/* General Component Imports*/
import { MainComponent } from './website/main/main.component';
import { DashboardComponent } from './kairo/dashboard/dashboard.component'
import { LoginComponent } from './website/modals/login/login.component';
import { NotFound404Component } from './website/common/not-found404/not-found404.component';
import { RegistrationComponent } from './website/modals/registration/registration.component';
import { ForgotPasswordComponent } from './website/forgot-password/forgot-password.component';

/* Approve Requests*/
import { ApproveLeaveComponent } from './kairo/approve/leave/approve-leave.component';
import { ApproveClaimComponent } from './kairo/approve/claim/approve-claim.component';
import { ApproveOndutyComponent } from './kairo/approve/onduty/approve-onduty.component';
import { ApprovePermissionComponent } from './kairo/approve/permission/approve-permission.component';
import { ApproveWorkforceComponent } from './kairo/approve/workforce/approve-workforce.component';

/* Feature */
import { TaskCreateComponent } from './kairo/feature/task/task-create.component';
import { SubtaskComponent } from './kairo/feature/component/subtask/subtask.component';
import { ReviewComponent } from './kairo/feature/review/review.component';
import { IssuesComponent } from './kairo/feature/issues/issues.component';
import { SettingComponent } from './kairo/feature/component/setting/setting.component';
import { LogHoursComponent } from './kairo/feature/log-hours/log-hours.component';

/* Approval Master Setttings */
import { ClaimApprovalSettingComponent } from './kairo/master-settings/approval/claim/claim-approval-setting.component';
import { LeaveApprovalSettingComponent } from './kairo/master-settings/approval/leave/leave-approval-setting.component';
import { OndutyApprovalSettingComponent } from './kairo/master-settings/approval/onduty/onduty-approval-setting.component';
import { PermissionApprovalSettingComponent } from './kairo/master-settings/approval/permission/permission-approval-setting.component';
import { WorkforceApprovalSettingComponent } from './kairo/master-settings/approval/workforce/workforce-approval-setting.component';

/* Smart Master Setttings */
import { ManageMenuComponent } from './kairo/master-settings/smart/manage-menu/manage-menu.component';

/* Project */
import { ProjectComponent } from './kairo/project/manage/project.component';
import { AllProjectsComponent } from './kairo/project/all-projects/all-projects.component';
import { AllocateResourcesComponent } from './kairo/project/allocate-resources/allocate-resources.component';
import { MyTeamComponent } from './kairo/project/my-team/my-team.component';

/* Resource */
import { ManageResourcesComponent } from './kairo/resource/manage-resources/manage-resources.component';

/* Request */
import { LeaveApplyComponent } from './kairo/request/leave/leave-apply.component';
import { LeaveStepsComponent } from './kairo/request/leave/leave-steps/leave-steps.component';
import { ClaimRequestComponent } from './kairo/request/claim/claim-request.component';
import { OndutyRequestComponent } from './kairo/request/onduty/onduty-request.component';
import { PermissionRequestComponent } from './kairo/request/permission/permission-request.component';
import { WorkforceRequestComponent } from './kairo/request/workforce/workforce-request.component';
import { LeaveViewComponent } from './kairo/request/leave/leave-view/leave-view.component';
import { LeaveChartComponent } from './kairo/request/leave/leave-chart/leave-chart.component';

/* User */
import { UserManagementComponent } from './kairo/user/manage/user-management.component';
import { MenuAddDrawerComponent } from './kairo/master-settings/smart/manage-menu/subsidary/menu-add-drawer/menu-add-drawer.component';
import { RibbonLabelComponent } from './website/common/ribbon-label/ribbon-label.component';
import { ChangePasswordComponent } from './website/modals/change-password/change-password.component';
import { ApplyLeaveComponent } from './kairo/request/leave/apply-leave/apply-leave.component';
import { AccessDenied401Component } from './website/common/access-denied401/access-denied401.component';

/* Master Settings HR */
import { ShiftComponent } from './kairo/master-settings/hr/shift/shift.component';
import { HolidayComponent } from './kairo/master-settings/hr/holiday/holiday.component';
import { LeaveAllotmentComponent } from './kairo/master-settings/hr/leave-allotment/leave-allotment.component';
import { RequestApprovalComponent } from './kairo/master-settings/hr/request-approval/request-approval.component';
import { AddHolidayComponent } from './kairo/master-settings/hr/holiday/add-holiday/add-holiday.component';


/* Redmine LogTime Report */
import { RedmineLogReportComponent } from './kairo/logtime/redmine-log-report/redmine-log-report.component';
import { RedmineNotLoggedComponent } from './kairo/logtime/redmine-notlogged/redmine-notlogged.component';
import { LeaveAllotmentUpdateComponent } from './kairo/master-settings/hr/leave-allotment/leave-allotment-update/leave-allotment-update.component';
import { PageRestrictionComponent } from './kairo/master-settings/hr/page-restriction/page-restriction.component';
import { SetPermissionComponent } from './kairo/master-settings/hr/page-restriction/set-permission/set-permission.component';

/* Myteam LogTime Report */
import { MyteamLogReportComponent } from './kairo/myteam/redmine-log-report/myteam-log-report.component';
import { ApproveModelComponent } from './kairo/approve/leave/approve-model/approve-model.component';
import { LeaveBalanceComponent } from './website/common/leave-balance/leave-balance.component';
import { NotificationComponent } from './website/common/notification/notification.component';
import { HolidayDetailsComponent } from './kairo/leave/holiday-details/holiday-details.component';
import { MyteamReportComponent } from './kairo/leave/myteam-report/myteam-report.component';
import { OrgReportComponent } from './kairo/leave/org-report/org-report.component';

registerLocaleData(en);
@NgModule({
  declarations: [
    AppComponent, LoginComponent, RoutingComponent,
    RegistrationComponent, MainComponent, SubtaskComponent, SettingComponent, LeaveViewComponent,
    TaskCreateComponent, UserManagementComponent, LeaveStepsComponent, DashboardComponent, NotFound404Component,
    ApproveLeaveComponent, ApproveClaimComponent, ApproveOndutyComponent, ApprovePermissionComponent, ApproveWorkforceComponent,
    ReviewComponent, IssuesComponent, ClaimApprovalSettingComponent, LeaveApprovalSettingComponent,
    OndutyApprovalSettingComponent, PermissionApprovalSettingComponent, WorkforceApprovalSettingComponent,
    ProjectComponent, AllProjectsComponent, AllocateResourcesComponent, ManageResourcesComponent, ClaimRequestComponent,
    OndutyRequestComponent, PermissionRequestComponent, WorkforceRequestComponent, LeaveApplyComponent, LeaveStepsComponent,
    LogHoursComponent, ManageMenuComponent, MenuAddDrawerComponent, RibbonLabelComponent, ChangePasswordComponent, ApplyLeaveComponent,
    AccessDenied401Component, LeaveChartComponent, ShiftComponent, HolidayComponent, LeaveAllotmentComponent, RequestApprovalComponent,
    RedmineLogReportComponent, RedmineNotLoggedComponent, LeaveAllotmentUpdateComponent, AddHolidayComponent, PageRestrictionComponent, SetPermissionComponent,
    MyteamLogReportComponent, MyTeamComponent, ApproveModelComponent, LeaveBalanceComponent, NotificationComponent, MyteamReportComponent, OrgReportComponent, HolidayDetailsComponent, ForgotPasswordComponent],

  imports: [
    BrowserModule, AppRoutingModule, AngularEditorModule,
    FormsModule, ReactiveFormsModule,
    HttpClientModule, BrowserAnimationsModule, NgxSpinnerModule,

    RootModule,
    EffectsModule.forRoot(),
    // StoreModule.forRoot({}),

    NzLayoutModule, NzGridModule, NzSliderModule, NzCollapseModule, NzAvatarModule, NzAutocompleteModule,
    NzFormModule, NzCardModule, NzMenuModule, NzIconModule, NzPopoverModule, NzListModule,
    NzBreadCrumbModule, NzButtonModule, NzInputModule, NzCheckboxModule, NzSpaceModule,
    NzDropDownModule, NzModalModule, NzSpinModule, NzAlertModule, NzPageHeaderModule,
    NzTableModule, NzDividerModule, NzSelectModule, NzDatePickerModule, NzTimelineModule,
    NzDrawerModule, NzRadioModule, NzPopconfirmModule, NzTagModule, NzToolTipModule,
    NzUploadModule, NzStatisticModule, NzBadgeModule, NzResultModule, NzSwitchModule,
    NzEmptyModule, NzInputNumberModule, NzUploadModule, ChartsModule, NzTimePickerModule,
    ScrollingModule, NzStepsModule, NzNotificationModule
  ],
  providers: [
    CookieService,
    DateUtility,
    DateUtils,
    NzMessageService,
    LazyLoadService,
    { provide: NZ_I18N, useValue: en_US },
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }



/*
Already added data:
1.



1.  Advanced filter in the Log report. Because after 3years enormous data will be  present.
2.  My report change to spent-hours to  logged hours.
3.  Dashboard current projects &  hierarchy.
4.  Previously worked projects & previous hiierarchy.
5.  Bulk Resource Movement
6.  Individual resource movement & bulk resource movement, projectmo -
7.  Filter org, org_division, project
8.  User save filter for pages.
9.  Official Role in project.
10. Unique Project code for every projects in project.
11. Proj code.
12. Leave balance Report.
13.
14.

*/