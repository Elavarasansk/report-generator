
interface UserReqDto {
    username?: string | null;
    email?: string | null;
    password: string | null;
}

interface UserRegisterReqDto {
    email: string | null;
    password: string | null;
    leave_count: {
        earned_leave: number;
        sick_leave: number;
        casual_leave: number;
    }
}

interface UserLeaveCountReqDto {
    id: number
}

interface PasswordChangeReqDto {
    oldPassword: string;
    newPassword: string;
}

interface PasswordChangeReqDto {
    oldPassword: string;
    newPassword: string;
}

interface RequestOtpDto {
    email?: string | null;
    username?: string | null;
}

interface VerifyOtpDto {
    email?: string | null;
    username?: string | null;
    otp: number;
    password: string;
}


export {
    UserReqDto,
    UserLeaveCountReqDto,
    UserRegisterReqDto,
    PasswordChangeReqDto,
    RequestOtpDto,
    VerifyOtpDto
}