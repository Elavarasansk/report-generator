import { LoginRespDto, RegistrationRespDto, MacRespDto, OperationControlRespDto, BasicUserInfoResDto } from '../res/auth.ires';

interface AuthPageState {
    openLoginModal: boolean,
    openSignUpModal: boolean,
    openPasswordChangeModal: boolean,

    isLoggedIn: boolean,
    loginResponse: LoginRespDto;
    registrationResponse: RegistrationRespDto;

    singleMenu: Array<MacRespDto>;
    nestedMenu: Array<MacRespDto>;
    pathBasedAclCrud: {};
    basicUserInfo: BasicUserInfoResDto;
    generatedOtp: boolean;
    openForgotPasswordModal: boolean;
}


export {
    AuthPageState
}