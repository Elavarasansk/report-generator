enum LOADER_MESSAGES {
    LOGIN = 'Logging in',
    LOGOUT = 'Logging out',
    CHANGE_PASSWORD = 'Changing Password',
    REGISTRATION = 'Registering User',
    LEAVE_DETAIL = 'Fetching Leave Detail',
    LEAVE_REQUEST = 'Leave Request Sent',
    LEAVE_COUNT = 'Leave Count Requested',
    LEAVE_WITHDRAW_REQUEST = 'Leave Withdraw Request Sent',
    ACCESS_CONTROL = 'Fetching Access Control List',
    ALL_MAC = 'Fetching All Registered Menus',
    ALL_MOC = 'Fetching All Menu Operation Control',

    MAC_META = 'Fetching All Menu Access Control metadata',
    ADD_MAC = 'Adding Menu Access Control',
    USER_DETAIL = 'Fetching All User Detail',
    ADD_USER = 'Adding User Detail',

    LEAVE_BALANCE = 'Fetching My Leave balance',
    MY_APPROVER_HIERARCHY = 'Fetch my approver hierarchy',
    MY_APPLIED_LEAVES = 'Fetching applied leaves',
    APPLY_LEAVE = 'Applying Leave',
    MODIFY_LEAVE_REASON = 'Modifying Leave reason',
    WITHDRAW_LEAVE_REQUEST = 'Withdrawing the Leave request',
    LEAVE_REQUEST_FLOW_DETAILS = 'Fetch My Leave request flow details',

    FETCH_LEAVE_REQUEST_GIVEN_TOME = 'Fetch Leave request given to me',
    FETCH_LR_DETALS_GIVEN_TOME = 'Fetch Leave request details',
    TAKE_ACTION_ON_LR_GIVEN_TOME = 'Taking Action on Leave request given',
    AUTOCOMPLETE_USER = 'AutoComplete User',
    EXPORT_USER_DETAILS = 'Export User Details',
    USER_HIERARCHY = 'User Hierarchy',
    FETCH_PROJECTS = 'Fetch project list',
    FETCH_PROJECT_RESOURCES = 'Fetch project resource list',
    CHANGE_ROLE = 'Change employee role',
    CHANGE_TEAM = 'Change employee team',
    CHANGE_PROJECT = 'Change employee project',
    ALL_NOTIFICATION = 'Fetching all notification',
    UPDATE_NOTIFICATION = 'Update notification',
    BULK_UPDATE = 'Resource bulk update',

    LEAVE_STATUS_META = "Fetching Leave Status types",

    ACTION_STATUS_META = 'Fetching All Approval Action Status',
    TAKE_ACTION_ON_ALL_LR_GIVEN_TOME = 'Taking Action on All Leave request given',
    BASIC_USER_INFO = 'Fetching My basic info',

    MASTER_SETTING_SHIFT = 'Fetching Master setting shift',
    MASTER_SETTING_SHIFT_ADD = 'Adding Master setting shift',
    MASTER_SETTING_SHIFT_UPDATE = 'Updating Master setting shift',

    MASTER_SETTING_HOLIDAY = 'Fetching Master setting holiday',
    MASTER_SETTING_HOLIDAY_ADD = 'Adding Master setting holiday',
    MASTER_SETTING_HOLIDAY_UPDATE = 'Updating Master setting holiday',
    MASTER_SETTING_HOLIDAY_DELETE = 'Deleting Master setting holiday',

    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH = 'Fetching Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH_ADD = 'Adding Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH_UPDATE = 'Updating Leave allotment settings',
    FETCH_REDMINE_LOGREPORT = 'Fetching Redmine logreport.',
    FETCH_REDMINE_NOTLOGGED_REPORT = 'Fetching Redmine not logged report.',
    FETCH_NESTED_REDMINE_NOTLOGGED_REPORT = 'Fetching Nested Redmine not logged report.',

    MASTER_SETTING_REQUEST_APPROVAL_FETCH = 'FetchingFetched request-approval settings',
    MASTER_SETTING_REQUEST_APPROVAL_FETCH_UPDATE = 'Updating request-approval settings',

    LEAVE_REQUEST_ALLOTMENT_DETAILS = 'Fetching Leave Allotment Setting',
    LEAVE_MASTER_SETTING_ALLOTMENT_DETAILS = 'Fetching User Master Allotment Setting',
    LEAVE_REQUEST_HOLIDAY_DETAILS = 'Fetching Organization Holiday Details',

    SET_MAC_PERMISSION = 'Setting Menu GlobalPermission',
    SET_MOC_PERMISSION = 'Setting Menu Cud Permission',

    FETCH_MYTEAM_REDMINE_LOG_REPORT = 'Fetching Myteam redmine log report.',  
    DOWNLOAD_PROJ_ALLOC_TEMPLATE = 'Download project allocation template',
    DOWNLOAD_LOGTIME_REPORT = 'Downloading logtime report.',
    FETCH_MYTEAM_DETAILS = 'Fetching my team details',
    DOWNLOAD_MYTEAM_DETAILS = 'Downloading my team details',
    LEAVE_ORG_REPORT = 'Fetching ORG leave org report',
    REQUEST_OTP = 'Request Otp',
    VERIFY_OTP = 'Verify Otp'
}

enum SUCCESS_MESSAGES {
    LOGIN = 'Login Successfull',
    LOGOUT_SUCCESSFULL = 'Logout Successfull',
    REGISTRATION = 'Registration Successfull',
    CHANGE_PASSWORD = 'Changing Password Successfull',
    LEAVE_DETAIL = "Loading Successfull",
    LEAVE_REQUEST = 'Leave Request Successfull',
    LEAVE_COUNT = 'Leave Count Successfull',
    LEAVE_WITHDRAW_REQUEST = 'Leave Withdraw Request Successfull',
    ACCESS_CONTROL = 'Fetching Access Control List Successful',
    ALL_MAC = 'Fetching All Registered Menus Successful',
    ALL_MOC = 'Fetching All Menu Operation Control Successful',

    MAC_META = 'Fetching All Menu Access Control metadata is Successful',
    ADD_MAC = 'Adding Menu Access Control is Successful',

    LEAVE_BALANCE = 'Successfully Fetched my Leave balance',
    MY_APPROVER_HIERARCHY = 'My hierarchy has been Fetched',
    MY_APPLIED_LEAVES = 'Succesfully Fetched applied leaves',
    APPLY_LEAVE = 'Leave applied Succesfully',
    MODIFY_LEAVE_REASON = 'Succesfully updated leave request reason',
    WITHDRAW_LEAVE_REQUEST = 'Succesfully Withdrawn the Leave request',
    LEAVE_REQUEST_FLOW_DETAILS = 'Succesfully Fetched My Leave request flow details',

    FETCH_LEAVE_REQUEST_GIVEN_TOME = 'Succesfully Fetched  Leave request given to me',
    FETCH_LR_DETALS_GIVEN_TOME = 'Succesfully Fetched Leave request details ',
    TAKE_ACTION_ON_LR_GIVEN_TOME = 'Succesfully took Action on Leave request given',
    USER_DETAIL = 'Fetching All User Detail is Successful',
    ADD_USER = 'Adding User Detail is Successful',
    AUTOCOMPLETE_USER = 'AutoComplete User is Successful',
    EXPORT_USER_DETAILS = 'Export User Details is Successful',
    USER_HIERARCHY = 'User Hierarchy is Successful',

    FETCH_PROJECTS = 'Successfully fetched project list',
    FETCH_PROJECT_RESOURCES = 'Successfully fetched project resource list',
    CHANGE_ROLE = 'Successfully changed employee role',
    CHANGE_TEAM = 'Successfully changed employee team',
    CHANGE_PROJECT = 'Successfully changed employee project',
    ALL_NOTIFICATION = 'Fetching all notification Succesfully',
    UPDATE_NOTIFICATION = 'Update notification Succesfully',
    BULK_UPDATE = 'Resource bulk updated successfully',

    LEAVE_STATUS_META = "Fetched Leave Status types",

    ACTION_STATUS_META = 'Fetching All Approval Action Status is Successful',
    TAKE_ACTION_ON_ALL_LR_GIVEN_TOME = 'Succesfully took Action on All Leave request given',

    BASIC_USER_INFO = 'Successfully Fetched basic info',
    MASTER_SETTING_SHIFT = 'Successfully Fetched Master setting shift',
    MASTER_SETTING_SHIFT_ADD = 'Successfully Added Master setting shift',
    MASTER_SETTING_SHIFT_UPDATE = 'Successfully updated Master setting shift',

    MASTER_SETTING_HOLIDAY = 'Successfully Fetched  Master setting holiday',
    MASTER_SETTING_HOLIDAY_ADD = 'Successfully Added  Master setting holiday',
    MASTER_SETTING_HOLIDAY_UPDATE = 'Successfully Updated Master setting holiday',
    MASTER_SETTING_HOLIDAY_DELETE = 'Successfully Deleted Master setting holiday',

    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH = 'Successfully Fetched Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH_ADD = 'Successfully Added Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH_UPDATE = 'Successfully updated Leave allotment settings',
    FETCH_REDMINE_LOGREPORT = 'Successfully Fetched Redmine logreport.',
    FETCH_REDMINE_NOTLOGGED_REPORT = 'Successfully Fetched Redmine not logged report.',
    FETCH_NESTED_REDMINE_NOTLOGGED_REPORT = 'Successfully Fetched Nested Redmine not logged report.',


    MASTER_SETTING_LEAVE_ALLOTMENT_ADD = 'Successfully Added Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_UPDATE = 'Successfully updated Leave allotment settings',

    MASTER_SETTING_REQUEST_APPROVAL_FETCH = 'Successfully Fetched request-approval settings',
    MASTER_SETTING_REQUEST_APPROVAL_UPDATE = 'Successfully updated request-approval settings',

    LEAVE_REQUEST_ALLOTMENT_DETAILS = 'Successfully Fetched Leave Allotment Setting',
    LEAVE_MASTER_SETTING_ALLOTMENT_DETAILS = 'Successfully Fetched User Master Allotment Setting',
    LEAVE_REQUEST_HOLIDAY_DETAILS = 'Successfully Fetched Organization Holiday Details',

    SET_MAC_PERMISSION = 'Successfully Set Menu GlobalPermission',
    SET_MOC_PERMISSION = 'Successfully Set Menu Cud Permission',

    FETCH_MYTEAM_REDMINE_LOG_REPORT = 'Successfully Fetched Myteam redmine log report.',
    DOWNLOAD_PROJ_ALLOC_TEMPLATE = 'Successfully downloaded project allocation template',
    DOWNLOAD_LOGTIME_REPORT = 'Successfully downloaded logtime report.',
    FETCH_MYTEAM_DETAILS = 'Successfully fetched my team details',
    DOWNLOAD_MYTEAM_DETAILS = 'Successfully downloaded my team details',
    LEAVE_ORG_REPORT = 'Successfully Fetched ORG leave report',
    REQUEST_OTP = 'OTP generated successfully',
    VERIFY_OTP = 'Password changed successfully'
}

enum ERROR_MESSAGES {
    LOGIN = 'Login Failed',
    LOGOUT = 'Log out Failed',
    CHANGE_PASSWORD = 'Changing Password failed',
    REGISTRATION = 'Registration Failed',
    LEAVE_DETAIL = 'Loading Failed',
    LEAVE_REQUEST = 'Leave Request Failed',
    LEAVE_COUNT = 'Leave Count Failed',
    LEAVE_WITHDRAW_REQUEST = 'Leave Withdraw Request Failed',
    ACCESS_CONTROL = 'Fetching Access Control List failed',
    ALL_MAC = 'Fetching All Registered Menus failed',
    ALL_MOC = 'Fetching AllMenu Operation Control failed',

    MAC_META = 'Fetching All Menu Access Control metadata, failed',
    ADD_MAC = 'Adding Menu Access Control failed',

    LEAVE_BALANCE = 'Failed Fetched my Leave balance',
    MY_APPROVER_HIERARCHY = ' Failed to fetch My hierarchy',
    MY_APPLIED_LEAVES = 'Failed to fetch applied leaves',
    APPLY_LEAVE = 'Failed to apply Leave',
    MODIFY_LEAVE_REASON = 'Failed to update leave request reason',
    WITHDRAW_LEAVE_REQUEST = 'Failed to Withdrawn the Leave request',
    LEAVE_REQUEST_FLOW_DETAILS = 'Failed to Fetch My Leave request flow details',

    FETCH_LEAVE_REQUEST_GIVEN_TOME = 'Failed to Fetch Leave request given to me',
    FETCH_LR_DETALS_GIVEN_TOME = 'Failed to Fetch Leave request details',
    TAKE_ACTION_ON_LR_GIVEN_TOME = 'Failed complete Action on Leave request given',

    USER_DETAIL = 'Fetching All User Detail failed',
    ADD_USER = 'Adding User Detail failed',
    AUTOCOMPLETE_USER = 'AutoComplete User is failed',
    EXPORT_USER_DETAILS = 'Export User Details is failed',
    USER_HIERARCHY = 'User Hierarchy is Successful',

    FETCH_PROJECTS = 'Failed to fetch project list',
    FETCH_PROJECT_RESOURCES = 'Failed to fetch project resource list',
    CHANGE_ROLE = 'Failed to change employee role',
    CHANGE_TEAM = 'Failed to change employee team',
    CHANGE_PROJECT = 'Failed to change employee project',
    ALL_NOTIFICATION = 'Fetching all notification failed',
    UPDATE_NOTIFICATION = 'Update notification failed',
    BULK_UPDATE = 'Resource bulk update failed',

    LEAVE_STATUS_META = "Fetching Leave Status types failed",

    ACTION_STATUS_META = 'Fetching All Approval Action Status is failed',
    TAKE_ACTION_ON_ALL_LR_GIVEN_TOME = 'Failed to complete Action on All Leave request given',

    BASIC_USER_INFO = 'Failed to fetch basic info',
    MASTER_SETTING_SHIFT = 'Failed to Fetched Master setting shift',
    MASTER_SETTING_SHIFT_ADD = 'Failed to Add Master setting shift',
    MASTER_SETTING_SHIFT_UPDATE = 'Failed to update Master setting shift',

    MASTER_SETTING_HOLIDAY = 'Failed to Fetch  Master setting holiday',
    MASTER_SETTING_HOLIDAY_ADD = 'Failed to Add  Master setting holiday',
    MASTER_SETTING_HOLIDAY_UPDATE = 'Failed to Update Master setting holiday',
    MASTER_SETTING_HOLIDAY_DELETE = 'Failed to Delete Master setting holiday',

    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH = 'Failed to Fetch Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH_ADD = 'Failed to Add Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_FETCH_UPDATE = 'Failed to update Leave allotment settings',

    NO_LEAVE_BALANCE = 'You dont have suffcient leave balance',
    WRONG_TO_DATE = 'End Date cannot be lessthan start date',
    FETCH_REDMINE_LOGREPORT = 'Failed to Fetched Redmine logreport.',
    FETCH_REDMINE_NOTLOGGED_REPORT = 'Failed to Fetched Redmine not logged report.',
    FETCH_NESTED_REDMINE_NOTLOGGED_REPORT = 'Failed to Fetched Nested Redmine not logged report.',

    MASTER_SETTING_LEAVE_ALLOTMENT_ADD = 'Failed to Add Leave allotment settings',
    MASTER_SETTING_LEAVE_ALLOTMENT_UPDATE = 'Failed to update Leave allotment settings',

    MASTER_SETTING_REQUEST_APPROVAL_FETCH = 'Failed to Fetch Fetched request-approval settings',
    MASTER_SETTING_REQUEST_APPROVAL_UPDATE = 'Failed to update request-approval settings',
    LEAVE_REQUEST_ALLOTMENT_DETAILS = 'Failed to fetch Leave Allotment Setting',
    LEAVE_MASTER_SETTING_ALLOTMENT_DETAILS = 'Failed to fetch User Master Allotment Setting',
    LEAVE_REQUEST_HOLIDAY_DETAILS = 'Failed to fetch Organization Holiday Details',

    SET_MAC_PERMISSION = 'Failed to Set Menu GlobalPermission',
    SET_MOC_PERMISSION = 'Failed to Set Menu Cud Permission',

    FETCH_MYTEAM_REDMINE_LOG_REPORT = 'Failed to fetch Myteam redmine log report.',
    DOWNLOAD_PROJ_ALLOC_TEMPLATE = 'Failed to download project allocation template',
    DOWNLOAD_LOGTIME_REPORT = 'Failed to downloaded logtime report.',
    FETCH_MYTEAM_DETAILS = 'Failed to fetch my team details',
    DOWNLOAD_MYTEAM_DETAILS = 'Failed to download my team details',
    LEAVE_ORG_REPORT = 'Failed Fetch ORG leave report',
    REQUEST_OTP = 'Failed to generate OTP. Enter valid domain name/email',
    VERIFY_OTP = 'Failed to change password. Request for OTP again.'
}

export {
    LOADER_MESSAGES,
    SUCCESS_MESSAGES,
    ERROR_MESSAGES
}