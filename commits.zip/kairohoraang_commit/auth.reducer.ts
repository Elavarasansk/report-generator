import { LoginActions } from '../actions/auth.action';
import { AuthPageState } from '../interfaces/state/auth.istate';
import { LOGIN_ACT_TYPES, REGISTRATION_ACT_TYPES, ACCESS_CONTROL_ACT_TYPES, CHANGE_PASSWORD_ACT_TYPES, BASIC_INFO_ACT_TYPES, FORGOT_PASSWORD_ACT_TYPES } from '../actionTypes/auth.actionType';


const initialState: AuthPageState = {
    isLoggedIn: false,
    loginResponse: null,
    registrationResponse: null,

    openLoginModal: false,
    openSignUpModal: false,
    openPasswordChangeModal: false,

    singleMenu: [],
    nestedMenu: [],
    pathBasedAclCrud: {},
    basicUserInfo: null,
    generatedOtp: false,
    openForgotPasswordModal: false
};

export default function AuthReducer(state: AuthPageState = initialState, action: LoginActions): AuthPageState {
    const { type, payload } = action;

    switch (type) {

        case LOGIN_ACT_TYPES.INVOKE_LOGIN_MODAL: {
            return {
                ...state,
                openLoginModal: payload
            }
        }

        case CHANGE_PASSWORD_ACT_TYPES.PASSWORD_CHANGE_MODAL: {
            return {
                ...state,
                openPasswordChangeModal: payload
            }
        }

        case REGISTRATION_ACT_TYPES.INVOKE_REGISTRATION_MODAL: {
            return {
                ...state,
                openSignUpModal: payload
            }
        }

        case LOGIN_ACT_TYPES.LOGIN: {
            return {
                ...state
            }
        }
        case LOGIN_ACT_TYPES.LOGIN_SUCCESS: {
            return {
                ...state,
                isLoggedIn: true,
                openLoginModal: false,
                loginResponse: payload
            }
        }

        case REGISTRATION_ACT_TYPES.REGISTRATION: {
            return {
                ...state
            }
        }
        case REGISTRATION_ACT_TYPES.REGISTRATION_SUCCESS: {
            return {
                ...state,
                openSignUpModal: false,
                registrationResponse: payload
            }
        }

        case LOGIN_ACT_TYPES.LOGOUT_CONFIRMED: {
            return {
                ...state,
                isLoggedIn: false,
                loginResponse: null
            }
        }

        case ACCESS_CONTROL_ACT_TYPES.ACL_FETCH: {
            return {
                ...state
            }
        }
        case ACCESS_CONTROL_ACT_TYPES.ACL_FETCH_SUCCESS: {
            const { singleMenu, nestedMenu, pathBasedAclCrud } = payload;

            return {
                ...state,
                singleMenu,
                nestedMenu,
                pathBasedAclCrud
            }
        }

        case BASIC_INFO_ACT_TYPES.FETCH: {
            return {
                ...state
            }
        }
        case BASIC_INFO_ACT_TYPES.FETCH_SUCCESS: {
            return {
                ...state,
                basicUserInfo: payload
            }
        }
        case FORGOT_PASSWORD_ACT_TYPES.FORGOT_PASSWORD_OTP_GENERATED: {
            return {
                ...state,
                generatedOtp: payload
            }
        }
        case FORGOT_PASSWORD_ACT_TYPES.OPEN_FORGOT_PASSWORD_MODAL: {
            return {
                ...state,
                openForgotPasswordModal: payload
            }
        }

        default:
            return state;
    }
}