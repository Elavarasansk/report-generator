enum LOGIN_ACT_TYPES {
    LOGIN = '[USER] Login',
    CHECK_LOGIN = '[USER] Login Check',
    LOGIN_SUCCESS = '[USER] Login Success',

    LOGOUT = '[USER] Logout',
    LOGOUT_CONFIRMED = '[USER] Logout Confirmed',

    INVOKE_LOGIN_MODAL = '[Invoke] Login Modal'
}

enum REGISTRATION_ACT_TYPES {
    REGISTRATION = '[USER] Registration',
    REGISTRATION_SUCCESS = '[USER] Registration Success',

    INVOKE_REGISTRATION_MODAL = '[Invoke] Registration Modal'
}

enum CHANGE_PASSWORD_ACT_TYPES {
    PASSWORD_CHANGE = '[PASSWORD] Change',
    PASSWORD_CHANGE_SUCCESS = '[PASSWORD] Change Success',

    PASSWORD_CHANGE_MODAL = '[PASSWORD] Change Modal'
}

enum ACCESS_CONTROL_ACT_TYPES {
    ACL_FETCH = '[ACL] Fetch',
    ACL_FETCH_SUCCESS = '[ACL] Fetch Success',
}

enum BASIC_INFO_ACT_TYPES {
    FETCH = '[Basic Info] Fetch',
    FETCH_SUCCESS = '[Basic Info] Fetch Success',
}

enum FORGOT_PASSWORD_ACT_TYPES {
    OPEN_FORGOT_PASSWORD_MODAL = '[Forgot Password] Open Forgot Password Modal',
    OTP_GENERATION = '[Forgot Password] Otp Generation',
    OTP_VERIFICATION = '[Forgot Password] Otp Verification',
    FORGOT_PASSWORD_OTP_GENERATED = '[Forgot Password] Forgot Password Otp generated',
}

export {
    LOGIN_ACT_TYPES,
    REGISTRATION_ACT_TYPES,
    ACCESS_CONTROL_ACT_TYPES,
    CHANGE_PASSWORD_ACT_TYPES,
    BASIC_INFO_ACT_TYPES,
    FORGOT_PASSWORD_ACT_TYPES
}