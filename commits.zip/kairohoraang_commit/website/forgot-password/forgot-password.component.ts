import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';

import KEY from '../../common/constants/storeKeys';
import { SMART } from 'src/app/common/constants/restapi.config';
import { RootStore } from '../../common/reduxFlow/root.state';

import { RequestOtpMail, ChangePassword, ForgotPasswordOtpGenerated } from '../../common/reduxFlow/actions/auth.action';
import { RequestOtpDto, VerifyOtpDto } from '../../common/reduxFlow/interfaces/req/auth.ireq';
import AuthService from '../../common/reduxFlow/services/auth.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
    
    activeStep: number = 1;
    validateFormOne!: FormGroup;
    validateFormTwo!: FormGroup;
    domainOrEmail: string = '';
    generatedOtp: boolean = false;
    popoverContent: string = "OTP has been sent to the email";
    closeConfirm: string = "On going back, the changes made will be lost and the OTP will become invalid. Do you really want to go back?";

    @Output()
    public backClick = new EventEmitter();

    constructor(private fb: FormBuilder, private router: Router, private store: Store<RootStore>, private authService: AuthService) {
      store.select(KEY.ROOT_REDUCER).subscribe(result => {
        const { generatedOtp } = result[KEY.AUTH_PAGE_STORE];
        this.generatedOtp = generatedOtp
        if (this.generatedOtp) {
          this.activeStep = 2;
        } else {
          this.activeStep = 1;
        }
      })
     }

    ngOnInit(): void {
        this.validateFormOne = this.fb.group({
            email: [null, [Validators.required]]
          });
        this.validateFormTwo = this.fb.group({
            newPassword: [null, [Validators.required]],
            otp: [null, [Validators.required]],
            checkPassword: [null, [Validators.required, this.confirmationValidator]]
          });
    }

    submitEmail(): void {
      for (const i in this.validateFormOne.controls) {
        this.validateFormOne.controls[i].markAsDirty();
        this.validateFormOne.controls[i].updateValueAndValidity();
      }
  
      const { store, validateFormOne } = this;
      const { email } = validateFormOne.controls;
  
      const isEmail = this.validateEmail(email.value);
      this.domainOrEmail = email.value;

      const requestParam: RequestOtpDto = {
        [isEmail ? "email" : "username"]: email.value
      }
      if (validateFormOne.status === `VALID`) {
        store.dispatch(new RequestOtpMail(requestParam));
      }
    }

    validateEmail(email): boolean {
      const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(String(email).toLowerCase());
    }

    submitOtpPassword(): void {

      for (const i in this.validateFormTwo.controls) {
        this.validateFormTwo.controls[i].markAsDirty();
        this.validateFormTwo.controls[i].updateValueAndValidity();
      }
  
      const { store, validateFormTwo } = this;
      const { otp, newPassword } = validateFormTwo.controls;

      const isEmail = this.validateEmail(this.domainOrEmail);

      const verifyParam: VerifyOtpDto = {
        [isEmail ? "email" : "username"]: this.domainOrEmail,
        otp : otp.value,
        password : newPassword.value
      }
      if (validateFormTwo.status === `VALID`) {
        store.dispatch(new ChangePassword(verifyParam));
      }
      this.validateFormTwo.reset()
      this.validateFormOne.reset()
    } 

    goBackToPreviousStep(): void {
      this.validateFormTwo.reset()
      const { store } = this;
      store.dispatch(new ForgotPasswordOtpGenerated(false));
      this.activeStep = 1;
    }

    goBackToLogin(): void {
      this.validateFormOne.reset()
      this.validateFormTwo.reset()
      this.activeStep = 1
      this.backClick.emit()
      this.store.dispatch(new ForgotPasswordOtpGenerated(false));
    }

    confirmationValidator = (control: FormControl): { [s: string]: boolean } => {
        if (!control.value) {
          return { required: true };
        } else if (control.value !== this.validateFormTwo.controls.newPassword.value) {
          return { confirm: true, error: true };
        }
        return {};
    };

    onClose(): void {
      this.goBackToLogin();
    }

}