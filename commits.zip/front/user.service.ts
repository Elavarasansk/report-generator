import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

import { CookieService } from 'ngx-cookie-service';

import { UserAddReqDto  } from '../interfaces/req/user.ireq';
import {  UserDetailRespDto} from '../interfaces/res/user.ires';
import { Store } from '@ngrx/store';
import { RootStore } from '../root.state';
import { LOADER_MESSAGES } from '../../constants/messages';
import { TriggerAjaxCall } from '../actions/overall.action';
import { BASE_URL } from '../../constants/restapi.config';

@Injectable({
  providedIn: 'root'
})
export default class UserService {

  constructor(private http: HttpClient, private store: Store<RootStore>) {
  }



  public downloadUserDetails(): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.EXPORT_USER_DETAILS));
    let headers = { 'Content-Type': 'application/ms-excel'  };
    return this.http.get(`${BASE_URL}/kairo_users/export`,{ responseType: 'blob'} );
  }
  

  public autoCompleteUser(): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.AUTOCOMPLETE_USER));
      return this.http.get(`${BASE_URL}/kairo_users?filter={ "fields":["id","empId","probationId","probationPrefix","isProbation" ] }`);
  }
  
  public getAllUser(param): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.USER_DETAIL));
    return this.http.post(`${BASE_URL}/kairo_users/management`,param);
  }

  public addNewUser(addParam): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.ADD_USER));
    return this.http.post<UserAddReqDto>(`${BASE_URL}/kairo_users/add/user`, addParam);
  }

  public getUserHierarchy(param): Observable<any> {
    this.store.dispatch(new TriggerAjaxCall(LOADER_MESSAGES.USER_HIERARCHY));
    return this.http.get(`${BASE_URL}/kairo_users/my/hierarchy?userId=${param}`, param);
  }

}