interface UserAddReqDto {
    mobile:number ,
    empId: number,
    firstName: string,
    lastName: string,
    username:string,
    password:string,
    role:number,
    project:number,
    organisation_id:number,
    email:string,
    gender:string,
    personalEmail:string ,
    probationPrefix : string,
    isProbation:boolean,
    probationId:string,
    active : boolean,
    emailVerified : boolean
}

interface UserFilterReqDto {
    searchTxt : string ,
    limit : number ,
    page : number
}

interface UserHierarchyReqDto {
    userId : number 
}


export {
    UserAddReqDto ,
    UserFilterReqDto ,
    UserHierarchyReqDto
}