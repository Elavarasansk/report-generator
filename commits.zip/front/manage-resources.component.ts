import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserFetch , UserAdd ,UserAutoCompete , UserExport , UserHierarchy} from '../../../common/reduxFlow/actions/user.action';
import { Store } from '@ngrx/store';
import { RootStore } from '../../../common/reduxFlow/root.state';
import KEY from '../../../common/constants/storeKeys';
import {SMART} from 'src/app/common/constants/restapi.config';
import { UserAddReqDto , UserFilterReqDto } from 'src/app/common/reduxFlow/interfaces/req/user.ireq';
import { NzMessageService } from 'ng-zorro-antd/message';
import { TriggerGlobalRefresh } from 'src/app/common/reduxFlow/actions/overall.action';

const MY_PAGE_PATH = '/resources/manage';

@Component({
  selector: 'app-manage-resources',
  templateUrl: './manage-resources.component.html',
  styleUrls: ['./manage-resources.component.css']
})
export class ManageResourcesComponent implements OnInit {

 
  listOfData : any = [];

  public isHierarchyVisible: boolean = false;

  public genderList: Array<string> = ['Male', 'Female'];
  roleList=[];
  projectList=[];
  organisationList = [];
  filterRole: Array<object> = [];
  filterProject: Array<object> = [];
  hierarchyList: Array<object> = [];
  filteredOptions: string[] = [];
  options = [];
  inputValue: string;
  selectedValue :string;
  pageIndex : number = 1;
  pageLimit : number = 7;
  totalSize:number = 1;

  public isVisible : boolean = false ;
  validateForm: FormGroup;

  constructor(private fb: FormBuilder , private store: Store<RootStore> , private message: NzMessageService) {  
    store.select(KEY.ROOT_REDUCER).subscribe(result => {
      const { allUserList , autoCompleteList , hierachyData } = result[KEY.USER_PAGE_STORE];
      const { isRefreshing } = result[KEY.OVERALL_PAGE_STORE];
      const { roleTypes,projectDetails,orgDetails,orgDivDetails } = result[KEY.META_DATA_PAGE_STORE];
           
      if (isRefreshing && (window.location.hash).replace(`${SMART.HASH_ROUTE}`, "") === MY_PAGE_PATH) {
        this.store.dispatch(new TriggerGlobalRefresh(false));
        let param : UserFilterReqDto = {
          searchTxt : this.selectedValue  ,
          limit : this.pageLimit ,
          page : this.pageIndex
          }
        this.store.dispatch(new UserAutoCompete(null));
        this.store.dispatch(new UserFetch(param));
      }

      let optionsList = [];
      autoCompleteList.forEach(data=>{
        const  { empId , isProbation , probationId , probationPrefix } = data;
        if(isProbation){
          optionsList.push( (probationPrefix+'-'+probationId).toString());
        }else{
          if(!empId) return;
          optionsList.push( empId.toString());
        }
      });
      let hrchyList = [];
      const { myHigherAuthorites , ownerAlloc } = hierachyData || {};
      const { employee , kairoRole  } = ownerAlloc || {};
      let { username , empId , isProbation , probationPrefix , probationId } = employee || {};
      const { name } = kairoRole || {};
      empId = isProbation ?  probationPrefix+'-'+probationId  : empId ;   
      hrchyList.push( { username , empId , name } );
      myHigherAuthorites && myHigherAuthorites.forEach(data => {
        const { employee , kairoRole  } = data ;
        let { username , empId , isProbation , probationPrefix , probationId } = employee;
        const { name } = kairoRole;  
        empId = isProbation ?  probationPrefix+'-'+probationId  : empId ;   
        hrchyList.push( { username , empId , name }  );
      });
      this.hierarchyList = hrchyList.reverse();
      this.totalSize = autoCompleteList && autoCompleteList.length;
      this.listOfData = allUserList;
      this.options = optionsList;
      this.filteredOptions = this.options;
      this.roleList = roleTypes;
      this.projectList =  projectDetails ? projectDetails.projectList : [];
      
      this.organisationList =  orgDetails ? orgDetails.organisationList : [];
    });
this.updateForm();
  }

  ngOnInit(): void {

    let param : UserFilterReqDto = {
      searchTxt : null ,
      limit : this.pageLimit ,
      page : this.pageIndex
      }
    this.store.dispatch(new UserAutoCompete(null));
    this.store.dispatch(new UserFetch(param));

  }


  handleCancel() {
    this.isVisible = false;
    this.resetForm();
  }


  showModal() {
    this.isVisible = true;
  }

  public setStatusValue(active: boolean): string {
    if(active){
      return "ACTIVE";
    }else{
      return "INACTIVE";
    }
}

  public setStatusColor(active: boolean): string {
      if(active){
        return "green";
      }else{
        return "red";
      }
  }

  public setGenderColor(gender: string): string {
    switch(gender) {
      case "MALE":
        return "green";
      default:
        return "red";
    }
}

public setRoleColor(role):string{
  if(!role) return ;
  switch(role.toUpperCase()) {
    case "SOFTWARE_MANAGER":
    case "ADMIN_MANAGER":
    case "HR_MANAGER":
      return "green";

    case "SOFTWARE_CL":
    case "ADMIN_LEAD":
    case "HR_LEAD":
    case "ACCOUNTS_LEAD":
       return "red";

    case "SOFTWARE_LL":
    case "ADMIN_STAFF":
      return "cyan";
    case "SOFTWARE_MEMBER":
      return "blue";

        default:
      return "";
  }
}

  public handleHierachyCancel() {
    this.isHierarchyVisible = false;

  }

  submitForm(value: { empType:string , empId: number; email: string , firstName: string,mobile : number,autoGenerate :boolean,
    lastName: string,gender: string,username : string , personalEmail : string, probationPrefix : string , probationId : string ,role:number,organisation_id:number,project:number}): void {

      for (const key in this.validateForm.controls) {
      this.validateForm.controls[key].markAsDirty();
      this.validateForm.controls[key].updateValueAndValidity();
    }

    if( this.validateForm.status == "INVALID"){
      return;
    }
    let { empType ,probationPrefix ,empId , lastName , firstName , gender , username , email , mobile ,personalEmail , autoGenerate,role,organisation_id,project} = value;
    let isProbation = false;
    let probationId = null;

    
    if(autoGenerate && empType == 'Probation'){
      probationPrefix = "P";
      isProbation = true;
    }else if(!autoGenerate && empType == 'Probation'){
      probationPrefix = "P";
      isProbation = true;
      probationId = value.probationId;
      if(!probationId){
        this.message.error('Probation ID is required');
        return;
      }
    }else if(autoGenerate && empType == 'Regular'){
      empId =null;
    }else if(!autoGenerate && empType == 'Regular'){
      if(!empId){
        this.message.error('Employee ID is required');
        return;
      }
    }
 
    let param : UserAddReqDto = {
      empId,
      mobile  ,
      firstName,
      lastName,
      username,
      password:email,
      role,
      project,
      organisation_id,
      email,
      gender,
      personalEmail,
      probationPrefix,
      isProbation,
      probationId,
      active : true,
      emailVerified : true
    }
   this.store.dispatch(new UserAdd(param));  
    this.isVisible = false;
    this.resetForm();
  }


  resetForm(): void {
    this.validateForm.reset();
    for (const key in this.validateForm.controls) {
      this.validateForm.controls[key].markAsPristine();
      this.validateForm.controls[key].updateValueAndValidity();
    }
    this.updateForm();
  }
  

  updateForm() : void {
    const { required, email } = Validators;
    this.validateForm = this.fb.group({
      empId: ['', []],
      firstName: ['', []],
      email: ['', [required, email]],
      personalEmail: ['', [email]],
      mobile: ['', [Validators.pattern("(0/91)?[7-9][0-9]{9}")]],
      gender: ['MALE', [required]],
      role:['',[required]],
      project:['',[required]],
      organisation_id:['',[required]],
      username: ['', [required]],
      lastName: ['', []] ,
      empType: ['Regular', []] ,
      probationId: ['', []] ,
      autoGenerate: ['true', []] ,
      probationPrefix: ['', []]
    });
  }

  onChange(value: string): void {

    let param : UserFilterReqDto = {
      searchTxt : this.selectedValue    ,
      limit : this.pageLimit ,
      page : 1
      }
      this.store.dispatch(new UserFetch(param));
  }

  onPageIndexChange(value: number):void {
    this.pageIndex = value;
    let param : UserFilterReqDto = {
      searchTxt : this.inputValue ,
      limit : this.pageLimit ,
      page : this.pageIndex 
      }
      this.store.dispatch(new UserFetch(param));

  }

  exportUserDetail = () =>{
    this.store.dispatch(new UserExport(null));
  }

  showUserHierarchy (userId) {
    this.store.dispatch(new UserHierarchy( userId ))
    this.isHierarchyVisible = true;

  }

}
