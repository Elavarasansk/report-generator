import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { NzModalService } from 'ng-zorro-antd/modal';
import AuthService from '../../common/reduxFlow/services/auth.service';
import { SMART } from 'src/app/common/constants/restapi.config';
import KEY from '../../common/constants/storeKeys';
import { RootStore } from '../../common/reduxFlow/root.state';
import moment from 'moment';
import { Logout, AclFetch, BootPasswordChangeModal } from '../../common/reduxFlow/actions/auth.action';
import { NotificationFetch, NotificationUpdate } from '../../common/reduxFlow/actions/notification.action';
import { NotificationFilterReqDto } from '../../common/reduxFlow/interfaces/req/notification.ireq';

import { TriggerGlobalRefresh } from '../../common/reduxFlow/actions/overall.action';

import { CountryFetch, ShiftFetch, OrgFetch, OrgDivFetch, ProjectFetch, LeaveAndSettingFetch, ReleaseFetch } from '../../common/reduxFlow/actions/meta.action';

import { RequestCategoryFetch, ApprovalFlowTypeFetch, RoleTypeFetch } from '../../common/reduxFlow/actions/meta.action';
import { FetchLeaveAllotmentDetails, FetchLeaveHolidayDetails, LeaveBalanceFetch } from 'src/app/common/reduxFlow/actions/leave-request.action';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {

  basicUserInfo = null;

  globalPath: string = 'smart';
  isLoading: boolean = false;
  isCollapsed: boolean = false;
  isLoggedIn: boolean = false;
  username: string = '';

  successBoot: boolean = false;
  failureBoot: boolean = false;

  singleMenuItems: Array<any> = [];
  nestedMenuItems: Array<any> = [];
  currentTitle: string = "";

  refreshing: boolean = false;
  notificationCount: number;

  // notificationList: Array<any>;
  // isApprovalVisible: boolean = false;
  // leaveDate: Date;
  // errorhours: number;
  // notificationId: number;
  // isFullDay: boolean;
  // isHalfDay: boolean;

  constructor(private store: Store<RootStore>, private router: Router, private authService: AuthService) {
    this.performSubscription();
  }

  ngOnInit(): void {
    this.store.dispatch(new AclFetch(null));
    this.store.dispatch(new NotificationFetch(null));
    this.store.dispatch(new FetchLeaveAllotmentDetails(null));
    this.store.dispatch(new FetchLeaveHolidayDetails(null));
    this.initalMetaFetch();
  }

  performSubscription() {
    this.store.select(KEY.ROOT_REDUCER).subscribe(result => {
      const { singleMenu, nestedMenu, pathBasedAclCrud } = result[KEY.AUTH_PAGE_STORE];
      this.renderSideMenu(singleMenu, nestedMenu);
      this.componentRouting(this.authService.routeGaurdCheck());

      const { basicUserInfo } = result[KEY.AUTH_PAGE_STORE];
      this.basicUserInfo = basicUserInfo;

      this.pageHeaderTitleSetUp(result);
      this.notificationSusbcription(result);
      this.refreshSubscription(result);
    });
    this.store.dispatch(new LeaveBalanceFetch(null));
  }

  notificationSusbcription = (result) => {
    const { notificationList } = result[KEY.NOTIFICATION_PAGE_STORE];
    this.notificationCount = notificationList && notificationList.length;
    // this.notificationList = notificationList;
  }

  refreshSubscription = (result) => {
    const { isRefreshing } = result[KEY.OVERALL_PAGE_STORE].isRefreshing;
    this.refreshing = isRefreshing;
  }

  pageHeaderTitleSetUp = (result) => {
    const { pathBasedAclCrud } = result[KEY.AUTH_PAGE_STORE];
    const pathInfo = (window.location.hash).replace(`${SMART.HASH_ROUTE}`, "");
    this.currentTitle = pathBasedAclCrud[pathInfo] && pathBasedAclCrud[pathInfo].TITLE;
  }

  initalMetaFetch = () => {
    this.store.dispatch(new RoleTypeFetch(null));
    this.store.dispatch(new CountryFetch(null));
    this.store.dispatch(new ShiftFetch(null));
    this.store.dispatch(new OrgFetch(null));
    this.store.dispatch(new OrgDivFetch(null));
    this.store.dispatch(new ProjectFetch(null));

    this.store.dispatch(new ProjectFetch(null));
    this.store.dispatch(new LeaveAndSettingFetch(null));
    this.store.dispatch(new ReleaseFetch(null));
    this.store.dispatch(new ReleaseFetch(null));

    this.store.dispatch(new RequestCategoryFetch(null));
    this.store.dispatch(new ApprovalFlowTypeFetch(null));
  }

  componentRouting(resp): void {
    const { accessToken, username } = resp;
    this.username = username;
    this.isLoggedIn = !!accessToken;
    if (!this.isLoggedIn) {
      this.router.navigate(['/home']);
    }
  }

  renderSideMenu = (singleMenu, nestedMenu) => {
    this.singleMenuItems = singleMenu;
    this.nestedMenuItems = nestedMenu;
  }
  onMenuSelect = (menu) => {
    const { path, title } = menu;
    this.currentTitle = title;
    this.router.navigate([`${this.globalPath}/${path}`]);
  }
  onSubMenuSelect = (menu, subMenu) => {
    const { path, title } = menu;
    this.currentTitle = `${title} - ${subMenu.title}`;
    this.router.navigate([`${this.globalPath}/${path}/${subMenu.path}`]);
  }

  handleProfile = () => { };
  handleSettings = () => { };
  showNotification = () => { };

  goToHome = () => this.router.navigate(['/home'])
  handleLogout = () => this.store.dispatch(new Logout(null));
  handleGlobalRefresh = () => this.store.dispatch(new TriggerGlobalRefresh(true));
  bootPasswordChangeModal = () => this.store.dispatch(new BootPasswordChangeModal(true));


  // markAllRead() {
  //   const idsList = this.notificationList.map(e => e.id)
  //   this.store.dispatch(new NotificationUpdate(idsList));
  // }
  // onView(item): void {
  //   this.store.dispatch(new NotificationUpdate([item.id]));
  //   const moduleType = item.notificationType.moduleName;
  //   let { type, noOfDays, fromDate, toDate, actionStatus, status, insufficientHours, flawDate } = item.messageValues;
  //   let param = { type, noOfDays, fromDate, toDate, status, insufficientHours, flawDate, selectActionStatus: actionStatus };
  //   switch (moduleType) {
  //     case "REDMINE_INSUFFICIENT_LOGTIME":
  //       this.router.navigate(['/smart/redmine-notlogged'], { queryParams: param });
  //       break;
  //     case "LEAVE_REQUEST_GIVEN_TO_ME":
  //       this.router.navigate([`/smart/approve/leave`], { queryParams: param });
  //       break;
  //     case "MY_APPROVED_REQUEST":
  //     case "MY_REJECTED_REQUEST":
  //     case "MY_STAGE_APPROVAL":
  //       this.router.navigate(['/smart/request/leave'], { queryParams: param });
  //       break;

  //   }
  // }
  // onLeaveViewClose(event): void {
  //   if (event) {
  //     this.isApprovalVisible = false;
  //   } else {
  //     this.store.dispatch(new NotificationFetch(null));
  //     this.isApprovalVisible = false;
  //   }
  // }
  // getAvatarPrefix(moduleName: string): string {
  //   switch (moduleName) {
  //     case "REDMINE_INSUFFICIENT_LOGTIME":
  //       return "IN";
  //     case "LEAVE_REQUEST_GIVEN_TO_ME":
  //       return "LR";
  //     case "MY_REJECTED_REQUEST":
  //       return "RJ";
  //     case "MY_APPROVED_REQUEST":
  //       return "AP";
  //     case "MY_STAGE_APPROVAL":
  //       return "AP";
  //   }
  // }
  // formatDate(inDate): string {
  //   return moment(inDate).format('DD-MM-YYYY');
  // }

}
