package validator.testcase.service;

public class ResultDetail {

	private String cellValue;
	private int rowNumber;
	private String sheetName;
	private String fileName;
	private String bugNumber;

	private String result1;
	private String result2;
	private String result3;
	private String result4;

	private String BugId1;
	private String BugId2;
	private String BugId3;
	private String BugId4;

	private String date1;
	private String date2;
	private String date3;
	private String date4;

	private String note1;
	private String note2;
	private String note3;
	private String note4;

	public String getCellValue() {
		return cellValue;
	}

	public void setCellValue(String cellValue) {
		this.cellValue = cellValue;
	}

	public int getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getBugNumber() {
		return bugNumber;
	}

	public void setBugNumber(String bugNumber) {
		this.bugNumber = bugNumber;
	}

	public String getResult1() {
		return result1;
	}

	public void setResult1(String result1) {
		this.result1 = result1;
	}

	public String getResult2() {
		return result2;
	}

	public void setResult2(String result2) {
		this.result2 = result2;
	}

	public String getResult3() {
		return result3;
	}

	public void setResult3(String result3) {
		this.result3 = result3;
	}

	public String getResult4() {
		return result4;
	}

	public void setResult4(String result4) {
		this.result4 = result4;
	}

	public String getBugId1() {
		return BugId1;
	}

	public void setBugId1(String bugId1) {
		BugId1 = bugId1;
	}

	public String getBugId2() {
		return BugId2;
	}

	public void setBugId2(String bugId2) {
		BugId2 = bugId2;
	}

	public String getBugId3() {
		return BugId3;
	}

	public void setBugId3(String bugId3) {
		BugId3 = bugId3;
	}

	public String getBugId4() {
		return BugId4;
	}

	public void setBugId4(String bugId4) {
		BugId4 = bugId4;
	}

	public String getDate1() {
		return date1;
	}

	public void setDate1(String date1) {
		this.date1 = date1;
	}

	public String getDate2() {
		return date2;
	}

	public void setDate2(String date2) {
		this.date2 = date2;
	}

	public String getDate3() {
		return date3;
	}

	public void setDate3(String date3) {
		this.date3 = date3;
	}

	public String getDate4() {
		return date4;
	}

	public void setDate4(String date4) {
		this.date4 = date4;
	}

	public String getNote1() {
		return note1;
	}

	public void setNote1(String note1) {
		this.note1 = note1;
	}

	public String getNote2() {
		return note2;
	}

	public void setNote2(String note2) {
		this.note2 = note2;
	}

	public String getNote3() {
		return note3;
	}

	public void setNote3(String note3) {
		this.note3 = note3;
	}

	public String getNote4() {
		return note4;
	}

	public void setNote4(String note4) {
		this.note4 = note4;
	}

	@Override
	public String toString() {
		return "ResultDetail [cellValue=" + cellValue + ", rowNumber=" + rowNumber + ", sheetName=" + sheetName
		        + ", fileName=" + fileName + ", bugNumber=" + bugNumber + ", result1=" + result1 + ", result2="
		        + result2 + ", result3=" + result3 + ", result4=" + result4 + ", BugId1=" + BugId1 + ", BugId2="
		        + BugId2 + ", BugId3=" + BugId3 + ", BugId4=" + BugId4 + ", date1=" + date1 + ", date2=" + date2
		        + ", date3=" + date3 + ", date4=" + date4 + ", note1=" + note1 + ", note2=" + note2 + ", note3=" + note3
		        + ", note4=" + note4 + ", getCellValue()=" + getCellValue() + ", getRowNumber()=" + getRowNumber()
		        + ", getSheetName()=" + getSheetName() + ", getFileName()=" + getFileName() + ", getBugNumber()="
		        + getBugNumber() + ", getResult1()=" + getResult1() + ", getResult2()=" + getResult2()
		        + ", getResult3()=" + getResult3() + ", getResult4()=" + getResult4() + ", getBugId1()=" + getBugId1()
		        + ", getBugId2()=" + getBugId2() + ", getBugId3()=" + getBugId3() + ", getBugId4()=" + getBugId4()
		        + ", getDate1()=" + getDate1() + ", getDate2()=" + getDate2() + ", getDate3()=" + getDate3()
		        + ", getDate4()=" + getDate4() + ", getNote1()=" + getNote1() + ", getNote2()=" + getNote2()
		        + ", getNote3()=" + getNote3() + ", getNote4()=" + getNote4() + ", getClass()=" + getClass()
		        + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
