package validator.testcase.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ooxml.POIXMLException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

//import org.apache.poi.POIXMLException;
//import org.apache.poi.xssf.usermodel.XSSFCell;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Service
public class ReviewTargetTest {

	public static PrintWriter pw = null;
	XSSFWorkbook workBook = null;
	private boolean sheetFlag = true;
	List<String> devTesterNameList = null;
	private boolean lineNoFlag = true;
	private boolean iscompleteFlag;
	public static boolean alertExceptionFlag;
	public static String alertMessage;

	public void doReview(File file, String testCaseFormat) {
		ReviewTargetTest reviewTargetTest = new ReviewTargetTest();
		pw = null;
		alertExceptionFlag = false;
		alertMessage = "";
		reviewTargetTest.iscompleteFlag = true;
		try {
			if (file.toString().endsWith(".ods")) {
				throw new Exception("Please, remove the \".ods\" file from the directory");
			}
			reviewTargetTest.workBook = new XSSFWorkbook(new FileInputStream(file));

			reviewTargetTest.getCellValueRowNumber(1, 5, 0, 4, file.getName(), false);

			if (reviewTargetTest.iscompleteFlag && pw != null) {
				pw.println("<no issues found>");
			}
			reviewTargetTest.iscompleteFlag = true;
			reviewTargetTest.sheetFlag = true;

			// int sheetCount = workBook.getNumberOfSheets();

			if (testCaseFormat.equalsIgnoreCase("old")) {
				reviewTargetTest.getCellValueRowNumber(13, 7, 1, 7, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(27, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(46, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(65, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(84, 7, 1, 12, file.getName(), false);
			} else if (testCaseFormat.equalsIgnoreCase("new")) {
				reviewTargetTest.getCellValueRowNumber(45, 7, 1, 7, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(58, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(77, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(96, 7, 1, 12, file.getName(), false);
			} else if (testCaseFormat.equalsIgnoreCase("enh")) {
				reviewTargetTest.getCellValueRowNumber(45, 7, 1, 7, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(58, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(77, 7, 1, 10, file.getName(), false);
				reviewTargetTest.getCellValueRowNumber(96, 7, 1, 12, file.getName(), false);

				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}
				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getDeveloperTesterNameUiUx(1, 3, 3);
				reviewTargetTest.getCellValueRowNumberLatestForUiUx(17, 15, 3, file.getName()); // (12,15,3,21,

				// if (reviewTargetTest.iscompleteFlag && pw != null) {
				// pw.println("<no issues found>");
				// }
				//
				// reviewTargetTest.iscompleteFlag = true;
				// reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getCellValueRowNumber(57, 6, 3, 3, file.getName(), true);
				reviewTargetTest.getCellValueRowNumber(67, 6, 3, 8, file.getName(), true);

				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}

				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getDeveloperTesterName(1, 3, 4);
				reviewTargetTest.getCellValueRowNumberLatest(13, 15, 4, file.getName()); // (12,15,3,21, file.getName(),
				// true);
				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}
				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getDeveloperTesterName(1, 3, 5);
				reviewTargetTest.getCellValueRowNumberLatest(10, 15, 5, file.getName()); // (9,15,4,3, file.getName(),
				// true);
				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}
				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getDeveloperTesterName(1, 3, 6);
				reviewTargetTest.getCellValueRowNumberLatest(10, 15, 6, file.getName()); // (9,15,5,2, file.getName(),
				// true);
				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}
				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getDeveloperTesterName(1, 3, 7);
				reviewTargetTest.getCellValueRowNumberLatest(10, 15, 7, file.getName()); // (9,15,6,5, file.getName(),
				// true);
				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}
				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				int noOfSheets = reviewTargetTest.workBook.getNumberOfSheets();

				for (int i = 19; i < noOfSheets; i++) {
					reviewTargetTest.getDeveloperTesterName(1, 3, i);
					List<ResultDetail> acExJnlMakeSumSetDlgResultOne = reviewTargetTest.getCellValueRowNumberLatest(13,
					        15, i, file.getName());
					if (reviewTargetTest.iscompleteFlag && pw != null) {
						pw.println("<no issues found>");
					}
					reviewTargetTest.iscompleteFlag = true;
					reviewTargetTest.sheetFlag = true;
				}

				if (pw != null) {
					pw.println(
					        "___________________________________________________________________________________________________________________________");
					pw.println("**************************" + file.getName()
					        + " testcase is completed*******************************");
				}

				if (pw != null) {
					pw.close();
				}

				return;
			} else if (testCaseFormat.equalsIgnoreCase("uiuxsummary")) {

				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;

				reviewTargetTest.getDeveloperTesterNameUiUx(1, 3, 3);
				reviewTargetTest.getCellValueRowNumberLatestForUiUx(17, 15, 3, file.getName()); // (12,15,3,21,

				reviewTargetTest.getCellValueRowNumber(57, 6, 3, 3, file.getName(), true);
				reviewTargetTest.getCellValueRowNumber(67, 6, 3, 8, file.getName(), true);

				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}

				if (pw != null) {
					pw.println(
					        "___________________________________________________________________________________________________________________________");
					pw.println("**************************" + file.getName()
					        + " testcase is completed*******************************");
				}
				if (pw != null) {
					pw.close();
				}
				return;
			}
			if (reviewTargetTest.iscompleteFlag && pw != null) {
				pw.println("<no issues found>");
			}
			reviewTargetTest.iscompleteFlag = true;
			reviewTargetTest.sheetFlag = true;

			reviewTargetTest.getDeveloperTesterName(1, 3, 3);
			reviewTargetTest.getCellValueRowNumberLatest(13, 15, 3, file.getName()); // (12,15,3,21, file.getName(),
			// true);
			if (reviewTargetTest.iscompleteFlag && pw != null) {
				pw.println("<no issues found>");
			}
			reviewTargetTest.iscompleteFlag = true;
			reviewTargetTest.sheetFlag = true;

			reviewTargetTest.getDeveloperTesterName(1, 3, 4);
			reviewTargetTest.getCellValueRowNumberLatest(10, 15, 4, file.getName()); // (9,15,4,3, file.getName(),
			// true);
			if (reviewTargetTest.iscompleteFlag && pw != null) {
				pw.println("<no issues found>");
			}
			reviewTargetTest.iscompleteFlag = true;
			reviewTargetTest.sheetFlag = true;

			reviewTargetTest.getDeveloperTesterName(1, 3, 5);
			reviewTargetTest.getCellValueRowNumberLatest(10, 15, 5, file.getName()); // (9,15,5,2, file.getName(),
			// true);
			if (reviewTargetTest.iscompleteFlag && pw != null) {
				pw.println("<no issues found>");
			}
			reviewTargetTest.iscompleteFlag = true;
			reviewTargetTest.sheetFlag = true;

			reviewTargetTest.getDeveloperTesterName(1, 3, 6);
			reviewTargetTest.getCellValueRowNumberLatest(10, 15, 6, file.getName()); // (9,15,6,5, file.getName(),
			// true);
			if (reviewTargetTest.iscompleteFlag && pw != null) {
				pw.println("<no issues found>");
			}
			reviewTargetTest.iscompleteFlag = true;
			reviewTargetTest.sheetFlag = true;

			int noOfSheets = reviewTargetTest.workBook.getNumberOfSheets();

			for (int i = 18; i < noOfSheets; i++) {
				reviewTargetTest.getDeveloperTesterName(1, 3, i);
				List<ResultDetail> acExJnlMakeSumSetDlgResultOne = reviewTargetTest.getCellValueRowNumberLatest(13, 15,
				        i, file.getName());
				if (reviewTargetTest.iscompleteFlag && pw != null) {
					pw.println("<no issues found>");
				}
				reviewTargetTest.iscompleteFlag = true;
				reviewTargetTest.sheetFlag = true;
			}

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			if (e instanceof POIXMLException && e.toString().contains("InvalidFormatException")) {
				alertExceptionFlag = true;
				alertMessage = "Please close all the files and " + file.getName() + " is currenlty opened";
				// System.exit(0);
			}
			if (e.toString().contains("Please, remove the \".ods\" file from the directory")) {
				alertExceptionFlag = true;
				alertMessage = "Please, remove the \".ods\" file from the directory, File Name:" + file.getName();
			}
		}

		if (pw != null) {
			pw.println(
			        "___________________________________________________________________________________________________________________________");
			pw.println("**************************" + file.getName()
			        + " testcase is completed*******************************");
		}

		if (pw != null) {
			pw.close();
		}

	}

	private void getCellValueRowNumber(int row, int column, int sheetNumber, int loopCount, String fileName,
	        boolean isUiUx) {
		List<ResultDetail> ResultDetailList = new ArrayList<>();
		for (int i = 0; i < loopCount; i++) {
			XSSFSheet reviewSheet = workBook.getSheetAt(sheetNumber);
			ResultDetail resultDetail = new ResultDetail();
			if (sheetNumber == 0) {
				XSSFCell reviewSheetCell = reviewSheet.getRow(row + i).getCell(column);
				String cellValue = reviewSheetCell.toString();
				String summayColumn = (cellValue != null && cellValue.isEmpty())
				        ? ((i == 0) ? "Developer:"
				                : ((i == 1) ? "Tester:"
				                        : ((i == 2) ? "Testcase Reviewer:"
				                                : ((i == 3) ? "Test Result Reviewer:" : ""))))
				                + "\"not filled\""
				        : "";
				resultDetail.setCellValue(summayColumn);
				resultDetail.setRowNumber(row + i + 1);
				resultDetail.setSheetName(reviewSheet.getSheetName());
				resultDetail.setFileName(fileName);
				ResultDetailList.add(resultDetail);
			} else if (sheetNumber == 1 || sheetNumber == 3) {
				XSSFCell reviewResultCell = reviewSheet.getRow(row + i).getCell(column);
				String reviewResult = reviewResultCell.toString();

				XSSFCell reviewerCell = reviewSheet.getRow(row + i).getCell(column - 1);
				String reviewer = reviewerCell.toString();

				XSSFCell reviewDateCell = reviewSheet.getRow(row + i).getCell(column - 2);
				String reviewDate;
				try {
					reviewDate = reviewDateCell.toString();
				} catch (Exception e) {
					e.printStackTrace();
					reviewDate = reviewDateCell.getDateCellValue().toInstant().atZone(ZoneId.systemDefault())
					        .toLocalDate().toString();
				}

				reviewResult = reviewResult == null ? "" : reviewResult.trim();
				reviewer = reviewer == null ? "" : reviewer.trim();
				reviewDate = reviewDate == null ? "" : reviewDate.trim();

				String finalResult = "";
				finalResult = reviewer.isEmpty() ? ("Reviewer Name:\"not filled\" , ")
				        : "Reviewer Name:" + reviewer + " , ";
				finalResult = finalResult + (reviewDate.isEmpty() ? ("Review Date:\"not filled\" , ")
				        : "Review Date:" + reviewDate + " , ");

				if (reviewResult.isEmpty() || reviewResult.equalsIgnoreCase("fail")) {
					String reviewResultTemp = reviewResult.isEmpty() ? ("Review Result:\"not filled\"")
					        : ("Review Result:" + reviewResult);
					finalResult = finalResult + reviewResultTemp;

				}
				if (reviewer.isEmpty() || reviewDate.isEmpty() || reviewResult.isEmpty()
				        || reviewResult.equalsIgnoreCase("fail")) {
					resultDetail.setCellValue(finalResult);
					resultDetail.setRowNumber(row + i + 1);
				}
				resultDetail.setSheetName(reviewSheet.getSheetName());
				resultDetail.setFileName(fileName);
				ResultDetailList.add(resultDetail);
			}

		}
		writeResultDetails(ResultDetailList, fileName, isUiUx);
	}

	private List<ResultDetail> getCellValueRowNumberLatest(int row, int column, int sheetNumber, String fileName) {

		List<ResultDetail> ResultDetailList = new ArrayList<>();
		XSSFSheet reviewSheet = workBook.getSheetAt(sheetNumber);
		int eol = reviewSheet.getLastRowNum();
		for (int i = 0; i <= (eol - row); i++) {

			// for (int i = 0; i <= reviewSheet.getLastRowNum(); i++) {

			if (Objects.nonNull(reviewSheet.getRow(row + i))
			        && Objects.nonNull(reviewSheet.getRow(row + i).getCell(3))) {
				XSSFCell viewPointCell = reviewSheet.getRow(row + i).getCell(3);
				String viewPointValue = viewPointCell == null ? "" : viewPointCell.toString();
				if (viewPointValue != null && !viewPointValue.isEmpty()) {

					XSSFCell reviewSheetCell = reviewSheet.getRow(row + i).getCell(column);
					String resultCellValue1 = reviewSheetCell.toString();
					String bugTicket1 = reviewSheet.getRow(row + i).getCell(column + 1).toString();
					String dateValue1 = "";
					Date date1 = null;
					String notes1 = "";

					try {
						dateValue1 = reviewSheet.getRow(row + i).getCell(column - 1).getDateCellValue() != null
						        ? reviewSheet.getRow(row + i).getCell(column - 1).getDateCellValue().toString()
						        : "";
						date1 = dateValue1 != "" ? reviewSheet.getRow(row + i).getCell(column - 1).getDateCellValue()
						        : null;
						dateValue1 = dateValue1 != ""
						        ? date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toString()
						        : "";
					} catch (IllegalStateException e) {
						e.printStackTrace();
						dateValue1 = reviewSheet.getRow(row + i).getCell(column - 1).toString();
					}

					try {
						notes1 = reviewSheet.getRow(row + i).getCell(column + 2).toString();
					} catch (Exception e) {
						e.printStackTrace();
					}

					String resultCellValue2 = reviewSheet.getRow(row + i).getCell(column + 4).toString();
					String bugTicket2 = reviewSheet.getRow(row + i).getCell(column + 5).toString();
					String dateValue2 = "";
					Date date2 = null;
					try {
						dateValue2 = reviewSheet.getRow(row + i).getCell(column + 3).getDateCellValue() != null
						        ? reviewSheet.getRow(row + i).getCell(column + 3).getDateCellValue().toString()
						        : "";
						date2 = dateValue2 != "" ? reviewSheet.getRow(row + i).getCell(column + 3).getDateCellValue()
						        : null;
						dateValue2 = dateValue2 != ""
						        ? date2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toString()
						        : "";
					} catch (IllegalStateException e) {
						e.printStackTrace();
						dateValue2 = reviewSheet.getRow(row + i).getCell(column + 3).toString();
					}

					String notes2 = reviewSheet.getRow(row + i).getCell(column + 6).toString();

					String resultCellValue3 = reviewSheet.getRow(row + i).getCell(column + 8).toString();
					String bugTicket3 = reviewSheet.getRow(row + i).getCell(column + 9).toString();

					String dateValue3 = "";
					Date date3 = null;

					try {
						dateValue3 = reviewSheet.getRow(row + i).getCell(column + 7).getDateCellValue() != null
						        ? reviewSheet.getRow(row + i).getCell(column + 7).getDateCellValue().toString()
						        : "";
						date3 = dateValue3 != "" ? reviewSheet.getRow(row + i).getCell(column + 7).getDateCellValue()
						        : null;
						dateValue3 = dateValue3 != ""
						        ? date3.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toString()
						        : "";
					} catch (IllegalStateException e) {
						e.printStackTrace();
						dateValue3 = reviewSheet.getRow(row + i).getCell(column + 7).toString();
					}
					String notes3 = reviewSheet.getRow(row + i).getCell(column + 10).toString();

					String resultCellValue4 = reviewSheet.getRow(row + i).getCell(column + 12).toString();
					String bugTicket4 = reviewSheet.getRow(row + i).getCell(column + 13) != null
					        ? reviewSheet.getRow(row + i).getCell(column + 13).toString()
					        : "";

					String dateValue4 = "";
					Date date4 = null;

					try {
						dateValue4 = reviewSheet.getRow(row + i).getCell(column + 11).getDateCellValue() != null
						        ? reviewSheet.getRow(row + i).getCell(column + 11).getDateCellValue().toString()
						        : "";
						date4 = dateValue4 != "" ? reviewSheet.getRow(row + i).getCell(column + 11).getDateCellValue()
						        : null;
						dateValue4 = dateValue4 != ""
						        ? date4.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toString()
						        : "";
					} catch (IllegalStateException e) {
						e.printStackTrace();
						dateValue4 = reviewSheet.getRow(row + i).getCell(column + 11).toString();
					}

					String notes4 = reviewSheet.getRow(row + i).getCell(column + 14) != null
					        ? reviewSheet.getRow(row + i).getCell(column + 14).toString()
					        : "";

					resultCellValue1 = resultCellValue1 == null ? "" : resultCellValue1.trim();

					ResultDetail resultDetail = new ResultDetail();

					resultDetail.setSheetName(reviewSheet.getSheetName());
					resultDetail.setFileName(fileName);
					ResultDetailList.add(resultDetail);

					if (resultCellValue1.isEmpty() || resultCellValue1.equalsIgnoreCase("fail")) {
						resultDetail.setResult1(resultCellValue1);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId1(bugTicket1);
						resultDetail.setDate1(dateValue1);
						resultDetail.setNote1(notes1);
					} else if ((resultCellValue1.equalsIgnoreCase("pass")
					        || resultCellValue1.equalsIgnoreCase("no need"))
					        && (dateValue1 == null || dateValue1.isEmpty())) {
						resultDetail.setResult1(resultCellValue1);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId1(bugTicket1);
						resultDetail.setDate1(dateValue1);
						resultDetail.setNote1(notes1);
					}

					if (resultCellValue2.isEmpty() || resultCellValue2.equalsIgnoreCase("fail")) {
						resultDetail.setResult2(resultCellValue2);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId2(bugTicket2);
						resultDetail.setDate2(dateValue2);
						resultDetail.setNote2(notes2);
					} else if ((resultCellValue2.equalsIgnoreCase("pass")
					        || resultCellValue1.equalsIgnoreCase("no need"))
					        && (dateValue2 == null || dateValue2.isEmpty())) {
						resultDetail.setResult2(resultCellValue2);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId2(bugTicket2);
						resultDetail.setDate2(dateValue2);
						resultDetail.setNote2(notes2);
					}

					if (resultCellValue3.isEmpty() || resultCellValue3.equalsIgnoreCase("fail")) {
						resultDetail.setResult3(resultCellValue3);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId3(bugTicket3);
						resultDetail.setDate3(dateValue3);
						resultDetail.setNote3(notes3);
					} else if ((resultCellValue3.equalsIgnoreCase("pass")
					        || resultCellValue1.equalsIgnoreCase("no need"))
					        && (dateValue3 == null || dateValue3.isEmpty())) {
						resultDetail.setResult3(resultCellValue3);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId3(bugTicket3);
						resultDetail.setDate3(dateValue3);
						resultDetail.setNote3(notes3);
					}

					if (resultCellValue4.isEmpty() || resultCellValue4.equalsIgnoreCase("fail")) {
						resultDetail.setResult4(resultCellValue4);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId4(bugTicket4);
						resultDetail.setDate4(dateValue4);
						resultDetail.setNote4(notes4);
					} else if ((resultCellValue4.equalsIgnoreCase("pass")
					        || resultCellValue1.equalsIgnoreCase("no need"))
					        && (dateValue4 == null || dateValue4.isEmpty())) {
						resultDetail.setResult4(resultCellValue4);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId4(bugTicket4);
						resultDetail.setDate4(dateValue4);
						resultDetail.setNote4(notes4);
					}

				}
			}

		}
		writeResultDetailsLatest(ResultDetailList, fileName, false);
		return ResultDetailList;
	}

	private List<String> getDeveloperTesterName(int row, int column, int sheetNumber) {

		devTesterNameList = new ArrayList<>();

		XSSFSheet reviewSheet = workBook.getSheetAt(sheetNumber);

		XSSFCell devNameCell = reviewSheet.getRow(row).getCell(column);
		String devName = devNameCell.toString();
		XSSFCell testerNameCell = reviewSheet.getRow(row).getCell(column + 3);
		String testerName = testerNameCell.toString();

		devTesterNameList.add(devName);
		devTesterNameList.add(testerName);

		return devTesterNameList;
	}

	private void writeResultDetails(List<ResultDetail> ResultDetailList, String fileName, boolean isUiUx) {

		try {
			if (!ResultDetailList.isEmpty()) {
				String path = "D:\\ReviewResult\\outfromtool\\" + fileName + ".txt";
				pw = (pw == null) ? new PrintWriter(new FileWriter(path)) : pw;
				for (ResultDetail resultDetail : ResultDetailList) {
					if (sheetFlag) {
						if (resultDetail.getSheetName().equalsIgnoreCase("summary")) {
							pw.println(
							        "___________________________________________________________________________________________________________________________");
							pw.println("**************************" + resultDetail.getFileName()
							        + " testcase is started*******************************");
						}
						pw.println(
						        "___________________________________________________________________________________________________________________________");
						pw.println(getCurrentTime() + "FileName:" + resultDetail.getFileName());
						pw.println(getCurrentTime() + "SheetName:" + resultDetail.getSheetName());

						sheetFlag = false;

						if (devTesterNameList != null && !devTesterNameList.isEmpty()) {
							String dev = devTesterNameList.get(0);
							if (dev != null && dev.isEmpty()) {
								pw.println(getCurrentTime() + "Developer Name:\"not filled\"");
								iscompleteFlag = false;
							}
							String tester = new String();
							if (!isUiUx) {
								tester = devTesterNameList.get(1);
								if (tester != null && tester.isEmpty()) {
									pw.println(getCurrentTime() + "Tester Name:\"not filled\"");
									iscompleteFlag = false;
								}
							}
							devTesterNameList = null;
						}

						if (!resultDetail.getSheetName().equalsIgnoreCase("summary")) {
							pw.println(getCurrentTime() + "Result Details:");
						}

					}
					if (!resultDetail.getSheetName().equalsIgnoreCase("summary")) {
						if (resultDetail.getRowNumber() != 0) {
							pw.println(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
							        + resultDetail.getCellValue());
							iscompleteFlag = false;
						}
					} else {
						if (resultDetail.getSheetName().equalsIgnoreCase("summary")
						        && resultDetail.getCellValue().contains(":")) {
							pw.println(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
							        + resultDetail.getCellValue());
							iscompleteFlag = false;

						}
					}
				}

				pw.flush();

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void writeResultDetailsLatest(List<ResultDetail> ResultDetailList, String fileName, boolean isUiUx) {

		try {
			if (!ResultDetailList.isEmpty()) {
				String path = "D:\\ReviewResult\\outfromtool\\" + fileName + ".txt";
				pw = (pw == null) ? new PrintWriter(new FileWriter(path)) : pw;
				for (ResultDetail resultDetail : ResultDetailList) {
					if (sheetFlag) {
						pw.println(
						        "___________________________________________________________________________________________________________________________");
						// pw.print(b);
						pw.println(getCurrentTime() + "FileName:" + resultDetail.getFileName());
						pw.println(getCurrentTime() + "SheetName:" + resultDetail.getSheetName());

						sheetFlag = false;

						if (devTesterNameList != null && !devTesterNameList.isEmpty()) {
							String dev = devTesterNameList.get(0);
							if (dev != null && dev.isEmpty()) {
								pw.println(getCurrentTime() + "Developer Name:\"not filled\"");
								iscompleteFlag = false;
							}
							String tester = new String();
							if (!isUiUx) {
								tester = devTesterNameList.get(1);
								if (tester != null && tester.isEmpty()) {
									pw.println(getCurrentTime() + "Tester Name:\"not filled\"");
									iscompleteFlag = false;
								}
							}
							devTesterNameList = null;
						}

						pw.println(getCurrentTime() + "Result Details:");
					}

					if (!isUiUx) {
						if (resultDetail.getResult1() != null && resultDetail.getBugId1() != null
						        && resultDetail.getDate1() != null) {
							lineNoFlag = false;
							if (resultDetail.getResult1().equalsIgnoreCase("fail")
							        && resultDetail.getNote1().isEmpty()) {

								pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
								        + "[<STEP-6>CheckedDate:" + checkEmpty(resultDetail.getDate1()) + " , Result:"
								        + checkEmpty(resultDetail.getResult1()) + " , Bug No:"
								        + checkEmpty(resultDetail.getBugId1()) + " , Notes: \"not filled\"" + "],");
							} else {
								String bugNo = (resultDetail.getResult1().equalsIgnoreCase("pass")
								        && resultDetail.getBugId1().isEmpty()) ? ""
								                : " , Bug No:" + checkEmpty(resultDetail.getBugId1());
								pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
								        + "[<STEP-6>CheckedDate:" + checkEmpty(resultDetail.getDate1()) + " , Result:"
								        + checkEmpty(resultDetail.getResult1()) + bugNo + "],");
							}
							iscompleteFlag = false;
						}
						if (resultDetail.getResult2() != null && resultDetail.getBugId2() != null
						        && resultDetail.getDate2() != null) {
							if (lineNoFlag) {
								if (resultDetail.getResult2().equalsIgnoreCase("fail")
								        && resultDetail.getNote2().isEmpty()) {
									pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
									        + "[<STEP-8>CheckedDate:" + checkEmpty(resultDetail.getDate2())
									        + " , Result:" + checkEmpty(resultDetail.getResult2()) + " , Bug No:"
									        + checkEmpty(resultDetail.getBugId2()) + " , Notes: \"not filled\"" + "],");
								} else {
									String bugNo = (resultDetail.getResult2().equalsIgnoreCase("pass")
									        && resultDetail.getBugId2().isEmpty()) ? ""
									                : " , Bug No:" + checkEmpty(resultDetail.getBugId2());
									pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
									        + "[<STEP-8>CheckedDate:" + checkEmpty(resultDetail.getDate2())
									        + " , Result:" + checkEmpty(resultDetail.getResult2()) + bugNo + "],");
								}

							} else {
								if (resultDetail.getResult2().equalsIgnoreCase("fail")
								        && resultDetail.getNote2().isEmpty()) {
									pw.print("[<STEP-8>CheckedDate:" + checkEmpty(resultDetail.getDate2())
									        + " , Result:" + checkEmpty(resultDetail.getResult2()) + " , Bug No:"
									        + checkEmpty(resultDetail.getBugId2()) + " , Notes: \"not filled\"" + "],");

								} else {
									String bugNo = (resultDetail.getResult2().equalsIgnoreCase("pass")
									        && resultDetail.getBugId2().isEmpty()) ? ""
									                : " , Bug No:" + checkEmpty(resultDetail.getBugId2());
									pw.print("[<STEP-8>CheckedDate:" + checkEmpty(resultDetail.getDate2())
									        + " , Result:" + checkEmpty(resultDetail.getResult2()) + bugNo + "],");
								}

							}
							lineNoFlag = false;
							iscompleteFlag = false;
						}

						if (resultDetail.getResult3() != null && resultDetail.getBugId3() != null
						        && resultDetail.getDate3() != null) {
							if (lineNoFlag) {
								if (resultDetail.getResult3().equalsIgnoreCase("fail")
								        && resultDetail.getNote3().isEmpty()) {
									pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
									        + "[<STEP-1>CheckedDate:" + checkEmpty(resultDetail.getDate3())
									        + " , Result:" + checkEmpty(resultDetail.getResult3()) + " , Bug No:"
									        + checkEmpty(resultDetail.getBugId3()) + " , Notes: \"not filled\"" + "],");
								} else {
									String bugNo = (resultDetail.getResult3().equalsIgnoreCase("pass")
									        && resultDetail.getBugId3().isEmpty()) ? ""
									                : " , Bug No:" + checkEmpty(resultDetail.getBugId3());
									pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
									        + "[<STEP-1>CheckedDate:" + checkEmpty(resultDetail.getDate3())
									        + " , Result:" + checkEmpty(resultDetail.getResult3()) + bugNo + "],");
								}

							} else {
								if (resultDetail.getResult3().equalsIgnoreCase("fail")
								        && resultDetail.getNote3().isEmpty()) {
									pw.print("[<STEP-1>CheckedDate:" + checkEmpty(resultDetail.getDate3())
									        + " , Result:" + checkEmpty(resultDetail.getResult3()) + " , Bug No:"
									        + checkEmpty(resultDetail.getBugId3()) + " , Notes: \"not filled\"" + "],");
								} else {
									String bugNo = (resultDetail.getResult3().equalsIgnoreCase("pass")
									        && resultDetail.getBugId3().isEmpty()) ? ""
									                : " , Bug No:" + checkEmpty(resultDetail.getBugId3());
									pw.print("[<STEP-1>CheckedDate:" + checkEmpty(resultDetail.getDate3())
									        + " , Result:" + checkEmpty(resultDetail.getResult3()) + bugNo + "],");
								}

							}
							lineNoFlag = false;
							iscompleteFlag = false;
						}

						if (resultDetail.getResult4() != null && resultDetail.getBugId4() != null
						        && resultDetail.getDate4() != null) {
							if (lineNoFlag) {
								if (resultDetail.getResult4().equalsIgnoreCase("fail")
								        && resultDetail.getNote4().isEmpty()) {
									pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
									        + "[<STEP-2>CheckedDate:" + checkEmpty(resultDetail.getDate4())
									        + " , Result:" + checkEmpty(resultDetail.getResult4()) + " , Bug No:"
									        + checkEmpty(resultDetail.getBugId4()) + " , Notes: \"not filled\"" + "]");
								} else {
									String bugNo = (resultDetail.getResult4().equalsIgnoreCase("pass")
									        && resultDetail.getBugId4().isEmpty()) ? ""
									                : " , Bug No:" + checkEmpty(resultDetail.getBugId4());
									pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
									        + "[<STEP-2>CheckedDate:" + checkEmpty(resultDetail.getDate4())
									        + " , Result:" + checkEmpty(resultDetail.getResult4()) + bugNo + "]");
								}

							} else {
								if (resultDetail.getResult4().equalsIgnoreCase("fail")
								        && resultDetail.getNote4().isEmpty()) {
									pw.print("[<STEP-2>CheckedDate:" + checkEmpty(resultDetail.getDate4())
									        + " , Result:" + checkEmpty(resultDetail.getResult4()) + " , Bug No:"
									        + checkEmpty(resultDetail.getBugId4()) + " , Notes: \"not filled\"" + "]");
								} else {
									String bugNo = (resultDetail.getResult4().equalsIgnoreCase("pass")
									        && resultDetail.getBugId4().isEmpty()) ? ""
									                : " , Bug No:" + checkEmpty(resultDetail.getBugId4());
									pw.print("[<STEP-2>CheckedDate:" + checkEmpty(resultDetail.getDate4())
									        + " , Result:" + checkEmpty(resultDetail.getResult4()) + bugNo + "]");
								}

							}
							lineNoFlag = false;
							iscompleteFlag = false;
						}
					} else {
						lineNoFlag = false;
						if (resultDetail.getResult1().equalsIgnoreCase("fail") && resultDetail.getNote1().isEmpty()) {

							pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
							        + "[<STEP-2>CheckedDate:" + checkEmpty(resultDetail.getDate1()) + " , Result:"
							        + checkEmpty(resultDetail.getResult1()) + " , Bug No:"
							        + checkEmpty(resultDetail.getBugId1()) + " , Notes: \"not filled\"" + "],");
						} else {
							String bugNo = (resultDetail.getResult1().equalsIgnoreCase("pass")
							        && resultDetail.getBugId1().isEmpty()) ? ""
							                : " , Bug No:" + checkEmpty(resultDetail.getBugId1());
							pw.print(getCurrentTime() + "Line No:" + resultDetail.getRowNumber() + " -> "
							        + "[<STEP-2>CheckedDate:" + checkEmpty(resultDetail.getDate1()) + " , Result:"
							        + checkEmpty(resultDetail.getResult1()) + bugNo + "],");
						}
						iscompleteFlag = false;
					}
					if (!lineNoFlag) {
						pw.println();
						lineNoFlag = true;
					}
				}
				pw.flush();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private String checkEmpty(String str) {
		if ((str != null && str.isEmpty()) || str == null) {
			return "\"not filled\"";
		}
		return str;
	}

	private String getCurrentTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String time = formatter.format(date);
		return "[" + time + "] ";
	}

	private List<ResultDetail> getCellValueRowNumberLatestForUiUx(int row, int column, int sheetNumber,
	        String fileName) {

		List<ResultDetail> ResultDetailList = new ArrayList<>();
		XSSFSheet reviewSheet = workBook.getSheetAt(sheetNumber);
		int eol = reviewSheet.getLastRowNum();
		for (int i = 0; i <= (eol - row); i++) {

			// for (int i = 0; i <= reviewSheet.getLastRowNum(); i++) {

			if (Objects.nonNull(reviewSheet.getRow(row + i))
			        && Objects.nonNull(reviewSheet.getRow(row + i).getCell(3))) {
				XSSFCell viewPointCell = reviewSheet.getRow(row + i).getCell(3);
				String viewPointValue = viewPointCell == null ? "" : viewPointCell.toString();
				if (viewPointValue != null && !viewPointValue.isEmpty()) {

					XSSFCell reviewSheetCell = reviewSheet.getRow(row + i).getCell(column);
					String resultCellValue1 = reviewSheetCell.toString();
					String bugTicket1 = reviewSheet.getRow(row + i).getCell(column + 1).toString();
					String dateValue1 = "";
					Date date1 = null;
					String notes1 = "";

					try {
						dateValue1 = reviewSheet.getRow(row + i).getCell(column - 1).getDateCellValue() != null
						        ? reviewSheet.getRow(row + i).getCell(column - 1).getDateCellValue().toString()
						        : "";
						date1 = dateValue1 != "" ? reviewSheet.getRow(row + i).getCell(column - 1).getDateCellValue()
						        : null;
						dateValue1 = dateValue1 != ""
						        ? date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toString()
						        : "";
					} catch (IllegalStateException e) {
						e.printStackTrace();
						dateValue1 = reviewSheet.getRow(row + i).getCell(column - 1).toString();
					}

					try {
						notes1 = reviewSheet.getRow(row + i).getCell(column + 2).toString();
					} catch (Exception e) {
						e.printStackTrace();
					}

					resultCellValue1 = resultCellValue1 == null ? "" : resultCellValue1.trim();

					ResultDetail resultDetail = new ResultDetail();

					resultDetail.setSheetName(reviewSheet.getSheetName());
					resultDetail.setFileName(fileName);

					if (resultCellValue1.isEmpty() || resultCellValue1.equalsIgnoreCase("fail")) {
						resultDetail.setResult1(resultCellValue1);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId1(bugTicket1);
						resultDetail.setDate1(dateValue1);
						resultDetail.setNote1(notes1);
						ResultDetailList.add(resultDetail);
					} else if ((resultCellValue1.equalsIgnoreCase("pass")
					        || resultCellValue1.equalsIgnoreCase("no need"))
					        && (dateValue1 == null || dateValue1.isEmpty())) {
						resultDetail.setResult1(resultCellValue1);
						resultDetail.setRowNumber(row + i + 1);
						resultDetail.setBugId1(bugTicket1);
						resultDetail.setDate1(dateValue1);
						resultDetail.setNote1(notes1);
						ResultDetailList.add(resultDetail);
					}
				}
			} else {
				break;
			}
		}

		writeResultDetailsLatest(ResultDetailList, fileName, true);
		return ResultDetailList;
	}

	private List<String> getDeveloperTesterNameUiUx(int row, int column, int sheetNumber) {

		devTesterNameList = new ArrayList<>();

		XSSFSheet reviewSheet = workBook.getSheetAt(sheetNumber);

		XSSFCell devNameCell = reviewSheet.getRow(row).getCell(column);
		String devName = devNameCell.toString();

		devTesterNameList.add(devName);

		return devTesterNameList;
	}

}
