package validator.testcase.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import validator.testcase.service.ReviewTargetTest;

@RestController
@RequestMapping("reviewtest/")
public class ReviewTargetController {

	@Autowired
	private ReviewTargetTest reviewTargetTest;

	@PostMapping("/reviewresult")
	@CrossOrigin
	public void doReviewTargetTest(MultipartFile file, String testCaseFormat, HttpServletResponse response) {
		File f = new File("D:\\ReviewResult\\temp\\" + file.getOriginalFilename());
		try {
			file.transferTo(f);
			reviewTargetTest.doReview(f, testCaseFormat);
			File outputFile = new File("D:\\ReviewResult\\outfromtool\\" + file.getOriginalFilename() + ".txt");
			InputStream inputStream = new FileInputStream(outputFile);
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition",
			        "attachment; filename=" + outputFile.getName().split("\\.")[0] + ".txt");
			IOUtils.copy(inputStream, response.getOutputStream());
			inputStream.close();
			response.flushBuffer();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
