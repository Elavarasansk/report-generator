package com.verupsql.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.verupsql.model.AcapQueryResult;

@Component
public class VerUpSqlDao {
	Connection conn = null;

	public void excuteSingleSqlQuery(AcapQueryResult acapQueryResult, Map<String, String> infoMap, String selectedDB)
			throws ClassNotFoundException, SQLException {
		Statement st = null;
		try {
			st = conn.createStatement();
			st.executeQuery(acapQueryResult.getQuery());
			acapQueryResult.setExecSuccess(true);
			acapQueryResult.setSqlErrorCode(1);
		} catch (SQLException e) {
			acapQueryResult.setSqlErrorMessage(e.getMessage() == null ? "" : e.getMessage());
			acapQueryResult.setSqlErrorCode(e.getErrorCode());
			acapQueryResult.setExecSuccess(false);
		} catch (NullPointerException e) {
			acapQueryResult.setSqlErrorMessage(e.getMessage() == null ? "" : e.getMessage());
			acapQueryResult.setSqlErrorCode(-1);
			acapQueryResult.setExecSuccess(false);
		} finally {
			st.close();
		}

	}

	private static Connection getConnection(Map<String, String> infoMap) throws ClassNotFoundException, SQLException {
		Class.forName(infoMap.get("driver"));
		return DriverManager.getConnection(infoMap.get("connstr"), infoMap.get("user"), infoMap.get("pass"));
	}

	public void connectDatabase(Map<String, String> infoMap, String selectedDB)
			throws ClassNotFoundException, SQLException {
		Class.forName(infoMap.get("driver"));
		if (selectedDB.equals("36")) {
			conn = DriverManager.getConnection(infoMap.get("connstr_36"), infoMap.get("user_36"),
					infoMap.get("pass_36"));
		} else if (selectedDB.equals("40")) {
			conn = DriverManager.getConnection(infoMap.get("connstr_40"), infoMap.get("user_40"),
					infoMap.get("pass_40"));
		}

	}
}
