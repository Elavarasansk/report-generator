package com.verupsql.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.verupsql.service.INIAccessor;
import com.verupsql.service.VerUpSqlService;
import com.verupsql.service.csv.CsvWriter;
import com.verupsql.service.csv.CsvWriterException;


@RestController
public class VerUpSqlController {
	private static Map<String, String> infoMap = new HashMap<String, String>();
	private static String path1 = Paths.get("").toAbsolutePath().toString();

	@Autowired
	private VerUpSqlService verUpSqlService;

	@RequestMapping("/")
	public String index() {
		return "Successfully created";
	}

	@PostMapping("/executeSql")
	public void executeSql(@RequestParam("directoryPath") String directoryPath,
			@RequestParam("selectedDB") String selectedDB)
					throws IOException, CsvWriterException, ClassNotFoundException, SQLException, NumberFormatException, InterruptedException {
		List<File> sqlFileListList = new ArrayList<File>();
		System.out.println(directoryPath + "" + "" + selectedDB);
		getParam();
		sqlFileListList = getFilesPath(infoMap.get("inputPath"));
		writeAllInCsv(sqlFileListList);
		verUpSqlService.executeAllSql(sqlFileListList, infoMap,selectedDB);
	}

	private static List<File> getFilesPath(String mainDirectoryPath) {
		List<File> resultFilesDetailsList = new ArrayList<File>();
		File readFile = new File(mainDirectoryPath);
		File[] allFilesFromDirectory = readFile.listFiles();
		for (File filesNames : allFilesFromDirectory) {
			boolean isFile = filesNames.isFile();
			if (isFile) {
				if (filesNames.getPath().toString().endsWith("sql")) {
					resultFilesDetailsList.add(filesNames);
				}
			} else if (filesNames.isDirectory()) {
				getFilesPath(filesNames.getAbsolutePath(), resultFilesDetailsList);
			}
		}
		return resultFilesDetailsList;
	}

	private static List<File> getFilesPath(String mainDirectoryPath, List<File> allFilesDetailsList) {
		File readFile = new File(mainDirectoryPath);
		File[] allFilesFromDirectory = readFile.listFiles();
		for (File filesNames : allFilesFromDirectory) {
			boolean isFile = filesNames.isFile();
			if (isFile) {
				if (filesNames.getPath().toString().endsWith("sql")) {
					allFilesDetailsList.add(filesNames);
				}
			} else if (filesNames.isDirectory()) {
				getFilesPath(filesNames.getAbsolutePath(), allFilesDetailsList);
			}
		}
		return allFilesDetailsList;
	}

	private static void writeAllInCsv(List<File> exucutedResultList) throws IOException, CsvWriterException {
		CsvWriter out = new CsvWriter(path1 + "\\" + infoMap.get("totalFiles"));
		out.open();
		out.writeln(new String[] { "SQL Files" });
		exucutedResultList.stream().forEach(action -> {
			try {
				out.writeln(new String[] { action.getAbsolutePath().replace(infoMap.get("inputPath"), "") });
			} catch (IOException e) {
				e.printStackTrace();
			} catch (CsvWriterException e) {
				e.printStackTrace();
			}
		});
		out.close();
	}

	private static void getParam() throws IOException {
		INIAccessor ini = new INIAccessor(path1 + "\\tools.ini");
		infoMap.put("path1", path1);
		infoMap.put("driver", ini.getValueAsString("DRIVER", "JDBC"));
		infoMap.put("connstr_36", ini.getValueAsString("DATABASE_36", "URL"));
		infoMap.put("connstr_40", ini.getValueAsString("DATABASE_40", "URL"));
		infoMap.put("user_36", ini.getValueAsString("DATABASE_36", "USER"));
		infoMap.put("user_40", ini.getValueAsString("DATABASE_40", "USER"));
		infoMap.put("pass_36", ini.getValueAsString("DATABASE_36", "PASS"));
		infoMap.put("pass_40", ini.getValueAsString("DATABASE_40", "PASS"));
		infoMap.put("inputPath", ini.getValueAsString("INPUT", "INPUT"));
		infoMap.put("outputExResult", ini.getValueAsString("OUTPUTEX", "OUTPUTEX"));
		infoMap.put("outputNotExResult", ini.getValueAsString("OUTPUTNOTEX", "OUTPUTNOTEX"));
		infoMap.put("outputInvalidNumberResult", ini.getValueAsString("INVALIDNUMBEROUTPUT", "INVALIDNUMBEROUTPUT"));
		infoMap.put("outputInvalidStatementResult",ini.getValueAsString("INVALIDSTATEMENTOUTPUT", "INVALIDSTATEMENTOUTPUT"));
		infoMap.put("outputInvalidYearResult", ini.getValueAsString("INVALIDYEAROUTPUT", "INVALIDYEAROUTPUT"));
		infoMap.put("updateQueryResult", ini.getValueAsString("UPDATEQUERY", "UPDATEQUERY"));
		infoMap.put("consoleLog", ini.getValueAsString("CONSOLE", "CONSOLE"));
		infoMap.put("totalFiles", ini.getValueAsString("TOTALFILES", "FILES"));
		ini.close();
	}
}