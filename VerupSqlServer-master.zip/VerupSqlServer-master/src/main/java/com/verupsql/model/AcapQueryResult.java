package com.verupsql.model;

public class AcapQueryResult {
	private boolean updateQuery = false;
	private String queryId ="-1";
	private String queryNm ="";
	private String query = "";
	private boolean execSuccess = false;
	private int	sqlErrorCode = -1;
	private String sqlErrorMessage = "";
	private long execDuration = -1;
	private long rowCount = -1;
	private String fullPath = "";

	public AcapQueryResult(){
	}

	public void setUpdateQuery(boolean updateQuery) {
		this.updateQuery = updateQuery;
	}

	public Boolean getUpdateQuery() {
		return updateQuery;
	}

	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}

	public String getQueryId() {
		return queryId;
	}

	public String getQueryNm() {
		return queryNm;
	}
	public void setQueryNm(String queryNm) {
		this.queryNm = queryNm;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getFullPath() {
		return fullPath;
	}

	public void setFullPath(String fullPath) {
		this.fullPath = fullPath;
	}

	public boolean isExecSuccess() {
		return execSuccess;
	}
	public void setExecSuccess(boolean execSuccess) {
		this.execSuccess = execSuccess;
	}
	public int getSqlErrorCode() {
		return sqlErrorCode;
	}
	public void setSqlErrorCode(int sqlErrorCode) {
		this.sqlErrorCode = sqlErrorCode;
	}
	public String getSqlErrorMessage() {
		return sqlErrorMessage;
	}
	public void setSqlErrorMessage(String sqlErrorMessage) {
		this.sqlErrorMessage = sqlErrorMessage;
	}
	public long getExecDuration() {
		return execDuration;
	}
	public void setExecDuration(long execDuration) {
		this.execDuration = execDuration;
	}

	public long getRowCount() {
		return rowCount;
	}

	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
	}
}
