package com.verupsql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerUpSqlApplication {
	public static void main(String[] args) {
		SpringApplication.run(VerUpSqlApplication.class, args);
	}
}