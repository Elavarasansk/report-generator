package com.verupsql.service.csv;

public class CsvWriterException extends Exception{
	//�«—ˆ‰½‚©‚â‚é—p‚ÉException‚ðŠO‚¾‚µ
	public CsvWriterException(String msg){
		super(msg);
	}
}
