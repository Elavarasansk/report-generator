package com.verupsql.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Vector;

public class INIAccessor {
	private boolean debuggingMode = false;
	private String fileName = "";
	private String encoding = System.getProperty("file.encoding");
	private Vector<String> sections = null;
	private Vector<Boolean> commentedsec = null;
	private HashMap<String, Vector<String>> keys = null;
	private HashMap<String, Vector<String>> values = null;
	private HashMap<String, Vector<Boolean>> commentedkey = null;

	public INIAccessor(String fileName, String file_encoding) {
		this.encoding = file_encoding;
		this.fileName = fileName;
		sections = new Vector<String>();
		commentedsec = new Vector<Boolean>();
		keys = new HashMap<String, Vector<String>>();
		values = new HashMap<String, Vector<String>>();
		commentedkey = new HashMap<String, Vector<Boolean>>();

		if (isFileExists(this.fileName)) {
			load();
		}
	}

	public INIAccessor(String fileName) {
		this.fileName = fileName;
		sections = new Vector<String>();
		commentedsec = new Vector<Boolean>();
		keys = new HashMap<String, Vector<String>>();
		values = new HashMap<String, Vector<String>>();
		commentedkey = new HashMap<String, Vector<Boolean>>();

		if (isFileExists(this.fileName)) {
			load();
		}
	}

	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	public boolean isDebuggingMode() {
		return debuggingMode;
	}

	public void setDebuggingMode(boolean debuggingMode) {
		this.debuggingMode = debuggingMode;
	}

	public boolean load() {
		try {
			clear();
			BufferedReader ini = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), encoding));
			String line = ini.readLine();
			String section = "";
			boolean comsec = false;
			boolean comline = false;
			Vector<String> key = null;
			Vector<String> val = null;
			Vector<Boolean> com = null;

			while (line != null) {
				if (line.trim().equals("")) {
				} else if (isSectionLine(line) || isSectionCommentLine(line)) {
					if (!section.equals("")) {
						sections.add(section);
						commentedsec.add(comsec);
						keys.put(section, key);
						values.put(section, val);
						commentedkey.put(section, com);
					}
					section = getSectionName(line, comsec);
					comsec = isSectionCommentLine(line);
					key = new Vector<String>();
					val = new Vector<String>();
					com = new Vector<Boolean>();
				} else {

					if (line.trim().equals("")) {
					} else {
						comline = isCommentLine(line);
						key.add(getLineKey(line, comline));
						val.add(getLineValue(line));
						com.add(comline);
					}
				}

				line = ini.readLine();
			}
			sections.add(section);
			commentedsec.add(comsec);
			keys.put(section, key);
			values.put(section, val);
			commentedkey.put(section, com);
			ini.close();

		} catch (FileNotFoundException e) {
			putDebugLog(e.getLocalizedMessage());
			return false;
		} catch (IOException e) {
			putDebugLog(e.getLocalizedMessage());
			return false;
		}

		return true;
	}

	public boolean flush() {
		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), encoding));

			String wk = "";
			Vector<String> wkKeys = null;
			Vector<String> wkVals = null;
			Vector<Boolean> wkComs = null;

			for (int iSections = 0; iSections <= sections.size() - 1; iSections++) {

				wk = "[" + sections.get(iSections) + "]";
				if (commentedsec.get(iSections)) {
					wk = "#" + wk;
				}
				out.write(wk);
				out.newLine();

				wkKeys = keys.get(sections.get(iSections));
				wkVals = values.get(sections.get(iSections));
				wkComs = commentedkey.get(sections.get(iSections));

				for (int iKeys = 0; iKeys <= wkKeys.size() - 1; iKeys++) {
					wk = wkKeys.get(iKeys) + "=" + wkVals.get(iKeys);
					if (wkComs.get(iKeys)) {
						wk = "#" + wk;
					}
					out.write(wk);
					out.newLine();
				}

				out.newLine();
			}
			out.close();
			out = null;
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	public void print() {
		String wk = "";
		Vector<String> wkKeys = null;
		Vector<String> wkVals = null;
		Vector<Boolean> wkComs = null;

		for (int iSections = 0; iSections <= sections.size() - 1; iSections++) {
			wk = "[" + sections.get(iSections) + "]";
			if (commentedsec.get(iSections)) {
				wk = "#" + wk;
			}
			System.out.println(wk);

			wkKeys = keys.get(sections.get(iSections));
			wkVals = values.get(sections.get(iSections));
			wkComs = commentedkey.get(sections.get(iSections));

			for (int iKeys = 0; iKeys <= wkKeys.size() - 1; iKeys++) {
				wk = wkKeys.get(iKeys) + "=" + wkVals.get(iKeys);
				if (wkComs.get(iKeys)) {
					wk = "#" + wk;
				}
				System.out.println(wk);
			}
			System.out.println("");
		}
	}

	public void close() {
		clear();
		sections = null;
		commentedsec = null;
		keys = null;
		values = null;
		commentedkey = null;
	}

	private void putDebugLog(String msg) {
		if (debuggingMode) {
			System.out.println(msg);
		}
	}

	private boolean isFileExists(String filename) {
		File f = new File(filename);
		return (f.isFile() && f.exists());
	}

	private void clear() {
		sections.clear();
		commentedsec.clear();
		keys.clear();
		values.clear();
		commentedkey.clear();
	}

	private boolean isSectionLine(String line) {
		String wk = line.trim();
		return ((wk.startsWith("[")) && (wk.endsWith("]")));
	}

	private boolean isSectionCommentLine(String line) {
		String wk = line.trim();
		return ((wk.startsWith("#[")) && (wk.endsWith("]")));
	}

	private boolean isCommentLine(String line) {
		return line.trim().startsWith("#");
	}

	private String getSectionName(String line, boolean isCommented) {
		String wk = line.trim();
		int startpos = 1;
		if (isCommented) {
			startpos++;
		}

		int endpos = wk.lastIndexOf("]");
		return wk.substring(startpos, endpos);
	}

	private String getLineKey(String line, boolean isCommented) {
		String wk = line.trim();
		int startpos = 0;
		if (isCommented) {
			startpos++;
		}

		int pos = wk.indexOf("=");
		if (pos <= 0) {
			return "";
		}
		return wk.substring(startpos, pos);
	}

	private String getLineValue(String line) {
		String wk = line.trim();
		wk = wk.substring(wk.indexOf("=") + 1);
		if (wk == null) {
			wk = "";
		}
		return wk;
	}

	private int indexOfIgnoreCase(Vector<String> wkvec, String s) {
		for (int i = 0; i <= wkvec.size() - 1; i++) {
			if (s.equalsIgnoreCase(wkvec.get(i))) {
				return i;
			}
		}
		return -1;
	}

	private String getIgnoreCaseStr(Vector<String> wkvec, String s) {
		for (int i = 0; i <= wkvec.size() - 1; i++) {
			if (s.equalsIgnoreCase(wkvec.get(i))) {
				return wkvec.get(i);
			}
		}
		return "";
	}

	public Vector<String> getSections() {
		return sections;
	}

	public Vector<String> getKeys(String section) {
		String wksec = getIgnoreCaseStr(sections, section);
		return keys.get(wksec);
	}

	public String getValueAsString(String section, String key) {
		String wk = null;
		String wksec = getIgnoreCaseStr(sections, section);

		if (!wksec.equals("")) {
			Vector<String> wkkey = keys.get(wksec);
			Vector<String> wkval = values.get(wksec);
			Vector<Boolean> wkcom = commentedkey.get(wksec);
			int pos = indexOfIgnoreCase(wkkey, key);

			if (pos >= 0) {
				if (wkcom.get(pos).equals(false)) {
					wk = wkval.get(pos);
				}
			}
		}
		return wk;
	}

	public String getValueAsString(String section, String key, String defval) {
		String wk = getValueAsString(section, key);
		return (wk == null) ? defval : wk;
	}

	public void setValue(String section, String key, String val) {
		String wksec = getIgnoreCaseStr(sections, section);

		if (wksec.equals("")) {
			sections.add(section);
			commentedsec.add(false);
			Vector<String> newkey = new Vector<String>();
			Vector<String> newval = new Vector<String>();
			Vector<Boolean> newcom = new Vector<Boolean>();
			newkey.add(key);
			newval.add(val);
			newcom.add(false);

			keys.put(section, newkey);
			values.put(section, newval);
			commentedkey.put(section, newcom);
		} else {
			Vector<String> seckey = keys.get(wksec);
			Vector<String> secval = values.get(wksec);
			Vector<Boolean> seccom = commentedkey.get(wksec);

			int pos = indexOfIgnoreCase(seckey, key);
			if (pos >= 0) {
				secval.set(pos, val);
				if (seccom.get(pos).equals(true)) {
					seccom.set(pos, false);
				}
			} else {
				seckey.add(key);
				secval.add(val);
				seccom.add(false);
			}
		}
	}
}
