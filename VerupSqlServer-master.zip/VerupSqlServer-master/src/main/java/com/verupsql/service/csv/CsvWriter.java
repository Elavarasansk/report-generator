package com.verupsql.service.csv;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;	

public class CsvWriter {
	public enum EnclosureType {
		eu_None, eu_SeparatorIncluded, eu_Always
	}

	//properties
	private String separator = ",";
	private String EnclosureChar = "\"";
	private EnclosureType encloseType = EnclosureType.eu_Always;
	private String fileName = null;

	//internal
	private boolean isOpened = false;
	private BufferedWriter out = null;

	public CsvWriter() {

	}

	public CsvWriter(String fileName) {
		this.fileName = fileName;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	public EnclosureType getEncloseType() {
		return encloseType;
	}

	public void setEncloseType(EnclosureType encloseType) {
		this.encloseType = encloseType;
	}

	public String getEnclosureChar() {
		return EnclosureChar;
	}

	public void setEnclosureChar(String enclosureChar) {
		EnclosureChar = enclosureChar;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void open() throws CsvWriterException, IOException {
		if (isOpened) {
			CsvWriterException e = new CsvWriterException("‚·‚Å‚Éƒtƒ@ƒCƒ‹‚ðƒI�[ƒvƒ“‚µ‚Ä‚¢‚Ü‚·");
			throw e;
		}

		if (this.fileName == null) {
			CsvWriterException e = new CsvWriterException("ƒtƒ@ƒCƒ‹–¼‚ªŽw’è‚³‚ê‚Ä‚¢‚Ü‚¹‚ñ");
			throw e;
		}

		out = new BufferedWriter(new FileWriter(fileName));
		isOpened = true;
	}

	private String setEnclosure(String val) {
		String ret = val;
		if (ret.contains(this.EnclosureChar)) {
			ret.replace(this.EnclosureChar, this.EnclosureChar + this.EnclosureChar);
		}

		ret = this.EnclosureChar + val + this.EnclosureChar;
		return ret;
	}

	public void writeln(ArrayList<String> values) throws IOException, CsvWriterException {
		String[] strs = new String[values.size()];

		for (int i = 0; i <= values.size() - 1; i++) {
			strs[i] = values.get(i);
		}
		writeln(strs);
	}

	public void writeln(String[] values) throws IOException, CsvWriterException {
		String ln = "";
		String val = "";
		for (int i = 0; i <= values.length - 1; i++) {
			val = values[i];
			switch (this.encloseType) {
			case eu_Always:
				val = setEnclosure(val);
			case eu_SeparatorIncluded:
				if (val.contains(this.separator)) {
					val = setEnclosure(val);
				}
				break;
			default:
				;//do nothing;
			}

			if (ln.length() > 0) {
				val = this.separator + val;
			}

			ln = ln + val;
		}

		writeln(ln);
	}

	public void writeln(String line) throws IOException, CsvWriterException {
		if (!isOpened) {
			CsvWriterException e = new CsvWriterException("ƒtƒ@ƒCƒ‹‚ÍƒI�[ƒvƒ“‚³‚ê‚Ä‚¢‚Ü‚¹‚ñ");
			throw e;
		}
		out.write(line);
		out.newLine();
	}

	public void close() throws IOException, CsvWriterException {
		if (!isOpened) {
			CsvWriterException e = new CsvWriterException("ƒtƒ@ƒCƒ‹‚ÍƒI�[ƒvƒ“‚³‚ê‚Ä‚¢‚Ü‚¹‚ñ");
			throw e;
		}

		out.close();
		out = null;
		isOpened = false;
	}
}
