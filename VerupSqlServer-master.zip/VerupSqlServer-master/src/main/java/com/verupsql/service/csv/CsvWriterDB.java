package com.verupsql.service.csv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import com.verupsql.service.csv.CsvWriter.EnclosureType;
	
public class CsvWriterDB {
	private Connection _conn = null;
	private CsvWriter out = null;

	private boolean outputHeader = true;
	private String dateformat = "yyyy/MM/dd";
	private String timeformat = "HH:mm:ss";

	public CsvWriterDB(Connection conn) {
		_conn = conn;
		out = new CsvWriter();
	}

	public CsvWriterDB(Connection conn, String fileName) {
		_conn = conn;
		out = new CsvWriter();
		setFileName(fileName);
	}

	public void setSeparator(String separator) {
		this.out.setSeparator(separator);
	}

	public void setEnclosureChar(String enclosureChar) {
		this.out.setEnclosureChar(enclosureChar);
	}

	public void setEncloseType(EnclosureType encloseType) {
		this.out.setEncloseType(encloseType);
	}

	public void setFileName(String fileName) {
		this.out.setFileName(fileName);
	}

	public boolean isOutputHeader() {
		return outputHeader;
	}

	public void setOutputHeader(boolean outputHeader) {
		this.outputHeader = outputHeader;
	}

	public String getDateformat() {
		return dateformat;
	}

	public void setDateformat(String dateformat) {
		this.dateformat = dateformat;
	}

	public String getTimeformat() {
		return timeformat;
	}

	public void setTimeformat(String timeformat) {
		this.timeformat = timeformat;
	}

	private String formatDate(Timestamp tm) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateformat);
		return sdf.format(tm);
	}

	private String formatDatetime(Timestamp tm) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateformat + " " + timeformat);
		return sdf.format(tm);
	}

	public void outputCsv(String tableName) throws SQLException, CsvWriterException, IOException {
		String sql = "select * from " + tableName;
		Statement st = _conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
		st.setFetchSize(1000);
		ResultSet rs = st.executeQuery(sql);

		outputCsv(rs);

		rs.close();
		rs = null;
		st.close();
		st = null;
	}

	public void outputCsv(ResultSet rs) throws IOException, CsvWriterException, SQLException {
		ResultSetMetaData meta = rs.getMetaData();
		out.open();

		//ƒwƒbƒ_�[‚Ì�ì�¬‚Æflush
		if (outputHeader) {
			String[] header = new String[meta.getColumnCount()];
			for (int i = 1; i <= meta.getColumnCount(); i++) {
				header[i - 1] = meta.getColumnName(i);
			}
			out.writeln(header);
		}

		//ƒf�[ƒ^�s‚ÌŽæ“¾
		String[] rec = new String[meta.getColumnCount()];

		while (rs.next()) {
			for (int i = 1; i <= meta.getColumnCount(); i++) {
				switch (meta.getColumnType(i)) {
				case java.sql.Types.VARCHAR:
				case java.sql.Types.CLOB:
					rec[i - 1] = rs.getString(i) == null ? "" : rs.getString(i);
					break;
				case java.sql.Types.DATE:
				case java.sql.Types.TIME:
				case java.sql.Types.TIMESTAMP:
					//Žž•ª•b‚ðŠÜ‚Þƒf�[ƒ^‚©‚Ç‚¤‚©‚ðŠm”F
					if (rs.getTimestamp(i) == null) {
						rec[i - 1] = "";
					} else if (!rs.getDate(i).equals(rs.getTimestamp(i))) {
						rec[i - 1] = formatDatetime(rs.getTimestamp(i));
					} else {
						rec[i - 1] = formatDate(rs.getTimestamp(i));
					}
					break;
				case java.sql.Types.NUMERIC:
				case java.sql.Types.INTEGER:
				case java.sql.Types.DOUBLE:
				case java.sql.Types.FLOAT:
					if (meta.getScale(i) > 0) {
						rec[i - 1] = Float.toString(rs.getFloat(i));
					} else if (meta.getScale(i) == 0) {
						rec[i - 1] = Long.toString(rs.getLong(i));
					} else {
						rec[i - 1] = rs.getString(i);
					}

					break;
				default:
					rec[i - 1] = "(Unkown DataType:" + meta.getColumnTypeName(i) + ")";
					break;
				}
			}
			out.writeln(rec);
		}

		out.close();

	}

}
