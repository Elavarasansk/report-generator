package com.verupsql.service;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.tika.parser.txt.CharsetDetector;
import org.apache.tika.parser.txt.CharsetMatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.verupsql.dao.VerUpSqlDao;
import com.verupsql.model.AcapQueryResult;
import com.verupsql.service.csv.CsvWriter;
import com.verupsql.service.csv.CsvWriterException;

@Service
public class VerUpSqlService {
	@Autowired
	private VerUpSqlDao verUpSqlDao;

	public void executeAllSql(List<File> sqlFileListList, Map<String, String> infoMap, String selectedDB)
			throws ClassNotFoundException, SQLException, IOException, CsvWriterException,
			NumberFormatException, InterruptedException {
		Map<Integer, String> executeMap = new HashMap<Integer, String>();
		Map<Integer, AcapQueryResult> outputExMap = new HashMap<Integer, AcapQueryResult>();
		Map<Integer, AcapQueryResult> outputInvalidNumberMap = new HashMap<Integer, AcapQueryResult>();
		Map<Integer, AcapQueryResult> outputInvalidStatementMap = new HashMap<Integer, AcapQueryResult>();
		Map<Integer, AcapQueryResult> outputInvalidYearMap = new HashMap<Integer, AcapQueryResult>();
		Map<Integer, AcapQueryResult> outputNotExMap = new HashMap<Integer, AcapQueryResult>();
		Map<Integer, AcapQueryResult> updateQueryMap = new HashMap<Integer, AcapQueryResult>();
		int count = 1;
		String path = infoMap.get("path1");
		connectDatabase(infoMap, selectedDB);
		for (File inputFile : sqlFileListList) {
			if (inputFile != null) {
				File file = new File(inputFile.toString());
				String readedQuery;
				String readedString;
				try {
					readedQuery = rawFileCreate(file);
					readedString = readedQuery;
					executeMap.put(count, file.getAbsolutePath().replace(infoMap.get("inputPath"), ""));
					try (BufferedWriter bufferedwriter = Files.newBufferedWriter(Paths.get(path + "\\" + infoMap.get("consoleLog")))) {
						bufferedwriter.write("Total No of Files: " + sqlFileListList.size());
						bufferedwriter.newLine();
						bufferedwriter.write("Total No of files executed :" + count);
						bufferedwriter.newLine();
						bufferedwriter.write("Executed Files");
						bufferedwriter.newLine();
						for (Entry<Integer, String> entry : executeMap.entrySet()) {
							bufferedwriter.write(entry.getKey() + "--" + entry.getValue());
							bufferedwriter.newLine();
						}
						bufferedwriter.close();
					}
					count = count + 1;
					AcapQueryResult aqr = new AcapQueryResult();
					processQueryString(readedString, aqr);
					aqr.setQueryNm(file.getName());
					aqr.setFullPath(file.getAbsolutePath());
					if (!aqr.getUpdateQuery()) {
						verUpSqlDao.excuteSingleSqlQuery(aqr, infoMap, selectedDB);
						if (aqr.getSqlErrorCode() == 1) {
							outputExMap.put(count, aqr);
							writInCsv(outputExMap, infoMap.get("outputExResult"),path);
						} else if (aqr.getSqlErrorCode() == 1722 || aqr.getSqlErrorCode() == 1858) {
							outputInvalidNumberMap.put(count, aqr);
							writInCsv(outputInvalidNumberMap, infoMap.get("outputInvalidNumberResult"),path);
						} else if (aqr.getSqlErrorCode() == 900) {
							outputInvalidStatementMap.put(count, aqr);
							writInCsv(outputInvalidStatementMap, infoMap.get("outputInvalidStatementResult"),path);
						} else if (aqr.getSqlErrorCode() == 1841) {
							outputInvalidYearMap.put(count, aqr);
							writInCsv(outputInvalidYearMap, infoMap.get("outputInvalidYearResult"),path);
						} else {
							outputNotExMap.put(count, aqr);
							writInCsv(outputNotExMap, infoMap.get("outputNotExResult"),path);
						}
					} else {
						updateQueryMap.put(count, aqr);
						writInCsv(updateQueryMap, infoMap.get("updateQueryResult"),path);
					}

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.exit(0);

	}
	
	private static void processQueryString(String readedString, AcapQueryResult aqr) {
		String cutString = "";
		String queryId = "";
		int queryIdStartIndex;
		int queryIdEndIndex;
		readedString = dateReplacement(readedString);
		while (readedString.indexOf("{") > 0) {
			int start = readedString.indexOf("{");
			int end = readedString.indexOf("}");
			int startQuote = readedString.indexOf("'{");
			int endQuote = readedString.indexOf("}'");
			String subString = readedString.substring(start, end + 1);
			if ((subString.contains("_STR") && startQuote > 0 && endQuote > 0) || subString.contains("_DATE")) {
				if (subString.contains("YYYYMMDD")) {
					readedString = readedString.replace(subString, "19000101");
				} else if (subString.contains("YYYY/MM")) {
					readedString = readedString.replace(subString, "1900/01");
				} else if (subString.contains("YYYYMM")) {
					readedString = readedString.replace(subString, "190001");
				} else if (subString.contains("YYYY")) {
					readedString = readedString.replace(subString, "1900");
				} else {
					readedString = readedString.replace(subString, "1900/01/01");
				}
			} else if (subString.contains("_STR")) {
				readedString = readedString.replace(subString, "1");
			} else if (subString.contains("_INT")) {
				readedString = readedString.replace(subString, "1");
			} else if (subString.contains("_FLO")) {
				readedString = readedString.replace(subString, "1");
			} else {
				cutString = cutString.concat(readedString.substring(0, end + 1));
				readedString = readedString.substring(end + 1, readedString.length());
			}
		}
		readedString = cutString.concat(readedString);
		queryIdStartIndex = readedString.indexOf("/*");
		queryIdEndIndex = readedString.indexOf("*/");
		while (queryIdStartIndex >= 0 && queryIdEndIndex > 0) {
			String sub = readedString.substring(queryIdStartIndex, queryIdEndIndex + 2);
			if (sub.contains("#")) {
				Pattern queryIdPattern = Pattern.compile("\\d+");
				Matcher queryIdMatcher = queryIdPattern.matcher(sub);
				if (queryIdMatcher.find()) {
					queryId = queryIdMatcher.group(0);
				}
			}
			readedString = readedString.replace(sub, " ");
			queryIdStartIndex = readedString.indexOf("/*");
			queryIdEndIndex = readedString.indexOf("*/");
		}
		readedString = readedString.replaceAll(";", "");
		readedString = removeUnwantedPrefix(readedString.trim(), aqr);
		aqr.setQueryId(queryId);
		aqr.setQuery(readedString);
	}
	
	
	private static String dateReplacement(String readedString) {
		int startIndex;
		int endIndex;
		String subString;
		String replaceString;
		String cutString = "";
		while (readedString.indexOf("TO_DATE('{") > 0) {
			startIndex = readedString.indexOf("TO_DATE('{");
			cutString = readedString.substring(0, startIndex);
			readedString = readedString.substring(startIndex);
			endIndex = readedString.indexOf("')");
			subString = readedString.substring(0, endIndex + 1);
			replaceString = subString;
			if (subString.contains("YYYY/MM/DD")) {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"1900/01/01");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);
			} else if (subString.contains("YYYY-MM-DD")) {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"1900-01-01");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);
			} else if (subString.contains("YYYY/MM")) {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"1900/01");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);

			} else if (subString.contains("MM/YYYY")) {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"01/1900");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);

			} else if (subString.contains("YYYYMMDD")) {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"19000101");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);
			} else if (subString.contains("YYYYMM")) {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"190001");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);

			} else {
				subString = subString.replace(subString.substring(subString.indexOf("{"), subString.indexOf("}") + 1),
						"1900/01/01");
				readedString = readedString.replace(replaceString, subString);
				readedString = cutString.concat(readedString);
			}
		}
		return readedString;
	}

	private static String removeUnwantedPrefix(String readedString, AcapQueryResult aqr) {
		int queryIdStartIndex;
		String substring;
		readedString = readedString.toUpperCase();
		if (readedString.startsWith("UPDATE") || readedString.startsWith("CREATE")) {
			aqr.setUpdateQuery(true);
			aqr.setSqlErrorCode(0);
		}
		if (!(readedString.startsWith("SELECT")) && readedString.indexOf("SELECT") > 0) {
			queryIdStartIndex = readedString.indexOf("SELECT");
			substring = readedString.substring(0, queryIdStartIndex);
			if (substring.contains("CREATE") || substring.contains("UPDATE")) {
				aqr.setUpdateQuery(true);
				aqr.setSqlErrorCode(0);
			} else {
				readedString = readedString.replace(readedString.substring(0, readedString.indexOf("SELECT")), " ");
			}
		}
		String pattern = "-{3,}";
		readedString = readedString.replaceAll(pattern, "");
		return readedString;
	}

	private static String rawFileCreate(File file) throws IOException {
		BufferedInputStream bufferStream = new BufferedInputStream(new FileInputStream(file));
		CharsetDetector cd = new CharsetDetector();
		cd.setText(bufferStream);
		CharsetMatch cm = cd.detect();
		String data = "";
		if (cm.getName() == "UTF-8") {
			data = FileUtils.readFileToString(file, "UTF-8");	
		} else {
			data = FileUtils.readFileToString(file);
		}
		return data;
	}

	private static void writInCsv(Map<Integer, AcapQueryResult> resultMap, String outputFile, String path)
			throws IOException, CsvWriterException {
		CsvWriter out = new CsvWriter(path + "\\" + outputFile);
		out.open();
		out.writeln(new String[] { "QUERY_ID", "QUERY_NM", "SUCCESS", "ERRORCODE", "ERRORMESSAGE" });
		for (Entry<Integer, AcapQueryResult> entry : resultMap.entrySet()) {
			String bol = entry.getValue().isExecSuccess() ? "OK" : "NG";
			try {
				out.writeln(new String[] { entry.getValue().getQueryId(), entry.getValue().getQueryNm(), bol,
						Integer.toString(entry.getValue().getSqlErrorCode()),
						entry.getValue().getSqlErrorMessage().trim() });
			} catch (IOException e) {
				e.printStackTrace();
			} catch (CsvWriterException e) {
				e.printStackTrace();
			}

		}
		out.close();
	}

	public void connectDatabase(Map<String, String> infoMap, String selectedDB)
			throws ClassNotFoundException, SQLException {
		verUpSqlDao.connectDatabase(infoMap, selectedDB);

	}

}
