package iv.intraweb.index;


import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import iv.intraweb.parser.DFMParser;

public class DFMSingleFileProcessFront {

	public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		initializeGui();
	}

	public static void initializeGui() throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());



		JFrame f = new JFrame("Intraweb Tools ");
		f.setBounds(0, 0, 750, 225);
		f.setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel  p1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		p1.setLayout(null);
		JLabel input = new JLabel("Input DFM Path");
		input.setBounds(20, 20, 90, 22);
		p1.add(input);

		JTextField inFile = new JTextField();
		inFile.setText("C:\\HUE\\Workspace\\Develop\\filepath\\FileName.dfm");
		inFile.setBounds(125, 20, 580, 22);
		p1.add(inFile);

		JLabel output = new JLabel("Output DFM Path");
		output.setBounds(20, 52, 90, 22);
		p1.add(output);

		JTextField outFile = new JTextField();
		outFile.setText("C:\\HUE\\Workspace\\Develop\\filepath\\FileName.dfm");
		outFile.setBounds(125, 52, 580, 22);
		p1.add(outFile);

		JButton start = new JButton("Align DFM");
		start.setBounds(530, 84, 150, 22);
		p1.add(start);

		JTabbedPane tp = new JTabbedPane();
		tp.setBounds(0, 0, 750, 225);
		tp.add("Align DFM",p1);
		f.add(tp);
		
		
		JPanel  p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		p2.setLayout(null);
		
		
		JLabel inputPanels = new JLabel("Panel List Path");
		inputPanels.setBounds(20, 20, 90, 22);
		p2.add(inputPanels);

		JTextField inFilePanels = new JTextField();
		inFilePanels.setText("Drive:\\panelpath\\panelfilelist.txt");
		inFilePanels.setBounds(125, 20, 580, 22);
		p2.add(inFilePanels);

		
		JLabel input2 = new JLabel("Input DFM Path");
		input2.setBounds(20, 52, 90, 22);
		p2.add(input2);

		JTextField inFile2 = new JTextField();
		inFile2.setText("C:\\HUE\\Workspace\\Develop\\filepath\\FileName.dfm");
		inFile2.setBounds(125, 52, 580, 22);
		p2.add(inFile2);
		
		
		JLabel output2 = new JLabel("Output DFM Path");
		output2.setBounds(20, 84, 90, 22);
		p2.add(output2);

		JTextField outFile2 = new JTextField();
		outFile2.setText("C:\\HUE\\Workspace\\Develop\\filepath\\FileName.dfm");
		outFile2.setBounds(125, 84, 580, 22);
		p2.add(outFile2);

		JButton start2 = new JButton("Special DFM");
		start2.setBounds(530, 116, 150, 22);
		p2.add(start2);
		
		tp.add("Special DFM",p2);
		f.add(tp);
		
		
//		JPanel  p3 = new JPanel(new FlowLayout(FlowLayout.LEFT));		
//		p3.setLayout(null);
//
//		JLabel input3 = new JLabel("Input DFM");
//		input3.setBounds(20, 20, 80, 22);
//		p3.add(input3);
//
//		JTextField inFile3 = new JTextField();
//		inFile3.setText("C:/HUE/WorkSpace/Develop/hue-ac-chennai-cam/hue_client/delphi/CAM/FA/Report/AltListPlus/CompressedList/CompressedListFrmPlus_old.dfm");
//		inFile3.setBounds(100, 20, 580, 22);
//		p3.add(inFile3);
//
//		JLabel output3 = new JLabel("Output DFM");
//		output3.setBounds(20, 52, 80, 22);
//		p3.add(output3);
//
//		JTextField outFile3 = new JTextField();
//		outFile3.setText("C:/HUE/WorkSpace/Develop/hue-ac-chennai-cam/hue_client/delphi/CAM/FA/Report/AltListPlus/CompressedList/CompressedListFrmPlus.dfm");
//		outFile3.setBounds(100, 52, 580, 22);
//		p3.add(outFile3);
//
//		JButton start3 = new JButton("Fix Color");
//		start3.setBounds(530, 84, 150, 22);
//		p3.add(start3);
//		
//		tp.add("Color code",p3);
//		f.add(tp);

		start.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {              
				try {
					File inputFile = new File(inFile.getText());
					if(!inputFile.exists())
						JOptionPane.showMessageDialog(f, "Input DFM file does not exists.");
					else {
						DFMParser.callConvert(inFile.getText(), outFile.getText(), "", false);
						JOptionPane.showMessageDialog(f, "DFM file aligned successfully.");
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		start2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {              
				try {
					File inputFile = new File(inFile2.getText());
					File panelsFile = new File(inFilePanels.getText());
					
					if(!panelsFile.exists())
						JOptionPane.showMessageDialog(f, "Panels list file does not exists.");
					else if(!inputFile.exists())
						JOptionPane.showMessageDialog(f, "Input DFM file does not exists.");
					else {
						DFMParser.callConvert(inFile2.getText(), outFile2.getText(), inFilePanels.getText(), true);
						JOptionPane.showMessageDialog(f, "DFM file aligned successfully.");
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		});
		
		
//		start3.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {              
//				try {
//					DFMParser.callConvert(inFile3.getText(), outFile3.getText());
//				} catch (IOException e1) {
//					e1.printStackTrace();
//				}
//
//
//			}
//		});
	}

}
