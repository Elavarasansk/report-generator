package iv.intraweb.aligner;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import iv.intraweb.entity.ComponentStructure;
import iv.intraweb.entity.DFMObject;

public class DFMPanelArranger {





	public static void getPanelList(DFMObject dfmObject,List<String> panelList) {		

		for( DFMObject dfmData  :  dfmObject.getChild()) {
			if(CollectionUtils.isNotEmpty(dfmData.getChild())){
				getPanelList(dfmData,panelList);
				if(CollectionUtils.isNotEmpty(dfmData.getChild()) && StringUtils.containsIgnoreCase(dfmData.getClassName(),"Panel")) {
					panelList.add(dfmData.getClassName().trim());
				}

			}
		}
	}

	private static int getData(DFMObject node, String paramKey) {
		AtomicReference<String> value = new AtomicReference<>(String.valueOf(0));
		if(	node.getData() != null) {
			node.getData().forEach((k, v) -> {
				if (k.trim().equalsIgnoreCase(paramKey)) {
					value.set(v.toString());
				}
			});
		}
		return Integer.valueOf(value.get()).intValue();
	}


	private static boolean isExist(DFMObject node, String paramKey) {
		boolean result = false;
		if(MapUtils.isNotEmpty(node.getData())) {
			return node.getData().entrySet()
					.stream()
					.filter(dfm-> StringUtils.equalsIgnoreCase(dfm.getKey().trim(),paramKey))
					.collect(Collectors.toList()).size() > 0;
		}
		return result;
	}



	public static int getPanelPropertyValue(DFMObject dfmData,String key) {		
		if(CollectionUtils.isNotEmpty(dfmData.getChild())) {
			return dfmData.getChild().stream().map(data->{
				if(MapUtils.isNotEmpty(data.getData())) {
					String top = data.getData().entrySet().stream().filter(dfm-> StringUtils.equalsIgnoreCase(dfm.getKey().trim(),key))
							.map(doc->doc.getValue().toString())
							.findFirst().orElse("0");
					if(key.equals("Top")) {
						String height = data.getData().entrySet().stream().filter(dfm-> StringUtils.equalsIgnoreCase(dfm.getKey().trim(),"Height"))
								.map(doc->doc.getValue().toString())
								.findFirst().orElse("0");
						int totalHeight  = Integer.valueOf(top).intValue()	+ Integer.valueOf(height).intValue() + 8;	
						return totalHeight;
					}else if(key.equals("Left")){
						String width = data.getData().entrySet().stream().filter(dfm-> StringUtils.equalsIgnoreCase(dfm.getKey().trim(),"Width"))
								.map(doc->doc.getValue().toString())
								.findFirst().orElse("0");
						int totalWidth  = Integer.valueOf(top).intValue() + Integer.valueOf(width).intValue() + 8;	
						return totalWidth;
					}
					return Integer.valueOf(top).intValue();
				}
				return 0;	
			}).max(Integer::compare).get().intValue();
		}		
		return 0;

	}


	public static int getPanelValue(DFMObject dfmData,String key) {
		if(CollectionUtils.isNotEmpty(dfmData.getChild())) {
			return dfmData.getChild().stream().map(data->{
				String top  = String.valueOf(0);
				if(MapUtils.isNotEmpty(data.getData())) {
					top = data.getData().entrySet().stream().filter(dfm-> StringUtils.equalsIgnoreCase(dfm.getKey().trim(),key))
							.map(doc->doc.getValue().toString())
							.findFirst().orElse("0");
				}
				return Integer.valueOf(top);	
			}).max(Integer::compare).get().intValue();
		}		
		return 0;		
	}



	public static DFMObject setPanelHW(DFMObject dfmObject) {

		for( DFMObject dfmData  :  dfmObject.getChild()) {

			if(CollectionUtils.isNotEmpty(dfmData.getChild())){
				setPanelHW(dfmData);
				arrangeCurrentPanel(dfmData);				
				int panelTop = 0;
				int panelLeft = 0;

				if(containsTWAPanel(dfmData)) {
					if(isExist(dfmData, "Height")) {
						int height = getPanelValue(dfmData, "Height");
						int oldHeight = getPanelPropertyValue(dfmData, "Height");
						setDFMPData(dfmData, "Height", oldHeight >  height ? oldHeight :height );
					}			
					if(isExist(dfmData, "Width")) {
						int width = getPanelValue(dfmData, "Width");
						int oldWidth = getPanelPropertyValue(dfmData, "Width");

						setDFMPData(dfmData, "Width",  oldWidth > width ? oldWidth : width  );
					}

					continue;

				}else {
					if(CollectionUtils.isNotEmpty(dfmData.getChild())) {
						panelTop = getPanelPropertyValue(dfmData, "Top");

					}
					if(CollectionUtils.isNotEmpty(dfmData.getChild())) {
						panelLeft = getPanelPropertyValue(dfmData, "Left");
					}

					if(isExist(dfmData, "Height")) {
						setDFMPData(dfmData, "Height", panelTop);
					}			

					if(isExist(dfmData, "Width")) {
						setDFMPData(dfmData, "Width", panelLeft);
					}
				}
			}

		}
		return dfmObject;

	}



	private static void setDFMPData(DFMObject node, String paramKey,int panel) {
		if (MapUtils.isNotEmpty(node.getData())) {
			node.getData().forEach((k, v) -> {
				if (k.trim().equalsIgnoreCase(paramKey)) {
					v.setData(Integer.valueOf(panel));
				} 
			});
		} 
	}

	public static void  arrangeCurrentPanel(DFMObject panel) {
		if(containsTWAPanel(panel)
				|| CollectionUtils.isEmpty(panel.getChild())
				|| panel.getName().equalsIgnoreCase("root")
				|| StringUtils.contains(panel.getName(),"huePnlMainContents")
				|| StringUtils.contains(panel.getClassName(),"TWAToolBar")
				|| StringUtils.contains(panel.getName(),"huePnlToolButtonBase")) {
			return;
		}	
		System.out.println("Classes"+ panel.getClassName());
		System.out.println("Name"+ panel.getName());
		DFMFileTreeGenerator.arrangeCurrentPanel(panel);

	}




	public static boolean containsTWAPanel(DFMObject panel) { 
		boolean result = false;
		if (CollectionUtils.isNotEmpty(panel.getChild())) {
			return panel.getChild().stream().filter(doc-> 
			StringUtils.contains(doc.getClassName(), "Panel")
					).collect(Collectors.toList()).size() > 0 ;
		}
		return result;

	}



	public static void getTreeToRowData(DFMObject treeData, LinkedList<ComponentStructure> dataList, AtomicInteger order) { 

		ComponentStructure data = ComponentStructure.builder()
				.componentType(treeData.getName())
				.top(Integer.valueOf(getDFMPData(treeData, "Top")))
				.left(Integer.valueOf(getDFMPData(treeData, "Left")))
				.componentId(treeData.getClassName()).build();        
		dataList.add(data);
		if (treeData.getChild().size() > 0) {
			order.incrementAndGet();
		}
		treeData.getChild().stream().forEachOrdered(child -> {
			getTreeToRowData(child, dataList, order);
		});
	}


	private static String getDFMPData(DFMObject child, String key) {
		AtomicReference<String> val = new AtomicReference<>("0");
		if (child.getData() != null) {
			child.getData().forEach((k, v) -> {
				if (k.trim().equalsIgnoreCase(key)) {
					val.set(v.toString());
				}
			});
		}
		return val.get();
	}

}
