
Overview:

The Input DFM will be aligned as per the given HUE standards.

Steps to clone:

1. Launch Git Bash and navigate to the folder to be cloned. [cd path/to/be/cloned]
2. Run the command git clone http://192.168.41.136/intraweb_support/intraweb-auto-aligner.git
3. Enter the UserName and Password to clone.
4. Run the command cd intraweb-auto-aligner/
5. Run the command mvn eclipse:clean eclipse:eclipse.
6. Import in eclipse to use the project.


Steps to Use:

Launch the main class file /src/main/java/iv/intraweb/index/DFMLauncher.java as Java Application.