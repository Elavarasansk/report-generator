const CRYPT_KEY : string = 'iwb__secret__key';
const CRYPT_ALGORITHM : string = 'aes-128-cbc';
const CRYPT_IV  = new Buffer('0000000000000000');
const DB_TYPE : string = 'Oracle';
const UTF8 : string = 'utf8';
const HEX : string = 'hex';
const EXCEL_FILE_NAME : string = 'DatabaseConfiguration.xlsx';
const USER: string = 'ACCOUNT';
const NOTCOLLECTED: string = 'NOT COLLECTED';
const COLLECTED: string = 'COLLECTED';
const DATABASE_VALID: string = 'DATABASEVALID';
const DATABASE_INVALID: string = 'DATABASEINVALID';
const SCHEMA_INVALID: string = 'SCHEMAINVALID';
const INSERT: string = 'insert';
const DELETE: string = 'delete';
const MANUAL: string = 'MANUAL';
const SCHEDULE: string = 'SCHEDULE';
const ENGLISH: string = 'en';
const JAPANESE: string = 'ja';
const EXIST_CHECK: string = 'EXIST_CHECK';
const UNIQUE_PARENT: string = 'UNIQUE_PARENT';
const UNIQUE_CHILD: string = 'UNIQUE_CHILD';
const INTERMEDIATE: string = 'INTERMEDIATE';

export const Constants = {
    CRYPT_KEY,
    CRYPT_ALGORITHM,
    CRYPT_IV,
    DB_TYPE,
    BOOLEAN_FALSE : false,
    BOOLEAN_TRUE : true,
    UTF8,
    HEX,
    EXCEL_FILE_NAME,
    USER_MAX_LIMIT: 5,
    USER,
    paging : {
        perPage: 10,
    },
    COUNT : 1,
    NOTCOLLECTED,
    COLLECTED,
    DATABASE_VALID,
    DATABASE_INVALID,
    SCHEMA_INVALID,
    INSERT,
    DELETE,
    MANUAL,
    SCHEDULE,
    ENGLISH,
    JAPANESE,
    EXIST_CHECK,
    UNIQUE_PARENT,
    UNIQUE_CHILD,
    INTERMEDIATE
}
