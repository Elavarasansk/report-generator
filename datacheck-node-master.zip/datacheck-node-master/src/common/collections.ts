export const Collection = {
    dbCollection: {
        DBDETAILS: 'oracle_db_config_details',
        TABLEMETADATA: 'table_metadata',
        TABLE_RELATIONS: 'relational_info',
        SCHEDULE: 'scheduler_details',
        INDEPENDENT_PARENT_LIST: 'independent_parent_details',
        INDEPENDENT_CHILD_LIST: 'independent_child_details',
        INTERMEDIATE_TABLE_LIST: 'intermediate_table_details',
        ERLIST: 'erList_table_details',
        EXERESULT: 'execution_result',
        OPQURIES: 'operation_queries',
        MULTIPLE_KEY_INCONSISTENT_DATA: "multiple_key_inconsistent_data",
        SINGLE_KEY_INCONSISTENT_DATA: "single_key_inconsistent_data",
        SUCCESSRATE: 'success_rate_child_tables',
        METADATA: 'execution_metadata'
    },
    resMessages: {
        DATA_SUCCESS: "Data Inserted Succesfully",
        DATA_INSERT_ERROR: "Error Ocurred while Data insertion",
        DATA_EMPTY: "Empty Values cannot be Inserted",
        SCHEDULER_NAME_EXSISTS: "Scheduler Name Already exsists",
        END_OF_RECORDS: "End of Records",
        NO_DATA_FOUND: "No Data Found",
        NO_QUERIES_FOUND: "No Queries found for Schdeuler name",
        NO_DELETE_SCHEDULER: "No Data to Delete with Scheduler Name",
        NO_DATA_DELETE: "No Data to Delete",
        CSV_SUCCESS: "CSV File Downloaded Succesfully"
    },
    flags: {
        F_SUCCESS: "flagsuccess",
        F_EXSISTS: "flagexsists",
        F_ERROR: "flagerror",
        F_EMPTY: "flagempty"
    },
    dateFormats: {
        EXECUTION_DATE_FORMAT: "dddd MMM D YYYY hh:mm:ss A ZZ",
        DELETE_DATE_FORMAT: "MMM D YYYY hh:mm:ss A",
        QUERY_DATE_FORMAT: 'MM/DD/YYYY'
    },
    keywords: {
        CREATED_USER: "Created User",
        EXECUTION_RESULT: "executionresult",
        DELETEED_COUNT: "Execution Records Deleted Count",
        NO_DATA_AVAILABLE: "No Data Available"
    }
};
