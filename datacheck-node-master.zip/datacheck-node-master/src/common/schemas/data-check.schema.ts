import * as mongoose from "mongoose";
import { Collection } from '../collections';

/* DB Details Schema - to save DB, host, user credential details */
const DbDetailsSchema = new mongoose.Schema({
    serialNumber: Number,
    oracleHostName: String,
    oraclePort: String,
    oracleServiceId: String,
    oracleUserName: String,
    oraclePassword: String,
    oracleSchema: String,
    isDeleted: Boolean,
    dbType: String,
    createdDate: Date,
    updatedDate: { type: Date, default: Date.now },
    createdUser: String,
    updatedUser: String,
    metadataCollection: String,
    tableCount: Number
}, { collection: Collection.dbCollection.DBDETAILS, versionKey: false });

/* Table MetaData Schema - to get list of tables, columns list and primary key list for specified DB [Database], */
const TableMetaDataSchema = new mongoose.Schema({
    tableName: String,
    columnList: Object,
    primaryKeyList: Object,
    dbIdList: [String]
}, { collection: Collection.dbCollection.TABLEMETADATA, versionKey: false });

/* Table Relation Schema - to save table relation, with primary and foreign key realtion */
const tableRelationsSchema = new mongoose.Schema({
    parentTable: { type: String, uppercase: true },
    parentColumn: String,
    childTable: { type: String, uppercase: true },
    childColumn: String,
    dbId: String,
    createdDate: Date,
    createdUser: String,
    updatedDate: { type: Date, default: Date.now },
    updatedUser: String,
}, { collection: Collection.dbCollection.TABLE_RELATIONS, versionKey: false });

/* Scheduler Schema - to save Scheduler Details, with DB name, Cron Expression, ER tables List */
const SchedulerSchema = new mongoose.Schema({
    scheduleName: String,
    dbId: String,
    cronExpression: String,
    erListId: String,
    selectedTables: Object,
    isDeleted: Boolean,
    createdDate: Date,
    createdUser: String,
    updatedDate: { type: Date, default: Date.now },
    updatedUser: String
}, { collection: Collection.dbCollection.SCHEDULE, versionKey: false });

/* IndependentParentListSchema - to save Independent parent table list */
const IndependentParentListSchema = new mongoose.Schema({
    dbId: String,
    uniqueParentTable: String
},  { collection: Collection.dbCollection.INDEPENDENT_PARENT_LIST, versionKey: false });

/* IndependentChildListSchema - to save Independent child table list */
const IndependentChildListSchema = new mongoose.Schema({
    dbId: String,
    uniqueChildTable: String
},  { collection: Collection.dbCollection.INDEPENDENT_CHILD_LIST, versionKey: false });

/* IntermediateListSchema - to save intermediate table list */
const IntermediateListSchema = new mongoose.Schema({
    dbId: String,
    intermediateTable: String
},  { collection: Collection.dbCollection.INTERMEDIATE_TABLE_LIST, versionKey: false });

/* ER List Schema - to save ER list tables IDs array */
const ERListSchema = new mongoose.Schema({
    relationalInfoName: String,
    relationInfoIdList: [String]
}, { collection: Collection.dbCollection.ERLIST, versionKey: false });

/* Execution Results Schema - to save execution results, display to user interface, */
const ExecutionResultSchema = new mongoose.Schema({
    schedulerId: String,
    schedulerName : String,
    successRate: String,
    executionDate: String,
    queryDate: String,
    deleteDate: String,
    isDeleted: { type: Boolean, default: false },
    childTablesSuccessRates: Array,
    createdDate: Date,
    updatedDate: { type: Date, default: Date.now },
    createdUser: String,
    updatedUser: String,
}, { collection: Collection.dbCollection.EXERESULT, versionKey: false });

/* Operationa Queries Schema - to fetch delete queries for execution results, allow download  */
const OperationQueriesSchema = new mongoose.Schema({
    schedulerId: String,
    insert: { type: Array, "default": [] },
    delete: { type: Array, "default": [] },
    createdDate: Date,
    updatedDate: { type: Date, default: Date.now },
    createdUser: String,
    updatedUser: String
}, { collection: Collection.dbCollection.OPQURIES, versionKey: false });

/* Single Key Data Schema - to save and access single key based data */
const SingleKeyDataSchema = new mongoose.Schema({
    schedulerId: String,
    executionDate: String,
    parentTable: String,
    childTable: String,
    parentColumnName: String,
    childColumnName: String,
    diffInconsistenceData: Array,
}, { collection: Collection.dbCollection.SINGLE_KEY_INCONSISTENT_DATA, versionKey: false });

/* Multiple Key Data Schema - to save and access multiple key based data */
const MultiKeyDataSchema = new mongoose.Schema({
    schedulerId: String,
    executionDate: String,
    parentTable: String,
    childTable: String,
    parentColumnName: [String],
    childColumnName: [String],
    diffInconsistenceData: [Object],
}, { collection: Collection.dbCollection.MULTIPLE_KEY_INCONSISTENT_DATA, versionKey: false });


export const SchemaCollection = {
    [Collection.dbCollection.DBDETAILS]: DbDetailsSchema,
    [Collection.dbCollection.TABLEMETADATA]: TableMetaDataSchema,
    [Collection.dbCollection.TABLE_RELATIONS]: tableRelationsSchema,
    [Collection.dbCollection.SCHEDULE]: SchedulerSchema,
    [Collection.dbCollection.INDEPENDENT_PARENT_LIST]: IndependentParentListSchema,
    [Collection.dbCollection.INDEPENDENT_CHILD_LIST]: IndependentChildListSchema,
    [Collection.dbCollection.INTERMEDIATE_TABLE_LIST]: IntermediateListSchema,
    [Collection.dbCollection.ERLIST]: ERListSchema,
    [Collection.dbCollection.EXERESULT]: ExecutionResultSchema,
    [Collection.dbCollection.OPQURIES]: OperationQueriesSchema,
    [Collection.dbCollection.SINGLE_KEY_INCONSISTENT_DATA]: SingleKeyDataSchema,
    [Collection.dbCollection.MULTIPLE_KEY_INCONSISTENT_DATA]: MultiKeyDataSchema
}
