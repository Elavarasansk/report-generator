import { HttpStatus, Injectable } from "@nestjs/common";
import { validate } from "class-validator";
import { ResMessage } from "./res.message";
import * as winston from "winston";
import * as nodemailer from 'nodemailer';
import * as config from 'config';
import { Constants } from '../common/constants';

winston.configure({
    transports: [
        new (winston.transports.File)({ filename: 'somefile.log' })
    ]
})

@Injectable()
export class Utility {
    constructor() { }

    sendSuccess(req, res, data, message) {
        const result = { hasError: Constants.BOOLEAN_FALSE, code: HttpStatus.OK, data, message };
        const { path, methods } = req.route;
        const { body } = req.body;
        const log: any = {
            date: new Date(),
            path,
            methods,
            body,
            result
        };
        winston.log('info', log);
        return res.status(HttpStatus.OK).json(result);
    }

    fieldValidate = async (data) => {
        let errors = await validate(data);
        if (!errors.length) {
            return true;
        }
        return { errors, message: ResMessage.VALIDATION_ERROR }
    }

    sendError(req, res, error) {
        const errorResult = error.message;
        let  errorMessage;
        if(typeof(errorResult) === 'object') {
            errorMessage = errorResult.message;
        }else {
            errorMessage = errorResult;
        }
        const result = { hasError: Constants.BOOLEAN_TRUE, code: 404, data: [], errorMessage};
        const { path, methods } = req.route;
        const { body } = req.body;
        const log: any = {
            date: new Date(),
            path,
            methods,
            body,
            result
        };
        winston.error('error', log);
        return res.status(HttpStatus.OK).json(result);
    }

    sendMailOptions(mailOptions) {
        try {
            const smtpTransport = nodemailer.createTransport(config.smtpTransportSetup);
            smtpTransport.sendMail(mailOptions);
        } catch (error) {
            console.log(error);
        }
    }
}
