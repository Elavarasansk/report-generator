import LocalizedStrings from 'localized-strings';
import * as data from './multilingual.json';

export const locale = new LocalizedStrings(data);