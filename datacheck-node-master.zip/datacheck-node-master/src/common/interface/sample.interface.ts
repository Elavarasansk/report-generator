import { ApiProperty } from "@nestjs/swagger";

interface referInterface {
    data1: String;
    data2: number;
    data3: object;
}

export {
    referInterface,
}