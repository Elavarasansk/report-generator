interface ExeResultInterface {
    _id: object,
    schedulerId: string,
    schedulerName : string,
    successRate: string,
    executionDate: string,
    queryDate: string,
    deleteDate: string,
    childTablesSuccessRates: Array<any>,
    isDeleted: Boolean,
    createdDate: Date,
    updatedDate: Date,
    createdUser: string,
    updatedUser: string
}

interface OperationQueriesInterface {
    _id: object,
    schedulerId: string,
    insert: Array<any>,
    delete: Array<any>,
    createdDate: Date,
    updatedDate: Date,
    createdUser: string,
    updatedUser: string
}

interface SingleKeyDataInterface {
    _id: object,
    scheduleId: string,
    executionDate: string,
    parentTable: string,
    childTable: string,
    parentColumnName: string,
    childColumnName: string,
    diffInconsistenceData: Array<string>,
    tableDataCount : Number
}

interface MultipleKeyDataInterface {
    _id: object,
    scheduleId: string,
    executionDate: string,
    parentTable: string,
    childTable: string,
    parentColumnName: [string],
    childColumnName: [string],
    diffInconsistenceData: [Object],
    tableDataCount : Number
}

export {
    ExeResultInterface,
    OperationQueriesInterface,
    SingleKeyDataInterface,
    MultipleKeyDataInterface
}