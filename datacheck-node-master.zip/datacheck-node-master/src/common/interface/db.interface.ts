import { Document, PassportLocalDocument } from "mongoose";
 
export interface DbDetails  {
  _id : object,
  serialNumber: number,
  oracleHostName: string,
  oraclePort: number,
  oracleServiceId: string,
  oracleUserName: string,
  oraclePassword: string,
  oracleSchema : string,
  isDeleted: boolean,
  dbType: string,
  createdDate: Date,
  updatedDate: Date,
  createdUser: string,
  updateUser: string,
  metadataCollection: string,
  tableCount: number
}
