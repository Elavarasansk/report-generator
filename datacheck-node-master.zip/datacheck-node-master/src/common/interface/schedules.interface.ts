export interface Scheduler  {
    _id : object,
    scheduleId : string,
    dbId : string,
    cronExpression : string,
    relationInfoId: string,
    selectedTables : Object,
    isDeleted: Boolean,
    createdDate: Date,
    updatedDate: Date,
    createdUser: string,
    updatedUser: string
}
export interface ERList {
    _id: object,
    relationalInfoName: string,
    relationInfoIdList: [string]
}
export interface IndependentParentList {
    _id: object,
    dbId: string,
    uniqueParentTable: string
}
export interface IndependentChildList {
    _id: object,
    dbId: string,
    uniqueChildTable: string
}
export interface IntermediateList {
    _id: object,
    dbId: string,
    intermediateTable: string
}
