interface TableColumns  {
  columnName: string,
  dataType: string;
}

interface TableRelationsInterface  {
  _id:object,
  parentTable: string,
  parentColumn: string,
  childTable: string,
  childColumn: string,
  dbId: string;
}

interface TableMetaDataInterface  {
  _id:object,
  tableName: string,
  columnList: [string],
  primaryKeyList: [string],
  dbIdList: [string];
}

interface DBDetailsInterface  {
  _id:object,
  serialNumber: Number,
  oracleHostName: String,
  oraclePort: String,
  oracleServiceId: String,
  oracleUserName: String,
  oraclePassword: String,
  oracleSchema: String,
  isDeleted: Boolean,
  dbType: String,
}

export{
  TableRelationsInterface,
  TableMetaDataInterface,
  DBDetailsInterface
}
