import { ApiProperty } from "@nestjs/swagger";

class ReferDto {
    @ApiProperty()
    readonly username: string;
    
    @ApiProperty()
    readonly userRole: string;
    
    @ApiProperty()
    readonly paging: {
        pageNum: number,
        limit: number //RowCount
    };
    
    @ApiProperty()
    readonly sortColumn: [{
        columnName: string,
        sortType: string
    }];
}

export {
    ReferDto,
}