import { ApiProperty } from "@nestjs/swagger";

/* to get page, sort options from Req  */
class PageSortDto {
    @ApiProperty()
    page: number;
    @ApiProperty()
    flag: string;
    @ApiProperty()
    sortOptions: object;
}

/* to get name, date, page, sort options from Req  */
class NameDatePageSortDto {
    @ApiProperty()
    schedulername: string;
    @ApiProperty()
    date: string;
    @ApiProperty()
    page: number;
    @ApiProperty()
    flag: string;
    @ApiProperty()
    sortOptions: object;
}

/* to get name, date, page, limit, sort options from Req  */
class NameDatePageLimitSortDto {
    @ApiProperty()
    schedulername: string;
    @ApiProperty()
    childTableName: string;
    @ApiProperty()
    date: string;
    @ApiProperty()
    page: number;
    @ApiProperty()
    limit: number;
    @ApiProperty()
    flag: string;
    @ApiProperty()
    sortOptions: object;
}

/* to get date, page , sort options from Req */
class DatePageSortDto {
    @ApiProperty()
    date: string;
    @ApiProperty()
    page: number;
    @ApiProperty()
    sortOptions: object;
}

/* to get name, page , sort options from Req */
class NamePageSortDto {
    @ApiProperty()
    schedulername: string;
    @ApiProperty()
    page: number;
    @ApiProperty()
    sortOptions: object;
}

/* to get scheduler name array, execution date array from req */
class DeleteManyBasedonIdDto {
    @ApiProperty()
    schedulerIdList: Array<string>;
}

/* to get scheduler name array, path of file from req */
class SchedulerNameArrayDto {
    @ApiProperty()
    schedulerNameArray: Array<string>
    @ApiProperty()
    executionDateArray: Array<string>
    @ApiProperty()
    mode: string
}

class DownloadQueryDto {
    @ApiProperty()
    schedulerName: string
    @ApiProperty()
    executionDate: string
    @ApiProperty()
    downloadType: string
    @ApiProperty()
    mode: string
}

class GraphDataDto {
    @ApiProperty()
    schedulerName: string
    @ApiProperty()
    date: string
    @ApiProperty()
    tableName: string
}

class DeleteFlagDto {
    @ApiProperty()
    flag: string
}

export {
    PageSortDto,
    NameDatePageSortDto,
    NameDatePageLimitSortDto,
    SchedulerNameArrayDto,
    DatePageSortDto,
    DeleteManyBasedonIdDto,
    NamePageSortDto,
    DownloadQueryDto,
    GraphDataDto,
    DeleteFlagDto
}