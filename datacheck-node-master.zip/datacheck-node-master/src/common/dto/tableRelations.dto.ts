import { ApiProperty } from "@nestjs/swagger";

// To Post the Table Relations through Input SQL.
class InputSqlTableRelationsDto {
    @ApiProperty()
    dbId: string;
    @ApiProperty()
    sql: string;
    @ApiProperty()
    lang: string;
}

// To Get and Post the Table Relations through ER List.
class TableRelationsDto {
    @ApiProperty()
    parentTable: string;
    @ApiProperty()
    parentColumn: string;
    @ApiProperty()
    childTable: string;
    @ApiProperty()
    childColumn: string;
    @ApiProperty()
    dbId: string;
    @ApiProperty()
    lang: string;
}

// Search the Table Relation Data.
class SearchTableRelationDataDto {
    @ApiProperty()
    parentTable: string;
    @ApiProperty()
    childTable: string;
    @ApiProperty()
    dbId: string;
    @ApiProperty()
    pageNumber: number;
    @ApiProperty()
    lang: string;
}

export{
    TableRelationsDto,
    InputSqlTableRelationsDto,
    SearchTableRelationDataDto
}
