import { ApiProperty } from "@nestjs/swagger";
class SelectedTablesDto {
    @ApiProperty()
    unique_parent: [string];
    @ApiProperty()
    unique_child: [string];
    @ApiProperty()
    intermediate: [string];
}

class ScheduleDetails {
    @ApiProperty()
    scheduleName: string;
    @ApiProperty()
    dbId: string;
    @ApiProperty()
    cronExpression: string;
    @ApiProperty()
    selectedTables: SelectedTablesDto;
    @ApiProperty()
    lang: string;
    @ApiProperty()
    jobTriggerMode: string;
} 

class PagingData {
    @ApiProperty()
    pageNum: number;
    @ApiProperty()
    limit: number;
}

class ScheduleFilter {
    @ApiProperty()
    scheduleName: string;
    @ApiProperty()
    dbId: string;
    @ApiProperty()
    paging: PagingData;
    @ApiProperty()
    lang: string;
    @ApiProperty()
    jobTriggerMode: string;
}

export {
    ScheduleDetails,
    ScheduleFilter,
    PagingData
}

