import { ApiProperty } from "@nestjs/swagger";

class DbConfigDetails {   
    @ApiProperty()
    oracleHostName: string;
    @ApiProperty()
    oraclePort: number;
    @ApiProperty()
    oracleServiceId: string;
    @ApiProperty()
    oracleUserName: string;
    @ApiProperty()
    oraclePassword: string;
    @ApiProperty()
    oracleSchema: string;
    @ApiProperty()
    dbType: string;
    @ApiProperty()
    lang: string;
}

class PagingFilter {
    @ApiProperty()
    lang: string;
    @ApiProperty()
    paging : {
        page : number,
        size : number
    }
}
 
 export {
    DbConfigDetails, PagingFilter
 }

