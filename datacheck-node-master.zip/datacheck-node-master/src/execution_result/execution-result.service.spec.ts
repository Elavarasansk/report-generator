import { ExecutionResultService } from './execution-result.service';
import { ExecutionResultModule } from './execution-result.module';
import { AppModule } from '../../src/app.module';
import { Utility } from '../common/utility';
import { Test, TestingModule } from '@nestjs/testing';

describe('ExecutionResultService', () => {
  let service: ExecutionResultService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports:[ExecutionResultModule, AppModule],
      providers: [ExecutionResultService, Utility],
    }).compile();

    service = module.get<ExecutionResultService>(ExecutionResultService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
