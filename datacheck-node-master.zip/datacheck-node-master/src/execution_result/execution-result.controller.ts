import { Controller, Get, Request, Response, Post, Body, Param, Delete } from '@nestjs/common';
import { ApiTags } from "@nestjs/swagger";
import { InjectModel } from '@nestjs/mongoose';
import { PassportLocalModel } from 'mongoose';
import * as Moment from 'Moment';
import * as fs from 'fs';
import * as _path from 'path';
import * as config from 'config';
import * as fsextra from 'fs-extra';
import { ExeResultInterface } from 'src/common/interface/execution-result.interface';
import { Utility } from '../common/utility';
import { Constants } from '../common/constants';
import { Collection } from '../common/collections';
import { ResMessage } from '../common/res.message';
import { ExecutionResultService } from './execution-result.service';
import { NameDatePageLimitSortDto, DeleteManyBasedonIdDto, SchedulerNameArrayDto, NameDatePageSortDto, PageSortDto, DownloadQueryDto, GraphDataDto, DeleteFlagDto } from '../common/dto/execution-result.dto';

const { CREATED_USER } = Collection.keywords;
const { DATA_SUCCESS, NO_DATA_DELETE } = Collection.resMessages;
const { EXECUTION_DATE_FORMAT, QUERY_DATE_FORMAT, DELETE_DATE_FORMAT } = Collection.dateFormats;
const { F_EMPTY } = Collection.flags;
const { BOOLEAN_FALSE, INSERT } = Constants;
const { SUCCESS } = ResMessage;
const shell = require('shelljs');
const tempPath = _path.join(__dirname, `../../temp/`);

@Controller(Collection.keywords.EXECUTION_RESULT)
@ApiTags(Collection.keywords.EXECUTION_RESULT)

export class ExecutionResultController {
    constructor(
        private readonly executionResultService: ExecutionResultService,
        private readonly utility: Utility,
        @InjectModel(Collection.dbCollection.EXERESULT)
        private readonly exeResultModel: PassportLocalModel<ExeResultInterface>) {
    }

    /** Get all Scheduler Results from  DB  */
    @Post('/getAllSchedulerResults')
    public async getAllExecutionResults(
        @Response() res,
        @Request() req,
        @Body() _getRequestData: PageSortDto) {
        const { page, flag, sortOptions } = _getRequestData;
        const sortQuery = this.formSortQuery(sortOptions);
        const { getExecutionResults } = this.executionResultService;
        const { sendSuccess, sendError } = this.utility;
        if (!fs.existsSync(tempPath)) {
            shell.mkdir('-p', tempPath);
        }
        try {
            const data = await getExecutionResults(page, flag, sortQuery);
            return sendSuccess(req, res, data, SUCCESS);
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /** Get data based on scheduler name and date */
    @Post('/getSchedulersOnaDate')
    public async getExecutionResultsOnNameAndDate(
        @Response() res,
        @Request() req,
        @Body() _getSchedulersOnaDate: NameDatePageSortDto) {
        const { schedulername, date, page, flag, sortOptions } = _getSchedulersOnaDate;
        const sortQuery = this.formSortQuery(sortOptions);
        const _dateObj = Moment(new Date(date)).format(QUERY_DATE_FORMAT);
        const momentObj = date !== "" ? _dateObj : "";
        const { getExecutionResultsOnNameAndDate } = this.executionResultService;
        const { sendSuccess, sendError } = this.utility;
        try {
            const data = await getExecutionResultsOnNameAndDate(schedulername, momentObj, page, flag, sortQuery);
            return sendSuccess(req, res, data, SUCCESS);
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /* Get Child Tables Success Rate Details based on Scheduler ID and Date selected */
    @Post('/getChildTableSuccessRates')
    public async getChildTableSuccessRates(
        @Response() res,
        @Request() req,
        @Body() _getChildTableSuccessRates: NameDatePageLimitSortDto) {
        let _resultObj = {}, tableMapObj, processArray = [], count, oracleDBDetails, childTableArray = [];
        const { schedulername, childTableName, date, page, limit, flag, sortOptions } = _getChildTableSuccessRates;
        const momentObj = date.substring(date.indexOf(' ') + 1, date.lastIndexOf(' '));
        const { getChildTableSuccessRates, getGraphData } = this.executionResultService;
        const { sendSuccess, sendError } = this.utility;
        try {
            const data = await getChildTableSuccessRates(schedulername, momentObj);
            const { childTablesSuccessRates } = data.childTableDetails[0];
            tableMapObj = await this.getTotalData(childTablesSuccessRates, getGraphData, schedulername, date);
            tableMapObj.forEach((element, index) => {
                const incoArray = element['data'];
                const inconsistentDataCount = incoArray[0];
                const consistentDataCount = incoArray[1];
                const totalData = inconsistentDataCount + consistentDataCount;
                processArray = processArray.concat({ ...childTablesSuccessRates[index], totalData, inconsistentDataCount, consistentDataCount });
            });
            oracleDBDetails = data.oracleDBDetails;
            const docs = (flag === 'table') ? this.getOrderedChildTableData(processArray, childTableName, page, limit, sortOptions, flag) :
                this.getOrderedChildTableData(childTablesSuccessRates, childTableName, page, limit, sortOptions, flag);
            if (flag === 'card') {
                count = childTablesSuccessRates ? (childTablesSuccessRates.length) : 0;
            } else {
                count = childTableName ? docs.length : childTablesSuccessRates.length;
            }
            (childTableName) ? docs.filter(element => childTableArray = childTableArray.concat(element['childTable'])) :
                childTablesSuccessRates.filter(element => childTableArray = childTableArray.concat(element['childTable']));
            _resultObj = {
                oracleDBDetails,
                docs,
                count,
                childTableArray
            }
            return sendSuccess(req, res, _resultObj, SUCCESS);
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /**Method to get table data count for individual child table  */
    private async getTotalData(childTablesSuccessRates: any, getGraphData: (schedulerName: String, executionDate: String, tableName: String) => Promise<any>, schedulername: string, date: string) {
        let data, returnArray = [];
        for (let key in childTablesSuccessRates) {
            data = await getGraphData(schedulername, date, childTablesSuccessRates[key]['childTable']);
            returnArray = returnArray.concat(data);
        }
        return returnArray;
    }

    /* Post method to get Child Tables Success Rate Details based on Scheduler ID and Date selected */
    @Post('/getGraphData')
    public async getGraphData(
        @Response() res,
        @Request() req,
        @Body() graphData: GraphDataDto) {
        const { schedulerName, date, tableName } = graphData;
        const { getGraphData } = this.executionResultService;
        const { sendSuccess, sendError } = this.utility;
        try {
            const data = await getGraphData(schedulerName, date, tableName);
            return sendSuccess(req, res, data, SUCCESS);
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /** Download Queries for Insert and delete based on schedulername, execution date and mode of download */
    @Post('/downloadSingleQuery')
    public async downloadSingleQuery(
        @Response() res,
        @Request() req,
        @Body() QueryParams: DownloadQueryDto) {
        const { schedulerName, executionDate, downloadType, mode } = QueryParams;
        const { sendError } = this.utility;
        const { getInsertQuery, getDeleteQuery } = this.executionResultService;
        const fileName = mode === INSERT ? `InsertQueries_${schedulerName}.sql` : `DeleteQueries_${schedulerName}.sql`;
        const zipFileName = mode === INSERT ? `Insert_Queries_for_${schedulerName}.zip` : `Delete_Queries_for_${schedulerName}.zip`;
        fsextra.emptyDirSync(_path.join(__dirname, `../../temp/`));
        try {
            const data = (mode === INSERT) ? await getInsertQuery(schedulerName, executionDate, downloadType) :
                await getDeleteQuery(schedulerName, executionDate, downloadType);
            downloadType === 'file' ?
                ((data && data.flag !== F_EMPTY) ? this.downloadFile(fileName, req, res, 'application/json', 100) : sendError(req, res, data)) :
                ((data && data.flag !== F_EMPTY) ? this.downloadFile(zipFileName, req, res, 'application/zip', 500) : sendError(req, res, data));
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /** Download all Insert queries based on multiple checkboxes selected  */
    @Post('/downloadMultipleSchedulerQuery')
    public async downloadAllInsertQuery(
        @Response() res,
        @Request() req,
        @Body() _schedulerNameArray: SchedulerNameArrayDto) {
        const { schedulerNameArray, executionDateArray, mode } = _schedulerNameArray;
        const { downloadAllInsertQuery, downloadAllDeleteQuery } = this.executionResultService;
        const { sendError } = this.utility;
        const filename = (mode === INSERT) ? `Multiple_Insert_Queries.zip` : `Multiple_Delete_Queries.zip`;
        fsextra.emptyDirSync(_path.join(__dirname, `../../temp/`));
        try {
            const data = (mode === INSERT) ? await downloadAllInsertQuery(schedulerNameArray, executionDateArray, filename) :
                await downloadAllDeleteQuery(schedulerNameArray, executionDateArray, filename)
            const time = mode === INSERT ? this.calculateTimeTaken(data) : 3000;
            mode === INSERT ? ((data && data.flag !== F_EMPTY) ? this.downloadFile(filename, req, res, 'application/zip', time) : sendError(req, res, data)) :
                ((data && data.flag !== F_EMPTY) ? this.downloadFile(filename, req, res, 'application/zip', time) : sendError(req, res, data));
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /** Download SQL and Zip files for insert and delete based on Request params */
    private downloadFile(fileName: string, req: any, res: any, contentType: string, time: number) {
        const { sendError } = this.utility;
        try {
            setTimeout(() => {
                const _fileName = fileName;
                const filePath = _path.join(__dirname, `../../temp/${_fileName}`);
                const stat = fs.statSync(filePath);
                res.writeHead(200, {
                    'Content-Type': `'${contentType}'`,
                    'Content-Length': stat.size,
                    "Content-Disposition": `attachment; filename= ${_fileName}`,
                });
                const readStream = fs.createReadStream(filePath);
                readStream.pipe(res);
            }, time);
        }
        catch (err) { return sendError(req, res, { message: err }); }
    }

    @Post('/downloadCSVFileSingle')
    public async downloadCSVFile(
        @Response() res,
        @Request() req,
        @Body() QueryParams: DownloadQueryDto) {
        const { schedulerName, executionDate } = QueryParams;
        const { sendSuccess, sendError } = this.utility;
        const { downloadSingleCSVFile } = this.executionResultService;
        try {
            const { contentType, contentDisposition } = config.excelDownloadConfig;
            const workbook = await downloadSingleCSVFile(schedulerName, executionDate);
            res.setHeader('Content-Type', contentType);
            res.setHeader("Content-Disposition", contentDisposition + `${schedulerName}.xlsx`);
            workbook.xlsx.write(res);
            return workbook;
        } catch (err) {
            return sendError(req, res, err);
        }
    }

    /** Insert single Execution Results */
    @Get('/executionresults/:schedulerId')
    public async postExecutionresults(
        @Request() req,
        @Response() res,
        @Param('schedulerId') schedulerId: string) {
        const currentDate = new Date();
        const { getSuccessRateDetails, getSchedulerDetails, postExecutionResults } = this.executionResultService;
        const { sendSuccess, sendError } = this.utility;
        const _schedulerDetailsObj = await getSchedulerDetails(schedulerId);
        if (!_schedulerDetailsObj) {
            return sendError(req, res, "No Scheduler ID found");
        }
        const _scheduleDetails = Object.assign({}, _schedulerDetailsObj);
        const { scheduleName } = _scheduleDetails._doc;
        const _successRateObj = await getSuccessRateDetails(schedulerId);
        const { _array } = _successRateObj;
        const _overAllSuccessRate = this.getOverallSuccessRate(_array);
        let successRateString = _overAllSuccessRate === 0 || _overAllSuccessRate === NaN ? '0' : _overAllSuccessRate;
        const _exeResultModelObj = this.setExecutionDetails(schedulerId, scheduleName, String(successRateString), currentDate, _array);
        const _exeResultSet = new this.exeResultModel(_exeResultModelObj);
        try {
            const data = await postExecutionResults(_exeResultSet);
            if (!data.hasOwnProperty('message')) {
                return sendSuccess(req, res, DATA_SUCCESS, SUCCESS);
            }
            return sendError(req, res, data);
        } catch (err) {
            return sendError(req, res, { message: err });
        }
    };

    /** Delete All Record of a Single scheduler irrespective of time and date */
    @Delete('/deleteMultipleSchedulerDetails')
    public async deleteMultipleSchedulerResults(
        @Request() req,
        @Response() res,
        @Body() _SchedulerDetails: DeleteManyBasedonIdDto) {
        const { deleteMultipleExecutionResults } = this.executionResultService;
        const { schedulerIdList } = _SchedulerDetails;
        const { sendSuccess, sendError } = this.utility;
        try {
            if (schedulerIdList) {
                const data = await deleteMultipleExecutionResults(schedulerIdList);
                if (data) { return sendSuccess(req, res, data, SUCCESS); }
                return sendError(req, res, data);
            } else {
                return sendError(req, res, { message: NO_DATA_DELETE });
            }
        } catch (err) {
            return sendError(req, res, { message: err });
        }
    };

    /** Delete all Scheduler Records in DB */
    @Delete('/all')
    public async deleteAllExecutionResults(
        @Request() req,
        @Response() res,
        @Body() deleteFlag: DeleteFlagDto) {
        const { deleteAllExecutionResults } = this.executionResultService;
        const { sendSuccess, sendError } = this.utility;
        const { flag } = deleteFlag;
        try {
            if (flag) {
                const data = await deleteAllExecutionResults(flag);
                if (data) { return sendSuccess(req, res, data, SUCCESS); }
                return sendError(req, res, data);
            } else {
                return sendError(req, res, { message: NO_DATA_DELETE });
            }
        } catch (err) {
            return sendError(req, res, { message: err });
        }
    };


    /** method to set Execution Details */
    private setExecutionDetails(_schedulerId: string, _schedulerName: string, _successRate: string, currentDate, _childTableSRArray): any {
        const executionModelObj = {
            schedulerId: _schedulerId,
            schedulerName: _schedulerName,
            successRate: _successRate,
            executionDate: Moment(new Date(currentDate)).format(EXECUTION_DATE_FORMAT),
            queryDate: Moment(new Date(currentDate)).format(QUERY_DATE_FORMAT),
            deleteDate: Moment(new Date(currentDate)).format(DELETE_DATE_FORMAT),
            childTablesSuccessRates: _childTableSRArray,
            isDeleted: BOOLEAN_FALSE,
            createdDate: currentDate,
            createdUser: CREATED_USER,
            updatedUser: CREATED_USER
        }
        return executionModelObj;
    }

    /** Get Ordered Child Table Success rates */
    private getOrderedChildTableData(_data, _childTableName, _page, _limit, _sortOptions, flag) {
        let _filterdElementArray = [];
        const _sortColumn = _sortOptions.hasOwnProperty('childTable') ? 'childTable' : 'successRate';
        _limit = 5;
        _page = Math.max(1, _page);
        const _finalIndex = (_page * _limit);
        const _initialIndex = _finalIndex - _limit;
        let _childTabeleArray = _data.slice(0);
        if (_sortColumn == 'childTable' && _sortOptions[_sortColumn] == -1) {
            _childTabeleArray.sort((a, b) => {
                let x = b.childTable.toLowerCase();
                let y = a.childTable.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        } else if (_sortColumn == 'successRate' && _sortOptions[_sortColumn] == 1) {
            _childTabeleArray.sort((a, b) => a.successRate - b.successRate);
        } else if (_sortColumn == 'successRate' && _sortOptions[_sortColumn] == -1) {
            _childTabeleArray.sort((a, b) => b.successRate - a.successRate);
        } else {
            _childTabeleArray.sort((a, b) => {
                let x = a.childTable.toLowerCase();
                let y = b.childTable.toLowerCase();
                return x < y ? -1 : x > y ? 1 : 0;
            });
        }
        _filterdElementArray = _childTabeleArray.filter(element => element['childTable'].includes(_childTableName.toUpperCase()));
        if (flag === 'table') {
            _filterdElementArray = _filterdElementArray.slice(_initialIndex, _finalIndex);
        }
        return _filterdElementArray;
    }

    /** Get Overall Success Rate for all Child tables involved in a scheduler */
    private getOverallSuccessRate(_array: any) {
        let objectSize: number = 0;
        const reduced = _array.length ? _array.reduce((r, a) => { return r + a.successRate; }, 0) : 0;
        _array.forEach((element) => { if (element.successRate !== 0) { objectSize++; } });
        const overallSuccessRate = (reduced <= 0 || reduced === NaN) ? 0.0 : (reduced / objectSize);
        return Number(overallSuccessRate.toFixed(2));
    }

    /** method to form sort query */
    private formSortQuery(_sortOptions) {
        let sortQuery = {};
        for (let key in _sortOptions) {
            sortQuery[key] = _sortOptions[key];
        }
        return sortQuery;
    }

    /** Remove a Directory */
    private removeDir(path) {
        if (fs.existsSync(path)) {
            const files = fs.readdirSync(path);
            if (files.length) {
                files.forEach((filename) => {
                    if (fs.statSync(`${path}\\${filename}`).isDirectory()) {
                        this.removeDir(`${path}\\${filename}`)
                    } else { fs.unlinkSync(`${path}\\${filename}`) }
                })
                fs.rmdirSync(path)
            } else { fs.rmdirSync(path) }
        } else { console.log(`Execeution Results Loaded at : ${Moment(new Date())}`) };
    }

    /** Method to Calculate time taken for Saving a file */
    private calculateTimeTaken(data: any) {
        let { takenTime } = data, time;
        if (takenTime >= 5 && takenTime < 10) {
            time = takenTime * 1000;
        }
        else if (takenTime > 10) {
            time = 10 * 1000;
        }
        else if (takenTime < 5) {
            time = 3 * 100;
        }
        else if (takenTime < 3) {
            time = 1 * 100;
        }
        return time;
    }
}
