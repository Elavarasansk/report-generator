import { PassportLocalModel } from 'mongoose';
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import * as fs from 'fs';
import * as _path from 'path';
import * as jszip from 'jszip';
import * as config from 'config';
import { Scheduler } from 'src/common/interface/schedules.interface';
import { TableMetaDataInterface, DBDetailsInterface } from 'src/common/interface/tableRelations.interface';
import { Constants } from '../common/constants';
import { Collection } from '../common/collections';
import { ExeResultInterface, SingleKeyDataInterface, MultipleKeyDataInterface } from '../common/interface/execution-result.interface';

const { BOOLEAN_FALSE, BOOLEAN_TRUE } = Constants;
const { END_OF_RECORDS, DATA_EMPTY, NO_DATA_DELETE, NO_DATA_FOUND, CSV_SUCCESS } = Collection.resMessages;
const { NO_DATA_AVAILABLE } = Collection.keywords;
const { perPage } = Constants.paging;
const { F_EMPTY, F_SUCCESS } = Collection.flags;
const _commonFilter: string = "schedulerName successRate executionDate";
let pageNumber: number = 0;
const shell = require('shelljs');
const tempPath = _path.join(__dirname, `../../temp`);
const performance = require('perf_hooks').performance;
const axios = require('axios');
const excel = require('exceljs');
const { connector, host, port, controller, method } = config.csvDownloadConfig;
const controllerPath = `${connector}://${host}/${controller}/${method}`;

@Injectable()
export class ExecutionResultService {
    constructor(
        @InjectModel(Collection.dbCollection.EXERESULT)
        private readonly exeResultModel: PassportLocalModel<ExeResultInterface>,

        @InjectModel(Collection.dbCollection.SINGLE_KEY_INCONSISTENT_DATA)
        private readonly singleKeyDataModel: PassportLocalModel<SingleKeyDataInterface>,

        @InjectModel(Collection.dbCollection.MULTIPLE_KEY_INCONSISTENT_DATA)
        private readonly multiKeyDataModel: PassportLocalModel<MultipleKeyDataInterface>,

        @InjectModel(Collection.dbCollection.SCHEDULE)
        private readonly schedulerDetailsModel: PassportLocalModel<Scheduler>,

        @InjectModel(Collection.dbCollection.TABLEMETADATA)
        private readonly tableMetaDataModel: PassportLocalModel<TableMetaDataInterface>,

        @InjectModel(Collection.dbCollection.DBDETAILS)
        private readonly dbDetailsModel: PassportLocalModel<DBDetailsInterface>
    ) { }

    /*Method to get Distinct Scheduler names based on all records present in DB */
    getDistinctSchedulerNames = async (flag: string): Promise<any> => {
        const _query = (flag === 'manual') ? { "schedulerName": { "$regex": '^Manual_', "$options": "i" }, isDeleted: BOOLEAN_FALSE } :
            { "schedulerName": { "$regex": '^Schedule_', "$options": "i" }, isDeleted: BOOLEAN_FALSE };
        const _distinct = 'schedulerName';
        const results = await this.exeResultModel
            .find(_query)
            .distinct(_distinct);
        if (!results) {
            return { message: NO_DATA_FOUND, flag: F_EMPTY };
        }
        return results;
    }

    /* Get Success rate details from two set of tables - single and mutli key data tables */
    getSuccessRateDetails = async (_schedulerID: String): Promise<any> => {
        const _sumObject = {}, _countObject = {};
        let _filterArray = [];
        const _query = { scheduleId: _schedulerID }, _projection = { '_id': 0 };
        const _filter = 'childTable parentTable diffInconsistenceData tableDataCount';
        _filterArray = await this.getConcatDataOfTable(_query, _projection, _filter, _filterArray);
        this._getSuccessRateArray(_filterArray, _sumObject, _countObject);
        const _finalArray = Object.keys(_sumObject).map(childTable => {
            return {
                childTable,
                successRate: _sumObject[childTable] / _countObject[childTable]
            }
        });
        return { '_array': _finalArray };
    }

    /**Method to get Table graph details, inconsistent data and consistent data */
    getGraphData = async (schedulerName: String, executionDate: String, tableName: String): Promise<any> => {
        const _executionResultQuery = { schedulerName, executionDate, isDeleted: BOOLEAN_FALSE };
        let _filterArray = [], inconsistDataCount = 0, tableDataCount = 0, consistentDataCount = 0;
        const _executionFilter = 'schedulerId', _projection = { '_id': 0 };
        const _filter = 'childTable parentTable diffInconsistenceData tableDataCount';
        const _schedulerID = await this.exeResultModel
            .find(_executionResultQuery, _projection)
            .select(_executionFilter);
        if (_schedulerID.length) {
            const _query = { scheduleId: _schedulerID[0].schedulerId };
            _filterArray = await this.getConcatDataOfTable(_query, _projection, _filter, _filterArray);
            const data = _filterArray.filter((element) => element.childTable === tableName);
            if (data.length) {
                data.forEach((element) => {
                    const { diffInconsistenceData } = element;
                    inconsistDataCount += diffInconsistenceData.length;
                    tableDataCount += element.toJSON().tableDataCount;
                });
                tableDataCount = tableDataCount / data.length;
                consistentDataCount = tableDataCount - inconsistDataCount;
                return ({ totalData: tableDataCount, data: [inconsistDataCount, consistentDataCount] });
            }
            return ({ totalData: tableDataCount, data: [inconsistDataCount, consistentDataCount] });
        }
        return ({ totalData: tableDataCount, data: [inconsistDataCount, consistentDataCount] });
    }

    /* Get Scheduler details from scheduler schema table [access Scheduler Schema to get the details] */
    getSchedulerDetails = async (_schedulerID: string): Promise<any> => {
        const _projection = { '_id': 0 };
        const results = await this.schedulerDetailsModel
            .findById(_schedulerID, _projection);
        if (!results) {
            return null;
        }
        return results;
    }

    /** Method to get ChildTableSuccessRates based on Child table name and inconsistent data present in table */
    getChildTableSuccessRates = async (_schedulerName: string, _momentObj): Promise<any> => {
        const _query = { isDeleted: BOOLEAN_FALSE, schedulerName: _schedulerName, deleteDate: _momentObj };
        const _projection = { '_id': 0 }, _filter = 'childTablesSuccessRates';
        const _collation = { locale: "en" };
        const results = await this.exeResultModel
            .find(_query, _projection)
            .select(_filter)
            .collation(_collation);
        if (!results[0]) {
            const returnResult = { message: END_OF_RECORDS, flag: F_EMPTY };
            return returnResult;
        }
        const dbResults = await this.exeResultModel
            .find(_query, _projection);
        const oracleDBDetails = await this.getOracleDBDetails(dbResults[0].schedulerId);
        if (oracleDBDetails) {
            const { oracleHostName, oraclePort, oracleSchema } = oracleDBDetails;
            return { childTableDetails: results, oracleDBDetails: { host: oracleHostName, port: oraclePort, schema: oracleSchema } };
        }
        return { childTableDetails: results, oracleDBDetails: { host: NO_DATA_AVAILABLE, port: NO_DATA_AVAILABLE, schema: NO_DATA_AVAILABLE } };
    }

    //** Get Oracle DB Details */
    private getOracleDBDetails = async (scheduleId: string) => {
        const _projection = { '_id': 0 };
        const _schedulerDetailsObj = await this.getSchedulerDetails(scheduleId);
        let oracleDBDetails;
        if (_schedulerDetailsObj) {
            const _scheduleDetails = Object.assign({}, _schedulerDetailsObj);
            const { dbId } = _scheduleDetails._doc;
            oracleDBDetails = await this.dbDetailsModel
                .findById(dbId, _projection);
        }
        return oracleDBDetails;
    }

    /* Get all non soft deleted scheduler records from DB */
    getExecutionResults = async (_page: number, flag: string, _sortOptions: object): Promise<any> => {
        pageNumber = this._getMaxNumber(_page);
        let _query = {}, finalResult = {};
        _sortOptions = _sortOptions !== null ? _sortOptions : {};
        const _distinctSchedulerName = await this.getDistinctSchedulerNames(flag);
        _query = (flag === 'manual') ? { "schedulerName": { "$regex": '^Manual_', "$options": "i" }, isDeleted: BOOLEAN_FALSE } :
            { "schedulerName": { "$regex": '^Schedule_', "$options": "i" }, isDeleted: BOOLEAN_FALSE };
        const results = await this._getExecutionDetails(_query, _sortOptions);
        const totalData = await this.getFilterDataCount(_query, _sortOptions);
        finalResult = {
            schedulerNameList: _distinctSchedulerName.length > 0 ? _distinctSchedulerName : [],
            docs: results,
            count: totalData.length
        }
        return finalResult;
    }

    /* Get data from DB based on Scheduler name and Date */
    getExecutionResultsOnNameAndDate = async (_schedulerName: string, _querydate: string, _page: number, flag: string, _sortOptions: Object): Promise<any> => {
        pageNumber = this._getMaxNumber(_page);
        let _query = {}, finalResult = {};
        _sortOptions = _sortOptions !== null ? _sortOptions : {};
        const regex = (flag === 'manual') ? new RegExp(`^Manual_`) : new RegExp(`^Schedule_`);
        const regex1 = (flag === 'manual') ? new RegExp(`(?=.*${_schedulerName})^Manual_`) : new RegExp(`(?=.*${_schedulerName})^Schedule_`);
        if (!_schedulerName && !_querydate) {
            _query = { "schedulerName": { "$regex": regex, "$options": "i" }, isDeleted: BOOLEAN_FALSE };
        } else if (!_schedulerName) {
            _query = { "schedulerName": { "$regex": regex, "$options": "i" }, isDeleted: BOOLEAN_FALSE, queryDate: _querydate };
        } else if (!_querydate) {
            _query = { "schedulerName": { "$regex": regex1, "$options": "i" }, isDeleted: BOOLEAN_FALSE };
        } else {
            _query = { isDeleted: BOOLEAN_FALSE, queryDate: _querydate, "schedulerName": { "$regex": regex1, "$options": "i" } }
        }
        const countData = await this.getFilterDataCount(_query, _sortOptions);
        const count = countData.length;
        const data = await this._getExecutionDetails(_query, _sortOptions);
        finalResult = {
            docs: data,
            count
        }
        return finalResult;
    }

    /* Method to Download Insert query */
    getInsertQuery = async (schedulerName, executionDate, _downloadType): Promise<any> => {
        try {
            let insertQuerySingleDepArray, insertQueryMultipleDepArray, _multipleQueryArray = [];
            const _executionResultQuery = { schedulerName, executionDate, isDeleted: BOOLEAN_FALSE };
            const _projection = { '_id': 0 };
            const _schedulerIdData = await this.exeResultModel
                .findOne(_executionResultQuery, _projection)
                .select('schedulerId');
            if (!_schedulerIdData) {
                throw new NotFoundException(
                    'Requested Schedule is not found.'
                );
            }
            this.createFolder();
            const { schedulerId } = _schedulerIdData;
            const _singleKeyDependencyData = await this.dependencyExistCheck(schedulerId, this.singleKeyDataModel);
            const _multipleKeyDepedencyData = await this.dependencyExistCheck(schedulerId, this.multiKeyDataModel);
            if (_singleKeyDependencyData) {
                insertQuerySingleDepArray = await this.makeInsertQuery(_singleKeyDependencyData, "single", _multipleQueryArray);
            }
            if (insertQuerySingleDepArray) {
                _multipleQueryArray = _multipleQueryArray.concat(insertQuerySingleDepArray._multipleQueryArray);
            }
            if (_multipleKeyDepedencyData) {
                insertQueryMultipleDepArray = await this.makeInsertQuery(_multipleKeyDepedencyData, "multiple", _multipleQueryArray);
            }
            if (insertQueryMultipleDepArray) {
                _multipleQueryArray = _multipleQueryArray.concat(insertQueryMultipleDepArray._multipleQueryArray);
            }
            const message = this.saveInsertQuery(_downloadType, schedulerName, insertQueryMultipleDepArray, "single");
            if (message === 'Fail') {
                const returnResult = { message: NO_DATA_FOUND, flag: F_EMPTY };
                return returnResult;
            }
            const returnResult = { message: CSV_SUCCESS, flag: F_SUCCESS };
            return returnResult;
        } catch (e) {
            console.log(e);
        }
    }

    /* Method to Make Insert query */
    private makeInsertQuery = async (dependencyData, flag, _multipleQueryArray): Promise<any> => {
        const _finalQueryArray = [];
        const promises = dependencyData.map(async (_recordObj) => {
            const _individualTableArray = [], _individualTableObj = {};
            const { parentTable, parentColumnName, childTable, diffInconsistenceData } = _recordObj;
            const columnList = await this.getColumnArray(parentTable);
            let _columnString, _valueString = ``;
            if (diffInconsistenceData.length) {
                ({ _columnString, _valueString } = this.formInsertQuery(diffInconsistenceData, parentTable, _columnString, _valueString, flag, columnList, parentColumnName, _finalQueryArray, _individualTableArray));
                _individualTableObj[`${parentTable}__${childTable}`] = _individualTableArray;
                _multipleQueryArray = _multipleQueryArray.concat(_individualTableObj);
            }
        });
        return Promise.all(promises)
            .then(() => {
                return { _finalQueryArray, _multipleQueryArray };
            }).catch(error => error);
    }

    /* Download Delete query based on scheduler name and execution date */
    getDeleteQuery = async (schedulerName, executionDate, _downloadType): Promise<any> => {
        try {
            let returnResult = {};
            const _executionResultQuery = { schedulerName, executionDate, isDeleted: BOOLEAN_FALSE };
            const _projection = { '_id': 0 };
            const _schedulerId = await this.exeResultModel
                .find(_executionResultQuery, _projection)
                .select('schedulerId');
            const _query = { scheduleId: _schedulerId[0].schedulerId };
            const _fileName = `DeleteQueries_${schedulerName}.sql`;
            this.createFolder();
            const filePath = _path.join(__dirname, `../../temp/${_fileName}`);
            const _finalQueryArray = [];
            let finalQueryObject = {};
            _finalQueryArray.push(await this.getSingleKeyMisMatch(_query, finalQueryObject));
            _finalQueryArray.push(await this.getMultiKeyMisMatch(_query, finalQueryObject));
            Promise.resolve()
                .then(async () => {
                    this.saveDeleteQuery(_downloadType, _finalQueryArray, filePath, finalQueryObject, schedulerName, "single");
                }).catch(() => {
                    returnResult = { message: NO_DATA_FOUND, flag: F_SUCCESS };
                    return returnResult;
                });
            returnResult = { message: CSV_SUCCESS, flag: F_SUCCESS };
            return returnResult;
        } catch (e) {
            console.log(e);
        }
    }

    /*  Extract singleKey mismatches */
    private getSingleKeyMisMatch = async (_query, finalQueryObject): Promise<any> => {
        const _singleDeleteQueryArray = [];
        const _filter = 'childTable childColumnName diffInconsistenceData';
        const _projection = { '_id': 0 };
        const _singleKeyObj = await this.singleKeyDataModel.find(_query, _projection).select(_filter);
        const promises = this.formSingleKeyDeleteQuery(_singleKeyObj, _singleDeleteQueryArray, finalQueryObject);
        return Promise.all(promises)
            .then(() => {
                return { _singleDeleteQueryArray };
            }).catch(error => error);
    }

    /*  Extract multikey mismatches */
    private getMultiKeyMisMatch = async (_query, finalQueryObject): Promise<any> => {
        const _multipleDeleteQueryArray = [];
        const _filter = 'childTable childColumnName diffInconsistenceData';
        const _projection = { '_id': 0 };
        const _multipleKeyObj = await this.multiKeyDataModel.find(_query, _projection).select(_filter);
        const promises = _multipleKeyObj.map(async (_recordObj) => {
            const { childTable, childColumnName, diffInconsistenceData } = _recordObj;
            const columnList = await this.getColumnArray(childTable);
            this.formMultiKeyDeleteQuery(diffInconsistenceData, childTable, childColumnName, columnList, _multipleDeleteQueryArray, finalQueryObject);
        });
        return Promise.all(promises)
            .then(() => {
                return { _multipleDeleteQueryArray, finalQueryObject };
            }).catch(error => error);
    }

    /* Download Multiple Delete Query query based on Scheduler name and execution date*/
    downloadAllInsertQuery = async (_schedulernameArray, _executionDateArray, _fileName): Promise<any> => {
        try {
            const scheduleIdArray = [];
            let returnResult = {}, t0, t1, _singleKeyDependencyData = [], _multipleKeyDepedencyData = [], insertQuerySingleDepArray, insertQueryMultipleDepArray;
            const _projection = { '_id': 0 };
            const result = await this.getSchedulerIdArray(_schedulernameArray, _executionDateArray, _projection, scheduleIdArray);
            this.createFolder();
            if (result) {
                ({ _singleKeyDependencyData, _multipleKeyDepedencyData } = await this.dependencyCheck(result, _singleKeyDependencyData, _multipleKeyDepedencyData));
            }
            if (_singleKeyDependencyData.length || _multipleKeyDepedencyData.length) {
                ({ insertQuerySingleDepArray, insertQueryMultipleDepArray } = await this.getDependencyInsertQuery(_singleKeyDependencyData, insertQuerySingleDepArray, _multipleKeyDepedencyData, insertQueryMultipleDepArray));
            }
            const { _multipleQueryArray } = insertQueryMultipleDepArray;
            if (_multipleQueryArray.length) {
                t0 = performance.now();
                this.saveInsertQuery("zip", _fileName, insertQueryMultipleDepArray, "zip");
                t1 = performance.now();
            } else {
                returnResult = { message: "No Data to Download", flag: F_EMPTY };
                return returnResult;
            }
            returnResult = { message: CSV_SUCCESS, flag: F_SUCCESS, takenTime: (t1 - t0).toFixed(0) };
            return returnResult;
        } catch (err) {
            console.log(err);
        };
    }

    /** Method to Download Delete Query SQL file in Zip format for multiple scheduler results */
    downloadAllDeleteQuery = async (_schedulernameArray, _executionDateArray, _fileName): Promise<any> => {
        try {
            const scheduleIdArray = [];
            let returnResult = {};
            const _projection = { '_id': 0 };
            const result = await this.getSchedulerIdArray(_schedulernameArray, _executionDateArray, _projection, scheduleIdArray);
            const filePath = _path.join(__dirname, `../../temp/${_fileName}`);
            let _finalQueryArray = [], finalQueryObject = {};
            this.createFolder();
            const promises = result.map(async (schedulerId) => {
                const _query = { scheduleId: schedulerId };
                _finalQueryArray.push(await this.getSingleKeyMisMatch(_query, finalQueryObject));
                _finalQueryArray.push(await this.getMultiKeyMisMatch(_query, finalQueryObject));
            });
            Promise.all(promises)
                .then((_finalQueryArray) => {
                    this.saveDeleteQuery("zip", _finalQueryArray, filePath, finalQueryObject, _fileName, "zip");
                }).catch(() => {
                    returnResult = { message: NO_DATA_FOUND, flag: F_EMPTY };
                    return returnResult;
                });
            returnResult = { message: CSV_SUCCESS, flag: F_SUCCESS };
            return returnResult;
        } catch (e) {
            console.log(e);
        }
    }

    /** Check whether schedulerId exists in dependency table or not */
    private dependencyExistCheck = async (scheduleId, dataModel): Promise<any> => {
        const searchKey = { scheduleId }, _filter = 'parentTable parentColumnName childTable diffInconsistenceData -_id';
        const dependencyData = await dataModel
            .find(searchKey)
            .select(_filter);
        return dependencyData;
    }

    /* Insert Scheduler details in DB */
    postExecutionResults = async (_exeResultModelObj: any): Promise<any> => {
        const { schedulerId, schedulerName, successRate, executionDate } = _exeResultModelObj;
        const _updateQuery = { schedulerId: schedulerId }, _updatedValue = { isDeleted: BOOLEAN_TRUE };
        if (schedulerId && schedulerName && successRate && executionDate) {
            const result = await this.exeResultModel.updateMany(_updateQuery, _updatedValue);
            const data = await _exeResultModelObj
                .save(_exeResultModelObj)
                .then(doc => doc)
                .catch(error => error);
            return data;
        }
        const returnResult = { message: DATA_EMPTY, flag: F_EMPTY };
        return returnResult;
    }

    /* Delete all data - soft delete */
    deleteAllExecutionResults = async (flag): Promise<any> => {
        const query = (flag === 'manual') ? { schedulerName: { "$regex": '^Manual_', "$options": "i" } } :
            { schedulerName: { "$regex": '^Schedule_', "$options": "i" } };
        const _updatedValue = { isDeleted: BOOLEAN_TRUE };
        const data = await this.exeResultModel
            .updateMany(query, _updatedValue);
        if (data.nModified > 0) { return data; }
        const returnResult = { message: `${NO_DATA_DELETE}` };
        return returnResult;
    }

    /** Delete Multiple Execution Results - soft delete*/
    deleteMultipleExecutionResults = async (_schedulerIdList): Promise<any> => {
        const _query = { _id: { '$in': _schedulerIdList } }, _updatedValue = { isDeleted: BOOLEAN_TRUE };
        const data = await this.exeResultModel
            .updateMany(_query, _updatedValue);
        if (data.nModified > 0) { return data; }
        const returnResult = { message: `${NO_DATA_DELETE}` };
        return returnResult;
    }

    /** Download CSV file containing inconsistent data records based based on scheduler name and execution date*/
    downloadSingleCSVFile = async (schedulerName, executionDate): Promise<any> => {
        const _query = { schedulerName, executionDate }, _projection = { '_id': 0 }, _filter = 'schedulerId';
        const _dataFilter = 'childColumnName childTable diffInconsistenceData';
        let singleInconsistentData, multipleInconsistentData, finalDataArray = [], finalReturnObject = {}, scheduleId;
        const data = await this.exeResultModel
            .find(_query, _projection)
            .select(_filter);
        if (data) {
            scheduleId = data[0].schedulerId;
            singleInconsistentData = await this.singleKeyDataModel.find({ scheduleId }, _projection).select(_dataFilter);
            multipleInconsistentData = await this.multiKeyDataModel.find({ scheduleId }, _projection).select(_dataFilter);
            if (singleInconsistentData.length) {
                this.getIncosisArray(singleInconsistentData, scheduleId, finalDataArray);
            }
            if (multipleInconsistentData.length) {
                this.getIncosisArray(multipleInconsistentData, scheduleId, finalDataArray);
            }
        }
        finalReturnObject = { scheduleId, inconsistentTableDataList: finalDataArray, mode: 'CSV' };
        const results = await axios.post(controllerPath, finalReturnObject)
            .then((response) => {
                if (response.data) {
                    return this.createCSVFile(response.data);
                }
            }).catch(function (error) {
                return error.response;
            });
        return results;
    }

    //Create CSV file for Inconsistent Data
    private createCSVFile = async (csvdata): Promise<any> => {
        try {
            let workbook = new excel.Workbook();
            for (let key in csvdata) {
                let columnArray = [], columArrayData = [];
                let worksheet = workbook.addWorksheet(key);
                columArrayData = csvdata[key][0];
                for (let columnName in columArrayData) {
                    columnArray = columnArray.concat({ header: columnName, key: columnName });
                }
                worksheet.columns = columnArray;
                if (csvdata[key]) {
                    csvdata[key].forEach((data) => {
                        worksheet.addRow(data);
                    });
                }
            }
            return workbook;
        } catch (e) {
            console.log(e);
        }
    }

    /** Get Coulmn Array from table meta table*/
    private getColumnArray = async (tableName): Promise<any> => {
        const _filter = 'columnList primaryKeyList -_id', searchKey = { tableName };
        const _tableMetaData = await this.tableMetaDataModel
            .findOne(searchKey)
            .select(_filter);
        if (_tableMetaData) {
            const _columnListObj = _tableMetaData['columnList'];
            return _columnListObj;
        }
    }

    /** Method to get Single and Multiple Inconsistent Data Array along with column name */
    private getIncosisArray(singleInconsistentData: any, scheduleId: any, finalReturnArray: any[]) {
        let inconsisDataArray = [];
        singleInconsistentData.map(data => {
            let { childTable, childColumnName, diffInconsistenceData } = data;
            diffInconsistenceData.map(inconsisData => {
                let keyValueArray = [];
                childColumnName = typeof (childColumnName) === 'string' ? [childColumnName] : childColumnName;
                for (let index in childColumnName) {
                    const key = childColumnName[index];
                    keyValueArray = typeof (inconsisData) === 'string' ? keyValueArray.concat({ [key]: inconsisData }) :
                        keyValueArray.concat({ [key]: inconsisData[index] });
                }
                inconsisDataArray = inconsisDataArray.concat(keyValueArray);
            });
            finalReturnArray.push({ tableName: childTable, columnName: childColumnName, inconsistentData: inconsisDataArray });
        });
    }

    /** Form Insert Query and return column and result string */
    private formInsertQuery(diffInconsistenceData: any, parentTable: any, _columnString: any, _valueString: string, flag: any, columnList: any, parentColumnName: any, _finalQueryArray: any[], _individualTableArray: any[]) {
        _columnString = Object.keys(columnList).reduce((prev, next) => `${prev}${next},`, `(`);
        _columnString = `${_columnString.substring(0, _columnString.length - 1)})`;
        diffInconsistenceData.forEach(inconsistData => {
            let _insertQuery = `\nINSERT INTO ${parentTable}`;
            _valueString = `(`;
            if (flag === "single") {
                for (const key in columnList) {
                    _valueString = (key === parentColumnName) ? this.setParentColumTypeValue(columnList[key], inconsistData, _valueString)
                        : this.setColumTypeValue(columnList[key], key, _valueString);
                }
            }
            else {
                for (const key in columnList) {
                    if (Object.values(parentColumnName).includes(key)) {
                        const _key = Object.keys(parentColumnName).find(parentkey => parentColumnName[parentkey] === key);
                        _valueString = this.setParentColumTypeValue(columnList[key], inconsistData[_key], _valueString);
                    }
                    else {
                        _valueString = this.setColumTypeValue(columnList[key], key, _valueString);
                    }
                }
            }
            _valueString = _valueString.slice(0, _valueString.length - 1);
            _valueString = `${_valueString});`;
            _insertQuery = `${_insertQuery} ${_columnString} VALUES ${_valueString}`;
            _finalQueryArray.push(_insertQuery);
            _individualTableArray.push(_insertQuery);
        });
        return { _columnString, _valueString };
    }

    /** Format Insert Query Array and save in temp */
    private saveInsertQuery(_downloadType: any, _saveByName: any, insertQueryMultipleDepArray: any, mode: string) {
        const { _multipleQueryArray } = insertQueryMultipleDepArray;
        if (_downloadType === "file") {
            const _fileName = `InsertQueries_${_saveByName}.sql`;
            let _queryString = ``;
            if (_multipleQueryArray.length) {
                _multipleQueryArray.map((elementObj) => {
                    for (const key in elementObj) {
                        if (!String(elementObj[key])) {
                            continue;
                        }
                        const parentTableName = key.substring(0, key.indexOf('__'));
                        const childTableName = key.substring(key.indexOf('__') + 2, key.length);
                        _queryString += elementObj[key].reduce((prev, next) => `${prev}${next}`, `${this.makeInsertQueryComment(parentTableName, childTableName)}`);
                    }
                    const filePath = _path.join(__dirname, `../../temp/${_fileName}`);
                    fs.writeFileSync(filePath, _queryString);
                });
            } else {
                return 'Fail';
            }
        }
        else {
            let _count = 1;
            const zip = new jszip();
            if (_multipleQueryArray.length) {
                const promises = _multipleQueryArray.map((elementObj) => {
                    for (const key in elementObj) {
                        const _fileName = `${_count}_InsertQueries_${key}.sql`;
                        const parentTableName = key.substring(0, key.indexOf('__'));
                        const childTableName = key.substring(key.indexOf('__') + 2, key.length);
                        if (elementObj[key].length) {
                            try {
                                const _queryString = elementObj[key].reduce((prev, next) => `${prev}${next}`, `${this.makeInsertQueryComment(parentTableName, childTableName)}`);
                                const filePath = mode === 'single' ? (_path.join(__dirname, `../../temp/Insert_Queries_for_${_saveByName}.zip`)) : (_path.join(__dirname, `../../temp/${_saveByName}`));
                                zip.file(_fileName, _queryString, { array: true });
                                zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
                                    .pipe(fs.createWriteStream(filePath))
                                    .on('finish', () => {
                                        const message = { message: `${_saveByName}.zip file written to disk at`, flag: F_SUCCESS };
                                        return message;
                                    });
                                ++_count;
                            } catch (err) {
                                console.log(err);
                            }
                        }
                    }
                });
            } else {
                return "Fail";
            }
        }
    }

    /** Make Insert Query SQL file comments */
    private makeInsertQueryComment = (parentTableName, childTableName): String => {
        const comment = `\n\n/* Insert Queries for Parent Table ' ${parentTableName} ' and Child Table ' ${childTableName} ' */` +
            `\n/*, Kindly Fill in ' ? column_name ? ' with Column Values before Performing Insert Operation */`
        return comment;
    }

    /** Switch case method to set column type based values for parent column*/
    private setParentColumTypeValue(columnType, data, _valueString) {
        switch (columnType) {
            case 'NUMBER': _valueString += `${data},`; break;
            case 'VARCHAR2': _valueString += `'${data}',`; break;
            case 'DATE': _valueString += `to_date('${data}','YYYY/MM/DD'),`; break;
            default: _valueString += `${data},`; break;
        }
        return _valueString;
    }

    /** Switch case method to set column type based values for columns other than parent column*/
    private setColumTypeValue(columnType, data, _valueString) {
        switch (columnType) {
            case 'NUMBER': _valueString += `?${data}?,`; break;
            case 'VARCHAR2': _valueString += `'?${data}?',`; break;
            case 'DATE': _valueString += `to_date('?${data}?','YYYY/MM/DD'),`; break;
            default: _valueString += `?${data}?,`; break;
        }
        return _valueString;
    }

    /** Form Single key delete query based on field type */
    private formSingleKeyDeleteQuery(_singleKeyObj: any, _singleDeleteQueryArray: any[], finalQueryObject: any) {
        return _singleKeyObj.map(async (_recordObj) => {
            const _singleArray = [], { childTable, childColumnName, diffInconsistenceData } = _recordObj;
            const columnList = await this.getColumnArray(childTable);
            diffInconsistenceData.forEach(data => {
                let _deleteQuery = ``;
                if (Object.keys(columnList).includes(childColumnName)) {
                    switch (columnList[childColumnName]) {
                        case 'NUMBER': _deleteQuery = `\nDELETE FROM ${childTable} WHERE ${childColumnName} = ${data};`; break;
                        case 'VARCHAR2': _deleteQuery = `\nDELETE FROM ${childTable} WHERE ${childColumnName} = '${data}';`; break;
                        default: _deleteQuery = `\nDELETE FROM ${childTable} WHERE ${childColumnName} = '${data}';`; break;
                    }
                    _singleDeleteQueryArray.push(_deleteQuery);
                    _singleArray.push(_deleteQuery);
                }
            });
            finalQueryObject[childTable] = _singleArray;
        });
    }

    /** Form Multi key delete query based on field type */
    private formMultiKeyDeleteQuery(diffInconsistenceData: any, childTable: any, childColumnName: any, columnList: any, _multipleDeleteQueryArray: any[], finalQueryObject: any[]) {
        diffInconsistenceData.map(element => {
            let _deleteQuery = `\nDELETE FROM ${childTable} WHERE `;
            for (const key in childColumnName) {
                if (Object.keys(columnList).includes(childColumnName[key])) {
                    if (key === '0') {
                        switch (columnList[childColumnName[key]]) {
                            case 'NUMBER': _deleteQuery += `${childColumnName[key]} = ${element[key]}`; break;
                            case 'VARCHAR2': _deleteQuery += `${childColumnName[key]} = '${element[key]}'`; break;
                            case 'DATE': _deleteQuery += `${childColumnName[key]} = to_date(${element[key]},'YYYY/MM/DD')`; break;
                            default: _deleteQuery += `${childColumnName[key]} = ${element[key]}`; break;
                        }
                    }
                    else {
                        switch (columnList[childColumnName[key]]) {
                            case 'NUMBER': _deleteQuery += ` AND ${childColumnName[key]} = ${element[key]}`; break;
                            case 'VARCHAR2': _deleteQuery += ` AND ${childColumnName[key]} = '${element[key]}'`; break;
                            case 'DATE': _deleteQuery += ` AND ${childColumnName[key]} = to_date(${element[key]},'YYYY/MM/DD')`; break;
                            default: _deleteQuery += ` AND ${childColumnName[key]} = ${element[key]}`; break;
                        }
                    }
                }
            }
            _deleteQuery = `${_deleteQuery};`;
            _multipleDeleteQueryArray.push(_deleteQuery);
            finalQueryObject[childTable] = _multipleDeleteQueryArray;
        });
    }

    /** Method to save Delete Query as sql and zip file */
    private saveDeleteQuery(_downloadType: any, _finalQueryArray: any[], filePath: string, finalQueryObject: {}, schedulerName: any, mode: string) {
        if (_downloadType === "file") {
            if (_finalQueryArray) {
                let _queryString = _finalQueryArray[0]._singleDeleteQueryArray.reduce((prev, next) => `${prev}${next}`, ``);
                _queryString += _finalQueryArray[1]._multipleDeleteQueryArray.reduce((prev, next) => `${prev}${next}`, ``);
                fs.writeFileSync(filePath, _queryString);
            }
        }
        else {
            let _count = 1;
            const zip = new jszip();
            for (const key in finalQueryObject) {
                const _fileName = `${_count}_DeleteQueries_${key}.sql`;
                if (finalQueryObject[key].length) {
                    try {
                        const _queryString = finalQueryObject[key].reduce((prev, next) => `${prev}${next}`, `/* Delete Queries for Child Table ${key} */`);
                        const filePath = (mode === 'single') ? (_path.join(__dirname, `../../temp/Delete_Queries_for_${schedulerName}.zip`)) : (_path.join(__dirname, `../../temp/${schedulerName}`));
                        zip.file(_fileName, _queryString, { array: true });
                        zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
                            .pipe(fs.createWriteStream(filePath))
                            .on('finish', () => {
                                const message = { message: `${schedulerName}.zip file written to disk at`, flag: F_SUCCESS };
                                return message;
                            });
                        ++_count;
                    }
                    catch (err) {
                        console.log(err);
                    }
                }
            }
        }
    }

    /** Method to get SchedulerId Array based on the list of scheduler details passed */
    private async getSchedulerIdArray(_schedulernameArray: any, _executionDateArray: any, _projection: { '_id': number; }, schedulerIdArray: any[]) {
        const result = await _schedulernameArray.map(async (schedulerName, index) => {
            const executionDate = _executionDateArray[index];
            const _executionResultQuery = { schedulerName, executionDate, isDeleted: BOOLEAN_FALSE };
            const data = await this.exeResultModel
                .find(_executionResultQuery, _projection)
                .select('schedulerId');
            if (data[0]) {
                schedulerIdArray.push(data[0].schedulerId);
            }
        });
        return Promise.all(result).then(() => {
            return schedulerIdArray;
        }).catch(error => error);
    }

    /** Method to check if dependency exsists for the single and multiple relation */
    private async dependencyCheck(scheduleIdArray: any[], _singleKeyDependencyData: any[], _multipleKeyDepedencyData: any[]) {
        if (scheduleIdArray.length) {
            const dependencyResult = await scheduleIdArray.map(async (schedulerId) => {
                _singleKeyDependencyData = await this.dependencyExistCheck(schedulerId, this.singleKeyDataModel);
                if (_singleKeyDependencyData.length) {
                    _singleKeyDependencyData.concat(_singleKeyDependencyData);
                }
                _multipleKeyDepedencyData = await this.dependencyExistCheck(schedulerId, this.multiKeyDataModel);
                if (_multipleKeyDepedencyData.length) {
                    _multipleKeyDepedencyData.concat(_multipleKeyDepedencyData);
                }
            });
            return Promise.all(dependencyResult).then(() => {
                return { _singleKeyDependencyData, _multipleKeyDepedencyData };
            }).catch(error => error);
        }
    }

    /** Method to get single and multiple dependency insert query based on the data array */
    private async getDependencyInsertQuery(_singleKeyDependencyData: any, insertQuerySingleDepArray: any, _multipleKeyDepedencyData: any, insertQueryMultipleDepArray: any) {
        let _multipleQueryArray = [];
        if (_singleKeyDependencyData) {
            insertQuerySingleDepArray = await this.makeInsertQuery(_singleKeyDependencyData, "single", _multipleQueryArray);
        }
        _multipleQueryArray = _multipleQueryArray.concat(insertQuerySingleDepArray._multipleQueryArray);
        if (_multipleKeyDepedencyData) {
            insertQueryMultipleDepArray = await this.makeInsertQuery(_multipleKeyDepedencyData, "multiple", _multipleQueryArray);
        }
        _multipleQueryArray = _multipleQueryArray.concat(insertQueryMultipleDepArray._multipleQueryArray);
        return { insertQuerySingleDepArray, insertQueryMultipleDepArray };
    }

    /** Get Concated Data of Individual Tables from two different tables */
    private async getConcatDataOfTable(_query: { scheduleId: String; }, _projection: { '_id': number; }, _filter: string, _filterArray: any[]) {
        const singleKeyData = await this.singleKeyDataModel
            .find(_query, _projection)
            .select(_filter);
        const multiKeyData = await this.multiKeyDataModel
            .find(_query, _projection)
            .select(_filter);
        _filterArray = _filterArray.concat(singleKeyData.map(element => element));
        _filterArray = _filterArray.concat(multiKeyData.map(element => element));
        return _filterArray;
    }

    /** Get Filter Data Count */
    private async getFilterDataCount(_query: {}, _sortOptions: Object) {
        const _collation = { locale: "en" };
        return await this.exeResultModel
            .find(_query)
            .select(_commonFilter)
            .collation(_collation)
            .sort(_sortOptions)
            .then(doc => {
                if (!doc[0]) {
                    return [];
                }
                return doc;
            });
    }

    /* Primary Method to get Data from DB */
    private async _getExecutionDetails(_query, _sortOptions: object) {
        const _collation = { locale: "en" };
        return await this.exeResultModel
            .find(_query)
            .select(_commonFilter)
            .skip(perPage * (pageNumber - 1))
            .limit(perPage)
            .collation(_collation)
            .sort(_sortOptions)
            .then(doc => {
                if (!doc[0]) {
                    return [];
                }
                return doc;
            });
    }

    /* Method to get Success Rate Array */
    private _getSuccessRateArray(doc: any, _sumObject: any, _countObject: any) {
        for (const element in doc) {
            let finalObject = {};
            const _tableDataCount = doc[element].toJSON().tableDataCount;
            const { childTable, diffInconsistenceData } = doc[element];
            const _inconsistentDataCount = this._size(diffInconsistenceData);
            const successRate = this._successRateAlgo(_inconsistentDataCount, _tableDataCount);
            finalObject = {
                childTable,
                successRate
            }
            _sumObject[childTable] = _sumObject[childTable] ? _sumObject[childTable] + successRate : successRate;
            _countObject[childTable] = _countObject[childTable] ? _countObject[childTable] + 1 : 1;
        }
        return _sumObject;
    }

    /* get Max value between two numbers */
    private _getMaxNumber(_page: number): number {
        return Math.max(1, _page);
    }

    /** Method to get Success Rate */
    private _successRateAlgo(_inconsistentDataCount: any, _tableDataCount: number): number {
        let successRate = 0;
        const _consistentDataCount = _tableDataCount - _inconsistentDataCount;
        if (_consistentDataCount && _tableDataCount) {
            successRate = (_consistentDataCount / _tableDataCount) * 100;
        }
        let _fixedValue = (Math.floor(100 * Number(successRate)) / 100).toFixed(2);
        return Number(_fixedValue);
    }

    /** Method to get size of an object*/
    private _size(obj) {
        let size = 0, key;
        for (key in obj) {
            if (obj.hasOwnProperty(key)) { size++ };
        }
        return size;
    };

    /**Method to get Total Records Count */
    private getTotalRecordCount = async (): Promise<any> => {
        const countSearchKey = { isDeleted: Constants['BOOLEAN_FALSE'] };
        const recordCount = await this.exeResultModel.countDocuments(countSearchKey);
        return recordCount;
    }

    /** Method to create temp folder if it doesn't exsist */
    private createFolder() {
        if (!fs.existsSync(tempPath)) {
            shell.mkdir('-p', tempPath);
        }
    }

}
