import { Utility } from '../common/utility';
import { SchemaCollection } from '../common/schemas/data-check.schema';
import { ExecutionResultController } from './execution-result.controller';
import { ExecutionResultService } from './execution-result.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';

const mongooseModel = Object.keys(SchemaCollection).map(name => {
    return { name, schema: SchemaCollection[name] };
});

@Module({
    imports: [MongooseModule.forFeature(mongooseModel)],
    controllers: [ExecutionResultController],
    providers: [ExecutionResultService, Utility],
    exports: [MongooseModule.forFeature(mongooseModel)]
})

export class ExecutionResultModule { }
