import { ExecutionResultController } from './execution-result.controller';
import { ExecutionResultModule } from './execution-result.module';
import { AppModule } from '../../src/app.module';
import { ExecutionResultService } from './execution-result.service';
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { Utility } from '../common/utility';

describe('ExecutionResultController', () => {
  let controller: ExecutionResultController;
  let app : INestApplication;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports:[ExecutionResultModule, AppModule],
      controllers: [ExecutionResultController],
      providers: [ExecutionResultService, Utility],
    }).compile();
    app = module.createNestApplication();
    controller = module.get<ExecutionResultController>(ExecutionResultController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('Get Distinct Scheduler Names', () => {
    it('should return an array of schedulers', async () =>{
      const result : any = ["s1","s2","s3","s4","s5","s10"];
    });
  });
});
