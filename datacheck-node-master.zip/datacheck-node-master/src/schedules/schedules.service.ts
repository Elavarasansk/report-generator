import { Model } from 'mongoose';
import { Injectable, NotFoundException, HttpException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { SchedulerRegistry } from '@nestjs/schedule';
import cronstrue from 'cronstrue';
import { CronJob } from 'cron';
import axios from 'axios';
import * as config from 'config';

import { Collection } from '../common/collections';
import { Constants } from '../common/constants';
import { Utility } from '../common/utility';
import { Scheduler, ERList, IndependentChildList, IndependentParentList, IntermediateList } from '../common/interface/schedules.interface';
import { TableRelationsInterface } from '../common/interface/tableRelations.interface';
import { DbDetails } from '../common/interface/db.interface';
import { ScheduleDetails, ScheduleFilter, PagingData } from '../common/dto/schedules.dto';
import { locale } from '../common/localization/dataCheckLocalization';



const { dbCollection } = Collection;
const { connector, host, port, controller, inconsistencyCheck } = config.schedulerConfig;
const schedulerControllerPath = `${connector}://${host}:${port}/${controller}/${inconsistencyCheck}`;

@Injectable()
export class SchedulesService {
    constructor(
        @InjectModel(dbCollection.DBDETAILS) private readonly dbDetailsModel: Model<DbDetails>,
        @InjectModel(dbCollection.TABLE_RELATIONS) private readonly erRelationModel: Model<TableRelationsInterface>,
        @InjectModel(dbCollection.INDEPENDENT_PARENT_LIST) private readonly independentParentListModel: Model<IndependentParentList>,
        @InjectModel(dbCollection.INDEPENDENT_CHILD_LIST) private readonly independentChildListModel: Model<IndependentChildList>,
        @InjectModel(dbCollection.INTERMEDIATE_TABLE_LIST) private readonly intermediateListModel: Model<IntermediateList>,
        @InjectModel(dbCollection.SCHEDULE) private readonly scheduleModel: Model<Scheduler>,
        @InjectModel(dbCollection.ERLIST) private readonly erListModel: Model<ERList>,
        @InjectModel(dbCollection.EXERESULT) private readonly executionResultModel: Model<ERList>,
        private readonly schedulerRegistry: SchedulerRegistry,
        private readonly Utility: Utility
    ) { }

    // Fetch TableList from relation_Info
    fetchTableList = async (dbId): Promise<any> => {

        await this.checkDBIdExistInRelationModel(dbId);
        const relationInfoList = await this.erRelationModel
            .aggregate([
                {
                    $match: {
                        "dbId": dbId
                    }
                },
                {
                    $group: {
                        _id: { dbId: "$dbId" },
                        parentTable: { $addToSet: '$parentTable' },
                        childTable: { $addToSet: '$childTable' },
                    }
                },
            ]);
        if (!relationInfoList[0]) {
            throw new NotFoundException(
                'RelationInfoList is Empty.'
            );
        }
        const parentTableList = relationInfoList[0]['parentTable'];
        const childTableList = relationInfoList[0]['childTable'];
        const unique_parent = await this.getTableList(parentTableList, childTableList, 0);
        const unique_child = await this.getTableList(childTableList, parentTableList, 0);
        const intermediate = await this.getTableList(parentTableList, childTableList, 1);
        const tableList = {
            unique_parent,
            unique_child,
            intermediate
        };
        return tableList;
    }

    // To check whether dbId exist in Relation Model
    checkDBIdExistInRelationModel = async (dbId): Promise<any> => {
        const relationSearchKey = { dbId };
        const relationalData = await this.erRelationModel
            .findOne(relationSearchKey);
        if (!relationalData) {
            throw new NotFoundException(
                'Configure your database first before setting up your jobs.'
            );
        }
    }
    // Find classified table lists
    getTableList = async (tableListFirst, tableListSecond, flagValue): Promise<any> => {
        const tableList = [];
        tableListFirst.forEach(tableElement => {
            if (flagValue === 0) {
                if (!(tableListSecond.includes(tableElement))) {
                    tableList.push(tableElement);
                }
            } else {
                if (tableListSecond.includes(tableElement)) {
                    tableList.push(tableElement);
                }
            }
        });
        return tableList;
    }

    // Save schedule details
    saveScheduleDetails = async (scheduleDetails: ScheduleDetails): Promise<any> => {
        const { scheduleName, dbId, cronExpression, jobTriggerMode, lang } = scheduleDetails;
        await this.checkDuplicateSchedule(scheduleName, lang);
        await this.checkDBIdExistInDBDetailsModel(dbId, lang);
        const { MANUAL, SCHEDULE } = Constants;
        try {
            if (jobTriggerMode === MANUAL) {
                scheduleDetails.cronExpression = "-";
                const savedSchedule = await this.makeSaveDetails(scheduleDetails);
                let { _id } = savedSchedule;
                _id = String(_id);
                await this.makeAxiosCall(_id);
            } else if (jobTriggerMode === SCHEDULE) {
                // Check for cron syntax
                cronstrue.toString(cronExpression);
                const savedSchedule = await this.makeSaveDetails(scheduleDetails);
                await this.scheduleJob(savedSchedule);
            }
        } catch (error) {
            throw error;
        }
    }

    // Create the schedule details object and perform save operation
    makeSaveDetails = async (scheduleDetails): Promise<any> => {
        const { scheduleName, dbId, cronExpression, lang } = scheduleDetails;
        let { selectedTables } = scheduleDetails;
        selectedTables = await this.convertToUpperCase(selectedTables);
        const erTableList = await this.concatTableList(selectedTables);
        const relationalInfo = await this.saveERListDetails(selectedTables, erTableList, dbId, lang);
        const erListId = relationalInfo['_id'];
        const schedule = {
            scheduleName,
            dbId,
            cronExpression,
            erListId,
            selectedTables
        }
        const scheduleData = new this.scheduleModel(schedule);
        const updatedSchedule = await this.setUserDateDetails(scheduleData);
        const savedSchedule = await updatedSchedule.save();
        return savedSchedule;
    }

    // Check whether duplicate schedulename exists
    checkDuplicateSchedule = async (scheduleName, lang): Promise<any> => {
        const scheduleSearchKey = { scheduleName, isDeleted: Constants.BOOLEAN_FALSE };
        const scheduleData = await this.scheduleModel
            .findOne(scheduleSearchKey);
        locale.setLanguage(lang);
        if (scheduleData) {
            throw new HttpException(
                locale.scheduler_msg_duplicate_job, 404
            );
        }
    }

    // Check whether dbId exist in DBDetails Model
    checkDBIdExistInDBDetailsModel = async (_id, lang): Promise<any> => {
        const dbDetailsSearchKey = { _id, isDeleted: Constants.BOOLEAN_FALSE };
        const dbDetailsData = await this.dbDetailsModel
            .findOne(dbDetailsSearchKey);
        locale.setLanguage(lang);
        if (!dbDetailsData) {
            throw new NotFoundException(
                locale.scheduler_msg_database_not_found
            );
        }
    }

    // Convert into uppercase
    convertToUpperCase = async (selectedTables): Promise<any> => {
        for (let key in selectedTables) {
            for (let value in selectedTables[key]) {
                selectedTables[key][value] = selectedTables[key][value].toUpperCase();
            }
        }
        return selectedTables;
    }

    // Concat the TableList
    concatTableList = async (selectedTables): Promise<any> => {
        const { unique_parent, unique_child, intermediate } = selectedTables;
        let erTableList = [];
        erTableList = erTableList
            .concat(unique_parent)
            .concat(unique_child)
            .concat(intermediate)
            .sort();
        return erTableList;
    }

    // Save Relational details
    saveERListDetails = async (selectedTables, erTableList, dbId, lang): Promise<any> => {
        const { unique_parent, unique_child, intermediate } = selectedTables;
        const relationalInfoName = JSON.stringify(erTableList);
        const relationSearchKey = { relationalInfoName };
        const erListData = await this.erListModel
            .findOne(relationSearchKey);
        if (erListData) {
            return erListData;
        }
        let IdList = [], searchKeyArray = [];
        if (unique_parent.length) {
            searchKeyArray = [dbId, 'parentTable'];
            IdList = await this.getTableListClassification(unique_parent, IdList, searchKeyArray);
        }
        if (unique_child.length) {
            searchKeyArray = [dbId, 'childTable'];
            IdList = await this.getTableListClassification(unique_child, IdList, searchKeyArray);
        }
        if (intermediate.length) {
            searchKeyArray = [dbId, 'parentTable'];
            IdList = await this.getTableListClassification(intermediate, IdList, searchKeyArray);
            searchKeyArray = [dbId, 'childTable'];
            IdList = await this.getTableListClassification(intermediate, IdList, searchKeyArray);
        }
        locale.setLanguage(lang);
        if (!IdList.length) {
            throw new HttpException(
                locale.scheduler_msg_erlist_not_selected, 404
            );
        }
        let relationalTableDetails = {
            relationalInfoName: relationalInfoName,
            relationInfoIdList: IdList
        }
        return await this.erListModel(relationalTableDetails).save();
    }

    // Fetch Relational ID of each table
    getTableListClassification = async (tableClassification, IdList, searchKeyArray): Promise<any> => {
        const selectedFields = '_id';
        const dbId = searchKeyArray[0];
        const tableClass = searchKeyArray[1];
        let searchKey = {};
        searchKey['dbId'] = `${dbId}`;
        const promises = tableClassification.map(async (tableElement) => {
            searchKey[`${tableClass}`] = tableElement;
            const data = await this.erRelationModel
                .find(searchKey)
                .select(selectedFields);
            data.forEach(dataElement => {
                const erListId = dataElement['_id'];
                const stringObj = String(erListId);
                if (!(IdList.includes(stringObj))) {
                    IdList.push(stringObj);
                }
            });
        });
        return Promise.all(promises)
            .then(() => IdList)
            .catch(error => error);
    }

    // Setting User Date details
    setUserDateDetails = async (listData): Promise<any> => {
        listData['createdUser'] = Constants['USER'];
        listData['createdDate'] = new Date();
        listData['updatedUser'] = Constants['USER'];
        listData['isDeleted'] = Constants['BOOLEAN_FALSE'];
        return listData;
    }

    // Get schedule details by applying filter
    getScheduleDetailsByFilter = async (scheduleFilter: ScheduleFilter): Promise<any> => {
        const { scheduleName, dbId, paging, lang, jobTriggerMode } = scheduleFilter;
        const { ENGLISH, JAPANESE, MANUAL } = Constants;
        let { limit, pageNum } = paging;
        if (!limit) {
            limit = 10;
        }
        pageNum = Math.max(1, pageNum);
        const keyword = jobTriggerMode === MANUAL ? `^MANUAL_.*${scheduleName}` : `^SCHEDULE_.*${scheduleName}`;
        let searchKey = {};
        if ((scheduleName && !dbId) || (!scheduleName && !dbId )) {
            searchKey['scheduleName'] = new RegExp(keyword, 'ig');
        } else {
            searchKey['dbId'] = new RegExp(dbId, 'ig');
            searchKey['scheduleName'] = new RegExp(keyword, 'ig');
        }
        searchKey['isDeleted'] = Constants['BOOLEAN_FALSE'];
        const selectedFields = 'scheduleName dbId cronExpression selectedTables';
        const fetchedData = await this.scheduleModel
            .find(searchKey)
            .select(selectedFields)
            .limit(limit)
            .skip(limit * (pageNum - 1));
        locale.setLanguage(lang);
        if (!(fetchedData.length)) {
            throw new NotFoundException(
                locale.scheduler_msg_job_not_found
            );
        }
        const newData = await this.addDBNameToScheduleData(fetchedData);
        const resultData = newData.sort((a, b) => a.scheduleName.localeCompare(b.scheduleName));
        const filteredResultCount = await this.getTotalRecordCount(this.scheduleModel, searchKey);
        const finalResultData = {
            resultData,
            resultCount: filteredResultCount
        };
        return finalResultData;
    }

    // Make resultData along with record count
    makeResultData = async (resultData): Promise<any> => {
        const countSearchKey = { isDeleted: Constants['BOOLEAN_FALSE'] };
        const resultCount = await this.getTotalRecordCount(this.scheduleModel, countSearchKey);
        const finalResultData = {
            resultData,
            resultCount
        }
        return finalResultData;
    }

    // Get TotalRecordCount
    getTotalRecordCount = async (dataModel, countSearchKey): Promise<any> => {
        const recordCount = await dataModel.countDocuments(countSearchKey);
        return recordCount;
    }

    // Delete schedule details
    deleteScheduleDetails = async (_id): Promise<any> => {
        const updateQuery = { $set: { isDeleted: Constants['BOOLEAN_TRUE'], updatedDate: Date.now(), updatedUser: Constants['USER'] } };
        const searchKey = { _id, isDeleted: Constants['BOOLEAN_FALSE'] };
        try {
            const scheduleIdData = await this.scheduleModel.findOne(searchKey);
            if (!scheduleIdData) {
                throw new NotFoundException(
                    'Requested Schedule is not found.'
                );
            }
            await this.scheduleModel.updateOne(searchKey, updateQuery, { new: true });
            const job = this.schedulerRegistry.getCronJob(_id);
            job.stop();
        } catch (error) {
            console.log(error);
        }
    }

    // Create dynamic job for cron operion
    scheduleJob = async (schedule): Promise<any> => {
        const { cronExpression } = schedule;
        let { _id } = schedule;
        try {
            _id = String(_id);
            const job = new CronJob(cronExpression, async () => {
                await this.makeAxiosCall(_id);
            });
            this.schedulerRegistry.addCronJob(_id, job);
            job.start();
        } catch (error) {
            console.log(error);
        }
    }

    // Java call for Scheduling operation
    makeAxiosCall = async (_id): Promise<any> => {
        axios.get(schedulerControllerPath, {
            params: {
                _id
            }
        }).catch((error) => error.response);
    }

    // Fetch All Schedule Details
    getAllScheduleDetails = async (pagingData: PagingData): Promise<any> => {
        let { limit, pageNum } = pagingData;
        if (!limit) {
            limit = 10;
        }
        pageNum = Math.max(1, pageNum);
        const searchKey = { isDeleted: Constants['BOOLEAN_FALSE'] };
        const selectedFields = 'scheduleName dbId cronExpression selectedTables';
        const fetchedData = await this.scheduleModel
            .find(searchKey)
            .select(selectedFields)
            .limit(limit)
            .skip(limit * (pageNum - 1));
        if (!(fetchedData.length)) {
            throw new NotFoundException(
                'you have not set up any job till yet. Make a new job and try again.'
            );
        }
        const newData = await this.addDBNameToScheduleData(fetchedData);
        const resultData = newData.sort((a, b) => a.scheduleName.localeCompare(b.scheduleName));
        const finalResultData = await this.makeResultData(resultData);
        return finalResultData;
    }

    // Create final schedule data with host and port details
    addDBNameToScheduleData = async (scheduleData): Promise<any> => {
        let newScheduleDataList = [];
        const promises = scheduleData.map(async (dataElement) => {
            const dbId = dataElement['dbId'];
            const { _id, scheduleName, cronExpression, selectedTables } = dataElement;
            const searchKey = { _id: dbId, isDeleted: Constants['BOOLEAN_FALSE'] };
            const selectedFields = 'oracleHostName oraclePort -_id';
            const dbData = await this.dbDetailsModel
                .findOne(searchKey)
                .select(selectedFields);
            if (dbData) {
                const { oracleHostName, oraclePort } = dbData;
                const dbName = `${oracleHostName}:${oraclePort}`;
                const newScheduleDataObject = {
                    _id,
                    scheduleName,
                    dbId,
                    dbName,
                    cronExpression,
                    selectedTables
                };
                newScheduleDataList.push(newScheduleDataObject);
            } else {
                await this.deleteScheduleDetails(_id);
            }
        });
        return Promise.all(promises)
            .then(() => newScheduleDataList)
            .catch(error => error);
    }

    // Update Schedule Details
    updateScheduleDetails = async (_id, scheduleDetails: ScheduleDetails): Promise<any> => {
        const { scheduleName, dbId, cronExpression, lang } = scheduleDetails;
        const searchKey = { _id, isDeleted: Constants['BOOLEAN_FALSE'] };
        try {
            // Check for cron syntax
            cronstrue.toString(cronExpression);
            let { selectedTables } = scheduleDetails;
            selectedTables = await this.convertToUpperCase(selectedTables);
            const erTableList = await this.concatTableList(selectedTables);
            const relationalInfo = await this.saveERListDetails(selectedTables, erTableList, dbId, lang);
            const erListId = relationalInfo['_id'];
            const updateQuery = { $set: { scheduleName, dbId, cronExpression, erListId, selectedTables, updatedDate: Date.now(), updatedUser: Constants['USER'] } };
            const updatedData = await this.scheduleModel
                .findOneAndUpdate(searchKey, updateQuery, { new: true });
            if (!updatedData) {
                throw new NotFoundException(
                    'You have not set up the requested job.'
                );
            }
            await this.scheduleJob(updatedData);
        } catch (error) {
            throw error;
        }
    }

    // Get table relation details
    getTableRelationDetails = async (dbId): Promise<any> => {
        const tableRelationList = {
            IndependentParent: [],
            IndependentChild: [],
            Intermediate: {}
        };
        const tableList = await this.fetchTableList(dbId);
        const { unique_parent, unique_child, intermediate } = tableList;
        let distinctKey, keyField;
        if (unique_parent.length) {
            distinctKey = 'childTable';
            keyField = 'parentTable';
            tableRelationList['IndependentParent'] = await this.fetchTableRelationObj(dbId, unique_parent, distinctKey, keyField);
        }
        if (unique_child.length) {
            distinctKey = 'parentTable';
            keyField = 'childTable';
            tableRelationList['IndependentChild'] = await this.fetchTableRelationObj(dbId, unique_child, distinctKey, keyField);
        }
        if (intermediate.length) {
            distinctKey = 'childTable';
            keyField = 'parentTable';
            const intermediateParent = await this.fetchTableRelationObj(dbId, intermediate, distinctKey, keyField);
            distinctKey = 'parentTable';
            keyField = 'childTable';
            const intermediateChild = await this.fetchTableRelationObj(dbId, intermediate, distinctKey, keyField);
            const intermediateObj = {}
            Object.keys(intermediateParent).forEach(key => {
                intermediateObj[key] = {
                    intermediateParent: intermediateParent[key],
                    intermediateChild: intermediateChild[key]
                }
            });
            tableRelationList['Intermediate'] = intermediateObj;
        }
        return tableRelationList;
    }

    // Fetch Relation details for each classification
    fetchTableRelationObj = async (dbId, tableList, distinctKey, keyField): Promise<any> => {
        const relationObj = {};
        const searchKey = { dbId };
        const promises = tableList.map(async (tableElement) => {
            searchKey[`${keyField}`] = tableElement;
            const relatedTableList = await this.erRelationModel
                .find(searchKey)
                .distinct(distinctKey);
            if (relatedTableList.length) {
                relationObj[`${tableElement}`] = relatedTableList;
            }
        });
        return Promise.all(promises)
            .then(() => relationObj)
            .catch(error => error);
    }

    // Separate independent parent, child and intermediate into 3 schemas
    extractTableRelations = async (tableRelations): Promise<any> => {
        tableRelations['parentTable'] = tableRelations['parentTable'].toUpperCase();
        tableRelations['childTable'] = tableRelations['childTable'].toUpperCase();
        const { parentTable, childTable, dbId } = tableRelations;
        const searchKey = { dbId };
        const parentRecordCount = await this.getTotalRecordCount(this.independentParentListModel, searchKey);
        const childRecordCount = await this.getTotalRecordCount(this.independentChildListModel, searchKey);
        const intermediateRecordCount = await this.getTotalRecordCount(this.intermediateListModel, searchKey);
        if (!parentRecordCount && !childRecordCount && !intermediateRecordCount) {
            await this.checkForEmptyLists(parentTable, childTable, dbId);
        } else {
            await this.checkForNotToBeEmptyLists(parentTable, childTable, dbId);
        }
    }

    // Condition 1 - Check when lists are empty
    checkForEmptyLists = async (parentTable, childTable, dbId): Promise<any> => {
        const { UNIQUE_PARENT, UNIQUE_CHILD, INSERT } = Constants;
        const operationKey = ['', INSERT];
        operationKey[0] = UNIQUE_PARENT;
        await this.updateModel(operationKey, dbId, parentTable, this.independentParentListModel);
        operationKey[0] = UNIQUE_CHILD;
        await this.updateModel(operationKey, dbId, childTable, this.independentChildListModel);
    }

    // Condition 2 - Check when all list is not empty
    checkForNotToBeEmptyLists = async (parentTable, childTable, dbId): Promise<any> => {
        let parentDataCheck, childDataCheck, intermediateDataCheck;
        const { UNIQUE_PARENT, UNIQUE_CHILD, INTERMEDIATE, INSERT, EXIST_CHECK, DELETE } = Constants;
        const operationKey = ['', EXIST_CHECK];
        /** Check for parent table */
        operationKey[0] = UNIQUE_PARENT;
        parentDataCheck = await this.updateModel(operationKey, dbId, parentTable, this.independentParentListModel);
        if (!parentDataCheck) { /** No duplicate parent */
            operationKey[0] = UNIQUE_CHILD;
            childDataCheck = await this.updateModel(operationKey, dbId, parentTable, this.independentChildListModel);
            if (!childDataCheck) { /** Given parent table does not exists as child table */
                operationKey[0] = INTERMEDIATE;
                intermediateDataCheck = await this.updateModel(operationKey, dbId, parentTable, this.intermediateListModel);
                if (!intermediateDataCheck) { /** Given parent table does not exists as intermediate */
                    operationKey[0] = UNIQUE_PARENT;
                    operationKey[1] = INSERT;
                    await this.updateModel(operationKey, dbId, parentTable, this.independentParentListModel);
                }
            } else {
                operationKey[0] = UNIQUE_CHILD;
                operationKey[1] = DELETE;
                await this.updateModel(operationKey, dbId, parentTable, this.independentChildListModel); /** Delete from Independent child */
                operationKey[0] = INTERMEDIATE;
                operationKey[1] = INSERT;
                await this.updateModel(operationKey, dbId, parentTable, this.intermediateListModel); /** Insert into Intermediate */
            }
        }

        /** Check for child table */
        operationKey[0] = UNIQUE_CHILD;
        operationKey[1] = EXIST_CHECK;
        childDataCheck = await this.updateModel(operationKey, dbId, childTable, this.independentChildListModel);
        if (!childDataCheck) { /** No duplicate child  */
            operationKey[0] = UNIQUE_PARENT;
            parentDataCheck = await this.updateModel(operationKey, dbId, childTable, this.independentParentListModel);
            if (!parentDataCheck) { /** Given child table does not exists as parent table */
                operationKey[0] = INTERMEDIATE;
                intermediateDataCheck = await this.updateModel(operationKey, dbId, childTable, this.intermediateListModel);
                if (!intermediateDataCheck) { /** Given child table does not exists as intermediate */
                    operationKey[0] = UNIQUE_CHILD;
                    operationKey[1] = INSERT;
                    await this.updateModel(operationKey, dbId, childTable, this.independentChildListModel);
                }
            } else {
                operationKey[0] = UNIQUE_PARENT;
                operationKey[1] = DELETE;
                await this.updateModel(operationKey, dbId, childTable, this.independentParentListModel); /** Delete from Independent parent */
                operationKey[0] = INTERMEDIATE;
                operationKey[1] = INSERT;
                await this.updateModel(operationKey, dbId, childTable, this.intermediateListModel); /** Insert into Intermediate */
            }
        }
    }

    // Perform data existence check, insert or delete accordingly
    updateModel = async (key, dbId, tableElement, dataModel): Promise<any> => {
        const { UNIQUE_PARENT, UNIQUE_CHILD, INTERMEDIATE, EXIST_CHECK, INSERT, DELETE } = Constants;
        let objKey;
        const dataObj = { dbId };
        if (key[0] === UNIQUE_PARENT) {
            objKey = 'uniqueParentTable';
        } else if (key[0] === UNIQUE_CHILD) {
            objKey = 'uniqueChildTable';
        } else if (key[0] === INTERMEDIATE) {
            objKey = 'intermediateTable';
        }
        dataObj[objKey] = tableElement;
        switch (key[1]) {
            case EXIST_CHECK:
                return await dataModel.findOne(dataObj);
            case INSERT:
                const newData = new dataModel(dataObj);
                await newData.save();
                break;
            case DELETE:
                await dataModel.deleteOne(dataObj);
                break;
        }
    }

    // Get Independent Parent, child and intermediate data
    fetchClassifiedData = async (dbId, classificationKey, pagingData): Promise<any> => {
        let { limit, pageNum } = pagingData;
        const { UNIQUE_PARENT, UNIQUE_CHILD, INTERMEDIATE } = Constants;
        let selectedFields, dataModel, objKey;
        const resultData = [];
        if (!limit) {
            limit = 10;
        }
        pageNum = Math.max(1, pageNum);
        const searchKey = { dbId };
        switch (classificationKey) {
            case UNIQUE_PARENT:
                selectedFields = 'uniqueParentTable -_id';
                dataModel = this.independentParentListModel;
                objKey = 'uniqueParentTable';
                break;
            case UNIQUE_CHILD:
                selectedFields = 'uniqueChildTable -_id';
                objKey = 'uniqueChildTable';
                dataModel = this.independentChildListModel;
                break;
            case INTERMEDIATE:
                selectedFields = 'intermediateTable -_id';
                objKey = 'intermediateTable';
                dataModel = this.intermediateListModel;
                break;
        }
        const fetchedData = await dataModel
            .find(searchKey)
            .select(selectedFields)
            .limit(limit)
            .skip(limit * (pageNum - 1));
        fetchedData.forEach(element => {
            resultData.push(element[objKey]);
        });
        const countSearchKey = {};
        let resultCount = 0;
        if (resultData.length) {
            resultCount = await this.getTotalRecordCount(dataModel, countSearchKey);
        }
        return {
            resultData,
            resultCount
        };
    }

    // Email Notification to Users
    notifyWithMail = async (schedulerId, startTime, endTime): Promise<any> => {
        const { sendMailOptions } = this.Utility;
        const { from, to, subject} = config.mailOptions;
        const searchKey = { schedulerId, isDeleted: Constants.BOOLEAN_FALSE };
        const selectedFields = 'schedulerName -_id';
        const resultData = await this.executionResultModel
            .findOne(searchKey)
            .select(selectedFields);
        if(resultData) {
            const { schedulerName } = resultData;
            const mailOptions = {
                from,
                to,
                subject,
                text: `Job named ${schedulerName} is triggered at ${startTime} and execution is finished at ${endTime}`
            };
            await sendMailOptions(mailOptions);
        }
    }
}