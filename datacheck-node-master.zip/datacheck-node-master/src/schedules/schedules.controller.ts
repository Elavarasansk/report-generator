import { Controller, Get, Post, Param, Response, Request, Body, Put, Delete } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';

import { Utility } from '../common/utility';
import { ResMessage } from '../common/res.message';
import { ScheduleDetails, ScheduleFilter, PagingData } from '../common/dto/schedules.dto';
import { SchedulesService } from './schedules.service';

@Controller('schedules')
@ApiTags('schedules')

// SchedulesContoller class is used for scheduling operations
export class SchedulesController {
    constructor(
        private readonly schedulesService: SchedulesService,
        private readonly Utility: Utility
    ) { }

    // Get unique-parent-child-intermediate tableList in a particular DB
    @Get('fetchTableList/:_dbId')
    public async fetchTableList(@Response() res, @Request() req, @Param('_dbId') _dbId: string) {
        const { fetchTableList } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await fetchTableList(_dbId);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    // Save schedule details
    @Post('saveScheduleDetails')
    public async saveScheduleDetails(@Response() res, @Request() req, @Body() scheduleDetails: ScheduleDetails) {
        const { saveScheduleDetails } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await saveScheduleDetails(scheduleDetails);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    //Fetch schedule details by applying filter
    @Post('getScheduleDetailsByFilter')
    public async getScheduleDetailsByFilter(@Response() res, @Request() req, @Body() scheduleFilter: ScheduleFilter) {
        const { getScheduleDetailsByFilter } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await getScheduleDetailsByFilter(scheduleFilter);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    //Delete schedule details
    @Delete(':_scheduleId')
    public async deleteScheduleDetails(@Request() req, @Response() res, @Param('_scheduleId') _scheduleId: string) {
        const { deleteScheduleDetails } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await deleteScheduleDetails(_scheduleId);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    // Get all schedule details
    @Post('getAllScheduleDetails')
    public async getAllScheduleDetails(@Response() res, @Request() req, @Body() pagingData: PagingData) {
        const { getAllScheduleDetails } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await getAllScheduleDetails(pagingData);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    // Update schedule details
    @Put(':_scheduleId')
    public async updateScheduleDetails(@Response() res, @Request() req, @Param('_scheduleId') _scheduleId: string, @Body() scheduleDetails: ScheduleDetails) {
        const { updateScheduleDetails } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await updateScheduleDetails(_scheduleId, scheduleDetails);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    // Get parent child relation details for each independent parent, child and intermediate table
    @Get('getTableRelationDetails/:_dbId')
    public async getTableRelationDetails(@Response() res, @Request() req, @Param('_dbId') _dbId: string) {
        const { getTableRelationDetails } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await getTableRelationDetails(_dbId);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    @Post('fetchClassifiedData/:_dbId/:_classificationKey')
    public async fetchClassifiedData(
        @Response() res,
        @Request() req,
        @Param('_dbId') _dbId: string,
        @Param('_classificationKey') _classificationKey: string,
        @Body() pagingData: PagingData) {
        const { fetchClassifiedData } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await fetchClassifiedData(_dbId, _classificationKey, pagingData);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }

    // Mail Notification after scheduling
    @Get('sendMail/:scheduleId/:start/:end')
    public async notifyWithMail(
        @Response() res,
        @Request() req,
        @Param('scheduleId') scheduleId: string,
        @Param('start') startTime: string,
        @Param('end') endTime: string) {
        const { notifyWithMail } = this.schedulesService;
        const { sendSuccess, sendError } = this.Utility;
        try {
            const result = await notifyWithMail(scheduleId, startTime, endTime);
            return sendSuccess(req, res, result, ResMessage.SUCCESS);
        } catch (error) {
            return sendError(req, res, error);
        }
    }
}
