import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ScheduleModule } from '@nestjs/schedule';

import { Utility } from '../common/utility';
import { SchemaCollection } from '../common/schemas/data-check.schema';
import { SchedulesController } from './schedules.controller';
import { SchedulesService } from './schedules.service';

const mongooseSchemModel = Object.keys(SchemaCollection).map(name => {
    return {name, schema:SchemaCollection[name]};
});
@Module({
    imports: [ScheduleModule.forRoot(),
        MongooseModule.forFeature(mongooseSchemModel)],
    controllers: [SchedulesController],
    providers: [SchedulesService , Utility],
    exports: [SchedulesService]
})

export class SchedulesModule {}
