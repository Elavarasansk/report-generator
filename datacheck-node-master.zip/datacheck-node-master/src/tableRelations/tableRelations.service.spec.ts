import { Test, TestingModule } from '@nestjs/testing';
import { TableRelationsService } from './tableRelations.service';

describe('TableRelationsService', () => {
  let service: TableRelationsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TableRelationsService],
    }).compile();

    service = module.get<TableRelationsService>(TableRelationsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
