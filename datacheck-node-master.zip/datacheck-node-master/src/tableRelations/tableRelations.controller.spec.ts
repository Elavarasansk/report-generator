import { Test, TestingModule } from '@nestjs/testing';
import { TableRelationsController } from './tableRelations.controller';

describe('TableRelations Controller', () => {
  let controller: TableRelationsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TableRelationsController],
    }).compile();

    controller = module.get<TableRelationsController>(TableRelationsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
