import { Controller, Get, Post, Request, Response, Param, Body, UseInterceptors, UploadedFile, Options, Put } from '@nestjs/common';
import { ApiTags, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import * as config from 'config';
import { Constants } from 'src/common/constants';
import { ResMessage } from '../common/res.message';
import { TableRelationsService } from './tableRelations.service';
import { TableRelationsDto, InputSqlTableRelationsDto, SearchTableRelationDataDto } from '../common/dto/tableRelations.dto';
import { Utility } from '../common/utility';
import { locale } from '../common/localization/dataCheckLocalization';


@Controller('relation')
@ApiTags('relation')
export class TableRelationsController {
  constructor(private readonly tableRelationsService: TableRelationsService,
    private readonly Utility: Utility) { }

  // Get the Table Data Starts with the given Parameter.
  @Get('tablemetasuggest/:_lang/:_tablename/:_maxlimit/:_dbid')
  public async getTableNameSuggestion(@Request() request, @Response() response,
    @Param('_lang') lang: string, @Param('_tablename') tableName: string,
    @Param('_maxlimit') maxLimit: Number, @Param('_dbid') dbId: string) {
    const { getTableNameSuggestion } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await getTableNameSuggestion(dbId, tableName, maxLimit, lang);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Get the Table Data for the given tableName.
  @Get('tablemetadata/:_lang/:_tablename/:_dbid')
  public async getTableData(@Request() request, @Response() response,
    @Param('_lang') lang: string, @Param('_tablename') tableName: string,
    @Param('_dbid') dbId: string) {
    const { getTableData } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await getTableData(dbId, tableName, lang);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Get the Table Column Data for the given tableName.
  @Get('tablemetacolumns/:_lang/:_tablename/:_dbid')
  public async getTableColumnData(@Request() request, @Response() response,
    @Param('_lang') lang: string, @Param('_tablename') tableName: string,
    @Param('_dbid') dbId: string) {
    const { getTableColumnData } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await getTableColumnData(dbId, tableName, lang);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Get the Table Primary Key Column Data for the given tableName.
  @Get('primarykeycolumns/:_lang/:_tablename/:_dbid')
  public async getPrimaryKeyColumnData(@Request() request, @Response() response,
    @Param('_lang') lang: string, @Param('_tablename') tableName: string,
    @Param('_dbid') dbId: string) {
    const { getPrimaryKeyColumnData } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await getPrimaryKeyColumnData(dbId, tableName, lang);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Get the Table Relation Data based on searchCondition from the collection.
  @Post('tablerelationdata')
  public async getAllRelationTableData(@Request() request, @Response() response,
  @Body() searchTableRelationDataDto: SearchTableRelationDataDto) {
    const { getAllRelationTableData } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await getAllRelationTableData(searchTableRelationDataDto);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Get all the table data from the relational_info collection through sql.
  @Post('sqltablerelationdata')
  public async getSqlRelationTableData(@Request() request, @Response() response,
    @Body() tableRelationBySqlParam: InputSqlTableRelationsDto) {
    const { getSqlRelationTableData } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    const { lang } = tableRelationBySqlParam;
    locale.setLanguage(lang);
    try {
      const result = await getSqlRelationTableData(tableRelationBySqlParam);
      return sendSuccess(request, response, result, locale.data_loaded_success);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Download Table Relation details.
  @Get('download/:_lang/:_dbId')
  public async downloadTableRelationDetails(@Request() request, @Response() response,
    @Param('_lang') lang: string, @Param('_dbId') dbId: string) {
    const { downloadDbDetails } = this.tableRelationsService;
    const { sendError } = this.Utility;
    const { contentType, contentDisposition } = config.excelDownloadConfig;
    try {
      const workbook = await downloadDbDetails(dbId, lang);
      response.setHeader('Content-Type', contentType);
      response.setHeader("Content-Disposition", contentDisposition + Constants.EXCEL_FILE_NAME);
      workbook.xlsx.write(response);
      return workbook;
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Insert One entry into DB Uniquely with parentColumn and childColumn.
  @Post('insertone')
  public async postTableRelationData(@Request() request, @Response() response, @Body() param: TableRelationsDto) {
    const { postTableRelationData } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await postTableRelationData(param);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Insert Multiple columns of the table into DB.
  @Post('insertmany')
  public async postTableRelationsList(@Request() request, @Response() response, @Body() param: TableRelationsDto[]) {
    const { postTableRelationsDetails } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const result = await postTableRelationsDetails(param);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }

  // Insert Multiple entries into DB through file upload.
  @Post('fileupload')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({ schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } } })
  public async postTableRelationsDetails(@Request() request, @Response() response, @UploadedFile('file') fileData) {
    const { postTableRelationsDetails } = this.tableRelationsService;
    const { sendSuccess, sendError } = this.Utility;
    try {
      const tableRelationsDto: TableRelationsDto[] = JSON.parse(fileData.buffer);
      const result = await postTableRelationsDetails(tableRelationsDto);
      return sendSuccess(request, response, result, ResMessage.SUCCESS);
    } catch (e) {
      return sendError(request, response, e);
    }
  }
}
