import { Injectable, NotFoundException, } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import axios from 'axios';
import * as config from 'config';
import { Collection } from '../common/collections';
import { Constants } from '../common/constants';
import {TableRelationsInterface, TableMetaDataInterface, DBDetailsInterface } from '../common/interface/tableRelations.interface';
import { TableRelationsDto, InputSqlTableRelationsDto, SearchTableRelationDataDto } from '../common/dto/tableRelations.dto';
import { SchedulesService } from '../schedules/schedules.service';
import { locale } from '../common/localization/dataCheckLocalization';

const excel = require('exceljs');

const { perPage } = Constants.paging;
const { connector, host, port, controller, tableRelationBySql } = config.tableRelationConfig;
const tableRelationControllerPath = `${connector}://${host}:${port}/${controller}/${tableRelationBySql}`;

@Injectable()
export class TableRelationsService {
    constructor(
        @InjectModel(Collection.dbCollection.TABLE_RELATIONS)
        private readonly tableRelationsModel: Model<TableRelationsInterface>,
        @InjectModel(Collection.dbCollection.TABLEMETADATA)
        private readonly tableMetaDataModel: Model<TableMetaDataInterface>,
        @InjectModel(Collection.dbCollection.DBDETAILS)
        private readonly dbDetailsModel: Model<DBDetailsInterface>,
        private readonly schedulesService: SchedulesService
    ){}

    // Making Regular Express for Find Query StartsWith.
    useRegExp = expName => {
        return new RegExp('^' + expName);
    }

    // Used to format the locale message along with parameter
    formatString = (message, variables) => {
      return locale.formatString(message, variables);
    }
    
    // Get the Table Data Starts with the given Parameter.
    getTableNameSuggestion = async (dbId, tableName, maxLimit, lang): Promise<any> => {
        tableName = tableName.toUpperCase();
        const result = await this.tableMetaDataModel
        .find({dbIdList: {$in: dbId}, tableName: this.useRegExp(tableName)}, {_id: 0, tableName: 1})
        .limit(JSON.parse(maxLimit))
        .sort('tableName');
        return result.map(key => key['tableName']);
    }

    // Get the Table Data for the given tableName.
    getTableData = async (dbId, tableName, lang): Promise<any> => {
        tableName = tableName.toUpperCase();
        const result = await this.tableMetaDataModel.findOne({dbIdList: {$in: dbId}, tableName});
        locale.setLanguage(lang);
        if (!result){
            throw new NotFoundException(this.formatString(locale.table_not_present, {tableName}));
        }
        return result;
    }

    // Get the Table Column Data for the given tableName.
    getTableColumnData = async (dbId, tableName, lang): Promise<any> => {
        const orderedData= {};
        const unorderedData = await this.tableMetaDataModel
        .findOne({dbIdList: {$in: dbId}, tableName: tableName.toUpperCase()}, {_id:0, columnList:1});
        locale.setLanguage(lang);
        if (!unorderedData){
            throw new NotFoundException(this.formatString(locale.column_not_present, {tableName}));
        }
        Object.keys(unorderedData['columnList']).sort().forEach(key => {
            orderedData[key] = unorderedData['columnList'][key];
        });
        return orderedData;
    }

    // Get the Table Primary Key Column Data for the given tableName.
    getPrimaryKeyColumnData = async (dbId, tableName, lang): Promise<any> => {
        const orderedData= {};
        const unorderedData = await this.tableMetaDataModel
        .findOne({dbIdList: {$in: dbId}, tableName: tableName.toUpperCase()}, {_id:0, primaryKeyList:1});
        locale.setLanguage(lang);
        if (!unorderedData){
            throw new NotFoundException(this.formatString(locale.primary_key_not_present, {tableName}));
        }
        Object.keys(unorderedData['primaryKeyList']).sort().forEach(key => {
            orderedData[key] = unorderedData['primaryKeyList'][key];
        });
        return orderedData;
    }

    // Get the Table Relation Data based on searchCondition from the collection.
    getAllRelationTableData = async (searchTableRelationDataDto: SearchTableRelationDataDto): Promise<any> => {
        const { parentTable, childTable, dbId, pageNumber } = searchTableRelationDataDto;
        const searchCondition = {dbId, parentTable:this.useRegExp(parentTable), childTable:this.useRegExp(childTable)};
        const totalCount =  await this.tableRelationsModel.countDocuments(searchCondition);
        const resultData = await this.tableRelationsModel.find(searchCondition).skip(perPage * (pageNumber - 1)).limit(perPage);
        return {totalCount, resultData};
    }

    // Get all the Table Relation through Input SQL from the collection.
    getSqlRelationTableData = async (inputSqlTableRelationsDto: InputSqlTableRelationsDto): Promise<any> => {
        const { dbId, sql, lang } = inputSqlTableRelationsDto;
        try{
            return await axios.post(tableRelationControllerPath, {
            dbId, sql, lang
            }).then(response => {
                if(!response['data'].length){
                    throw new NotFoundException(response['data']['errorMessage'])
                }
                return response['data'];
            });
        }catch(exception){
            throw new NotFoundException(exception['response']['data']['message']);
        }
    }

    // Download Table Relation details.
    downloadDbDetails = async (dbId, lang): Promise<any> => {
        const tableRelationList = await this.tableRelationsModel.find({dbId});
        const dbData = await this.dbDetailsModel.findOne({ _id: dbId});
        var workbook = new excel.Workbook();
        var worksheet = workbook.addWorksheet('Table Relation Data');
        worksheet.columns = [
            { header: 'Data Base', key: 'dataBase', width: 22},
            { header: 'Parent Table', key: 'parentTable', width: 30 },
            { header: 'Parent Column', key: 'parentColumn', width: 30 },
            { header: 'Child Table', key: 'childTable', width: 22 },
            { header: 'Child Column', key: 'childColumn', width: 22 }
        ];
        if (tableRelationList) {
            tableRelationList.forEach(tableRelationData => {
                tableRelationData['dataBase'] = `${dbData.oracleHostName}:${dbData.oraclePort}`;
                worksheet.addRow(tableRelationData);
            });
        }
        return workbook;
    }

    // Check the Table Data present in Table Metadata or not.
    checkTableMetaData = async (tableRelationsDto: TableRelationsDto): Promise<any> => {
        const { parentTable, parentColumn, childTable, childColumn, dbId, lang } = tableRelationsDto
        let checkPrimaryKey, checkColumnKey;
        locale.setLanguage(lang);
        if(parentTable === childTable){
            throw new NotFoundException(locale.same_table);
        }
        await this.tableMetaDataModel
        .findOne({dbIdList: {$in: dbId}, tableName: parentTable}, {_id:0, columnList:1})
        .then(primaryKeydata => {
            if(!primaryKeydata){
                throw new NotFoundException(this.formatString(locale.check_parent_table, {parentTable}));
            }else{
                if(!primaryKeydata['columnList']){
                    throw new NotFoundException(this.formatString(locale.primary_key_list_not_present, {parentTable}));
                }
                checkPrimaryKey = Object.keys(primaryKeydata['columnList']).includes(parentColumn);
                if(!checkPrimaryKey){
                    throw new NotFoundException(this.formatString(locale.check_parent_table_column, {parentColumn, parentTable}));
                }
            }
        });
        await this.tableMetaDataModel
        .findOne({dbIdList: {$in: dbId}, tableName: childTable}, {_id:0, columnList:1})
        .then(childColumnData => {
            if(!childColumnData){
                throw new NotFoundException(this.formatString(locale.check_child_table, {childTable}));
            }else{
                if(!childColumnData['columnList']){
                    throw new NotFoundException(this.formatString(locale.column_not_present_child, {childTable}));
                }
                checkColumnKey = Object.keys(childColumnData['columnList']).includes(childColumn);
                if(!checkColumnKey){
                    throw new NotFoundException(this.formatString(locale.check_child_table_column, {childColumn, childTable}));
                }
            }
        });
    }

    // Insert One entry into DB Uniquely with parent and child table.
    postTableRelationData = async (tableRelationsDto: TableRelationsDto ): Promise<any> => {
        const {parentTable, parentColumn, childTable, childColumn, dbId, lang} = tableRelationsDto;
        locale.setLanguage(lang);
        if(parentTable && parentColumn && childTable && childColumn && dbId){
            await this.checkTableMetaData(tableRelationsDto);
            await this.tableRelationsModel.findOneAndUpdate({parentTable, parentColumn, childTable, childColumn, dbId}, {}, {upsert:true});
            await this.schedulesService.extractTableRelations({parentTable, parentColumn, childTable, childColumn, dbId});
        }else{
            throw new NotFoundException(locale.check_parameters);
        }
    }

    // Insert Multiple entries into DB.
    postTableRelationsDetails = async (tableRelationsDto: TableRelationsDto[]): Promise<any> => {
        await Promise.all(tableRelationsDto.map(async tableRelation => {
            await this.postTableRelationData(tableRelation);
        }));
    }

}
