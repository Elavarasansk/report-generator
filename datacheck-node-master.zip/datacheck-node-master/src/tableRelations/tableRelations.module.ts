import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SchemaCollection } from '../common/schemas/data-check.schema';
import { TableRelationsController } from './tableRelations.controller';
import { TableRelationsService } from './tableRelations.service';
import { Utility } from '../common/utility';
import { SchedulesModule } from '../schedules/schedules.module';
import { SchedulesService } from '../schedules/schedules.service';

const mongooseModel = Object.keys(SchemaCollection).map(name =>{
  return {name, schema:SchemaCollection[name]};
  });

@Module({
  imports: [MongooseModule.forFeature(mongooseModel), SchedulesModule],
  controllers: [TableRelationsController],
  providers: [TableRelationsService, SchedulesService, Utility]
})
export class TableRelationsModule {}
