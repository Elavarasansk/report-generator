import { Controller } from '@nestjs/common';

@Controller('user-management')
export class UserManagementController {
    
    
    
    
}
