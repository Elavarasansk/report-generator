import { Module } from '@nestjs/common';
import { DbController } from './db.controller';
import { DbService } from './db.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Collection } from '../common/collections';
import { SchemaCollection } from '../common/schemas/data-check.schema';
import { Utility } from '../common/utility';

const mongooseSchemaModule = Object.keys(SchemaCollection).map(name => {
  return {name, schema:SchemaCollection[name]};
})

@Module({
  imports: [
    MongooseModule.forFeature(mongooseSchemaModule)
  ],
  controllers: [DbController],
  providers: [DbService , Utility],
  exports : [MongooseModule.forFeature(mongooseSchemaModule)
]

})
export class DbModule {}
