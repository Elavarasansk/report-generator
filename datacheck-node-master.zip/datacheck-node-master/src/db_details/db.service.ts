import { Injectable, NotFoundException } from '@nestjs/common';
import { Model, PassportLocalModel, Types } from "mongoose";
import { InjectModel } from '@nestjs/mongoose';
import { Collection } from '../common/collections';
import { DbDetails } from '../common/interface/db.interface';
import { DbConfigDetails } from '../common/dto/db.dto';
import { Constants } from '../common/constants';
import * as config from 'config';
import { ResMessage } from '../common/res.message';
import { locale } from '../common/localization/dataCheckLocalization';

const excel = require('exceljs');
const axios = require('axios');
const crypto = require('crypto');
const { connector, host, port, controller } = config.oracleConnectivityPath;
const { connectivityMethod, metadataMethod } = config.methodPath;
const oracleControllerPath = `${connector}://${host}:${port}/${controller}/${connectivityMethod}`;
const metadataControllerPath = `${connector}://${host}:${port}/${controller}/${metadataMethod}`;

@Injectable()
export class DbService {
  constructor(
    @InjectModel(Collection.dbCollection.DBDETAILS) private readonly dbDetailsModel: PassportLocalModel<DbDetails>,
  ) { }

  // Used to format the locale message along with parameter
  formatString = (message, variables) => {
    return locale.formatString(message, variables);
  }

  //Get all database configuration details
  getDbDetails = async (pagingFilter): Promise<any> => {
    const { lang } = pagingFilter;
    const { page, size } = pagingFilter.paging;
    const dataCount = await this.dbDetailsModel.countDocuments({ isDeleted: Constants.BOOLEAN_FALSE});
    const dbData = await this.dbDetailsModel.find({ isDeleted: Constants.BOOLEAN_FALSE }).skip(size * (page - 1)).limit(parseInt(size));
    locale.setLanguage(lang);
    dbData.forEach((data) => {
      data.oracleUserName = '*****';
      data.oraclePassword = '*****';
    }
    );
    if (!dbData) {
      throw new NotFoundException(locale.db_details_not_found);
    }
    return {
      data : dbData,
      count : dataCount
    };
  }

  //Insert database configuration details
  postDbDetails = async (dbConfigDetails: DbConfigDetails): Promise<any> => {
    const { oracleUserName, oraclePassword, dbType, oracleHostName, oraclePort, oracleServiceId, oracleSchema, lang } = dbConfigDetails;

    dbConfigDetails.oracleUserName = encryptData(oracleUserName);
    dbConfigDetails.oraclePassword = encryptData(oraclePassword);
    locale.setLanguage(lang);
    if (!dbType) {
      dbConfigDetails.dbType = Constants.DB_TYPE;
    }
    if(await this.checkIfAlreadyExist(dbConfigDetails)) {
      throw new NotFoundException(locale.db_details_already_exist);
    }
    const results = await axios.post(oracleControllerPath, {
        oracleHostName,
        oraclePort,
        oracleServiceId,
        oracleUserName,
        oraclePassword,
        oracleSchema
    }).then((response) => {
        return this.addDatabaseDetails(response, dbConfigDetails);
    }).catch((error) => {
      return error.response;
    });
    const { message, hasError } = results;
    if(hasError){
      throw new NotFoundException(message);
    }
    return message;
  }

  //Update database confiuration details
  putDbDetails = async (_id: string, dbConfigDetails: DbConfigDetails): Promise<any> => {
    const { oracleUserName, oraclePassword, dbType, oracleHostName, oraclePort, oracleServiceId, oracleSchema } = dbConfigDetails;
    dbConfigDetails.oracleUserName = encryptData(oracleUserName);
    dbConfigDetails.oraclePassword = encryptData(oraclePassword);
    if (!dbType) {
      dbConfigDetails.dbType = Constants.DB_TYPE;
    }
    const results = await axios.post(oracleControllerPath, {
        oracleHostName,
        oraclePort,
        oracleServiceId,
        oracleUserName,
        oraclePassword,
        oracleSchema
    }).then((response) => {
        return this.updateDatabaseDetails(response, dbConfigDetails, _id);
    }).catch((error) => {
      return error.response;
    });
    return results;
  }

  //Delete database configuration details
  deleteDbDetails = async (lang, _id): Promise<any> => {
    const dbData = await this.dbDetailsModel.findOneAndUpdate({ _id }, { $set: { isDeleted: Constants.BOOLEAN_TRUE } }, { new: true });
    locale.setLanguage(lang);
    if (!dbData) {
      throw new NotFoundException(locale.db_details_not_found);
    }
    return this.formatString(locale.host_deleted, {hostName: dbData.oracleHostName});
  }

  //Download database configuration details
  downloadDbDetails = async (): Promise<any> => {
    const dbData = await this.dbDetailsModel.find();
    var workbook = new excel.Workbook();
    var worksheet = workbook.addWorksheet('Sheet 1');
    worksheet.columns = [
      { header: 'S.No', key: 'serialNumber' },
      { header: 'Oracle Hostname', key: 'oracleHostName' },
      { header: 'Oracle Port', key: 'oraclePort' },
      { header: 'Oracle Service ID', key: 'oracleServiceId' },
      { header: 'Oracle Username', key: 'oracleUserName' },
      { header: 'Oracle Password', key: 'oraclePassword' },
      { header: 'Created Date', key: 'createdDate' },
      { header: 'Updated Date', key: 'updatedDate' }
    ];
    if (dbData) {
      dbData.forEach((data) => {
        const { isDeleted } = data;
        if (!isDeleted) {
          data.oracleUserName = '';
          data.oraclePassword = '';
          worksheet.addRow(data);
        }
      });
    }
    return workbook;
  }

   //Add the given database details 
   addDatabaseDetails = async (response, dbConfigDetails) => {
    const allData = await this.dbDetailsModel.find().sort({ serialNumber: 'desc' });
    const { lang } = dbConfigDetails;
    locale.setLanguage(lang);
    if (response.data === Constants.DATABASE_VALID) {
      const dbData = new this.dbDetailsModel(dbConfigDetails);
      dbData.isDeleted = Constants.BOOLEAN_FALSE;
      dbData.createdDate = new Date();
      dbData.metadataCollection = Constants.NOTCOLLECTED;
      dbData.tableCount = 0;
      if (allData.length == 0) {
        dbData.serialNumber = 1;
      } else {
        dbData.serialNumber = allData[0].serialNumber + 1;
      }
      await dbData.save();
      axios.get(metadataControllerPath)
      .catch((error) => {
        return error.response;
      })
      return {
        message: this.formatString(locale.host_deleted, {hostName: dbData.oracleHostName}),
        hasError: Constants.BOOLEAN_FALSE
      };
    } else if (response.data === Constants.DATABASE_INVALID) {
      return {
        message: locale.invalid_db_details,
        hasError: Constants.BOOLEAN_TRUE
      };
    } else {
      return {
        message: locale.invalid_schema,
        hasError: Constants.BOOLEAN_TRUE
      };
    }
  }

  //Update the given database details
  updateDatabaseDetails = async (response, dbConfigDetails, _id) => {
    const { lang } = dbConfigDetails;
    locale.setLanguage(lang);
    if (response.data === Constants.DATABASE_VALID) {
      const dbData = await this.dbDetailsModel.findOneAndUpdate({ _id }, dbConfigDetails, { new: true });
      if (!dbData) {
        throw new NotFoundException(locale.db_details_not_found);
      }
      axios.get(metadataControllerPath)
      .catch((error) => {
        return error.response;
      })
      return {
        message: dbData.oracleHostName + ' ' + ResMessage.UPDATE_SUCCESS,
        hasError: Constants.BOOLEAN_FALSE
      };
    } else if (response.data === Constants.DATABASE_INVALID) {
      return {
        message: locale.invalid_db_details,
        hasError: Constants.BOOLEAN_TRUE
      };
    } else {
      return {
        message: locale.invalid_schema,
        hasError: Constants.BOOLEAN_TRUE
      };
    }
  }

  //Get database configuration details for the given id
  getDbDetailsById = async(lang, _id) : Promise<any> => {
    const dbData = await this.dbDetailsModel.find({_id});
    locale.setLanguage(lang);
    dbData.forEach((data) => {
      const { oracleUserName, oraclePassword } = data;
      data.oracleUserName = decryptData(oracleUserName);
      data.oraclePassword = decryptData(oraclePassword);
    }
    );
    if (!dbData) {
      throw new NotFoundException(locale.db_details_not_found);
    }
    return dbData;
  }

//Get all the database configuration details
getAllDBDetailsList = async (lang): Promise<any> => {
    const searchKey = { metadataCollection: Constants.COLLECTED, isDeleted: Constants.BOOLEAN_FALSE };
    const selectedFields  = 'oracleHostName oraclePort';
    const dbData = await this.dbDetailsModel
        .find(searchKey)
        .select(selectedFields);
        locale.setLanguage(lang);
    if(!dbData.length) {
        throw new NotFoundException(locale.metadata_not_collected);
    }
    return dbData;
}

//Check whether the database configuration details already exist
checkIfAlreadyExist = async(dbConfigDetails): Promise<Boolean> => {
    let isPresent = Constants.BOOLEAN_FALSE;
    const existingData = await this.dbDetailsModel.find(dbConfigDetails);
    if(existingData.length !== 0 ) {
      existingData.forEach((data) => {
        if(!data.isDeleted) {
          isPresent = Constants.BOOLEAN_TRUE;
          return;
        }
      });
    }
      return isPresent;
}

}

//Encrypt the database username and password
function encryptData(data: String): string {
  var decodeKey = crypto.createHash('md5').update(Constants.CRYPT_KEY, Constants.UTF8).digest();
  var cipher = crypto.createCipheriv(Constants.CRYPT_ALGORITHM, decodeKey, Constants.CRYPT_IV);
  return cipher.update(data, Constants.UTF8, Constants.HEX) + cipher.final(Constants.HEX);
};

//Decrypt the database username and password
function decryptData(data: String): string {
  var encodeKey = crypto.createHash('md5').update(Constants.CRYPT_KEY, Constants.UTF8).digest();
  var cipher = crypto.createDecipheriv(Constants.CRYPT_ALGORITHM, encodeKey, Constants.CRYPT_IV);
  return cipher.update(data, Constants.HEX, Constants.UTF8) + cipher.final(Constants.UTF8);
}


