import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ExecutionResultModule } from './execution_result/execution-result.module';
import { DbModule } from './db_details/db.module';
import { SampleModule } from './sample/sample.module';
import { SchedulesModule } from './schedules/schedules.module';
import { TableRelationsModule } from './tableRelations/tableRelations.module';
import { UserManagementModule } from './user-management/user-management.module';
import { Utility } from './common/utility';
import * as config from 'config'; 
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';

const {connector, host, port, dbName, props} = config.database;
const _link = `${connector}://${host}:${port}/${dbName}`;

@Module({
  imports: [ MongooseModule.forRoot(_link, props),
    UserManagementModule, SampleModule, DbModule, TableRelationsModule, SchedulesModule, ExecutionResultModule],
    controllers: [AppController],
    providers: [AppService, Utility],
  })
  
  export class AppModule {
  }