import { Controller, Request, Response, Body  } from '@nestjs/common';
import { Get, Put, Post, Delete } from "@nestjs/common";
import { ReferDto } from "../common/dto/sample.dto";
import { SampleService } from "./sample.service";


@Controller('sample')
export class SampleController {
    
    
    constructor(private readonly sampleService: SampleService) {}
    
    @Post()
    public async sampleGetRequest(@Response() res, @Request() req, @Body() referDto: ReferDto){
        try{
            
        } catch (err){
            
        }
    }
    
}
