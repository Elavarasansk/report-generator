import { Injectable } from '@nestjs/common';
import { ReferDto } from "../common/dto/sample.dto";

@Injectable()
export class SampleService {
    
    public async getService(referDto: ReferDto): Promise<any> {
        
    }
    
}
