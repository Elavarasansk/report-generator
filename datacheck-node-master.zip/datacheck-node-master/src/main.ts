import { AppModule } from './app.module';
import * as config from "config";
import * as fs from 'fs';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { NestFactory } from '@nestjs/core';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors();
  const options = new DocumentBuilder()
    .setTitle("Node API Template")
    .setDescription('Node API Template')
    .setVersion('1.0')
    .addTag('Node API')
    .build();

  const document = SwaggerModule.createDocument(app, options);
  fs.writeFileSync("./swagger-spec.json", JSON.stringify(document));
  SwaggerModule.setup("api", app, document);

  await app.listen(config.projectSetup.port);
}
bootstrap();
