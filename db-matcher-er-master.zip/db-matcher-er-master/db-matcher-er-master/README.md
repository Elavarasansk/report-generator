# db-matcher-er

### Overview:
        Table Analyzer Tool is to find Data Mismatch between two tables based on related column between them.
          

### Steps to clone:

        1. Launch Git Bash and navigate to the folder to be cloned. [cd path/to/be/cloned]
        2. Run the command [ git clone http://192.168.41.136/intraweb_support/db-matcher-er.git ]
        3. Enter the UserName and Password to clone
        4. Run the command [cd db-matcher-er/]
        5. Run the command mvn eclipse:clean eclipse:eclipse
        6. Import as maven project in eclipse
        

### Steps to Use:
    
There are <b>two ways</b> to run the application.
        
1) Launch the main file `src/main/java/org/intraweb/tools/dbMatcher/main/DbMatcherMain.java` as java application.
    
           GUI screen will open. Enter the required input details and click Submit Button.
           
           
2) Sample configuration.properties file present in `src/main/resources` folder.<br/>
    Update the configuration.properties file based on your requirement.<br/>
    `Launch the main file src/main/java/org/intraweb/tools/dbMatcher/main/DbMatcherMain.java by passing configuration.properties File Path as Command Line Argument.`