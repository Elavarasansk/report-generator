package org.intraweb.tools.dbMatcher.ExecutionType1.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Getter
@Builder
public class RelationalEntity {
  private String tableName;
  private String parentTableName;
  private String parentName;
  private String columnName;
  private String parentColumnName;

}
