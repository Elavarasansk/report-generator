package org.intraweb.tools.dbMatcher.DbMatcherGui.Consts;

public class DbMatcherConsts {

    public static final String Css_File = "dbMatcher.css";

    public static final String Tool_Image = "iw_tools.png";

    public static final String Info_Icon = "info_icon.png";

    public static final String Download_Icon = "download_icon.png";

    public static final String Title = "Database Matcher";

    public static final String Empty_String = "";

    public static final String Alert_Title = "Sample Template For Input Sheet";

    public static final String Sample_Template_Content = "Sample Template For Input Sheet is packed along with the DB Matcher jar";

    public static final String Warning_Message_Input = "The Input Sheet path can not be empty";

    public static final String Warning_Message_Output = "The Output Sheet path can not be empty";

    public static final String File_Not_Found = "The Input File doesn't exists";

    public static final String Incorrect_File_Format = "The file should be in .xls format";

    public static final String Xls = ".xls";

    public static final String Warning = "WARNING";

    public static final String TargetDb_Title =  "TARGET DB CONNECTION DETAILS : ";

    public static final String Ip = "Ip";

    public static final String Port = "Port";

    public static final String ServiceId = "ServiceId";

    public static final String UserName = "UserName";

    public static final String Password = "Password";

    public static final String Schema = "Schema";

    public static final String tIp = "tIp";

    public static final String tPort = "tPort";

    public static final String tServiceId = "tServiceId";

    public static final String tUserName = "tUserName";

    public static final String tPassword = "tPassword";

    public static final String tSchema = "tSchema";

    public static final String mIp = "mIp";

    public static final String mPort = "mPort";

    public static final String mUserName = "mUserName";

    public static final String mPassword = "mPassword";

    public static final String Input_Sheet_Details = "INPUT SHEET DETAILS : ";

    public static final String Input_Sheet_Path = "Input Sheet Path";

    public static final String Input = "Input";

    public static final String Sample_Template = "Sample Template For Input Sheet is provided in the DB matcher jar";

    public static final String OUTPUT_SHEET_DETAILS = "OUTPUT SHEET DETAILS : ";

    public static final String Output_Sheet_Path = "Output Sheet Path";

    public static final String Output = "Output";

    public static final String MongoDb_Store = "Click here to store the data to MongoDb";

    public static final String MongoDb_Connection_Details = "MONGO DB CONNECTION DETAILS : ";

    public static final String SUBMIT = "SUBMIT";

    public static final String Ip_Validation_Message = "The target Db Ip can not be empty";

    public static final String Port_Validation_Message = "The target Db Port can not be empty";

    public static final String Username_Validation_Message = "The target Db UserName can not be empty";

    public static final String Password_Validation_Message = "The target Db Password can not be empty";

    public static final String ServiceId_Validation_Message = "The target Db ServiceId can not be empty";

    public static final String Schema_Validation_Message = "The  target Db Schema can not be empty";

    public static final String Mongo_Ip_Validation_Message = "The Ip can not be empty";

    public static final String Mongo_Port_Validation_Message = "The Port can not be empty";

    public static final String Mongo_Username_Validation_Message = "The UserName can not be empty";

    public static final String Mongo_Password_Validation_Message = "The Password can not be empty";

    public static final String MainGridId = "mainGrid";

    public static final String Checkbox = "checkbox";

    public static final String OracleHostName = "oracleHostName";

    public static final String OraclePort = "oraclePort";

    public static final String OracleServiceId = "oracleServiceId";

    public static final String OracleUserName = "oracleUserName";

    public static final String OraclePassword = "oraclePassword";

    public static final String OracleSchema = "oracleSchema";

    public static final String MongodbStore = "mongodbStore";

    public static final String MongodbHostName = "mongodbHostName";

    public static final String MongodbPort = "mongodbPort";

    public static final String MongodbUserName = "mongodbUserName";

    public static final String MongodbPassword = "mongodbPassword";

    public static final String Oracle_HostName = "oracle.hostName";

    public static final String Oracle_Port = "oracle.port";

    public static final String Oracle_ServiceId = "oracle.serviceId";

    public static final String Oracle_UserName = "oracle.userName";

    public static final String Oracle_Password = "oracle.password";

    public static final String Oracle_Schema = "oracle.schema";

    public static final String Mongodb_Store = "mongodb.store";

    public static final String Mongodb_HostName = "mongodb.hostName";

    public static final String Mongodb_Port = "mongodb.port";

    public static final String Mongodb_UserName = "mongodb.userName";

    public static final String Mongodb_Password = "mongodb.password";

    public static final String Input_FilePath = "input.filePath";

    public static final String Output_FilePath = "output.filePath";

    public static final String Intraweb_Standalone_Tools = "intraweb_standalone_tools";

    public static final String SINGLE_MISMATCH_DATA = "SINGLE_MISMATCH_DATA";

    public static final String MULTI_MISMATCH_DATA = "MULTI_MISMATCH_DATA";

    public static final String True = "true";

    public static final String DbMatcherResult_xlsx = "//DbMatcherResult.xlsx";

    public static final String Single_Field_Mismatch_Value = "Single_Field_Mismatch_Value";

    public static final String Composite_Fields_Mismatch_Value = "Composite_Fields_Mismatch_Value";

    public static final String Meiryo_UI = "Meiryo UI";

    public static final String No = "No";

    public static final String PARENT_TABLE = "PARENT TABLE";

    public static final String CHILD_TABLE = "CHILD TABLE";

    public static final String PARENT_COLUMN = "PARENT COLUMN";

    public static final String CHILD_COLUMN = "CHILD COLUMN";

    public static final String MISMATCH_VALUE_IN_CHILD_TABLE = "MISMATCH VALUE IN CHILD TABLE";
}
