package org.intraweb.tools.dbMatcher.ExecutionType2.TableAnalyzer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.intraweb.tools.dbMatcher.ExecutionType2.connectivity.JdbcConnection;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.ColumnRelationEntity;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.MultipleMismatchDataEntity;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.ParentChildRelationEntity;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.SingleMismatchDataEntity;
import org.intraweb.tools.dbMatcher.utils.WorkSheetUtils;

public class TableAnalyzer {

    private Map<String, String> oracleDbPropertiesMap = new HashMap<>();

    private Map<String, String> mongoDbPropertiesMap = new HashMap<>();
    
    List<SingleMismatchDataEntity> singleMismatchDataEntityList = new ArrayList<>();
    List<MultipleMismatchDataEntity> multipleMismatchDataEntityList =  new ArrayList<>();

    private String inputSheetPath;

    private String outputSheetPath;
    
    public TableAnalyzer(String inputSheetPath, String outputSheetPath, Map<String, String> oracleDbPropertiesMap,
            Map<String, String> mongoDbPropertiesMap) {
          this.inputSheetPath = inputSheetPath;
          this.outputSheetPath = outputSheetPath;
          this.oracleDbPropertiesMap = oracleDbPropertiesMap;
          this.mongoDbPropertiesMap = mongoDbPropertiesMap;
        }


    public void start() {
        System.out.println("Start Time --------------" + System.currentTimeMillis());
        long start = System.currentTimeMillis();

        JdbcConnection connector = new JdbcConnection(oracleDbPropertiesMap, mongoDbPropertiesMap);

        List<ParentChildRelationEntity> pcreMainList = new ArrayList<>();
        WorkSheetUtils.makeListFromInput(inputSheetPath, pcreMainList);
        Map<String, List<ParentChildRelationEntity>> childBasedData = pcreMainList.stream()
                .collect(Collectors.groupingBy(ParentChildRelationEntity::getChildTableName, Collectors.toList()));

        for (Entry<String, List<ParentChildRelationEntity>> indiviRecord : childBasedData.entrySet()) {
            String childTableName = indiviRecord.getKey();
            List<ColumnRelationEntity> columnList = indiviRecord.getValue().stream()
                    .flatMap(x -> x.getColumnRelationList().stream()).collect(Collectors.toList());
            Map<String, List<ColumnRelationEntity>> parentBasedValue = columnList.stream().filter(
                    entity -> !entity.getParentTableName().trim().equals("-") && !entity.getParentTableName().isEmpty())
                    .collect(Collectors.groupingBy(ColumnRelationEntity::getParentTableName, Collectors.toList()));
            for (Entry<String, List<ColumnRelationEntity>> childCol : parentBasedValue.entrySet()) {
                if (childCol.getValue().size() > 1) {
                    connector.validateMultiDependencyParent(childTableName, childCol.getKey(), childCol.getValue(),multipleMismatchDataEntityList);
                    continue;
                }
                connector.validateSingleDependencyParent(childTableName, childCol.getKey(), childCol.getValue().get(0),singleMismatchDataEntityList);
            }
            
        }
        ResultService ResultService = new ResultService(outputSheetPath);
        ResultService.writeResult(singleMismatchDataEntityList, multipleMismatchDataEntityList);
        connector.destroyConnection();
        long end = System.currentTimeMillis();
        System.out.println("Execution Finished:  Time Taken " + (end - start) + "ms");
    }
}
