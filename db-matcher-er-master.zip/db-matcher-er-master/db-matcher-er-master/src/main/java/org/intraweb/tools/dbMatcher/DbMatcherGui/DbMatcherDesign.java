package org.intraweb.tools.dbMatcher.DbMatcherGui;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.intraweb.tools.dbMatcher.DbMatcherGui.Consts.DbMatcherConsts;
import org.intraweb.tools.dbMatcher.ExecutionType1.main.DataAnalyzerMain;
import org.intraweb.tools.dbMatcher.ExecutionType2.TableAnalyzer.TableAnalyzer;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DbMatcherDesign extends Application {

    ClassLoader classLoader = this.getClass().getClassLoader();
    String inputSheetPath = null;
    String outputSheetPath = null;
    String targetIp = null;
    String targetPort = null;
    String targetServiceId = null;
    String targetUserName = null;
    String targetPassword = null;
    String targetSchema = null;
    String mongoIp = null;
    String mongoPort = null;
    String mongoUserName = null;
    String mongoPassword = null;
    String mongoStore = "false";

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane mainGrid = setGridConfiguration();
        Scene scene = setSceneConfiguration(mainGrid);
        setPrimaryStageConfiguration(scene, primaryStage);
    }

    private Scene setSceneConfiguration(GridPane mainGrid) {
        Scene scene = new Scene(mainGrid, 840, 665);
        String styleSheetLayout = classLoader.getResource(DbMatcherConsts.Css_File).toExternalForm();
        scene.getStylesheets().addAll(styleSheetLayout);
        return scene;
    }

    public static void launchGUI(String[] args) {
        launch(args);
    }

    private void setPrimaryStageConfiguration(Scene scene, Stage primaryStage) {
        primaryStage.setScene(scene);
        InputStream setTitleImage = classLoader.getResourceAsStream(DbMatcherConsts.Tool_Image);
        primaryStage.getIcons().add(new Image(setTitleImage, 150, 150, true, false));
        primaryStage.setResizable(false);
        primaryStage.setTitle(DbMatcherConsts.Title);
        primaryStage.show();
    }

    private GridPane setGridConfiguration() {
        GridPane mainGrid = new GridPane();
        mainGrid.setId(DbMatcherConsts.MainGridId);

        GridPane targetDbConnectionGrid = new GridPane();
        GridPane targetDbIpGrid = new GridPane();
        GridPane targetDbPortGrid = new GridPane();
        GridPane targetDbServiceIdGrid = new GridPane();
        GridPane targetDbUserNameGrid = new GridPane();
        GridPane targetDbPasswordGrid = new GridPane();
        GridPane targetDbSchemaGrid = new GridPane();

        Label targetDbConnectionLabel = new Label(DbMatcherConsts.TargetDb_Title);
        Label targetDbIpLabel = new Label(DbMatcherConsts.Ip);

        TextField targetDbIpInputText = new TextField();
        targetDbIpInputText.setMinWidth(250);
        textFieldListener(targetDbIpInputText, DbMatcherConsts.tIp);

        targetDbIpGrid.setVgap(20);
        targetDbIpGrid.setHgap(90);
        targetDbIpGrid.add(targetDbIpLabel, 0, 0);
        targetDbIpGrid.add(targetDbIpInputText, 1, 0);

        Label targetDbPortLabel = new Label(DbMatcherConsts.Port);

        TextField targetDbPortInputText = new TextField();
        targetDbPortInputText.setMinWidth(250);
        textFieldListener(targetDbPortInputText, DbMatcherConsts.tPort);

        targetDbPortGrid.setVgap(20);
        targetDbPortGrid.setHgap(80);
        targetDbPortGrid.add(targetDbPortLabel, 0, 0);
        targetDbPortGrid.add(targetDbPortInputText, 1, 0);

        Label targetDbServiceIdLabel = new Label(DbMatcherConsts.ServiceId);

        TextField targetDbServiceIdInputText = new TextField();
        targetDbServiceIdInputText.setMinWidth(250);
        textFieldListener(targetDbServiceIdInputText, DbMatcherConsts.tServiceId);

        targetDbServiceIdGrid.setVgap(20);
        targetDbServiceIdGrid.setHgap(30);
        targetDbServiceIdGrid.add(targetDbServiceIdLabel, 0, 0);
        targetDbServiceIdGrid.add(targetDbServiceIdInputText, 1, 0);

        Label targetDbUserNameLabel = new Label(DbMatcherConsts.UserName);

        TextField targetDbUserNameInputText = new TextField();
        targetDbUserNameInputText.setMinWidth(250);
        textFieldListener(targetDbUserNameInputText, DbMatcherConsts.tUserName);

        targetDbUserNameGrid.setVgap(20);
        targetDbUserNameGrid.setHgap(20);
        targetDbUserNameGrid.add(targetDbUserNameLabel, 0, 0);
        targetDbUserNameGrid.add(targetDbUserNameInputText, 1, 0);

        Label targetDbPasswordLabel = new Label(DbMatcherConsts.Password);

        TextField targetDbPasswordInputText = new TextField();
        targetDbPasswordInputText.setMinWidth(250);
        textFieldListener(targetDbPasswordInputText, DbMatcherConsts.tPassword);

        targetDbPasswordGrid.setVgap(20);
        targetDbPasswordGrid.setHgap(35);
        targetDbPasswordGrid.add(targetDbPasswordLabel, 0, 0);
        targetDbPasswordGrid.add(targetDbPasswordInputText, 1, 0);

        Label targetDbSchemaLabel = new Label(DbMatcherConsts.Schema);

        TextField targetDbSchemaInputText = new TextField();
        targetDbSchemaInputText.setMinWidth(250);
        textFieldListener(targetDbSchemaInputText, DbMatcherConsts.tSchema);

        targetDbSchemaGrid.setVgap(20);
        targetDbSchemaGrid.setHgap(50);
        targetDbSchemaGrid.add(targetDbSchemaLabel, 0, 0);
        targetDbSchemaGrid.add(targetDbSchemaInputText, 1, 0);

        Separator targetSeparator = new Separator();
        targetSeparator.setHalignment(HPos.CENTER);
        targetSeparator.maxWidth(200);
        VBox targetDbBox = new VBox();
        targetDbBox.getChildren().add(targetSeparator);
        targetDbBox.setMaxWidth(1000);

        targetDbConnectionGrid.setVgap(20);
        targetDbConnectionGrid.setHgap(20);
        targetDbConnectionGrid.add(targetDbConnectionLabel, 0, 0);
        targetDbConnectionGrid.add(targetDbIpGrid, 0, 1);
        targetDbConnectionGrid.add(targetDbUserNameGrid, 0, 2);
        targetDbConnectionGrid.add(targetDbServiceIdGrid, 0, 3);
        targetDbConnectionGrid.add(targetDbPortGrid, 1, 1);
        targetDbConnectionGrid.add(targetDbPasswordGrid, 1, 2);
        targetDbConnectionGrid.add(targetDbSchemaGrid, 1, 3);
        targetDbConnectionGrid.setPadding(new Insets(0, 0, 0, 20));

        GridPane inputSheetDetailsGrid = new GridPane();

        GridPane inputSheetGrid = new GridPane();

        Label mainInputSheetDetailLabel = new Label(DbMatcherConsts.Input_Sheet_Details);

        Label inputSheetPathLabel = new Label(DbMatcherConsts.Input_Sheet_Path);

        TextField inputSheetPath = new TextField();
        inputSheetPath.setMinWidth(500);
        textFieldListener(inputSheetPath, DbMatcherConsts.Input);

        inputSheetGrid.setHgap(20);
        inputSheetGrid.add(inputSheetPathLabel, 0, 0);
        inputSheetGrid.add(inputSheetPath, 1, 0);

        InputStream InfoIconInputStream = classLoader.getResourceAsStream(DbMatcherConsts.Info_Icon);
        Image infoIconImage = new Image(InfoIconInputStream, 16, 16, true, false);

        Button infoButton = new Button();
        infoButton.setGraphic(new ImageView(infoIconImage));
        infoButton.setTooltip(new Tooltip(DbMatcherConsts.Sample_Template));
        infoButtonListener(infoButton);

        inputSheetDetailsGrid.setHgap(20);
        inputSheetDetailsGrid.setVgap(20);
        inputSheetDetailsGrid.add(mainInputSheetDetailLabel, 0, 0);
        inputSheetDetailsGrid.add(inputSheetGrid, 0, 1);
        inputSheetDetailsGrid.add(infoButton, 1, 1);
        inputSheetDetailsGrid.setPadding(new Insets(0, 0, 0, 20));

        GridPane outputSheetDetailGrid = new GridPane();

        GridPane outputSheetGrid = new GridPane();

        Label mainOutputSheetDetailLabel = new Label(DbMatcherConsts.OUTPUT_SHEET_DETAILS);

        Label outputSheetPathLabel = new Label(DbMatcherConsts.Output_Sheet_Path);

        TextField outputSheetPath = new TextField();
        outputSheetPath.setMinWidth(500);
        textFieldListener(outputSheetPath, DbMatcherConsts.Output);

        outputSheetGrid.setHgap(20);
        outputSheetGrid.setVgap(20);
        outputSheetGrid.add(outputSheetPathLabel, 0, 0);
        outputSheetGrid.add(outputSheetPath, 1, 0);

        outputSheetDetailGrid.setHgap(20);
        outputSheetDetailGrid.setVgap(20);
        outputSheetDetailGrid.add(mainOutputSheetDetailLabel, 0, 0);
        outputSheetDetailGrid.add(outputSheetGrid, 0, 1);
        outputSheetDetailGrid.setPadding(new Insets(0, 0, 0, 20));

        Separator sheetSeparator = new Separator();
        sheetSeparator.setHalignment(HPos.CENTER);
        sheetSeparator.maxWidth(200);
        VBox sheetBox = new VBox();
        sheetBox.getChildren().add(sheetSeparator);
        sheetBox.setMaxWidth(1000);

        GridPane mongoDbConnectionGrid = new GridPane();
        GridPane mongoDbIpGrid = new GridPane();
        GridPane mongoDbPortGrid = new GridPane();
        GridPane mongoDbUserNameGrid = new GridPane();
        GridPane mongoDbPasswordGrid = new GridPane();

        CheckBox storeDataCheckBox = new CheckBox();
        storeDataCheckBox.setText(DbMatcherConsts.MongoDb_Store);
        storeDataCheckBox.setId(DbMatcherConsts.Checkbox);
        checkboxListener(storeDataCheckBox, mongoDbConnectionGrid);

        Label mongoDbConnectionLabel = new Label(DbMatcherConsts.MongoDb_Connection_Details);

        Label mongoDbIpLabel = new Label(DbMatcherConsts.Ip);

        TextField mongoDbIpInputText = new TextField();
        mongoDbIpInputText.setMinWidth(250);
        textFieldListener(mongoDbIpInputText, DbMatcherConsts.mIp);

        mongoDbIpGrid.setVgap(20);
        mongoDbIpGrid.setHgap(90);
        mongoDbIpGrid.add(mongoDbIpLabel, 0, 0);
        mongoDbIpGrid.add(mongoDbIpInputText, 1, 0);

        Label mongoDbPortLabel = new Label(DbMatcherConsts.Port);

        TextField mongoDbPortInputText = new TextField();
        mongoDbPortInputText.setMinWidth(250);
        textFieldListener(mongoDbPortInputText, DbMatcherConsts.mPort);

        mongoDbPortGrid.setVgap(20);
        mongoDbPortGrid.setHgap(80);
        mongoDbPortGrid.add(mongoDbPortLabel, 0, 0);
        mongoDbPortGrid.add(mongoDbPortInputText, 1, 0);

        Label mongoDbUserNameLabel = new Label(DbMatcherConsts.UserName);

        TextField mongoDbUserNameInputText = new TextField();
        mongoDbUserNameInputText.setMinWidth(250);
        textFieldListener(mongoDbUserNameInputText, DbMatcherConsts.mUserName);

        mongoDbUserNameGrid.setVgap(20);
        mongoDbUserNameGrid.setHgap(20);
        mongoDbUserNameGrid.add(mongoDbUserNameLabel, 0, 0);
        mongoDbUserNameGrid.add(mongoDbUserNameInputText, 1, 0);

        Label mongoDbPasswordLabel = new Label(DbMatcherConsts.Password);

        TextField mongoDbPasswordInputText = new TextField();
        mongoDbPasswordInputText.setMinWidth(250);
        textFieldListener(mongoDbPasswordInputText, DbMatcherConsts.mPassword);

        mongoDbPasswordGrid.setVgap(20);
        mongoDbPasswordGrid.setHgap(35);
        mongoDbPasswordGrid.add(mongoDbPasswordLabel, 0, 0);
        mongoDbPasswordGrid.add(mongoDbPasswordInputText, 1, 0);

        mongoDbConnectionGrid.setVgap(20);
        mongoDbConnectionGrid.setHgap(20);
        mongoDbConnectionGrid.add(mongoDbConnectionLabel, 0, 0);
        mongoDbConnectionGrid.add(mongoDbIpGrid, 0, 1);
        mongoDbConnectionGrid.add(mongoDbUserNameGrid, 0, 2);
        mongoDbConnectionGrid.add(mongoDbPortGrid, 1, 1);
        mongoDbConnectionGrid.add(mongoDbPasswordGrid, 1, 2);
        mongoDbConnectionGrid.setVisible(false);
        mongoDbConnectionGrid.setPadding(new Insets(0, 20, 20, 20));

        Pane root = new Pane();
        Button submitButton = new Button();
        submitButton.setText(DbMatcherConsts.SUBMIT);
        submitButton.setLayoutX(370);
        submitButton.setLayoutY(5);
        root.getChildren().add(submitButton);
        buttonListener(submitButton);

        mainGrid.add(targetDbConnectionGrid, 0, 0);
        mainGrid.add(targetDbBox, 0, 1);
        mainGrid.add(inputSheetDetailsGrid, 0, 2);
        mainGrid.add(outputSheetDetailGrid, 0, 3);
        mainGrid.add(sheetBox, 0, 4);
        mainGrid.add(storeDataCheckBox, 0, 5);
        mainGrid.add(mongoDbConnectionGrid, 0, 6);
        mainGrid.add(root, 0, 7);
        mainGrid.setVgap(20);
        mainGrid.setHgap(20);
        mainGrid.setPadding(new Insets(20, 20, 20, 20));
        return mainGrid;
    }

    void textFieldListener(TextField folderInputText, String parameter) {
        folderInputText.textProperty().addListener((observable, oldValue, newValue) -> {
            switch (parameter) {

                case DbMatcherConsts.tIp:
                    targetIp = newValue;
                    break;
                case DbMatcherConsts.tPort:
                    targetPort = newValue;
                    break;
                case DbMatcherConsts.tServiceId:
                    targetServiceId = newValue;
                    break;
                case DbMatcherConsts.tUserName:
                    targetUserName = newValue;
                    break;
                case DbMatcherConsts.tPassword:
                    targetPassword = newValue;
                    break;
                case DbMatcherConsts.tSchema:
                    targetSchema = newValue;
                    break;
                case DbMatcherConsts.mIp:
                    mongoIp = newValue;
                    break;
                case DbMatcherConsts.mPort:
                    mongoPort = newValue;
                    break;
                case DbMatcherConsts.mUserName:
                    mongoUserName = newValue;
                    break;
                case DbMatcherConsts.mPassword:
                    mongoPassword = newValue;
                    break;
                case DbMatcherConsts.Output:
                    outputSheetPath = newValue;
                    break;
                case DbMatcherConsts.Input:
                    inputSheetPath = newValue;
                    break;
            }
        });
    }

    private void infoButtonListener(Button infoButton) {
        Alert alert = setInitalAlertConfigs();
        infoButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                alert.setContentText(DbMatcherConsts.Sample_Template_Content);
                alert.setTitle(DbMatcherConsts.Alert_Title);
                alert.show();
            }
        });
    }

    private void checkboxListener(CheckBox checkbox, GridPane mongoDbConnectionGrid) {
        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent arg0) {
                if (checkbox.isSelected()) {
                    mongoStore = "true";
                    mongoDbConnectionGrid.setVisible(true);
                } else {
                    mongoStore = "false";
                    mongoDbConnectionGrid.setVisible(false);
                }
            }
        };
        checkbox.setOnAction(event);
    }

    private Alert setInitalAlertConfigs() {
        Alert infoAlert = new Alert(AlertType.INFORMATION);
        InputStream titleImageStream = classLoader.getResourceAsStream(DbMatcherConsts.Tool_Image);
        infoAlert.setHeaderText(null);
        Stage infoAlertStage = (Stage) infoAlert.getDialogPane().getScene().getWindow();
        infoAlertStage.getIcons().add(new Image(titleImageStream, 50, 50, true, false));
        return infoAlert;
    }

    public void buttonListener(Button button) {
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                validationFilePath(inputSheetPath, outputSheetPath, targetIp, targetPort, targetServiceId,
                        targetUserName, targetPassword, targetSchema, mongoIp, mongoPort, mongoUserName, mongoPassword);
            }

            private void validationFilePath(String inputSheetPath, String outputSheetPath, String targetIp,
                    String targetPort, String targetServiceId, String targetUserName, String targetPassword,
                    String targetSchema, String mongoIp, String mongoPort, String mongoUserName, String mongoPassword) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setHeaderText(null);
                InputStream titleImage = classLoader.getResourceAsStream(DbMatcherConsts.Tool_Image);
                Stage errorAlertStage = (Stage) alert.getDialogPane().getScene().getWindow();
                errorAlertStage.getIcons().add(new Image(titleImage, 50, 50, true, false));
                File inputFile = new File(inputSheetPath);
                if (inputSheetPath == null || inputSheetPath.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Warning_Message_Input);
                    alert.showAndWait();
                    return;
                }
                if (!(inputFile.exists())) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.File_Not_Found);
                    alert.showAndWait();
                    return;
                }
                if (!(inputSheetPath.contains(DbMatcherConsts.Xls))) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Incorrect_File_Format);
                    alert.showAndWait();
                    return;
                }
                if (outputSheetPath == null || outputSheetPath.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Warning_Message_Output);
                    alert.showAndWait();
                    return;
                }
                if (targetIp == null || targetIp.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Ip_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (targetPort == null || targetPort.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Port_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (targetServiceId == null || targetServiceId.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.ServiceId_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (targetUserName == null || targetUserName.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Username_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (targetPassword == null || targetPassword.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Password_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (targetSchema == null || targetSchema.equals(DbMatcherConsts.Empty_String)) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Schema_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (mongoStore.equals("true") && (mongoIp == null || mongoIp.equals(DbMatcherConsts.Empty_String))) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Mongo_Ip_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (mongoStore.equals("true") && (mongoPort == null || mongoPort.equals(DbMatcherConsts.Empty_String))) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Mongo_Port_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (mongoStore.equals("true")&&(mongoUserName == null || mongoUserName.equals(DbMatcherConsts.Empty_String))) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Mongo_Username_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                if (mongoStore.equals("true")&&(mongoPassword == null || mongoPassword.equals(DbMatcherConsts.Empty_String))) {
                    alert.setTitle(DbMatcherConsts.Warning);
                    alert.setContentText(DbMatcherConsts.Mongo_Password_Validation_Message);
                    alert.showAndWait();
                    return;
                }
                Map<String, String> oracleDbPropertiesMap = new HashMap<>();
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleHostName, targetIp);
                oracleDbPropertiesMap.put(DbMatcherConsts.OraclePort, targetPort);
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleServiceId, targetServiceId);
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleUserName, targetUserName);
                oracleDbPropertiesMap.put(DbMatcherConsts.OraclePassword, targetPassword);
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleSchema, targetSchema);
                Map<String, String> mongoDbPropertiesMap = new HashMap<>();
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbStore, mongoStore);
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbHostName, mongoIp);
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbPort, mongoPort);
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbUserName, mongoUserName);
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbPassword, mongoPassword);
                String inputFilePath = inputSheetPath;
                String outputFilePath = outputSheetPath;
                boolean executionTypeOneFlag = true;
                if (executionTypeOneFlag) {
                    DataAnalyzerMain dataAnalyzerMain = new DataAnalyzerMain(inputFilePath, outputFilePath,
                            oracleDbPropertiesMap, mongoDbPropertiesMap);
                    dataAnalyzerMain.start();
                } else {
                    TableAnalyzer tableAnalyzerMain = new TableAnalyzer(inputFilePath, outputFilePath,
                            oracleDbPropertiesMap, mongoDbPropertiesMap);
                    tableAnalyzerMain.start();
                }
                Stage stage = (Stage) button.getScene().getWindow();
                stage.close();
            }
        });
    }
}
