package org.intraweb.tools.dbMatcher.ExecutionType1.entity;

import java.util.List;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Getter
@Builder
public class CompositeFieldsErrorEntity {
  private String parentTableName;
  private String childTableName;
  private List<String> parentColumnName;
  private List<String> childColumnName;
  private List<String> childColumnValue;
}
