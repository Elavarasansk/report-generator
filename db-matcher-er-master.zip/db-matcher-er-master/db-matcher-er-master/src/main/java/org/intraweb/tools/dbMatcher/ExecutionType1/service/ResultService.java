package org.intraweb.tools.dbMatcher.ExecutionType1.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.dbMatcher.DbMatcherGui.Consts.DbMatcherConsts;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.CompositeFieldsErrorEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.SingleFieldErrorEntity;

public class ResultService {

  public static List<String> headerCells = new ArrayList<>();
  static {
    headerCells.add(DbMatcherConsts.No);
    headerCells.add(DbMatcherConsts.PARENT_TABLE);
    headerCells.add(DbMatcherConsts.CHILD_TABLE);
    headerCells.add(DbMatcherConsts.PARENT_COLUMN);
    headerCells.add(DbMatcherConsts.CHILD_COLUMN);
    headerCells.add(DbMatcherConsts.MISMATCH_VALUE_IN_CHILD_TABLE);
  }

  private String outputSheetPath;

  public ResultService(String outputSheetPath) {
    this.outputSheetPath = outputSheetPath;
    createOutputSheet();
  }

  public void createOutputSheet() {
    Workbook workbook = new HSSFWorkbook();
    try {
      File directory = new File(outputSheetPath);
      directory.mkdir();
      OutputStream fileOutputStream = new FileOutputStream(outputSheetPath + DbMatcherConsts.DbMatcherResult_xlsx);
      workbook.write(fileOutputStream);
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        workbook.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  public void writeResult(List<SingleFieldErrorEntity> singleFieldErrorEntityList,
      List<CompositeFieldsErrorEntity> compositeFieldErrorEntityList) {
    try {
      FileInputStream file = new FileInputStream(new File(outputSheetPath + DbMatcherConsts.DbMatcherResult_xlsx));
      Workbook workbook = WorkbookFactory.create(file);
      if (!singleFieldErrorEntityList.isEmpty()) {
        writeSingleKeyErrorResult(singleFieldErrorEntityList, workbook);
      }
      if (!compositeFieldErrorEntityList.isEmpty()) {
        writeCompositeKeyErrorResult(compositeFieldErrorEntityList, workbook);
      }
      file.close();
      FileOutputStream fileOutputStream = new FileOutputStream(new File(outputSheetPath + DbMatcherConsts.DbMatcherResult_xlsx));
      workbook.write(fileOutputStream);
      workbook.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void makeHeaders(Sheet sheet, Workbook workBook) {
    Row headerRow = sheet.createRow(0);

    Font font = workBook.createFont();
    font.setColor(HSSFColor.HSSFColorPredefined.WHITE.getIndex());
    font.setFontName(DbMatcherConsts.Meiryo_UI);

    CellStyle styleOne = workBook.createCellStyle();
    styleOne.setFillForegroundColor(IndexedColors.ROYAL_BLUE.getIndex());
    styleOne.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    styleOne.setFont(font);

    CellStyle styleTwo = workBook.createCellStyle();
    styleTwo.setFillForegroundColor(IndexedColors.INDIGO.getIndex());
    styleTwo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    styleTwo.setFont(font);

    CellStyle styleThree = workBook.createCellStyle();
    styleThree.setFillForegroundColor(IndexedColors.RED1.getIndex());
    styleThree.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    styleThree.setFont(font);

    sheet.createFreezePane(2, 1);

    headerRow.setHeight((short) 700);

    for (int i = 0; i < headerCells.size(); i++) {
      headerRow.createCell(i).setCellValue(headerCells.get(i));
      CellStyle style = i > 2 ? styleTwo : styleOne;
      style = (i == headerCells.size() - 1) ? styleThree : style;
      int width = (i == 0) ? 1500 : 10000;
      headerRow.getCell(i).setCellStyle(style);
      sheet.setColumnWidth(i, width);
    }
  }

  private void writeSingleKeyErrorResult(List<SingleFieldErrorEntity> singleFieldErrorEntityList, Workbook workbook) {
    Sheet sheet = workbook.createSheet(DbMatcherConsts.Single_Field_Mismatch_Value);
    makeHeaders(sheet, workbook);
    int rowNumber = 1;
    CellStyle cellStyle = createStyle(workbook);
    for (SingleFieldErrorEntity singleFieldErrorEntity : singleFieldErrorEntityList) {
      Row row = sheet.createRow(rowNumber++);
      addCellWithStyle(row, cellStyle);
      row.getCell(0).setCellValue(rowNumber - 1);
      row.getCell(1).setCellValue(singleFieldErrorEntity.getParentTableName());
      row.getCell(2).setCellValue(singleFieldErrorEntity.getChildTableName());
      row.getCell(3).setCellValue(singleFieldErrorEntity.getParentColumnName());
      row.getCell(4).setCellValue(singleFieldErrorEntity.getChildColumnName());
      row.getCell(5).setCellValue(singleFieldErrorEntity.getChildColumnValue());
    }
  }

  private void writeCompositeKeyErrorResult(List<CompositeFieldsErrorEntity> compositeFieldsErrorEntityList,
      Workbook workbook) {
    Sheet sheet = workbook.createSheet(DbMatcherConsts.Composite_Fields_Mismatch_Value);
    makeHeaders(sheet, workbook);
    int rowNumber = 1;
    CellStyle cellStyle = createStyle(workbook);
    for (CompositeFieldsErrorEntity compositeFieldsErrorEntity : compositeFieldsErrorEntityList) {
      Row row = sheet.createRow(rowNumber++);
      addCellWithStyle(row, cellStyle);
      row.getCell(0).setCellValue(rowNumber - 1);
      row.getCell(1).setCellValue(compositeFieldsErrorEntity.getParentTableName());
      row.getCell(2).setCellValue(compositeFieldsErrorEntity.getChildTableName());
      row.getCell(3).setCellValue(compositeFieldsErrorEntity.getParentColumnName().toString());
      row.getCell(4).setCellValue(compositeFieldsErrorEntity.getChildColumnName().toString());
      row.getCell(5).setCellValue(compositeFieldsErrorEntity.getChildColumnValue().toString());
    }
  }

  private CellStyle createStyle(Workbook workbook) {
    CellStyle cellStyle = workbook.createCellStyle();
    cellStyle.setBorderTop(BorderStyle.THIN);
    cellStyle.setBorderRight(BorderStyle.THIN);
    cellStyle.setBorderBottom(BorderStyle.THIN);
    cellStyle.setBorderLeft(BorderStyle.THIN);
    return cellStyle;
  }

  private void addCellWithStyle(Row row, CellStyle cellStyle) {
    row.setHeight((short) 700);
    for (int i = 0; i < headerCells.size(); i++) {
      row.createCell(i).setCellStyle(cellStyle);
    }
  }

}
