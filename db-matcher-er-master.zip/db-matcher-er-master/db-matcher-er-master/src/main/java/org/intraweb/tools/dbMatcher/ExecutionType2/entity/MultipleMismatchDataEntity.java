package org.intraweb.tools.dbMatcher.ExecutionType2.entity;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MultipleMismatchDataEntity {

    private Object _id;
    private List<String> childColumnName;
    private List<String> parentColumnName;
    private String childTable;
    private String parentTable;
    private List<String> differenceColData;

}
