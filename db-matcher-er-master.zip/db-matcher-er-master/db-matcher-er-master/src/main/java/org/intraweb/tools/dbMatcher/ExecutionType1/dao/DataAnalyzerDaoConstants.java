package org.intraweb.tools.dbMatcher.ExecutionType1.dao;

public class DataAnalyzerDaoConstants {

  public static String ID = "_id";

  public static String CHILD_TABLE_COLUMNNAME = "childColumnName";

  public static String PARENT_TABLE_COLUMNNAME = "parentColumnName";

  public static String CHILD_TABLE = "childTable";

  public static String PARENT_TABLE = "parentTable";

  public static String DIFFERENCE_COLUMN_DATA = "differenceColData";

}
