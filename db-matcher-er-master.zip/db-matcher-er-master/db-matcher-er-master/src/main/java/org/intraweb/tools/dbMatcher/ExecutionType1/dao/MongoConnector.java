package org.intraweb.tools.dbMatcher.ExecutionType1.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.CompositeFieldsErrorEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.SingleFieldErrorEntity;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoConnector {

  private MongoClient mongo;

  private MongoDatabase intraWebDb;

  private Map<String, String> mongoConnectorPropertiesMap;

  public static String SINGLE_MISMATCH_DATA_COLLECTION = "SINGLE_MISMATCH_DATA";
  MongoCollection<Document> singleMismatchDataCollection;

  public static String MULTI_MISMATCH_DATA_COLLECTION = "MULTI_MISMATCH_DATA";
  MongoCollection<Document> multiMismatchDataCollection;

  public static String DATABASE = "intraweb_standalone_tools";

  public MongoConnector(Map<String, String> mongoConnectorPropertiesMap) {
    this.mongoConnectorPropertiesMap = mongoConnectorPropertiesMap;
    initDatabaseConnection();
  }

  public void initDatabaseConnection() {
    this.mongo = new MongoClient(mongoConnectorPropertiesMap.get("mongodbHostName"),
        Integer.parseInt(mongoConnectorPropertiesMap.get("mongodbPort")));
    this.intraWebDb = mongo.getDatabase(DATABASE);

    this.singleMismatchDataCollection = intraWebDb.getCollection(SINGLE_MISMATCH_DATA_COLLECTION);
    this.multiMismatchDataCollection = intraWebDb.getCollection(MULTI_MISMATCH_DATA_COLLECTION);

    if (singleMismatchDataCollection == null) {
      intraWebDb.createCollection(SINGLE_MISMATCH_DATA_COLLECTION);
      this.singleMismatchDataCollection = intraWebDb.getCollection(SINGLE_MISMATCH_DATA_COLLECTION);
    }

    if (multiMismatchDataCollection == null) {
      intraWebDb.createCollection(MULTI_MISMATCH_DATA_COLLECTION);
      this.multiMismatchDataCollection = intraWebDb.getCollection(MULTI_MISMATCH_DATA_COLLECTION);
    }
  }

  public void persistSingleMismatchToCollection(List<SingleFieldErrorEntity> singleFieldErrorEntityList) {
    List<Document> singleFieldMismatchDataDocumentList = new ArrayList<Document>();
    singleFieldErrorEntityList.forEach(errorEntity -> {
      Document document = new Document(DataAnalyzerDaoConstants.CHILD_TABLE_COLUMNNAME,
          errorEntity.getChildColumnName())
              .append(DataAnalyzerDaoConstants.PARENT_TABLE_COLUMNNAME, errorEntity.getParentColumnName())
              .append(DataAnalyzerDaoConstants.CHILD_TABLE, errorEntity.getChildTableName())
              .append(DataAnalyzerDaoConstants.PARENT_TABLE, errorEntity.getParentTableName())
              .append(DataAnalyzerDaoConstants.DIFFERENCE_COLUMN_DATA, errorEntity.getChildColumnValue());
      singleFieldMismatchDataDocumentList.add(document);
    });
    if (!singleFieldMismatchDataDocumentList.isEmpty()) {
      singleMismatchDataCollection.insertMany(singleFieldMismatchDataDocumentList);
    }
  }

  public void persistMultiMismatchToCollection(List<CompositeFieldsErrorEntity> compositeFieldsErrorEntityList) {
    List<Document> compositeFieldMismatchDataDocumentList = new ArrayList<Document>();
    compositeFieldsErrorEntityList.forEach(errorEntity -> {
      Document document = new Document(DataAnalyzerDaoConstants.CHILD_TABLE_COLUMNNAME,
          errorEntity.getChildColumnName())
              .append(DataAnalyzerDaoConstants.PARENT_TABLE_COLUMNNAME, errorEntity.getParentColumnName())
              .append(DataAnalyzerDaoConstants.CHILD_TABLE, errorEntity.getChildTableName())
              .append(DataAnalyzerDaoConstants.PARENT_TABLE, errorEntity.getParentTableName())
              .append(DataAnalyzerDaoConstants.DIFFERENCE_COLUMN_DATA, errorEntity.getChildColumnValue());
      compositeFieldMismatchDataDocumentList.add(document);
    });
    if (!compositeFieldMismatchDataDocumentList.isEmpty()) {
      multiMismatchDataCollection.insertMany(compositeFieldMismatchDataDocumentList);
    }
  }

}