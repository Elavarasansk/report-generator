
package org.intraweb.tools.dbMatcher.ExecutionType1.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.intraweb.tools.dbMatcher.ExecutionType1.dao.MongoConnector;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.CompositeFieldsErrorEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.RelationalEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.SingleFieldErrorEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.TreeEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.service.DataAnalyzerService;
import org.intraweb.tools.dbMatcher.ExecutionType1.service.ResultService;
import org.intraweb.tools.dbMatcher.ExecutionType1.service.TreeFormationService;
import org.intraweb.tools.dbMatcher.utils.WorkSheetUtils;

public class DataAnalyzerMain {

  public List<RelationalEntity> relationalEntityList = new ArrayList<>();

  public List<SingleFieldErrorEntity> singleFieldErrorEntityList = new ArrayList<>();

  public List<CompositeFieldsErrorEntity> compositeFieldsErrorEntityList = new ArrayList<>();

  private Map<String, String> oracleDbPropertiesMap = new HashMap<>();

  private Map<String, String> mongoDbPropertiesMap = new HashMap<>();

  private String inputSheetPath;

  private String outputSheetPath;

  public DataAnalyzerMain(String inputSheetPath, String outputSheetPath, Map<String, String> oracleDbPropertiesMap,
      Map<String, String> mongoDbPropertiesMap) {
    this.inputSheetPath = inputSheetPath;
    this.outputSheetPath = outputSheetPath;
    this.oracleDbPropertiesMap = oracleDbPropertiesMap;
    this.mongoDbPropertiesMap = mongoDbPropertiesMap;
  }

  public void start() {
    System.out.println("Execution Started ");
    long timeStart = System.currentTimeMillis();

    WorkSheetUtils.readInputSheet(inputSheetPath, relationalEntityList);

    TreeFormationService treeFormationService = new TreeFormationService();
    TreeEntity rootTable = treeFormationService.makeTableRelation(relationalEntityList);

    DataAnalyzerService dataAnalyzerService = new DataAnalyzerService(oracleDbPropertiesMap, singleFieldErrorEntityList,
        compositeFieldsErrorEntityList);
    dataAnalyzerService.processTables(rootTable);

    ResultService resultService = new ResultService(outputSheetPath);
    resultService.writeResult(singleFieldErrorEntityList, compositeFieldsErrorEntityList);

    if (mongoDbPropertiesMap.get("mongodbStore").equals("false")) {
      long timeEnd = System.currentTimeMillis();
      System.out.println("Execution Finished:  Time Taken " + (timeEnd - timeStart) + "ms");
      return;
    }

    MongoConnector mongoConnector = new MongoConnector(mongoDbPropertiesMap);
    mongoConnector.persistSingleMismatchToCollection(singleFieldErrorEntityList);
    mongoConnector.persistMultiMismatchToCollection(compositeFieldsErrorEntityList);

    long timeEnd = System.currentTimeMillis();
    System.out.println("Execution Finished:  Time Taken " + (timeEnd - timeStart) + "ms");
  }

}
