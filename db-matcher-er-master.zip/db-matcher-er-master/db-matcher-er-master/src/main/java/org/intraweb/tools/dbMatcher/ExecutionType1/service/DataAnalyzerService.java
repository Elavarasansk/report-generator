package org.intraweb.tools.dbMatcher.ExecutionType1.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.intraweb.tools.dbMatcher.ExecutionType1.dao.DataAnalyzerDao;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.ColumnEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.CompositeFieldsErrorEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.SingleFieldErrorEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.TreeEntity;

public class DataAnalyzerService {

  public static String SELECT = "SELECT ";

  public static String FROM = " FROM ";

  public static String LEFT_JOIN = " LEFT JOIN ";

  public static String WHERE = " WHERE ";

  public static String ON = " ON ";

  Map<String, String> oracleDbPropertiesMap = new HashMap<>();

  public List<SingleFieldErrorEntity> singleFieldErrorEntityList;

  public List<CompositeFieldsErrorEntity> compositeFieldsErrorEntityList;

  public DataAnalyzerDao dataAnalyzerDao;

  public DataAnalyzerService(Map<String, String> databasePropertiesMap,
      List<SingleFieldErrorEntity> singleFieldErrorEntityList,
      List<CompositeFieldsErrorEntity> compositeFieldsErrorEntityList) {
    this.oracleDbPropertiesMap = databasePropertiesMap;
    this.singleFieldErrorEntityList = singleFieldErrorEntityList;
    this.compositeFieldsErrorEntityList = compositeFieldsErrorEntityList;
    dataAnalyzerDao = new DataAnalyzerDao(this.oracleDbPropertiesMap);
  }

  public void processTables(TreeEntity rootTable) {
    HashSet<String> alreadyProcessedTableSet = new HashSet<>();
    checkDataMatch(rootTable.getChildTableNameEntityList(), rootTable.getTableName(), alreadyProcessedTableSet);
  }

  private void checkDataMatch(List<TreeEntity> childColumns, String tableName,
      HashSet<String> alreadyProcessedTableSet) {
    if (childColumns == null) {
      return;
    }
    for (int i = 0; i < childColumns.size(); i++) {
      if (!childColumns.get(i).getColumnNames().isEmpty()) {
        List<ColumnEntity> columnEntityList = childColumns.get(i).getColumnNames();
        compareData(columnEntityList, tableName, childColumns.get(i).getTableName());
      }
      if (!alreadyProcessedTableSet.isEmpty()
          && alreadyProcessedTableSet.contains(childColumns.get(i).getTableName())) {
        continue;
      }
      alreadyProcessedTableSet.add(childColumns.get(i).getTableName());
      checkDataMatch(childColumns.get(i).getChildTableNameEntityList(), childColumns.get(i).getTableName(),
          alreadyProcessedTableSet);
    }
  }

  private void compareData(List<ColumnEntity> columnEntityList, String parentTableName, String childTableName) {

    String query = formQuery(columnEntityList, parentTableName, childTableName);

    ResultSet nonMatchingResult = dataAnalyzerDao.executeQuery(query);

    try {
      while (nonMatchingResult.next()) {
        List<String> parentColumnNameList = new ArrayList<>();
        List<String> childColumnNameList = new ArrayList<>();
        List<String> childColumnValueList = new ArrayList<>();
        for (ColumnEntity columnEntity : columnEntityList) {
          parentColumnNameList.add(columnEntity.getParentColumnName());
          childColumnNameList.add(columnEntity.getColumnName());
          childColumnValueList.add(nonMatchingResult.getString(columnEntity.getColumnName()));
        }
        if (columnEntityList.size() == 1) {
          singleFieldErrorEntityList.add(SingleFieldErrorEntity.builder().parentTableName(parentTableName)
              .childTableName(childTableName).parentColumnName(parentColumnNameList.get(0))
              .childColumnName(childColumnNameList.get(0)).childColumnValue(childColumnValueList.get(0)).build());
        } else {
          compositeFieldsErrorEntityList.add(CompositeFieldsErrorEntity.builder().parentTableName(parentTableName)
              .childTableName(childTableName).parentColumnName(parentColumnNameList)
              .childColumnName(childColumnNameList).childColumnValue(childColumnValueList).build());
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public String formQuery(List<ColumnEntity> columnEntityList, String parentTableName, String childTableName) {
    String query = "";
    String parentTableNameWithSchema = oracleDbPropertiesMap.get("oracleSchema").concat(".").concat(parentTableName);
    String childTableNameWithSchema = oracleDbPropertiesMap.get("oracleSchema").concat(".").concat(childTableName);

    List<String> parentColumnNamesList = columnEntityList.stream()
        .map(columnEntity -> parentTableNameWithSchema.concat("." + columnEntity.getParentColumnName()))
        .collect(Collectors.toList());

    List<String> childColumnNamesList = columnEntityList.stream()
        .map(columnEntity -> childTableNameWithSchema.concat("." + columnEntity.getColumnName()))
        .collect(Collectors.toList());

    String childColumnNames = childColumnNamesList.stream().map(String::valueOf).collect(Collectors.joining(", "));

    String joinCondition = columnEntityList.stream()
        .map(columnEntity -> childTableNameWithSchema.concat("." + columnEntity.getColumnName()).concat(" = ")
            .concat(parentTableNameWithSchema).concat("." + columnEntity.getParentColumnName()))
        .collect(Collectors.joining(" and "));

    String whereCondition = parentColumnNamesList.stream().map(parentColumn -> parentColumn.concat(" IS NULL"))
        .collect(Collectors.joining(" and "));

    query = String.format("Select distinct * from ( SELECT %s from %s LEFT JOIN %s ON %s WHERE %s )", childColumnNames,
        childTableNameWithSchema, parentTableNameWithSchema, joinCondition, whereCondition);
    return query;
  }

}
