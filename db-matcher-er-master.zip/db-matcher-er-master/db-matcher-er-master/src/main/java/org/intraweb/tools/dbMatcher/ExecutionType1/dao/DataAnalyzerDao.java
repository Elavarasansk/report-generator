package org.intraweb.tools.dbMatcher.ExecutionType1.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class DataAnalyzerDao {

  Map<String, String> oracleDatabasePropertiesMap = new HashMap<>();

  private Connection connection;

  public DataAnalyzerDao(Map<String, String> databasePropertiesMap) {
    this.oracleDatabasePropertiesMap = databasePropertiesMap;
    this.connection = initDatabaseConnection();
  }

  public Connection initDatabaseConnection() {
    try {
      String url = oracleDatabasePropertiesMap.get("oracleHostName");
      int port = Integer.parseInt(oracleDatabasePropertiesMap.get("oraclePort"));
      String serviceId = oracleDatabasePropertiesMap.get("oracleServiceId");
      String userName = oracleDatabasePropertiesMap.get("oracleUserName");
      String password = oracleDatabasePropertiesMap.get("oraclePassword");
      Class.forName("oracle.jdbc.driver.OracleDriver");
      return DriverManager.getConnection("jdbc:oracle:thin:@" + url + ":" + port + ":" + serviceId, userName, password);
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    }catch(SQLException e){
      System.out.println("Check the DB Properties ");
      e.printStackTrace();
    }
    return null;
  }

  public ResultSet executeQuery(String query) {
    ResultSet resultSet = null;
    try {
      Statement statement = connection.createStatement();
      resultSet = statement.executeQuery(query);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return resultSet;
  }

}
