package org.intraweb.tools.dbMatcher.ExecutionType1.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.intraweb.tools.dbMatcher.ExecutionType1.entity.ColumnEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.RelationalEntity;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.TreeEntity;

public class TreeFormationService {

  public TreeEntity rootTable = null;

  public TreeEntity makeTableRelation(List<RelationalEntity> relationalEntityList) {
    List<RelationalEntity> firstLevelRelationEntityList = relationalEntityList.stream()
        .filter(relationEntity -> isIndependentEntity(relationEntity.getParentTableName()))
        .collect(Collectors.toList());
    relationalEntityList.removeAll(firstLevelRelationEntityList);
    makeFirstLevelInTree(firstLevelRelationEntityList);
    relationalEntityList.stream().forEach(entity -> {
      appendChildTable(rootTable, entity);
    });
    return rootTable;
  }

  private void makeFirstLevelInTree(List<RelationalEntity> firstLevelRelationEntityList) {
    firstLevelRelationEntityList.stream().forEach(entity -> {
      if (rootTable == null) {
        TreeEntity rootTableEntity = new TreeEntity("Root", new ArrayList<>(), new ArrayList<>());
        rootTable = rootTableEntity;
      }
      List<TreeEntity> childColumnList = rootTable.getChildTableNameEntityList();
      childColumnList.add(new TreeEntity(entity.getTableName(), new ArrayList<>(), new ArrayList<>()));
      rootTable.setChildTableNameEntityList(childColumnList);
    });
  }

  private void appendChildTable(TreeEntity currentTable, RelationalEntity entity) {
    if (currentTable.getTableName().equals(entity.getParentTableName())) {
      appendTable(currentTable, entity);
      return;
    } else {
      for (int i = 0; i < currentTable.getChildTableNameEntityList().size(); i++) {
        appendChildTable(currentTable.getChildTableNameEntityList().get(i), entity);
      }
    }
  }

  private void appendTable(TreeEntity currentTable, RelationalEntity entity) {
    List<TreeEntity> childEntityList = currentTable.getChildTableNameEntityList();
    boolean isAlreadyPresentFlag = false;
    for (TreeEntity childEntity : childEntityList) {
      if (childEntity.getTableName().equals(entity.getTableName())) {
        ColumnEntity columnEntity = new ColumnEntity(entity.getColumnName(), entity.getParentColumnName());
        List<ColumnEntity> columnEntityList = new ArrayList<>(childEntity.getColumnNames());
        columnEntityList.add(columnEntity);
        childEntity.setColumnNames(columnEntityList);
        isAlreadyPresentFlag = true;
        break;
      }
    }
    if (!isAlreadyPresentFlag) {
      ColumnEntity columnEntity = new ColumnEntity(entity.getColumnName(), entity.getParentColumnName());
      TreeEntity treeEntity = new TreeEntity(entity.getTableName(), Arrays.asList(columnEntity), new ArrayList<>());
      childEntityList.add(treeEntity);
      currentTable.setChildTableNameEntityList(childEntityList);
    }
  }

  private boolean isIndependentEntity(String parentTableName) {
    return parentTableName.trim().equals("-") || parentTableName.isEmpty();
  }

}
