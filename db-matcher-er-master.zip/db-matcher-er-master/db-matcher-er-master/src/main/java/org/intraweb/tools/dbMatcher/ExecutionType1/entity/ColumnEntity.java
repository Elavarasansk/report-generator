package org.intraweb.tools.dbMatcher.ExecutionType1.entity;

import lombok.Data;
import lombok.Getter;

@Data
@Getter
public class ColumnEntity {
  private String columnName;
  private String parentColumnName;

  public ColumnEntity(String columnName, String parentColumnName) {
    this.columnName = columnName;
    this.parentColumnName = parentColumnName;
  }

}
