package org.intraweb.tools.dbMatcher.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.dbMatcher.ExecutionType1.entity.RelationalEntity;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.ColumnRelationEntity;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.ParentChildRelationEntity;

public class WorkSheetUtils {

  public static final String FILE_VALIDATION_MESSAGE = "File Not Exists";

  public static final String SHEET_NAME = "Input Sheet";

  public static void readInputSheet(String inputSheetPath, List<RelationalEntity> relationalEntityList) {
    File inputFile = new File(inputSheetPath);
    if (!inputFile.exists()) {
      System.out.println(FILE_VALIDATION_MESSAGE);
      return;
    }
    try {
      Workbook inputWorksheet = WorkbookFactory.create(inputFile);
      int readStartRow = 1;
      Sheet sheet = inputWorksheet.getSheet(SHEET_NAME);
      for (int counter = readStartRow; counter <= sheet.getLastRowNum(); counter++) {
        Row row = sheet.getRow(counter);
        if (row == null) {
          break;
        }
        String tableName = getStringValue(row.getCell(0)).trim();
        String parentTableName = getStringValue(row.getCell(1)).trim();
        String columnName = getStringValue(row.getCell(2)).trim();
        String parentColumnName = getStringValue(row.getCell(3)).trim();
        relationalEntityList.add(RelationalEntity.builder().tableName(tableName).parentTableName(parentTableName)
            .columnName(columnName).parentColumnName(parentColumnName).build());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return;
  }
  
    public static void makeListFromInput(String inputSheetPath, List<ParentChildRelationEntity> pcreMainList) {
        File inputFile = new File(inputSheetPath);
        if (!inputFile.exists()) {
            System.out.println(FILE_VALIDATION_MESSAGE);
            return;
        }
        try {
            Workbook inputWorksheet = WorkbookFactory.create(inputFile);
            int readStartRow = 1;
            Sheet sheet = inputWorksheet.getSheet(SHEET_NAME);
            for (int counter = readStartRow; counter <= sheet.getLastRowNum(); counter++) {
                Row row = sheet.getRow(counter);
                if (row == null) {
                    break;
                }
                List<ColumnRelationEntity> columnRelationEntityList = new ArrayList<>();
                String tableName = getStringValue(row.getCell(0)).trim();
                String parentTableName = getStringValue(row.getCell(1)).trim();
                String columnName = getStringValue(row.getCell(2)).trim();
                String parentColumnName = getStringValue(row.getCell(3)).trim();
                ColumnRelationEntity columnRelationEntity = ColumnRelationEntity.builder().columnName(columnName)
                        .parentAliasName(parentColumnName).parentTableName(parentTableName).build();
                columnRelationEntityList.add(columnRelationEntity);
                pcreMainList.add(ParentChildRelationEntity.builder().childTableName(tableName)
                        .columnRelationList(columnRelationEntityList).build());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }

  public static String getStringValue(Cell cell) {
    if (cell == null) {
      return "";
    }
    switch (cell.getCellType()) {
    case NUMERIC:
      return Double.toString(cell.getNumericCellValue());
    case STRING:
      return cell.getStringCellValue();
    case FORMULA:
      Workbook wb = cell.getSheet().getWorkbook();
      CreationHelper crateHelper = wb.getCreationHelper();
      FormulaEvaluator evaluator = crateHelper.createFormulaEvaluator();
      return getStringValue(evaluator.evaluateInCell(cell));
    case BOOLEAN:
      return Boolean.toString(cell.getBooleanCellValue());
    case ERROR:
      return "ERROR";
    case BLANK:
    default:
      return "";
    }
  }
}
