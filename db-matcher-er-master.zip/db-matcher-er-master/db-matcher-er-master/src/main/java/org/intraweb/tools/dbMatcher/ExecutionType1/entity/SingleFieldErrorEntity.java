package org.intraweb.tools.dbMatcher.ExecutionType1.entity;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Getter
@Builder
public class SingleFieldErrorEntity {
  private String parentTableName;
  private String childTableName;
  private String parentColumnName;
  private String childColumnName;
  private String childColumnValue;
}
