package org.intraweb.tools.dbMatcher.main;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.intraweb.tools.dbMatcher.DbMatcherGui.DbMatcherDesign;
import org.intraweb.tools.dbMatcher.DbMatcherGui.Consts.DbMatcherConsts;
import org.intraweb.tools.dbMatcher.ExecutionType1.main.DataAnalyzerMain;
import org.intraweb.tools.dbMatcher.ExecutionType2.TableAnalyzer.TableAnalyzer;

public class DbMatcherMain {

    public static void main(String[] args) {
        if (args.length == 0) {
            DbMatcherDesign.launchGUI(args);
        } else {
            String propertiesFilePath = args[0];
            try {
                InputStream propertiesFile = new FileInputStream(propertiesFilePath);
                Properties properties = new Properties();
                properties.load(propertiesFile);
                Map<String, String> oracleDbPropertiesMap = new HashMap<>();
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleHostName, properties.getProperty(DbMatcherConsts.Oracle_HostName));
                oracleDbPropertiesMap.put(DbMatcherConsts.OraclePort, properties.getProperty(DbMatcherConsts.Oracle_Port));
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleServiceId, properties.getProperty(DbMatcherConsts.Oracle_ServiceId));
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleUserName, properties.getProperty(DbMatcherConsts.Oracle_UserName));
                oracleDbPropertiesMap.put(DbMatcherConsts.OraclePassword, properties.getProperty(DbMatcherConsts.Oracle_Password));
                oracleDbPropertiesMap.put(DbMatcherConsts.OracleSchema, properties.getProperty(DbMatcherConsts.Oracle_Schema));
                Map<String, String> mongoDbPropertiesMap = new HashMap<>();
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbStore, properties.getProperty(DbMatcherConsts.Mongodb_Store));
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbHostName, properties.getProperty(DbMatcherConsts.Mongodb_HostName));
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbPort, properties.getProperty(DbMatcherConsts.Mongodb_Port));
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbUserName, properties.getProperty(DbMatcherConsts.Mongodb_UserName));
                mongoDbPropertiesMap.put(DbMatcherConsts.MongodbPassword, properties.getProperty(DbMatcherConsts.Mongodb_Password));
                String inputFilePath = properties.getProperty(DbMatcherConsts.Input_FilePath);
                String outputFilePath = properties.getProperty(DbMatcherConsts.Output_FilePath);
                boolean executionTypeOneFlag = true;
                if (executionTypeOneFlag) {
                    DataAnalyzerMain dataAnalyzerMain = new DataAnalyzerMain(inputFilePath, outputFilePath,
                            oracleDbPropertiesMap, mongoDbPropertiesMap);
                    dataAnalyzerMain.start();
                }else {
                    TableAnalyzer tableAnalyzerMain = new TableAnalyzer(inputFilePath, outputFilePath,
                            oracleDbPropertiesMap, mongoDbPropertiesMap);
                    tableAnalyzerMain.start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
