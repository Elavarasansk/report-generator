package org.intraweb.tools.dbMatcher.ExecutionType1.entity;

import java.util.List;

import lombok.Data;
import lombok.Getter;

@Data
@Getter
public class TreeEntity {
  String tableName;
  List<ColumnEntity> columnNames;
  List<TreeEntity> childTableNameEntityList;

  public TreeEntity(String tableName, List<ColumnEntity> columnNames, List<TreeEntity> childTableNameEntityList) {
    this.tableName = tableName;
    this.columnNames = columnNames;
    this.childTableNameEntityList = childTableNameEntityList;
  }

}
