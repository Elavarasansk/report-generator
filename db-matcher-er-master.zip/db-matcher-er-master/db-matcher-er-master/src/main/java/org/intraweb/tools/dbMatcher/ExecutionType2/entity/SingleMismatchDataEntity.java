package org.intraweb.tools.dbMatcher.ExecutionType2.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SingleMismatchDataEntity {

    private Object _id;
    private String childColumnName;
    private String parentColumnName;
    private String childTable;
    private String parentTable;
    private String differenceColData;

}
