package org.intraweb.tools.dbMatcher.ExecutionType2.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.intraweb.tools.dbMatcher.DbMatcherGui.Consts.DbMatcherConsts;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.MultipleMismatchDataEntity;
import org.intraweb.tools.dbMatcher.ExecutionType2.entity.SingleMismatchDataEntity;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoConnector {

    MongoClient mongo;
    MongoDatabase intraWebDb;

    String SINGLE_MISMATCH_DATA_COLLECTION = DbMatcherConsts.SINGLE_MISMATCH_DATA;
    MongoCollection<Document> singleMismatchDataCollection;

    String MULTI_MISMATCH_DATA_COLLECTION = DbMatcherConsts.MULTI_MISMATCH_DATA;
    MongoCollection<Document> multiMismatchDataCollection;
    
    Map<String, String> credentialsMap;

    public MongoConnector(Map<String, String> credentialsMap) {
        
        String mongoIp = credentialsMap.get(DbMatcherConsts.MongodbHostName);
        int mongoPort = Integer.parseInt(credentialsMap.get(DbMatcherConsts.MongodbPort));
        
        this.mongo = new MongoClient(mongoIp, mongoPort);
        this.intraWebDb = mongo.getDatabase(DbMatcherConsts.Intraweb_Standalone_Tools);

        this.singleMismatchDataCollection = intraWebDb.getCollection(SINGLE_MISMATCH_DATA_COLLECTION);
        this.multiMismatchDataCollection = intraWebDb.getCollection(MULTI_MISMATCH_DATA_COLLECTION);

        if (singleMismatchDataCollection == null) {
            intraWebDb.createCollection(SINGLE_MISMATCH_DATA_COLLECTION);
            this.singleMismatchDataCollection = intraWebDb.getCollection(SINGLE_MISMATCH_DATA_COLLECTION);
        }

        if (multiMismatchDataCollection == null) {
            intraWebDb.createCollection(MULTI_MISMATCH_DATA_COLLECTION);
            this.multiMismatchDataCollection = intraWebDb.getCollection(MULTI_MISMATCH_DATA_COLLECTION);
        }
    }

    public void persistSingleMismatchToCollection(List<SingleMismatchDataEntity> singleMismatchDataList) {
        List<Document> singleMismatchDataDocumentList = new ArrayList<Document>();
        singleMismatchDataList.forEach(f4Events -> {
            Document document = new Document(SingleMismatchDataFields.CHILD_TABLE_COLUMNNAME,
                    f4Events.getChildColumnName())
                            .append(SingleMismatchDataFields.PARENT_TABLE_COLUMNNAME, f4Events.getParentColumnName())
                            .append(SingleMismatchDataFields.CHILD_TABLE, f4Events.getChildTable())
                            .append(SingleMismatchDataFields.PARENT_TABLE, f4Events.getParentTable())
                            .append(SingleMismatchDataFields.DIFFERENCE_COLUMN_DATA, f4Events.getDifferenceColData());
            singleMismatchDataDocumentList.add(document);
        });
        if(!singleMismatchDataDocumentList.isEmpty()) {
            singleMismatchDataCollection.insertMany(singleMismatchDataDocumentList);
        }
    }

    public void persistMultiMismatchToCollection( List<MultipleMismatchDataEntity> singleMismatchDataList) {
        List<Document> mismatchDataDocumentList = new ArrayList<Document>();
        singleMismatchDataList.forEach(f4Events -> {
            Document document = new Document(SingleMismatchDataFields.CHILD_TABLE_COLUMNNAME,
                    f4Events.getChildColumnName())
                            .append(SingleMismatchDataFields.PARENT_TABLE_COLUMNNAME, f4Events.getParentColumnName())
                            .append(SingleMismatchDataFields.CHILD_TABLE, f4Events.getChildTable())
                            .append(SingleMismatchDataFields.PARENT_TABLE, f4Events.getParentTable())
                            .append(SingleMismatchDataFields.DIFFERENCE_COLUMN_DATA, f4Events.getDifferenceColData());
            mismatchDataDocumentList.add(document);
        });
        if(!singleMismatchDataList.isEmpty()) {
            multiMismatchDataCollection.insertMany(mismatchDataDocumentList);
        }
    }

    public List<Document> fetchV36Data() {
        List<Document> iterDoc = singleMismatchDataCollection.find().into(new ArrayList<Document>());
        return iterDoc;
    }
}