package com.infoview.admin.asset.dto.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.infoview.admin.asset.dto.entity.TestAttendDetails;
import com.infoview.admin.asset.dto.vo.TestAttendDetailsVo;


@Transactional
public interface TestAttendDetailsRepository extends JpaRepository<TestAttendDetails, String> {

	TestAttendDetails findById(Long testId);
	
}