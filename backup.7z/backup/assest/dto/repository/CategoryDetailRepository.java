package com.infoview.admin.asset.dto.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.infoview.admin.asset.dto.entity.CategoryDetails;
import com.infoview.admin.asset.dto.entity.UserAuthorityInfo;
import com.infoview.admin.asset.dto.entity.UserDetails;


@Transactional
public interface CategoryDetailRepository extends JpaRepository<CategoryDetails, String> {
	
	CategoryDetails findByCategoryName(String categoryName);
	
	CategoryDetails findByCategoryNameId(long categoryId);
	
}