package com.infoview.admin.asset.dto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.infoview.admin.asset.dto.entity.EmployeeProjectInfo;
import com.infoview.admin.asset.dto.entity.Project;
import com.infoview.admin.asset.dto.entity.Role;

@Transactional
public interface EmployeeProjectInfoRepository extends JpaRepository<EmployeeProjectInfo, Long> {

    EmployeeProjectInfo findByMailIdAndProjectAndRole(String mailId, Project projectId, Role role);
}
