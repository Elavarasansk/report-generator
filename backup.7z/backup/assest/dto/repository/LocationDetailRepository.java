package com.infoview.admin.asset.dto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.infoview.admin.asset.dto.entity.LocationDetails;

@Transactional
public interface LocationDetailRepository extends JpaRepository<LocationDetails, Long> {

	LocationDetails findByPlaceAndBranchAndFloorAndSeatNo(String place, String branch, int floor, String seatNo);
}
