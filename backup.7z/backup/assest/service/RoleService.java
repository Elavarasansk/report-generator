package com.infoview.admin.asset.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infoview.admin.asset.dto.entity.Role;
import com.infoview.admin.asset.dto.repository.RoleRepository;
import com.infoview.admin.asset.dto.vo.RoleVo;
import com.infoview.admin.asset.utils.storage.CookieSessionStorage;

@Service
public class RoleService {

	@Autowired
	private RoleRepository roleRepo;
	
	public List<Role> getRoleList(){
        return roleRepo.findAll();   
    }

    public Role saveRole(RoleVo roleForm) {
        String sessionUser = CookieSessionStorage.get().getUserName();
        Role roleBuilder = Role.builder().build();
        BeanUtils.copyProperties(roleForm, roleBuilder);

        roleBuilder.setCreateUser(sessionUser);
        roleBuilder.setUpdateUser(sessionUser);
        return roleRepo.save(roleBuilder);
    }

    public void removeRole(long roleId){
        roleRepo.delete(roleId);   
    }

}
