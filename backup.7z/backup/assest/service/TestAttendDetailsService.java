package com.infoview.admin.asset.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.TestAttendDetails;
import com.infoview.admin.asset.dto.repository.TestAttendDetailsRepository;
import com.infoview.admin.asset.dto.vo.TestAttendDetailsVo;

import javassist.NotFoundException;

public class TestAttendDetailsService {
	
	@Autowired
	private TestAttendDetailsRepository testAttendDetailsRepository;
	
	public TestAttendDetailsVo addNewTestAttend( TestAttendDetailsVo testAttendDetailsVo)  throws DuplicateKeyException{
		TestAttendDetails testAttendDetails = testAttendDetailsRepository.findOne(testAttendDetailsVo.getTestId());
		if(ObjectUtils.isEmpty(testAttendDetails)) {
			TestAttendDetailsVo testAttendDetailsBuilder= TestAttendDetailsVo.builder().build();
			BeanUtils.copyProperties( testAttendDetails, testAttendDetailsBuilder);
			testAttendDetailsRepository.save(testAttendDetails);
		}else {
			throw new DuplicateKeyException("Test Id - \""+testAttendDetailsVo.getTestId()+"\" already exists."
					+ " So Test cannot be Created");
		}
		return testAttendDetailsVo;
	}
	
	public TestAttendDetailsVo deleteTestAttend(TestAttendDetailsVo testAttendDetailsVo)  throws NotFoundException{
		TestAttendDetails testAttendDetails = testAttendDetailsRepository.findOne(testAttendDetailsVo.getTestId());
		
		if(!ObjectUtils.isEmpty(testAttendDetails)) {
			testAttendDetailsRepository.delete(testAttendDetails.getTestId());
		}else {
			throw new NotFoundException("Test ID - "+ testAttendDetails.getTestId() +" doesnot Exists ");
		}
		return testAttendDetailsVo;
	}
	
	public TestAttendDetailsVo updateTestAttend(TestAttendDetailsVo testAttendDetailsVo)  throws NotFoundException{
		TestAttendDetails testAttendDetails = testAttendDetailsRepository.findById(testAttendDetailsVo.getId());
		
		if(!ObjectUtils.isEmpty(testAttendDetails)) {
			testAttendDetailsRepository.delete(testAttendDetails.getTestId());
			TestAttendDetailsVo testAttendDetailsBuilder= TestAttendDetailsVo.builder().build();
			BeanUtils.copyProperties( testAttendDetails, testAttendDetailsBuilder);
			testAttendDetailsRepository.save(testAttendDetails);
		}else {
			throw new NotFoundException("Test ID - "+ testAttendDetails.getTestId() +" doesnot Exists ");
		}
		return testAttendDetailsVo;
	}
	
}