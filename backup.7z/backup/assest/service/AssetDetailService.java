package com.infoview.admin.asset.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.AssetDetails;
import com.infoview.admin.asset.dto.entity.UserDetails;
import com.infoview.admin.asset.dto.repository.AssetDetailRepository;
import com.infoview.admin.asset.dto.vo.AssetDetailVo;
import com.infoview.admin.asset.dto.vo.DistinctAssetDetailVo;
import com.infoview.admin.asset.utils.storage.CookieSessionStorage;

import javassist.NotFoundException;

@Service
public class AssetDetailService {

	@Autowired
	private AssetDetailRepository assetDetailRepo;
	
	@Autowired
	private UserDetailService userDetailService;

	public List<AssetDetails> fetchAssetDetails(){
		return assetDetailRepo.findAll();
	}
	
	public List<DistinctAssetDetailVo> findDistinctAssetType(){
		List<AssetDetails> assetDetails = assetDetailRepo.findDistinctTypeMakeModel();
		List<DistinctAssetDetailVo> distinctAssetDetails = assetDetails.stream().map(assetDetail -> {
			DistinctAssetDetailVo distinctAssetDetail = DistinctAssetDetailVo.builder().build();
			BeanUtils.copyProperties(assetDetail, distinctAssetDetail);
			return distinctAssetDetail;
		}).collect(Collectors.toList());
		return distinctAssetDetails;
	}
	
	public List<AssetDetails> fetchUserAssetDetail(){
		UserDetails userInfo = userDetailService.fetchUserInfo();
		if(ObjectUtils.isEmpty(userInfo)) {
		    return null;
		}
		List<String> assetIds = Arrays.asList(userInfo.getAssetId().split(","));
		List<Long> assetIdList = assetIds.stream().map(x -> Long.parseLong(x)).collect(Collectors.toList());
		
		return assetDetailRepo.findByIdIn(assetIdList);
	}

	public List<AssetDetails> fetchByAssetType(String assetType){
		return assetDetailRepo.findByType(assetType);
	}

	public List<AssetDetails> saveAssetDetail(AssetDetailVo assetInfo){
		AssetDetails updatedAssetInfo = assetDetailRepo.save(processAssetDetails(assetInfo));
		
		UserDetails userDetails = userDetailService.mapAssetToUser(assetInfo.getMailId(), updatedAssetInfo);
		
		updatedAssetInfo.setLocationDetails(userDetails.getLocationDetails());
		assetDetailRepo.save(updatedAssetInfo);
		
		return this.fetchUserAssetDetail();
	}

	private AssetDetails processAssetDetails(AssetDetailVo assetInfo){
		String sessionUser = CookieSessionStorage.get().getUserName();
		
		AssetDetails assetDetailBuilder = AssetDetails.builder().build();
		BeanUtils.copyProperties(assetInfo, assetDetailBuilder);
		
		checkAssetExists(assetDetailBuilder);
		if(assetInfo.getId() == null) {
			assetDetailBuilder.setCreateUser(sessionUser);
		}
		assetDetailBuilder.setUpdateUser(sessionUser);
		return assetDetailBuilder;
	}
	
	private void checkAssetExists(AssetDetails assetDetailBuilder) {
		AssetDetails existingAsset =  assetDetailRepo.findByTypeAndNameAndSerialNo(assetDetailBuilder.getType(),
				assetDetailBuilder.getName(), assetDetailBuilder.getSerialNo());
		if(!ObjectUtils.isEmpty(existingAsset)) {
			assetDetailBuilder.setId(existingAsset.getId());
		}
	}

	public String deleteAssetInfo(Long id) throws NotFoundException{
		AssetDetails assetDetail = assetDetailRepo.findOne(id);

		if(!ObjectUtils.isEmpty(assetDetail)) {
			assetDetailRepo.delete(id);
		}else {		
			throw new NotFoundException("Employee - "+ id +" doesnot Exists ");
		}		
		return "Employee Details Removed";
	}
}
