package com.infoview.admin.asset.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.util.ObjectUtils;

import com.infoview.admin.asset.dto.entity.CategoryDetails;
import com.infoview.admin.asset.dto.repository.CategoryDetailRepository;

import javassist.NotFoundException;

public class CategoryDetailsService{ 
    
	@Autowired
	private CategoryDetailRepository categoryDetailRepository;
	
	public CategoryDetails addNewCategory(CategoryDetails categoryDetails)  throws DuplicateKeyException{
		CategoryDetails responseCategoryDetail = categoryDetailRepository.findByCategoryName(categoryDetails.getCategoryName());
		
		if(ObjectUtils.isEmpty(responseCategoryDetail)) {
			CategoryDetails categoryDetailsBuilder = CategoryDetails.builder().build();
			BeanUtils.copyProperties(categoryDetails, categoryDetailsBuilder);
			categoryDetailRepository.save(categoryDetailsBuilder);
		}else {
			throw new DuplicateKeyException("Category - \""+categoryDetails.getCategoryName()+"\" already exists."
					+ " So Category cannot be Created");
		}
		return categoryDetails;
	}
	
	public CategoryDetails deleteCategory(CategoryDetails categoryDetails)  throws NotFoundException{
		CategoryDetails responseCategoryDetail = categoryDetailRepository.findByCategoryName(categoryDetails.getCategoryName());
		
		if(!ObjectUtils.isEmpty(responseCategoryDetail)) {
			categoryDetailRepository.delete(categoryDetails.getCategoryName());
		}else {
			throw new NotFoundException("Category - "+ categoryDetails.getCategoryName() +" doesnot Exists ");
		}
		return responseCategoryDetail;
	}
	
	public CategoryDetails updateCategory(CategoryDetails categoryDetails)  throws NotFoundException{
		CategoryDetails responseCategoryDetail = categoryDetailRepository.findByCategoryNameId(categoryDetails.getId());
		
		if(!ObjectUtils.isEmpty(responseCategoryDetail)) {
			categoryDetailRepository.delete(categoryDetails.getCategoryName());
			CategoryDetails categoryDetailsBuilder = CategoryDetails.builder().build();
			BeanUtils.copyProperties(categoryDetails, categoryDetailsBuilder);
			categoryDetailRepository.save(categoryDetailsBuilder);
		}else {
			throw new NotFoundException("Category - "+ categoryDetails.getCategoryName() +" doesnot Exists ");
		}
		return responseCategoryDetail;
	}
}