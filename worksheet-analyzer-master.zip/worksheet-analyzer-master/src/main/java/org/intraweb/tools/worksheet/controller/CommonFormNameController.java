package org.intraweb.tools.worksheet.controller;

import org.intraweb.tools.worksheet.service.CommonFormNameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/common")
public class CommonFormNameController {

    @Autowired
    private CommonFormNameService commonFormNameService;

    @GetMapping("/persist/name")
    public void persistPasName() {
        commonFormNameService.persistPasName();
    }
    
    @GetMapping("/by/name")
    public void getByPasName() {
        commonFormNameService.getFormsByName();
    }

}













