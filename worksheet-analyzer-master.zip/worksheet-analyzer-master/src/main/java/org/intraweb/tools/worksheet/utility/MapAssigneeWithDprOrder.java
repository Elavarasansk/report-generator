package org.intraweb.tools.worksheet.utility;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MapAssigneeWithDprOrder {

	@Autowired
	private FileReadWriteService fileReaderService;

	public void main(String[] args) throws IOException {
		String dprHeirarchyFilePath = "D:\\Vairavan\\Learning\\Projects\\intraweb-redmine\\src\\main\\resources\\SummarizeTargetList.csv";
		List<List<String>> dprData = fileReaderService.readCsvFile(dprHeirarchyFilePath);

		String haraKajimaFilePath = "D:\\Vairavan\\Detailed_DPR_Suggest_Plugins\\Summary\\DPR_Assign hara_with_kajima.csv";
		List<List<String>> haraKajimaData = fileReaderService.readCsvFile(haraKajimaFilePath);

		int start=1;
		int dprCol = 3, complexCol = 12, leaderCol = 15, assigneeCol=18;

		Map<String,List<String>> dprKajimaMap = new HashMap<String,List<String>>();
		for(int i=start; i< haraKajimaData.size(); i++) {
			List<String> additionalDetails = new ArrayList<>();

			additionalDetails.add(haraKajimaData.get(i).get(complexCol));
			additionalDetails.add(haraKajimaData.get(i).get(leaderCol));
			additionalDetails.add(haraKajimaData.get(i).get(assigneeCol));

			dprKajimaMap.put(haraKajimaData.get(i).get(dprCol), additionalDetails);
		}

		List<List<String>> orderlyAssignedDprList = new ArrayList<List<String>>();
		for(List<String> dprRow:dprData) {
			List<String> newDprData = new ArrayList<String>(dprRow); 
			String dprName = dprRow.get(0).replace(".dpr", "");
			log.info(dprName);
			if(CollectionUtils.isEmpty(dprKajimaMap.get(dprName))) {
				orderlyAssignedDprList.add(newDprData);
				continue;
			}
			newDprData.addAll(dprKajimaMap.get(dprName));
			orderlyAssignedDprList.add(newDprData);
		}

		String filePath = "D:\\Vairavan\\";
		fileReaderService.writeToCsvFile(filePath, "MySummaryList", orderlyAssignedDprList);
	}
}
