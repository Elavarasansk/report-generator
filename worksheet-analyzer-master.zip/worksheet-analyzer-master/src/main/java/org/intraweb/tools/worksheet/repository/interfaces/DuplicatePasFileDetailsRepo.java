package org.intraweb.tools.worksheet.repository.interfaces;

import java.util.List;

import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface DuplicatePasFileDetailsRepo extends MongoRepository<DuplicatePasDetails, String>{
    
    List<DuplicatePasDetails> findByPasNameInIgnoreCase(List<String> pasNameList);

}
