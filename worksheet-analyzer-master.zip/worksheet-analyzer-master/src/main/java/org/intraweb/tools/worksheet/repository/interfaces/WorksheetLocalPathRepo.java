package org.intraweb.tools.worksheet.repository.interfaces;

import java.util.List;

import org.intraweb.tools.worksheet.entity.WorksheetLocalPath;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface WorksheetLocalPathRepo extends MongoRepository<WorksheetLocalPath, String>{

	List<WorksheetLocalPath> findByDprName(String dprName);

}