package org.intraweb.tools.worksheet.utility.worksheet;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.development.CheckListJudgment;
import org.intraweb.tools.worksheet.development.JudgeMainFrame;
import org.intraweb.tools.worksheet.entity.WorksheetFileListEntity;
import org.intraweb.tools.worksheet.utility.Constants;
import org.intraweb.tools.worksheet.utility.FilePathReader;

public class LayoutType {

	private WorksheetFileListEntity fileListDetails;

	public LayoutType(WorksheetFileListEntity fileListDetails) {
		this.fileListDetails = fileListDetails;
	}

	public WorksheetFileListEntity computeLayoutType() throws Exception {
		String framework = fileListDetails.getFrameWork();

		if(!isStageOnePassed(framework)) {
			CheckListJudgment checkListJudgment= new CheckListJudgment(fileListDetails);
			checkListJudgment.computeLayoutType();
			return fileListDetails;
		}

		if(isStageTwoPassed()) {
			fileListDetails.setLayoutType(Constants.PARTS_FRAME);
			return fileListDetails;
		}

		if(isStageThreePassed()) {

			fileListDetails.setLayoutType(Constants.MAIN_FRAME);
		} else {
			fileListDetails.setLayoutType(Constants.DIALOG);
		}
		return fileListDetails;
	}

	/*
	 * Framework based Validation
	 * */
	private boolean isStageOnePassed(String framework) {
		boolean result = false;
		switch (framework.toLowerCase()) {
		case Constants.TFORM:
		case Constants.TCFW_ROOT_FRAME:
		case Constants.TCFW_BASE_FRAME:
		case Constants.TCFW_DIALOG:
		case Constants.TCFW_REPORT_FRAME:
			result = true;
			break;
		}
		return result;
	}

	/*
	 * Dynamic Form Validation
	 * */
	private boolean isStageTwoPassed() {
		return isDynamicFrame();
	}

	/*
	 * Main Form Validation
	 * */
	private boolean isStageThreePassed() throws IOException {
		if(fileListDetails.isTargetBiz()) {
			return true;
		}
		String dprPath = fileListDetails.getDprPath();
		String dprAbsolutePath = FilePathReader.getProductPath(dprPath) + dprPath;
		String firstForm = JudgeMainFrame.getFirstForm(dprAbsolutePath);
		if(StringUtils.isEmpty(firstForm)) {
			return false;
		}
		boolean result = isDprsFirstForm(firstForm);
		return result;
	}


	private boolean isDynamicFrame() {
		//TODO: Read pascal file and check arrangeLayout() procedure/function exists
		return false;
	}

	private boolean isDprsFirstForm(String firstForm) {
		return StringUtils.contains(fileListDetails.getFileName(), firstForm);
	}


}
