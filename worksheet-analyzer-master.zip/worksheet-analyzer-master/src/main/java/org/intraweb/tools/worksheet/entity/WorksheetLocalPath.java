package org.intraweb.tools.worksheet.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="worksheet_local_path")
public class WorksheetLocalPath {
	
	@Id
	private ObjectId id;
	
	private String worksheetPath;
	
//	@Indexed(unique=true)
	private String dprName;

}
