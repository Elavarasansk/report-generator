package org.intraweb.tools.worksheet.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="nonform_duplicate_paspath_details")
public class NonFormDuplicatePasDetails {
	
	@Id
	private ObjectId id;

	@Indexed(unique=true)
	private String pasFileName;
	
	private List<String> dprs;

}
