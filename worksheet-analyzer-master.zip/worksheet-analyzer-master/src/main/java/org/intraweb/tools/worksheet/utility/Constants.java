package org.intraweb.tools.worksheet.utility;

public class Constants{
	


	public static final String COMMA=",";
	public static final String CSV_FILE=".csv";
	public static final String TXT_FILE=".txt";
	public static final String WORKSHEET_PREFIX = "Worksheet_";
	
	public static final String MAIN_FRAME = "Main Frame";
	public static final String DIALOG = "Dialog";
	public static final String PARTS_FRAME = "Parts Frame";
	
	public static final String LIST_FRAME = "List Frame";
	public static final String DETAIL_FRAME = "Detail Frame";
	
	public static final int directoryCol = 2;

	public static final int isFormCol = 4; // Cell index in column wise
	public static final int fileNameCol = 3;
	public static final int filePathCol = 34;
	
	public static final int link = 5; 	
	public static final int assignee = 6; 

	public static final int isTargetCol = 7;
	public static final int frameworkCol = 17;
	public static final int typeCol = 18;
	public static final int patternCol = 19;
	public static final int isBizTargetCol = 12;
	
	//Framework List
	public static final String TFORM = "tform";
	public static final String TCFW_ROOT_FRAME = "tcfwrootframe";
	public static final String TCFW_BASE_FRAME = "tcfwbaseframe";
	public static final String TCFW_DIALOG = "tcfwdialog";
	public static final String TCFW_REPORT_FRAME = "tcfwreportframe";
	
	public static final String TCFW_BASE_PLAIN_DIALOG = "tcfwbaseplaindialog";
	public static final String TCFW_BASE_SEARCH_DIALOG = "TCfwBaseSearchDialog";
	
	public static final String SEARCH_DIALOG = "Search Dialog";
	
	public static final String TCFW_BASE_FRAME_EXCOOL = "tcfwbaseframeexcool";
	
	public static final String TCFW_BASE_LIST_FRAME = "TCfwBaseListFrame";
	public static final String TCFW_BASE_LIST_FRAME_EXCOOL = "TCfwBaseListFrameExCool";
	
	public static final String TCFW_ROOT_DETAIL_FRAME = "TCfwRootDetailFrame";
	public static final String TCFW_DETAIL_FRAME = "TCfwDetailFrame";
	
}



