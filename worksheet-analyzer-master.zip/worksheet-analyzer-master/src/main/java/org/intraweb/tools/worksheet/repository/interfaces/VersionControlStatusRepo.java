package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.VersionControlStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface VersionControlStatusRepo extends MongoRepository<VersionControlStatus, String> {
	
	VersionControlStatus findByVersionTypeAndModule(String version, String moduleName);

}
