package org.intraweb.tools.worksheet.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.IOUtils;
import org.intraweb.tools.worksheet.service.autocheckservice.AutoCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("autocheck/")
@CrossOrigin
public class AutoCheckController {

	@Autowired
	private AutoCheckService autoCheckService;

	
	@PostMapping("mode/dfm")
	public void executeAutoCheckSingleDfm(@RequestParam("file") MultipartFile uploadFiles, HttpServletResponse response) throws Exception {
		File file = autoCheckService.dispatchAutoCheck(uploadFiles);
		InputStream inputStream = new FileInputStream(file);       
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename="+file.getCanonicalFile().getName()); 
		IOUtils.copy(inputStream, response.getOutputStream());
		response.flushBuffer();
		inputStream.close();
		FileUtils.deleteQuietly(file);
	}
	
	@PostMapping("mode/worksheet")
	public void executeAutoCheckWorkSheet(@RequestParam("file") MultipartFile uploadFiles, HttpServletResponse response) throws Exception {
		
	}
	
	


}
