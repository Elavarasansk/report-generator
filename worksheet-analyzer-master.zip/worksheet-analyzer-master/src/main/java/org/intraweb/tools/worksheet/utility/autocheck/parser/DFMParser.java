package org.intraweb.tools.worksheet.utility.autocheck.parser;





import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.LinkedList;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.CellType;
import org.intraweb.tools.worksheet.entity.aligner.DFMData;
import org.intraweb.tools.worksheet.entity.aligner.DFMObject;
import org.intraweb.tools.worksheet.utility.autocheck.colorcode.DFMPanelArranger;

import lombok.extern.slf4j.Slf4j;



/**
 * Hello world!
 *
 */
@Slf4j
public class DFMParser {
	private static String CRLF = "\\R";
	private  int lineIndex;
	private  int spaceCount;    
	private  DFMObject resObj;

	
	public DFMParser() {
		this.lineIndex = 0;
		this.spaceCount = 0;
		this.resObj = new DFMObject();
	}




	// public static void main(String[] args) throws IOException {
	// String content = readFile("D:/Setup files/VscIssuerExpBondReceiveDlg.dfm");
	// String[] lines = content.split(CRLF);
	// DFMObject treeData = processLines(lines);
	// DFMObject in = treeData;
	// DFMObject out = DFMIWArranger.rearrageData(treeData);
	// String fileData = makeFileFromData(treeData);
	// DFMLauncher.makeLog(fileData);
	// DFMLauncher.makeLog("LOC = " + fileData.split(System.lineSeparator()).length);
	// writeFile(fileData, "C:/HUE/WorkSpace/Develop/hue-ac-chennai-ccm/hue_client/delphi/CCM/VSC/view/issuerExp/common/bond/VscIssuerExpBondReceiveDlg.dfm");
	// callConvert("D:/Setup files/VscIssuerExpBondReceiveDlg.dfm", "C:/HUE/WorkSpace/Develop/hue-ac-chennai-ccm/hue_client/delphi/CCM/VSC/view/issuerExp/common/bond/VscIssuerExpBondReceiveDlg.dfm");
	// }

	public  void callWorksheetConvert(String inFile) throws FileNotFoundException {
		File worksheet = new File(inFile);

		if (!worksheet.exists()) {
			throw new FileNotFoundException("Worksheet file not found at given location.");
		}

		try {
			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(worksheet));
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFRow row = null;
			HSSFCell cell = null;

			int rows; // No of rows
			rows = sheet.getPhysicalNumberOfRows();

			int cols = 0; // No of columns
			int tmp = 0;

			// This trick ensures that we get the data properly even if it doesn't start from first few rows
			for (int i = 0; i < 10 || i < rows; i++) {
				row = sheet.getRow(i);
				if (row != null) {
					tmp = sheet.getRow(i).getPhysicalNumberOfCells();
					if (tmp > cols)
						cols = tmp;
				}
			}
			HSSFCell targetRow = getFirstCell("Target", sheet, rows, cols, row, cell);
			int targetColumn = targetRow.getColumnIndex();
			int dataStartRow = targetRow.getRowIndex() + 1; // we can start reading data from this line
			int filePathColumn = getFirstCell("File Path", sheet, rows, cols, row, cell).getColumnIndex();

			LinkedList<HSSFRow> checkRow = new LinkedList<HSSFRow>();
			// getting the rows that have TRUE in the Target column
			for (int r = dataStartRow; r < rows; r++) {
				row = sheet.getRow(r);
				if (row != null) {
					int c = targetColumn;
					cell = row.getCell((short) c);
					if (cell != null) {
						// some cells are in number format. 1 = TRUE, 0 = FALSE
						if (cell.getCellType().equals(CellType.STRING)) {
							if (cell.getRichStringCellValue().getString().toLowerCase().contains("true")) {
								// This row has data for processing
								checkRow.add(row);
							}
						} else if (cell.getCellType().equals(CellType.BOOLEAN)) {
							if (cell.getBooleanCellValue()) {
								// This row has data for processing
								checkRow.add(row);
							}
						} else if (cell.getCellType().equals(CellType.FORMULA)) {
							if (cell.getBooleanCellValue()) {
								// This row has data for processing
								checkRow.add(row);
							}
						} else if (cell.getCellType().equals(CellType.NUMERIC)) {
							if (cell.getNumericCellValue() == 1) {
								// This row has data for processing
								checkRow.add(row);
							}
						} else {
							log.error("[WARNING] Unknown data format found in target column. " +  cell.getCellType());
						}
					}
				}
			}

			// for all data in checkRow need to generate files.
			// resultant files will get generated at the tool's path

			LinkedList<String> files = new LinkedList<String>();
			// process the rows and get the actual source file path
			for (int i = 0; i < checkRow.size(); i++) {
				String location = checkRow.get(i).getCell(filePathColumn).getStringCellValue();
				String subFolderSuffix = location.split("\\\\")[0].toLowerCase();
				files.add("C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-" + (subFolderSuffix.matches("share|sharetest|CompanyAC|common|accommon") ? "cac" : subFolderSuffix) + "\\hue_client\\delphi\\" + location.replace(".pas", ".dfm"));
			}

			for (int i = 0; i < files.size(); i++) {
				try {
					// DFMLauncher.makeLog("Processing File " + files.get(i), true);
					String existReplace = makeOriginalBackup(files.get(i), "before"); // made backup of old
					if (existReplace != null) {
						//TODO  changes for worksheet need.
						//  callConvert(existReplace, files.get(i)); // tool is run for the second time. take file from backup taken in "before" folder
					} else {
						//TODO  changes for worksheet need.
						// callConvert(files.get(i), files.get(i)); // dare to write in source
					}
					makeOriginalBackup(files.get(i), "after"); // made backup of new
					// callConvert(files.get(i), "D:\\outputCheck\\" + files.get(i).split("hue_client\\\\delphi\\\\")[1]);
					// DFMLauncher.makeLog("Processing File Complete.", true);
					//  DFMLauncher.makeLog("", true);
				} catch (FileNotFoundException e) {
					log.error("File Not Found  " + e.getMessage());
				} catch (Exception e) {
					log.error("[ERROR] " + e.getMessage());
				}
			}
			wb.close();
		} catch (Exception e) {
			log.error("[ERROR] " + e.getMessage());
		}
	}

	private  String makeOriginalBackup(String sourcePath, String parentInner) throws IOException {
		File oldFile = new File(sourcePath);
		File backupFile = new File(oldFile.getParent() + "\\" + parentInner + "\\" + oldFile.getName());
		if (!backupFile.getParentFile().exists()) {
			backupFile.getParentFile().mkdir();
		}
		if (parentInner.equals("before") && backupFile.exists()) { // backup already taken. No need to copy.
			return backupFile.getAbsolutePath();
		}
		Files.copy(oldFile.toPath(), backupFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
		return null;
	}

	private  HSSFCell getFirstCell(String colName, HSSFSheet sheet, int rows, int cols, HSSFRow row, HSSFCell cell) {
		for (int r = 0; r < rows; r++) {
			row = sheet.getRow(r);
			if (row != null) {
				for (int c = 0; c < cols; c++) {
					cell = row.getCell((short) c);
					if (cell != null) {
						if (cell.getCellType().equals(CellType.STRING) && cell.getRichStringCellValue().getString().equals(colName)) {
							return cell;
						}
					}
				}
			}
		}
		return null;
	}

	public File execAutoCheck(File inFile, String fileName) throws IOException {
		//  if (!DFMLauncher.isWorksheetMode && inFile.equals(outFile)) {
		//      DFMLauncher.makeLog("[WARNING] Input and Output files are the same. This may cause loss of data and re doing v4-Convert. Kindly change the destination file name.", true);
		//      return;
		//  }
		// DFMLauncher.makeLog("Processing File " + inFile, true);

		String content = readFile(inFile);
		String[] lines = content.split(CRLF);
		DFMObject treeData = processLines(lines);

		DFMPanelArranger panelArranger = new DFMPanelArranger();
		panelArranger.setColorCode(treeData);
		//        System.out.println(treeData);
		//        DFMFileTreeGenerator.arrangeCurrentPanel(treeData);
		//        DFMObject newTreeData =   DFMPanelArranger.setPanelHW(treeData);
		// DFMIWArranger.rearrageData(treeData);
		String fileData = makeFileFromData(treeData);
		// DFMLauncher.makeLog(fileData);
		// DFMLauncher.makeLog("LOC = " + fileData.split(System.lineSeparator()).length);
		// if(DFMIWArranger.nullTopLeftFlag){
		// TODO some parameter gets appended in the first line. Need to check.
		if (!fileData.startsWith("inherited") && !fileData.startsWith("object")) {
			fileData = fileData.substring(fileData.indexOf("\n") + 1, fileData.length());
		}
		// }
		return writeFile(fileData,fileName);
	}

	private File writeFile(String fileData,String fileName) throws IOException {
		File f = new File(fileName);
		try (FileWriter fw = new FileWriter(f)){
			fw.append(fileData);
			fw.flush();
		}       
		return f;
	}

	private  String makeFileFromData(DFMObject a) {
		StringBuilder sb = new StringBuilder();
		printFile(a, sb);
		sb = sb.delete(0, "root\r\n".length());
		sb = sb.delete(sb.length() - "end\r\n".length(), sb.length());
		return sb.toString();
	}

	/**
	 * printTree method is used for
	 * 
	 * @param treeNode
	 */
	private  String printFile(DFMObject treeNode, StringBuilder sb) {
		printData(treeNode, sb);
		treeNode.getChild().stream().forEachOrdered(child -> {
			printFile(child, sb);
		});
		sb.append(DFMData.getSpace(spaceCount) + "end" + System.lineSeparator());
		spaceCount -= 2;
		return sb.toString();
	}

	private  void printData(DFMObject a, StringBuilder sb) {
		registerSpace(a.getName());
		if (a.getClassName() == null) {
			sb.append(a.getName() + System.lineSeparator());
		} else {
			sb.append(a.getName() + ": " + a.getClassName() + System.lineSeparator());
		}
		if (a.getData() != null) {
			a.getData().forEach((da, va) -> {
				sb.append(da + "= " + va + System.lineSeparator());
			});
		}
	}

	private  void registerSpace(String name) {
		spaceCount = (int) (name.chars().filter(Character::isWhitespace).count() - 1);
	}

	/**
	 * processLines method is used for
	 * 
	 * @param lines
	 */
	private  DFMObject processLines(String[] lines) {
		DFMObject currentObj = new DFMObject();
		currentObj.setName("root");
		currentObj.setParent(currentObj);
		DFMObject rootObj = currentObj;
		DFMObject newObj = null;
		for (lineIndex = 0; lineIndex < lines.length; lineIndex++) {
			// DFMLauncher.makeLog(lines[lineIndex]);
			if (lines[lineIndex].trim().startsWith("inherited") || lines[lineIndex].trim().startsWith("object")) {
				// inobCnt++;
				newObj = makeNewNode(lines[lineIndex]);
				newObj.setParent(currentObj);
				currentObj.setChild(newObj);
				currentObj = newObj;
				// DFMLauncher.makeLog(newObj.getName());
			} else if (lines[lineIndex].trim().equals("end")) {
				// endCnt++;
				currentObj = currentObj.getParent();
			} else {
				currentObj.setData(getKeyValue(lines, lineIndex));
			}
		}
		return rootObj;
	}

	/**
	 * makeNewNode method is used for
	 * 
	 * @param obj
	 * @param string
	 * @return
	 */
	private  DFMObject makeNewNode(String string) {
		DFMObject newObj = new DFMObject();
		String[] tokens = string.split(": "); // .split("inherited |object ")[1] trying to preserve text as it is as much as possible
		newObj.setName(tokens[0]);
		if (tokens.length > 1) {
			newObj.setClassName(tokens[1]);
		}
		return newObj;
	}

	/**
	 * readFile method is used for
	 * 
	 * @param string
	 * @return
	 * @throws IOException
	 */
	private  String readFile(File f) throws IOException {
		StringBuilder sb = new StringBuilder();
		if (!f.exists()) {
			throw new FileNotFoundException("Target file not found.");
		}
		if (!f.getAbsolutePath().endsWith(".dfm")) {
			throw new FileNotFoundException("Please select a .DFM file");
		}
		FileReader fr = new FileReader(f);
		int c;
		while ((c = fr.read()) != -1) {
			sb.append((char) c);
		}
		fr.close();
		return sb.toString();
	}

	/**
	 * getKeyValue method is used for
	 * 
	 * @param string
	 * @return
	 */
	public  String[] getKeyValue(String[] lines, int lineIndex) {
		// if(lineIndex == 5270){
		// System.out.println();
		// }
		String[] result = null;
		if (lines[lineIndex].isEmpty()) {
			return new String[] { "", "" };
		}
		try {
			if (lines[lineIndex].split("=")[1].trim().isEmpty()) {
				result = new String[] { lines[lineIndex].split("=")[0], getNullMLValue(lines, lineIndex) };
			} else {
				return new String[] { lines[lineIndex].split("=")[0], getMLValue(lines[lineIndex].split("=")[1].trim(), lines) };
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("[ERROR]"+e.getMessage());
		}
		return result;
	}

	public  String[] getStringKeyValue(String[] lines, int lineIndex) {
		String[] result = null;
		String value = lines[lineIndex];
		if (value.isEmpty()) {
			return new String[] { "", "" };
		}
		try {
			if (value.split("=").length == 1) {
				return null; // multiline data
			}
			if (value.endsWith("[") || value.endsWith("(") || value.endsWith("{") || value.endsWith("<")) { // MLValue inside ML value
				return new String[] { value.split("=")[0], getInnerMLValue(lines[lineIndex].split("=")[1].trim(), lines, lineIndex) };
			} else {
				if (value.split("=")[1].trim().isEmpty()) {
					result = new String[] { value.split("=")[0], getNullMLValue(lines, lineIndex) };
				} else {
					return new String[] { value.split("=")[0], getMLValue(lines[lineIndex].split("=")[1].trim(), lines) };
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("[Error] "+ e.getMessage());
		}
		return result;
	}

	private String getNullMLValue(String[] lines, int lineInde) {
		StringBuilder sb = new StringBuilder();
		sb.append(System.lineSeparator());
		for (int i = lineInde + 1; i < lines.length; i++) {
			if (lines[i].contains("=")) {
				lineIndex = i;
				break;
			}
			sb.append(lines[i] + System.lineSeparator());
		}
		return sb.toString();
	}

	private static String getInnerMLValue(String value, String[] lines, int currentLineIndex) {
		if (value.startsWith("[") || value.startsWith("(") || value.startsWith("{") || value.startsWith("<")) {
			StringBuilder sb = new StringBuilder();
			char startClosureChar = value.trim().charAt(0);
			char closureChar = startClosureChar;
			switch (startClosureChar) {
			case '[':
				closureChar = ']';
				break;
			case '(':
				closureChar = ')';
				break;
			case '{':
				closureChar = '}';
				break;
			case '<':
				closureChar = '>';
				break;
			default:
				break;
			}
			if (value.endsWith(closureChar + "") || lines[currentLineIndex].endsWith(closureChar + "")) {
				return value;
			}
			sb.append(startClosureChar + System.lineSeparator());
			for (currentLineIndex++; currentLineIndex < lines.length; currentLineIndex++) {
				sb.append(lines[currentLineIndex] + System.lineSeparator());
				if (lines[currentLineIndex].endsWith(closureChar + "")) {
					break;
				}
			}
			return sb.toString();
		} else {
			return value;
		}
	}

	/**
	 * getMLValue method is used for
	 * 
	 * @param lineIndex
	 * @param lines
	 * 
	 * @param trim
	 * @return
	 */
	private  String getMLValue(String value, String[] lines) {
		if (value.startsWith("[") || value.startsWith("(") || value.startsWith("{") || value.startsWith("<")) {
			StringBuilder sb = new StringBuilder();
			char startClosureChar = value.trim().charAt(0);
			char closureChar = startClosureChar;
			switch (startClosureChar) {
			case '[':
				closureChar = ']';
				break;
			case '(':
				closureChar = ')';
				break;
			case '{':
				closureChar = '}';
				break;
			case '<':
				closureChar = '>';
				break;
			default:
				break;
			}
			if (value.endsWith(closureChar + "") || lines[lineIndex].endsWith(closureChar + "")) { // single line data close
				return value;
			}
			sb.append(startClosureChar + System.lineSeparator());
			for (lineIndex++; lineIndex < lines.length; lineIndex++) {
				sb.append(lines[lineIndex] + System.lineSeparator());
				if (lines[lineIndex].endsWith(closureChar + "")) {
					break;
				}
			}
			return sb.toString();
		} else {
			return value;
		}
	}


	private  DFMObject iterateChildren(DFMObject treeData, String inputPnl) {
		if(treeData.getChild().size() > 0) {
			for(DFMObject child: treeData.getChild()) {
				iterateChildren(child, inputPnl);
				if(child.getName().trim().split(" ")[1].equalsIgnoreCase(inputPnl)) {
					resObj = child;
					break;
				}
			}
		}
		return resObj;
	}

	private  void getNonEmptyChildParent(DFMObject treeData, Set<String> resPanelList) {
		for(DFMObject child: treeData.getChild()) {
			if(!child.getChild().isEmpty()) {
				getNonEmptyChildParent(child, resPanelList);
			} else {
				resPanelList.add(child.getParent().getName().trim().split(" ")[1]);
			}
		}
	}

}
