package org.intraweb.tools.worksheet.utility.autocheck.colorcode;



import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.entity.aligner.DFMData;
import org.intraweb.tools.worksheet.entity.aligner.DFMObject;

public class DFMColorCodeFixer {


	private static List<String> condition_4_Edit = Arrays.asList("TEdit","TEcoEdit","TSpecialEdit","TSpEdit2","TSpEdit2Color","TSpEditAc","THistoryEdit","TListEdit","TFillEdit","TSpinEdit","THueSuggestEdit");

	private static List<String> condition_4_ComboBox = Arrays.asList("TCompanyComboBox","TCorpComboBox","TCorpComboBox2","THistoryComboBox","TIniCombo2","TLightComboBox","TModuleComboBox","TProductComboBox","TWAComboBox","TComboBox");

	private static List<String> condition_4_Currency = Arrays.asList("TTCurrencyCtrl","TMoneyCtrl2","TMoneyCtrlAC");

	private static List<String> condition_4_Mask = Arrays.asList("TCompanyMask","TMaskEdit");	

	private static List<String> condition_6_Memo= Arrays.asList("TMemo","TCompanyMemo2","TWARichEdit","TLinkMemo2","TRichEdit");

	private static List<String> condition_10_Panel = Arrays.asList("TWAPanel","TWAScrollBox","TWANoteBook","TWAGroupBox");

	private static List<String> condition_1_Label = Arrays.asList("TIniLabel2","TSmartLabel","TWACustomLabel","TLinkLabel","TWAStaticText");

	private static List<String> condition_7_checkbox = Arrays.asList("TCheckBox","TDivCheckBox","TSpecialCheckBox");

	private static List<String> condition_15_Grid= Arrays.asList("TTControlGrid","TTMultilineControlGrid","TWAStringGrid0","TDrawGrid","TStringGrid");

	private static List<String> condition_5_DateTime= Arrays.asList("TDateTimeCtl2");


	///EDIT COMPONENT///

	//Enabled //00FFFFFF 
	private static String EDIT_ENABLED = "clWhite";	

	//Readonly //00F3EFED
	private static String EDIT_READONLY = "15986669";

	//ViewOnly
	private static String EDIT_VIEWONLY = "clBtnFace";

	//Disabled //00EAE8E6
	private static String EDIT_DISABLED = "15395046";



	///DATE TIME COMPONENT///

	//Enabled //00FFFFFF 
	private static String DATE_ENABLED = "clWhite";	

	//Readonly //00F3EFED
	private static String DATE_READONLY = "15986669";

	//Disabled //00EAE8E6
	private static String DATE_DISABLED = "15395046";




	private static String PANEL_COLOR = "$00F2F1F0";


	//$00333333	
	private static String HEADER_LABEL_COLOR = "3355443";

	//$007F7F7F
	private static String INPUT_LABEL_COLOR = "8355711";


	private static String CHECKBOX_ENABLED_TRUE = "#333";

	private static String CHECKBOX_ENABLED_FALSE = "#d0d0d0";

	private static String CHECKBOX_VIEWONLY_TRUE = "#d0d0d0";


	//#7f7f7f

	private static String COMBOBOX_COLOR = "clWhite";

	private static String GRID_HEADER_COLOR = "clWhite";














	public  void fixColorCode(DFMObject dfmObject) {

		if(StringUtils.isEmpty(dfmObject.getClassName())) {
			return;
		}

		if(condition_1_Label.contains(dfmObject.getClassName().trim())) {
			System.out.println("Label: "+dfmObject.getName());
			setLabelFontColor(dfmObject);
		}


		if(condition_4_Edit.contains(dfmObject.getClassName().trim())) {
			System.out.println("Edit: "+dfmObject.getName());
			setEditColor(dfmObject) ;
		}

		if(condition_4_Currency.contains(dfmObject.getClassName().trim())) {
			System.out.println("Currency: "+dfmObject.getName());
			setEditColor(dfmObject) ;

		}

		if(condition_4_Mask.contains(dfmObject.getClassName().trim())) {
			System.out.println("Mask: "+dfmObject.getName());
			setEditColor(dfmObject) ;


		}

		if(condition_4_ComboBox.contains(dfmObject.getClassName().trim())) {
			//setData(dfmObject, "Font.Color", COMBOBOX_COLOR);
			System.out.println("Combo: "+dfmObject.getName());
			setEditColor(dfmObject) ;

		}

		if(condition_5_DateTime.contains(dfmObject.getClassName().trim())) {
			System.out.println("DateTime: "+dfmObject.getName());
			setDateTimeColor(dfmObject) ;
		}

		if(condition_6_Memo.contains(dfmObject.getClassName().trim())) {
			System.out.println("Memo: "+dfmObject.getName());
			setDateTimeColor(dfmObject) ;
		}


		//if(condition_10_Panel.contains(dfmObject.getClassName().trim())) {
		//		setColor(dfmObject,"color",PANEL_COLOR);
		//	}


		if(condition_7_checkbox.contains(dfmObject.getClassName().trim())) {
			//	setCheckBoxColor(dfmObject);
		}




		if(condition_15_Grid.contains(dfmObject.getClassName().trim())) {
			//setData(dfmObject, "Font.Color", GRID_HEADER_COLOR);
		}


	}


	private  void setDateTimeColor(DFMObject node) {

		if(isExist(node, "Enabled")) {
			boolean isEnabled = Boolean.valueOf(getDFMPData(node, "Enabled"));			
			if(!isEnabled)
				setData(node, "Color", !isEnabled ?  DATE_DISABLED : DATE_ENABLED );
			else
				setData(node, "Color",  DATE_ENABLED );
		}else if(isExist(node, "ReadOnly")) {
			boolean isReadOnly = Boolean.valueOf(getDFMPData(node, "ReadOnly"));
			if(isReadOnly)
				setData(node, "Color", isReadOnly ?  DATE_READONLY: DATE_ENABLED  );
			else
				setData(node, "Color",  DATE_ENABLED );
		}else {
			setData(node, "Color",  DATE_ENABLED );
		}
	}


	private  void setEditColor(DFMObject node) {
		System.out.println("SuggestEdit : "+node.getName());

		if(isExist(node, "Enabled")) {
			boolean isEnabled = Boolean.valueOf(getDFMPData(node, "Enabled"));			
			if(!isEnabled)
				setData(node, "Color", !isEnabled ?  EDIT_DISABLED : EDIT_ENABLED );
			else
				setData(node, "Color",  EDIT_ENABLED );
		}else if(isExist(node, "ReadOnly")) {
			boolean isReadOnly = Boolean.valueOf(getDFMPData(node, "ReadOnly"));
			if(isReadOnly)
				setData(node, "Color", isReadOnly ?  EDIT_READONLY: EDIT_ENABLED  );
			else
				setData(node, "Color",  EDIT_ENABLED );
		}else if(isExist(node, "ViewOnly")) {
			boolean isViewOnly = Boolean.valueOf(getDFMPData(node, "ViewOnly"));
			if(isViewOnly)
				setData(node, "Color", isViewOnly ?  EDIT_VIEWONLY : EDIT_ENABLED );
			else
				setData(node, "Color",  EDIT_ENABLED );
		}else {
			setData(node, "Color",  EDIT_ENABLED );
		}
	}


	private  void setCheckBoxColor(DFMObject node) {
		if(isExist(node, "Enabled")) {
			boolean isEnabled = Boolean.valueOf(getDFMPData(node, "Enabled"));			
			setData(node, "Color", isEnabled ?  CHECKBOX_ENABLED_TRUE : CHECKBOX_ENABLED_FALSE );
		}else if(isExist(node, "ViewOnly")) {
			boolean isViewOnly = Boolean.valueOf(getDFMPData(node, "ViewOnly"));
			setData(node, "Color", isViewOnly ?  CHECKBOX_VIEWONLY_TRUE : CHECKBOX_ENABLED_TRUE );
		}else {
			setData(node, "Color",  CHECKBOX_ENABLED_TRUE );
		}
	}


	private  void setLabelFontColor(DFMObject dfmObject) {

		String LabelType = getDFMPData(dfmObject, "LabelType");
		if(StringUtils.isEmpty(LabelType)) {
			return;
		}

		System.out.println("LabelType : "+LabelType);
		switch(LabelType.trim()) {
		case "ltHeaderLabel":
			if(isExist(dfmObject, "Font.Color")) {	
				setData(dfmObject,"Font.Color",HEADER_LABEL_COLOR);
			}
			if(isExist(dfmObject, "Color")) {	
				setData(dfmObject,"Color",HEADER_LABEL_COLOR);
			}
			break;
		case "ltInputLabel":
			if(isExist(dfmObject, "Font.Color")) {	
				setData(dfmObject,"Font.Color",INPUT_LABEL_COLOR);
			}
			if(isExist(dfmObject, "Color")) {	
				setData(dfmObject,"Color",INPUT_LABEL_COLOR);

			}
			break;	
			//TODO Text Label need to implement.
			//TODO Link Label need to implement.
		default:
			break;
		}

	}


	private  String getDFMPData(DFMObject child, String key) {
		AtomicReference<String> val = new AtomicReference<>("0");
		if (child.getData() != null) {
			child.getData().forEach((k, v) -> {
				if (k.trim().equalsIgnoreCase(key)) {
					val.set(v.toString());
				}
			});
		}
		return val.get();
	}


	/*	private static void setColor(DFMObject node, String attribute, String eDIT_ENABLED2) {
		if (MapUtils.isNotEmpty(node.getData())) {
			node.getData().forEach((k, v) -> {
				if (k.trim().equalsIgnoreCase(attribute)) {
					v.setData(eDIT_ENABLED2);
				} 
			});
		} 

	}*/


	private  void setData(DFMObject node, String attribute, String value) {
		Map<String, DFMData> inputMap = node.getData();
		if (MapUtils.isNotEmpty(inputMap)) {
			inputMap.entrySet().forEach(rec -> {
				if ((rec.getKey().trim().split("=")[0].equalsIgnoreCase(attribute))) {
					inputMap.put(rec.getKey(), new DFMData(value));
				} 
			});
		} 

	}


	private static boolean isExist(DFMObject node, String paramKey) {
		boolean result = false;
		if(MapUtils.isNotEmpty(node.getData())) {
			return node.getData().entrySet()
					.stream()
					.filter(dfm-> StringUtils.equalsIgnoreCase(dfm.getKey().trim(),paramKey))
					.collect(Collectors.toList()).size() > 0;
		}
		return result;
	}




}
