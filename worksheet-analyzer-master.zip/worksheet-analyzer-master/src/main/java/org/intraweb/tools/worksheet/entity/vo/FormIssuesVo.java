package org.intraweb.tools.worksheet.entity.vo;

import java.util.Date;

import org.bson.types.ObjectId;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FormIssuesVo {

    private ObjectId id;

    private int issueId;

    private String status;
    private String priority;
    private String subject;
    private String assigneeName;
    private Date startDate;
    private Date dueDate;
    private String module;
    
    private boolean parent;
    private boolean childTested;

}
