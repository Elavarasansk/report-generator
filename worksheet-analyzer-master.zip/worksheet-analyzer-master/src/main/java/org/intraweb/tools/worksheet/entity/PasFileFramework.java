package org.intraweb.tools.worksheet.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="pas_file_framework")
public class PasFileFramework {

	@Id
	private ObjectId id;
	
	@Indexed(unique=true)
	private String filePath;
	
	private String fileName;
	private String framework;
}
