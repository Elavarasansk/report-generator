package org.intraweb.tools.worksheet.dto;

import lombok.Builder;

import lombok.Data;

@Data
@Builder
public class FramworkTypePatternDto {
	
	private String pasFileName; 
	private String framework; 
	private String layoutType; 
	private String layoutPattern;

}
