package org.intraweb.tools.worksheet.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.intraweb.tools.worksheet.entity.FormIssues;
import org.intraweb.tools.worksheet.entity.FormParentChildRelationEntity;
import org.intraweb.tools.worksheet.entity.PasFileHierarchy;
import org.intraweb.tools.worksheet.entity.vo.FormIssuesVo;
import org.intraweb.tools.worksheet.repository.interfaces.FormIssuesRepo;
import org.intraweb.tools.worksheet.repository.interfaces.FormParentChildRelationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Service
public class NonTestedFormService {
    @Autowired
    private FormIssuesRepo formIssuesRepo;

    @Autowired
    private FormParentChildRelationRepo formParentChildRelationRepo;

    private static final String Status = "Developed";

    public List<FormIssuesVo> getAllNonTestedFormDetails() {
	List<FormIssuesVo> formIssuesVoList = new ArrayList<>();
	List<FormIssues> formIssuesList = formIssuesRepo.findAll();
	String formName = null;
	formIssuesList = formIssuesList.stream()
		.filter(x -> (x.getStatus().toLowerCase().equals("developed")) && (x.getAssigneeName() == null))
		.collect(Collectors.toList());
	for (FormIssues formIssues : formIssuesList) {
	    FormIssuesVo formIssuesVo = getFormIssues(formIssues);
	    formName = formIssuesVo.getSubject();
	    getParentChildRelation(formName, formIssuesVo);
	    formIssuesVoList.add(formIssuesVo);
	}
	return formIssuesVoList;
    }

    private FormIssuesVo getFormIssues(FormIssues formIssues) {
	String subject = formIssues.getSubject();
	return FormIssuesVo.builder().id(formIssues.getId()).issueId(formIssues.getIssueId())
		.status(formIssues.getStatus()).priority(formIssues.getPriority()).subject(subject)
		.assigneeName(formIssues.getAssigneeName()).startDate(formIssues.getStartDate())
		.dueDate(formIssues.getDueDate()).module(getModule(subject)).build();
    }

    private String getModule(String subject) {
	String module = "COM";
	if (subject.startsWith("CAM")) {
	    return module = "CAM";
	} else if (subject.startsWith("CBM")) {
	    return module = "CBM";
	} else if (subject.startsWith("CCM")) {
	    return module = "CCM";
	} else if (subject.startsWith("CFM")) {
	    return module = "CFM";
	}
	return module;
    }

    public void getParentChildRelation(String formName, FormIssuesVo formIssuesVo) {
	FormParentChildRelationEntity formParentChildRelationEntity = formParentChildRelationRepo
		.findByFormName(formName);

	if (ObjectUtils.isEmpty(formParentChildRelationEntity)) {
	    formIssuesVo.setParent(false);
	    formIssuesVo.setChildTested(false);
	    return;
	}

	List<PasFileHierarchy> pasFileChildrenList = formParentChildRelationEntity.getChildrenList();
	boolean isParent = CollectionUtils.isNotEmpty(pasFileChildrenList);
	formIssuesVo.setParent(isParent);
	if (isParent) {
	    Set<String> absolutePathSet = new HashSet<>();

	    pasFileChildrenList.forEach(pasFileHierarchy -> {
		getAllPath(pasFileHierarchy, absolutePathSet);
	    });

	    List<FormIssues> formIssuesVoListAfterFiltering = formIssuesRepo
		    .findBySubjectInAndStatus(new ArrayList<String>(absolutePathSet), Status);
	    formIssuesVoListAfterFiltering = formIssuesVoListAfterFiltering.stream()
		    .filter(data -> data.getAssigneeName() != null).collect(Collectors.toList());
	    formIssuesVo.setChildTested(formIssuesVoListAfterFiltering != null);
	} else {
	    formIssuesVo.setParent(false);
	}
    }

    private String getAllPath(PasFileHierarchy pasFileHierarchy, Set<String> absolutePathList) {
	String absolutePath = pasFileHierarchy.getAbsoluteFilePath();
	if (pasFileHierarchy.getChildEntry() != null) {
	    System.out.println(pasFileHierarchy);
	    absolutePathList.add(getAllPath(pasFileHierarchy.getChildEntry().get(0), absolutePathList));
	} else {
	    absolutePathList.add(absolutePath);
	}
	return absolutePath;
    }
}
