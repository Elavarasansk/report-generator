package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.EpicIssues;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EpicIssuesRepo extends MongoRepository<EpicIssues, String> {
	
	public EpicIssues findByIssueId(int issueId);
	
}
