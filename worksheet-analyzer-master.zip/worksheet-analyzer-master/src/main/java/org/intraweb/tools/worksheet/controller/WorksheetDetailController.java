package org.intraweb.tools.worksheet.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.IOUtils;
import org.intraweb.tools.worksheet.service.DataFetchService;
import org.intraweb.tools.worksheet.service.DprBasedPasFileRelationService;
import org.intraweb.tools.worksheet.service.GitFileSearch;
import org.intraweb.tools.worksheet.service.HierarchyClassifierService;
import org.intraweb.tools.worksheet.service.NonFormPasFileClassificationService;
import org.intraweb.tools.worksheet.service.PasFileClassificationService;
import org.intraweb.tools.worksheet.service.RedmineOperationsService;
import org.intraweb.tools.worksheet.service.WorksheetDetailService;
import org.intraweb.tools.worksheet.service.WorksheetLayoutFillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.taskadapter.redmineapi.RedmineException;

@RestController
@RequestMapping("worksheet/")
public class WorksheetDetailController {

	@Autowired
	private WorksheetDetailService worksheetService;

	@Autowired
	private PasFileClassificationService pasFileClassifyService;

	@Autowired
	private GitFileSearch gitFileSearch;

	@Autowired
	private DataFetchService dataFetchService;

	@Autowired
	private WorksheetLayoutFillService layoutFillService;

	@Autowired
	private HierarchyClassifierService hierarchyClassifierService;

	@Autowired
	private RedmineOperationsService redmineOperationsService;
	
	@Autowired
	private DprBasedPasFileRelationService dprBasedPasFileRelationService;


	@Autowired
	private NonFormPasFileClassificationService nonFormPasFileClassifyService;
	
	
	@GetMapping("save/dpr/summary")
	public void storeDprSummaryInfo() throws IOException {
		worksheetService.storeDprSummaryInfo();
	}

	@GetMapping("save/worksheet/path")
	public void storeWorksheetPath() throws IOException {
		worksheetService.storeWorksheetPath();
	}

	@GetMapping("save/pas/details")
	public void persistPasInfo() throws EncryptedDocumentException, InvalidFormatException, IOException {
		pasFileClassifyService.worksheetService();
	}
	
	@GetMapping("save/nonpas/details")
	public void persistNonPasInfo() throws EncryptedDocumentException, InvalidFormatException, IOException {
		nonFormPasFileClassifyService.worksheetService();
	}

	@GetMapping("/write/pas/files")
	public void writeFiles() throws IOException {
		dataFetchService.getPasFileTarget();
	}

	//	@GetMapping("/git/file/get")
	//	@CrossOrigin(origins="http://localhost:9090")
	//	public void findFilesInGitGet() throws IOException, InvalidFormatException {
	//		gitFileSearch.searchFilesInRepo();
	//	}

	@PostMapping("/git/file/finder")
	@CrossOrigin
	public List<List<String>> findFilesInGit(@RequestParam("file") MultipartFile[] uploadFiles,HttpServletResponse response) throws IOException, InvalidFormatException {
		return gitFileSearch.searchFilesInRepo(uploadFiles[0]);
	}

	@CrossOrigin
	@PostMapping("auto/fill")
	public void findLayoutTypePattern(@RequestParam("file") MultipartFile uploadFiles, HttpServletResponse response) throws Exception {
		//	@RequestParam("file") MultipartFile[] uploadFiles,
		File file = layoutFillService.fillTypePattern(uploadFiles);
		//	File file = layoutFillService.fillTypePattern();
		InputStream inputStream = new FileInputStream(file);       
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename="+file.getName()); 
		IOUtils.copy(inputStream, response.getOutputStream());
		response.flushBuffer();
		inputStream.close();
		FileUtils.deleteQuietly(file);
	}

	@GetMapping("download/file")
	public void persistSuggestPluginData(HttpServletResponse response) throws IOException {
		File fileToDownload = new File("C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-document\\30_Worksheet\\10_template\\CAM\\Worksheet_AroFaPatReference_20190214.xls");
		InputStream inputStream = new FileInputStream(fileToDownload);       
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename="+"fileName"+".xls"); 
		IOUtils.copy(inputStream, response.getOutputStream());
		response.flushBuffer();
		inputStream.close();
	}

	@PostMapping("/analyze/pas/hierarchy")
	public void classifyHierarchy() throws IOException, InvalidFormatException {
		hierarchyClassifierService.findAllDprHierachy();
	}

	@PostMapping("/analyze/test/pas/hierarchy")
	public void classifyTestHierarchy(@RequestParam("file") MultipartFile uploadFile) throws IOException, InvalidFormatException {
		File x = hierarchyClassifierService.multipartToFile(uploadFile);
		hierarchyClassifierService.hierarchyByDpr(x, "camform");
	}

	@PostMapping("/redmine/insert")
	public void redmineInsert() throws RedmineException  {
		redmineOperationsService.writeRedmineToMongoDB();
	}

	@PostMapping("/redmine/update")
	public void redmineUpdate() {
		redmineOperationsService.updateEntitiesRedmine();
	}

	@GetMapping("relation/service")
	public void executeRelationService()  {
		dprBasedPasFileRelationService.execute();
	}
	
	@GetMapping("pasfile/parent/child/relation/service")
	public void executePasFileParentChildRelation()  {
		dprBasedPasFileRelationService.executePasFileParentChildRelation();
	}
	
}
