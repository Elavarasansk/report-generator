package org.intraweb.tools.worksheet.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.intraweb.tools.worksheet.entity.DprAssignmentOrder;
import org.intraweb.tools.worksheet.entity.WorksheetLocalPath;
import org.intraweb.tools.worksheet.repository.interfaces.DprAssignmentOrderRepo;
import org.intraweb.tools.worksheet.repository.interfaces.WorksheetLocalPathRepo;
import org.intraweb.tools.worksheet.utility.FileReadWriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WorksheetDetailService {

	@Autowired
	private FileReadWriteService fileReaderService;

	@Autowired
	private DprAssignmentOrderRepo dprAssignmentOrderRepo;

	@Autowired
	private WorksheetLocalPathRepo worksheetLocalPathRepo;

	@Value("${worksheet.directory}")
	private String worksheetsPath;

	@Value("${assignment.dpr.order}")
	private String assigneDprListFile;

	List<File> allWorksheetList = new ArrayList<File>();

	public void storeDprSummaryInfo()  throws IOException {
		List<List<String>> dprPathList = getDprAssignmentInfo();
		List<DprAssignmentOrder> dprAssignmentOrderList = new ArrayList<>();

		for(List<String> dprInfo : dprPathList) {
			DprAssignmentOrder dprOrderDto = DprAssignmentOrder.builder()
					.dprName(dprInfo.get(0).replace(".dpr", ""))
					.priority(dprInfo.get(1))
					.moduleName(dprInfo.get(2)!=null? dprInfo.get(2): "")
					.module(dprInfo.get(3)!=null? dprInfo.get(3): "")
					.dprPath(dprInfo.get(4)!=null? dprInfo.get(4): "")
					.complexity(dprInfo.size()>5? dprInfo.get(5): "")
					.lableader(dprInfo.size()>5? dprInfo.get(6): "")
					.assignee(dprInfo.size()>5? dprInfo.get(7): "")
					.build();
			dprAssignmentOrderList.add(dprOrderDto);
		}
		dprAssignmentOrderRepo.deleteAll();
		dprAssignmentOrderRepo.saveAll(dprAssignmentOrderList);
		System.out.println(dprAssignmentOrderRepo.findAll());
	}

	public void storeWorksheetPath()  throws IOException {
		retreiveAllWorksheetLists(worksheetsPath);
		persistWorksheetPath();
	}

	private void persistWorksheetPath() {
		List<WorksheetLocalPath> worksheetPathList = new ArrayList<>();

		for(File sheet:allWorksheetList) {
			log.info(sheet.getName());
			String[] worksheetName = sheet.getName().split("Worksheet_");
			
			if(worksheetName.length == 1) {
				continue;
			}
			
			String dprName = worksheetName[1];
			int x = dprName.lastIndexOf('_');
			WorksheetLocalPath worksheetLocalPath = WorksheetLocalPath.builder()
					.dprName(dprName.substring(0, x))
					.worksheetPath(sheet.getAbsolutePath())
					.build();
			worksheetPathList.add(worksheetLocalPath);
		}
		worksheetLocalPathRepo.deleteAll();
		worksheetLocalPathRepo.saveAll(worksheetPathList);
	}

	private void retreiveAllWorksheetLists(String worksheetDirPath) {
		File worksheetDirectory = new File(worksheetDirPath);
		File[] fileList = worksheetDirectory.listFiles();

		for(File worksFile:fileList) {
			boolean isDir = worksFile.isDirectory();
			boolean isFile = worksFile.isFile();
			if(isFile) {
				allWorksheetList.add(worksFile);
			} else if(isDir) {
				retreiveAllWorksheetLists(worksFile.getAbsolutePath());
			}
		}
	}

	private List<List<String>> getDprAssignmentInfo() throws IOException {
		return fileReaderService.readResourcePathCsvFile(assigneDprListFile);
	}

}
