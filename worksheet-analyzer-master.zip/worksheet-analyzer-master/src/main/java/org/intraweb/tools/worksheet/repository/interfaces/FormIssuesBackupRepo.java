package org.intraweb.tools.worksheet.repository.interfaces;

import java.util.List;

import org.intraweb.tools.worksheet.entity.FormIssues;
import org.intraweb.tools.worksheet.entity.FormIssuesBackup;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FormIssuesBackupRepo extends MongoRepository<FormIssuesBackup, String>{
	
	public FormIssuesBackupRepo findByIssueId(int issueId);
	
	public List<FormIssues> findAllBySubject(List<String> subjectList);
	
}
