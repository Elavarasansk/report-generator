package org.intraweb.tools.worksheet.service.autocheckservice;

import java.io.File;
import java.io.IOException;

import org.intraweb.tools.worksheet.utility.autocheck.parser.DFMParser;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AutoCheckService {

	public File dispatchAutoCheck(MultipartFile uploadFiles) {
		try {
			File file = multipartToFile(uploadFiles);
			DFMParser dfmParser = new DFMParser();
			return dfmParser.execAutoCheck(file,file.getCanonicalFile().getName());
		} catch (IllegalStateException | IOException e) {
			log.error("[ERROR]"+e.getMessage());	
		}
		return null;
	}



	public File multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException {
		String fileName = multipart.getOriginalFilename();
		log.info("Multipart File Worksheet " + fileName);
		File convFile = new File(System.getProperty("java.io.tmpdir") + "/" + fileName);
		multipart.transferTo(convFile);
		return convFile;
	}

}
