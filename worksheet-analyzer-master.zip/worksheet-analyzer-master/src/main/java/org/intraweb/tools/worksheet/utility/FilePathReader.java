package org.intraweb.tools.worksheet.utility;

public class FilePathReader {	
	
	/**
	 * getProductPath method return the repository path in local machine
	 * 
	 * @param dprPath
	 * @return resultPath
	 */
	public static String getProductPath(String dprPath) {
		String resultPath = new String();
		if(dprPath.contains("\\")) {
			String product = dprPath.substring(0, dprPath.indexOf("\\")).toLowerCase();
			if(product.equalsIgnoreCase("share") || product.equalsIgnoreCase("accommon") || product.equalsIgnoreCase("common")) {
				product = "cac";
			}
			String productName = "hue-ac-chennai-" + product;
			resultPath = "C:\\HUE\\Workspace\\Develop\\" + productName + "\\company_client\\delphi\\";
		}
		return resultPath;
	}

}
