package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.DprBasedPasFileHierarchy;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DprbasedPasFileHierarchyRepo extends MongoRepository<DprBasedPasFileHierarchy, String>{

	boolean existsByDprName(String dprName);

	void deleteByDprName(String dprName);
	
	DprBasedPasFileHierarchy findByDprName(String dprName);
	
}
