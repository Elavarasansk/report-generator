package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.InquiryIssues;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InquiryIssuesRepo extends MongoRepository<InquiryIssues, String>  {
	
	public InquiryIssues findByIssueId(int issueId);

}
