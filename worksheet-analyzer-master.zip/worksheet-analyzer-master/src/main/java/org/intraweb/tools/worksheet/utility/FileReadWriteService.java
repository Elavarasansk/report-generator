package org.intraweb.tools.worksheet.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.tomcat.util.buf.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

@Service
public class FileReadWriteService{
	
	public List<List<String>> readResourcePathCsvFile(String resourcePathFile) throws IOException {
		File file = ResourceUtils.getFile("classpath:" + resourcePathFile);
		return readCsvFile(file.getAbsolutePath());
	}
	
	public List<List<String>> readCsvFile(String filePath) throws IOException {
		List<List<String>> parsedDataList = new ArrayList<List<String>>();

		File heirarchyCsvFile = new File(filePath);

		boolean isSummaryFile = heirarchyCsvFile.isFile();

		if(isSummaryFile){
			BufferedReader buffer = new BufferedReader(new FileReader(heirarchyCsvFile));

			String currentLine = null;
			while((currentLine = buffer.readLine()) != null) {
				if(currentLine.isEmpty()) {
					continue;
				}
				List<String> rowDataList = Arrays.asList(currentLine.split(Constants.COMMA));
				parsedDataList.add(rowDataList);
			}
			buffer.close();
		}
		return parsedDataList;
	}
	
	public void writeToCsvFile(String filePath, String fileName, List<List<String>> rows) throws IOException {
		File file = new File(filePath + fileName + Constants.CSV_FILE);
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		if (!file.exists()) {
			file.createNewFile();
		}
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

		for (List<String> row : rows) {
			pw.print(StringUtils.join(row,',') + ",");
			pw.println();
		}
		pw.close();
	}

}