package org.intraweb.tools.worksheet.dto;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="form_control")
public class FormControlDto{
	@Id
	private ObjectId id;
	
	String formName;
	
	String type;
	List<String> sharedDprs;
	int redmineId;
	String cortexId;
	String redminestatus;
	String cortexstatus;
	String gittype;
	String gitmergestatus;
	String redmineassignee;
	String targetdpr;
	String enddate;
}