package org.intraweb.tools.worksheet.entity.aligner;




import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Hello world!
 *
 */
public class DFMObject {

    private String name;

    private String className;

    private DFMObject parent;

    private List<DFMObject> child;

    private Map<String, DFMData> data;

    public DFMObject() {
        child = new LinkedList<>();
    }

    /**
     * getParent method is the getter for parent
     *
     * @return parent
     */
    public DFMObject getParent() {
        return parent;
    }

    /**
     * setParent method is the setter for parent
     *
     * @param parent
     */
    public void setParent(DFMObject parent) {
        this.parent = parent;
    }

    /**
     * getData method is the getter for data
     *
     * @return data
     */
    public Map<String, DFMData> getData() {
        return data;
    }

    /**
     * setData method is the setter for data
     *
     * @param data
     */
    public void setData(Map<String, DFMData> data) {
        this.data = data;
    }

    /**
     * getClassName method is the getter for className
     *
     * @return className
     */
    public String getClassName() {
        return className;
    }

    /**
     * setClassName method is the setter for className
     *
     * @param className
     */
    public void setClassName(String className) {
        this.className = className;
    }

    /**
     * getName method is the getter for name
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * setName method is the setter for name
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * setData method is used for
     * 
     * @param keyValue
     */
    public void setData(String[] keyValue) {
        if (data == null) {
            data = new LinkedHashMap<>();
        }
        data.put(keyValue[0], new DFMData(keyValue[1]));
    }

    public List<DFMObject> getChild() {
        return child;
    }

    public void setChild(DFMObject child) {
        if (this.child == null) {
            this.child = new LinkedList<>();
        }
        this.child.add(child);
    }

    public String getCaption() {
        AtomicReference<String> val = new AtomicReference<>();
        if (this.getData() != null) {
            this.getData().forEach((k, v) -> {
                if (k.trim().equals("Caption")) {
                    val.set(v.getData().toString());
                }
            });
        }
        return val.get();
    }

}
