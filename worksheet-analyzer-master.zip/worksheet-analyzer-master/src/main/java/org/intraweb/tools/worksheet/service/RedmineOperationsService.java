package org.intraweb.tools.worksheet.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.entity.FormIssues;
import org.intraweb.tools.worksheet.entity.FormIssuesBackup;
import org.intraweb.tools.worksheet.entity.RedmineRecordForPasFileEntity;
import org.intraweb.tools.worksheet.repository.interfaces.EpicIssuesRepo;
import org.intraweb.tools.worksheet.repository.interfaces.FormIssuesBackupRepo;
import org.intraweb.tools.worksheet.repository.interfaces.FormIssuesRepo;
import org.intraweb.tools.worksheet.repository.interfaces.InquiryIssuesRepo;
import org.intraweb.tools.worksheet.repository.interfaces.MongoDataService;
import org.intraweb.tools.worksheet.repository.interfaces.SocialPluginIssuesRepo;
import org.intraweb.tools.worksheet.repository.interfaces.SuggestPluginIssuesRepo;
import org.intraweb.tools.worksheet.repository.interfaces.TaskIssuesRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.taskadapter.redmineapi.IssueManager;
import com.taskadapter.redmineapi.RedmineException;
import com.taskadapter.redmineapi.RedmineManager;
import com.taskadapter.redmineapi.RedmineManagerFactory;
import com.taskadapter.redmineapi.bean.Issue;
import com.taskadapter.redmineapi.internal.ResultsWrapper;

@Service
public class RedmineOperationsService {

	@Autowired
	private EpicIssuesRepo epicIssuesRepo;

	@Autowired
	private FormIssuesRepo formIssuesRepo;
	
	@Autowired
	private InquiryIssuesRepo inquiryIssuesRepo;
	
	@Autowired
	private SocialPluginIssuesRepo socialPluginIssuesRepo;
	
	@Autowired
	private SuggestPluginIssuesRepo suggestPluginIssuesRepo;
	
	@Autowired
	private TaskIssuesRepo taskIssuesRepo;
	
	@Autowired
	private FormIssuesBackupRepo formIssuesBackupRepo;
	
	@Autowired
	MongoDataService mongoDataService;

	@Value("${redmine.url}")
	private String redmineUrl;

	@Value("${redmine.user.name}")
	private String redmineUserName;

	@Value("${redmine.user.password}")
	private String redminePassowrd;

	private static RedmineManager redmineManager;

	private static IssueManager issueManager;

	@PostConstruct
	public void configureRedmine() {
		redmineManager  = RedmineManagerFactory.createWithUserAuth(redmineUrl, redmineUserName, redminePassowrd);
		issueManager = redmineManager.getIssueManager();
	}
	
	//Inserts all data from Redmine to Mongo DB
	public void writeRedmineToMongoDB() throws RedmineException {
		
		//		List<EpicIssues> epicIssuesList = new ArrayList<>();
		//		List<FormIssuesBackup> formIssuesBackupList = new ArrayList<>();
		//		List<InquiryIssues> inquiryIssuesList = new ArrayList<>();
		//		List<SocialPluginIssues> socialPluginIssuesList = new ArrayList<>();
		//		List<SuggestPluginIssues> suggestPluginIssuesList = new ArrayList<>();
		//		List<TaskIssues> taskIssuesList = new ArrayList<>();

		//		List<Issue> epicIssues = issueManager.getIssues("196", 443);
		//		epicIssues.stream().forEach(l -> {
		//			epicIssuesList.add(EpicIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//					.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//		});
		//		epicIssuesRepo.saveAll(epicIssuesList);

		/** To insert all form data into FormIssuesBackup */
		
		formIssuesBackupRepo.deleteAll();
		insertRedmineToDBOperation(83790, 106565);
		insertRedmineToDBOperation(129630, 129635);
		insertRedmineToDBOperation(130045, 130200);
		
		System.out.println("DONE...");
		
		// 
		
		//		List<Integer> failIssuesList = new ArrayList<>();
		//		formIssuesBackupRepo.deleteAll();
		//		for(int c = 83790; c < 106565; c++) {
		//			Integer failIssue = new Integer(0);
		//			try {
		//				System.out.println(c);
		//				failIssue = c;
		//				Issue l = issueManager.getIssueById(c);
		//				if(l.getTracker().getName().equalsIgnoreCase("form")) {
		//					formIssuesBackupList.add(FormIssuesBackup.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//					.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//				}
		//			} catch(Exception e) {
		//				e.printStackTrace();
		//				failIssuesList.add(failIssue);
		//				continue;
		//			}
		//			if(formIssuesBackupList.size() > 0 && formIssuesBackupList.size() % 800 == 0) {
		//				formIssuesBackupRepo.saveAll(formIssuesBackupList);
		//				formIssuesBackupList.clear();
		//			}
		//		}
		//		if(!formIssuesBackupList.isEmpty()) {
		//			formIssuesBackupRepo.saveAll(formIssuesBackupList);
		//		}
		//		if(!failIssuesList.isEmpty()) {
		//			reexecuteFailedformIssuesBackupRepo(failIssuesList);
		//		}

		//		List<Issue> inquiryIssues = issueManager.getIssues("196", 448);
		//		inquiryIssues.stream().forEach(l -> {
		//			inquiryIssuesList.add(InquiryIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//					.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//		});
		//		inquiryIssuesRepo.saveAll(inquiryIssuesList);
		//		
		//		List<Issue> socialPluginIssues = issueManager.getIssues("196", 447);
		//		socialPluginIssues.stream().forEach(l -> {
		//			socialPluginIssuesList.add(SocialPluginIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//					.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//		});
		//		socialPluginIssuesRepo.saveAll(socialPluginIssuesList);
		//		
		//		List<Issue> suggestPluginIssues = issueManager.getIssues("196", 446);
		//		suggestPluginIssues.stream().forEach(l -> {
		//			suggestPluginIssuesList.add(SuggestPluginIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//					.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//		});
		//		suggestPluginIssuesRepo.saveAll(suggestPluginIssuesList);
		//		
		//		List<Issue> taskIssues = issueManager.getIssues("196", 444);
		//		taskIssues.stream().forEach(l -> {
		//			taskIssuesList.add(TaskIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//					.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//		});
		//		taskIssuesRepo.saveAll(taskIssuesList);

	}
	
	//Updates existing issues in Mongo DB
	public void updateEntitiesRedmine() {

		//		List<EpicIssues> epicIssuesList = epicIssuesRepo.findAll();
		//		epicIssuesList.stream().forEach(issue -> {
		//			epicIssuesRepo.save(epicIssuesRepo.findByIssueId(issue.getIssueId()));
		//		});

		/** To move entries of FormIssuesBackup collection to FormIssues collection */

		List<FormIssuesBackup> formIssuesBackupList = formIssuesBackupRepo.findAll();
		formIssuesRepo.deleteAll();
		List<FormIssues> formIssuesList = new ArrayList<FormIssues>();
		formIssuesBackupList.stream().forEach(l -> {
			FormIssues fm = FormIssues.builder().build();
			BeanUtils.copyProperties(l, fm);
			formIssuesList.add(fm);
		});
		if(!formIssuesList.isEmpty()) {
			formIssuesRepo.saveAll(formIssuesList);
		}

		/** To move entries of FormIssues collection to FormIssuesBackup collection */

		//		List<FormIssues> formIssuesList = formIssuesRepo.findAll();
		//		List<FormIssuesBackup> formIssuesBackupList = new ArrayList<FormIssuesBackup>();
		//		formIssuesList.stream().forEach(l -> {
		//			FormIssuesBackup fm = FormIssuesBackup.builder().build();
		//			BeanUtils.copyProperties(l, fm);
		//			formIssuesBackupList.add(fm);
		//		});
		//		if(!formIssuesBackupList.isEmpty()) {
		//			formIssuesBackupRepo.saveAll(formIssuesBackupList);
		//		}

		/** To update the DB entries from redmine */

		//		List<FormIssues> formIssuesList = formIssuesRepo.findAll();
		//		formIssuesRepo.deleteAll();
		//		List<Integer> failedIssuesList = new ArrayList<>();
		//		for(FormIssues fe:formIssuesList) {
		//			Integer failedIssueId = new Integer(0);
		//			try {
		//				failedIssueId = fe.getIssueId();
		//				Issue l= issueManager.getIssueById(fe.getIssueId());
		//				formIssuesRepo.save(FormIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
		//						.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
		//			} catch (Exception e) {
		//				// TODO Auto-generated catch block
		//				failedIssuesList.add(failedIssueId);
		//				e.printStackTrace();
		//			}
		//		}
		//		if(!failedIssuesList.isEmpty()) {
		//			reexecuteFailed(failedIssuesList);
		//		}

		//		List<InquiryIssues> inquiryIssuesList = inquiryIssuesRepo.findAll();
		//		inquiryIssuesList.stream().forEach(issue -> {
		//			inquiryIssuesRepo.save(inquiryIssuesRepo.findByIssueId(issue.getIssueId()));
		//		});
		//		
		//		List<SocialPluginIssues> socialPluginIssuesList = socialPluginIssuesRepo.findAll();
		//		socialPluginIssuesList.stream().forEach(issue -> {
		//			socialPluginIssuesRepo.save(socialPluginIssuesRepo.findByIssueId(issue.getIssueId()));
		//		});
		//		
		//		List<SuggestPluginIssues> suggestPluginIssuesList = suggestPluginIssuesRepo.findAll();
		//		suggestPluginIssuesList.stream().forEach(issue -> {
		//			suggestPluginIssuesRepo.save(suggestPluginIssuesRepo.findByIssueId(issue.getIssueId()));
		//		});
		//		
		//		List<TaskIssues> taskIssuesList = taskIssuesRepo.findAll();
		//		taskIssuesList.stream().forEach(issue -> {
		//			taskIssuesRepo.save(taskIssuesRepo.findByIssueId(issue.getIssueId()));
		//		});
	}
	
	public  Map<String, FormIssues> getDetails(List<String> pasFileUrlList) throws RedmineException {
		List<FormIssues> formIssueList=mongoDataService.findAllBySubject(pasFileUrlList);
		Map<String,FormIssues> map = new HashMap<>();
		if(CollectionUtils.isEmpty(formIssueList)){
			//TODO	
		}
		formIssueList.stream().forEach(document->{
			if(StringUtils.isNotEmpty(document.getSubject())) {
				map.put(document.getSubject(), document);
			}			
		});	
		return map;
	}


	public static RedmineRecordForPasFileEntity getDetails(String pasFileUrl) throws RedmineException {
		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("subject", pasFileUrl);
		ResultsWrapper<Issue> issueWrapper = issueManager.getIssues(paramMap);
		List<Issue> issueList = issueWrapper.getResults();
		if(issueList.isEmpty()) {
			return RedmineRecordForPasFileEntity.builder().build();
		}
		Optional<Issue> resultIssue = issueList.stream().findFirst();
		if(!resultIssue.isPresent()) {
			return RedmineRecordForPasFileEntity.builder().build(); 
		}
		return RedmineRecordForPasFileEntity.builder().pasFileName(pasFileUrl).assigneeName(resultIssue.get().getAssigneeName())
				.issueId(resultIssue.get().getId()).url("http://ac-conv-redmine.internal.worksap.com/redmine/issues/" + resultIssue.get().getId()).status(resultIssue.get().getStatusName()).build();
	}
	
	public void reexecuteFailed(List<Integer> failedIssuesList) {
		List<Integer> failedSubIssueList = new ArrayList<>();
		for(Integer issue: failedIssuesList) {
			Integer failedSubIssue = new Integer(0);
			try {
				failedSubIssue = issue;
				Issue l = issueManager.getIssueById(issue);
				formIssuesRepo.save(FormIssues.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
						.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
			} catch (Exception e) {
				if(!e.getClass().toString().contains("DuplicateKeyException")) {
					failedSubIssueList.add(failedSubIssue);
				}
				e.printStackTrace();
			}

		}
		if(!failedSubIssueList.isEmpty()) 
			reexecuteFailed(failedSubIssueList);
		else 
			return;
	}


	public void reexecuteFailedformIssuesBackupRepo(List<Integer> failedIssuesList) {
		List<Integer> failedSubIssueList = new ArrayList<>();
		for(Integer issue: failedIssuesList) {
			Integer failedSubIssue = new Integer(0);
			try {
				failedSubIssue = issue;
				Issue l = issueManager.getIssueById(issue);
				formIssuesBackupRepo.save(FormIssuesBackup.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
						.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
			} catch (Exception e) {
				if(!e.getClass().toString().contains("DuplicateKeyException")) {
					failedSubIssueList.add(failedSubIssue);
				}
				e.printStackTrace();
			}
		}
		if(!failedSubIssueList.isEmpty()) 
			reexecuteFailedformIssuesBackupRepo(failedSubIssueList);
		else 
			return;
	}

	private void insertRedmineToDBOperation(int startRange, int endRange) throws RedmineException {
		List<FormIssuesBackup> formIssuesBackupList = new ArrayList<>();
		List<Integer> failIssuesList = new ArrayList<>();
		for(int c = startRange; c < endRange; c++) {
			Integer failIssue = new Integer(0);
			try {
				System.out.println(c);
				failIssue = c;
				Issue l = issueManager.getIssueById(c);
				if(l.getTracker().getName().equalsIgnoreCase("form")) {
					formIssuesBackupList.add(FormIssuesBackup.builder().issueId(l.getId()).status(l.getStatusName()).priority(l.getPriorityText())
							.subject(l.getSubject()).assigneeName(l.getAssigneeName()).startDate(l.getStartDate()).dueDate(l.getDueDate()).build());
				}
			} catch(Exception e) {
				e.printStackTrace();
				failIssuesList.add(failIssue);
				continue;
			}
			if(formIssuesBackupList.size() > 0 && formIssuesBackupList.size() % 800 == 0) {
				formIssuesBackupRepo.saveAll(formIssuesBackupList);
				formIssuesBackupList.clear();
			}
		}
		if(!formIssuesBackupList.isEmpty()) {
			formIssuesBackupRepo.saveAll(formIssuesBackupList);
		}
		if(!failIssuesList.isEmpty()) {
			reexecuteFailedformIssuesBackupRepo(failIssuesList);
		}
	}
}
