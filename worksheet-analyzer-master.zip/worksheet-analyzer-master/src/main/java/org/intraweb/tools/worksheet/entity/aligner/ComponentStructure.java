package org.intraweb.tools.worksheet.entity.aligner;




import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ComponentStructure {
	private String componentId;
	private String componentType;
	private String caption;
	private int left;
	private int top;
	private int width;
	private int height;
}
