package org.intraweb.tools.worksheet.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.buf.StringUtils;
import org.intraweb.tools.worksheet.entity.DprPasFileDetails;
import org.intraweb.tools.worksheet.repository.interfaces.DprPasFileDetailsRepo;
import org.intraweb.tools.worksheet.utility.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DataFetchService {

	@Autowired
	private DprPasFileDetailsRepo dprPasFileDetailsRepo; 

	public void getPasFileTarget() throws IOException {
		List<DprPasFileDetails> pasFileTargetInfo = dprPasFileDetailsRepo.findAll();

		List<String> pasFileRows = new ArrayList<String>();
		
		String header = "DprName,TotalCount,TargetCount,DuplicateCount,AccommonCount";
		pasFileRows.add(header);
		pasFileTargetInfo.forEach(pas -> {
			long totalCount = pas.getTargetCount()+pas.getDuplicateCount()+pas.getAcCommonCount();
			String data = pas.getDprName()+","+totalCount+","+pas.getTargetCount()+","+pas.getDuplicateCount()+","+pas.getAcCommonCount();
			pasFileRows.add(data);
		});
		writeToCsvFile("D:\\ToolFiles", "Summary", pasFileRows);
		
		
		pasFileTargetInfo.forEach(pas -> {
			String dprNamePath = "D:\\ToolFiles\\"+pas.getDprName();
			try {
				log.info("-------------------------->Started writing" + pas.getDprName());
				writeToCsvFile(dprNamePath, "TargetFiles", pas.getTargetPasFiles());
				writeToCsvFile(dprNamePath, "DuplicateFile", pas.getDuplicatePasFiles());
				writeToCsvFile(dprNamePath, "AccommonFiles", pas.getAcCommonFiles());
			}catch(Exception e) {
				e.printStackTrace();
			}
		});

	}
	
	public void writeToCsvFile(String filePath, String fileName, List<String> rows) throws IOException {
		File file = new File(filePath+"\\" + fileName+ Constants.CSV_FILE);
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		if (!file.exists()) {
			file.createNewFile();
		}
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

		for (String row : rows) {
			pw.print(row+ ",");
			pw.println();
		}
		pw.close();
	}


}
