package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.DprPasFileOldWorkSheetDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface DprPasFileOldWorkSheetDetailsRepo extends MongoRepository<DprPasFileOldWorkSheetDetails, String>{

	boolean existsByDprName(String dprName);

	void deleteByDprName(String dprName);
	
}
