package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.dto.FormControlDto;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface  FormControlRepo extends MongoRepository<FormControlDto,String> {
	
}