package org.intraweb.tools.worksheet.utility.worksheet;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.development.CheckListJudgment;
import org.intraweb.tools.worksheet.entity.WorksheetFileListEntity;
import org.intraweb.tools.worksheet.utility.Constants;
import org.intraweb.tools.worksheet.utility.FilePathReader;

import com.google.common.io.Files;

public class LayoutPattern {

	private WorksheetFileListEntity fileListDetails;

	public LayoutPattern(WorksheetFileListEntity fileListDetails) {
		this.fileListDetails = fileListDetails;
	}

	public WorksheetFileListEntity computeLayoutPattern() throws IOException {
		String layoutType = fileListDetails.getLayoutType();
		switch (layoutType) {
			case Constants.DIALOG:
				validateDialogLayoutType();
				break;
			case Constants.MAIN_FRAME:
				validateMainLayoutType();
				break;
			case Constants.PARTS_FRAME:
				fileListDetails.setLayoutPattern(Constants.PARTS_FRAME);
				break;
		}
		return fileListDetails;
	}


	private void validateDialogLayoutType() throws IOException {
		String framework = fileListDetails.getFrameWork();
		
		switch (framework.toLowerCase()) {
			case Constants.TCFW_BASE_PLAIN_DIALOG:
				validateSearchDialog();
				break;
			default:
				CheckListJudgment checkListJudgment= new CheckListJudgment(fileListDetails);
				checkListJudgment.computeLayoutPattern();
				break;
		}
	}

	private void validateSearchDialog() throws IOException {
		boolean isSearchFrame = fileListDetails.getFileName().toLowerCase().contains("search");		
		String pasLocalPath = FilePathReader.getProductPath(fileListDetails.getDprPath()) + fileListDetails.getFilePath();
		File file = new File(pasLocalPath);
		if(file.exists() && !isSearchFrame ) {
			List<String> lineList = Files.readLines(file, Charset.defaultCharset());
			isSearchFrame = lineList.stream()
					.filter(currentLine ->currentLine.contains("Grids"))
					.collect(Collectors.toList()).size() > 0 ;
			
		}
		if(isSearchFrame) {			
			fileListDetails.setLayoutPattern(Constants.SEARCH_DIALOG);
			fileListDetails.setFrameWork(Constants.TCFW_BASE_SEARCH_DIALOG);
		} else {
			CheckListJudgment checkListJudgment= new CheckListJudgment(fileListDetails);
			checkListJudgment.computeLayoutPattern();
		}

	}

	private void validateMainLayoutType() throws IOException {
		String framework = fileListDetails.getFrameWork();
		switch(framework.toLowerCase()) {
			case Constants.TFORM:
			case Constants.TCFW_ROOT_FRAME:
			case Constants.TCFW_DIALOG:
				validateDetailScreen();
				break;

			case Constants.TCFW_BASE_FRAME:
			case Constants.TCFW_BASE_FRAME_EXCOOL:
				validateListScreen();
				break;

			default:
				CheckListJudgment checkListJudgment= new CheckListJudgment(fileListDetails);
				checkListJudgment.computeLayoutPattern();
				break;
		}
	}

	private void validateDetailScreen() {
		String fileName = fileListDetails.getFileName();
		String framework = fileListDetails.getFrameWork();
		//TODO: Read dfm file and check for ok/save/cancel button crud detail page.
		boolean isDetail = fileName.toLowerCase().contains("detail");

		if(!isDetail) {
			CheckListJudgment checkListJudgment= new CheckListJudgment(fileListDetails);
			checkListJudgment.computeLayoutPattern();
			return;
		}

		fileListDetails.setLayoutPattern(Constants.DETAIL_FRAME);
		switch(framework.toLowerCase()) {
			case Constants.TFORM:
			case Constants.TCFW_ROOT_FRAME:
				fileListDetails.setFrameWork(Constants.TCFW_ROOT_DETAIL_FRAME);
				break;
			case Constants.TCFW_DIALOG:
				fileListDetails.setFrameWork(Constants.TCFW_DETAIL_FRAME);
				break;
		}
	}

	private void validateListScreen() throws IOException {
		int gridsCount = 0;
		int searchCondCount = 0;
		int infoGridCount = 0;
		String fileName = fileListDetails.getFileName();
		String framework = fileListDetails.getFrameWork();
		boolean isList = fileName.toLowerCase().contains("search");		
		String pasLocalPath = FilePathReader.getProductPath(fileListDetails.getDprPath()) + fileListDetails.getFilePath();
		File file = new File(pasLocalPath);
		if(file.exists() && !isList) {
			List<String> lineList = Files.readLines(file, Charset.defaultCharset());
			//isList = lineList.stream()
			//	/	.filter(currentLine ->currentLine.contains("Grid") || (currentLine.contains("TListView")))
				//	.collect(Collectors.toList()).size() > 0 ;					
			 gridsCount  = lineList.stream().filter(currentLine -> 
			        StringUtils.contains(currentLine, "TTControlGrid")
			   || StringUtils.contains(currentLine, "TTMultilineControlGrid")
			   ||  StringUtils.contains(currentLine, "TWAStringGrid0")
			   ||  StringUtils.contains(currentLine, "TDrawGrid")
			   ||  StringUtils.contains(currentLine, "TStringGrid")
			   || StringUtils.contains(currentLine,"TListView")) //TODO exclude from grids count when judgement wrong.
			.filter( currentLine->currentLine.contains(":"))
			.collect(Collectors.toList()).size();
			
			searchCondCount = lineList.stream().filter(currentLine-> StringUtils.contains(currentLine, "TVisualButtonNeo"))
			.filter(currentLine-> currentLine.contains(":") && StringUtils.containsIgnoreCase(currentLine, "search")).collect(Collectors.toList()).size();	
		
			infoGridCount = lineList.stream().filter(currentLine-> StringUtils.contains(currentLine, "infoGrid")).collect(Collectors.toList()).size();
		}
		
		
		if( !(gridsCount > 0 && searchCondCount > 0) && !(infoGridCount > 0) && !(isList) ) {
			CheckListJudgment checkListJudgment= new CheckListJudgment(fileListDetails);
			checkListJudgment.computeLayoutPattern();
			return;
		}

		fileListDetails.setLayoutPattern(Constants.LIST_FRAME);
		switch(framework.toLowerCase()) {
			case Constants.TCFW_BASE_FRAME:
				fileListDetails.setFrameWork(Constants.TCFW_BASE_LIST_FRAME);
				break;
			case Constants.TCFW_BASE_FRAME_EXCOOL:
				fileListDetails.setFrameWork(Constants.TCFW_BASE_LIST_FRAME_EXCOOL);
				break;
		}
	}

}
