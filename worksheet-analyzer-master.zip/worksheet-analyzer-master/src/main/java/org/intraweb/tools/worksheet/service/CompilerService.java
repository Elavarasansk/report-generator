package org.intraweb.tools.worksheet.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.entity.CompileResultEntity;
import org.intraweb.tools.worksheet.entity.CompileStatusEntity;
import org.intraweb.tools.worksheet.entity.CompilerDetails;
import org.intraweb.tools.worksheet.entity.DprAssignmentOrder;
import org.intraweb.tools.worksheet.repository.interfaces.CompilerRepo;
import org.intraweb.tools.worksheet.repository.interfaces.MongoDataService;
import org.intraweb.tools.worksheet.utility.compiler.CompilerConstants;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CompilerService {



	private static final String ERROR = "Error:";	
	private static final String HINT = "Hint:";	
	private static final String FATAL = "Fatal:";
	private static final String WARNING = "Warning:";
	private static final String AC_GIT = "AC_GIT";	
	private static final String AC_SVN40 = "AC_SVN40";
	private static final String AC_SVN41 = "AC_SVN41";
	private static final String DPR = ".dpr";
	private static final String OPTION = "-I";
	private static final String COMPILER = "dcc32";
	private static final String SPLIT = ";";




	@Autowired
	private MongoDataService mongoDataService;

	@Autowired
	private CompilerRepo compilerRepo;


	public CompileResultEntity executeDprFromGit(String dprName,String module,String versionControl) {	
		String execDprName = FilenameUtils.isExtension(dprName, DPR.replace(".", "")) ? dprName : dprName.concat(DPR) ;
		DprAssignmentOrder dprDetails = mongoDataService.getDprDetails(dprName.replace(DPR, ""), module);
		if(Objects.isNull(dprDetails)) {
			CompileResultEntity result =  formCompileResult(Arrays.asList("File Not Found"),execDprName,"",module);
			result.setCompiledList("File Not Found");
			result.setStatus(false);
			return result;
		}
		String dprPath = formGitFilePath(dprDetails.getDprPath(), dprDetails.getModule());
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			Date compilerStartTime = new Date();
			processBuilder.directory(new File(dprPath));
			String pathList  = CompilerConstants.GIT_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),OPTION,execDprName);
			processBuilder.redirectErrorStream(true);
			p =processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
			Date compilerEndTime = new Date();
			//TODO need fix
			//insertCompilerExec(execDprName, dprPath, module, versionControl, linesList, compilerStartTime, compilerEndTime);
			return formCompileResult(linesList,execDprName,dprPath,module);
		} catch (IOException e) {	
			log.error("Exception occured while processing :",e.getMessage());
			CompileResultEntity result =  formCompileResult(Arrays.asList(e.getMessage()),execDprName,dprPath,module);
			result.setCompiledList(e.getMessage());
			result.setStatus(false);
			return result;

		}finally {
			//p.destroy();
		}

	}



	public CompileResultEntity executeDprFromSvn(String dprName,String module,String versionControl) {
		String execDprName = FilenameUtils.isExtension(dprName, DPR.replace(".", "")) ? dprName : dprName.concat(DPR) ;
		DprAssignmentOrder dprDetails = mongoDataService.getDprDetails(dprName.replace(DPR, ""), module);
		if(Objects.isNull(dprDetails)) {
			CompileResultEntity result =  formCompileResult(Arrays.asList("File Not Found"),execDprName,"",module);
			result.setCompiledList("File Not Found");
			result.setStatus(false);
			return result;
		}
		String dprPath = formSVNFilePath(dprDetails.getDprPath(), dprDetails.getModule(),versionControl);
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		String pathList = StringUtils.EMPTY;
		switch(versionControl) {
		case AC_SVN40:
			pathList = CompilerConstants.SVN40_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
			break;
		case AC_SVN41:
			pathList = CompilerConstants.SVN41_COMPILER_LIBRARY_LIST.stream().collect(Collectors.joining(SPLIT));
			break;
		}
		try {
			Date compilerStartTime = new Date();
			processBuilder.directory(new File(dprPath));
			processBuilder.command(COMPILER,"-u".concat(pathList),"-r".concat(pathList),OPTION,execDprName);
			processBuilder.redirectErrorStream(true);
			p =processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
			Date compilerEndTime = new Date();
			//TODO need fix
			//insertCompilerExec(execDprName, dprPath, module, versionControl, linesList, compilerStartTime, compilerEndTime);
			return formCompileResult(linesList,execDprName,dprPath,module);
		} catch (IOException e) {	
			log.error("Exception occured while processing :",e.getMessage());
			CompileResultEntity result =  formCompileResult(Arrays.asList(e.getMessage()),execDprName,dprPath,module);
			result.setCompiledList(e.getMessage());
			result.setStatus(false);
			return result;

		}finally {
			//p.destroy();
		}
	}


	public void insertCompilerExec(String dprName,String dprPath,String module,String versionControl,List<String> linesList,Date compilerStartTime,Date compilerEndTime) {

		CompileStatusEntity  compilerEntity=compilerRepo.findByDprName(dprName);
		List<CompilerDetails> resultList = Arrays.asList(CompilerDetails.builder().compilerEndTime(compilerEndTime).compilerStartTime(compilerStartTime).linesList(linesList).build());
		CompileStatusEntity entity = CompileStatusEntity.builder()
				.dprName(dprName)
				.dprPath(dprPath)
				.module(module).build();
		if(Objects.nonNull(compilerEntity)) {
			BeanUtils.copyProperties(compilerEntity, entity);
		}
		switch(versionControl.toUpperCase()) {
		case AC_GIT:
			List<CompilerDetails> gitList = CollectionUtils.isNotEmpty(entity.getGitList()) ? entity.getGitList() : new ArrayList<>();
			gitList.addAll(resultList);
			entity.setGitList(gitList);
			break;
		case AC_SVN40:
			List<CompilerDetails> svn40List =  CollectionUtils.isNotEmpty(entity.getSvn40List()) ? entity.getSvn40List() : new ArrayList<>();
			svn40List.addAll(resultList);
			entity.setSvn40List(svn40List);
			break;
		case AC_SVN41:
			List<CompilerDetails> svn41List =  CollectionUtils.isNotEmpty(entity.getSvn41List()) ? entity.getSvn41List() : new ArrayList<>();
			svn41List.addAll(resultList);
			entity.setSvn40List(svn41List);
			break;
		default:
			break;
		}
		compilerRepo.save(entity);
	}



	public CompileResultEntity formCompileResult(List<String> linesList,String dprName,String dprPath,String module) {
		List<String> errorList = new ArrayList<>();			
		List<String> fatalList =  new ArrayList<>();		
		List<String> hintList =  new ArrayList<>();					
		List<String> warningList =  new ArrayList<>();		
		StringBuilder compiledList = new StringBuilder();
		Collections.reverse(linesList);
		linesList.stream().forEach(lne->{
			compiledList.append(lne);
			compiledList.append("\n");
			if(StringUtils.isNotEmpty(lne)){
				if(StringUtils.contains(lne, FATAL)){
					fatalList.add(lne);
				}else if(StringUtils.contains(lne, ERROR)) {
					errorList.add(lne);
				}else if(StringUtils.contains(lne, WARNING)) {
					warningList.add(lne);
				}else if(StringUtils.contains(lne, HINT)) {
					hintList.add(lne);

				}
			}			
		});		
		return CompileResultEntity
				.builder()
				.dprName(dprName)
				.dprPath(dprPath)
				.module(module)
				.fatalList(fatalList)
				.errorList(errorList)
				.warningList(warningList)
				.hintList(hintList)
				.compiledList(compiledList.toString())
				.status(fatalList.isEmpty() && errorList.isEmpty() )
				.build();

	}


	public String formSVNFilePath(String dprPath,String module, String versionControl) { 
		String formSvnFilePath = "\\C:\\HUE\\WorkSpace\\Develop\\SVN\\V";
		String svnNum = "40";
		if(versionControl.equals(AC_SVN41)) {
			svnNum = "41";
		}	
		svnNum+="\\";
		if(module.toLowerCase().startsWith("cam")) {
			formSvnFilePath += svnNum+"CAM"+svnNum+"\\";
		} else if(module.toLowerCase().startsWith("cbm")) {
			formSvnFilePath += svnNum+"CBM"+svnNum+"\\";
		} else if(module.toLowerCase().startsWith("ccm")) {
			formSvnFilePath += svnNum+"CCM"+svnNum+"\\";
		} else if(module.toLowerCase().startsWith("cfm")) {
			formSvnFilePath += svnNum+"CFM"+svnNum+"\\";
		} else if(module.toLowerCase().startsWith("share") || module.toLowerCase().startsWith("common")) {
			formSvnFilePath += svnNum+"COM"+svnNum+"\\";
		}

		String replacePath = dprPath.replace("/", "\\");
		formSvnFilePath += "hue_client\\delphi\\"+replacePath;
		return FilenameUtils.getPath(formSvnFilePath);


	}



	public String formGitFilePath(String dprPath,String module) { 
		String searchPath = "\\C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-";		
		if(module.toLowerCase().startsWith("cam")) {
			searchPath += "cam\\";
		} else if(module.toLowerCase().startsWith("cbm")) {
			searchPath += "cbm\\";
		} else if(module.toLowerCase().startsWith("ccm")) {
			searchPath += "ccm\\";
		} else if(module.toLowerCase().startsWith("cfm")) {
			searchPath += "cfm\\";
		} else if(module.toLowerCase().startsWith("share") || module.toLowerCase().startsWith("common")) {
			searchPath += "cac\\";
		}
		String replacePath = dprPath.replace("/", "\\");
		searchPath += "hue_client\\delphi\\"+replacePath;
		return FilenameUtils.getPath(searchPath);
	}


}
