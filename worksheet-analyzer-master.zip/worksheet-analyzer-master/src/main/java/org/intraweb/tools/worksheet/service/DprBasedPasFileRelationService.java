package org.intraweb.tools.worksheet.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.entity.DprBasedPasFileHierarchy;
import org.intraweb.tools.worksheet.entity.DprBasedPasFileRelation;
import org.intraweb.tools.worksheet.entity.FormParentChildRelationEntity;
import org.intraweb.tools.worksheet.entity.PasFileHierarchy;
import org.intraweb.tools.worksheet.repository.interfaces.DprBasedPasFileRelationRepo;
import org.intraweb.tools.worksheet.repository.interfaces.DprbasedPasFileHierarchyRepo;
import org.intraweb.tools.worksheet.repository.interfaces.FormParentChildRelationRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DprBasedPasFileRelationService {

	@Autowired
	private DprBasedPasFileRelationRepo dprBasedPasFileRelationRepo;


	@Autowired
	private DprbasedPasFileHierarchyRepo dprbasedPasFileHierarchyRepo;


	@Autowired
	private FormParentChildRelationRepo formParentChildRelationRepo;



	public void execute()  {
		List<DprBasedPasFileRelation> list = new ArrayList<>();
		List<DprBasedPasFileHierarchy> fileHierarchy = dprbasedPasFileHierarchyRepo.findAll();
		for(DprBasedPasFileHierarchy entity:fileHierarchy) {			
			List<PasFileHierarchy> resultList = new ArrayList<>();
			list.add(DprBasedPasFileRelation.builder().dprName(entity.getDprName()).relationMap(getHierarchyList(entity.getAllFileHierarchy(),resultList)).build());
		}
		dprBasedPasFileRelationRepo.deleteAll();
		dprBasedPasFileRelationRepo.saveAll(list);

	}

	private Map<String, String> getHierarchyList(List<PasFileHierarchy> allFileHierarchy, List<PasFileHierarchy> resultList) {

		for(PasFileHierarchy hierarchy:allFileHierarchy) {
			if(CollectionUtils.isNotEmpty(hierarchy.getChildEntry())) {
				getHierarchyList(hierarchy.getChildEntry(), resultList);
			}
			resultList.add(hierarchy);
		}
		Map<String, String> resultMap = new HashMap<>(); 
		resultList.stream().forEach(doc->{
			if(StringUtils.isEmpty(doc.getFileName())) {
				return;
			}
			String find = StringUtils.substringAfter(doc.getFileName(), ".");
			resultMap.put(StringUtils.trim(StringUtils.replace(doc.getFileName(), "."+find, "")),  doc.getParentFile());
		});

		return resultMap;

	}


	private Map<String, PasFileHierarchy> getHierarchyDetails(List<PasFileHierarchy> allFileHierarchy, List<PasFileHierarchy> resultList) {

		for(PasFileHierarchy hierarchy:allFileHierarchy) {
			if(CollectionUtils.isNotEmpty(hierarchy.getChildEntry())) {
				getHierarchyList(hierarchy.getChildEntry(), resultList);
			}
			resultList.add(hierarchy);
		}
		Map<String, PasFileHierarchy> resultMap = new HashMap<>(); 
		resultList.stream().forEach(doc->{
			if(StringUtils.isEmpty(doc.getFileName())) {
				return;
			}
			String find = StringUtils.substringAfter(doc.getFileName(), ".");
			resultMap.put(StringUtils.trim(StringUtils.replace(doc.getFileName(), "."+find, "")),  doc);
		});

		return resultMap;

	}

	public void executePasFileParentChildRelation() {
		log.info("Started executePasFileParentChildRelation method "+ new Date(System.currentTimeMillis()));
		formParentChildRelationRepo.deleteAll();
		List<DprBasedPasFileHierarchy> fileHierarchyList = dprbasedPasFileHierarchyRepo.findAll();

		//TODO test data 
		//List<DprBasedPasFileHierarchy> fileHierarchyList = Arrays.asList( dprbasedPasFileHierarchyRepo.findByDprName("AnyTimePaymentForEmp"));

		for( DprBasedPasFileHierarchy fileHierarchy: fileHierarchyList) {
			List<PasFileHierarchy> resultList = new ArrayList<>();
			Map<String, PasFileHierarchy> dataList = getHierarchyDetails(fileHierarchy.getAllFileHierarchy() ,resultList );
			insertChild(dataList,fileHierarchy.getDprName());
			iterateTillChild(fileHierarchy.getAllFileHierarchy(), dataList,fileHierarchy.getDprName());
		}

		log.info("Ended executePasFileParentChildRelation method "+ new Date(System.currentTimeMillis()));

	}


	private void insertChild(Map<String, PasFileHierarchy> dataList,String dprName) {	
		Map<String, PasFileHierarchy> childMap  = new HashMap<>();
		dataList.entrySet().stream().forEach(mapper->{
			childMap.put(mapper.getValue().getAbsoluteFilePath(), mapper.getValue());
		});
		childMap.entrySet().stream().forEach(record->{
			FormParentChildRelationEntity hierarchyDetails =  formParentChildRelationRepo.findByFormName(record.getKey());
			if(Objects.isNull(hierarchyDetails)) {	
				FormParentChildRelationEntity childrenDetails = FormParentChildRelationEntity.builder().build();
				if(CollectionUtils.isNotEmpty(record.getValue().getChildEntry())) {
					record.getValue().setDprName(dprName);
					childrenDetails.setChildrenList(Arrays.asList(record.getValue()));
				}
				childrenDetails.setFormName(record.getKey());
				if( StringUtils.isNotEmpty(childrenDetails.getFormName())) {
					formParentChildRelationRepo.save(childrenDetails);
				}
			}else {				
				if(CollectionUtils.isNotEmpty(record.getValue().getChildEntry())) {
					record.getValue().setDprName(dprName);
					List<PasFileHierarchy> list = hierarchyDetails.getChildrenList() ;
					if(CollectionUtils.isEmpty(list)) {
						list = new ArrayList<>();
					}
					list.add(record.getValue());
					hierarchyDetails.setChildrenList(list);
					if( StringUtils.isNotEmpty(hierarchyDetails.getFormName())) {
						formParentChildRelationRepo.save(hierarchyDetails);
					}
				}
			}

		});

	}



	private Map<String, PasFileHierarchy> iterateTillChild(List<PasFileHierarchy> fileHierarchy, Map<String, PasFileHierarchy> dataList, String dprName) {	
		Map<String, PasFileHierarchy> dataParentMap = new HashMap<>();	
		List<PasFileHierarchy> list = dataList.entrySet().stream().map(mapper->mapper.getValue()).collect(Collectors.toList());	
		for(PasFileHierarchy hierarchy : list) {
			Map<String, PasFileHierarchy> data = iterateForParent(hierarchy,dataList);		
			data.entrySet().stream().forEach(record->{		
				FormParentChildRelationEntity hierarchyDetails =  formParentChildRelationRepo.findByFormName(record.getKey());
				if(Objects.isNull(hierarchyDetails)) {	
					FormParentChildRelationEntity parentDetails = FormParentChildRelationEntity.builder().build();
					if(CollectionUtils.isNotEmpty(record.getValue().getChildEntry())) {
						record.getValue().setDprName(dprName);
						parentDetails.setParentList(Arrays.asList(record.getValue()));
					}
					parentDetails.setFormName(record.getKey());
					if( StringUtils.isNotEmpty(parentDetails.getFormName())) {
						formParentChildRelationRepo.save(parentDetails);
					}
				}else {					
					if(CollectionUtils.isNotEmpty(record.getValue().getChildEntry())) {
						record.getValue().setDprName(dprName);
						List<PasFileHierarchy> listData = hierarchyDetails.getParentList() ;
						if(CollectionUtils.isEmpty(listData)) {
							listData = new ArrayList<>();
						}
						listData.add(record.getValue());
						hierarchyDetails.setParentList(listData);
						if( StringUtils.isNotEmpty(hierarchyDetails.getFormName())) {
							formParentChildRelationRepo.save(hierarchyDetails);
						}
					}
				}

			});
		}
		return dataParentMap;

	}


	private Map<String, PasFileHierarchy> iterateForParent(PasFileHierarchy allFileHierarchy, Map<String, PasFileHierarchy> dataList) {	
		Map<String, PasFileHierarchy> dataMap = new HashMap<>();
		PasFileHierarchy finalHierarchy = PasFileHierarchy.builder().build();
		if(StringUtils.isNotEmpty(allFileHierarchy.getParentFile())) {	
			String fileName = 	allFileHierarchy.getFileName().replace(".pas", StringUtils.EMPTY).trim();
			while(StringUtils.isNotEmpty(fileName)) {
				String key = fileName.replace(".pas", StringUtils.EMPTY).trim();
				fileName = String.valueOf(dataList.containsKey(key) ? dataList.get(key).getFileName() : StringUtils.EMPTY);
				key = fileName.replace(".pas", StringUtils.EMPTY).trim();
				if(StringUtils.isEmpty(fileName)  ||  !dataList.containsKey(key)) {
					break;
				}
				PasFileHierarchy hierarchy = dataList.get(key) ; 
				if(StringUtils.isEmpty(finalHierarchy.getFileName())) {
					PasFileHierarchy childList = hierarchy;
					childList.setChildEntry(null);
					BeanUtils.copyProperties(childList, finalHierarchy);
				}else {
					PasFileHierarchy childDataList = finalHierarchy;
					hierarchy.setChildEntry(new ArrayList<>());				
					finalHierarchy = hierarchy ; 
					finalHierarchy.setChildEntry( Arrays.asList(childDataList)) ;
				}	
				fileName = String.valueOf(hierarchy.getParentFile());

			}	
			dataMap.put(allFileHierarchy.getAbsoluteFilePath(), finalHierarchy);
			return dataMap;

		}
		//else {
		//	dataMap.put(allFileHierarchy.getAbsoluteFilePath(), allFileHierarchy);

		//}

		return dataMap;

	}




	/*
	private void iterateForParent(PasFileHierarchy allFileHierarchy,PasFileHierarchy finalHierarchy,Map<String,PasFileHierarchy> dataMap, Map<String, PasFileHierarchy> dataList) {	


		if(CollectionUtils.isEmpty(allFileHierarchy.getChildEntry())) {
			List<PasFileHierarchy> childDataList = finalHierarchy.getChildEntry() ; 
			PasFileHierarchy newPasFileHirarchy = PasFileHierarchy.builder().build(); 
			newPasFileHirarchy.setFileName(allFileHierarchy.getFileName());
			newPasFileHirarchy.setChildEntry(childDataList);
			newPasFileHirarchy.setAbsoluteFilePath(allFileHierarchy.getAbsoluteFilePath());
			newPasFileHirarchy.setChild(allFileHierarchy.isChild());
			newPasFileHirarchy.setParent(allFileHierarchy.isParent());
			dataMap.put(allFileHierarchy.getFileName(), newPasFileHirarchy);
			finalHierarchy = PasFileHierarchy.builder().build();
			return;
		}

		for(PasFileHierarchy hierarchy : allFileHierarchy.getChildEntry()) {
			if(CollectionUtils.isNotEmpty(hierarchy.getChildEntry())) {
				iterateForParent(hierarchy,finalHierarchy,dataMap,dataList);
			}
			if(!hierarchy.isChild()) {
				List<PasFileHierarchy> childDataList = finalHierarchy.getChildEntry() ; 
				PasFileHierarchy newPasFileHirarchy = PasFileHierarchy.builder().build(); 

				newPasFileHirarchy.setFileName(hierarchy.getFileName());
				newPasFileHirarchy.setChildEntry(childDataList);
				newPasFileHirarchy.setAbsoluteFilePath(hierarchy.getAbsoluteFilePath());
				newPasFileHirarchy.setChild(hierarchy.isChild());
				newPasFileHirarchy.setParent(hierarchy.isParent());
				newPasFileHirarchy.setChildEntry(childDataList);

				dataMap.put(hierarchy.getFileName(), newPasFileHirarchy);
				finalHierarchy = PasFileHierarchy.builder().build();
			}
			if(hierarchy.isChild()) {
				if(CollectionUtils.isEmpty( finalHierarchy.getChildEntry())) {
					List<PasFileHierarchy> childList = new ArrayList<>() ;
					childList.add(hierarchy);
					finalHierarchy.setChildEntry(childList);
				}else {
					List<PasFileHierarchy> childDataList = finalHierarchy.getChildEntry() ; 
					finalHierarchy = hierarchy ; 
					finalHierarchy.setChildEntry(childDataList);
				}

			}


		}




	}
	 */


	private void iterateToChild(List<PasFileHierarchy> allHierarchyList, Map<String, String> map) {
		for(PasFileHierarchy hierarchy:allHierarchyList) {
			if(CollectionUtils.isNotEmpty(hierarchy.getChildEntry())) {
				iterateToChild(hierarchy.getChildEntry(),map);
			}
			List<String> parentList =  new ArrayList<>();
			//getParentFiles(hierarchy,parentList,map);
			List<String> childList = new ArrayList<>();
			//getChildFiles(hierarchy,childList);
			FormParentChildRelationEntity  fromRelationEntity =  FormParentChildRelationEntity.builder().formName(hierarchy.getAbsoluteFilePath()).build();
			FormParentChildRelationEntity  relationEntity = formParentChildRelationRepo.findByFormName(hierarchy.getAbsoluteFilePath());
			if(Objects.nonNull(relationEntity)) {
				relationEntity.getParentList().addAll(fromRelationEntity.getParentList());
				relationEntity.getChildrenList().addAll(fromRelationEntity.getChildrenList());
				formParentChildRelationRepo.save(relationEntity);

			}else {
				formParentChildRelationRepo.save(fromRelationEntity);
			}
		}
	}


	private void getChildFiles(PasFileHierarchy allFileHierarchy, List<String> childList) {
		if(CollectionUtils.isEmpty(allFileHierarchy.getChildEntry())) {
			return;
		}

		for(PasFileHierarchy hierarchy : allFileHierarchy.getChildEntry()) {
			if(CollectionUtils.isNotEmpty(hierarchy.getChildEntry())) {
				getChildFiles(hierarchy, childList);
			}
			childList.add(hierarchy.getFileName());
		}

	}

	private void getParentFiles(PasFileHierarchy hierarchy,List<String> parentList, Map<String, String> map){
		if(StringUtils.isNotEmpty(hierarchy.getParentFile())) {		
			String fileName = 	hierarchy.getParentFile().replace(".pas", StringUtils.EMPTY).trim();
			parentList.add(fileName);
			while(StringUtils.isNotEmpty(fileName)) {
				String key = fileName.replace(".pas", StringUtils.EMPTY).trim();
				fileName =  map.containsKey(key) ?  map.get(key) : StringUtils.EMPTY;
				if(StringUtils.isEmpty(fileName))
					continue;
				parentList.add(fileName);
			}

		}

	}





}
