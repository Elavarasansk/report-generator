package org.intraweb.tools.worksheet.controller;

import java.util.List;

import org.intraweb.tools.worksheet.entity.vo.FormIssuesVo;
import org.intraweb.tools.worksheet.service.NonTestedFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class NonTestedFormController {

    @Autowired
    private NonTestedFormService nonTestedFormService;

    @GetMapping("/intraweb/nonTestedForm")
    public List<FormIssuesVo> getAllDetails() {
	return nonTestedFormService.getAllNonTestedFormDetails();
    }
}
