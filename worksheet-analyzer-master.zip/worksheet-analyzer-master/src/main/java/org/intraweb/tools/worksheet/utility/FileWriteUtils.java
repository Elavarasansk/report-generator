package org.intraweb.tools.worksheet.utility;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.intraweb.tools.worksheet.entity.WorksheetFileListEntity;


public class FileWriteUtils {

	public static File writeToFile(File workSheetFile,Workbook workbook, List<WorksheetFileListEntity> dprPasFileDetailList, Map<String, List<String>> filePathMap ) throws IOException {

		//	Workbook workbook = WorkbookFactory.create(workSheetFile);
		Sheet worksheet = workbook.getSheet("FileList");
		int frameworkCol = Constants.frameworkCol;//Cell index in column wise
		int typeCol = Constants.typeCol;//Cell index in column wise
		int patternCol = Constants.patternCol;//Cell index in column wise
		int isTargetCol = Constants.isTargetCol;//Cell index in column wise
		int statusCol = 8;

		dprPasFileDetailList.stream().forEach(row->{
			if(row.isForm() && row.isTargetForm()) {
				Cell frameworkCell= worksheet.getRow(row.getRowIndex()).getCell(frameworkCol);
				frameworkCell.setCellValue(row.getFrameWork());
				Cell typeCell= worksheet.getRow(row.getRowIndex()).getCell(typeCol);
				typeCell.setCellValue(row.getLayoutType());
				Cell patternCell= worksheet.getRow(row.getRowIndex()).getCell(patternCol);
				patternCell.setCellValue(row.getLayoutPattern());
				Cell targetCell= worksheet.getRow(row.getRowIndex()).getCell(isTargetCol);
				//targetCell.setCellValue(1);	
				Cell statusCell= worksheet.getRow(row.getRowIndex()).getCell(statusCol);
				statusCell.setCellValue(row.getStatus());
				if(StringUtils.isNotEmpty(row.getAssignee())) {
					Cell assigneeCell = worksheet.getRow(row.getRowIndex()).getCell(Constants.assignee);
					assigneeCell.setCellValue(row.getAssignee());
					//targetCell.setCellValue(0);	
				}

				if(filePathMap.containsKey(row.getFilePath())) {
					List<String> dprList = filePathMap.get(row.getFilePath());
					String firstDpr =dprList.get(0);

					if(StringUtils.contains(row.getDprPath(),firstDpr)) {
						targetCell.setCellValue(1);
					}else {
						targetCell.setCellValue(0);
					}
				}

				//Bug Fix
				if(StringUtils.contains(row.getStatus(), "Developed")) {
					targetCell.setCellValue(0);

				}


				Cell link = worksheet.getRow(row.getRowIndex()).getCell(Constants.link);
				drawHyperLink(workbook, link,row);
			}
		});

		String fileName = FilenameUtils.removeExtension(workSheetFile.getName());

		File tempFile = File.createTempFile(fileName,".xls");				
		System.out.println("File Path :"+tempFile.getAbsolutePath());		
		//File write 
		try(FileOutputStream out  = new FileOutputStream(tempFile)){
			workbook.write(out);
		}
		workbook.close();
		return tempFile;


	}


	public static void drawHyperLink(Workbook workbook,Cell hyperLinkCell, WorksheetFileListEntity sheetEntity) {
		if(StringUtils.isNotEmpty(sheetEntity.getIssueId())) {
			CreationHelper createHelper = workbook.getCreationHelper();
			CellStyle hlink_style = workbook.createCellStyle();
			hlink_style.cloneStyleFrom(hyperLinkCell.getCellStyle());
			Font hlink_font = workbook.createFont();
			hlink_font.setUnderline(Font.U_SINGLE);
			hlink_font.setColor(HSSFColorPredefined.BLUE.getIndex());
			hlink_style.setFont(hlink_font);
			Hyperlink link = createHelper.createHyperlink(HyperlinkType.URL);
			link.setAddress(sheetEntity.getHyperLink());
			hyperLinkCell.setHyperlink(link);
			hyperLinkCell.setCellStyle(hlink_style);
			hyperLinkCell.setCellValue(new StringBuilder().append("#").append(sheetEntity.getIssueId()).toString());
		}

	}



}
