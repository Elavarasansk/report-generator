package org.intraweb.tools.worksheet.utility.autocheck.colorcode;




import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.intraweb.tools.worksheet.entity.aligner.DFMObject;

public class DFMPanelArranger {



	public  void setColorCode(DFMObject dfmObject) {
		List<DFMObject> objList = new ArrayList<>();
		 formData(dfmObject,objList);
		 arrangeCurrentPanel(objList);
	}
	
	




	public  void formData(DFMObject dfmObject, List<DFMObject> objList) {

		for( DFMObject dfmData  :  dfmObject.getChild()) {

			if( CollectionUtils.isNotEmpty(dfmData.getChild())){
				formData(dfmData,objList);

			}
			objList.add(dfmData);
		}
	}



	public  void  arrangeCurrentPanel(List<DFMObject> panel) {
		DFMColorCodeFixer colorfix = new DFMColorCodeFixer();
		for( DFMObject child  :  panel) {
			if(Objects.nonNull(child)) {

				if(isExist(child, "Color") || isExist(child, "Font.Color")) {
					colorfix.fixColorCode(child);
				}

				
			}

		}
		System.out.println("arrangeCurrentPanel finished..");

	}





	private  boolean isExist(DFMObject node, String paramKey) {
		boolean result = false;
		if(MapUtils.isNotEmpty(node.getData())) {
			return node.getData().entrySet()
					.stream()
					.filter(dfm-> dfm.getKey().trim().split("=")[0].equalsIgnoreCase(paramKey))
					.collect(Collectors.toList()).size() > 0;
		}
		return result;
	}

}
