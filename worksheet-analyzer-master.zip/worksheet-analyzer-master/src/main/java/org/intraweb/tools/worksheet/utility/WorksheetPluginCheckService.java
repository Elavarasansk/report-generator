package org.intraweb.tools.worksheet.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class WorksheetPluginCheckService {


	static List<String> dprSuggestPluginStats = new ArrayList<String>();
	static List<String> dprSocialPluginStats = new ArrayList<String>();
	
	static List<String> duplicateSuggestPluginData = new ArrayList<String>();
	static List<String> duplicateSocialPluginData = new ArrayList<String>();
	
	static List<File> allWorksheetList = new ArrayList<File>();
	static List<File> arrangedWorksheets = new ArrayList<File>();

	public static void main(String args[]) throws IOException, EncryptedDocumentException, InvalidFormatException {
		String worksheetDirectory = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-document\\30_Worksheet\\10_template";
		String dprHeirarchyFilePath = "D:\\Vairavan\\Learning\\Projects\\intraweb-redmine\\src\\main\\resources\\SummarizeTargetList.csv";

		List<List<String>> parsedDprInfoList = processDprCsvFile(dprHeirarchyFilePath);

		getAllWorksheets(worksheetDirectory);
		
		List<String> worksheetOrder = new ArrayList<String>();

//		dprSuggestPluginStats.add("dprName" +","+ "myTargetPluginCount" +","+ "dupPluginCount");
		dprSocialPluginStats.add("dprName" +","+ "myTargetPluginCount" +","+ "dupPluginCount");
		for(List<String> dprInfo :parsedDprInfoList) {
			String dprName = dprInfo.get(0).replace(".dpr", "");

			int fileIndex=0;
			for(File workbook: allWorksheetList) {
				fileIndex++;
				int dprIndex = workbook.getName().indexOf(Constants.WORKSHEET_PREFIX+dprName);
				if(dprIndex == -1) {
					continue;
				}
				allWorksheetList.remove(fileIndex-1);
				log.info("Worksheet Count "+ allWorksheetList.size());
				worksheetOrder.add(dprName);
				processDprWorksheet(workbook, dprName);
				break;
			}
		}
//		prepareDprSpecificCount("Summary", "OverallPluginStats", dprSuggestPluginStats);
//		prepareDprSpecificCount("Summary", "Total Unique Plugins", duplicateSuggestPluginData);
//		prepareDprSpecificCount("Summary", "OrderOfExecution", worksheetOrder);
		
		prepareDprSpecificCount("Summary", "OverallPluginStats", dprSocialPluginStats);
		prepareDprSpecificCount("Summary", "Total Unique Plugins", duplicateSocialPluginData);
		prepareDprSpecificCount("Summary", "OrderOfExecution", worksheetOrder);
	}

	private static void getAllWorksheets(String worksheetDirPath) {
		File worksheetDirectory = new File(worksheetDirPath);
		File[] fileList = worksheetDirectory.listFiles();
		
		for(File worksFile:fileList) {
			boolean isDir = worksFile.isDirectory();
			boolean isFile = worksFile.isFile();
			if(isFile) {
				allWorksheetList.add(worksFile);
			} else if(isDir) {
				getAllWorksheets(worksFile.getAbsolutePath());
			}
		}
	}

	private static void arrangeWorksheets(File workbookFile, String dprName) {
		String fileName = workbookFile.getName();
		if(fileName.indexOf(Constants.WORKSHEET_PREFIX+dprName) != -1) {
			arrangedWorksheets.add(workbookFile);
		}
	}


	private static void extractSheetsFromDirectory(String worksheetDirectoryPath, String dprName) {
		File worksheetDirectory = new File(worksheetDirectoryPath);
		boolean isDirectory = worksheetDirectory.isDirectory();
		if(isDirectory) {
			File[] worksheetFileList = worksheetDirectory.listFiles();
			for(File workbookFile: worksheetFileList) {
				if(workbookFile.isDirectory()) {
					extractSheetsFromDirectory(workbookFile.getAbsolutePath(), dprName);
				} else {
					arrangeWorksheets(workbookFile, dprName);
					return;
				}
			}
		}
	}


	private static void processDprWorksheet(File workSheetFile, String dprName) throws EncryptedDocumentException, InvalidFormatException, IOException {
		Workbook workbook = WorkbookFactory.create(workSheetFile);
		for(Sheet worksheet : workbook) {
			String sheetName = worksheet.getSheetName();
			switch (sheetName) {
			case "EditList":
//				log.info("Getting Plugins for -> "+dprName);
//				processSuggestPlugins(worksheet,dprName);
				break;
				
			case "FileList":
				log.info("Getting Social Plugins for -> "+dprName);
				processSocialPlugins(worksheet,dprName);
				break;	
			}
		}
	}

	private static void processSuggestPlugins(Sheet editFieldSheet, String dprName) {
		DataFormatter dataFormatter = new DataFormatter();

		/*int startRowIndex = editFieldSheet.getFirstRowNum()+2;
		int endRowIndex = editFieldSheet.getLastRowNum();*/

		int startRowIndex = 3;
		int endRowIndex = editFieldSheet.getLastRowNum();
		
		int masterSuggest = 11; //Cell index in column wise
		int sqlTag = 14; //Cell index in column wise

		int dupCount=0;
		int myCount=0;

		List<String> myUniquePlugins = new ArrayList<String>();
		List<String> myDuplicatePlugins = new ArrayList<String>();

		for(int i=startRowIndex;i<=endRowIndex; i++) {
			Cell suggestField = editFieldSheet.getRow(i).getCell(masterSuggest);
			Cell sqlTagField = editFieldSheet.getRow(i).getCell(sqlTag);

			String suggestValue = dataFormatter.formatCellValue(suggestField);
			String sqlValue = dataFormatter.formatCellValue(sqlTagField);

			boolean suggestPluginExists = (suggestValue.toLowerCase().equals("true") ||
					(!sqlValue.isEmpty() && sqlValue!=null));

			if(!suggestPluginExists) {
				continue;
			}

			if(duplicateSuggestPluginData.contains(sqlValue)) {
				if(!myDuplicatePlugins.contains(sqlValue)) {
					dupCount++;
					myDuplicatePlugins.add(sqlValue);
				}
			} else {
				myCount++;
				myUniquePlugins.add(sqlValue);
				duplicateSuggestPluginData.add(sqlValue);
			}
		}
		dprSuggestPluginStats.add(dprName +","+ myCount +","+dupCount);
		
		try {
			prepareDprSpecificCount(dprName,"myUniquePlugins", myUniquePlugins);
			prepareDprSpecificCount(dprName,"myDuplicatePlugins", myDuplicatePlugins);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private static void processSocialPlugins(Sheet editFieldSheet, String dprName) {
		DataFormatter dataFormatter = new DataFormatter();

		/*int startRowIndex = editFieldSheet.getFirstRowNum()+2;
		int endRowIndex = editFieldSheet.getLastRowNum();*/

		int startRowIndex = 12;
		int endRowIndex = editFieldSheet.getLastRowNum();
		
		int socialPlugin = 12; //Cell index in column wise
		int sqlTag = 15; //Cell index in column wise

		int dupCount=0;
		int myCount=0;

		List<String> myUniquePlugins = new ArrayList<String>();
		List<String> myDuplicatePlugins = new ArrayList<String>();

		for(int i=startRowIndex;i<=endRowIndex; i++) {
			Cell suggestField = editFieldSheet.getRow(i).getCell(socialPlugin);
			Cell sqlTagField = editFieldSheet.getRow(i).getCell(sqlTag);

			String suggestValue = dataFormatter.formatCellValue(suggestField);
			String sqlValue = dataFormatter.formatCellValue(sqlTagField);

			boolean suggestPluginExists = (suggestValue.toLowerCase().equals("true") ||
					(!sqlValue.isEmpty() && sqlValue!=null && !suggestValue.equals("-") && !sqlValue.equals("-")));

			if(!suggestPluginExists) {
				continue;
			}
			
			if(sqlValue.isEmpty() || sqlValue == null) {
				sqlValue = "null";
			}

			if(duplicateSocialPluginData.contains(sqlValue)) {
				if(!myDuplicatePlugins.contains(sqlValue)) {
					dupCount++;
					myDuplicatePlugins.add(sqlValue);
				}
			} else {
				myCount++;
				myUniquePlugins.add(sqlValue);
				duplicateSocialPluginData.add(sqlValue);
			}
		}
		dprSocialPluginStats.add(dprName +","+ myCount +","+dupCount);
		
		try {
			prepareDprSpecificCount(dprName,"myUniquePlugins", myUniquePlugins);
			prepareDprSpecificCount(dprName,"myDuplicatePlugins", myDuplicatePlugins);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private static void prepareDprSpecificCount(String dprName, String type, List<String> rows ) throws IOException {
		String filePath = "D:\\Vairavan\\Detailed_DPR_Social_Plugins\\"+ dprName +"\\" + type+ ".csv";
		File file = new File(filePath);

		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		if (!file.exists()) {
			file.createNewFile();
		}
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));

		for (String row : rows) {
			pw.print(row + ",");
			pw.println();
		}
		pw.close();
	}



	private static List<List<String>> processDprCsvFile(String dprHeirarchyFilePath) throws IOException {
		List<List<String>> parsedDataList = new ArrayList<List<String>>();

		File heirarchyCsvFile = new File(dprHeirarchyFilePath);

		boolean isSummaryFile = heirarchyCsvFile.isFile();

		if(isSummaryFile){
			BufferedReader buffer = new BufferedReader(new FileReader(heirarchyCsvFile));

			String currentLine = null;
			while((currentLine = buffer.readLine()) != null) {
				if(currentLine.isEmpty()) {
					continue;
				}
				List<String> rowDataList = Arrays.asList(currentLine.split(Constants.COMMA));
				parsedDataList.add(rowDataList);
			}
		}
		return parsedDataList;
	}


}
