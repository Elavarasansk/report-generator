package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.PasFileHierarchy;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PasFileHierarchyRepo extends MongoRepository<PasFileHierarchy, String>{

}
