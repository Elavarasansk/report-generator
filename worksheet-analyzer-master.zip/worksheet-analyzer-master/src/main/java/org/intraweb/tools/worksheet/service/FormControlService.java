package org.intraweb.tools.worksheet.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.intraweb.tools.worksheet.dto.FormControlDto;
import org.intraweb.tools.worksheet.entity.CortexDprDetails;
import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.intraweb.tools.worksheet.entity.FormIssues;
import org.intraweb.tools.worksheet.repository.interfaces.CortexDprDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.DuplicatePasFileDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.FormControlRepo;
import org.intraweb.tools.worksheet.repository.interfaces.FormIssuesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FormControlService{

	@Autowired
	private DuplicatePasFileDetailsRepo duplicatePasFileDetailsRepo;

	@Autowired
	private CortexDprDetailsRepo cortexDprDetailsRepo;

	@Autowired
	private FormIssuesRepo formIssuesRepo;

	@Autowired
	private FormControlRepo formControlRepo;


	public void getFormControlDetails() {
		log.info("----------------------------------------------> Start Time"+ new Date(System.currentTimeMillis()));
		List<FormIssues> redmineData = formIssuesRepo.findAll();
		List<CortexDprDetails> cortexDprList = cortexDprDetailsRepo.findAll();
		List<DuplicatePasDetails> duplicatePasFileData = duplicatePasFileDetailsRepo.findAll();
		System.out.println("cortexDprList----------------------------"+cortexDprList);

		
		Map<String, CortexDprDetails> cortexMap = new HashMap<String, CortexDprDetails>();
		
		cortexDprList = cortexDprList.stream().filter(x-> x.getDprname()!=null ).collect(Collectors.toList());

		Map<String, List<CortexDprDetails>> cortexInfoMapList = cortexDprList.stream().collect(Collectors.groupingBy(CortexDprDetails::getDprname));
		for(Map.Entry<String, List<CortexDprDetails>> cortexData : cortexInfoMapList.entrySet()) {
			List<CortexDprDetails> duplicateDprList = cortexData.getValue();
			duplicateDprList.forEach(dprData -> {
				if(!dprData.getDprstatus().equalsIgnoreCase("discard"));{
					cortexMap.put(cortexData.getKey(), dprData);
				}
			});
		}

		Map<String, FormIssues> redmineInfoMap = new HashMap<>();
		redmineData.forEach(data -> {
			redmineInfoMap.put(data.getSubject(), data);
		});


		List<FormControlDto> formControlList = new ArrayList<>();
		duplicatePasFileData.forEach(data -> {
			List<String> sharedDprList= data.getDprs();
			String targetDpr = sharedDprList.get(0);

			FormControlDto formControlDto = FormControlDto.builder()
					.formName(data.getPasFileName())
					.sharedDprs(data.getDprs())
					.targetdpr(targetDpr)
					.build();

			String redminePath = data.getPasFileName().replace("\\", "/");
			String redmineTypeArray[] = redminePath.split("/");
			if(redmineInfoMap.get(redminePath)!=null) {
				FormIssues redmineIssueDetails = redmineInfoMap.get(redminePath);
				formControlDto.setRedmineId(redmineIssueDetails.getIssueId());
				formControlDto.setRedminestatus(redmineIssueDetails.getStatus());
				formControlDto.setRedmineassignee(redmineIssueDetails.getAssigneeName());
			}
			formControlDto.setType(redmineTypeArray[0]);

			CortexDprDetails cortexStoryData = cortexMap.get(sharedDprList.get(0));
			if(cortexMap.get(sharedDprList.get(0)) != null) {
				formControlDto.setCortexId(cortexStoryData.getStoryid());
				formControlDto.setCortexstatus(cortexStoryData.getDprstatus());
				formControlDto.setEnddate(cortexStoryData.getEnddate());
				formControlDto.setGitmergestatus(cortexStoryData.getGitmergestatus());
				formControlDto.setGittype(cortexStoryData.getGittype());
			}

			formControlList.add(formControlDto);
		});

		formControlRepo.deleteAll();
		formControlRepo.saveAll(formControlList);
		log.debug("formControlList -------------> "+formControlList);
		log.info("----------------------------------------------> End Time"+ new Date(System.currentTimeMillis()));
	}



	public void getFormDetails_() {
		List<DuplicatePasDetails> duplicatePasFileData = duplicatePasFileDetailsRepo.findAll();
		List<FormControlDto> formControlList = new ArrayList<>();
		duplicatePasFileData.forEach(data -> {
			Boolean wrongStroyFlag = true;
			List<String> dprname= data.getDprs();
			String cortexstatus=null;
			String storyid = null;
			String enddate = null;
			String gittype = null;
			String gitmergestatus = null;
			List<CortexDprDetails> cortexDprDetailsData = cortexDprDetailsRepo.findByDprname(String.valueOf(dprname.get(0)));
			String redminePath = data.getPasFileName().replace("\\", "/");
//			List<FormIssues> formIssuesData = formIssuesRepo.findBySubject(redminePath);

			/*if(cortexDprDetailsData.size()>0) {
				cortexDprDetailsData.forEach(dataStatus -> {
					if(!dataStatus.getDprstatus().equals("Discard")) {
						cortexstatus = cortexDprDetailsData.get(0).getDprstatus();
						storyid = cortexDprDetailsData.get(0).getStoryid();
						enddate =  cortexDprDetailsData.get(0).getEnddate();
						if(formIssuesData.size()>0 && cortexstatus.equals("Resolved") && formIssuesData.get(0).getAssigneeName() != "" && formIssuesData.get(0).getStatus().equals("Developed")){
							gittype = cortexDprDetailsData.get(0).getGittype();
							gitmergestatus =cortexDprDetailsData.get(0).getGitmergestatus();
						}else{
							gittype = "";
							gitmergestatus = "";
						}
					}else {
						wrongStroyFlag = false;
					}
				});
			}else{
				cortexstatus = "Not Created";
			}*/








			/*if(wrongStroyFlag && formIssuesData.size()>0 ) {
				FormControlDto formControlDto = FormControlDto.builder()
						.formName(data.getPasFileName())
						.sharedDprs(data.getDprs())
						.cortexId(storyid)
						.cortexstatus(cortexstatus)
						.gittype(gittype)
						.gitmergestatus(gitmergestatus)
						.targetdpr(dprname.get(0))
						.enddate(enddate)
						.redmineId(formIssuesData.get(0).getIssueId())
						.redminestatus(formIssuesData.get(0).getStatus())
						.redmineassignee(formIssuesData.get(0).getAssigneeName())
						.build();
				formControlList.add(formControlDto);
			}*/
		});
		formControlRepo.deleteAll();
		formControlRepo.saveAll(formControlList);
		log.info("formControlList -------------> "+formControlList);
	}
}