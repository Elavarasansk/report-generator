package org.intraweb.tools.worksheet.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="form_parent_child_relation")
public class FormParentChildRelationEntity {

	@Id
	private ObjectId id; 	

	@Indexed
	private String formName;
	

	private List<PasFileHierarchy> parentList;

	private List<PasFileHierarchy> childrenList;





}
