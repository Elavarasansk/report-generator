package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.DprBasedPasFileRelation;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DprBasedPasFileRelationRepo extends MongoRepository<DprBasedPasFileRelation, String>{
	
	DprBasedPasFileRelation findByDprName(String dprName);


}
