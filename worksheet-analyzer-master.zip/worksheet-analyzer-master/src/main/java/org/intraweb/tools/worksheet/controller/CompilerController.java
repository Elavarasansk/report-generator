package org.intraweb.tools.worksheet.controller;

import org.intraweb.tools.worksheet.entity.CompileResultEntity;
import org.intraweb.tools.worksheet.service.CompilerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("compiler/")
@CrossOrigin
public class CompilerController {

	
	@Autowired
	private CompilerService compilerService;

	
	@GetMapping("git")
	public CompileResultEntity executeDprFromGit(@RequestParam String dprName,@RequestParam String module,@RequestParam String versionType) {
		return compilerService.executeDprFromGit(dprName,module,versionType);
	}
	
	@GetMapping("svn")
	public CompileResultEntity executeDprFromSvn(@RequestParam String dprName,@RequestParam String module,@RequestParam String versionType) {
		return compilerService.executeDprFromSvn(dprName,module,versionType);
	}
	

	
	


}
