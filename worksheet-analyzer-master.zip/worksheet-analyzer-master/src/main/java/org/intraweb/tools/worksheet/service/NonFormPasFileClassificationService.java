package org.intraweb.tools.worksheet.service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.worksheet.entity.DprAssignmentOrder;
import org.intraweb.tools.worksheet.entity.DprPasFileDetails;
import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.intraweb.tools.worksheet.entity.NonFormDprPasFileDetails;
import org.intraweb.tools.worksheet.entity.NonFormDuplicatePasDetails;
import org.intraweb.tools.worksheet.entity.WorksheetLocalPath;
import org.intraweb.tools.worksheet.repository.interfaces.DprAssignmentOrderRepo;
import org.intraweb.tools.worksheet.repository.interfaces.DprPasFileDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.DuplicatePasFileDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.NonFormDprPasFileDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.NonFormDuplicatePasFileDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.WorksheetLocalPathRepo;
import org.intraweb.tools.worksheet.utility.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NonFormPasFileClassificationService {

	@Autowired
	private DprAssignmentOrderRepo dprAssignmentOrderRepo;

	@Autowired
	private WorksheetLocalPathRepo worksheetLocalPathRepo;

	@Autowired
	private NonFormDprPasFileDetailsRepo nonFormDprPasFileDetailsRepo;
	
	@Autowired
	private NonFormDuplicatePasFileDetailsRepo nonFormDupsPasFileDetailsRepo;

	@Value("${worksheet.directory}")
	private String worksheetsPath;

	@Value("${assignment.dpr.order}")
	private String assigneDprListFile;

	List<File> allWorksheetList = new ArrayList<File>();

	List<String> allDprPasDetailList = new ArrayList<>();

	public void worksheetService() throws EncryptedDocumentException, InvalidFormatException, IOException {
		List<String> totalDuplicatePasFiles = new ArrayList<String>();
		List<NonFormDuplicatePasDetails> pasFileDprRepetition = new ArrayList<>();

		Map<String, List<String>> fileDprMap = new HashMap<>();

		List<DprAssignmentOrder> orderedDprList = dprAssignmentOrderRepo.findAll();
		
		nonFormDprPasFileDetailsRepo.deleteAll();

		for(DprAssignmentOrder dprInfo: orderedDprList) {
			//log.info("-------------------------------------------Pas File identifier " + dprInfo.getDprName());
			
			List<WorksheetLocalPath> worksheetList  = worksheetLocalPathRepo.findByDprName(dprInfo.getDprName());
			
			if(CollectionUtils.isEmpty(worksheetList)) {
				continue;
			}
			
			WorksheetLocalPath worksheet = worksheetList.get(worksheetList.size()-1);
			File workSheetFile = new File(worksheet.getWorksheetPath());
			processDprWorksheet(workSheetFile, dprInfo, totalDuplicatePasFiles, fileDprMap);
		}
		
		for(Map.Entry<String, List<String>> entry: fileDprMap.entrySet()) {
			NonFormDuplicatePasDetails pasFileDetails = NonFormDuplicatePasDetails.builder()
					.pasFileName(entry.getKey())
					.dprs(entry.getValue())
					.build();
			pasFileDprRepetition.add(pasFileDetails);
		}
		
		nonFormDupsPasFileDetailsRepo.deleteAll();
		nonFormDupsPasFileDetailsRepo.saveAll(pasFileDprRepetition);
		
		//create Csv file
//		createCsvFile();
	}

	private void processDprWorksheet(File workSheetFile, DprAssignmentOrder dprInfo, List<String> totalDuplicatePasFiles, Map<String, List<String>> fileDprMap) throws EncryptedDocumentException, InvalidFormatException, IOException {
		if(!workSheetFile.exists()) {
			System.out.println("File Not Found :" + workSheetFile.getAbsolutePath());
			return;
		}		

		Workbook workbook = WorkbookFactory.create(workSheetFile);
		List<NonFormDprPasFileDetails> dprPasFileDetailList = new ArrayList<>();

		for(Sheet worksheet : workbook) {
			String sheetName = worksheet.getSheetName();
			switch (sheetName) {
				case "FileList":
					dprPasFileDetailList.add(getPasFileInfo(worksheet, dprInfo, totalDuplicatePasFiles, fileDprMap));
					break;	
				case "EditList":
					break;
				case "Otherimplements":
					break;
			}
		}
		nonFormDprPasFileDetailsRepo.saveAll(dprPasFileDetailList);
	}

	private NonFormDprPasFileDetails getPasFileInfo(Sheet fileListSheet, DprAssignmentOrder dprDto, List<String>totalDuplicatePasFiles, Map<String, List<String>> fileDprMap) {

		DataFormatter dataFormatter = new DataFormatter();

		int startRowIndex = 12;
		int endRowIndex = fileListSheet.getLastRowNum();

		int isFormCol = 4; //Cell index in column wise
		int fileNameCol = 3; //Cell index in column wise
		int filePathCol = 34; //Cell index in column wise

		List<String> targetPasFiles = new ArrayList<String>();
		List<String> accommonPasFiles = new ArrayList<String>();
		List<String> duplicatePasFiles = new ArrayList<String>();

//		Map<String, List<String>> fileDprMap = new HashMap<>();

		for(int i=startRowIndex;i<=endRowIndex; i++) {

			Cell isFormTrue = fileListSheet.getRow(i).getCell(isFormCol);
			Cell fileNameCell = fileListSheet.getRow(i).getCell(fileNameCol);
			Cell filePathCell = fileListSheet.getRow(i).getCell(filePathCol);

			String isDelphiForm = dataFormatter.formatCellValue(isFormTrue);
			String pasFileName = dataFormatter.formatCellValue(fileNameCell);
			String pasFilePath = dataFormatter.formatCellValue(filePathCell);

			if(!isDelphiForm.toLowerCase().equals("false")) {
				continue;
			}

			if(pasFilePath.startsWith("accommon")) {
				accommonPasFiles.add(pasFilePath);
				continue;
			}
			
			List<String> dprList = new ArrayList<>();
			if(CollectionUtils.isEmpty(fileDprMap.get(pasFilePath))) {
				dprList.add(dprDto.getDprName());
				fileDprMap.put(pasFilePath, dprList);
			} else {
				dprList = fileDprMap.get(pasFilePath);
				dprList.add(dprDto.getDprName());
				fileDprMap.put(pasFilePath, dprList);
			}
			
			/*List<String> dprList = new ArrayList<>();
			if(CollectionUtils.isEmpty(fileDprMap.get(pasFileName))) {
				dprList.add(dprDto.getDprName());
				fileDprMap.put(pasFileName, dprList);
			} else {
				dprList = fileDprMap.get(pasFileName);
				dprList.add(dprDto.getDprName());
				fileDprMap.put(pasFileName, dprList);
			}*/

			if(totalDuplicatePasFiles.contains(pasFilePath)){
				duplicatePasFiles.add(pasFilePath);
			} else {
				targetPasFiles.add(pasFilePath);
				totalDuplicatePasFiles.add(pasFilePath);
				allDprPasDetailList.add(dprDto.getDprName()+","+pasFilePath);
			}
		}

		NonFormDprPasFileDetails pasFileDetails = NonFormDprPasFileDetails.builder()
				.dprName(dprDto.getDprName())
				.acCommonFiles(accommonPasFiles)
				.targetPasFiles(targetPasFiles)
				.duplicatePasFiles(duplicatePasFiles)
				.acCommonCount(accommonPasFiles.size())
				.targetCount(targetPasFiles.size())
				.duplicateCount(duplicatePasFiles.size())
				.build();

		return pasFileDetails;
	}


	private DprPasFileDetails getSuggestPluginFileInfo(Sheet fileListSheet, DprAssignmentOrder dprDto, List<String>totalDuplicatePasFiles) {

		DataFormatter dataFormatter = new DataFormatter();

		int startRowIndex = 12;
		int endRowIndex = fileListSheet.getLastRowNum();

		int isFormCol = 4; //Cell index in column wise
		int fileNameCol = 3; //Cell index in column wise
		int filePathCol = 34; //Cell index in column wise

		List<String> targetPasFiles = new ArrayList<String>();
		List<String> accommonPasFiles = new ArrayList<String>();
		List<String> duplicatePasFiles = new ArrayList<String>();

		for(int i=startRowIndex;i<=endRowIndex; i++) {
			Map<String, String> fileNamePath = new HashMap<>();

			Cell isFormTrue = fileListSheet.getRow(i).getCell(isFormCol);
			Cell fileNameCell = fileListSheet.getRow(i).getCell(fileNameCol);
			Cell filePathCell = fileListSheet.getRow(i).getCell(filePathCol);

			String isDelphiForm = dataFormatter.formatCellValue(isFormTrue);
			String pasFileName = dataFormatter.formatCellValue(fileNameCell);
			String pasFilePath = dataFormatter.formatCellValue(filePathCell);

			if(!isDelphiForm.toLowerCase().equals("true")) {
				continue;
			}

			if(pasFilePath.startsWith("accommon")) {
				accommonPasFiles.add(pasFilePath);
				continue;
			}

			if(totalDuplicatePasFiles.contains(pasFilePath)){
				duplicatePasFiles.add(pasFilePath);
			} else {
				targetPasFiles.add(pasFilePath);
				totalDuplicatePasFiles.add(pasFilePath);
			}
		}

		DprPasFileDetails pasFileDetails = DprPasFileDetails.builder()
				.dprName(dprDto.getDprName())
				.acCommonFiles(accommonPasFiles)
				.targetPasFiles(targetPasFiles)
				.duplicatePasFiles(duplicatePasFiles)
				.acCommonCount(accommonPasFiles.size())
				.targetCount(targetPasFiles.size())
				.duplicateCount(duplicatePasFiles.size())
				.build();

		return pasFileDetails;
	}
}
