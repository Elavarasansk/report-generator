package org.intraweb.tools.worksheet.entity.aligner;




import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.intraweb.tools.worksheet.utility.aligner.parser.DFMParser;


/**
 * Hello world!
 *
 */
public class DFMData {

    private Object data;

    private Type type;

    private static final String CRLF = System.lineSeparator();

    private enum Type {
        STRING, LIST, STRINGLIST, BINARY, MAP, NUMBER, LONG_NUMBER, BOOLEAN, FLOAT
    }

    public DFMData(String data) {
        if (data.isEmpty()) { // special case. Data in next line
            setType(Type.STRING);
            setData(data);
        } else if (data.equals("end")) { // special case. End of node
            setType(Type.STRING);
            setData(data);
        } else if (data.equals("True") || data.equals("False")) { // Type BOOLEAN
            setType(Type.BOOLEAN);
            setData(data.equals("True") ? true : false);
        } else if (data.matches("(-?[0-9]+\\.+[0-9]+)")) { // Type FLOAT
            setType(Type.FLOAT);
            setData(data); // float used as it is for now FR Float.parseFloat(data)
        } else if (data.matches("(-?[0-9]+)") && data.length() > 9) { // Type LONG_NUMBER
            setType(Type.LONG_NUMBER);
            setData(Long.parseLong(data));
        } else if (data.matches("(-?[0-9]+)")) { // Type NUMBER
            setType(Type.NUMBER);
            setData(Integer.parseInt(data));
        } else if (data.startsWith("'")) { // Type STRING
            setType(Type.STRING);
            setData(data);
        } else if (data.startsWith("[")) { // Type LIST
            setType(Type.LIST);
            setData(getListData(data));
        } else if (data.startsWith("(")) { // Type STRINGLIST
            setType(Type.STRINGLIST);
            setData(getStringListData(data));
        } else if (data.startsWith("{")) { // Type BINARY
            setType(Type.BINARY);
            setData(data); // why remove {}? data is not parsable anyway. FR .replace("{", "").replace("}", "")
        } else if (data.startsWith("<")) { // Type MAP
            setType(Type.MAP);
            setData(getMap(data));
        } else { // Type STRING
            setType(Type.STRING);
            setData(data);
        }
    }

    /**
     * getMap method is used for
     * 
     * @param data2
     * @return
     */
    private List<Map<String, String>> getMap(String data) {
        // data = data.replace("<", "").replace(">", "");
        if (data.isEmpty()) {
            return new LinkedList<>();
        }
        String[] lines;
        if (data.contains(CRLF)) {
            lines = data.split(CRLF);
        } else {
            lines = getSpaceSplit(data);
        }
        List<Map<String, String>> dataMap = new LinkedList<>();
        Map<String, String> innerMap = new LinkedHashMap<>();
        for (int i = 1; i < lines.length; i++) { // 0 is item
            if (lines[i].trim().isEmpty()) {
                continue;
            } else if (lines[i].contains("item")) {
                innerMap = new LinkedHashMap<>();
                innerMap.put("item", lines[i]);
            } else if (lines[i].contains("end")) {
                dataMap.add(innerMap);
                innerMap.put("end", lines[i]);
            } else {
            	DFMParser parser = new DFMParser();
                String[] kv = parser.getStringKeyValue(lines, i);
                // try {
                if (kv != null) {
                    innerMap.put(kv[0].substring(0, kv[0].length() - 1), kv[1]); // kv[0].substring(0, kv[0].length() - 1) for extra space
                }
                // } catch (NullPointerException e) {
                // System.out.println();
                // }
            }
        }
        return dataMap;
    }

    private String[] getSpaceSplit(String data) {
        String[] opt = data.split(" ");
        int max = 1, currMax = 0, currMin = opt.length;
        for (int i = 0; i < opt.length; i++) {
            if (opt[i].isEmpty()) {
                max++;
            } else {
                if (max > 1) {
                    currMin = Math.min(currMin, max);
                }
                currMax = Math.max(max, currMax);
                max = 1;
            }
        }
        if (!data.isEmpty()) {
            opt = data.split(" {" + currMin + "," + currMax + "}");
        }
        String minSpace = getSpace(currMin), maxSpace = getSpace(currMax);
        for (int i = 0; i < opt.length; i++) {
            if (opt[i].equals("item") || opt[i].equals("end")) {
                opt[i] = minSpace + opt[i];
            } else {
                opt[i] = maxSpace + opt[i];
            }
        }
        return opt;
    }

    public static String getSpace(int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }

    /**
     * getTListData method is used for
     * 
     * @param data2
     * @return
     */
    private List<String> getStringListData(String data) {
        if (data.equals("()")) {
            return Arrays.asList(new String[] {});
        }
        // data = data.replace("(", "").replace(")", "");
        if (data.contains(CRLF)) {
            return Arrays.asList(data.split(CRLF));
        } else {
            return Arrays.asList(getSpaceSplit(data));
        }
    }

    /**
     * getSetData method is used for
     * 
     * @param data2
     * @return
     */
    private List<String> getListData(String data) {
        data = data.replace("[", "").replace("]", "").replace(CRLF, ""); // TODO check if this is ok
        return Arrays.asList(data.split(", "));
    }

    /**
     * getType method is the getter for type
     *
     * @return type
     */
    public Type getType() {
        return type;
    }

    /**
     * setType method is the setter for type
     *
     * @param type
     */
    public void setType(Type type) {
        this.type = type;
    }

    /**
     * getData method is the getter for data
     *
     * @return data
     */
    @SuppressWarnings("unchecked")
    public Object getRawData() {
        if (getType().equals(Type.STRING)) { // Type STRING
            return getData().toString();
        } else if (getType().equals(Type.BOOLEAN)) { // Type BOOLEAN
            return Boolean.valueOf(getData().toString());
        } else if (getType().equals(Type.LIST)) { // Type LIST
            return (List<String>) getData();
        } else if (getType().equals(Type.STRINGLIST)) { // Type STRINGLIST
            return (List<String>) getData();
        } else if (getType().equals(Type.BINARY)) { // Type BINARY
            return getData().toString();
        } else if (getType().equals(Type.MAP)) { // Type MAP
            return (List<Map<String, String>>) getData();
        } else if (getType().equals(Type.LONG_NUMBER)) { // Type LONG_NUMBER
            return Long.valueOf(getData().toString());
        } else if (getType().equals(Type.NUMBER)) { // Type NUMBER
            return Integer.valueOf(getData().toString());
        } else if (getType().equals(Type.FLOAT)) { // Type FLOAT
            return getData().toString();
        } else {
            return null;
        }
    }

    /**
     * setData method is the setter for data
     *
     * @param data
     */
    public Object getData() {
        return data;
    }

    /**
     * setData method is the setter for data
     *
     * @param data
     */
    public void setData(Object data) {
        this.data = data;
    }

    @SuppressWarnings("unchecked")
    @Override
    public String toString() {
        if (getType().equals(Type.STRING)) { // Type STRING
            return getData().toString();
        } else if (getType().equals(Type.BOOLEAN)) { // Type BOOLEAN
            return getData().toString().equals("true") ? "True" : "False";
        } else if (getType().equals(Type.LIST)) { // Type LIST
            return getListAsString((List<String>) getData());
        } else if (getType().equals(Type.STRINGLIST)) { // Type STRINGLIST
            return getStringListAsString((List<String>) getData());
        } else if (getType().equals(Type.BINARY)) { // Type BINARY
            return getData().toString();
        } else if (getType().equals(Type.MAP)) { // Type MAP
            return getMapAsString((List<Map<String, String>>) getData());
        } else if (getType().equals(Type.LONG_NUMBER)) { // Type LONG_NUMBER
            return Long.toString((Long) getData());
        } else if (getType().equals(Type.NUMBER)) { // Type NUMBER
            return Integer.toString((Integer) getData());
        } else if (getType().equals(Type.FLOAT)) { // Type FLOAT
            return getData().toString(); // Float is used as it is as for now. Data format mismatch FR Float.toString((Float) getData());
        } else {
            return null;
        }
    }

    private String getMapAsString(List<Map<String, String>> data) {
        if (data.size() == 0) {
            return "<>";
        }
        StringBuilder sb = new StringBuilder();
        final int min = 0, max = data.size() - 1;
        AtomicInteger ai = new AtomicInteger();
        data.forEach(entry -> {
            entry.forEach((k, v) -> {
                if (k.equals("end")) {
                    sb.append(v.split("end")[0] + "end" + (ai.get() == max ? ">" : System.lineSeparator()));
                } else if (k.equals("item")) {
                    sb.append((ai.get() == min ? "<" : v.split("item")[0]) + "item" + System.lineSeparator());
                } else {
                    sb.append(k + " = " + v + System.lineSeparator());
                }
            });
            ai.incrementAndGet();
        });
        return sb.toString();
    }

    private String getStringListAsString(List<String> data) {
        if (data.size() == 0) {
            return "()";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        // if(data.get(0).trim().equals("(")){
        // data.remove(0); // deleting the open brace
        // }
        for (int i = 1; i < data.size(); i++) {
            String entry = data.get(i);
            sb.append(System.lineSeparator() + entry /*(entry.startsWith(" ") ? entry.substring(2, entry.length()) : entry)*/);
        }
        // data.forEach(entry -> {
        // // if (!entry.trim().isEmpty()) { // y tho?
        // sb.append(entry.startsWith(" ") ? entry.substring(1, entry.length()) : entry);
        // // }
        // });
        // sb.replace(sb.length() - 2, sb.length(), "");
        // sb.append(")");
        return sb.toString();
    }

    private String getListAsString(List<String> data) {
        if (data.size() == 0) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        data.forEach(entry -> {
            sb.append(entry + ", ");
        });
        sb.replace(sb.length() - 2, sb.length(), "");
        sb.append("]");
        return sb.toString();
    }

}
