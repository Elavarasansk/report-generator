package org.intraweb.tools.worksheet.controller;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;


public class JavaTest {
	public static void main(String[] args) throws EncryptedDocumentException, IOException, InterruptedException {
		FileUtils.moveDirectory(new File("D:\\TEST\\NEW"), new File("D:\\TEST\\MOVED"));
	}
}
