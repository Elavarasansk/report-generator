package org.intraweb.tools.worksheet.service;

public class RunDpr {

	public static void main(String[] args)   {
		String path = "CCM/CCMCOM/iomanage/repaycancel/CmComRepayCancelProc.dpr";
		
		System.out.println(path.replace("/", "\\"));
	}

}
