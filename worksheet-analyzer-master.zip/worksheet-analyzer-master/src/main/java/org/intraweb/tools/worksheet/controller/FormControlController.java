package org.intraweb.tools.worksheet.controller;

import org.intraweb.tools.worksheet.service.FormControlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
@RequestMapping("form/")
public class FormControlController{
	
	@Autowired
	private FormControlService formControlService;
	
	@GetMapping("form_control/")
	public void handleFormDetails() {
		formControlService.getFormControlDetails();
	}
	
	@GetMapping("download/csv")
	public void downloadCSV(@RequestParam("file") MultipartFile[] uploadFiles) {
		formControlService.getFormControlDetails();
	}
}