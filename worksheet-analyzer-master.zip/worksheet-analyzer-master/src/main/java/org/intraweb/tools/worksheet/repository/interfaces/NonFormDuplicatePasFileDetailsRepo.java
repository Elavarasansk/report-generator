package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.NonFormDuplicatePasDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface NonFormDuplicatePasFileDetailsRepo extends MongoRepository<NonFormDuplicatePasDetails, String>{
	
}
