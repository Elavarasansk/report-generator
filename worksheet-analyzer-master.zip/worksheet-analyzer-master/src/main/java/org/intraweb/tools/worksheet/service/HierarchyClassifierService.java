package org.intraweb.tools.worksheet.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.worksheet.entity.DprBasedPasFileHierarchy;
import org.intraweb.tools.worksheet.entity.PasFileHierarchy;
import org.intraweb.tools.worksheet.entity.WorksheetLocalPath;
import org.intraweb.tools.worksheet.repository.interfaces.DprbasedPasFileHierarchyRepo;
import org.intraweb.tools.worksheet.repository.interfaces.PasFileHierarchyRepo;
import org.intraweb.tools.worksheet.repository.interfaces.WorksheetLocalPathRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class HierarchyClassifierService  {

	@Autowired
	private PasFileHierarchyRepo pasFileHierarchyRepo;

	@Autowired
	private DprbasedPasFileHierarchyRepo dprbasedPasFileHierarchyRepo;
	
	@Autowired
	private WorksheetLocalPathRepo worksheetLocalPathRepo;

	String IDENTIFIER_CONST =  "->";
	String filePath = "D:\\Workspace\\Eclipse\\spring-mongo\\src\\main\\resources\\hierarchyWorkbook.xls";


	public File multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException {
		String fileName = multipart.getOriginalFilename();
		log.info("Multipart File Worksheet " + fileName);
		File convFile = new File(System.getProperty("java.io.tmpdir") + "/" + fileName);
		multipart.transferTo(convFile);
		return convFile;
	}
	
	public void findAllDprHierachy() throws InvalidFormatException, IllegalStateException, IOException  {
		List<WorksheetLocalPath> worksheetPathList = worksheetLocalPathRepo.findAll();
		
		for(WorksheetLocalPath workSheet : worksheetPathList) {
			File workBookfile = new File(workSheet.getWorksheetPath());
			hierarchyByDpr(workBookfile, workSheet.getDprName());
		}
	}


	public DprBasedPasFileHierarchy hierarchyByDpr(File workBookfile, String dprName) throws InvalidFormatException, IllegalStateException, IOException {
		/*File workBookfile = multipartToFile(multipart);
		String fName = workBookfile.getName();

		String dprName = fName.split("Worksheet_")[1];
		int x = dprName.lastIndexOf('_');*/
		
	
		Workbook hierarchyBook = WorkbookFactory.create(workBookfile);
		try {
			for(Sheet fileSheet:hierarchyBook) {
				switch(fileSheet.getSheetName()) {
					case "FileList":
						return getBookFile(fileSheet, dprName);
				}
			}
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} finally {
			hierarchyBook.close();
		}

		return null;
	}

	public List<PasFileHierarchy> getHierarchyData() {
		return pasFileHierarchyRepo.findAll();
	}

	public  DprBasedPasFileHierarchy getBookFile(Sheet fileSheet, String dprName) {
		DataFormatter formatData = new DataFormatter();
		
		int isFormCol = 4;

		int startRow = 12;
		int endRow = fileSheet.getLastRowNum();

		int startCol = 20;
		int endCol = 33;

		int fileNameCol = 3;
		int directoryCol = 2;

		List<PasFileHierarchy> pasList = new ArrayList<>();

		log.info("Computing Hierarchy for - " +dprName);
		for(int currRow = startRow;currRow<=endRow;currRow++) {
			PasFileHierarchy pasBuilder = PasFileHierarchy.builder().build();
			Row rowModel = fileSheet.getRow(currRow);

			String directoryType = formatData.formatCellValue(rowModel.getCell(directoryCol));;
			if(directoryType.equalsIgnoreCase("accommon") || StringUtils.isEmpty(directoryType)) {
				continue;
			}
			
			Cell isFormTrue = fileSheet.getRow(currRow).getCell(isFormCol);
			String isDelphiForm = formatData.formatCellValue(isFormTrue);
			if(!isDelphiForm.toLowerCase().equals("true")) {
				continue;
			}
			
			for(int curCol=startCol; curCol<=endCol; curCol++) {
				//				Row rowModel = fileSheet.getRow(currRow);

				String currData = formatData.formatCellValue(rowModel.getCell(curCol));

				/*if(StringUtils.isEmpty(currData)) {
					continue;
				}*/

				if(!StringUtils.isEmpty(currData) && currData.equals(IDENTIFIER_CONST)) {
					String fileName = formatData.formatCellValue(rowModel.getCell(fileNameCol/*curCol+1*/));
					String parentName = checkAndFindParent(fileSheet, startRow, currRow-1, startCol, curCol-1);
					String absoluteFilePath = formatData.formatCellValue(rowModel.getCell(endCol+1));
					if(StringUtils.isNotEmpty(absoluteFilePath))
						absoluteFilePath = absoluteFilePath.replace("\\", "/");					
					pasBuilder.setFileName(fileName);
					pasBuilder.setAbsoluteFilePath(absoluteFilePath);
					if(StringUtils.isNotEmpty(parentName)) {
						pasBuilder.setChild(true);
						pasBuilder.setParentFile(parentName);
					}
					pasList.add(pasBuilder);
					break;
				}

				if(curCol == endCol) {
					String absoluteFilePath = formatData.formatCellValue(rowModel.getCell(endCol+1));
					if(StringUtils.isNotEmpty(absoluteFilePath))
						absoluteFilePath = absoluteFilePath.replace("\\", "/");	
					String fileName = formatData.formatCellValue(rowModel.getCell(fileNameCol/*curCol+1*/));
					pasBuilder.setFileName(fileName);
					pasBuilder.setAbsoluteFilePath(absoluteFilePath);
					pasBuilder.setParent(true);
					pasList.add(pasBuilder);
				}
			}
		}
		System.out.println(pasList);
		List<PasFileHierarchy> allFileHierachy = formTreeStructure(pasList);

		DprBasedPasFileHierarchy dprHier = DprBasedPasFileHierarchy.builder()
				.dprName(dprName)
				.allFileHierarchy(allFileHierachy)
				.build();

		if(dprbasedPasFileHierarchyRepo.existsByDprName(dprName)) {
			dprbasedPasFileHierarchyRepo.deleteByDprName(dprName);
		}

		return dprbasedPasFileHierarchyRepo.save(dprHier);
	}

	public  String checkAndFindParent(Sheet fileSheet, int startRow, int currRow, int startCol, int childCol) {
		DataFormatter formatData = new DataFormatter();
		int fileNameCol = 3;
		int directoryCol = 2;
		/*if(startRow == currRow) {
			return null;
		}*/
		String parentName = null;

		for(int row=currRow; row>=startRow; row--) {
			Row rowModel = fileSheet.getRow(row);

			String directoryType = formatData.formatCellValue(rowModel.getCell(directoryCol));;
			if(directoryType.equalsIgnoreCase("accommon")) {
//				continue;
				return parentName;
			}

			for(int col=childCol; col>=startCol; col--) {
				//				Row rowModel = fileSheet.getRow(row);
				String rowData = formatData.formatCellValue(rowModel.getCell(col));

				if(StringUtils.isEmpty(rowData)) {
					continue;
				}

				if(rowData.equals(IDENTIFIER_CONST)) {
					parentName = formatData.formatCellValue(rowModel.getCell(fileNameCol/*col+1*/));
					return parentName;
				}
			}
		}
		return parentName;
	}

	private List<PasFileHierarchy> formTreeStructure(List<PasFileHierarchy> pasList) {
		Map<String, PasFileHierarchy> fileBasedMap = new HashMap<>();
		pasList.forEach(hierarchy -> fileBasedMap.put(hierarchy.getFileName(), hierarchy));

		pasList.forEach(hierarchy -> {
			String currFileName = hierarchy.getFileName();
			String parentName = fileBasedMap.get(currFileName).getParentFile();

			if(!StringUtils.isEmpty(parentName)) {
				fileBasedMap.get(parentName).setParent(true);
				List<PasFileHierarchy> x = fileBasedMap.get(parentName).getChildEntry();
				if(CollectionUtils.isEmpty(x)) {
					x = new ArrayList<>();
				}
				x.add(fileBasedMap.get(currFileName));
				fileBasedMap.get(parentName).setChildEntry(x);

			} else {
				fileBasedMap.get(currFileName).setParent(true);
			}
		});

		List<PasFileHierarchy> formedTreeStructure = new ArrayList<>();

		for(Map.Entry<String, PasFileHierarchy> entry : fileBasedMap.entrySet()) {
			PasFileHierarchy mappedHierarchy = entry.getValue();
			if(mappedHierarchy.isParent() && !mappedHierarchy.isChild()) {
				formedTreeStructure.add(mappedHierarchy);	
			}
		}

		System.out.println(formedTreeStructure);

		//		pasFileHierarchyRepo.saveAll(formedTreeStructure);

		return formedTreeStructure;
	}
}
