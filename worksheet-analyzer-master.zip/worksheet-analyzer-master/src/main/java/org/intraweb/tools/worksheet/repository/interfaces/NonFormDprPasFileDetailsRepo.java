package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.NonFormDprPasFileDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface NonFormDprPasFileDetailsRepo extends MongoRepository<NonFormDprPasFileDetails, String>{
	
}
