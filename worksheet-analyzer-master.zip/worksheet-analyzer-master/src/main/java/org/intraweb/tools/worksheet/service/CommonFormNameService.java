package org.intraweb.tools.worksheet.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.worksheet.dto.PasPathFinder;
import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.intraweb.tools.worksheet.repository.interfaces.DuplicatePasFileDetailsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
public class CommonFormNameService {

    @Autowired
    private DuplicatePasFileDetailsRepo duplicatePasFileDetailsRepo;

    @Value("classpath:path_needed.xlsx")
    Resource pathNeededResource;

    public void persistPasName() {
        List<DuplicatePasDetails> pasFileDetails = duplicatePasFileDetailsRepo.findAll();
        pasFileDetails.forEach(x -> {
            String[] splitPath = x.getPasFileName().toString().split("\\\\");
            x.setPasName(splitPath[splitPath.length-1].toLowerCase());
        });
        duplicatePasFileDetailsRepo.deleteAll();
        duplicatePasFileDetailsRepo.saveAll(pasFileDetails);
    }

    public void getFormsByName() {
        try {
            InputStream pathNeededStream = pathNeededResource.getInputStream();
            Workbook hfssWorkBook = WorkbookFactory.create(pathNeededStream);
            for(Sheet workSheet: hfssWorkBook) {
                String sheetName = workSheet.getSheetName();

                switch(sheetName) {
                    case "Onlyin1path":
                        writeToExcelSheet(identifyFormNames(workSheet),"onlyin1path");
                        break;

                    case "more_than_one_path":
                        writeToExcelSheet(identifyFormNames(workSheet), "multipath");
                        break;
                }
            }
        } catch(IOException e) {

        }
    }


    public List<PasPathFinder> identifyFormNames(Sheet workSheet) {
        int startRow = 0;
        int lastRow = workSheet.getLastRowNum();
        DataFormatter dataFormatter = new DataFormatter();
        Set<String> pasFileNameSet = new HashSet<String>();


        Map<String, List<String>> suggestPasPathMap = new HashMap<>();
        for(int curRow=0; curRow<lastRow; curRow++) {
            Cell cellData = workSheet.getRow(curRow).getCell(0);
            String columnName =  dataFormatter.formatCellValue(cellData);
            String pasFileName = columnName.split("_")[0];
            pasFileNameSet.add(pasFileName.toLowerCase());

            List<String> columnNameList = new ArrayList<>();
            columnNameList.add(columnName);

            if(suggestPasPathMap.get(pasFileName.toLowerCase()) != null) {
                columnNameList.addAll(suggestPasPathMap.get(pasFileName.toLowerCase()));
            }
            suggestPasPathMap.put(pasFileName.toLowerCase(), columnNameList);
        }

        List<DuplicatePasDetails> dupPasDetails = duplicatePasFileDetailsRepo.findByPasNameInIgnoreCase(new ArrayList<>(pasFileNameSet));

        List<PasPathFinder> pasPathFinderList = new ArrayList<>();
        dupPasDetails.stream().forEach(x -> {
            String pasName = x.getPasName();
            String filePath = x.getPasFileName();
            String[] originalFileName = x.getPasFileName().split("\\\\");
            List<String> dprList = x.getDprs();

            dprList.stream().forEach(dprName -> {
                List<String> pluginCompName = suggestPasPathMap.get(pasName);
                pluginCompName.forEach(compName -> {
                    pasPathFinderList.add(PasPathFinder.builder()
                            .pluginCompName(compName)
                            .dprName(dprName)
                            .fileName(originalFileName[originalFileName.length-1])
                            .filePath(filePath)
                            .build());
                });
            });
        });
        return pasPathFinderList;

        //                public Map<String,List<DuplicatePasDetails>> identifyFormNames(Sheet workSheet) {
        /*Map<String,List<DuplicatePasDetails>> dupPasPathMap  = new HashMap<>();
        dupPasPathMap = dupPasDetails.stream().collect(Collectors.groupingBy(DuplicatePasDetails::getPasName, Collectors.toList()));
        return dupPasPathMap;*/
    }


    private void writeToExcelSheet(List<PasPathFinder> dupPasPathMap, String xlsName) {
        int rowNum = 0;
        Workbook pasNamePathFinder;
        try {
            pasNamePathFinder = WorkbookFactory.create(true);
            Sheet catchBlockSheet = pasNamePathFinder.createSheet(xlsName);

            Row headerRow = catchBlockSheet.createRow(rowNum++);
            Cell pluginCompNameHead = headerRow.createCell(0);
            Cell fileNameHead = headerRow.createCell(1);
            Cell filePathHead = headerRow.createCell(2);
            Cell dprNameHead = headerRow.createCell(3);

            pluginCompNameHead.setCellValue("Plugin Name");
            fileNameHead.setCellValue("FileName");
            filePathHead.setCellValue("Path");
            dprNameHead.setCellValue("DprName");


            for(PasPathFinder x:dupPasPathMap) {
                Row columnRow = catchBlockSheet.createRow(rowNum++);
                Cell pluginCompName = columnRow.createCell(0);
                Cell fileName = columnRow.createCell(1);
                Cell filePath = columnRow.createCell(2);
                Cell dprName = columnRow.createCell(3);

                pluginCompName.setCellValue(x.getPluginCompName());
                fileName.setCellValue(x.getFileName());
                filePath.setCellValue(x.getFilePath());
                dprName.setCellValue(x.getDprName());
            }

            FileOutputStream out = new FileOutputStream(
                    new File("D:\\Nayana\\PasPathfinder\\"+xlsName+".xlsx"));
            pasNamePathFinder.write(out);
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /*int rowNum = 0;
    private void writeToExcelSheet(Map<String, List<DuplicatePasDetails>> dupPasPathMap, String xlsName) {

        Workbook pasNamePathFinder;
        try {
            pasNamePathFinder = WorkbookFactory.create(true);
            Sheet catchBlockSheet = pasNamePathFinder.createSheet(xlsName);

            Row headerRow = catchBlockSheet.createRow(rowNum++);
            Cell fileNameHead = headerRow.createCell(0);
            Cell pathDetailsHead = headerRow.createCell(1);

            fileNameHead.setCellValue("Common FileName");
            pathDetailsHead.setCellValue("PasPathName - DprName");

            dupPasPathMap.entrySet().forEach(x -> {
                Row columnRow = catchBlockSheet.createRow(rowNum++);
                Cell fileName = columnRow.createCell(0);
                Cell pasPathDpr = columnRow.createCell(1);

                String[] splitName = x.getValue().get(0).getPasFileName().split("\\\\");
                String name = splitName[splitName.length-1];
                fileName.setCellValue(name);

                String pasPathData =  x.getValue().stream().map(data -> data.getDprs().get(0) + "   -    " +data.getPasFileName()).collect(Collectors.joining("\n"));
                pasPathDpr.setCellValue(pasPathData);
            });

            FileOutputStream out = new FileOutputStream(
                    new File("D:\\Nayana\\PasPathfinder\\"+xlsName+".xlsx"));
            pasNamePathFinder.write(out);
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }*/



}
