package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.FormParentChildRelationEntity;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface FormParentChildRelationRepo extends MongoRepository<FormParentChildRelationEntity, String>{

	FormParentChildRelationEntity findByFormName(String formName);
  
}
