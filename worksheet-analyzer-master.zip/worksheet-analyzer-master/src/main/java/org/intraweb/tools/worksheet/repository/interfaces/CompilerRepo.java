package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.CompileStatusEntity;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface CompilerRepo extends MongoRepository<CompileStatusEntity, String>{
	
 public CompileStatusEntity findByDprName(String dprName); 
	
	

}
