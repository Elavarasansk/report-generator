package org.intraweb.tools.worksheet.service;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullResult;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.TextProgressMonitor;
import org.eclipse.jgit.transport.TrackingRefUpdate;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.intraweb.tools.worksheet.dto.GitPullResponse;
import org.intraweb.tools.worksheet.dto.RefsTrackingUpdate;
import org.intraweb.tools.worksheet.entity.VersionControlStatus;
import org.intraweb.tools.worksheet.repository.interfaces.VersionControlStatusRepo;
import org.intraweb.tools.worksheet.utility.GITConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GitSyncService {

	@Value("${acgit.url}")
	private String acgitUrl;

	@Value("${acgit.user.name}")
	private String acgitUserName;

	@Value("${acgit.user.password}")
	private String acgitPassword;

	@Autowired
	private VersionControlStatusRepo versionControlStatusRepo; 

	public void multiRepoSyncThread() {

		Thread cacThread = new Thread(new Runnable() {
			@Override
			public void run() {
				cacGitPull();
			}
		});

		Thread camThread = new Thread(new Runnable() {
			@Override
			public void run() {
				camGitPull();
			}
		});

		Thread cbmThread = new Thread(new Runnable() {
			@Override
			public void run() {
				cbmGitPull();
			}
		});

		Thread ccmThread = new Thread(new Runnable() {
			@Override
			public void run() {
				ccmGitPull();
			}
		});

		Thread cfmThread = new Thread(new Runnable() {
			@Override
			public void run() {
				cfmGitPull();
			}
		});


		Thread documentThread = new Thread(new Runnable() {
			@Override
			public void run() {
				documentGitPull();
			}
		});

		cacThread.start();
		camThread.start();
		cbmThread.start();
		ccmThread.start();
		cfmThread.start();
		documentThread.start();
	}

	public VersionControlStatus syncServiceStart(String verType, String module) {

		VersionControlStatus vcs = VersionControlStatus.builder()
				.versionType(verType)
				.module(module)
				.syncInProgress(true)
				.lastSyncStartTime(new Date())
				.lastSyncEndTime(null)
				.build();

		VersionControlStatus existingVersionInfo = versionControlStatusRepo.findByVersionTypeAndModule(verType, module);

		if(!ObjectUtils.isEmpty(existingVersionInfo)) {
			vcs.setId(existingVersionInfo.getId());
		}

		return versionControlStatusRepo.save(vcs);
	}

	public void syncServiceEnd(VersionControlStatus vcs, GitPullResponse response) {
		vcs.setSyncInProgress(false);
		vcs.setLastSyncEndTime(new Date());
		vcs.setGitPullResponse(response);
		versionControlStatusRepo.save(vcs);
	}

	public GitPullResponse cacGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File cacRepoPath = new File(GITConstants.HUE_DEVELOP_AC + GITConstants.CAC_REPO);
		if(cacRepoPath.exists()) {
			VersionControlStatus vcs = syncServiceStart(GITConstants.AC_GIT, GITConstants.CAC);
			response = pullExistingRepo(cacRepoPath);
			syncServiceEnd(vcs, response);
		} else {
			cloneNonExistingRepo(GITConstants.CAC_REPO);
		}
		return response;
	}

	public GitPullResponse camGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File camRepoPath = new File(GITConstants.HUE_DEVELOP_AC + GITConstants.CAM_REPO);

		if(camRepoPath.exists()) {
			VersionControlStatus vcs = syncServiceStart(GITConstants.AC_GIT, GITConstants.CAM);
			response = pullExistingRepo(camRepoPath);
			syncServiceEnd(vcs, response);
		} else {
			cloneNonExistingRepo(GITConstants.CAM_REPO);
		}
		return response;
	}

	public GitPullResponse cbmGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File cbmRepoPath = new File(GITConstants.HUE_DEVELOP_AC + GITConstants.CBM_REPO);

		if(cbmRepoPath.exists()) {
			VersionControlStatus vcs = syncServiceStart(GITConstants.AC_GIT, GITConstants.CBM);
			response = pullExistingRepo(cbmRepoPath);
			syncServiceEnd(vcs, response);
		} else {
			cloneNonExistingRepo(GITConstants.CBM_REPO);
		}
		return response;
	}

	public GitPullResponse ccmGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File ccmRepoPath = new File(GITConstants.HUE_DEVELOP_AC + GITConstants.CCM_REPO);

		if(ccmRepoPath.exists()) {
			VersionControlStatus vcs = syncServiceStart(GITConstants.AC_GIT, GITConstants.CCM);
			response = pullExistingRepo(ccmRepoPath);
			syncServiceEnd(vcs, response);
		} else {
			cloneNonExistingRepo(GITConstants.CCM_REPO);
		}
		return response;
	}

	public GitPullResponse cfmGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File cfmRepoPath = new File(GITConstants.HUE_DEVELOP_AC + GITConstants.CFM_REPO);

		if(cfmRepoPath.exists()) {
			VersionControlStatus vcs = syncServiceStart(GITConstants.AC_GIT, GITConstants.CFM);
			response = pullExistingRepo(cfmRepoPath);
			syncServiceEnd(vcs, response);
		} else {
			cloneNonExistingRepo(GITConstants.CFM_REPO);
		}
		return response;
	}

	public GitPullResponse documentGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File cfmRepoPath = new File(GITConstants.HUE_DEVELOP_AC + GITConstants.DOCUMENT_REPO);

		if(cfmRepoPath.exists()) {
			VersionControlStatus vcs = syncServiceStart(GITConstants.AC_GIT, GITConstants.DOCUMENT);
			response = pullExistingRepo(cfmRepoPath);
			syncServiceEnd(vcs, response);
		} else {
			cloneNonExistingRepo(GITConstants.DOCUMENT_REPO);
		}
		return response;
	}

	private void cloneNonExistingRepo(String repo) {
		UsernamePasswordCredentialsProvider credsProvider = new UsernamePasswordCredentialsProvider(acgitUserName, acgitPassword);
		log.info("Cloning the repo - "+repo+" Started @" + new Date(System.currentTimeMillis()));
		try {
			Git.cloneRepository()
			.setURI(acgitUrl+repo)
			.setCredentialsProvider(credsProvider)
			.setDirectory(new File(GITConstants.HUE_DEVELOP))
			.call();
			log.info("Cloning the repo - "+repo+" Completed @" + new Date(System.currentTimeMillis()));
		} catch (GitAPIException e) {
			e.printStackTrace();
			log.error("Cloning the repo - "+repo+" failed " + new Date(System.currentTimeMillis()));
		}
	}

	private GitPullResponse pullExistingRepo(File repoPath) {
		GitPullResponse response = GitPullResponse.builder().build();
		String repoName = repoPath.getPath();

		File lockFile = new File(repoName + "\\" + GITConstants.INDEX_LOCK_FILE);
		if(lockFile.exists()) {
			lockFile.delete();
		}

		UsernamePasswordCredentialsProvider credsProvider = new UsernamePasswordCredentialsProvider(acgitUserName, acgitPassword);
		log.info("Started @ git pull - "+repoName+" " + new Date(System.currentTimeMillis()));
		try {
			Git localGit = Git.open(repoPath);
			PullResult pullRes = localGit.pull()
					.setProgressMonitor(new TextProgressMonitor(new PrintWriter(System.out)))
					.setRemote(GITConstants.ORIGIN)
					.setCredentialsProvider(credsProvider).call();
			log.info("Result "+ pullRes.getMergeResult());
			log.info("Completed @ git pull - "+repoName+" " + new Date(System.currentTimeMillis()));
			localGit.close();
			response = processPullResult(pullRes);
		} catch (GitAPIException | IOException e) {
			log.error("Error Fetching the repo "+ e.getMessage());
		}
		return response;
	}

	private GitPullResponse processPullResult(PullResult pullResult) {
		Collection<TrackingRefUpdate> trackingRef = pullResult.getFetchResult().getTrackingRefUpdates();

		List<RefsTrackingUpdate> trackingUpdate = trackingRef.stream().map(y ->RefsTrackingUpdate.builder()
				.remoteName(y.getRemoteName())
				.trackResult(y.getResult().toString())
				.build()).collect(Collectors.toList());

		return GitPullResponse.builder()
				.fetchFrom(pullResult.getFetchedFrom())
				.mergeSuccess(pullResult.getMergeResult().getMergeStatus().isSuccessful())
				.pullSuccess(pullResult.isSuccessful())
				.remoteUri(pullResult.getFetchResult().getURI().toString())
				.trackingUpdate(trackingUpdate)
				.build();
	}

}

//TODO: /*.advertisedRefs(pullResult.getFetchResult().getAdvertisedRefs())*/
//FetchResult fetchRes = localGit.fetch().setRemote(GITConstants.ORIGIN).setCredentialsProvider(credsProvider).call();
