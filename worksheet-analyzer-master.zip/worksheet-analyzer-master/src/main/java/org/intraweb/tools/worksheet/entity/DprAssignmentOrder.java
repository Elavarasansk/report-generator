package org.intraweb.tools.worksheet.entity;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="dpr_assignment_order_paused_2")
public class DprAssignmentOrder {
	
	@Id
	private ObjectId id;

	@Indexed(unique=true)
	private String dprName;

	private String priority;
	private String complexity;
	private String module;
	private String moduleName;
	private String dprPath;

	
	private String lableader;
	private String assignee;
	
}
