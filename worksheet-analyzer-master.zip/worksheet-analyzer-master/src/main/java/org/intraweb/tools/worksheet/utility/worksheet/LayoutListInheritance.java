package org.intraweb.tools.worksheet.utility.worksheet;

import org.intraweb.tools.worksheet.entity.WorksheetFileListEntity;

public class LayoutListInheritance {

	private void getLayoutType(WorksheetFileListEntity fileListDetails) {
		String framework = fileListDetails.getFrameWork();
		String layoutType = fileListDetails.getLayoutType();
		String layoutPattern = fileListDetails.getLayoutPattern();

		switch (framework) {
			case "TForm":
			case "TCfwRootFrame":
			case "TCfwBaseFrame":
			case "TCfwDialog":
			case "TCfwReportFrame":
				break;

			default:
				break;
		}

	}

}
