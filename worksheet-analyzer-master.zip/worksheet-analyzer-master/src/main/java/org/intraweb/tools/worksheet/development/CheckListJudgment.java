package org.intraweb.tools.worksheet.development;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.intraweb.tools.worksheet.entity.WorksheetFileListEntity;

public class CheckListJudgment {
	
	private  WorksheetFileListEntity fileListDetails;

	public CheckListJudgment(WorksheetFileListEntity fileListDetails) {
		this.fileListDetails = fileListDetails;
	}
	
	public void computeLayoutType() {	
		String framework = fileListDetails.getFrameWork();
		if(StringUtils.isNotEmpty(framework)) {
			CheckListJudgmentEnum listEnum=	CheckListJudgmentEnum.getTypePattern(framework);
			if(Objects.nonNull(listEnum)) {
				fileListDetails.setLayoutType(listEnum.getLayoutType());
				fileListDetails.setLayoutPattern(listEnum.getLayoutPattern());
				//fileListDetails.setFrameWork(listEnum.getFramework());
			}

		}
	}

	public void computeLayoutPattern() {
		String framework = fileListDetails.getFrameWork();
		String layoutPattern = fileListDetails.getLayoutType();
		if(StringUtils.isNotEmpty(framework) && StringUtils.isNotEmpty(layoutPattern)  ) {
			CheckListJudgmentEnum listEnum=	CheckListJudgmentEnum.getTypePattern(framework,layoutPattern);
			if(Objects.nonNull(listEnum)) {
				fileListDetails.setLayoutType(listEnum.getLayoutType());
				fileListDetails.setLayoutPattern(listEnum.getLayoutPattern());
				fileListDetails.setFrameWork(listEnum.getFramework());
			}

		}
	}





}
