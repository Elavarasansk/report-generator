package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.DprPasFileNewWorkSheetDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface DprPasFileNewWorkSheetDetailsRepo extends MongoRepository<DprPasFileNewWorkSheetDetails, String>{

	boolean existsByDprName(String dprName);

	void deleteByDprName(String dprName);

	
}
