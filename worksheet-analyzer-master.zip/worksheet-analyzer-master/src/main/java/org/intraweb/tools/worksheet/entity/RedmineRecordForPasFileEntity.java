package org.intraweb.tools.worksheet.entity;

import lombok.Builder;

import lombok.Data;

@Data
@Builder
public class RedmineRecordForPasFileEntity {

	private String pasFileName;
	private String assigneeName;
	private int issueId;
	private String url;
	private String status;
}
