package org.intraweb.tools.worksheet.service;

import java.io.File;

import org.intraweb.tools.worksheet.utility.GITConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNUpdateClient;
import org.tmatesoft.svn.core.wc.SVNWCClient;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

@Service
public class SvnSyncService {


	@Value("${svn.url.com}")
	private String COM;

	@Value("${svn.url.cam}")
	private String CAM;

	@Value("${svn.url.cbm}")
	private String CBM;

	@Value("${svn.url.ccm}")
	private String CCM;

	@Value("${svn.url.cfm}")
	private String CFM;

	@Value("${svn.user.name}")
	private String svnLogin;

	@Value("${svn.user.password}")
	private String svnPassword;


	public void prepareForSvnUpdate(String svnType, String module) throws SVNException {
		String svnUrl="";
		String formSvnFilePath = "C:\\HUE\\WorkSpace\\Develop\\SVN\\V";

		String svnNum = "40";
		if(svnType.equals(GITConstants.AC_SVN41)) {
			svnNum = "41";
		}

		switch (module) {
			case GITConstants.COM:
				svnUrl = COM+svnNum;
				formSvnFilePath += svnNum+"\\"+GITConstants.COM+svnNum;
				break;

			case GITConstants.CAM:
				svnUrl = CAM+svnNum;
				formSvnFilePath += svnNum+"\\"+GITConstants.CAM+svnNum;
				break;

			case GITConstants.CBM:
				svnUrl = CBM+svnNum;
				formSvnFilePath += svnNum+"\\"+GITConstants.CBM+svnNum;
				break;

			case GITConstants.CCM:
				svnUrl = CCM+svnNum;
				formSvnFilePath += svnNum+"\\"+GITConstants.CCM+svnNum;
				break;

			case GITConstants.CFM:
				svnUrl = CFM+svnNum;
				formSvnFilePath += svnNum+"\\"+GITConstants.CFM+svnNum;
				break;
		}
		updateSvn(svnUrl, formSvnFilePath);

	}

	public void updateSvn(String url, String formSvnFilePath) throws SVNException {
		SVNRepository repository = SVNRepositoryFactory.create(SVNURL.parseURIDecoded(url));
		ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(svnLogin, svnPassword);
		repository.setAuthenticationManager(authManager);

		SVNClientManager ourClientManager = SVNClientManager.newInstance();
		ourClientManager.setAuthenticationManager(authManager);

		SVNUpdateClient updateClient = ourClientManager.getUpdateClient();
		updateClient.setIgnoreExternals(true);

		SVNWCClient workingCopy = ourClientManager.getWCClient();
		long latestRevision = repository.getLatestRevision();

		workingCopy.doCleanup(new File(formSvnFilePath), false, true, false, false, false, true);
		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);
		//		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);

		System.out.print("revision info "+ latestRevision +"-------->"+ updatedRevision);
	}


}
