package org.intraweb.tools.worksheet.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.intraweb.tools.worksheet.entity.DprBasedPasFileRelation;
import org.intraweb.tools.worksheet.entity.DprPasFileNewWorkSheetDetails;
import org.intraweb.tools.worksheet.entity.DprPasFileOldWorkSheetDetails;
import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.intraweb.tools.worksheet.entity.FormIssues;
import org.intraweb.tools.worksheet.entity.PasFileFramework;
import org.intraweb.tools.worksheet.entity.RedmineRecordForPasFileEntity;
import org.intraweb.tools.worksheet.entity.WorksheetFileListEntity;
import org.intraweb.tools.worksheet.repository.interfaces.DprBasedPasFileRelationRepo;
import org.intraweb.tools.worksheet.repository.interfaces.DprPasFileNewWorkSheetDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.DprPasFileOldWorkSheetDetailsRepo;
import org.intraweb.tools.worksheet.repository.interfaces.MongoDataService;
import org.intraweb.tools.worksheet.repository.interfaces.PasFileFrameworkRepo;
import org.intraweb.tools.worksheet.utility.Constants;
import org.intraweb.tools.worksheet.utility.FilePathReader;
import org.intraweb.tools.worksheet.utility.FileWriteUtils;
import org.intraweb.tools.worksheet.utility.worksheet.LayoutPattern;
import org.intraweb.tools.worksheet.utility.worksheet.LayoutType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.taskadapter.redmineapi.RedmineException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WorksheetLayoutFillService {

    private String worksheetFilePath = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-document\\30_Worksheet\\10_template\\CAM\\Worksheet_AroFaPatReference_20190214.xls";

    @Autowired
    private DprPasFileOldWorkSheetDetailsRepo dprPasFileOldWorkSheetDetailsRepo;

    @Autowired
    private DprPasFileNewWorkSheetDetailsRepo dprPasFileNewWorkSheetDetailsRepo;

    @Autowired
    private RedmineOperationsService redmineOperationsService;

    @Autowired
    private PasFileFrameworkRepo pasFileFrameworkRepo;

    @Autowired
    private DprBasedPasFileRelationRepo dprBasedPasFileRelationRepo;

    @Autowired
    private MongoDataService mongoDataService;

    private Collection<File> cacFileCollection;
    private Collection<File> camFileCollection;
    private Collection<File> cbmFileCollection;
    private Collection<File> ccmFileCollection;
    private Collection<File> cfmFileCollection;

    @PostConstruct
    public void initPasFileCollection() {
        String[] format = new String[1];
        String cacLocalPath = "C:\\HUE\\Workspace\\Develop\\hue-ac-chennai-cac\\company_client\\delphi\\";
        String camLocalPath = "C:\\HUE\\Workspace\\Develop\\hue-ac-chennai-cam\\company_client\\delphi\\";
        String cbmLocalPath = "C:\\HUE\\Workspace\\Develop\\hue-ac-chennai-cbm\\company_client\\delphi\\";
        String ccmLocalPath = "C:\\HUE\\Workspace\\Develop\\hue-ac-chennai-ccm\\company_client\\delphi\\";
        String cfmLocalPath = "C:\\HUE\\Workspace\\Develop\\hue-ac-chennai-cfm\\company_client\\delphi\\";
        format[0] = "pas";

        Thread cacT = new Thread(new Runnable() {
            @Override
            public void run() {
                cacFileCollection = FileUtils.listFiles(new File(cacLocalPath), format, true);
            }
        });


        Thread camT = new Thread(new Runnable() {
            @Override
            public void run() {
                camFileCollection = FileUtils.listFiles(new File(camLocalPath), format, true);
            }
        });

        Thread cbmT = new Thread(new Runnable() {
            @Override
            public void run() {
                cbmFileCollection = FileUtils.listFiles(new File(cbmLocalPath), format, true);
            }
        });

        Thread ccmT = new Thread(new Runnable() {
            @Override
            public void run() {
                ccmFileCollection = FileUtils.listFiles(new File(ccmLocalPath), format, true);
            }
        });

        Thread cfmT = new Thread(new Runnable() {
            @Override
            public void run() {
                cfmFileCollection = FileUtils.listFiles(new File(cfmLocalPath), format, true);
            }
        });

        cacT.start();
        camT.start();
        cbmT.start();
        ccmT.start();
        cfmT.start();

        /*cacFileCollection = FileUtils.listFiles(new File(cacLocalPath), format, true);
		camFileCollection = FileUtils.listFiles(new File(camLocalPath), format, true);
		cbmFileCollection = FileUtils.listFiles(new File(cbmLocalPath), format, true);
		ccmFileCollection = FileUtils.listFiles(new File(ccmLocalPath), format, true);
		cfmFileCollection = FileUtils.listFiles(new File(cfmLocalPath), format, true);*/
    }

    public File multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException {
        String fileName = multipart.getOriginalFilename();
        log.info("Multipart File Worksheet " + fileName);
        File convFile = new File(System.getProperty("java.io.tmpdir") + "/" + fileName);
        multipart.transferTo(convFile);
        return convFile;
    }

    public File fillTypePattern(MultipartFile multipart) throws InvalidFormatException, IOException, RedmineException {
        // MultipartFile multipart
        File worksheetFile = multipartToFile(multipart);
        //File worksheetFile = new File(worksheetFilePath);
        List<WorksheetFileListEntity> dprPasFileDetailList = new ArrayList<>();
        Workbook workbook = WorkbookFactory.create(worksheetFile);
        for (Sheet worksheet : workbook) {
            String sheetName = worksheet.getSheetName();
            switch (sheetName) {
                case "FileList":
                    dprPasFileDetailList = getDetailsFromFileListsheet(worksheet);
                    break;
                case "EditList":
                    break;
                case "Otherimplements":
                    break;
            }
        }
        WorksheetFileListEntity workSheetEntity = dprPasFileDetailList.stream().findAny().orElse(null);
        DprPasFileOldWorkSheetDetails oldWorkSheetDetails =  DprPasFileOldWorkSheetDetails
                .builder().dprName(workSheetEntity.getDprName())
                .workSheetDetailsList(dprPasFileDetailList)
                .build();	
        if(dprPasFileOldWorkSheetDetailsRepo.existsByDprName(workSheetEntity.getDprName())) {
            dprPasFileOldWorkSheetDetailsRepo.deleteByDprName(workSheetEntity.getDprName());
        }
        dprPasFileOldWorkSheetDetailsRepo.save(oldWorkSheetDetails);
        //workbook.close();

        /* To find the framework */
        Map<String, PasFileFramework> frameworkRecMap = assignFrameworkDBRecToMap();
        for(WorksheetFileListEntity record : dprPasFileDetailList) {
            if(record.getFilePath().isEmpty()) {
                continue;
            }
            if(!record.getFrameWork().isEmpty()) {
                continue;
            }
            PasFileFramework framework = frameworkRecMap.get(record.getFilePath());
            if(Objects.nonNull(framework)) {
                if(framework.getFramework().toLowerCase().contains("cfw")) {
                    record.setFrameWork(framework.getFramework());
                    record.setOldFrameWork(framework.getFramework());
                } else  if(framework.getFramework().toLowerCase().contains("tform")) {
                    record.setFrameWork("tform");
                    record.setOldFrameWork("tform");
                } else {
                    String resFramework = iterateForFramework(record.getDprPath(), framework, frameworkRecMap).getFramework();
                    record.setFrameWork(resFramework);
                    record.setOldFrameWork(resFramework);
                }
            }
        }

        String dprName = workSheetEntity.getDprName();
        dprName = dprName.replace(".dpr", "").trim();

        DprBasedPasFileRelation fileHierarchy = dprBasedPasFileRelationRepo.findByDprName(dprName);
        Map<String, String> hierarchyMap = fileHierarchy.getRelationMap();

        List<WorksheetFileListEntity> newDprPasFileDetails = getTypePatternFromFrameWork(dprPasFileDetailList,hierarchyMap);
        // fetch redmine
        //updateRedmineDetails(newDprPasFileDetails);

        // fetch Mongo		
        updateRedmineFromMongo(newDprPasFileDetails);

        DprPasFileNewWorkSheetDetails newWorkSheetDetails =  DprPasFileNewWorkSheetDetails
                .builder().dprName(workSheetEntity.getDprName())
                .workSheetDetailsList(newDprPasFileDetails)
                .build();	
        if(dprPasFileNewWorkSheetDetailsRepo.existsByDprName(workSheetEntity.getDprName())) {
            dprPasFileNewWorkSheetDetailsRepo.deleteByDprName(workSheetEntity.getDprName());
        }
        dprPasFileNewWorkSheetDetailsRepo.save(newWorkSheetDetails);
        List<String> filePathList = newWorkSheetDetails.getWorkSheetDetailsList().stream().map(WorksheetFileListEntity::getFilePath).collect(Collectors.toList());
        Map<String, List<String>> filePathMap = mongoDataService.findDuplicatePasDetails(filePathList);
        return FileWriteUtils.writeToFile(worksheetFile, workbook,newDprPasFileDetails,filePathMap);

        /*getTypePatternFromFw(dprPasFileDetailList);*/

        /*
         * workbook.close(); log.info(worksheetFile.getName() + "Closed successfuly");
         * worksheetFile.delete();
         */
    }



    private List<WorksheetFileListEntity> getTypePatternFromFrameWork(List<WorksheetFileListEntity> pasFileDetailList, Map<String, String> hierarchyMap) {
        List<WorksheetFileListEntity> computedLayoutList = pasFileDetailList.stream()
                .map(pasFileDetails -> { 
                    WorksheetFileListEntity fileSheetEntity = pasFileDetails;
                    if( fileSheetEntity.isForm() && fileSheetEntity.isTargetForm()) {
                        try {						
                            String layoutType= fileSheetEntity.getLayoutType();
                            String framework=fileSheetEntity.getFrameWork();				
                            LayoutType layoutTypeUtils = new LayoutType(fileSheetEntity);
                            fileSheetEntity = layoutTypeUtils.computeLayoutType();	
                            updateChildrenPasFile(fileSheetEntity,hierarchyMap,pasFileDetailList);
                            LayoutPattern layoutPatternUtils = new LayoutPattern(fileSheetEntity);
                            fileSheetEntity = layoutPatternUtils.computeLayoutPattern();
                            if(StringUtils.equals(layoutType, Constants.PARTS_FRAME)) {
                                fileSheetEntity.setLayoutPattern(Constants.PARTS_FRAME);
                                fileSheetEntity.setLayoutType(Constants.PARTS_FRAME);
                                fileSheetEntity.setFrameWork(framework);								
                            }
                        } catch (Exception e) {
                        }			
                    }
                    return fileSheetEntity;
                }).collect(Collectors.toList());

        //Map<String, List<WorksheetFileListEntity>> fileMappedEntity = computedLayoutList.stream()
        //		.collect(Collectors.groupingBy(WorksheetFileListEntity::getFileName));

        return computedLayoutList;
    }


    private List<WorksheetFileListEntity> getDetailsFromFileListsheet(Sheet worksheet) {
        DataFormatter dataFormatter = new DataFormatter();

        int startRowIndex = 12;
        int endRowIndex = worksheet.getLastRowNum();

        Cell dprNameCell = worksheet.getRow(5).getCell(3);
        String dprName = dataFormatter.formatCellValue(dprNameCell);

        Cell dprPathCell = worksheet.getRow(6).getCell(3);
        String dprPath = dataFormatter.formatCellValue(dprPathCell);

        List<WorksheetFileListEntity> dprPasFileDetailList = new ArrayList<>();
        for (int i = startRowIndex; i <= endRowIndex; i++) {
            Row currentRow = worksheet.getRow(i);

            Cell isFormTrue = currentRow.getCell(Constants.isFormCol);
            Cell fileNameCell = currentRow.getCell(Constants.fileNameCol);
            Cell filePathCell = currentRow.getCell(Constants.filePathCol);
            Cell directoryCell = currentRow.getCell(Constants.directoryCol);


            Cell isTargetCell = currentRow.getCell(Constants.isTargetCol);
            Cell frameworkCell = currentRow.getCell(Constants.frameworkCol);
            Cell typeCell = currentRow.getCell(Constants.typeCol);
            Cell patternCell = currentRow.getCell(Constants.patternCol);
            Cell isBizTargetCell = currentRow.getCell(Constants.isBizTargetCol);

            //	Cell assigneeCell = currentRow.getCell(Constants.assignee);
            //	Cell link = currentRow.getCell(Constants.link);

            String directory = dataFormatter.formatCellValue(directoryCell);
            String isDelphiForm = dataFormatter.formatCellValue(isFormTrue);
            String pasFileName = dataFormatter.formatCellValue(fileNameCell);
            String pasFilePath = dataFormatter.formatCellValue(filePathCell);
            String isTarget = dataFormatter.formatCellValue(isTargetCell);
            String framework = dataFormatter.formatCellValue(frameworkCell);
            String layoutType = dataFormatter.formatCellValue(typeCell);
            String layoutPattern = dataFormatter.formatCellValue(patternCell);
            String isTargetBiz = dataFormatter.formatCellValue(isBizTargetCell);

            //	String assigneeCol = dataFormatter.formatCellValue(assigneeCell);
            //String linkCol = dataFormatter.formatCellValue(link);


            if (StringUtils.equals(directory, "accommon")  || StringUtils.isEmpty(pasFilePath)) {
                continue;
            }

            boolean isTargetImpl = StringUtils.equals(StringUtils.lowerCase(isTarget), "true")
                    || StringUtils.isEmpty(isTarget);
            boolean isFormImpl = StringUtils.equals(StringUtils.lowerCase(isDelphiForm), "true") || StringUtils.isEmpty(isDelphiForm);
            boolean isBizImpl = StringUtils.equals(StringUtils.lowerCase(isTargetBiz), "true");	

            WorksheetFileListEntity fileListSheet = WorksheetFileListEntity.builder()
                    .rowIndex(i)
                    .dprName(dprName)
                    .dprPath(dprPath)
                    .fileName(pasFileName)
                    .isForm(isFormImpl)
                    .filePath(pasFilePath)
                    .frameWork(framework)
                    .layoutType(layoutType)
                    .layoutPattern(layoutPattern)
                    .isTargetForm(isTargetImpl)
                    .oldFrameWork(framework)
                    .isTargetBiz(isBizImpl)
                    .build();
            dprPasFileDetailList.add(fileListSheet);

        }
        return dprPasFileDetailList;
    }


    private void updateChildrenPasFile(WorksheetFileListEntity fileSheetEntity, Map<String, String> hierarchyMap, List<WorksheetFileListEntity> pasFileDetailList) {
        String fileName = fileSheetEntity.getFileName().replace(".pas", "").trim();
        if(hierarchyMap.containsKey(fileName)) {
            if(StringUtils.isEmpty(hierarchyMap.get(fileName))) {
                return;
            }
            String parent = hierarchyMap.get(fileName);
            WorksheetFileListEntity parentEntity = pasFileDetailList.stream().filter(doc->StringUtils.equals(doc.getFileName(),parent)).findFirst().orElse(null);
            if(Objects.isNull(parentEntity))
                return;
            fileSheetEntity.setFrameWork(parentEntity.getOldFrameWork());
            fileSheetEntity.setLayoutType(parentEntity.getLayoutType());
            fileSheetEntity.setLayoutPattern(parentEntity.getLayoutPattern());
        }
    }

    private List<WorksheetFileListEntity> updateRedmineFromMongo(List<WorksheetFileListEntity> pasFileDetailList) throws RedmineException  {
        List<String> passFileList = pasFileDetailList.stream().map(doc->StringUtils.replace(doc.getFilePath(),"\\","/")).collect(Collectors.toList());		
        Map<String, FormIssues> result = redmineOperationsService.getDetails(passFileList);		 
        pasFileDetailList.stream().forEach(pasFileDetail->{
            if(!result.containsKey(StringUtils.replace(pasFileDetail.getFilePath(),"\\","/"))) {
                return;
            }
            FormIssues formIssue= result.get(StringUtils.replace(pasFileDetail.getFilePath(),"\\","/"));
            pasFileDetail.setAssignee(formIssue.getAssigneeName());
            pasFileDetail.setIssueId(String.valueOf(formIssue.getIssueId()));				
            pasFileDetail.setHyperLink("http://ac-conv-redmine.internal.worksap.com/redmine/issues/" + formIssue.getIssueId());
            pasFileDetail.setStatus(formIssue.getStatus());
        });

        return pasFileDetailList;

    }



    private List<WorksheetFileListEntity> updateRedmineDetails(List<WorksheetFileListEntity> pasFileDetailList) throws RedmineException {

        for(  WorksheetFileListEntity  pasFileDetail : pasFileDetailList) {
            if(pasFileDetail.isForm()) {
                String param = StringUtils.replace(pasFileDetail.getFilePath(),"\\","/");
                RedmineRecordForPasFileEntity result = redmineOperationsService.getDetails(param);
                pasFileDetail.setAssignee(result.getAssigneeName());
                pasFileDetail.setIssueId(String.valueOf(result.getIssueId()));
                pasFileDetail.setHyperLink(result.getUrl());
                pasFileDetail.setStatus(result.getStatus());
            }
        }

        return pasFileDetailList;
    }

    private PasFileFramework iterateForFramework(String dprPath, PasFileFramework dbRecord, Map<String, PasFileFramework> frameworkRecMap) throws IOException {
        String dpr = dprPath;
        String dbFramework = dbRecord.getFramework();
        //		String formattedInput = dbFramework.substring(1, dbFramework.length()).replaceAll("Frame", "Frm").replaceAll("Dialog", "Dlg") + ".pas";
        //		String input = formattedInput.contains("_") ? (formattedInput.split("_")[1].replaceAll(".pas", "") + formattedInput.split("_")[0] + ".pas") : formattedInput;
        String productLocal = FilePathReader.getProductPath(dprPath);
        String[] format = new String[1];
        format[0] = "pas";

        Collection<File> fileList = getFileCollection(productLocal);
        //		File resFile = fileList.stream().filter(file -> file.getName().equalsIgnoreCase(input)).findFirst().orElse(null);

        //		if(Objects.isNull(resFile)) {
        //			String tempInput = input.replaceAll("Frm", "Frame").replaceAll("Dlg", "Dialog"); 
        //			resFile = fileList.stream().filter(file -> file.getName().equalsIgnoreCase(tempInput)).findFirst().orElse(null);
        //		}



        File resFile = new File("");

        try {
            for(File file: fileList) {
                List<String> fileLines = FileUtils.readLines(file, "UTF-8");
                List<String> resLines = fileLines.stream().filter(line -> line.contains(dbFramework + " = class(")).collect(Collectors.toList());
                if(!resLines.isEmpty()) {
                    resFile = file;
                    break;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }



        if(Objects.nonNull(resFile) && resFile.exists()) {
            PasFileFramework dbRec = frameworkRecMap.get(resFile.getPath().substring(66, resFile.getPath().length()));
            if(Objects.nonNull(dbRec)) {
                if(dbRec.getFramework().toLowerCase().contains("cfw")) {
                    return dbRec;
                } else {
                    if(StringUtils.equals(dbRecord.getFramework(), dbRec.getFramework())) {
                        return dbRec;
                    }

                    PasFileFramework finalRec = iterateForFramework(dpr, dbRec, frameworkRecMap);
                    return finalRec;
                }
            } else {
                return PasFileFramework.builder().build();
            }
        } else {
            return PasFileFramework.builder().build();
        }
    }

    private Map<String, PasFileFramework> assignFrameworkDBRecToMap() {
        List<PasFileFramework> frameworkRecList = pasFileFrameworkRepo.findAll();
        Map<String, PasFileFramework> frameworkRecMap = frameworkRecList.stream().collect(Collectors.toMap(rec -> rec.getFilePath(), record -> record));
        return frameworkRecMap;
    }

    private Collection<File> getFileCollection(String productLocal) {
        String repo = productLocal.substring(40, 43);
        if(repo.equalsIgnoreCase("CAC")) {
            return cacFileCollection;
        } else if(repo.equalsIgnoreCase("CAM")) {
            return camFileCollection;
        } else if(repo.equalsIgnoreCase("CBM")) {
            return cbmFileCollection;
        } else if(repo.equalsIgnoreCase("CCM")) {
            return ccmFileCollection;
        } else {
            return cfmFileCollection;
        } 
    }

}


/*
	private void getTypePatternFromFw(List<WorksheetFileListEntity> dprPasFileDetailList) {
		dprPasFileDetailList.stream().forEach(fileListDetails -> {
			String framework = fileListDetails.getFrameWork();


			switch (framework) {
				case "TForm":
				case "TCfwRootFrame":
				case "TCfwBaseFrame":
				case "TCfwDialog":
				case "TCfwReportFrame":
					checkLayoutPattern(fileListDetails);
					break;
				default:
					if (StringUtils.isEmpty(framework)) {
						break;
					}
					CheckListJudgment c = new CheckListJudgment();
					CheckListResultEntity resultEntity = c.getTypePattern(framework);
					if (Objects.nonNull(resultEntity)) {
						fileListDetails.setLayoutType(resultEntity.getLayoutType());
						fileListDetails.setLayoutPattern(resultEntity.getLayoutPattern());
						fileListDetails.setFrameWork(resultEntity.getFramework());
					}
			}

		});

		Map<String, WorksheetFileListEntity> dprPasFileDetailMap = new HashMap<>();
		dprPasFileDetailList.stream().forEach(row -> {
			dprPasFileDetailMap.put(row.getFileName(), row);
		});

		Map<String, List<WorksheetFileListEntity>> fileMappedEntity = dprPasFileDetailList.stream()
				.collect(Collectors.groupingBy(WorksheetFileListEntity::getFileName));

	}

	private void checkLayoutPattern(WorksheetFileListEntity fileListSheetEntity) {
		PatternFinder patternFinder = new PatternFinder();
		String dprName = StringUtils.remove(fileListSheetEntity.getDprName(), ".dpr");
		try {
			if (fileListSheetEntity.isTargetBiz() || StringUtils.contains(fileListSheetEntity.getFilePath(), dprName)) {
				fileListSheetEntity.setLayoutType(Constants.MAIN_FRAME);
				patternFinder.getMainFramePattern(fileListSheetEntity);
			} else {
				fileListSheetEntity.setLayoutType(Constants.DIALOG);
				patternFinder.getDialogPattern(fileListSheetEntity);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
 */

/*if (StringUtils.isNotEmpty(layoutType)
		&& StringUtils.isNotEmpty(layoutPattern)) {
	break;
}*/

/*if( StringUtils.isNotEmpty(fileListSheetEntity.getLayoutType()) &&
StringUtils.isNotEmpty(fileListSheetEntity.getLayoutPattern())) {
return;
}*/