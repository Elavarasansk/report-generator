package org.intraweb.tools.worksheet.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.intraweb.tools.worksheet.dto.GitPullResponse;
import org.intraweb.tools.worksheet.service.GitSyncService;
import org.intraweb.tools.worksheet.service.SvnFileSearch;
import org.intraweb.tools.worksheet.service.SvnSyncService;
import org.intraweb.tools.worksheet.utility.GITConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.tmatesoft.svn.core.SVNException;

@RestController
@RequestMapping("version_control/")
@CrossOrigin
public class VersionControlController {

	@Autowired
	private GitSyncService gitSyncService;

	@Autowired
	private SvnSyncService svnSyncService;
	
	@Autowired
	private SvnFileSearch svnFileSearch;
	
	@GetMapping("sync/all")
	public void syncAllRepos() {
		gitSyncService.multiRepoSyncThread();
	}
	
	@GetMapping("sync/cac")
	public GitPullResponse requestCacSync() {
		return gitSyncService.cacGitPull();
	}
	
	@GetMapping("sync/cam")
	public GitPullResponse requestCamSync() {
		return gitSyncService.camGitPull();
	}
	
	@GetMapping("sync/cbm")
	public GitPullResponse requestCbmSync() {
		return gitSyncService.cbmGitPull();
	}
	
	@GetMapping("sync/ccm")
	public GitPullResponse requestCcmSync () {
		return gitSyncService.ccmGitPull();
	}
	
	@GetMapping("sync/cfm")
	public GitPullResponse requestCfmSync() {
		return gitSyncService.cfmGitPull();
	}
	
	@GetMapping("sync/document")
	public GitPullResponse requestDocumentSync() {
		return gitSyncService.documentGitPull();
	}
	
	@GetMapping("sync/svn")
	public void requestSvnSyncCam(@RequestParam("svnType") String svnType, @RequestParam("module") String module) throws SVNException {
		svnSyncService.prepareForSvnUpdate(svnType, module);
	}

	@PostMapping("/svn40/check")
	@CrossOrigin
	public List<List<String>> checkExistingFilesSvn40(@RequestParam("file") MultipartFile[] uploadFiles, HttpServletResponse response) 
			throws IOException, InvalidFormatException {
		return svnFileSearch.searchFilesInRepo(uploadFiles[0], GITConstants.AC_SVN40);
	}

	@PostMapping("/svn41/check")
	@CrossOrigin
	public List<List<String>> checkExistingFilesSvn41(@RequestParam("file") MultipartFile[] uploadFiles, HttpServletResponse response) 
			throws IOException, InvalidFormatException {
		return svnFileSearch.searchFilesInRepo(uploadFiles[0], GITConstants.AC_SVN41);
	}
}
