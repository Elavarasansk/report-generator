package org.intraweb.tools.worksheet.repository.interfaces;

import java.util.ArrayList;
import java.util.List;

import org.intraweb.tools.worksheet.entity.FormIssues;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FormIssuesRepo extends MongoRepository<FormIssues, String> {
	
	
	public FormIssues findByIssueId(int issueId);
	
	public List<FormIssues> findAllBySubject(List<String> subjectList);

	public List<FormIssues> findBySubjectInAndStatus(ArrayList<String> arrayList, String status);
	
}
