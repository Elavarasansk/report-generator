package org.intraweb.tools.worksheet.dto;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class PasPathFinder {
    
    private String pluginCompName;
    private String fileName;
    private String filePath;
    private String dprName;
    
}


