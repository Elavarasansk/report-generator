package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.PasFileFramework;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PasFileFrameworkRepo extends MongoRepository<PasFileFramework, String> {
	
	public PasFileFramework findByFilePath(String filePath);

}
