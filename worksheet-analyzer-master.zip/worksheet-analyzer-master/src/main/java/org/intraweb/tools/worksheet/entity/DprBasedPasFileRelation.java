package org.intraweb.tools.worksheet.entity;

import java.util.Map;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="dprbased_pas_file_relation")
public class DprBasedPasFileRelation {

	@Indexed(unique=true)
	private String dprName;
	
	private Map<String,String> relationMap;
}
