package org.intraweb.tools.worksheet.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.ListBranchCommand.ListMode;
import org.eclipse.jgit.api.LogCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;

//@Service
public class GitRepositorySync {

	static String localGitPath = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-document\\.git";
	

	public void main() {
		try {
			connectGit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	
	
	public static void connectGit() throws IOException, GitAPIException {
		FileRepositoryBuilder repositoryBuilder = new FileRepositoryBuilder();
		Repository repository = repositoryBuilder.setGitDir(new File(localGitPath))
		                .readEnvironment() // scan environment GIT_* variables
		                .findGitDir() // scan up the file system tree
		                .setMustExist(true)
		                .build();
		
	    Git git = new Git(repository);
	    
//	    RevWalk walk = new RevWalk(repository);
	    
	    List<Ref> branches = git.branchList()/*.setListMode( ListMode.ALL )*/.call();
	    
		for(Ref referenceBranch: branches) {
			System.out.println(referenceBranch.getName());
	    }
		git.close();
	}
	
	
}
