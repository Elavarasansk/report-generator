package org.intraweb.tools.worksheet.repository.interfaces;

import org.intraweb.tools.worksheet.entity.DprPasFileDetails;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface DprPasFileDetailsRepo extends MongoRepository<DprPasFileDetails, String>{
	
}
