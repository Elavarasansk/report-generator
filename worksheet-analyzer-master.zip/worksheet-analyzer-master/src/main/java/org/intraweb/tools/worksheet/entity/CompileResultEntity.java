package org.intraweb.tools.worksheet.entity;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CompileResultEntity {
	
	private boolean status;

	private String dprName;
	
	private String dprPath;
	
	private String module;
	
	private List<String> errorList;
	
	private List<String> fatalList;
	
	private String compiledList;
	
	private List<String> hintList;
	
	private List<String> warningList;
	

}
