package org.intraweb.tools.worksheet.entity;

import java.util.List;

import lombok.Builder;
import lombok.Data;
import java.util.Date;

@Data
@Builder
public class CompilerDetails {
	
	private List<String> linesList;
	
	private Date compilerStartTime;
	
	private Date compilerEndTime;
	
	private boolean status;

		
}
