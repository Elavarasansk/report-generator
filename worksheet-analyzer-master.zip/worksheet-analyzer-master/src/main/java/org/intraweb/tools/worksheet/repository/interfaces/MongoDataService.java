package org.intraweb.tools.worksheet.repository.interfaces;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.intraweb.tools.worksheet.entity.DprAssignmentOrder;
import org.intraweb.tools.worksheet.entity.DuplicatePasDetails;
import org.intraweb.tools.worksheet.entity.FormIssues;
import org.intraweb.tools.worksheet.entity.PasFileFramework;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MongoDataService {

	@Autowired
	private MongoTemplate mongoTemplate; 


	public List<FormIssues> findAllBySubject(List<String> subjectList){
		Query query = new Query();
		query.addCriteria(Criteria.where("subject").in(subjectList));
		return mongoTemplate.find(query,FormIssues.class);

	}

	public void insert(List<PasFileFramework> fileList) {
		mongoTemplate.insertAll(fileList);
	}

	public List<PasFileFramework> findPasFrameworkByPath(List<String> filePath) {
		Query query = new Query();
		query.addCriteria(Criteria.where("filePath").in(filePath));
		return mongoTemplate.find(query, PasFileFramework.class);
	}


	public Map<String, List<String>> findDuplicatePasDetails(List<String> filePath) {
		Query query = new Query();
		query.addCriteria(Criteria.where("pasFileName").in(filePath));
		List<DuplicatePasDetails> pasPathList = mongoTemplate.find(query, DuplicatePasDetails.class);
		return pasPathList.stream().collect(Collectors.toMap(DuplicatePasDetails::getPasFileName, value->value.getDprs()));
	}
	
	
	
	public Map<String, PasFileFramework> getPasFileList(List<String> filePath) {
		Query query = new Query();
		query.addCriteria(Criteria.where("filePath").in(filePath));
		List<PasFileFramework> pasPathList = mongoTemplate.find(query, PasFileFramework.class);
		return pasPathList.stream().collect(Collectors.toMap(PasFileFramework::getFilePath, value->value));
	}
	
	

	public DprAssignmentOrder getDprDetails(String dprName,String module) {
		Query query = new Query();
		query.addCriteria(Criteria.where("dprName").is(dprName).and("module").is(module.toUpperCase()));
		DprAssignmentOrder	dprList =  mongoTemplate.findOne(query, DprAssignmentOrder.class);
		return dprList;
	}

}
