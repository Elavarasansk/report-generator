package org.intraweb.tools.worksheet.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="duplicate_paspath_details")
public class DuplicatePasDetails {
	
	@Id
	private ObjectId id;
	
	private String pasName;

	@Indexed(unique=true)
	private String pasFileName;
	
	private List<String> dprs;

}
