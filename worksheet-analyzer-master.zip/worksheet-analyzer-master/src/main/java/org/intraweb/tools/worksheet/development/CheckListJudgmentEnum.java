package org.intraweb.tools.worksheet.development;


import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;

public enum CheckListJudgmentEnum {	

	TMYNUMBERDLG_MAIN_FRAME("TForm","Main Frame", "Plain Frame", "TCfwRootPlainFrame"),
	TMYNUMBERDLG_DIALOG("TForm","Dialog", "Plain Dialog", "TCfwRootPlainDialog"),		
	TCFWROOTFRAME_MAIN_FRAME("TCfwRootFrame","Main Frame", "Plain Frame", "TCfwRootPlainFrame"),
	TCFWROOTFRAME_DIALOG("TCfwRootFrame","Dialog", "Plain Dialog", "TCfwRootPlainDialog"),	
	TMYNUMBERDLG("TMyNumberDlg","Dialog", "Plain Dialog", "TMyNumberDlg"),	
	TCFWSIMPLEDIALOG("TCfwSimpleDialog","Dialog", "Plain Dialog", "TCfwSimpleDialog"),
	TCFWCSVINPUTFRAME("TCfwCsvInputFrame","Dialog", "Plain Dialog", "TCfwCsvInputFrame"),	
	TCFWPRINTERDIALOG("TCfwPrinterDialog","Dialog", "Plain Dialog", "TCfwPrinterDialog"),
	TCFWABOUTFRAME("TCfwAboutFrame","Dialog", "Plain Dialog", "TCfwAboutFrame"),	
	TCFWBASEFRAME_MAIN_FRAME("TCfwBaseFrame","Main Frame", "Plain Frame", "TCfwBasePlainFrame"),
	TCFWBASEFRAME_DIALOG("TCfwBaseFrame","Dialog", "Plain Dialog", "TCfwBasePlainDialog"),	
	TCFWLISTFRAMEEXCOOL("TCfwListFrameExCool","Main Frame", "List Frame", "TCfwListFrameExCool"),	
	TCFWVIEWLISTFRAMEEXCOOL("TCfwViewListFrameExCool","Main Frame", "List Frame", "TCfwViewListFrameExCool"),	
	TCFWLISTFRAMEEXCOOLORDER("TCfwListFrameExCoolOrder","Main Frame", "List Frame", "TCfwListFrameExCoolOrder"),	
	TCFWVIEWLISTFRAMEEXCOOLORDER("TCfwViewListFrameExCoolOrder","Main Frame", "List Frame", "TCfwViewListFrameExCoolOrder"),
	TCFWSIMPLEFRAME("TCfwSimpleFrame","Main Frame", "List Frame", "TCfwSimpleFrame"),	
	TCFWDRAWGRIDFRAME("TCfwDrawGridFrame","Main Frame", "List Frame", "TCfwDrawGridFrame"),	
	TCFWTREEREFFRAME("TCfwTreeRefFrame","Main Frame", "List Frame", "TCfwTreeRefFrame"),	
	TCFWTREEREFORDERFRAME("TCfwTreeRefOrderFrame","Main Frame", "List Frame", "TCfwTreeRefOrderFrame"),	
	TCFWBASEFRAMEEXCOOL("TCfwBaseFrameExCool","Main Frame", "Plain Frame", "TCfwBasePlainFrameExCool"),
	TCFWREPORTFRAME_MAIN_FRAME("TCfwReportFrame","Main Frame", "Report Frame", "TCfwReportMainFrame"),
	TCFWREPORTFRAME_DIALOG("TCfwReportFrame","Dialog", "Report Dialog", "TCfwReportDialog"),
	TCFWSEARCHFRAMEEXCOOL("TCfwSearchFrameExCool","Dialog", "Search Dialog", "TCfwSearchFrameExCool"),
	TCFWSEARCHVIEWFRAMECNTOPTIONAL("TCfwSearchViewFrameCntOptional","Dialog", "Search Dialog", "TCfwSearchViewFrameCntOptional"),
	TCFWSEARCHVIEWFRAMEEXCOOL("TCfwSearchViewFrameExCool","Dialog", "Search Dialog", "TCfwSearchViewFrameExCool"),
	TCFWLANGUAGESEARCHDLG("TCfwLanguageSearchDlg","Dialog", "Search Dialog", "TCfwLanguageSearchDlg"),
	TCFWDIALOG_MAIN_FRAME("TCfwDialog","Main Frame", "Plain Frame", "TCfwPlainFrame"),
	TCFWDIALOG_DIALOG("TCfwDialog","Dialog", "Plain Dialog", "TCfwPlainDialog"),	
	TCFWDIALOGEXPLUS("TCfwDialogExPlus","Main Frame", "Detail Frame", "TCfwDialogExPlus"),	
	TCFWFILESAVEQUERYDIALOG("TCfwFileSaveQueryDialog","Dialog", "CSV Input Dialog", "TCfwFileSaveQueryDialog"),
	TCFWREPORTPREVIEWDIALOG("TCfwReportPreviewDialog","Dialog", "Header Less Dialog", "TCfwReportPreviewDialog"),
	TCFWREADDIALOG("TCfwReadDialog","Dialog", "Header Less Dialog", "TCfwReadDialog");

	@Getter
	private String frame;

	@Getter
	private String layoutType;

	@Getter
	private String layoutPattern;

	@Getter
	private String framework;



	CheckListJudgmentEnum(String frame,String layoutType,String layoutPattern,String framework){
		this.frame = frame;
		this.layoutType = layoutType;
		this.layoutPattern = layoutPattern;
		this.framework = framework;

	}

	public static CheckListJudgmentEnum getTypePattern(String frame) {
		return Arrays.stream(CheckListJudgmentEnum.values())
				.filter(data -> StringUtils.equalsIgnoreCase(data.getFrame(),frame)).findFirst().orElse(null);
	}

	public static CheckListJudgmentEnum getTypePattern(String frame,String layoutType) {
		return Arrays.stream(CheckListJudgmentEnum.values())
				.filter(data ->  StringUtils.equalsIgnoreCase(data.getFrame(),frame) && StringUtils.equals(data.getLayoutType(),layoutType)).findFirst().orElse(null);


	}





}
