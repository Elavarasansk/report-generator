package org.intraweb.tools.worksheet.entity;


import org.springframework.data.annotation.Transient;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WorksheetFileListEntity {
	
	@Transient
	private int rowIndex;	
	@Transient
	private String oldFrameWork;
	private String assignee;
	private String issueId;
	private String hyperLink;
	private String dprName;
	private String dprPath;
	private boolean isForm;
	private boolean isTargetForm;
	private boolean isTargetBiz;
	private String frameWork;
	private String layoutType;
	private String layoutPattern;
	private String fileName;
	private String filePath;
	private String status;

}
