package org.intraweb.tools.worksheet.development;

import java.io.File;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.google.common.io.Files;


public class JudgeMainFrame {

	public static String getFirstForm(String dprPath){
		File file = new File(dprPath);
		try {
			if(file.exists()) {
				List<String> lineList =Files.readLines(file, Charset.defaultCharset());
				long size =lineList.size();
				StringBuilder frameBuilder = new StringBuilder();
				for (int i=0;i<size;i++) {
					String currentLine = lineList.get(i);
					if(	currentLine.contains(".CreateForm(")) {
						if( currentLine.contains("(") && currentLine.contains(");") ) {
							frameBuilder.append(currentLine.substring(currentLine.indexOf("(") + 1, currentLine.lastIndexOf(");")).split(",")[1].trim());
							break;
						}else{						
							frameBuilder.append(findFrame(lineList,size,i,currentLine));
						}
					}

				}
				String frame = frameBuilder.toString();
				Optional<String> mainFrame =  lineList.stream().filter(currentLine ->currentLine.contains(frame)).findFirst();
				String result = StringUtils.EMPTY;
				if(mainFrame.isPresent()) {
					String currentLine = mainFrame.get();
					result = currentLine.substring(currentLine.indexOf("'")+1, currentLine.lastIndexOf("'")).trim();
				}			

				return result;
			}
		}catch(Exception e){
			System.out.println("Exception :"+e);
			System.out.println("File Missing in : "+dprPath);
			return StringUtils.EMPTY;
		}

		return null;
	}

	public static String findFrame(List<String> lineList, long size, int currentIndex, String currentLine){	

		StringBuilder line = new StringBuilder(currentLine);

		for (int j = currentIndex+1;j<size;j++) {
			if(!currentLine.contains(");")) {
				line.append(lineList.get(j));
			}else
				break;

		}
		String frame = line.toString();
		return frame.substring(frame.indexOf("(") + 1, frame.lastIndexOf(");")).split(",")[1].trim();

	}

}
