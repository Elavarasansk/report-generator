package com.iv.svn.utility;




public class GITConstants{

	public static final String ORIGIN = "origin";
	public static final String HUE_DEVELOP = "D:\\HUE\\WorkSpace\\Develop\\";
	public static final String HUE_DEVELOP_AC = "C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-";
	public static final String GIT_INDEX = "\\.git";
	public static final String CAC_REPO = "cac" + GIT_INDEX;
	public static final String CAM_REPO = "cam" + GIT_INDEX;
	public static final String CBM_REPO = "cbm" + GIT_INDEX;
	public static final String CCM_REPO = "ccm" + GIT_INDEX;
	public static final String CFM_REPO = "cfm" + GIT_INDEX;
	public static final String DOCUMENT_REPO = "document" + GIT_INDEX;
	public static final String INDEX_LOCK_FILE = "index.lock";
	
	public static final String CFW_TOOL_REPO = "hue-ac-cfw-tool";
	
	public static final String DCC32_COMPILER = "D:\\Borland\\Delphi7\\Bin\\DCC32.EXE";

	
	
	public static final String AC_GIT = "AC_GIT";
	public static final String AC_SVN40 = "AC_SVN40";
	public static final String AC_SVN41 = "AC_SVN41";
	
	public static final String CAC = "CAC";
	public static final String COM = "COM";
	public static final String ALL = "ALL";
	public static final String CAM = "CAM";
	public static final String CBM = "CBM";
	public static final String CCM = "CCM";
	public static final String CFM = "CFM";
	public static final String DOCUMENT = "DOCUMENT";
	
	public static final String WEB_CONVERT_JAR = "web-converter-jar-with-dependencies.jar";
	public static final String JAR_PATH_TARGET = GITConstants.HUE_DEVELOP+GITConstants.CFW_TOOL_REPO+"\\"+"target";
	public static final String JAR_PATH = GITConstants.HUE_DEVELOP+GITConstants.CFW_TOOL_REPO+"\\"+"target"+"\\"+WEB_CONVERT_JAR;


}
