package com.iv.svn;

import com.iv.svn.controller.SvnController;

public class SvnSyncMain {

	public static void main(String[] args) throws Exception {
		String module = args[0]; 
		SvnController.prepareForSvnUpdate(module);
	}

}