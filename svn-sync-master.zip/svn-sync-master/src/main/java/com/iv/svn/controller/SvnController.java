package com.iv.svn.controller;

import com.iv.svn.service.SvnSyncService;
import com.iv.svn.utility.GITConstants;

public class SvnController {
	
	public static void prepareForSvnUpdate(String module) throws Exception{
		if(module.equalsIgnoreCase(GITConstants.ALL)) {
			SvnSyncService.prepareForSvnUpdateAll();
		}else {
			SvnSyncService.prepareForSvnUpdate("svn",module);
		}
		
	}
	

}
