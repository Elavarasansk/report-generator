package com.iv.svn.service;




import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNUpdateClient;
import org.tmatesoft.svn.core.wc.SVNWCClient;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.iv.svn.utility.CommonUtils;
import com.iv.svn.utility.GITConstants;


public class SvnSyncService {

	private static String COM = "http://com-prm/svn/prm/branches/COM";

	private static String CAM = "http://cam-prm/svn/prm/branches/CAM";

	private static String CBM = "http://cbm-prm/svn/prm/branches/CBM";

	private static String CCM = "http://ccm-prm/svn/prm/branches/CCM";

	private static String CFM = "http://cfm-prm/svn/prm/branches/CFM";

	private static String svnLogin = "vairavan.u";

	private static String svnPassword = "vairavan.u";
	
	private static String formSvnFilePath = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V41";
	
	private static String  SVN_CLEAN = "cleanup";
	private static String  SVN_UPDATE = "update";

	private static String SVN_EXE = "C:\\Program Files\\TortoiseSVN\\bin\\svn.exe";



	public static void prepareForSvnUpdate(String svnType, String module) throws Exception {
		String svnUrl="";
		String svn_client = "/hue_client";
		String svn_web = "/hue_web";

		
		
		switch (module) {
		case GITConstants.COM:
			svnUrl = COM;
			break;

		case GITConstants.CAM:
			svnUrl = CAM;
			break;

		case GITConstants.CBM:
			svnUrl = CBM;
			break;

		case GITConstants.CCM:
			svnUrl = CCM;
			break;

		case GITConstants.CFM:
			svnUrl = CFM;
			break;
	}
		formSvnFilePath = CommonUtils.findSvnPath(module);
		updateSvnCommandLine(formSvnFilePath +svn_client);
		updateSvnCommandLine(formSvnFilePath +svn_web);


	}
	
	
	private static void updateSvnCommandLine(String formSvnFilePath) throws Exception {
		try {
			ProcessBuilder processBuilder = new ProcessBuilder();
			processBuilder.command("cmd.exe", "/c", "dir "+formSvnFilePath);
			processBuilder.start();
			processBuilder.directory(new File(formSvnFilePath));
			processBuilder. redirectErrorStream(true);
			processBuilder.command(SVN_EXE, SVN_CLEAN);
			Process cleanupResult = processBuilder.start();
			cleanupResult.waitFor();
			System.out.println(streamExecutedResult("CLEAN", cleanupResult).toString());
			processBuilder.command(SVN_EXE, SVN_UPDATE);
			Process updateResult = processBuilder.start();
			cleanupResult.waitFor();
			 streamExecutedResult("UPDATE", updateResult);
			cleanupResult.destroyForcibly();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("SVN process failed - "+ formSvnFilePath +"----"+ e.getMessage());
			throw new Exception("SVN update failed..");

		}
	}

	public static List<String> streamExecutedResult(String type, Process result) throws Exception {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(result.getInputStream()));
		List<String> linesList = new ArrayList<>();
		String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
		System.out.println(linesList.toString());
		return linesList;
	}

	
	public static void updateSvn(String url, String formSvnFilePath,String verType, String module) throws Exception{
		SVNRepository repository;
		try {
			System.out.print(module+ " Sync started.");
			repository = SVNRepositoryFactory.create(SVNURL.parseURIDecoded(url));
			ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(svnLogin, svnPassword);
			repository.setAuthenticationManager(authManager);

			SVNClientManager ourClientManager = SVNClientManager.newInstance();
			ourClientManager.setAuthenticationManager(authManager);

			SVNUpdateClient updateClient = ourClientManager.getUpdateClient();
			updateClient.setIgnoreExternals(true);

			SVNWCClient workingCopy = ourClientManager.getWCClient();
			long latestRevision = repository.getLatestRevision();

			workingCopy.doCleanup(new File(formSvnFilePath), false, true, false, false, false, true);
			long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);
			//		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);

			System.out.print("revision info "+ latestRevision +"-------->"+ updatedRevision);
			System.out.print(module+ " Sync ended.");
		} catch (SVNException e) {
			e.printStackTrace();
			
			throw new Exception("SVN update failed.."+module);
		}
		
}

	public static void prepareForSvnUpdateAll() throws Exception {
		
		prepareForSvnUpdate("SVN", "COM");
	    prepareForSvnUpdate("SVN", "CAM");
		prepareForSvnUpdate("SVN", "CCM");
		prepareForSvnUpdate("SVN", "CFM");
		prepareForSvnUpdate("SVN", "CBM");
				
	}



}
