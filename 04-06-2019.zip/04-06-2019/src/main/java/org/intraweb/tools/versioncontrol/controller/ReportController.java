package org.intraweb.tools.versioncontrol.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.intraweb.tools.versioncontrol.service.ReportGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("report/generator/download")
@CrossOrigin
public class ReportController {

	@Autowired
	private ReportGeneratorService  reportGeneratorService;
	
	@PostMapping("pdf")
	public void downloadPDF(HttpServletResponse response) throws IOException {
			File file = reportGeneratorService.generatePDF();
			InputStream inputStream = new FileInputStream(file);       
			response.setContentType("application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename="+file.getName()); 
			IOUtils.copy(inputStream, response.getOutputStream());
			response.flushBuffer();
			inputStream.close();
			FileUtils.deleteQuietly(file);
	}

}
