package org.intraweb.tools.versioncontrol.controller;

import org.intraweb.tools.versioncontrol.dto.entity.TesterDetails;
import org.intraweb.tools.versioncontrol.dto.vo.TesterDetailsVo;
import org.intraweb.tools.versioncontrol.service.TesterDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javassist.NotFoundException;

@RestController
@RequestMapping("tester/details/")
@CrossOrigin
public class TesterDetailController {
	
	@Autowired
	private TesterDetailsService  testerDetailsService;
	
	
	@PostMapping("create")
	public TesterDetailsVo create(@RequestBody TesterDetailsVo testerDetailsVo) {
		return testerDetailsService.create(testerDetailsVo);
	}
	
	
	@PostMapping("update")
	public TesterDetailsVo update(@RequestBody TesterDetailsVo testerDetailsVo) throws NotFoundException {
		return testerDetailsService.update(testerDetailsVo);
	}
	
	
	@PostMapping("delete")
	public TesterDetailsVo delete(@RequestBody TesterDetailsVo testerDetailsVo) throws NotFoundException {
		return testerDetailsService.delete(testerDetailsVo);
	}
	
	@PostMapping("find/one")
	public TesterDetails findone(@RequestBody Long id) throws NotFoundException {
		return testerDetailsService.findOne(id);
	}

	


}
