package org.intraweb.tools.versioncontrol.dto.repository;


import java.util.Optional;

import org.intraweb.tools.versioncontrol.dto.entity.TesterDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;


@Transactional
public interface TesterDetailsRepository extends JpaRepository<TesterDetails, Long> {
	
	public Optional<TesterDetails> findById(Long id); 

	
}
