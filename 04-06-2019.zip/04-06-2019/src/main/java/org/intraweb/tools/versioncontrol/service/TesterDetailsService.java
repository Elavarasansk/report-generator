package org.intraweb.tools.versioncontrol.service;

import java.util.Objects;
import java.util.Optional;

import org.intraweb.tools.versioncontrol.dto.entity.TesterDetails;
import org.intraweb.tools.versioncontrol.dto.repository.TesterDetailsRepository;
import org.intraweb.tools.versioncontrol.dto.vo.TesterDetailsVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import javassist.NotFoundException;


@Service
public class TesterDetailsService {

	@Autowired
	private TesterDetailsRepository testerDetailsRepository;



	public TesterDetailsVo create( TesterDetailsVo testerDetailsVo)  throws DuplicateKeyException{
		if(Objects.nonNull(testerDetailsVo)) {
			TesterDetails testerDetailsBuilder= TesterDetails.builder().build();
			BeanUtils.copyProperties( testerDetailsVo, testerDetailsBuilder);
			testerDetailsRepository.save(testerDetailsBuilder);
		}else {
			throw new DuplicateKeyException("Test Id - \""+testerDetailsVo.getTestId()+"\" already exists."
					+ " So Test cannot be Created");
		}
		return testerDetailsVo;
	}



	public TesterDetailsVo delete(TesterDetailsVo testAttendDetailsVo)  throws NotFoundException{
		Optional<TesterDetails> testerDetails = testerDetailsRepository.findById(testAttendDetailsVo.getId());		
		if(testerDetails.isPresent()) {
			testerDetailsRepository.delete(testerDetails.get());
		}else {
			throw new NotFoundException("Test ID - "+ testAttendDetailsVo.getTestId() +" doesnot Exists ");
		}
		return testAttendDetailsVo;
	}


	public TesterDetails findOne(Long id)  throws NotFoundException {
		Optional<TesterDetails> testerDetails = testerDetailsRepository.findById(id);		
		if(testerDetails.isPresent()) {
			return testerDetails.get();
		}else {
			throw new NotFoundException("Test ID - "+ id +" doesnot Exists ");
		}
	}


	public TesterDetailsVo update(TesterDetailsVo testAttendDetailsVo)  throws NotFoundException{		
		Boolean exists = testerDetailsRepository.existsById(testAttendDetailsVo.getId());
		if(exists) {			
			TesterDetails testerDetailsBuilder = TesterDetails.builder().build();
			BeanUtils.copyProperties( testAttendDetailsVo, testerDetailsBuilder);
			testerDetailsRepository.save(testerDetailsBuilder);
		}else {
			throw new NotFoundException("Test ID - "+ testAttendDetailsVo.getTestId() +" doesnot Exists ");
		}
		return testAttendDetailsVo;
	}



}