package org.intraweb.tools.versioncontrol.service;




import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.intraweb.tools.versioncontrol.contsant.ReportConstants;
import org.intraweb.tools.versioncontrol.entity.ReportEntity;
import org.intraweb.tools.versioncontrol.entity.SubReportEntity;
import org.intraweb.tools.versioncontrol.utils.CustomizePieChart;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;


@Slf4j
@Service
public class ReportGeneratorService  {

	public File generatePDF() {		
		FileUtils.deleteQuietly(new File(ReportConstants.PDF_NAME));
		File outputFile  = null;
		try {
			outputFile = new File(ReportConstants.PDF_NAME);
			JasperReport jasperReport = CustomizePieChart.getJasperReport();
			JasperReport jasperSubReport = JasperCompileManager.compileReport(ReportConstants.SUB_REPORT);
			List<SubReportEntity> modelSubList = new ArrayList<SubReportEntity>();
			modelSubList.add(new SubReportEntity("A for","apple","mongo"));
			modelSubList.add(new SubReportEntity("B for ","Ball","C"));					
			List<ReportEntity> modelList = new ArrayList<ReportEntity>();
			modelList.add(new ReportEntity(7,7,"Wrong Answer","Right Answer","Elasu","Apti","A","03-04-1992",0,8,6,0,0,0));
			JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(modelList);
			JRBeanCollectionDataSource dataSubSource = new JRBeanCollectionDataSource(modelSubList);
			Map<String,Object> params = new HashMap<String,Object>();
			JasperPrint jasperPrint =  JasperFillManager.fillReport(jasperReport,params,dataSource);
			JasperPrint jasperSubPrint =  JasperFillManager.fillReport(jasperSubReport,params,dataSubSource);		
			JasperExportManager.exportReportToPdfFile(jasperPrint,outputFile.getAbsolutePath());
			OutputStream output = new FileOutputStream(outputFile);
			JRPdfExporter exporter = new JRPdfExporter();
			exporter.setExporterInput(SimpleExporterInput.getInstance(Arrays.asList(jasperPrint,jasperSubPrint)));
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(output)); 
			SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
			exporter.setConfiguration(configuration);
			exporter.exportReport();
			output.close();
			return outputFile;
		}catch(Exception e) {
			FileUtils.deleteQuietly(outputFile);
			log.error("Exception while generating report "+e.getMessage());
		}
		return outputFile;
	}


}
