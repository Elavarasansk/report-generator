package org.intraweb.tools.versioncontrol.dto.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "testerdetails")
public class TesterDetails  implements Serializable {
	private static final long serialVersionUID = -1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long id;

	private String testId;

	private String testerName;

	private String password;

	private String emailId;

	private String category;

	@CreationTimestamp
	private Date expiryDate;

	@CreationTimestamp
	private Date createdDate;	

	private String createdBy;

	private String questionId;

	private String testName;	

	private Integer questionNo;	

	private String status;

}
