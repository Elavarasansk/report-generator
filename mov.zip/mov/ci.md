# SmartWorks - KairoHoraServer  

### Step1
    Install Node LTS 12
    Install YARN

### Step2
    git clone http://192.168.41.136/SmartWorks/kairohoraserver.git
    yarn install
    
### Step3
    Use MYSQL Database.
    Create database,user,password as mentioned in the kairohoraserver/server/datasource.json file (`kairo_postgres` object)

### Step4
    Edit "kairo_postgres" object in the kairohoraserver/server/datasource.json file
    host,port will point to the MYSQL database.

### Step5
    cd "kairohoraserver"
    yarn run build & start
