package com.intraweb.project_basecamp_automation.vo;

import java.util.List;

import lombok.Data;

@Data
public class DllGenerateVo {

	private List<String> dprList;
	
}
