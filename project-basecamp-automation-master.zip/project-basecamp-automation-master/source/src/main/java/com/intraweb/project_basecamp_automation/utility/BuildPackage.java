package com.intraweb.project_basecamp_automation.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class BuildPackage {
	
	public static boolean build(String path) throws IOException{

			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			processBuilder.command("cmd.exe","/c",path);			
			p = processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getErrorStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
				linesList.add(line);
			}	
 			p.destroy();
			return true;
			
		
	}

}
