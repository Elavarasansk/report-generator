package com.intraweb.project_basecamp_automation.vo;

import lombok.Data;

@Data
public class CompilerVo {

	private String dprPath;
	
	private String module;
	
}
