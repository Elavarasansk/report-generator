package com.intraweb.project_basecamp_automation.entity;


import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.intraweb.project_basecamp_automation.dto.GitPullResponse;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection="version_control_status")
public class VersionControlStatus {
	
	@Id
	private ObjectId id;

	private String versionType;
	
	private String module;

	private boolean syncInProgress;

	private Date lastSyncStartTime;

	private Date lastSyncEndTime;
	
}
