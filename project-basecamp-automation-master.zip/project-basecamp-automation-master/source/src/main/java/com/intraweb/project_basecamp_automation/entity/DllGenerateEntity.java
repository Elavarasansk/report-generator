package com.intraweb.project_basecamp_automation.entity;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = "dynamic_dll_result")
public class DllGenerateEntity {

	@Id
	private ObjectId id;
	
	private String dprName;
	private String dprPath;
	private String module;
	private List<String> compileLog;
	private Boolean isDllGenerated;
	private Boolean isDllDeployed;
	private LocalDateTime lastCompiled;
	
	private Duration webConvertDuration;
	private Duration dllGenerateDuration;
	private Duration dllDeployDuration;
	
}
