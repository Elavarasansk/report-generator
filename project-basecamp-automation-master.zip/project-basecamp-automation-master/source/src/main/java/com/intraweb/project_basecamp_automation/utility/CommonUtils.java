package com.intraweb.project_basecamp_automation.utility;

public class CommonUtils {
	
	public static String findSvnPath(String module){
		String svnNum = "41";
		String formSvnFilePath = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V41";
		switch (module) {
			case GITConstants.COM:
				formSvnFilePath += "\\"+GITConstants.COM+svnNum;
				break;

			case GITConstants.CAM:
				formSvnFilePath += "\\"+GITConstants.CAM+svnNum;
				break;

			case GITConstants.CBM:
				formSvnFilePath += "\\"+GITConstants.CBM+svnNum;
				break;

			case GITConstants.CCM:
				formSvnFilePath += "\\"+GITConstants.CCM+svnNum;
				break;

			case GITConstants.CFM:
				formSvnFilePath += "\\"+GITConstants.CFM+svnNum;
				break;
		}
		
		return formSvnFilePath;
		
	}

}
