package com.intraweb.project_basecamp_automation.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.intraweb.project_basecamp_automation.entity.DllGenerateEntity;
import com.intraweb.project_basecamp_automation.service.MainService;

@RestController
@CrossOrigin
@RequestMapping("/dllcompiler")
public class MainController {

	@Autowired
	private MainService mainService;
	
	@GetMapping("/dprcompile/details")
	public DllGenerateEntity showlogs(@RequestParam String dprPath) {
		return mainService.getDprCompileDetails(dprPath);
	}	
	
	@GetMapping("/dpr/getall")
	public Map<String, Object> getAllDprs() {
		return mainService.getAllDprs();
	}
	
	@GetMapping("/dpr/metaData")
	public Map<String, String> createMetaData() {
		return mainService.createMetaData();
	}
}
