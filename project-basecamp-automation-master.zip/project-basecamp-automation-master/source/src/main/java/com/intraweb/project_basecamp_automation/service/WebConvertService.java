package com.intraweb.project_basecamp_automation.service;


import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.intraweb.project_basecamp_automation.utility.CommonUtils;
import com.intraweb.project_basecamp_automation.utility.GITConstants;

@Service
public class WebConvertService {

	public void convert(List<String> dprPath) {
		dprPath.stream().forEach(path -> {
			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			try {
				processBuilder.directory(new File(GITConstants.JAR_PATH_TARGET));
				processBuilder.command("java", "-jar" ,"-Xmx1024m", "web-converter-jar-with-dependencies.jar","1",path);					
				p = processBuilder.start();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(p.getInputStream()));
				List<String> linesList = new ArrayList<>();
				String line;
				while ((line = reader.readLine()) != null) {
					linesList.add(line);
				}
			} catch (IOException e) {
				System.out.println("Web convert failed for-"+path+""+e.getMessage());
			}finally {
				p.destroy();
			}
		});
	}


	public void convertModule( String module) {
		String dirPath = CommonUtils.findSvnPath(module);
		dirPath = dirPath+"\\"+"hue_client\\delphi";
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			processBuilder.directory(new File(GITConstants.JAR_PATH_TARGET));
			processBuilder.command("java", "-jar", "-Xmx1024m", "web-converter-jar-with-dependencies.jar","2",dirPath);					
			p = processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			p.destroy();
		}
	}


	public boolean convertSingle(String dprPath) throws Exception {
		ProcessBuilder processBuilder = new ProcessBuilder();
		Process p = null;
		try {
			processBuilder.directory(new File(GITConstants.JAR_PATH_TARGET));
			processBuilder.command("java", "-jar" ,"-Xmx1024m", "web-converter-jar-with-dependencies.jar","1",dprPath);					
			p = processBuilder.start();
			BufferedReader reader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}
			return true;
		} catch (IOException e) {
			System.out.println("Web convert failed for- "+dprPath+" "+e.getMessage());
			return false;
		}finally {
			p.destroy();
		}
	}


}
