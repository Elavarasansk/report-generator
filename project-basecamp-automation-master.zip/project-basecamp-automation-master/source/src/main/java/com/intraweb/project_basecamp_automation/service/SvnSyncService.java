package com.intraweb.project_basecamp_automation.service;


import java.io.File;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNUpdateClient;
import org.tmatesoft.svn.core.wc.SVNWCClient;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.intraweb.project_basecamp_automation.entity.VersionControlStatus;
import com.intraweb.project_basecamp_automation.repository.VersionControlStatusRepo;
import com.intraweb.project_basecamp_automation.utility.CommonUtils;
import com.intraweb.project_basecamp_automation.utility.GITConstants;

@Service
public class SvnSyncService {


	@Value("${svn.url.com}")
	private String COM;

	@Value("${svn.url.cam}")
	private String CAM;

	@Value("${svn.url.cbm}")
	private String CBM;

	@Value("${svn.url.ccm}")
	private String CCM;

	@Value("${svn.url.cfm}")
	private String CFM;

	@Value("${svn.user.name}")
	private String svnLogin;

	@Value("${svn.user.password}")
	private String svnPassword;
	
	@Autowired
	private VersionControlStatusRepo versionControlStatusRepo;

	private String formSvnFilePath = "D:\\HUE\\WorkSpace\\Develop\\SVN\\V41";


	public void prepareForSvnUpdate(String svnType, String module) throws SVNException {
		String svnUrl="";
		String svnNum = "41/hue_client";

		switch (module) {
		case GITConstants.COM:
			svnUrl = COM+svnNum;
			break;

		case GITConstants.CAM:
			svnUrl = CAM+svnNum;
			break;

		case GITConstants.CBM:
			svnUrl = CBM+svnNum;
			break;

		case GITConstants.CCM:
			svnUrl = CCM+svnNum;
			break;

		case GITConstants.CFM:
			svnUrl = CFM+svnNum;
			break;
	}
		formSvnFilePath = CommonUtils.findSvnPath(module) + "\\hue_client";
		updateSvn(svnUrl, formSvnFilePath,svnType,module);

	}
	
	public List<VersionControlStatus> getSvnStatus() {
		return versionControlStatusRepo.findAll();
	}
	
	public VersionControlStatus syncServiceStart(String verType, String module) {
		VersionControlStatus vcs = VersionControlStatus.builder()
				.versionType(verType)
				.module(module)
				.syncInProgress(true)
				.lastSyncStartTime(new Date())
				.lastSyncEndTime(null)
				.build();

		VersionControlStatus existingVersionInfo = versionControlStatusRepo.findByVersionTypeAndModule(verType, module);

		if(!ObjectUtils.isEmpty(existingVersionInfo)) {
			vcs.setId(existingVersionInfo.getId());
		}

		return versionControlStatusRepo.save(vcs);
	}

	public void syncServiceEnd(VersionControlStatus vcs) {
		vcs.setSyncInProgress(false);
		vcs.setLastSyncEndTime(new Date());
		versionControlStatusRepo.save(vcs);
	}

	public void updateSvn(String url, String formSvnFilePath,String verType, String module) throws SVNException {
		VersionControlStatus vcs = syncServiceStart(verType, module);
		SVNRepository repository = SVNRepositoryFactory.create(SVNURL.parseURIDecoded(url));
		ISVNAuthenticationManager authManager = SVNWCUtil.createDefaultAuthenticationManager(svnLogin, svnPassword);
		repository.setAuthenticationManager(authManager);

		SVNClientManager ourClientManager = SVNClientManager.newInstance();
		ourClientManager.setAuthenticationManager(authManager);

		SVNUpdateClient updateClient = ourClientManager.getUpdateClient();
		updateClient.setIgnoreExternals(true);

		SVNWCClient workingCopy = ourClientManager.getWCClient();
		long latestRevision = repository.getLatestRevision();

		workingCopy.doCleanup(new File(formSvnFilePath), false, true, false, false, false, true);
		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);
		//		long updatedRevision = updateClient.doUpdate(new File(formSvnFilePath), SVNRevision.HEAD, SVNDepth.INFINITY, true, true);

		System.out.print("revision info "+ latestRevision +"-------->"+ updatedRevision);
		syncServiceEnd(vcs);
}

	public void prepareForSvnUpdateAll() {
		
		String svnNum = "41";
		Thread cacThread = new Thread(new Runnable() {
			@Override
			public void run() {
				String svnUrl = "COM"+svnNum;
				try {
					updateSvn(svnUrl, svnUrl, "SVN", "COM");
				} catch (SVNException e) {
					e.printStackTrace();
				}
			}
		});

		Thread camThread = new Thread(new Runnable() {
			@Override
			public void run() {
				String svnUrl = "CAM"+svnNum;
				try {
					updateSvn(svnUrl, svnUrl, "SVN", "CAM");
				} catch (SVNException e) {
					e.printStackTrace();
				}			
			}
		});

		Thread cbmThread = new Thread(new Runnable() {
			@Override
			public void run() {		
				String svnUrl = "CCM"+svnNum;
			try {
				updateSvn(svnUrl, svnUrl, "SVN", "CCM");
			} catch (SVNException e) {
				e.printStackTrace();
			}			
		}
		});

		Thread ccmThread = new Thread(new Runnable() {
			@Override
			public void run() {
			String svnUrl = "CFM"+svnNum;
			try {
				updateSvn(svnUrl, svnUrl, "SVN", "CFM");
			} catch (SVNException e) {
				e.printStackTrace();
			}			
		}
		});

		Thread cfmThread = new Thread(new Runnable() {
			@Override
			public void run() {
				String svnUrl = "CBM"+svnNum;
				try {
					updateSvn(svnUrl, svnUrl, "SVN", "CBM");
				} catch (SVNException e) {
					e.printStackTrace();
				}			
			}			
		});

		cacThread.start();
		camThread.start();
		cbmThread.start();
		ccmThread.start();
		cfmThread.start();
	}



}
