package com.intraweb.project_basecamp_automation;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

public class DllGenerateMain {

	public static void main(String[] args) {

		DllGenerateMain generate = new DllGenerateMain();
		Map<String, List<String>> libFiles = generate.getLibFilePath();

//		String dprPath = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\CFM41\\hue_web\\delphi\\CFM\\GP\\GpProc\\GpProc.dpr";
		if(Objects.isNull(args[0]) || args[0].equalsIgnoreCase(StringUtils.EMPTY)) {
			System.out.println("DPR path not specified in command line args.");
			return;
		}
		if(!new File(args[0]).exists()) {
			System.out.println("Invalid DPR path or DPR does not exists.");
			return;
		}
		
		String dprPath = args[0];
		List<File> dllFilesList = generate.compileDpr(dprPath);
		generate.moveDllToIIS(dllFilesList);
		
	}

	public Map<String, List<String>> getLibFilePath() {

		String cacGitPath = "C:\\HUE\\Workspace\\Develop\\hue-ac-chennai-cac\\";
		String cacSvnPath = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\COM41\\";
		String delphiPath = "D:\\Borland\\Delphi7\\";
		String sysWowPath = "C:\\Windows\\SysWOW64\\";

		String delphiLib = "hue_web\\delphi\\cvcommon\\Lib\\IntraWeb\\Lib\\";
		String delphiCvCommon = "hue_web\\delphi\\cvcommon\\packages";

		String[] formats = { "bpl" };

		List<String> dynamicBpl = Arrays.asList("bdertl70.bpl","dbrtl70.bpl","designide70.bpl","dsnap70.bpl","indy70.bpl",
				"inet70.bpl","Intracvcommon.bpl","rtl70.bpl","soaprtl70.bpl","vcl70.bpl","vclactnband70.bpl","vcljpg70.bpl","vclx70.bpl");

		Map<String, List<String>> resMap = new HashMap<>();

		dynamicBpl.stream().forEach(bpl -> {
			resMap.put(bpl, new ArrayList<>());
		});

		// Delphi cv common path
		List<String> filePathList = FileUtils.listFiles(new File(cacSvnPath + delphiCvCommon), formats, true).stream().
				map(file -> file.getPath()).collect(Collectors.toList());
		Map<String, String> filePathNameMap = filePathList.stream().collect(Collectors.toMap(path -> new File(path).getName(), val -> val));

		// SysWOW path
		List<String> sysWowFiles = FileUtils.listFiles(new File(sysWowPath), formats, true).stream().
				map(file -> file.getPath()).collect(Collectors.toList());
		Map<String, String> filePathNameMapSysWow = sysWowFiles.stream().collect(Collectors.toMap(key -> new File(key).getName(), val -> val));

		// Delphi Bin path
		List<String> binFiles = FileUtils.listFiles(new File(delphiPath + "bin"), formats, true).stream().
				map(file -> file.getPath()).collect(Collectors.toList());
		Map<String, String> filePathNameMapBin = binFiles.stream().collect(Collectors.toMap(key -> new File(key).getName(), val -> val));


		dynamicBpl.stream().forEach(bpl -> {
			String path = filePathNameMap.get(bpl);
			if(Objects.nonNull(path) && !path.equalsIgnoreCase("")) {
				List<String> bplList = resMap.get(bpl);
				bplList.add(path);
				resMap.put(bpl, bplList);
			}


			String pathVal = filePathNameMapSysWow.get(bpl);
			if(Objects.nonNull(pathVal) && !pathVal.equalsIgnoreCase("")) {
				List<String> bplList = resMap.get(bpl);
				bplList.add(pathVal);
				resMap.put(bpl, bplList);
			}

			String pathBin = filePathNameMapBin.get(bpl);
			if(Objects.nonNull(pathBin) && !pathBin.equalsIgnoreCase("")) {
				List<String> bplList = resMap.get(bpl);
				bplList.add(pathBin);
				resMap.put(bpl, bplList);
			}
		});

		return resMap;
	}


	public List<File> compileDpr(String dprPath) {
		try {
			File dpr = new File(dprPath);
			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			processBuilder.directory(dpr.getParentFile());
			processBuilder.command("dcc32", dpr.getName());
			processBuilder.redirectErrorStream(true);
			p = processBuilder.start();

			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
				System.out.println(line);
			}

			linesList.stream().forEach(lne -> {
				System.out.println(lne);
//				if (StringUtils.isNotEmpty(lne)) {
//					if (StringUtils.contains(lne, FATAL)) {
//						fatalList.add(lne);
//					} else if (StringUtils.contains(lne, ERROR) || (StringUtils.containsIgnoreCase(lne, FILE_NOT_FOUND)
//							&& StringUtils.containsIgnoreCase(lne, "dfm"))) {
//						errorList.add(lne);
//					} else if (StringUtils.contains(lne, WARNING)) {
//						warningList.add(lne);
//					} else if (StringUtils.contains(lne, HINT)) {
//						hintList.add(lne);
//					}
//				}
			});

			System.out.println("DPR compiled and Dynamic DLL generated successfully -- " + dpr.getName());
			
			String[] format = { "dll" };
			List<File> dllFilesList = FileUtils.listFiles(dpr.getParentFile(), format, true).stream().map(file -> (File) file).collect(Collectors.toList());
			return dllFilesList;
			
		} catch(Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}

	}

	public void moveDllToIIS(List<File> dllFilesList) {
		String path = "\\\\192.168.50.174\\iis\\ac-conversion\\sandbox_chen\\Basecamp\\Dynamic";
		dllFilesList.stream().forEach(file -> {
			try {
				System.out.println(path + "\\" + file.getName());
				File dllFile = new File(path + "\\" + file.getName());
				if(dllFile.exists()) {
					dllFile.delete();
				}
				FileUtils.copyFileToDirectory(file, new File(path), true);
			} catch(Exception e) {
				e.printStackTrace();
			}
		});
		System.out.println("DLL file moved to IIS successfully.");
	}
	
}
