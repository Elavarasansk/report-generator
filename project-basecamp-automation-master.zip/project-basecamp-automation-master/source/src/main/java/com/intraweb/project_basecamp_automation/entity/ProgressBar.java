package com.intraweb.project_basecamp_automation.entity;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProgressBar {
    public float percentage;
    public String dprName;
    public int step;
    public String logs;
    public String  status;
}
