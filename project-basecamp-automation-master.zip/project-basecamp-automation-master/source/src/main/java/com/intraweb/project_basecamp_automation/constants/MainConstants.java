package com.intraweb.project_basecamp_automation.constants;

public class MainConstants {

	public static final String SVN41_CAM = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\CAM41\\hue_client\\delphi\\";
	
	public static final String SVN41_CBM = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\CBM41\\hue_client\\delphi\\";
	
	public static final String SVN41_CCM = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\CCM41\\hue_client\\delphi\\";
	
	public static final String SVN41_CFM = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\CFM41\\hue_client\\delphi\\";
	
	public static final String SVN41_COM = "D:\\HUE\\Workspace\\Develop\\SVN\\V41\\COM41\\hue_client\\delphi\\";

	public static final String IIS_DYNAMIC = "\\\\192.168.50.174\\iis\\ac-conversion\\sandbox_chen\\Basecamp\\Dynamic";
	
	public static final String IIS_STATIC = "\\\\192.168.50.174\\iis\\ac-conversion\\sandbox_chen\\Basecamp\\Static";

}
