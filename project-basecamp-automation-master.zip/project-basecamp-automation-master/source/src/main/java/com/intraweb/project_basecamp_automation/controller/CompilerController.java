package com.intraweb.project_basecamp_automation.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.intraweb.project_basecamp_automation.service.CompilerService;
import com.intraweb.project_basecamp_automation.vo.CompilerVo;

@RestController
@RequestMapping("/dllcompiler")
@CrossOrigin
public class CompilerController {
	
	@Autowired
	public CompilerService compilerService;
	
	@PostMapping("/single/build")
	public Map<String,Object> singleBuild(@RequestBody List<CompilerVo> dprList,@RequestParam boolean isStatic) throws Exception {
		return compilerService.singleBuild(dprList,isStatic);
	}

	@PostMapping("/group/build")
	public Map<String,Object> groupBuild(@RequestBody String module,@RequestParam boolean isStatic) throws Exception {
		return compilerService.groupBuild(module,isStatic);
	}

}
