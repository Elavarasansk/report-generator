package com.intraweb.project_basecamp_automation.controller;


import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.tmatesoft.svn.core.SVNException;

import com.intraweb.project_basecamp_automation.service.GitSyncService;
import com.intraweb.project_basecamp_automation.service.SvnSyncService;

@RestController
@RequestMapping("version_control/")
@CrossOrigin
public class VersionControlController {

	@Autowired
	private GitSyncService gitSyncService;

	@Autowired
	private SvnSyncService svnSyncService;
	
	@GetMapping("sync/cfw-tool")
	public void syncAllRepos() throws IOException {
		gitSyncService.multiRepoSyncThread();
	}
	
	@GetMapping("sync/stats")
	public void getSvnStats()  {
		svnSyncService.getSvnStatus();
	}

	@GetMapping("sync/svn")
	public void requestSvnSync(@RequestParam("svnType") String svnType, @RequestParam("module") String module) throws SVNException {
		svnSyncService.prepareForSvnUpdate(svnType, module);
	}

	
	@GetMapping("sync/all")
	public void requestSvnAll() throws SVNException {
		svnSyncService.prepareForSvnUpdateAll();
	}


	
}
