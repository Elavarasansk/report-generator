package com.intraweb.project_basecamp_automation.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Service;
import org.tmatesoft.svn.core.SVNException;

import com.intraweb.project_basecamp_automation.entity.DllGenerateEntity;
import com.intraweb.project_basecamp_automation.entity.ProgressBar;
import com.intraweb.project_basecamp_automation.vo.CompilerVo;
import com.intraweb.project_basecamp_automation.vo.DllGenerateModuleVo;


@Service
public class CompilerService {

	@Autowired
	public SvnSyncService svnSyncService;

	@Autowired
	public WebConvertService webConvertService;

	@Autowired
	public MainService mainService;

	@Autowired
	private SimpMessageSendingOperations messagingTemplate;

	private void updateProgressPercent(float percentage, String dprName,int step, String logs, String status) {
		messagingTemplate.convertAndSend("/topic/public",ProgressBar.builder()
				.percentage(percentage)
				.dprName(dprName)
				.step(step)
				.logs(logs)
				.status(status)
				.build());
	}

	public Map<String, Object> singleBuild(List<CompilerVo> dprList, boolean isStatic) throws Exception {
		List<String> list = dprList.stream().map(CompilerVo::getModule)
				.distinct().collect(Collectors.toList());
		List<String> webConvertList = new ArrayList<>();
		Map<String, Object> resMap = new HashMap<>();

		// 1.SVN SYNC
		try {
			for( String data : list) {
				svnSyncService.prepareForSvnUpdate("SVN", data);
				updateProgressPercent(25,"",1,"SVN syn successfully","pass");
			}
		} catch (SVNException e) {
			updateProgressPercent(25,"",1,"SVN syn failed","fail");
			throw new Exception("SVN SYNC failed.");
		}		

		//2.WEB CONVERT
		webConvertList = dprList.stream().map(CompilerVo::getDprPath).collect(Collectors.toList());

		//3. DLL GENERATION && IIS DEPLOY
		List<DllGenerateEntity> dllList = mainService.executeMultiple(webConvertList,isStatic,false);
		List<DllGenerateEntity> isNotDeployedList = dllList.stream()
				.filter(p->!p.getIsDllGenerated()).collect(Collectors.toList());

		if(dprList.size() == 1 && isNotDeployedList.size() > 0) {
			throw new Exception("DLL generation failed.");
		}

		resMap.put("status", "200");
		resMap.put("message", "Operation successful");

		return resMap;
	}

	public Map<String, Object> groupBuild(String module, boolean isStatic) throws Exception{

		Map<String, Object> resMap = new HashMap<>();

		module = module.replaceAll("\"", "");

		// 1.SVN SYNC
		try {
			svnSyncService.prepareForSvnUpdate("SVN", module);
			updateProgressPercent(25,"",1,"SVN Sync Successful","pass");
		} catch (SVNException e) {
			updateProgressPercent(25,"",1,"SVN Sync Failed","fail");
			throw new Exception("SVN SYNC failed.");
		}				

		//2. DLL GENERATION && IIS DEPLOY
		DllGenerateModuleVo vo = new DllGenerateModuleVo();
		vo.setModule(module);
		try {
			resMap = mainService.generateAndDeployDllModule(vo,isStatic);
		} catch(Exception e) {
			e.printStackTrace();
		}

		return resMap;
	}

}
