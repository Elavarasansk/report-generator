package com.intraweb.project_basecamp_automation.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.intraweb.project_basecamp_automation.entity.DllGenerateEntity;

public interface DllGenerateRepo extends MongoRepository<DllGenerateEntity, String> {

	List<DllGenerateEntity> findByDprPath(String dprPath);
	
}
