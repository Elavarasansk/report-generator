package com.intraweb.project_basecamp_automation.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Service;

import com.intraweb.project_basecamp_automation.constants.MainConstants;
import com.intraweb.project_basecamp_automation.entity.DllGenerateEntity;
import com.intraweb.project_basecamp_automation.entity.DprDetailsEntity;
import com.intraweb.project_basecamp_automation.entity.ProgressBar;
import com.intraweb.project_basecamp_automation.repository.DllGenerateRepo;
import com.intraweb.project_basecamp_automation.utility.GITConstants;
import com.intraweb.project_basecamp_automation.vo.DllGenerateModuleVo;

@Service
public class MainService {

	@Autowired
	private DllGenerateRepo repo;

	@Autowired
	private WebConvertService webConvertService;

	@Autowired
	private SimpMessageSendingOperations messagingTemplate;

	private void updateProgressPercent(float percentage, String dprName,int step, String logs, String status) {
		messagingTemplate.convertAndSend("/topic/public",ProgressBar.builder()
				.percentage(percentage)
				.dprName(dprName)
				.step(step)
				.logs(logs)
				.status(status)
				.build());
	}

	public List<String> getDprList(String repo) {
		String format[] = { "dpr" };
		List<String> fileList = new ArrayList<>();

		String repoPath = new String();

		switch(repo.toUpperCase()) {
		case "COM":
			repoPath = MainConstants.SVN41_COM;
			break;
		case "CAM":
			repoPath = MainConstants.SVN41_CAM;
			break;
		case "CBM":
			repoPath = MainConstants.SVN41_CBM;
			break;
		case "CCM":
			repoPath = MainConstants.SVN41_CCM;
			break;
		case "CFM":
			repoPath = MainConstants.SVN41_CFM;
			break;
		default:
			repoPath = null;
			break;
		}

		if(Objects.isNull(repoPath) || !new File(repoPath).exists()) {
			return null;
		}

		fileList = FileUtils.listFiles(new File(repoPath), format, true).stream()
				.filter(file-> !file.getAbsolutePath().toLowerCase().contains("renderingcomponents"))
				.filter(file-> !file.getAbsolutePath().toLowerCase().contains("accommon"))
				.filter(file -> !((File) file).getName().contains("_FORDEV"))
				.map(file -> file.getPath()).collect(Collectors.toList());
		return fileList;
	}

	public Map<String, Object> generateAndDeployDllModule(DllGenerateModuleVo vo, boolean isStatic) {
		List<String> dprList = getDprList(vo.getModule());
		Map<String, Object> resMap = new HashMap<>();
		executeMultiple(dprList,isStatic,true);
		resMap.put("status", "200");
		resMap.put("message", "Operation successful");
		return resMap;
	}

	public List<DllGenerateEntity> executeMultiple(List<String> dprList, boolean isStatic, boolean isGroupBuild) {
		List<DllGenerateEntity> list = new ArrayList<>(); 

		Map<String, List<DllGenerateEntity>> dbDprRec = new HashMap<>();

		repo.findAll().stream().forEach(entity -> {
			String dprPath = entity.getDprPath();
			List<DllGenerateEntity> dbDpr = dbDprRec.get(dprPath);
			if(Objects.nonNull(dbDpr)) {
				dbDpr.add(entity);
			} else {
				List<DllGenerateEntity> dbData = new ArrayList<>();
				dbData.add(entity);
				dbDprRec.put(dprPath, dbData);
			}
		});

		IntStream.range(0, dprList.size()).forEach(idx -> {
			String dprPath = dprList.get(idx);
			try {
				Boolean status = false;
				DllGenerateEntity savedEntity = DllGenerateEntity.builder().build();
				List<DllGenerateEntity> entityData = dbDprRec.get(dprPath);
				DllGenerateEntity entity = Objects.nonNull(entityData) ? entityData.get(0) : DllGenerateEntity.builder().build() ;
				if(isGroupBuild) {
					savedEntity = executeGroupBuild(dprPath,entity,isStatic);
					int cutoff = Math.round(dprList.size()/3);
					if(cutoff == idx) {
						updateProgressPercent(50,dprPath,2,"Web Convert Success","pass");
					} else if((cutoff*2) == idx) {
						updateProgressPercent(75,dprPath,3,"DLL Generated Successfully" ,"pass");
					} else if(idx == dprList.size()-1){
						updateProgressPercent(100,dprPath,4,"DLL deployed sucessfully" ,"pass");
					}
				} else {
					status = webConvert(dprPath, entity);
					if(status) {
						generateDllFiles(dprPath, entity, isStatic);
						savedEntity = saveResultData(dprPath, entity);
					} else {
						savedEntity = saveResultData(dprPath, entity);
					}
				}
				list.add(savedEntity);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		return list;
	}

	public boolean webConvert(String dprPath, DllGenerateEntity entity) throws Exception {
		LocalDateTime webConvertStart = LocalDateTime.now();
		boolean convertStatus = webConvertService.convertSingle(dprPath);
		LocalDateTime webConvertEnd = LocalDateTime.now();
		entity.setWebConvertDuration(Duration.between(webConvertStart, webConvertEnd));
		if(convertStatus) {
			updateProgressPercent(50,dprPath,2,"Web Convert Success","pass");
		} else {
			entity.setIsDllDeployed(convertStatus);
			entity.setIsDllGenerated(convertStatus);
			updateProgressPercent(50,dprPath,2,"Web Convert Failed","fail");
			entity.setDllGenerateDuration(Duration.ZERO);
			entity.setDllDeployDuration(Duration.ZERO);
		}
		return convertStatus;
	}

	public void generateDllFiles(String dprPath, DllGenerateEntity entity, boolean isStatic) {
		LocalDateTime compileStart = LocalDateTime.now();
		List<File> dllFilesList = compileDpr(dprPath, entity, isStatic);
		boolean status = dllFilesList.isEmpty();
		LocalDateTime compileEnd = LocalDateTime.now();
		entity.setDllGenerateDuration(Duration.between(compileStart, compileEnd));
		entity.setIsDllGenerated(!status);
		if(status) {
			updateProgressPercent(75,dprPath,3,"DLL Generation Failed" ,"fail");
			entity.setIsDllDeployed(!status);
			entity.setDllDeployDuration(Duration.ZERO);
		} else {
			updateProgressPercent(75,dprPath,3,"DLL Generated Successfully" ,"pass");
			deployIIS(dprPath, entity, dllFilesList.get(0), isStatic);
		}
	}

	public void deployIIS(String dprPath, DllGenerateEntity entity, File dllFile, boolean isStatic) {
		LocalDateTime deployStart = LocalDateTime.now();
		boolean status = moveDllToIIS(dllFile,isStatic);
		LocalDateTime deployEnd = LocalDateTime.now();
		entity.setDllDeployDuration(Duration.between(deployStart, deployEnd));
		entity.setIsDllDeployed(status);
		if(status) {
			updateProgressPercent(100,dprPath,4,"DLL deployed sucessfully" ,"pass");
		} else {
			updateProgressPercent(85,dprPath,4,"DLL deploy Failed" ,"fail");
		}
	}

	public DllGenerateEntity executeGroupBuild(String dprPath, DllGenerateEntity entity, boolean isStatic) throws Exception {
		try {
			LocalDateTime webConvertStart = LocalDateTime.now();
			boolean convertStatus = webConvertService.convertSingle(dprPath);
			LocalDateTime webConvertEnd = LocalDateTime.now();
			entity.setWebConvertDuration(Duration.between(webConvertStart, webConvertEnd));
			if(convertStatus) {
				LocalDateTime compileStart = LocalDateTime.now();
				List<File> dllFilesList = compileDpr(dprPath, entity, isStatic);
				boolean status = dllFilesList.isEmpty();
				LocalDateTime compileEnd = LocalDateTime.now();
				entity.setDllGenerateDuration(Duration.between(compileStart, compileEnd));
				entity.setIsDllGenerated(!status);
				if(status) {
					entity.setIsDllDeployed(!status);
					entity.setDllDeployDuration(Duration.ZERO);
				} else {
					LocalDateTime deployStart = LocalDateTime.now();
					status = moveDllToIIS(dllFilesList.get(0),isStatic);
					LocalDateTime deployEnd = LocalDateTime.now();
					entity.setDllDeployDuration(Duration.between(deployStart, deployEnd));
					entity.setIsDllDeployed(true);
				}
			} else {
				entity.setIsDllDeployed(convertStatus);
				entity.setIsDllGenerated(convertStatus);
				entity.setDllGenerateDuration(Duration.ZERO);
				entity.setDllDeployDuration(Duration.ZERO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Group Build Failed - " + e.getMessage());
		}
		return saveResultData(dprPath, entity);
	}


	public DllGenerateEntity saveResultData(String dprPath, DllGenerateEntity entity) {
		File dpr = new File(dprPath);
		entity.setDprName(dpr.getName());
		entity.setDprPath(dpr.getPath());
		entity.setLastCompiled(LocalDateTime.now());
		return repo.save(entity);
	}


	public DllGenerateEntity getDprCompileDetails(String dprPath) {
		List<DllGenerateEntity> dbRec = repo.findByDprPath(dprPath).stream()
				.sorted(Comparator.comparing(DllGenerateEntity::getLastCompiled).reversed())
				.collect(Collectors.toList());
		if(dbRec.size() > 0) {
			return dbRec.get(0);
		}
		return DllGenerateEntity.builder().build();
	}

	public Map<String, Object> getAllDprs() {
		List<DprDetailsEntity> allDprList = new ArrayList<>();
		Map<String, Object>  resultMap = new HashMap<>();

		List<DprDetailsEntity> comList = new ArrayList<>();
		List<DprDetailsEntity> camList = new ArrayList<>();
		List<DprDetailsEntity> ccmList = new ArrayList<>();
		List<DprDetailsEntity> cfmList = new ArrayList<>();
		List<DprDetailsEntity> cbmList = new ArrayList<>();

		getDprForModule("COM", comList);
		getDprForModule("CAM", camList);
		getDprForModule("CBM", cbmList);
		getDprForModule("CCM", ccmList);
		getDprForModule("CFM", cfmList);

		allDprList.addAll(comList);
		allDprList.addAll(camList);
		allDprList.addAll(ccmList);
		allDprList.addAll(cfmList);
		allDprList.addAll(cbmList);


		resultMap.put("CCM", ccmList.size());
		resultMap.put("CAM", camList.size());
		resultMap.put("CBM", cbmList.size());
		resultMap.put("COM", comList.size());
		resultMap.put("CFM", cfmList.size());
		resultMap.put("ALL", allDprList.size());

		Map<String, Object>  dataMap = new HashMap<>();
		dataMap.put("data",  allDprList);
		dataMap.put("count", resultMap);
		return dataMap;
	}

	private void getDprForModule(String module, List<DprDetailsEntity> entity) {
		repo.findAll().stream().filter(record -> record.getModule().equals(module)).forEach(dpr -> {
			DprDetailsEntity dprEntity = DprDetailsEntity.builder().dprName(dpr.getDprName()).dprPath(dpr.getDprPath())
					.module(module).lastCompiled(dpr.getLastCompiled()).isDllGenerated(dpr.getIsDllGenerated())
					.isDllDeployed(dpr.getIsDllDeployed()).build();
			entity.add(dprEntity);
		});
	}

	private List<File> compileDpr(String dprPath, DllGenerateEntity entity, boolean isStatic) {
		try {
			dprPath = dprPath.replace("hue_client", "hue_web");
			File dpr = new File(dprPath);
			List<String> compileLog = new ArrayList<>();

			ProcessBuilder processBuilder = new ProcessBuilder();
			Process p = null;
			processBuilder.directory(dpr.getParentFile());
			if(isStatic) {
				processBuilder.command("D:\\Borland\\Delphi7\\Bin\\dcc32.exe", dpr.getName());
			}else {
				processBuilder.command("D:\\Borland\\Delphi7\\Bin\\dcc32.exe","-LU"+GITConstants.DYNAMIC_DLL_PARAM, dpr.getName());
			}
			processBuilder.redirectErrorStream(true);
			p = processBuilder.start();

			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			List<String> linesList = new ArrayList<>();
			String line;
			while ((line = reader.readLine()) != null) {
				linesList.add(line);
			}

			linesList.stream().forEach(lne -> {
				compileLog.add(lne);
			});

			entity.setCompileLog(compileLog);

			String[] format = { "dll" };
			List<File> dllFilesList = FileUtils.listFiles(dpr.getParentFile(), format, true).stream().map(file -> (File) file).collect(Collectors.toList());
			return dllFilesList;

		} catch(Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	private boolean moveDllToIIS(File filePath, boolean isStatic) {
		try {
			String location = isStatic ? MainConstants.IIS_STATIC : MainConstants.IIS_DYNAMIC;
			File dllFile = new File(location+ "\\" + filePath.getName());
			if(dllFile.exists()) {
				dllFile.delete();
			}
			FileUtils.copyFileToDirectory(filePath, new File(location), true);
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public Map<String, String> createMetaData() {

		Map<String, String>  dataMap = new HashMap<>();

		repo.deleteAll();

		getAllDprForModule(MainConstants.SVN41_COM, "COM");
		dataMap.put("COM", String.valueOf(repo.findAll().stream()
				.filter(record -> record.getModule().equals("COM")).count()));
		getAllDprForModule(MainConstants.SVN41_CAM, "CAM");
		dataMap.put("CAM", String.valueOf(repo.findAll().stream()
				.filter(record -> record.getModule().equals("CAM")).count()));
		getAllDprForModule(MainConstants.SVN41_CBM, "CBM");
		dataMap.put("CBM", String.valueOf(repo.findAll().stream()
				.filter(record -> record.getModule().equals("CBM")).count()));
		getAllDprForModule(MainConstants.SVN41_CCM, "CCM");
		dataMap.put("CCM", String.valueOf(repo.findAll().stream()
				.filter(record -> record.getModule().equals("CCM")).count()));
		getAllDprForModule(MainConstants.SVN41_CFM, "CFM");
		dataMap.put("CFM", String.valueOf(repo.findAll().stream()
				.filter(record -> record.getModule().equals("CFM")).count()));

		dataMap.put("status", "200");
		dataMap.put("message", "MetaData created Successfully");

		return dataMap;

	}


	private void getAllDprForModule(String modulePath, String module) {
		String format[] = { "dpr" };
		if(!new File(modulePath).exists()) {
			return;
		}

		FileUtils.listFiles(new File(modulePath), format, true).stream()
		.filter(file-> !file.getAbsolutePath().toLowerCase().contains("renderingcomponents"))
		.filter(file-> !file.getAbsolutePath().toLowerCase().contains("accommon"))
		.filter(file -> !((File) file).getName().contains("_FORDEV")).forEach(dpr -> {
			DllGenerateEntity saveEntity = DllGenerateEntity.builder().dprName(dpr.getName()).dprPath(dpr.getPath()).module(module)
					.compileLog(new ArrayList<>()).isDllGenerated(false).isDllDeployed(false).lastCompiled(null)
					.webConvertDuration(Duration.ZERO).dllGenerateDuration(Duration.ZERO).dllDeployDuration(Duration.ZERO).build();
			repo.save(saveEntity);
		});
	}

}
