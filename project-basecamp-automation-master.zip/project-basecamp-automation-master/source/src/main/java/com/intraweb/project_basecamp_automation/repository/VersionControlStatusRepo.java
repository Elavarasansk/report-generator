package com.intraweb.project_basecamp_automation.repository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.intraweb.project_basecamp_automation.entity.VersionControlStatus;

public interface VersionControlStatusRepo extends MongoRepository<VersionControlStatus, String> {
	
	VersionControlStatus findByVersionTypeAndModule(String version, String moduleName);

}
