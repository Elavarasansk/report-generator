package com.intraweb.project_basecamp_automation.vo;

import lombok.Data;

@Data
public class DllGenerateModuleVo {

	private String module;
	
}
