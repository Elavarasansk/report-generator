package com.intraweb.project_basecamp_automation.entity;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DprDetailsEntity {

	private String dprName;
	private String dprPath;
	private String module;
	private Boolean isDllGenerated;
	private Boolean isDllDeployed;
	private LocalDateTime lastCompiled;
	
}
