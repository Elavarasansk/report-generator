package com.intraweb.project_basecamp_automation.service;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullResult;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.TextProgressMonitor;
import org.eclipse.jgit.transport.TrackingRefUpdate;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.intraweb.project_basecamp_automation.dto.GitPullResponse;
import com.intraweb.project_basecamp_automation.dto.RefsTrackingUpdate;
import com.intraweb.project_basecamp_automation.repository.VersionControlStatusRepo;
import com.intraweb.project_basecamp_automation.utility.BuildPackage;
import com.intraweb.project_basecamp_automation.utility.GITConstants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GitSyncService {

	@Value("${acgit.url}")
	private String acgitUrl;

	@Value("${acgit.user.name}")
	private String acgitUserName;

	@Value("${acgit.user.password}")
	private String acgitPassword;

	@Value("classpath:mvn_cfw.bat")
	Resource cfwResource;


	public void multiRepoSyncThread() throws IOException {
		cacGitPull();
		String filePath  = FileUtils.getTempDirectoryPath()+File.separator+"mvn_cfw.bat";
		if(!(new File(filePath).exists())) {
			File newFile = new File(filePath);
			FileUtils.copyInputStreamToFile(cfwResource.getInputStream(), newFile);
			filePath= newFile.getAbsolutePath();
		}

		BuildPackage.build(filePath);
	}

	
	public GitPullResponse cacGitPull() {
		GitPullResponse response = GitPullResponse.builder().build();
		File cacRepoPath = new File(GITConstants.HUE_DEVELOP+GITConstants.CFW_TOOL_REPO);
		if(cacRepoPath.exists()) {
			pullExistingRepo(cacRepoPath);
		} else {
			cloneNonExistingRepo(GITConstants.CFW_TOOL_REPO);
		}
		return response;
	}

	private void cloneNonExistingRepo(String repo) {
		UsernamePasswordCredentialsProvider credsProvider = new UsernamePasswordCredentialsProvider(acgitUserName, acgitPassword);
		log.info("Cloning the repo - "+repo+" Started @" + new Date(System.currentTimeMillis()));
		try {
			Git.cloneRepository()
			.setURI(acgitUrl+repo)
			.setCredentialsProvider(credsProvider)
			.setDirectory(new File(GITConstants.HUE_DEVELOP))
			.call();
			log.info("Cloning the repo - "+repo+" Completed @" + new Date(System.currentTimeMillis()));
		} catch (GitAPIException e) {
			e.printStackTrace();
			log.error("Cloning the repo - "+repo+" failed " + new Date(System.currentTimeMillis()));
		}
	}

	private GitPullResponse pullExistingRepo(File repoPath) {
		GitPullResponse response = GitPullResponse.builder().build();
		String repoName = repoPath.getPath();

		File lockFile = new File(repoName + "\\" + GITConstants.INDEX_LOCK_FILE);
		if(lockFile.exists()) {
			lockFile.delete();
		}

		UsernamePasswordCredentialsProvider credsProvider = new UsernamePasswordCredentialsProvider(acgitUserName, acgitPassword);
		log.info("Started @ git pull - "+repoName+" " + new Date(System.currentTimeMillis()));
		try {
			Git localGit = Git.open(repoPath);
			PullResult pullRes = localGit.pull()
					.setProgressMonitor(new TextProgressMonitor(new PrintWriter(System.out)))
					.setRemote(GITConstants.ORIGIN)
					.setCredentialsProvider(credsProvider).call();
			log.info("Result "+ pullRes.getMergeResult());
			log.info("Completed @ git pull - "+repoName+" " + new Date(System.currentTimeMillis()));
			localGit.close();
			response = processPullResult(pullRes);
		} catch (GitAPIException | IOException e) {
			log.error("Error Fetching the repo "+ e.getMessage());
		}
		return response;
	}

	private GitPullResponse processPullResult(PullResult pullResult) {
		Collection<TrackingRefUpdate> trackingRef = pullResult.getFetchResult().getTrackingRefUpdates();

		List<RefsTrackingUpdate> trackingUpdate = trackingRef.stream().map(y ->RefsTrackingUpdate.builder()
				.remoteName(y.getRemoteName())
				.trackResult(y.getResult().toString())
				.build()).collect(Collectors.toList());

		return GitPullResponse.builder()
				.fetchFrom(pullResult.getFetchedFrom())
				.mergeSuccess(pullResult.getMergeResult().getMergeStatus().isSuccessful())
				.pullSuccess(pullResult.isSuccessful())
				.remoteUri(pullResult.getFetchResult().getURI().toString())
				.trackingUpdate(trackingUpdate)
				.build();
	}

}
