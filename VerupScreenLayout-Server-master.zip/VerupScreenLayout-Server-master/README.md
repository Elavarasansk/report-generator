hit url in the following format

http://localhost:8080/getDetails?dprName=ItemCompPortal