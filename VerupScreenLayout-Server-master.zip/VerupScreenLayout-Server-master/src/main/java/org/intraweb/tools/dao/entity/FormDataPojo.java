package org.intraweb.tools.dao.entity;

import java.util.Map;

import lombok.Data;

@Data
public class FormDataPojo {

    String dprName;

    String moduleName;

    String fileName;

    String filePath;

    String status;

    Map<String, Object> comment;

    String mode;

    String imagePath;

}