package org.intraweb.tools.dao.entity;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class VerupScreenLayoutEntity {

    public VerupScreenLayoutEntity(){}

    public VerupScreenLayoutEntity(String dprName, String dprPath, int frameCount, Map<String, Object> dprFrame,
            Map<String, Object> sharedFrame, String companyClient, String hueClient,boolean dprCheckedStatus) {
        super();
        this.dprName = dprName;
        this.dprPath = dprPath;
        this.frameCount = frameCount;
        this.dprFrame = dprFrame;
        this.sharedFrame = sharedFrame;
        this.companyClient = companyClient;
        this.hueClient = hueClient;
        this.dprCheckedStatus = dprCheckedStatus;
    }

    private String dprName;

    private String dprPath;

    private int frameCount;

    private Map<String,Object> dprFrame;

    private Map<String,Object> sharedFrame;

    private String companyClient;

    private String hueClient;

    private boolean dprCheckedStatus;

}
