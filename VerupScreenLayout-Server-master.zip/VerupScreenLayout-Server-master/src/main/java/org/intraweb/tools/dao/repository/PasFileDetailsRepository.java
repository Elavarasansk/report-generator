package org.intraweb.tools.dao.repository;

import java.util.List;

import org.intraweb.tools.dao.dto.PasFileDetailsEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PasFileDetailsRepository extends MongoRepository<PasFileDetailsEntity, String> {

    List<PasFileDetailsEntity> findByPasFileName(String pasFileName);

}
