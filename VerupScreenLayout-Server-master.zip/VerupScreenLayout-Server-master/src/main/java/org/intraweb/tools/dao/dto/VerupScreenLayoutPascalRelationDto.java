package org.intraweb.tools.dao.dto;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "pascal-data")
public class VerupScreenLayoutPascalRelationDto {

    @Id
    private ObjectId id;

    private String filePath;

    private String frameName;

    private List<String> companyClientPathList;

    private List<String> hueClientPathList;

    private String ownDprName;

    private List<String> sharedDprName;

    private String pascalCheckedStatus;

    private String frameCaptionJa;

    private String frameCaptionEn;

}
