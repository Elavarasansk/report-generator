package org.intraweb.tools.constant;

public class VerupScreenlayoutConstant {

    public static final String DPRTEXT = ".dpr";

    public static final String EMPTYTEXT = "";

    public static final String DELPHITEXT = "\\delphi\\";

    public static final String PASTEXT = ".pas";

    public static final String DFMTEXT = ".dfm";

    public static final String COMPANY_CLIENT_PATH_TEXT = "\\company_client";

    public static final String HUE_CLIENT_PATH_TEXT = "\\hue_client";

    public static final int CONSTANT_ZERO = 0;

    public static final int CONSTANT_THREE = 3;

    public static final int CONSTANT_FOUR = 4;

    public static final int CONSTANT_FIVE = 5;

    public static final int CONSTANT_SIX = 6;

    public static final int ROWCOUNT = 12;

    public static final int CONSTANT_TWO = 2;

    public static final String DEFAULT_PATH_TEXT = "D:\\SVN\\";

    public static final String NOT_YET_STARTED_TEXT = "NOT YET STARTED";

    public static final String PENDING_TEXT = "PENDING";

    public static final String REVIEWED_TEXT = "REVIEWED";

    public static final String LOCAL_REPOSITORY_TEXT = "D:\\";

    public static final String MODULE_CAM = "CAM\\";

    public static final String MODULE_CBM = "CBM\\";

    public static final String MODULE_CCM = "CCM\\";

    public static final String MODULE_COM = "COM\\";

    public static final String MODULE_CFM = "CFM\\";

    public static final String BACKWARD_SLASH_TEXT = "\\";

    public static final int CONSTANT_ONE = 1;

    public static final String CAPTION_TEXT = "Caption = ";

    public static final String SINGLE_APOSTROPHE_TEXT = "'";

    public static final String HASHCODE_TEXT = "#";

    public static final String GOOGLEAPI_URL = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=ja&tl=en&dt=t&q=";

    public static final String CAM = "CAM";

    public static final String CBM = "CBM";

    public static final String CCM = "CCM";

    public static final String COM = "COM";

    public static final String CFM = "CFM";

    public static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss";

    public static final String CDN_UPLOAD_PATH = "http://192.168.57.30/cdn/uploads?filepath=";

    public static final String CDN_GET_PATH = "http://192.168.57.30/cdn/getfilename?filepath=";

    public static final String CDN_GET_SPECIFICIMAGE_PATH = "http://192.168.57.59/cdn/getspecificformname?filepath=";

    public static final String OPENCURLY_BRACE = "{";

    public static final String CLOSECURLY_BRACE = "}";

    public static final String OPEN_BRACE = "(";

    public static final String CLOSE_BRACE = ")";

    public static final String OPENSQUARE_BRACE = "[";

    public static final String CLOSESQUARE_BRACE = "]";

    public static final String COMMA = ",";

    public static final String HUE_CLIENT = "hue_client";

    public static final String COMPANY_CLIENT = "company_client";

    public static final String BACK_SLASH = "\"";

    public static final String UPLOAD = "upload";

    public static final String DELETE = "delete";

}
