package org.intraweb.tools.dao.entity;

import java.util.List;
import java.util.Map;

import org.intraweb.tools.dao.dto.VerupScreenLayoutFormControlDto;

import lombok.Data;

@Data
public class VerupScreenLayoutFormControlEntity {

    private String dprName;

    private String fileName;

    private String filePath;

    private List<Map<String, Object>> comments;

    private String pascalCheckedStatus;

    private String createUserName;

    private String updateUserName;

    private String createdDate;

    private String updatedDate;

    private List<String> sharedDpr;

    public static VerupScreenLayoutFormControlDto entityToDtoConverter(VerupScreenLayoutFormControlEntity entity) {
        return VerupScreenLayoutFormControlDto.builder().dprName(entity.getDprName()).fileName(entity.getFileName())
                .filePath(entity.getFilePath()).comments(entity.getComments())
                .pascalCheckedStatus(entity.getPascalCheckedStatus()).createUserName(entity.getCreateUserName())
                .updateUserName(entity.getUpdateUserName()).createdDate(entity.getCreatedDate())
                .updatedDate(entity.getUpdatedDate()).sharedDpr(entity.getSharedDpr()).build();
    }

    public static VerupScreenLayoutFormControlDto entityToDtoConverter(VerupScreenLayoutFormControlEntity entity,
            VerupScreenLayoutFormControlDto dto) {
        return VerupScreenLayoutFormControlDto.builder().id(dto.getId()).dprName(entity.getDprName())
                .fileName(entity.getFileName()).filePath(entity.getFilePath()).comments(entity.getComments())
                .pascalCheckedStatus(entity.getPascalCheckedStatus()).createUserName(entity.getCreateUserName())
                .updateUserName(entity.getUpdateUserName()).createdDate(entity.getCreatedDate())
                .updatedDate(entity.getUpdatedDate()).sharedDpr(entity.getSharedDpr()).build();
    }

}
