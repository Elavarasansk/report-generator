package org.intraweb.tools.dao.dto;

import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
@Document(collection = "form-control")
public class VerupScreenLayoutFormControlDto {

    @Id
    private ObjectId id;

    private String dprName;

    private String fileName;

    private String filePath;

    private List<Map<String, Object>> comments;

    private String pascalCheckedStatus;

    private String createUserName;

    private String updateUserName;

    private String createdDate;

    private String updatedDate;

    private List<String> sharedDpr;

}
