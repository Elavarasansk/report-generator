package org.intraweb.tools.dao.repository;

import java.util.List;

import org.intraweb.tools.dao.dto.VerupScreenLayoutFormControlDto;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface VerupScreenLayoutFormControlRepository
        extends MongoRepository<VerupScreenLayoutFormControlDto, String> {

    VerupScreenLayoutFormControlDto findByFilePath(String filePath);

    List<VerupScreenLayoutFormControlDto> findByDprNameOrSharedDpr(String dprName, String sharedDpr);
}
