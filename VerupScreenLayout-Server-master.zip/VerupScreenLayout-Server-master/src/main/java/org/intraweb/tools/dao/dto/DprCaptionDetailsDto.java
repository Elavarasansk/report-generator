package org.intraweb.tools.dao.dto;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;

@Document(collection = "dpr_caption_data")
@Getter
public class DprCaptionDetailsDto {

    @Id
    private ObjectId id;
    private String dprName;
    private String captionJa;
    private String captionEn;

}
