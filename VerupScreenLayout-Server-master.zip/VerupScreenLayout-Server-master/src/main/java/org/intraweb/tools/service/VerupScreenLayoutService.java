package org.intraweb.tools.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Workbook;
import org.intraweb.tools.constant.VerupScreenlayoutConstant;
import org.intraweb.tools.dao.VerupScreenLayoutDao;
import org.intraweb.tools.dao.dto.DprCaptionDetailsDto;
import org.intraweb.tools.dao.dto.DprDetailsDto;
import org.intraweb.tools.dao.dto.PasFileDetailsEntity;
import org.intraweb.tools.dao.dto.VerupScreenLayoutDprRelationDto;
import org.intraweb.tools.dao.dto.VerupScreenLayoutFormControlDto;
import org.intraweb.tools.dao.dto.VerupScreenLayoutPascalRelationDto;
import org.intraweb.tools.dao.entity.FormDataPojo;
import org.intraweb.tools.dao.entity.GetMappingPojo;
import org.intraweb.tools.dao.entity.VerupScreenLayoutFormControlEntity;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class VerupScreenLayoutService {

    @Autowired
    private VerupScreenLayoutDao verupScreenLayoutDao;

    private List<Map<String, Object>> getGridData(VerupScreenLayoutDprRelationDto verupScreenLayoutDprRelationDto) {
        List<Map<String, Object>> pathList = new ArrayList<Map<String, Object>>();
        List<VerupScreenLayoutPascalRelationDto> pascalDataList = verupScreenLayoutDao
                .getPascalDataList(verupScreenLayoutDprRelationDto.getDprName());
        Map<String, VerupScreenLayoutPascalRelationDto> pascalDataMap = pascalDataList.stream()
                .collect(Collectors.toMap(VerupScreenLayoutPascalRelationDto::getFilePath, pasData -> pasData));
        for (Entry<String, Object> dprFrame : verupScreenLayoutDprRelationDto.getFramePath().entrySet()) {
            Map<String, Object> pathMap = new HashMap<String, Object>();
            VerupScreenLayoutPascalRelationDto pascalData = pascalDataMap.get(dprFrame.getValue());
            pathMap.put("filePath", pascalData.getFilePath());
            pathMap.put("targetDprName", pascalData.getOwnDprName());
            pathMap.put("dprCaption", getDprCaption(pascalData.getOwnDprName(), true));
            pathMap.put("status", pascalData.getPascalCheckedStatus());
            pathMap.put("formCaption", getFormCaption(pascalData, true));
            pathMap.put("key", pathList.size());
            pathList.add(pathMap);
        }
        return pathList;
    }

    private Map<String, Object> getStatusCount(VerupScreenLayoutDprRelationDto verupScreenLayoutDprRelationDto) {
        Map<String, Object> frameCountMap = new HashMap<String, Object>();
        Map<String, Object> statusMap = new HashMap<String, Object>();
        List<VerupScreenLayoutPascalRelationDto> pascalDataList = new ArrayList<VerupScreenLayoutPascalRelationDto>();
        int notYetStartedCountOwn = 0, pendingCountOwn = 0, completedCountOwn = 0, notYetStartedCountShared = 0,
                pendingCountShared = 0, completedCountShared = 0;
        pascalDataList = verupScreenLayoutDao.getPascalDataList(verupScreenLayoutDprRelationDto.getDprName());
        Map<String, VerupScreenLayoutPascalRelationDto> PascalDataMap = pascalDataList.stream()
                .collect(Collectors.toMap(VerupScreenLayoutPascalRelationDto::getFilePath, pasData -> pasData));
        for (Map.Entry<String, Object> map : verupScreenLayoutDprRelationDto.getFramePath().entrySet()) {
            VerupScreenLayoutPascalRelationDto pascalData = PascalDataMap.get(map.getValue());
            if (pascalData.getPascalCheckedStatus() != null) {
                String status = pascalData.getPascalCheckedStatus();
                if (pascalData.getOwnDprName().equals(verupScreenLayoutDprRelationDto.getDprName())) {
                    if (status.equals(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT)) {
                        notYetStartedCountOwn++;
                    } else if (status.equals(VerupScreenlayoutConstant.PENDING_TEXT)) {
                        pendingCountOwn++;
                    } else if (status.equals(VerupScreenlayoutConstant.REVIEWED_TEXT)) {
                        completedCountOwn++;
                    }
                } else {
                    if (status.equals(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT)) {
                        notYetStartedCountShared++;
                    } else if (status.equals(VerupScreenlayoutConstant.PENDING_TEXT)) {
                        pendingCountShared++;
                    } else if (status.equals(VerupScreenlayoutConstant.REVIEWED_TEXT)) {
                        completedCountShared++;
                    }
                }
            }
        }
        frameCountMap.put("notYetStarted", notYetStartedCountOwn);
        frameCountMap.put("pending", pendingCountOwn);
        frameCountMap.put("reviewedCount", completedCountOwn);
        statusMap.put("ownForms", frameCountMap);
        frameCountMap = new HashMap<String, Object>();
        frameCountMap.put("notYetStarted", notYetStartedCountShared);
        frameCountMap.put("pending", pendingCountShared);
        frameCountMap.put("reviewedCount", completedCountShared);
        statusMap.put("sharedForms", frameCountMap);
        return statusMap;
    }

    private Map<String, Object> getDprCaption(String fileName, boolean noNeedEnCaption) {
        Map<String, Object> captionMap = new HashMap<String, Object>();
        DprDetailsDto dprData = new DprDetailsDto();
        dprData = verupScreenLayoutDao.getDprInfo(fileName);
        captionMap.put("en", dprData.getCaptionEn());
        if (noNeedEnCaption) {
            captionMap.put("en", fileName);
        }
        captionMap.put("ja", dprData.getCaptionJa());
        return captionMap;
    }

    private Map<String, Object> getFormCaption(VerupScreenLayoutPascalRelationDto pascalData, boolean noNeedEnCaption) {
        Map<String, Object> captionMap = new HashMap<String, Object>();
        if (pascalData != null) {
            captionMap.put("en", pascalData.getFrameCaptionEn());
            if (noNeedEnCaption) {
                captionMap.put("en", Paths.get(pascalData.getFilePath()).getFileName().toString());
            }
            captionMap.put("ja", pascalData.getFrameCaptionJa());
        }
        return captionMap;
    }

    public Map<String, Object> getDprInformation(GetMappingPojo getData) {
        VerupScreenLayoutDprRelationDto verupScreenLayoutDprRelationDto;
        List<VerupScreenLayoutPascalRelationDto> pascalDataList = new ArrayList<VerupScreenLayoutPascalRelationDto>();
        List<VerupScreenLayoutFormControlDto> formcontrolDataList = new ArrayList<VerupScreenLayoutFormControlDto>();
        List<Map<String, Object>> pathList = new ArrayList<Map<String, Object>>();
        List<String> filePathList = new ArrayList<String>();
        List<Object> fileNameList = new ArrayList<Object>();
        Map<String, Object> frameCountMap = new HashMap<String, Object>();
        verupScreenLayoutDprRelationDto = verupScreenLayoutDao.getGridData(getData);
        Map<String, Object> dprFrameMap = new HashMap<String, Object>();
        if (verupScreenLayoutDprRelationDto == null) {
            dprFrameMap.put("message", "Data not found for dprname: " + getData.getDprName());
            dprFrameMap.put("statusCode", "404");
            return dprFrameMap;
        }
        pascalDataList = verupScreenLayoutDao.getPascalDataList(verupScreenLayoutDprRelationDto.getDprName());
        Map<String, VerupScreenLayoutPascalRelationDto> pascalDataMap = pascalDataList.stream()
                .collect(Collectors.toMap(VerupScreenLayoutPascalRelationDto::getFilePath, pasData -> pasData));
        formcontrolDataList = verupScreenLayoutDao.getAllFormControlData(verupScreenLayoutDprRelationDto.getDprName());
        Map<String, VerupScreenLayoutFormControlDto> formControlDataMap = formcontrolDataList.stream()
                .collect(Collectors.toMap(VerupScreenLayoutFormControlDto::getFilePath, formData -> formData));
        for (Entry<String, Object> dprFrame : verupScreenLayoutDprRelationDto.getFramePath().entrySet()) {
            VerupScreenLayoutFormControlDto formcontrolData;
            Map<String, Object> activeIndexMap = new HashMap<String, Object>();
            Map<String, Object> companyClientPathMap = new HashMap<String, Object>();
            List<String> companyClientPathList = new ArrayList<String>();
            List<String> hueClientPathList = new ArrayList<String>();
            VerupScreenLayoutPascalRelationDto pascalData = pascalDataMap.get(dprFrame.getValue().toString());
            try {
                companyClientPathList = getImageSourceList(pascalData.getCompanyClientPathList());
                hueClientPathList = getImageSourceList(pascalData.getHueClientPathList());
            } catch (IOException exception) {
                exception.printStackTrace();
            }
            companyClientPathMap.put("filePath", pascalData.getFilePath());
            companyClientPathMap.put("fileName", Paths.get(pascalData.getFilePath()).getFileName().toString());
            companyClientPathMap.put("v36", companyClientPathList);
            companyClientPathMap.put("v40", hueClientPathList);
            companyClientPathMap.put("formCaption", getFormCaption(pascalData, false));
            companyClientPathMap.put("ownDprName", pascalData.getOwnDprName());
            Map<String, Object> indexMap = new HashMap<String, Object>();
            indexMap.put("v36Index", "0");
            indexMap.put("v40Index", "0");
            if (getData.getMode() != null && getData.getMode().equals(VerupScreenlayoutConstant.UPLOAD)
                    && getData.getFilepath().equals(pascalData.getFilePath())) {
                indexMap.put("v40Index", Integer.toString(hueClientPathList.size() - 1));
            }
            if (getData.getMode() != null && getData.getMode().equals(VerupScreenlayoutConstant.DELETE)
                    && getData.getFilepath().equals(pascalData.getFilePath())) {
                indexMap.put("v40Index", Integer.toString(getData.getImageRemovedIndex()));
            }
            activeIndexMap.put("slide", indexMap);
            activeIndexMap.put("list", indexMap);
            companyClientPathMap.put("activeIndex", activeIndexMap);
            filePathList.add(pascalData.getFilePath());
            fileNameList.add(Paths.get(pascalData.getFilePath()).getFileName().toString());
            formcontrolData = formControlDataMap.get(pascalData.getFilePath().toString());
            if (formcontrolData != null) {
                companyClientPathMap.put("comments", formcontrolData.getComments());
                companyClientPathMap.put("formStatus", formcontrolData.getPascalCheckedStatus());
            } else {
                companyClientPathMap.put("comments", new ArrayList<String>());
                companyClientPathMap.put("formStatus", "");
            }
            pathList.add(companyClientPathMap);
        }
        return getDprInfoMap(verupScreenLayoutDprRelationDto, pathList, filePathList, fileNameList, frameCountMap);
    }

    private Map<String, Object> getDprInfoMap(VerupScreenLayoutDprRelationDto verupScreenLayoutDprRelationDto,
            List<Map<String, Object>> pathList, List<String> filePathList, List<Object> fileNameList,
            Map<String, Object> frameCountMap) {
        Map<String, Object> dprFrameMap = new HashMap<>();
        dprFrameMap.put("dprName", verupScreenLayoutDprRelationDto.getDprName());
        dprFrameMap.put("module", verupScreenLayoutDprRelationDto.getModule());
        dprFrameMap.put("frameCount", verupScreenLayoutDprRelationDto.getFrameCount());
        dprFrameMap.put("dprPath", verupScreenLayoutDprRelationDto.getDprPath());
        dprFrameMap.put("dprCheckStatus", verupScreenLayoutDprRelationDto.getDprCheckedStatus());
        dprFrameMap.put("imageSource", pathList);
        dprFrameMap.put("filePathList", filePathList);
        dprFrameMap.put("fileNameList", fileNameList);
        dprFrameMap.put("dprCaption", getDprCaption(verupScreenLayoutDprRelationDto.getDprName(), false));
        frameCountMap.put("sharedFormCount", verupScreenLayoutDprRelationDto.getSharedFrameCount());
        frameCountMap.put("ownFormCount", verupScreenLayoutDprRelationDto.getOwnFrameCount());
        frameCountMap.put("totalFormCount", verupScreenLayoutDprRelationDto.getFrameCount());
        dprFrameMap.put("count", frameCountMap);
        dprFrameMap.put("status", getStatusCount(verupScreenLayoutDprRelationDto));
        dprFrameMap.put("gridData", getGridData(verupScreenLayoutDprRelationDto));
        dprFrameMap.put("statusCode", "200");
        return dprFrameMap;
    }

    public void pathUpload(String path) {
        VerupScreenLayoutDprRelationDto verupScreenLayoutDto = new VerupScreenLayoutDprRelationDto();
        VerupScreenLayoutPascalRelationDto verupScreenLayoutPascalRelationDto = new VerupScreenLayoutPascalRelationDto();
        createDataBase(path, verupScreenLayoutDto, verupScreenLayoutPascalRelationDto);
    }

    /**
     * @param filePath
     * @param checkedStatus This method is used to update pascal data during update
     *                      on formcontrol status
     */
    public void updatePascalData(String filePath, String checkedStatus) {
        VerupScreenLayoutPascalRelationDto pascalData = verupScreenLayoutDao.getPascalData(filePath);
        if (Objects.isNull(pascalData)) {
            return;
        }
        pascalData.setPascalCheckedStatus(checkedStatus);
        verupScreenLayoutDao.updatePascalData(pascalData);
    }

    public void updateDprData(String dprname, String filePath, int overAllCompleted, int pendingCount) {
        VerupScreenLayoutDprRelationDto dprData;
        int remaingFormsCount;
        dprData = verupScreenLayoutDao.getData(dprname);
        if (dprData != null) {
            if (overAllCompleted == dprData.getFrameCount()) {
                dprData.setDprCheckedStatus(VerupScreenlayoutConstant.REVIEWED_TEXT);
            } else if (pendingCount > 0) {
                dprData.setDprCheckedStatus(VerupScreenlayoutConstant.PENDING_TEXT);
            } else {
                dprData.setDprCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
            }
            remaingFormsCount = dprData.getFrameCount() - overAllCompleted;
            dprData.setOverAllCompleted(overAllCompleted);
            dprData.setRemainingForms(remaingFormsCount);
            verupScreenLayoutDao.updateDprData(dprData);
        }
    }

    public Map<String, Object> updateFormControlData(FormDataPojo formControlData) {
        VerupScreenLayoutFormControlDto formData;
        VerupScreenLayoutPascalRelationDto pascalData;
        VerupScreenLayoutDprRelationDto layoutData;
        GetMappingPojo getData = new GetMappingPojo();
        List<VerupScreenLayoutPascalRelationDto> pascalList;
        pascalData = verupScreenLayoutDao.getPascalData(formControlData.getFilePath());
        formData = verupScreenLayoutDao.getformControlData(formControlData.getFilePath());
        if (formData == null) {
            insertFormData(formControlData, pascalData);
        } else {
            updateFormData(formData, formControlData, pascalData);
        }
        getData.setDprName(formControlData.getDprName());
        getData.setModuleName(formControlData.getModuleName());
        int overAllCompletedCount = 0;
        int pendingCount = 0;
        layoutData = verupScreenLayoutDao.getGridData(getData);
        pascalList = verupScreenLayoutDao.getPascalDataList(layoutData.getDprName());
        Map<String, VerupScreenLayoutPascalRelationDto> pascalDataMap = pascalList.stream()
                .collect(Collectors.toMap(VerupScreenLayoutPascalRelationDto::getFilePath, pasData -> pasData));
        if (layoutData != null) {
            for (Entry<String, Object> frameMap : layoutData.getFramePath().entrySet()) {
                VerupScreenLayoutPascalRelationDto pascalDataStatus = pascalDataMap.get(frameMap.getValue());
                String status = pascalDataStatus.getPascalCheckedStatus();
                if (status != null && status.equals(VerupScreenlayoutConstant.REVIEWED_TEXT)) {
                    overAllCompletedCount++;
                } else if (status != null && status.equals(VerupScreenlayoutConstant.PENDING_TEXT)) {
                    pendingCount++;
                }
            }
        }
        updateDprData(formControlData.getDprName(), formControlData.getFilePath(), overAllCompletedCount, pendingCount);
        return getDprInformation(getData);
    }

    private void insertFormData(FormDataPojo formControlData, VerupScreenLayoutPascalRelationDto pascalData) {
        ArrayList<Map<String, Object>> commentsList = new ArrayList<Map<String, Object>>();
        Map<String, Object> comments = new HashMap<String, Object>();
        VerupScreenLayoutFormControlEntity formControlDataEntity = new VerupScreenLayoutFormControlEntity();
        DateFormat dateFormat = new SimpleDateFormat(VerupScreenlayoutConstant.DATE_FORMAT);
        Date date = new Date();
        formControlDataEntity.setDprName(formControlData.getDprName());
        formControlDataEntity.setFileName(formControlData.getFileName());
        formControlDataEntity.setFilePath(formControlData.getFilePath());
        formControlDataEntity.setPascalCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
        if (formControlData.getStatus() != null) {
            comments.put("name", "Jess");
            comments.put("date", dateFormat.format(date));
            comments.put("message", "Status changed from Not yet started -> " + formControlData.getStatus());
            commentsList.add(comments);
            formControlDataEntity.setPascalCheckedStatus(formControlData.getStatus());
            updatePascalData(formControlData.getFilePath(), formControlData.getStatus());
        }
        if (formControlData.getComment() != null) {
            commentsList.add(formControlData.getComment());
        }
        formControlDataEntity.setComments(commentsList);
        formControlDataEntity.setCreateUserName("Kathir");
        formControlDataEntity.setCreatedDate(dateFormat.format(date));
        formControlDataEntity.setSharedDpr(pascalData.getSharedDprName());
        verupScreenLayoutDao.createFormControlData(formControlDataEntity);
    }

    private void updateFormData(VerupScreenLayoutFormControlDto formData, FormDataPojo formControlData,
            VerupScreenLayoutPascalRelationDto pascalData) {
        List<Map<String, Object>> commentsList = new ArrayList<Map<String, Object>>();
        Map<String, Object> comments = new HashMap<String, Object>();
        String formStatus = "";
        DateFormat dateFormat = new SimpleDateFormat(VerupScreenlayoutConstant.DATE_FORMAT);
        Date date = new Date();
        commentsList = formData.getComments();
        if (commentsList == null) {
            commentsList = new ArrayList<Map<String, Object>>();
        }
        if (formControlData.getComment() != null) {
            commentsList.add(formControlData.getComment());
        }
        if (formControlData.getStatus() != null) {
            if (!(formControlData.getMode() != null
                    && formControlData.getMode().equals(VerupScreenlayoutConstant.UPLOAD))) {
                formStatus = formData.getPascalCheckedStatus();
                comments.put("name", "Kathir");
                comments.put("date", dateFormat.format(date));
                comments.put("message", "Status changed from " + formStatus + " -> " + formControlData.getStatus());
                commentsList.add(comments);
                formData.setComments(commentsList);
                updatePascalData(formControlData.getFilePath(), formControlData.getStatus());
            }
            formData.setPascalCheckedStatus(formControlData.getStatus());
        }
        formData.setComments(commentsList);
        formData.setUpdatedDate(dateFormat.format(date));
        formData.setUpdateUserName("Ranjith");
        formData.setDprName(formControlData.getDprName());
        formData.setFileName(formControlData.getFileName());
        formData.setSharedDpr(pascalData.getSharedDprName());
        verupScreenLayoutDao.updateFormControlData(formData);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public Map<String, Object> getAllDprData(boolean custom) {
        List<String> moduleValuesList = new ArrayList();
        Map<String, Object> allDprDataMap = new HashMap();
        moduleValuesList.add(VerupScreenlayoutConstant.CAM);
        moduleValuesList.add(VerupScreenlayoutConstant.CBM);
        moduleValuesList.add(VerupScreenlayoutConstant.CCM);
        moduleValuesList.add(VerupScreenlayoutConstant.CFM);
        moduleValuesList.add(VerupScreenlayoutConstant.COM);
        /*
         * When we need this method we need to call them this is to create meta data
         * only once
         */
        // insertAllDprData();
        Map<String, Object> dprValueListMap = new HashMap();
        List<DprDetailsDto> allDprDetails = verupScreenLayoutDao.getAllDprInfo();
        moduleValuesList.stream().forEach(module -> {
            ArrayList dprList = new ArrayList();
            List<String> dprPathList = new ArrayList<String>();
            List dprCaptionList = new ArrayList();
            List<DprDetailsDto> moduleList = allDprDetails.stream()
                    .filter(dprData -> dprData.getModule().equals(module)).collect(Collectors.toList());
            moduleList.stream().forEach(dprValue -> {
                Map<String, Object> captionMap = new HashMap<String, Object>();
                captionMap.put("dprName", dprValue.getDprName());
                captionMap.put("en", dprValue.getCaptionEn());
                captionMap.put("ja", dprValue.getCaptionJa());
                dprList.add(dprValue.getDprName());
                dprPathList.add(dprValue.getDprPath());
                dprCaptionList.add(captionMap);
            });
            /*
             * This if condition is to get all dprpaths only
             */
            if (custom) {
                allDprDataMap.put(module, dprPathList);
            } else {
                allDprDataMap.put(module, dprList);
                dprValueListMap.put(module, dprCaptionList);
                allDprDataMap.put("dprGridList", dprValueListMap);
            }
        });
        return allDprDataMap;
    }

    /**
     * This is to insert ja and en captions of dpr in to all_dpr_data collection
     */
    public void insertAllDprData() {
        List<DprDetailsDto> dprList = verupScreenLayoutDao.getAllDprInfo();
        List<DprCaptionDetailsDto> allCaptionDataList = verupScreenLayoutDao.getDprCaption();
        dprList.stream().forEach(dprData -> {
            DprCaptionDetailsDto captionData = new DprCaptionDetailsDto();
            List<DprCaptionDetailsDto> captionDataList = allCaptionDataList.stream()
                    .filter(singleCaptionData -> singleCaptionData.getDprName().equals(dprData.getDprName()))
                    .collect(Collectors.toList());
            if (captionDataList.size() > 0) {
                captionData = captionDataList.get(0);
                if (captionData == null || captionData.getCaptionJa().equals("")) {
                    dprData.setCaptionJa(dprData.getDprName());
                } else {
                    dprData.setCaptionJa(captionData.getCaptionJa());
                }
                if (captionData == null || captionData.getCaptionEn().equals("")) {
                    try {
                        dprData.setCaptionEn(getEnglishCaption(captionData.getCaptionJa()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    dprData.setCaptionEn(captionData.getCaptionEn());
                }
            } else {
                dprData.setCaptionJa(dprData.getDprName());
                dprData.setCaptionEn(dprData.getDprName());
            }
            verupScreenLayoutDao.saveDprData(dprData);
        });

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private List<String> getImageSourceList(List imageList) throws IOException {
        List<String> imageUpdatedList = new ArrayList<String>();
        if (!imageList.isEmpty()) {
            imageList.stream().forEach(imagePath -> {
                try {
                    if (!imagePath.toString().replace(" ", "%20").isEmpty()) {
                        String image = getImageSource(imagePath.toString().replace(" ", "%20"));
                        if (!image.equals(VerupScreenlayoutConstant.EMPTYTEXT)) {
                            imageUpdatedList.add(image);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
        return imageUpdatedList;
    }

    private String getImageSource(String filePath) throws IOException {
        StringBuffer bufferContent = new StringBuffer();
        try {
            URL url = new URL(VerupScreenlayoutConstant.CDN_UPLOAD_PATH + filePath);
            if (filePath.isEmpty()) {
                return null;
            }
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            bufferContent = new StringBuffer();
            while ((inputLine = bufferReader.readLine()) != null) {
                bufferContent.append(inputLine);
            }
            bufferReader.close();
            connection.disconnect();
        } catch (Exception e) {
            System.out.println("File Not Found");
        }
        return bufferContent.toString();
    }

    /**
     * This method is used to fetch the image source path from CDN server
     * 
     * @param filePath
     * @return
     * @throws IOException
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Map<String, ArrayList<String>> getImagePathSource(String filePath) throws IOException {
        URL url = new URL(VerupScreenlayoutConstant.CDN_GET_PATH + filePath);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine = bufferReader.readLine();
        Map<String, ArrayList<String>> imagePathMap = new HashMap();
        ArrayList<String> hueClientPathList = new ArrayList();
        ArrayList<String> companyClientPathList = new ArrayList();
        if (inputLine != null) {
            int inputLength = inputLine.split(VerupScreenlayoutConstant.COMMA).length;
            int incrementor = 0;
            while (incrementor < inputLength) {
                String path = inputLine.split(VerupScreenlayoutConstant.COMMA)[incrementor]
                        .replace(VerupScreenlayoutConstant.OPENCURLY_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.CLOSECURLY_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.OPENSQUARE_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.CLOSESQUARE_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.BACK_SLASH, VerupScreenlayoutConstant.EMPTYTEXT);
                if (path.contains(VerupScreenlayoutConstant.HUE_CLIENT_PATH_TEXT
                        + VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT)) {
                    hueClientPathList.add(path);
                } else if (path.contains(VerupScreenlayoutConstant.COMPANY_CLIENT_PATH_TEXT
                        + VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT)) {
                    companyClientPathList.add(path);
                }
                incrementor++;
            }
        }
        imagePathMap.put(VerupScreenlayoutConstant.HUE_CLIENT, hueClientPathList);
        imagePathMap.put(VerupScreenlayoutConstant.COMPANY_CLIENT, companyClientPathList);
        bufferReader.close();
        connection.disconnect();
        return imagePathMap;
    }

    /**
     * This method is to read images files from AUTOTEST tool generated resource.
     * 
     * @param filePath
     * @param fileName
     * @return
     * @throws IOException
     */
    public Map<String, ArrayList<String>> getImagePathSourceFromAutoTestServer(String filePath, String fileName)
            throws IOException {
        URL url = new URL(VerupScreenlayoutConstant.CDN_GET_SPECIFICIMAGE_PATH + filePath + "&filename=" + fileName);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine = bufferReader.readLine();
        Map<String, ArrayList<String>> imagePathMap = new HashMap<>();
        ArrayList<String> hueClientPathList = new ArrayList<>();
        ArrayList<String> companyClientPathList = new ArrayList<>();
        if (inputLine != null) {
            int inputLength = inputLine.split(VerupScreenlayoutConstant.COMMA).length;
            int incrementor = 0;
            while (incrementor < inputLength) {
                String path = inputLine.split(VerupScreenlayoutConstant.COMMA)[incrementor]
                        .replace(VerupScreenlayoutConstant.OPENCURLY_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.CLOSECURLY_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.OPENSQUARE_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.CLOSESQUARE_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                        .replace(VerupScreenlayoutConstant.BACK_SLASH, VerupScreenlayoutConstant.EMPTYTEXT);
                if (path.contains(VerupScreenlayoutConstant.HUE_CLIENT_PATH_TEXT
                        + VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT)) {
                    hueClientPathList.add(path);
                } else if (path.contains(VerupScreenlayoutConstant.COMPANY_CLIENT_PATH_TEXT
                        + VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT)) {
                    companyClientPathList.add(path);
                }
                hueClientPathList.add(path);
                incrementor++;
            }
        }
        imagePathMap.put(VerupScreenlayoutConstant.HUE_CLIENT, hueClientPathList);
        imagePathMap.put(VerupScreenlayoutConstant.COMPANY_CLIENT, companyClientPathList);
        bufferReader.close();
        connection.disconnect();
        return imagePathMap;
    }

    public Map<String, Object> updateImageSource(FormDataPojo updateImageSource) {
        List<String> hueClientPathList = new ArrayList<String>();
        GetMappingPojo getData = new GetMappingPojo();
        VerupScreenLayoutPascalRelationDto pascalData = new VerupScreenLayoutPascalRelationDto();
        String imagePath = updateImageSource.getImagePath();
        Map<String, Object> commentMap = new HashMap<String, Object>();
        DateFormat dateFormat = new SimpleDateFormat(VerupScreenlayoutConstant.DATE_FORMAT);
        Date date = new Date();
        String pascalStatus;
        int imageRemovedIndex = 0;
        String fileName = Paths.get(updateImageSource.getFilePath()).getFileName().toString();
        pascalData = verupScreenLayoutDao.getPascalData(updateImageSource.getFilePath());
        String imageName = Paths.get(updateImageSource.getImagePath()).getFileName().toString();
        if (pascalData == null) {
            Map<String, Object> errorData = new HashMap<String, Object>();
            errorData.put("message", "couldn't update imagesource for : " + fileName + " check file path once");
            errorData.put("statusCode", "404");
            return errorData;
        }
        hueClientPathList = pascalData.getHueClientPathList();
        pascalStatus = pascalData.getPascalCheckedStatus();
        if (updateImageSource.getMode().equals(VerupScreenlayoutConstant.UPLOAD)) {
            commentMap.put("name", "Sankar");
            commentMap.put("message", imageName + " -> Uploaded");
            if (pascalStatus.equals(VerupScreenlayoutConstant.REVIEWED_TEXT)) {
                commentMap.put("message", imageName + " -> Uploaded \r\n" + "Status changed from "
                        + VerupScreenlayoutConstant.REVIEWED_TEXT + " -> " + VerupScreenlayoutConstant.PENDING_TEXT);
                updateImageSource.setStatus(VerupScreenlayoutConstant.PENDING_TEXT);
                pascalData.setPascalCheckedStatus(VerupScreenlayoutConstant.PENDING_TEXT);
            }
            commentMap.put("date", dateFormat.format(date));
            hueClientPathList.add(imagePath);
        } else if (updateImageSource.getMode().equals(VerupScreenlayoutConstant.DELETE)) {
            imageRemovedIndex = 0;
            commentMap.put("name", "Ranjith");
            commentMap.put("message", imageName + " -> Deleted");
            commentMap.put("date", dateFormat.format(date));
            for (String imageSourcePath : hueClientPathList) {
                if (imageSourcePath.equals(imagePath)) {
                    break;
                }
                imageRemovedIndex++;
            }
            hueClientPathList.remove(imageRemovedIndex);
            if (hueClientPathList.size() == imageRemovedIndex) {
                imageRemovedIndex--;
            }
        }
        pascalData.setHueClientPathList(hueClientPathList);
        verupScreenLayoutDao.updatePascalData(pascalData);
        updateImageSource.setComment(commentMap);
        updateImageSource.setFileName(fileName);
        updateFormControlData(updateImageSource);
        getData.setDprName(updateImageSource.getDprName());
        getData.setModuleName(updateImageSource.getModuleName());
        getData.setMode(updateImageSource.getMode());
        getData.setFilepath(updateImageSource.getFilePath());
        getData.setImageRemovedIndex(imageRemovedIndex);
        return getDprInformation(getData);
    }

    /**
     * This function is used to convert japanese caption to english caption
     * 
     * @param japaneseCaption
     * @return
     * @throws IOException
     */
    public String getEnglishCaption(String japaneseCaption) throws IOException {
        String urlStr = VerupScreenlayoutConstant.GOOGLEAPI_URL + URLEncoder.encode(japaneseCaption, "UTF-8");
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestProperty("User-Agent", "Mozilla/5.0");

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        int status = con.getResponseCode();
        System.out.println(status);
        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return parseResult(response.toString());
    }

    private String parseResult(String inputJson) {
        JSONArray jsonArray = new JSONArray(inputJson);
        JSONArray jsonArray1 = (JSONArray) jsonArray.get(0);
        JSONArray jsonArray2 = (JSONArray) jsonArray1.get(0);
        return jsonArray2.get(0).toString();
    }

    /**
     * This function is used to create dpr-data and pascal-dat table entries by
     * reading worksheet
     * 
     * @param filePath
     * @param verupScreenLayoutRepository
     * @param verupScreenLayoutDto
     * @param verupScreenLayoutPascalRelationDto
     * @param pascalRelationRepository
     */
    public void createDataBase(String filePath, VerupScreenLayoutDprRelationDto verupScreenLayoutDto,
            VerupScreenLayoutPascalRelationDto verupScreenLayoutPascalRelationDto) {
        File fileFolder = new File(VerupScreenlayoutConstant.LOCAL_REPOSITORY_TEXT + filePath);
        File[] filePaths = fileFolder.listFiles();
        int fileCount = VerupScreenlayoutConstant.CONSTANT_ZERO;
        while (fileCount < filePaths.length) {
            verupScreenLayoutDto = new VerupScreenLayoutDprRelationDto();
            try {
                FileInputStream fileInputStream = new FileInputStream(new File(filePaths[fileCount].toString()));
                DataFormatter dataFormatter = new DataFormatter();
                Workbook workbook = new HSSFWorkbook(fileInputStream);
                Cell screenNameCell = workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO)
                        .getRow(VerupScreenlayoutConstant.CONSTANT_FOUR)
                        .getCell(VerupScreenlayoutConstant.CONSTANT_THREE);
                Cell dprNameCell = workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO)
                        .getRow(VerupScreenlayoutConstant.CONSTANT_FIVE)
                        .getCell(VerupScreenlayoutConstant.CONSTANT_THREE);
                Cell dprPathCell = workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO)
                        .getRow(VerupScreenlayoutConstant.CONSTANT_SIX)
                        .getCell(VerupScreenlayoutConstant.CONSTANT_THREE);
                String screenName = dataFormatter.formatCellValue(screenNameCell);
                String dprName = dataFormatter.formatCellValue(dprNameCell);
                String dprPath = dataFormatter.formatCellValue(dprPathCell);
                dprName = dprName.replace(VerupScreenlayoutConstant.DPRTEXT, VerupScreenlayoutConstant.EMPTYTEXT);
                dprPath = dprPath.replace(VerupScreenlayoutConstant.DPRTEXT, VerupScreenlayoutConstant.EMPTYTEXT);
                String convertedDprPath = dprPath.replace(dprName, VerupScreenlayoutConstant.EMPTYTEXT);
                if (dprPath.contains(VerupScreenlayoutConstant.MODULE_CAM)) {
                    verupScreenLayoutDto.setModule(VerupScreenlayoutConstant.MODULE_CAM.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                } else if (dprPath.contains(VerupScreenlayoutConstant.MODULE_CFM)) {
                    verupScreenLayoutDto.setModule(VerupScreenlayoutConstant.MODULE_CFM.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                } else if (dprPath.contains(VerupScreenlayoutConstant.MODULE_CBM)) {
                    verupScreenLayoutDto.setModule(VerupScreenlayoutConstant.MODULE_CBM.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                } else if (dprPath.contains(VerupScreenlayoutConstant.MODULE_CCM)) {
                    verupScreenLayoutDto.setModule(VerupScreenlayoutConstant.MODULE_CCM.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                } else if (dprPath.contains(VerupScreenlayoutConstant.MODULE_COM)) {
                    verupScreenLayoutDto.setModule(VerupScreenlayoutConstant.MODULE_COM.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                }
                verupScreenLayoutDto.setScreenName(screenName);
                verupScreenLayoutDto.setDprName(dprName);
                verupScreenLayoutDto.setDprPath(VerupScreenlayoutConstant.DELPHITEXT + dprPath);
                int rowcount = VerupScreenlayoutConstant.ROWCOUNT;
                getPascalDetails(verupScreenLayoutDto, workbook, rowcount, verupScreenLayoutPascalRelationDto,
                        convertedDprPath, dprName, dprPath);
                verupScreenLayoutDto.setOverAllCompleted(VerupScreenlayoutConstant.CONSTANT_ZERO);
                fileCount++;
            } catch (FileNotFoundException exception) {
                log.info(exception.toString());
            } catch (IOException ioException) {
                log.info(ioException.toString());
            }
            verupScreenLayoutDao.insertVerupScreenLayoutRepository(verupScreenLayoutDto);
        }
        ;
    }

    /**
     * @param verupScreenLayoutDto
     * @param workbook
     * @param rowcount
     * @param verupScreenLayoutPascalRelationDto
     * @param convertedDprPath
     * @param dprName
     * @param dprPath
     * @param pascalRelationRepository
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private VerupScreenLayoutDprRelationDto getPascalDetails(VerupScreenLayoutDprRelationDto verupScreenLayoutDto,
            Workbook workbook, int rowcount, VerupScreenLayoutPascalRelationDto verupScreenLayoutPascalRelationDto,
            String convertedDprPath, String dprName, String dprPath) {
        ArrayList pathList = new ArrayList();
        Map<String, Object> pathMap = new HashMap<>();
        Map<String, Object> sharedPathMap = new HashMap<>();
        int frameCountIncrementor = VerupScreenlayoutConstant.CONSTANT_ONE;
        int sharedFrameCountIncrementor = VerupScreenlayoutConstant.CONSTANT_ONE;
        while (workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getLastRowNum() >= rowcount) {
            if (workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount)
                    .getCell(VerupScreenlayoutConstant.CONSTANT_FOUR).toString().equals("true")
                    && !workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount)
                            .getCell(VerupScreenlayoutConstant.CONSTANT_TWO).toString().equals("accommon")) {
                String pathKey = workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount)
                        .getCell(VerupScreenlayoutConstant.CONSTANT_THREE).toString();
                String framePath = VerupScreenlayoutConstant.DELPHITEXT + workbook
                        .getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount).getCell(34).toString();
                pathKey = pathKey.replace(VerupScreenlayoutConstant.PASTEXT, VerupScreenlayoutConstant.EMPTYTEXT);
                framePath = framePath.replace(VerupScreenlayoutConstant.PASTEXT, VerupScreenlayoutConstant.DFMTEXT);
                pathList.add(framePath);
                String filename = Paths.get(framePath).getFileName().toString();
                filename = filename.replace(VerupScreenlayoutConstant.DFMTEXT, VerupScreenlayoutConstant.EMPTYTEXT);
                ArrayList<String> hueClientPathList = new ArrayList();
                ArrayList<String> companyClientPathList = new ArrayList();
                Map<String, ArrayList<String>> imagePathMap = new HashMap();
                try {
                    /*
                     * This is used to get Image source from the pas files structure. we changed
                     * this since Autotest tool will place all files in single folder
                     */
//                    imagePathMap = getImagePathSource(path);
                    imagePathMap = getImagePathSourceFromAutoTestServer(dprPath, filename);
                    hueClientPathList = imagePathMap.get(VerupScreenlayoutConstant.HUE_CLIENT_PATH_TEXT.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                    companyClientPathList = imagePathMap.get(VerupScreenlayoutConstant.COMPANY_CLIENT_PATH_TEXT.replace(
                            VerupScreenlayoutConstant.BACKWARD_SLASH_TEXT, VerupScreenlayoutConstant.EMPTYTEXT));
                } catch (IOException exception) {
                    log.info(exception.toString());
                }
                ArrayList duplicateDprList = new ArrayList();
                pathMap.put(pathKey, framePath);
                verupScreenLayoutPascalRelationDto
                        .setPascalCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
                if (companyClientPathList != null && hueClientPathList != null
                        && workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount).getCell(34)
                                .toString().contains(convertedDprPath)) {
                    verupScreenLayoutPascalRelationDto = new VerupScreenLayoutPascalRelationDto();
                    String frameFilePath = VerupScreenlayoutConstant.DELPHITEXT
                            + workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount).getCell(34)
                                    .toString();
                    frameFilePath = frameFilePath.replace(VerupScreenlayoutConstant.PASTEXT,
                            VerupScreenlayoutConstant.DFMTEXT);
                    verupScreenLayoutPascalRelationDto.setFilePath(frameFilePath);
                    getFrameName(verupScreenLayoutPascalRelationDto, frameFilePath, verupScreenLayoutDto.getModule());
                    getPascalRelationDtoDetails(verupScreenLayoutPascalRelationDto, companyClientPathList,
                            hueClientPathList, dprName, duplicateDprList, sharedPathMap, workbook, convertedDprPath,
                            pathKey, framePath, rowcount);
                    verupScreenLayoutDto.setOwnFrameCount(frameCountIncrementor);
                    frameCountIncrementor++;
                } else if (companyClientPathList != null && hueClientPathList != null) {
                    verupScreenLayoutPascalRelationDto = new VerupScreenLayoutPascalRelationDto();
                    verupScreenLayoutPascalRelationDto.setFilePath(framePath);
                    getFrameName(verupScreenLayoutPascalRelationDto, framePath, verupScreenLayoutDto.getModule());
                    getPascalRelationDtoDetails(verupScreenLayoutPascalRelationDto, companyClientPathList,
                            hueClientPathList, dprName, duplicateDprList, sharedPathMap, workbook, convertedDprPath,
                            pathKey, framePath, rowcount);
                    verupScreenLayoutDto.setSharedFrameCount(sharedFrameCountIncrementor);
                    sharedFrameCountIncrementor++;
                } else {
                    verupScreenLayoutPascalRelationDto = new VerupScreenLayoutPascalRelationDto();
                    verupScreenLayoutPascalRelationDto.setFilePath(framePath);
                    getFrameName(verupScreenLayoutPascalRelationDto, framePath, verupScreenLayoutDto.getModule());
                    getPascalRelationDtoDetails(verupScreenLayoutPascalRelationDto, companyClientPathList,
                            hueClientPathList, dprName, duplicateDprList, sharedPathMap, workbook, convertedDprPath,
                            pathKey, framePath, rowcount);
                    verupScreenLayoutDto.setSharedFrameCount(sharedFrameCountIncrementor);
                    sharedFrameCountIncrementor++;
                }
                getSharedDpr(verupScreenLayoutPascalRelationDto);
                verupScreenLayoutDao.updatePascalData(verupScreenLayoutPascalRelationDto);
            }
            verupScreenLayoutDto.setFrameCount(pathList.size());
            rowcount++;
            verupScreenLayoutDto.setSharedFrame(sharedPathMap);
            verupScreenLayoutDto.setOwnFrame(setOwnFrame(pathMap, sharedPathMap));
            Map<String, Object> framePathMap = new LinkedHashMap();
            framePathMap.putAll(verupScreenLayoutDto.getOwnFrame());
            framePathMap.putAll(verupScreenLayoutDto.getSharedFrame());
            verupScreenLayoutDto.setFramePath(framePathMap);
            verupScreenLayoutDto.setDprCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
            verupScreenLayoutDto.setOverAllCompleted(VerupScreenlayoutConstant.CONSTANT_ZERO);
            verupScreenLayoutDto.setRemainingForms(pathList.size());
        }
        return verupScreenLayoutDto;
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private Map<String, Object> setOwnFrame(Map<String, Object> pathMap, Map<String, Object> sharedPathMap) {
        Map<String, Object> ownFramePath = new HashMap(pathMap);
        sharedPathMap.entrySet().stream().forEach(sharedPath -> ownFramePath.remove(sharedPath.getKey()));
        return ownFramePath;
    }

    private void getSharedDpr(VerupScreenLayoutPascalRelationDto verupScreenLayoutPascalRelationDto) {
        if (StringUtils.isEmpty(verupScreenLayoutPascalRelationDto.getFilePath())) {
            return;
        }
        String fileName = verupScreenLayoutPascalRelationDto.getFilePath()
                .replace(VerupScreenlayoutConstant.DELPHITEXT, VerupScreenlayoutConstant.EMPTYTEXT)
                .replace(VerupScreenlayoutConstant.DFMTEXT, VerupScreenlayoutConstant.PASTEXT);
        List<PasFileDetailsEntity> pasFileDetailsList = verupScreenLayoutDao.getPasFilename(fileName);
        pasFileDetailsList.stream().findFirst().ifPresent(pasFileDetails -> {
            verupScreenLayoutPascalRelationDto.setOwnDprName(pasFileDetails.getDprs().get(0));
            pasFileDetails.getDprs().remove(0);
            verupScreenLayoutPascalRelationDto.setSharedDprName(pasFileDetails.getDprs());
        });
    }

    /**
     * @param verupScreenLayoutPascalRelationDto
     * @param companyClientPathList
     * @param hueClientPathList
     * @param dprName
     * @param duplicateDprList
     * @param sharedPathMap
     * @param workbook
     * @param convertedDprPath
     * @param pathKey
     * @param framePath
     * @param rowcount
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private void getPascalRelationDtoDetails(VerupScreenLayoutPascalRelationDto verupScreenLayoutPascalRelationDto,
            ArrayList<String> companyClientPathList, ArrayList<String> hueClientPathList, String dprName,
            ArrayList duplicateDprList, Map<String, Object> sharedPathMap, Workbook workbook, String convertedDprPath,
            String pathKey, String framePath, int rowcount) {
        if (companyClientPathList != null && hueClientPathList != null
                && workbook.getSheetAt(VerupScreenlayoutConstant.CONSTANT_ZERO).getRow(rowcount).getCell(34).toString()
                        .contains(convertedDprPath)) {
            verupScreenLayoutPascalRelationDto.setCompanyClientPathList(companyClientPathList);
            verupScreenLayoutPascalRelationDto.setHueClientPathList(hueClientPathList);
            verupScreenLayoutPascalRelationDto.setOwnDprName(dprName);
            verupScreenLayoutPascalRelationDto.setSharedDprName(new ArrayList<>());
            verupScreenLayoutPascalRelationDto.setPascalCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
        } else if (companyClientPathList != null && hueClientPathList != null) {
            verupScreenLayoutPascalRelationDto.setCompanyClientPathList(companyClientPathList);
            verupScreenLayoutPascalRelationDto.setHueClientPathList(hueClientPathList);
            verupScreenLayoutPascalRelationDto.setOwnDprName(VerupScreenlayoutConstant.EMPTYTEXT);
            verupScreenLayoutPascalRelationDto.setPascalCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
            duplicateDprList.add(dprName);
            duplicateDprList.stream().distinct();
            verupScreenLayoutPascalRelationDto.setSharedDprName(duplicateDprList);
            sharedPathMap.put(pathKey, framePath);
        } else {
            verupScreenLayoutPascalRelationDto.setCompanyClientPathList(new ArrayList<>());
            verupScreenLayoutPascalRelationDto.setHueClientPathList(new ArrayList<>());
            verupScreenLayoutPascalRelationDto.setOwnDprName(VerupScreenlayoutConstant.EMPTYTEXT);
            verupScreenLayoutPascalRelationDto.setPascalCheckedStatus(VerupScreenlayoutConstant.NOT_YET_STARTED_TEXT);
            duplicateDprList.add(dprName);
            duplicateDprList.stream().distinct();
            verupScreenLayoutPascalRelationDto.setSharedDprName(duplicateDprList);
            sharedPathMap.put(pathKey, framePath);
        }

    }

    /**
     * @param verupScreenLayoutPascalRelationDto
     * @param framePath
     * @param module
     */
    public void getFrameName(VerupScreenLayoutPascalRelationDto verupScreenLayoutPascalRelationDto, String framePath,
            String module) {
        String captionCode = VerupScreenlayoutConstant.EMPTYTEXT;
        StringBuffer caption = new StringBuffer();
        BufferedReader bufferReader;
        try {
            String filePath = VerupScreenlayoutConstant.DEFAULT_PATH_TEXT + module + "41"
                    + VerupScreenlayoutConstant.HUE_CLIENT_PATH_TEXT + framePath;
            bufferReader = new BufferedReader(new FileReader(filePath));
            while ((captionCode = bufferReader.readLine()) != null) {
                if (captionCode.contains(VerupScreenlayoutConstant.CAPTION_TEXT)) {
                    captionCode = captionCode
                            .replace(VerupScreenlayoutConstant.CAPTION_TEXT, VerupScreenlayoutConstant.EMPTYTEXT)
                            .replace(VerupScreenlayoutConstant.SINGLE_APOSTROPHE_TEXT,
                                    VerupScreenlayoutConstant.EMPTYTEXT)
                            .trim();
                    break;
                }
            }
            if (captionCode.contains(VerupScreenlayoutConstant.HASHCODE_TEXT)) {
                int lengthIncrementor = VerupScreenlayoutConstant.CONSTANT_ONE;
                int length = captionCode.split(VerupScreenlayoutConstant.HASHCODE_TEXT).length
                        - VerupScreenlayoutConstant.CONSTANT_ONE;
                String[] captionArray = captionCode.split(VerupScreenlayoutConstant.HASHCODE_TEXT);
                char[] captionCharector = null;
                while (lengthIncrementor < length) {
                    captionCharector = Character.toChars(Integer.parseInt(captionArray[lengthIncrementor]
                            .replace(VerupScreenlayoutConstant.OPEN_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                            .replace(VerupScreenlayoutConstant.CLOSE_BRACE, VerupScreenlayoutConstant.EMPTYTEXT)
                            .trim()));
                    caption.append(captionCharector[VerupScreenlayoutConstant.CONSTANT_ZERO]);
                    lengthIncrementor++;
                }
                verupScreenLayoutPascalRelationDto.setFrameCaptionJa(caption.toString());
                verupScreenLayoutPascalRelationDto.setFrameCaptionEn(getEnglishCaption(caption.toString()));

            } else {
                verupScreenLayoutPascalRelationDto.setFrameCaptionJa(captionCode);
                verupScreenLayoutPascalRelationDto.setFrameCaptionEn(getEnglishCaption(captionCode));
            }
        } catch (FileNotFoundException e) {
            log.error("Unable to find the file: fileName");
        } catch (IOException e) {
            log.error("Unable to read the file: fileName");
        }
    }

    public void triggerFileSync(GetMappingPojo getDprData) throws IOException {
        URL url = new URL("http://192.168.57.59/cdn/readBulkData");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        BufferedReader bufferReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        Map<String, Object> framePath = new HashMap<>();
        VerupScreenLayoutDprRelationDto verupScreenLayoutDprRelationDto = verupScreenLayoutDao
                .getData(getDprData.getDprName());
        framePath = verupScreenLayoutDprRelationDto.getFramePath();
        List<VerupScreenLayoutPascalRelationDto> pascalDataList = verupScreenLayoutDao
                .getPascalDataList(verupScreenLayoutDprRelationDto.getDprName());
        Map<String, VerupScreenLayoutPascalRelationDto> pascalDataMap = pascalDataList.stream()
                .collect(Collectors.toMap(VerupScreenLayoutPascalRelationDto::getFilePath, pasData -> pasData));
        framePath.entrySet().forEach(map -> {
            try {
                Map<String, ArrayList<String>> imagePathMap = new HashMap<>();
                imagePathMap = getImagePathSourceFromAutoTestServer(
                        verupScreenLayoutDprRelationDto.getDprPath().replace("\\delphi\\", ""),
                        Paths.get(map.getValue().toString()).getFileName().toString().replace(".dfm", ""));
                VerupScreenLayoutPascalRelationDto pascalData = pascalDataMap.get(map.getValue());
                pascalData.setHueClientPathList(imagePathMap.get("hue_client"));
                pascalData.setCompanyClientPathList(imagePathMap.get("company_client"));
                verupScreenLayoutDao.updatePascalData(pascalData);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
