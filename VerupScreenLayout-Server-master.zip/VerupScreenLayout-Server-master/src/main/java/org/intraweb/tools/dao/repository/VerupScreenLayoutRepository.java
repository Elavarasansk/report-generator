package org.intraweb.tools.dao.repository;

import org.intraweb.tools.dao.dto.VerupScreenLayoutDprRelationDto;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface VerupScreenLayoutRepository extends MongoRepository<VerupScreenLayoutDprRelationDto, String> {

    VerupScreenLayoutDprRelationDto findByDprName(String dprName);

    VerupScreenLayoutDprRelationDto findByDprNameAndModule(String dprName, String module);

}
