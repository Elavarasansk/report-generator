package org.intraweb.tools.dao.dto;

import java.util.ArrayList;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;

@Document(collection = "duplicate_paspath_details")
@Getter
public class PasFileDetailsEntity {

    private String pasName;
    private String pasFileName;
    private ArrayList<String> dprs;

}
