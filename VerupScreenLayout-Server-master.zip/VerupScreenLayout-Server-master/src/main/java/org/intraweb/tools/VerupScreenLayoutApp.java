package org.intraweb.tools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerupScreenLayoutApp {
    public static void main(String[] args) {
        SpringApplication.run(VerupScreenLayoutApp.class, args);
    }
}
