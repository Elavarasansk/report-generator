package org.intraweb.tools.dao.dto;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(collection = "all_dpr_data")
@Data
public class DprDetailsDto {

    @Id
    private ObjectId id;
    private String dprName;
    private String priority;
    private String complexity;
    private String module;
    private String moduleName;
    private String dprPath;
    private String lableader;
    private String assignee;
    private String captionJa;
    private String captionEn;

}
