package org.intraweb.tools.dao;

import java.util.List;

import org.intraweb.tools.dao.dto.DprCaptionDetailsDto;
import org.intraweb.tools.dao.dto.DprDetailsDto;
import org.intraweb.tools.dao.dto.PasFileDetailsEntity;
import org.intraweb.tools.dao.dto.VerupScreenLayoutDprRelationDto;
import org.intraweb.tools.dao.dto.VerupScreenLayoutFormControlDto;
import org.intraweb.tools.dao.dto.VerupScreenLayoutPascalRelationDto;
import org.intraweb.tools.dao.entity.GetMappingPojo;
import org.intraweb.tools.dao.entity.VerupScreenLayoutFormControlEntity;
import org.intraweb.tools.dao.repository.DprCaptionDetailsRepository;
import org.intraweb.tools.dao.repository.DprDetailsRepository;
import org.intraweb.tools.dao.repository.PasFileDetailsRepository;
import org.intraweb.tools.dao.repository.VerupScreenLayoutFormControlRepository;
import org.intraweb.tools.dao.repository.VerupScreenLayoutPascalRelationRepository;
import org.intraweb.tools.dao.repository.VerupScreenLayoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class VerupScreenLayoutDao {
    @Autowired
    private PasFileDetailsRepository pasFileDetailsRepository;

    @Autowired
    private VerupScreenLayoutRepository verupScreenLayoutRepository;

    @Autowired
    private VerupScreenLayoutPascalRelationRepository pascalRelationRepository;

    @Autowired
    private VerupScreenLayoutFormControlRepository formControlRepository;

    @Autowired
    private DprDetailsRepository dprDetailsRepository;

    @Autowired
    private DprCaptionDetailsRepository dprCaptionDetailsRepository;

    /**
     * This function is used to get all form details of dpr to show it in grid
     * 
     * @param getData
     * @param verupScreenLayoutRepository
     * @return
     */
    public VerupScreenLayoutDprRelationDto getGridData(GetMappingPojo getData) {
        return verupScreenLayoutRepository.findByDprNameAndModule(getData.getDprName(), getData.getModuleName());
    }

    /**
     * This is used to return dpr information from dpr-data tabel
     * 
     * @param dprName
     * @param verupScreenLayoutRepository
     * @return
     */
    public VerupScreenLayoutDprRelationDto getData(String dprName) {
        return verupScreenLayoutRepository.findByDprName(dprName);
    }

    /**
     * This method is used to fetch particular pascal file data
     * 
     * @param filePath
     * @param pascalRelationRepository
     * @return
     */
    public VerupScreenLayoutPascalRelationDto getPascalData(String filePath) {
        return pascalRelationRepository.findByFilePath(filePath);
    }

    /**
     * This function will create new records for form-control tabel
     * 
     * @param formControlData
     * @param formControlRepository
     */
    public void createFormControlData(VerupScreenLayoutFormControlEntity formControlData) {
        formControlRepository.insert(VerupScreenLayoutFormControlEntity.entityToDtoConverter(formControlData));
    }

    /**
     * This is used to update pascal-data information during status change for pas
     * files
     * 
     * @param pascalData
     * @param pascalRelationRepository
     */
    public void updatePascalData(VerupScreenLayoutPascalRelationDto pascalData) {
        pascalRelationRepository.save(pascalData);
    }

    /**
     * This function will updated the dpr information based on the forms completed
     * during review
     * 
     * @param dprData
     * @param repository
     */
    public void updateDprData(VerupScreenLayoutDprRelationDto dprData) {
        verupScreenLayoutRepository.save(dprData);
    }

    /**
     * This is to fetch form-control data for particular file
     * 
     * @param filepath
     * @param formControlRepository
     * @return
     */
    public VerupScreenLayoutFormControlDto getformControlData(String filepath) {
        return formControlRepository.findByFilePath(filepath);
    }

    /**
     * This method is used to update the form-control data during review
     * 
     * @param formData
     * @param formControlRepository
     */
    public void updateFormControlData(VerupScreenLayoutFormControlDto formData) {
        formControlRepository.save(formData);
    }

    /**
     * This method will return dpr data for particular dpr
     * 
     * @param dprDetailsRepository
     * @param dprName
     * @return
     */
    public DprDetailsDto getDprInfo(String dprName) {
        return dprDetailsRepository.findOneByDprName(dprName);
    }

    public List<VerupScreenLayoutPascalRelationDto> getPascalDataList(String dprName) {
        return pascalRelationRepository.findByOwnDprNameOrSharedDprName(dprName, dprName);

    }

    public List<VerupScreenLayoutFormControlDto> getAllFormControlData(String dprName) {
        return formControlRepository.findByDprNameOrSharedDpr(dprName, dprName);
    }

    public List<DprDetailsDto> getAllDprInfo() {
        return dprDetailsRepository.findAll();
    }

    public List<DprCaptionDetailsDto> getDprCaption() {
        return dprCaptionDetailsRepository.findAll();
    }

    public void saveDprData(DprDetailsDto dprData) {
        dprDetailsRepository.save(dprData);
    }

    public List<PasFileDetailsEntity> getPasFilename(String fileName) {
        return pasFileDetailsRepository.findByPasFileName(fileName);
    }

    public void insertVerupScreenLayoutRepository(VerupScreenLayoutDprRelationDto verupScreenLayoutDto) {
        verupScreenLayoutRepository.save(verupScreenLayoutDto);
    }
}
