package org.intraweb.tools.controller;

import java.io.IOException;
import java.util.Map;

import org.intraweb.tools.dao.entity.FormDataPojo;
import org.intraweb.tools.dao.entity.GetMappingPojo;
import org.intraweb.tools.service.VerupScreenLayoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class VerupScreenLayoutController {

    @Autowired
    public VerupScreenLayoutService verupScreenLayoutService;

    @PostMapping("/getDprInfo")
    public Map<String, Object> getDprInfo(@RequestBody GetMappingPojo getDprData) {
        return verupScreenLayoutService.getDprInformation(getDprData);
    }

    @PostMapping("/worksheetPathUpdate")
    public void worksheetPathUpdate(@RequestParam(value = "filePath") String path) {
        verupScreenLayoutService.pathUpload(path);
    }

    @PostMapping("/updateFormControl")
    public Map<String, Object> updateFormControlData(@RequestBody FormDataPojo formControlData) {
        return verupScreenLayoutService.updateFormControlData(formControlData);
    }

    @GetMapping("/getAllDprData")
    public Map<String, Object> getAllDprData() {
        return verupScreenLayoutService.getAllDprData(false);
    }

    @PostMapping("/upload")
    public Map<String, Object> updateImageSource(@RequestBody FormDataPojo updateImageSource) {
        return verupScreenLayoutService.updateImageSource(updateImageSource);
    }

    @PostMapping("/triggerFileSync")
    public void triggerFileSync(@RequestBody GetMappingPojo getDprData) throws IOException {
        verupScreenLayoutService.triggerFileSync(getDprData);
    }

}
