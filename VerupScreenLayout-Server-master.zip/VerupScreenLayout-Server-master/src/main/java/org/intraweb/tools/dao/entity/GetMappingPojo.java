package org.intraweb.tools.dao.entity;

import lombok.Data;

@Data
public class GetMappingPojo {

    String dprName;

    String moduleName;

    String mode;

    String filepath;

    int imageRemovedIndex;

}
