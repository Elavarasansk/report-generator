package org.intraweb.tools.dao.repository;

import java.util.List;

import org.intraweb.tools.dao.dto.VerupScreenLayoutPascalRelationDto;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface VerupScreenLayoutPascalRelationRepository
        extends MongoRepository<VerupScreenLayoutPascalRelationDto, String> {

    VerupScreenLayoutPascalRelationDto findByFilePath(String filePath);

    List<VerupScreenLayoutPascalRelationDto> findByOwnDprNameOrSharedDprName(String ownDprName, String sharedDprName);
}
