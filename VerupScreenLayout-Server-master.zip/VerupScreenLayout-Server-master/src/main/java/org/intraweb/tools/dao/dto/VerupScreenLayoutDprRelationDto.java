package org.intraweb.tools.dao.dto;

import java.util.Map;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection = "worksheet-data")
public class VerupScreenLayoutDprRelationDto {

    @Id
    private ObjectId id;

    private String screenName;

    private String dprName;

    private String module;

    private Map<String, Object> framePath;

    private String dprPath;

    private int frameCount;

    private Map<String, Object> sharedFrame;

    private Map<String, Object> ownFrame;

    private String dprCheckedStatus;

    private int ownFrameCount;

    private int sharedFrameCount;

    private int overAllCompleted;

    private int remainingForms;

}
