package org.intraweb.tools.dao.repository;

import java.util.List;

import org.intraweb.tools.dao.dto.DprDetailsDto;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DprDetailsRepository extends MongoRepository<DprDetailsDto, String> {

    List<DprDetailsDto> findByModule(String module);

    DprDetailsDto findOneByDprName(String dprName);
}
