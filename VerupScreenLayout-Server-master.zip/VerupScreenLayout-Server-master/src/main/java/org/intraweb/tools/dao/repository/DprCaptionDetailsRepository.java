package org.intraweb.tools.dao.repository;

import java.util.ArrayList;

import org.intraweb.tools.dao.dto.DprCaptionDetailsDto;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DprCaptionDetailsRepository extends MongoRepository<DprCaptionDetailsDto, String> {

    ArrayList<DprCaptionDetailsDto> findByDprName(String dprName);
}
