package org.intraweb.tools.ReportComparison.dao.entity;

import lombok.Data;

@Data
public class GetMappingPojo {

	Integer apiJobId; 

	String apiPtnCode;
	
	String apiJobName;
	
	String executionTime;

	String extraParameters;

	Integer key;
	
	String dbVersionCompanyKey;
	
	String dbVersionWebKey;

}
