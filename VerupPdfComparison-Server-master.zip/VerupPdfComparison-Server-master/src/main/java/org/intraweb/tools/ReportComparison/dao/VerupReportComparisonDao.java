package org.intraweb.tools.ReportComparison.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.intraweb.tools.ReportComparison.connectivity.JdbcConnection;
import org.intraweb.tools.ReportComparison.constant.VerupReportComparisonConstants;
import org.intraweb.tools.ReportComparison.dao.dto.VerupReportComparisonDto;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity;
import org.intraweb.tools.ReportComparison.dao.entity.GetMappingPojo;
import org.intraweb.tools.ReportComparison.dao.repository.EnvironmentConfigurationRepository;
import org.intraweb.tools.ReportComparison.dao.repository.VerupReportComparisonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class VerupReportComparisonDao {

	@Autowired
	VerupReportComparisonRepository repository;

	@Autowired
	VerupReportComparisonDto dtoObject;

	@Autowired
	VerupReportComparisonConstants verupReportComparisonConstants;
	
	@Autowired
	private EnvironmentConfigurationRepository environmentRepository;
	
	@Autowired
    private JdbcConnection jdbcConnection;
    

	public void executeQuery(GetMappingPojo getMappingPojo,String url,String user,String passCode,Map<String, Object> returnMap,String keyWord, Map<String, List<String>> fir, Map<String, List<String>> sec) throws InterruptedException {
		Map<String,Integer> dataMap = new HashMap<>();
		Map<String,Object> paramListMap = new HashMap<>();
		Map<String,String> fileNameMap = new HashMap<String, String>();
		final CountDownLatch latch = new CountDownLatch(1) ;
		try {

			String jobId = getMappingPojo.getApiJobId().toString();

			String ptnCode = getMappingPojo.getApiPtnCode();

			returnMap.put(verupReportComparisonConstants.JOB_ID,jobId);
			returnMap.put(verupReportComparisonConstants.PTNCODE,ptnCode);

			ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);

			try {
				Runtime.getRuntime()
				.exec(new String[] {"cmd.exe", "/c","start C:\\HUE\\WorkSpace\\Develop\\hue-ac-chennai-cac\\company_batch\\shell\\win\\companyacjobkicker.bat",
						getMappingPojo.getApiJobId().toString(),getMappingPojo.getApiPtnCode() });
			} catch (Exception exception) {
				log.info(exception.toString());
				handleException(returnMap, exception.toString());
			}

			Runnable getDataToInsert = () -> {
				try {
					DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
					Connection connection = DriverManager.getConnection(url, user, passCode);
					Statement  statement = connection.createStatement();
					String sql = "SELECT * FROM AC_COM_API_PARAM_MST WHERE api_job_id = "+jobId+"";
					Map<String,Integer> queryIdParamMap = getParamDetails(connection,sql,statement);
					if(MapUtils.isNotEmpty(queryIdParamMap)) {
					String paramSql = "SELECT * FROM AC_COM_API_PARAM_ITEM WHERE api_job_id = "+jobId+" AND API_ACTPTN_CODE='"+ptnCode+"'"
							+ "AND PARAM_ORDER='"+queryIdParamMap.get(verupReportComparisonConstants.QUERY_ID)+"'";
					int queryId = getParamItemDetails(connection,paramSql,statement);
					dataMap.put(verupReportComparisonConstants.QUERYID,queryId);
					String paramOneSql = "SELECT * FROM AC_COM_API_PARAM_ITEM WHERE api_job_id = "+jobId+" AND API_ACTPTN_CODE='"+ptnCode+"'"
							+ "AND PARAM_ORDER='"+queryIdParamMap.get(verupReportComparisonConstants.FILENAME)+"'";
					fileNameMap.put(verupReportComparisonConstants.FILE_NAME, getParamFileNameItemDetails(connection,paramOneSql,statement));
					String jobSql = "SELECT * FROM ACAP_QUERY_STATUS_LIST WHERE QUERY_ID="+queryId+" ORDER BY JOB_ID DESC";
					getJobDetails(connection,jobSql,statement,dataMap);		
					if(dataMap.get(verupReportComparisonConstants.STATUS) == 1) {
							String paramListSql = "SELECT * FROM PARAM_LIST WHERE PARAMETER LIKE '"+ dataMap.get(verupReportComparisonConstants.JOB_ID) +"%'";
							getParamList(connection,paramListSql,statement,paramListMap);
					}else{
						if((!paramListMap.isEmpty()) && (dataMap.get(verupReportComparisonConstants.STATUS) == 9)) {							
							List<String> firstHeaderList = new ArrayList<>();
							List<String> secondHeaderList = new ArrayList<>();
							DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
							String tablesql = "SELECT EXEC_QUERY_FILE FROM ACAP_QUERY_STATUS_LIST WHERE QUERY_ID ="+dataMap.get(verupReportComparisonConstants.QUERYID)+" AND STATUS = 9 ORDER BY JOB_ID DESC";
							Map<String,Object> primaryKeyMap = getTableName(connection,statement,tablesql);		
							if(keyWord.equalsIgnoreCase(verupReportComparisonConstants.DELPHI_KEYWORD)) {
								fir.putAll(readFirstDataAll(connection,statement,primaryKeyMap,primaryKeyMap.get(verupReportComparisonConstants.QUERY),keyWord,firstHeaderList));
								returnMap.put(verupReportComparisonConstants.FIRST_HEADER_LIST,firstHeaderList);
							}else if(keyWord.equalsIgnoreCase(verupReportComparisonConstants.WEB_KEYWORD)) {
								sec.putAll(readFirstDataAll(connection,statement,primaryKeyMap,primaryKeyMap.get(verupReportComparisonConstants.QUERY),keyWord,secondHeaderList));
								returnMap.put(verupReportComparisonConstants.SECOND_HEADER_LIST,secondHeaderList);
							}
							returnMap.put(verupReportComparisonConstants.PRIMARY_KEY_LIST,primaryKeyMap.get(verupReportComparisonConstants.PRIMARY_KEY_LIST));
							ses.shutdown();
							latch.countDown();
						}else if (dataMap.get(verupReportComparisonConstants.STATUS) == 8) {
							returnMap.put("error", "Error occured while running batch");
							ses.shutdown();
							latch.countDown();
						}else if(dataMap.get(verupReportComparisonConstants.STATUS) == 0&& queryId ==0) {
							returnMap.put("error", "Error occured while running batch");
							ses.shutdown();
							latch.countDown();
						}
					}
					}else {
						returnMap.put("error", "Error occured while running batch");
						ses.shutdown();
						latch.countDown();
					}
					connection.close();
				} catch (SQLException exception) {
					log.info(exception.toString());
					handleException(returnMap, exception.toString());
				}
			};
			ses.scheduleAtFixedRate(getDataToInsert,1, 1, TimeUnit.MICROSECONDS);
		}catch (Exception exception) { 
			log.info(exception.toString());
			handleException(returnMap, exception.toString());
		}
		latch.await();
	}

	private void handleException(Map<String, Object> returnMap, String exception) {
		returnMap.put("exception", exception);
	}

	@SuppressWarnings("unchecked")
	private Map<String, List<String>> readFirstDataAll(Connection connection, Statement statement, Map<String,Object> primaryKeyMap, Object object,String keyWord, List<String> headerList) throws SQLException {
		Map<String, List<String>> dataOneMap = new HashMap<String, List<String>>();
		ResultSet tableNameSet;
		String primaryKey = StringUtils.EMPTY;
		Integer dataIndex = 0;
		tableNameSet = statement.executeQuery(object.toString());
		while(tableNameSet.next()) {
			List<String> primaryKeyList = (List<String>) primaryKeyMap.get(verupReportComparisonConstants.PRIMARY_KEY_LIST);
			if(primaryKeyList.size() == 1) {
				primaryKey = primaryKeyList.get(0);

				List<String> valueOneList = new ArrayList<String>();	
				int columnCount = tableNameSet.getMetaData().getColumnCount();
				for(int count = 1; count <= columnCount;count++) {
					if(tableNameSet.isFirst()) {
						headerList.add(tableNameSet.getMetaData().getColumnName(count));
					}
					if(tableNameSet.getMetaData().getColumnName(count).equalsIgnoreCase(primaryKey)) {
						dataIndex = count;
					}
					valueOneList.add(tableNameSet.getString(count));
				}												
				dataOneMap.put(tableNameSet.getString(dataIndex), valueOneList);					 
			}else if(primaryKeyList.size() > 1) {
				String primaryKeyOne;
				primaryKey = primaryKeyList.get(0);
				List<Integer> fileIntList = new ArrayList<Integer>();
				List<String> valueTwoList = new ArrayList<String>();
				int columnCount = tableNameSet.getMetaData().getColumnCount();
				for(int count = 1; count <= columnCount;count++) {
					if(tableNameSet.isFirst()) {
						headerList.add(tableNameSet.getMetaData().getColumnName(count));
					}
					if(tableNameSet.getMetaData().getColumnName(count).equalsIgnoreCase(primaryKey)) {
						fileIntList.add(count);
					}
				}
				for(int keyCount=1;keyCount<primaryKeyList.size();keyCount++) {                	
					primaryKey = primaryKey + primaryKeyList.get(keyCount);  						
					for(int count = 1; count <= columnCount;count++) {
						if(tableNameSet.getMetaData().getColumnName(count).equalsIgnoreCase(primaryKeyList.get(keyCount))) {
							fileIntList.add(count);
						}
						valueTwoList.add(tableNameSet.getString(count));
					}
				}

				primaryKeyOne = tableNameSet.getString(fileIntList.get(0));
				for(int firstListIterator =1;firstListIterator < fileIntList.size();firstListIterator++) {
					tableNameSet.getString(firstListIterator);
					primaryKeyOne = primaryKeyOne + tableNameSet.getString(fileIntList.get(firstListIterator));
				}
				dataOneMap.put(primaryKeyOne, valueTwoList);	
			}
		}
		return dataOneMap;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, Object> getTableName(Connection connection, Statement statement, String tablesql) throws SQLException {
		Map<String, Object> returFinalMap = new HashMap<String, Object>();
		Map<String,String> queryMap = new HashMap<String, String>();
		List<String> primaryKeyList = new ArrayList<String>();
		Map<Integer,String> primaryKeyMap = new HashMap<Integer, String>();
		String tableName = StringUtils.EMPTY;

		ResultSet tableNameSet = statement.executeQuery(tablesql);
		if(tableNameSet.next()) {
			queryMap.put(verupReportComparisonConstants.QUERY, tableNameSet.getString(1));
		}

		Pattern p = Pattern.compile("from\\s+(?:\\w+\\.)*(\\w+)($|\\s+[WHERE,JOIN,START\\s+WITH,ORDER\\s+BY,GROUP\\s+BY])",Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(queryMap.get(verupReportComparisonConstants.QUERY)); 
		while(m.find()) {

			tableName = m.group(1);
		}


		DatabaseMetaData meta = connection.getMetaData();
		ResultSet rs1= meta.getTables(null, null, tableName.toUpperCase() , new String[]{verupReportComparisonConstants.TABLE});			
		rs1=meta.getPrimaryKeys(null, null, tableName.toUpperCase());
		while(rs1.next()) {
			primaryKeyMap.put(rs1.getInt(5), rs1.getString(4));
		}

		SortedSet<Integer> keys = new TreeSet(primaryKeyMap.keySet());
		for(Integer key : keys) {
			primaryKeyList.add(primaryKeyMap.get(key));
		}
		returFinalMap.put(verupReportComparisonConstants.PRIMARY_KEY_LIST, primaryKeyList);
		returFinalMap.put(verupReportComparisonConstants.QUERY, queryMap.get(verupReportComparisonConstants.QUERY));

		return returFinalMap;
	}


	public static Map<String,Integer> getParamDetails(Connection connection, String sql, Statement statement) throws SQLException {
		Map<String,Integer> returnMap = new HashMap<String, Integer>();
		ResultSet a = statement.executeQuery(sql);
		while(a.next()) {
			if (a.getString(4).equals(VerupReportComparisonConstants.QUERY_ID)) {
				returnMap.put(VerupReportComparisonConstants.QUERY_ID, a.getInt(2));
			}
			if (a.getString(4).equals(VerupReportComparisonConstants.FILENAME)) {
				returnMap.put(VerupReportComparisonConstants.FILENAME, a.getInt(2));
			}
		}
		return returnMap;
	}


	public static int getParamItemDetails(Connection connection, String sql, Statement statement) throws SQLException {
		int queryIdData = 0;
		ResultSet a = statement.executeQuery(sql);
		while(a.next()) {
			queryIdData = a.getInt(6);
		}
		return queryIdData;
	}

	public static String getParamFileNameItemDetails(Connection connection, String sql, Statement statement) throws SQLException {
		String queryIdData = StringUtils.EMPTY;
		ResultSet a = statement.executeQuery(sql);
		while(a.next()) {
			queryIdData = a.getString(6);
		}
		return queryIdData;
	}

	public static void getJobDetails(Connection connection, String sql, Statement statement,Map<String,Integer> dataMap) throws SQLException {
		int status = 0;
		int jobId = 0;
		ResultSet a = statement.executeQuery(sql);
		while(a.next()) {
			if(a.isFirst()) {
				jobId = a.getInt(1);
				status = a.getInt(3);
			}
		}
		dataMap.put(VerupReportComparisonConstants.JOB_ID, jobId);
		dataMap.put(VerupReportComparisonConstants.STATUS, status);
	}

	public static void getParamList(Connection connection, String sql, Statement statement,Map<String,Object> paramListMap) throws SQLException {
		ResultSet a = statement.executeQuery(sql);
		while(a.next()) {
			paramListMap.put(VerupReportComparisonConstants.ID,a.getInt(1));
			paramListMap.put(VerupReportComparisonConstants.PARAMETER,a.getString(2).isEmpty() ? StringUtils.EMPTY : a.getString(2));
			paramListMap.put(VerupReportComparisonConstants.USER_ID,a.getString(3).isEmpty() ? StringUtils.EMPTY : a.getString(3));
			paramListMap.put(VerupReportComparisonConstants.INPUT_DATE,a.getString(4).isEmpty() ? StringUtils.EMPTY : a.getString(4));
		}

	}

	public List<Map<String, String>> displayParameters(String companyKey) {
		List<Map<String,String>> doneList = new ArrayList<Map<String,String>>();
		try {
			EnvironmentConfigurationEntity environmentDetails = environmentRepository.findByName(companyKey);
			if(jdbcConnection.hostAvailabilityCheck(environmentDetails)==true) {
				String url = verupReportComparisonConstants.CONN_STRING + environmentDetails.getHost() + verupReportComparisonConstants.SEMI_COLON
						+ environmentDetails.getPort() + verupReportComparisonConstants.SEMI_COLON + environmentDetails.getSid();
				String user= environmentDetails.getUserName();
				String passCode = environmentDetails.getPassword();
			Map<String, String> dataMap = new HashMap<>();
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			Connection connection = DriverManager.getConnection(url, user, passCode);
			Statement  statement = connection.createStatement();
			String sql = "SELECT  DISTINCT(AC_COM_API_PARAM_ITEM.API_ACTPTN_CODE), AC_COM_API_PARAM_ITEM.API_JOB_ID,AC_COM_API_MST.PRODUCT_ID,AC_COM_API_MST.API_JOB_NAME "
					+ "FROM AC_COM_API_PARAM_ITEM ,"
					+ "AC_COM_API_MST "
					+ "where AC_COM_API_PARAM_ITEM.API_JOB_ID = AC_COM_API_MST.API_JOB_ID";
			ResultSet displayData = statement.executeQuery(sql);
			int key=0;
			while(displayData.next()) {
				dataMap = new HashMap<>();
				dataMap.put("key", Integer.toString(key));
				dataMap.put(verupReportComparisonConstants.API_JOB_ID,displayData.getString(2).isEmpty()? StringUtils.EMPTY : displayData.getString(2));
				dataMap.put(verupReportComparisonConstants.API_PTN_CODE,displayData.getString(1).isEmpty() ? StringUtils.EMPTY : displayData.getString(1));
				dataMap.put(verupReportComparisonConstants.API_JOB_NAME,displayData.getString(4).isEmpty() ? StringUtils.EMPTY : displayData.getString(4));
				dataMap.put(verupReportComparisonConstants.PRODUCT_ID,displayData.getString(3).isEmpty() ? StringUtils.EMPTY : displayData.getString(3));
				doneList.add(dataMap);
				key++;
			}			

			}else {
				return doneList;
			}
		}catch(Exception exception) {
			exception.printStackTrace();
			Map<String, String> exceptionMap = new HashMap<>();
			exceptionMap.put("exception", exception.toString());
			List<Map<String, String>> exceptionList = new ArrayList<>();
			exceptionList.add(exceptionMap);
			return exceptionList;
		}
		return doneList.stream().distinct().collect(Collectors.toList());
	}

	public void putDataToDb(Map<String, Object> returnMap,
			String apiJobName, List<Map<String, String>> fd, 
			List<Map<String, String>> sd, Map<Integer, List<Integer>> mismatchIndexMap, 
			List<String> list, List<String> list2, Set<Object> set, 
			List<Object> differenceIndexList, Object object) throws JsonMappingException, JsonProcessingException {
		dtoObject = new VerupReportComparisonDto();
		dtoObject.setJobId(returnMap.get(verupReportComparisonConstants.JOB_ID).toString());
		dtoObject.setPtnCode(returnMap.get(verupReportComparisonConstants.PTNCODE).toString());
		dtoObject.setJobName(apiJobName);
		dtoObject.setFirstDataMap(fd);
		dtoObject.setSecondDataMap(sd);
		dtoObject.setDownloadIndexMap(mismatchIndexMap);
		dtoObject.setFirstHeaderList(list);
		dtoObject.setSecondHeaderList(list2);
		dtoObject.setDisplayListMap(set);
		dtoObject.setDifferenceIndexList(differenceIndexList);
		dtoObject.setPrimaryKeyList(object);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(verupReportComparisonConstants.DATE_FORMAT);
		String formattedDate = formatter.format(date);
		dtoObject.setExecutionTime(formattedDate);
		if(returnMap.containsKey("error")) {
			dtoObject.setResult("FAILURE");
		}else {
			dtoObject.setResult("SUCCESS");
		}
		repository.insert(dtoObject);
	}
	public void putDataToDbOnFailure(Map<String, Object> returnMap,
			String apiJobName) {
		dtoObject = new VerupReportComparisonDto();
		dtoObject.setJobId(returnMap.get(verupReportComparisonConstants.JOB_ID).toString());
		dtoObject.setPtnCode(returnMap.get(verupReportComparisonConstants.PTNCODE).toString());
		dtoObject.setJobName(apiJobName);
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(verupReportComparisonConstants.DATE_FORMAT);
		String formattedDate = formatter.format(date);
		dtoObject.setExecutionTime(formattedDate);
		dtoObject.setResult("FAILURE");
		repository.insert(dtoObject);
	}

	public VerupReportComparisonDto getData(String string,String ptnCode,String executionCode) {
		return repository.findByJobIdAndPtnCodeAndExecutionTime(string, ptnCode,executionCode); 
	}

	public void putDataToDbbyId(Map<String, Object> returnMap, List<Map<String, String>> firstDataList,
			List<Map<String, String>> secondDataList, ObjectId id, Map<Integer, List<Integer>> mismatchIndexMap, List<String> list, List<String> list2, Set<Object> set, List<Object> differenceIndexList, Object object) {
		dtoObject.setId(id);
		dtoObject.setJobId(returnMap.get(verupReportComparisonConstants.JOB_ID).toString());
		dtoObject.setPtnCode(returnMap.get(verupReportComparisonConstants.PTNCODE).toString());
		dtoObject.setFirstDataMap(firstDataList);  
		dtoObject.setSecondDataMap(secondDataList);
		dtoObject.setDownloadIndexMap(mismatchIndexMap);
		dtoObject.setFirstHeaderList(list);
		dtoObject.setSecondHeaderList(list2);
		dtoObject.setDisplayListMap(set);
		dtoObject.setDifferenceIndexList(differenceIndexList);
		dtoObject.setPrimaryKeyList(object);
		repository.save(dtoObject);
	}
	
	public List<VerupReportComparisonDto> getResultsData(){
		return repository.findAll(Sort.by(Sort.Direction.DESC,"executionTime"));
	}
}
