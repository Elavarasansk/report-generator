package org.intraweb.tools.ReportComparison.dao.repository;

import org.intraweb.tools.ReportComparison.dao.dto.VerupReportComparisonDto;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface VerupReportComparisonRepository extends MongoRepository<VerupReportComparisonDto, String>{
	
	VerupReportComparisonDto findByJobIdAndPtnCode(String jobId,String ptnCode);

	VerupReportComparisonDto findByJobIdAndPtnCodeAndExecutionTime(String string, String ptnCode, String executionCode);
}
