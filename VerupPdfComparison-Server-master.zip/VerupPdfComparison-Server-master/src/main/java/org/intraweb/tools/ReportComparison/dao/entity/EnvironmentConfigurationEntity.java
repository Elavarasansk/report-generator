package org.intraweb.tools.ReportComparison.dao.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Document(collection ="environment_data")
@Data
@Builder
public class EnvironmentConfigurationEntity {

    @Id
    private String id;
    private String name;
    private verTypeEnum environmentType;
    private String host;
    private String port;
    private String sid;
    private String userName;
    private String password;
    private String createdUser;
    private String createdDate;
    private String updatedUser;
    private String updatedDate;
    private boolean currentEnvironment;

    public enum verTypeEnum {
        VERSION_36, VERSION_40
    }

}
