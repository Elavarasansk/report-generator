package org.intraweb.tools.ReportComparison.dao.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProgressBar {

	public float percentage;

	public String jobId;

	public Integer key;

	public String result;
	
}
