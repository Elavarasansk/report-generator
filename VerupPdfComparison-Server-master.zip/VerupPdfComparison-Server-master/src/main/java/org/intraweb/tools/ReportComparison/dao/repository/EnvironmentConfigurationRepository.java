package org.intraweb.tools.ReportComparison.dao.repository;

import java.util.List;

import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity.verTypeEnum;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface EnvironmentConfigurationRepository extends MongoRepository<EnvironmentConfigurationEntity, String> {

	public List<EnvironmentConfigurationEntity> findByCurrentEnvironment(boolean currentEnvironment);

	public List<EnvironmentConfigurationEntity> findAllById(String id);
	
	public EnvironmentConfigurationEntity findByName(String name);

	public List<EnvironmentConfigurationEntity> findByEnvironmentType(verTypeEnum environmentType);
}
