package org.intraweb.tools.ReportComparison.constant;

import org.springframework.stereotype.Component;

@Component
public class VerupReportComparisonConstants {
	
	public String DELPHI_URL = "jdbc:oracle:thin:@192.168.41.170:1521:cpac";
	public String ACCOUNT = "account";
	public String DELPHI_DB = "192.168.41.170:1521:cpac";
	public String DELPHI_KEYWORD = "first";
	public String WEB_URL ="jdbc:oracle:thin:@192.168.50.174:1521:cpac";
	public String WEB_DB = "192.168.50.174:1521:cpac";
	public String WEB_KEYWORD = "second";
	public String FIRST_HEADER_LIST = "firstHeaderList";
	public String SECOND_HEADER_LIST = "secondHeaderList";
	public String FIRST_DATA_MAP = "firstDataMap";
	public String SECOND_DATA_MAP = "secondDataMap";
	public String PRIMARY_KEY_LIST = "primaryKeyList";
	public String INITIAL_DISPLAY_LIST = "initialDisplayList";
	public String DIFFERENCE_INDEX_LIST = "differenceIndexList";
	public String DISPLAY_LIST_MAP = "displayListMap";
	public String INI_FILE_PATH = "C://HUE//WorkSpace//account//exe//WAServlet.ini";
	public String DATABASE = "Database";
	public String MAIL = "MAIL";
	public String SYSTEM = "System";
	public String USER = "User";
	public String PASSWORD = "Password";
	public String SMTP_SERVER = "SMTPSERVER";
	public String FROM_ADDRESS = "FROM_ADDRESS";
	public String SMTP = "(蟄伜惠縺吶ｋSMTP繧ｵ繝ｼ繝仙錐)";
	public String ADDRESS = "(騾∽ｿ｡閠�縺ｮ繝｡繝ｼ繝ｫ繧｢繝峨Ξ繧ｹ)";
	public String QUERYID = "queryId";
	public static String QUERY_ID = "QUERY_ID";
	public String FILE_NAME = "fileName";
	public static String STATUS = "status";
	public static String JOB_ID = "jobId";
	public String QUERY = "Query";
	public static String ID = "id";
	public static String PARAMETER = "parameter";
	public static String USER_ID = "userId";
	public static String INPUT_DATE = "inputDate";
	public static String FILENAME = "FILE_NAME";
	public String API_JOB_ID = "apiJobId";
	public String API_PTN_CODE = "apiPtnCode";
	public String API_JOB_NAME = "apiJobName";
	public String PRODUCT_ID = "productId";
	public String TABLE = "TABLE";
	public String PTNCODE = "ptnCode";
	public static final String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss";
	public static final String ENV_LIST = "environmentList";
	public static final String TEST_CHECKER = "testChecker";
	public static final String VERSION_36 = "version_36";
    public static final String VERSION_40 = "version_40";
    public static final String ENUM_VERSION_36 = "VERSION_36";
    public static final String ENUM_VERSION_40 = "VERSION_40";
    public static final int MINUS_ONE = -1;
    public static final String SEMI_COLON = ":";
	public static final String CONN_STRING = "jdbc:oracle:thin:@";

}
