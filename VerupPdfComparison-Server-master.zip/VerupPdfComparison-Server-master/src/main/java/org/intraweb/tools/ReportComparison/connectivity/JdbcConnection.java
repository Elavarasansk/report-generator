package org.intraweb.tools.ReportComparison.connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity.verTypeEnum;
import org.springframework.stereotype.Service;

@Service
public class JdbcConnection {

	// JDBC driver name and database URL
	private static final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";

	private static final String SEMI_COLON = ":";

	private static final String CONN_STRING = "jdbc:oracle:thin:@";

	private Connection conn36 = null;
	private Connection conn40 = null;

	public Connection prepareConnStatement(EnvironmentConfigurationEntity environmentConfigurationEntity) {
		Connection conn = null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			final String DB_URL = CONN_STRING + environmentConfigurationEntity.getHost() + SEMI_COLON
					+ environmentConfigurationEntity.getPort() + SEMI_COLON + environmentConfigurationEntity.getSid();
			conn = DriverManager.getConnection(DB_URL, environmentConfigurationEntity.getUserName(),
					environmentConfigurationEntity.getPassword());
		
		} catch (SQLException e) {
			return conn;
		}
		return conn;
	}

	public boolean hostAvailabilityCheck(EnvironmentConfigurationEntity environmentConfigurationEntity) {
		Connection connection = prepareConnStatement(environmentConfigurationEntity);
		try {
			if (connection.isClosed()) {
				return false;
			} else {
				if (environmentConfigurationEntity.getEnvironmentType().equals(verTypeEnum.VERSION_36)) {
					conn36 = connection;
				} else if (environmentConfigurationEntity.getEnvironmentType().equals(verTypeEnum.VERSION_40)) {
					conn40 = connection;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void destroyConnection() {
		try {
			conn36.close();
			conn40.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}