package org.intraweb.tools.ReportComparison.service;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.ini4j.Config;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Wini;
import org.intraweb.tools.ReportComparison.connectivity.JdbcConnection;
import org.intraweb.tools.ReportComparison.constant.VerupReportComparisonConstants;
import org.intraweb.tools.ReportComparison.dao.VerupReportComparisonDao;
import org.intraweb.tools.ReportComparison.dao.dto.VerupReportComparisonDto;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity.verTypeEnum;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationVo;
import org.intraweb.tools.ReportComparison.dao.entity.GetMappingPojo;
import org.intraweb.tools.ReportComparison.dao.entity.ProgressBar;
import org.intraweb.tools.ReportComparison.dao.repository.EnvironmentConfigurationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VerupReportComparisonService {

	@Autowired
	VerupReportComparisonDao verupReportComparisonDao;
	@Autowired
	VerupReportComparisonConstants verupReportComparisonConstants;
	@Autowired
	private SimpMessageSendingOperations messagingTemplate;
	@Autowired
	private EnvironmentConfigurationRepository environmentRepository;
	@Autowired
    private JdbcConnection jdbcConnection;
	
	@SuppressWarnings("rawtypes")
	public void reportGenerate(GetMappingPojo getMappingPojo,
			Map<String,Object> returnMap) throws InterruptedException, IOException {		
		Map<String,List<String>> fir = new HashMap<String, List<String>>();
		Map<String,List<String>> sec = new HashMap<String, List<String>>();		
		Thread t1 = new Thread() {
			public void run() {
				try {
					EnvironmentConfigurationEntity environmentDetails = environmentRepository.findByName(getMappingPojo.getDbVersionCompanyKey());
					if(jdbcConnection.hostAvailabilityCheck(environmentDetails)==true) {
					String url = verupReportComparisonConstants.CONN_STRING + environmentDetails.getHost() + verupReportComparisonConstants.SEMI_COLON
							+ environmentDetails.getPort() + verupReportComparisonConstants.SEMI_COLON + environmentDetails.getSid();
					String user= environmentDetails.getUserName();
					String passCode = environmentDetails.getPassword();
					updateProgressPercent(getMappingPojo.getKey(),10,"pass");
					setIniValues(environmentDetails.getHost()+":"+environmentDetails.getPort()+":"+environmentDetails.getSid(), user, passCode);
					verupReportComparisonDao.executeQuery(getMappingPojo,url,user,passCode,returnMap,verupReportComparisonConstants.DELPHI_KEYWORD,fir,sec);
					}else {
						updateProgressPercent(getMappingPojo.getKey(),0,"host unavailable");
						returnMap.put("error", "host unavailable");
					}
				} catch (InterruptedException exception) {
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString());
					handleException(returnMap, exception.toString());
				} catch (IOException exception)
				{
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString()); 
					handleException(returnMap, exception.toString());
				}catch(NullPointerException exception) {
					returnMap.put(verupReportComparisonConstants.JOB_ID,getMappingPojo.getApiJobId());
					returnMap.put(verupReportComparisonConstants.PTNCODE,getMappingPojo.getApiPtnCode());
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString()); 
					handleException(returnMap, exception.toString());
				}
			}
		};
		Thread t2 = new Thread() {
			public void run() {
				try {
					EnvironmentConfigurationEntity environmentDetails = environmentRepository.findByName(getMappingPojo.getDbVersionCompanyKey());
					if(jdbcConnection.hostAvailabilityCheck(environmentDetails)==true) {
					String url = verupReportComparisonConstants.CONN_STRING + environmentDetails.getHost() + verupReportComparisonConstants.SEMI_COLON
							+ environmentDetails.getPort() + verupReportComparisonConstants.SEMI_COLON + environmentDetails.getSid();
					String user= environmentDetails.getUserName();
					String passCode = environmentDetails.getPassword();
					setIniValues(environmentDetails.getHost()+":"+environmentDetails.getPort()+":"+environmentDetails.getSid() , user, passCode);
					try {
						Runtime.getRuntime().exec("taskkill /f /im cmd.exe") ;
						updateProgressPercent(getMappingPojo.getKey(),25,"pass");
					} catch (Exception exception) {
						updateProgressPercent(getMappingPojo.getKey(),0,"fail");
						log.info(exception.toString());  
						handleException(returnMap, exception.toString());
					}
					sleep(1000);
					verupReportComparisonDao.executeQuery(getMappingPojo,url,user,passCode,returnMap, verupReportComparisonConstants.WEB_KEYWORD,fir,sec);
					}else {
						updateProgressPercent(getMappingPojo.getKey(),0,"host unavailable");
						returnMap.put("error", "host unavailable");
					}
				} catch (InterruptedException exception) {
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString());
					handleException(returnMap, exception.toString());
				} catch (IOException exception)
				{
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString()); 
					handleException(returnMap, exception.toString());
				}catch(NullPointerException exception) {
					returnMap.put(verupReportComparisonConstants.JOB_ID,getMappingPojo.getApiJobId());
					returnMap.put(verupReportComparisonConstants.PTNCODE,getMappingPojo.getApiPtnCode());
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString()); 
					handleException(returnMap, exception.toString());
				}
			}
		};
		
		try {
		t1.start();		
		t1.join();
		if(returnMap.containsKey("error")|| returnMap.containsKey("exception")) {
			Runtime.getRuntime().exec("taskkill /f /im cmd.exe") ;
			updateProgressPercent(getMappingPojo.getKey(),0,"fail");
		}else {
			t2.start();
			t2.join();
		}
		} catch (InterruptedException exception) {
			updateProgressPercent(getMappingPojo.getKey(),0,"fail");
			log.info(exception.toString()); 
			handleException(returnMap, exception.toString());
		}
		if(returnMap.containsKey("error")||returnMap.containsKey("exception")) {
			updateProgressPercent(getMappingPojo.getKey(),0,"fail");
			verupReportComparisonDao.putDataToDbOnFailure(returnMap,getMappingPojo.getApiJobName());
		}else {
		List<Object> differenceIndexList = new ArrayList<>();
		List<List<String>> firstFinalList = new ArrayList<>();
		List<List<String>> secFinalList = new ArrayList<>();
		Map<Integer,List<Integer>> mismatchIndexMap = new HashMap<Integer, List<Integer>>();
		updateProgressPercent(getMappingPojo.getKey(),50,"pass");
		

		Thread t3 = new Thread() {
			public void run() {
				try {
					Runtime.getRuntime().exec("taskkill /f /im cmd.exe");
					compareTwoFiles(fir,sec,differenceIndexList,convertToList(returnMap.get(verupReportComparisonConstants.FIRST_HEADER_LIST)),convertToList(returnMap.get(verupReportComparisonConstants.SECOND_HEADER_LIST)),firstFinalList,secFinalList,mismatchIndexMap);
				} catch (JsonMappingException exception) {
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString());
					handleException(returnMap, exception.toString());
				} catch (JsonProcessingException exception) {
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString());
					handleException(returnMap, exception.toString());
				} catch (Exception exception) {
					updateProgressPercent(getMappingPojo.getKey(),0,"fail");
					log.info(exception.toString());  
					handleException(returnMap, exception.toString());
				}
			}								 
		};
		try {
				t3.start();
				t3.join();	
		} catch (InterruptedException exception) {
			updateProgressPercent(getMappingPojo.getKey(),0,"fail");
			log.info(exception.toString());
			handleException(returnMap, exception.toString());
		}
		List<Object> distinctKeyList = new ArrayList<Object>();
    	distinctKeyList = differenceIndexList.stream().filter(as->CollectionUtils.isNotEmpty((Collection) as)).limit(1).collect(Collectors.toList());
		Set<Object> initialDisplayList = new HashSet<Object>();
		Map<String,Set<Object>> displayListMap = new HashMap<>();
		List<String> differenceHeaderList = new ArrayList<>();
		try {
			returnMap.put(verupReportComparisonConstants.FIRST_DATA_MAP ,prepareResponseDataTwo(firstFinalList,convertToList(returnMap.get(verupReportComparisonConstants.FIRST_HEADER_LIST))));
			returnMap.put(verupReportComparisonConstants.SECOND_DATA_MAP ,prepareResponseDataTwo(secFinalList,convertToList(returnMap.get(verupReportComparisonConstants.SECOND_HEADER_LIST))));
			getHeaderListDifference(convertToList(returnMap.get(verupReportComparisonConstants.FIRST_HEADER_LIST)),convertToList(returnMap.get(verupReportComparisonConstants.SECOND_HEADER_LIST)),differenceHeaderList);
			initialDisplayList.addAll(convertToList(returnMap.get(verupReportComparisonConstants.PRIMARY_KEY_LIST)));
			if(CollectionUtils.isNotEmpty(distinctKeyList)) {
				List<String> dkList = convertToList(distinctKeyList.get(0));
				List<String> pkList = convertToList(returnMap.get("primaryKeyList"));
				initialDisplayList.addAll(dkList.stream().filter(predicate-> !pkList.contains(predicate)).limit(3).collect(Collectors.toList()));
			}
		} catch (JsonProcessingException exception) {
			exception.printStackTrace();
			handleException(returnMap, exception.toString());
			updateProgressPercent(getMappingPojo.getKey(),0,"fail");
		}
		initialDisplayList.addAll(differenceHeaderList);
		updateProgressPercent(getMappingPojo.getKey(),80,"pass");
		displayListMap.put(verupReportComparisonConstants.INITIAL_DISPLAY_LIST ,initialDisplayList);
		returnMap.put(verupReportComparisonConstants.DIFFERENCE_INDEX_LIST ,differenceIndexList);
		returnMap.put(verupReportComparisonConstants.DISPLAY_LIST_MAP ,displayListMap);
        verupReportComparisonDao.putDataToDb(returnMap,getMappingPojo.getApiJobName(),prepareResponseDataTwo(firstFinalList,convertToList(returnMap.get(verupReportComparisonConstants.FIRST_HEADER_LIST))),prepareResponseDataTwo(secFinalList,convertToList(returnMap.get(verupReportComparisonConstants.SECOND_HEADER_LIST))),mismatchIndexMap,convertToList(returnMap.get(verupReportComparisonConstants.FIRST_HEADER_LIST)),convertToList(returnMap.get(verupReportComparisonConstants.SECOND_HEADER_LIST)),displayListMap.get(verupReportComparisonConstants.INITIAL_DISPLAY_LIST),differenceIndexList,returnMap.get("primaryKeyList"));
        updateProgressPercent(getMappingPojo.getKey(),100,"pass");
		}
	}
	
	private void updateProgressPercent(Integer key,float percentage, String result) {
		messagingTemplate.convertAndSend("/topic/public",ProgressBar.builder().percentage(percentage).result(result).key(key).build());
	}
	
	protected void handleException(Map<String, Object> returnMap, String exception) {
		returnMap.put("exception", exception);	
	}
	
	private List<Map<String,String>> prepareResponseDataTwo(List<List<String>> firstFinalList,
			List<String> convertToList) {
		List<Map<String,String>> finList = new ArrayList<Map<String,String>>();
		AtomicInteger runCount= new AtomicInteger(0);
		firstFinalList.stream().forEach(action->{			
			Map<String,String> resultMap = new HashMap<String, String>();
			resultMap.put("key", String.valueOf(runCount));
			List<String> as = action;
			if(!as.isEmpty()) {
				for(int count = 0; count< convertToList.size();count++) {		
					resultMap.put(convertToList.get(count), as.get(count)); 
				}			
			}
			finList.add(resultMap);
			runCount.getAndIncrement();
		});
		return finList;	
	}
	
	private void getHeaderListDifference(List<String> firstHeaderList, List<String> secondHeaderList,
			List<String> differenceHeaderList) {
		differenceHeaderList.addAll(firstHeaderList.stream().filter(data -> !secondHeaderList.contains(data)).collect(Collectors.toList()));
		differenceHeaderList.addAll(secondHeaderList.stream().filter(data -> !firstHeaderList.contains(data)).collect(Collectors.toList()));
	}

	private List<String> convertToList(Object convertData) throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(objectMapper.writeValueAsString(convertData), new TypeReference<List<String>>(){});
	}
	
	private void setIniValues(String url, String userName, String password) throws InvalidFileFormatException, IOException {
			Wini ini = new Wini(new File(verupReportComparisonConstants.INI_FILE_PATH));
			Config config = ini.getConfig();
			config.setStrictOperator(true);
			ini.setConfig(config); 
			ini.put(verupReportComparisonConstants.DATABASE, verupReportComparisonConstants.SYSTEM, url);
			ini.put(verupReportComparisonConstants.DATABASE, verupReportComparisonConstants.USER, userName);
			ini.put(verupReportComparisonConstants.DATABASE, verupReportComparisonConstants.PASSWORD, password);
			ini.put(verupReportComparisonConstants.MAIL, verupReportComparisonConstants.SMTP_SERVER, verupReportComparisonConstants.SMTP).toString();
			ini.put(verupReportComparisonConstants.MAIL, verupReportComparisonConstants.FROM_ADDRESS, verupReportComparisonConstants.ADDRESS).toString();
			ini.store();
		} 

	private static void compareTwoFiles(Map<String, List<String>> firstDataMap, Map<String, List<String>> secondDataMap, List<Object> finalList, List<String> firstHeaderList, List<String> secondHeaderList, List<List<String>> firstFinalList, List<List<String>> secFinalList, Map<Integer, List<Integer>> mismatchIndexMap) {
		if(secondDataMap.size() > firstDataMap.size()) {
			secondDataMap.entrySet().stream().forEach(action->{
				List<String> first =  firstDataMap.get(action.getKey());
				List<String> second = action.getValue();
				List<Object> indexList = new ArrayList<>();
				List<Integer> indexIntList = new ArrayList<>();
				if(Objects.nonNull(first) && Objects.nonNull(second)) {
					for(int firstIterator= 0;firstIterator<first.size();firstIterator++) {
						if(Objects.nonNull(first.get(firstIterator)) && Objects.nonNull(second.get(firstIterator)) && !first.get(firstIterator).equalsIgnoreCase(second.get(firstIterator))) {					
							indexList.add(firstHeaderList.get(firstIterator)); 
							indexIntList.add(firstIterator);
						}else if(Objects.nonNull(first.get(firstIterator)) && !Objects.nonNull(second.get(firstIterator))) {
							indexIntList.add(firstIterator);
							indexList.add(firstHeaderList.get(firstIterator));
						}else if(!Objects.nonNull(first.get(firstIterator)) && Objects.nonNull(second.get(firstIterator))) {
							indexIntList.add(firstIterator);
							indexList.add(firstHeaderList.get(firstIterator));
						}					
					}	
					firstFinalList.add(first);
					secFinalList.add(second);
				}else if(Objects.nonNull(second) && !Objects.nonNull(first) ){
					firstFinalList.add(new ArrayList<String>());
					secFinalList.add(second);
					for(int secondHeaderListIterator= 0;secondHeaderListIterator<secondHeaderList.size() ;secondHeaderListIterator++) {
						indexList.add(secondHeaderList.get(secondHeaderListIterator)); 
					}
				}
                finalList.add(indexList);
				if(!CollectionUtils.isEmpty(indexIntList)) {
					mismatchIndexMap.put(mismatchIndexMap.size() ,indexIntList);
				} else {
					mismatchIndexMap.put(mismatchIndexMap.size() ,indexIntList);
				}
			});
			firstDataMap.entrySet().stream().forEach(action->{
				List<String> second =  secondDataMap.get(action.getKey());
				List<String> first = action.getValue();
				List<Object> indexList = new ArrayList<Object>();
				if(Objects.nonNull(first) && !Objects.nonNull(second)){
					secFinalList.add(new ArrayList<String>());
					firstFinalList.add(first);	
					for(int firstHeaderListIterator= 0;firstHeaderListIterator<firstHeaderList.size();firstHeaderListIterator++) {
						indexList.add(firstHeaderList.get(firstHeaderListIterator)); 
					}
				}
				if(!CollectionUtils.isEmpty(indexList)) {
					finalList.add(indexList);
				}				
			});
		}else {
			firstDataMap.entrySet().stream().forEach(action->{
				List<String> second =  secondDataMap.get(action.getKey());
				List<String> first = action.getValue();
				List<Object> indexList = new ArrayList<Object>();
				List<Integer> indexIntList = new ArrayList<>();
				if(Objects.nonNull(first) && Objects.nonNull(second)) {
					for(int firstIterator= 0;firstIterator<first.size();firstIterator++) {
						if(Objects.nonNull(first.get(firstIterator)) && Objects.nonNull(second.get(firstIterator)) && !first.get(firstIterator).equalsIgnoreCase(second.get(firstIterator))) {					
							indexList.add(secondHeaderList.get(firstIterator));
							indexIntList.add(firstIterator);
						}else if(Objects.nonNull(first.get(firstIterator)) && !Objects.nonNull(second.get(firstIterator))) {
							indexIntList.add(firstIterator);
							indexList.add(secondHeaderList.get(firstIterator));
						}else if(!Objects.nonNull(first.get(firstIterator)) && Objects.nonNull(second.get(firstIterator))) {
							indexIntList.add(firstIterator);
							indexList.add(secondHeaderList.get(firstIterator));
						}			
					}
					firstFinalList.add(first);
					secFinalList.add(second);
				}else if(Objects.nonNull(first) && !Objects.nonNull(second)){
					secFinalList.add(new ArrayList<String>());
					firstFinalList.add(first);	
					for(int firstHeaderListIterator= 0;firstHeaderListIterator<firstHeaderList.size() ;firstHeaderListIterator++) {
						indexList.add(firstHeaderList.get(firstHeaderListIterator)); 
					}
				}
				finalList.add(indexList);
				
				if(!CollectionUtils.isEmpty(indexIntList)) {
					mismatchIndexMap.put(mismatchIndexMap.size() ,indexIntList);
				} else {
					mismatchIndexMap.put(mismatchIndexMap.size() ,indexIntList);
				}
			});
			secondDataMap.entrySet().stream().forEach(action->{
				List<String> first =  firstDataMap.get(action.getKey());
				List<String> second = action.getValue();
				List<Object> indexList = new ArrayList<Object>();
				if(Objects.nonNull(second) && !Objects.nonNull(first) ){
					firstFinalList.add(new ArrayList<String>());
					secFinalList.add(second);
					for(int secondHeaderListIterator= 0;secondHeaderListIterator<secondHeaderList.size() ;secondHeaderListIterator++) {
						indexList.add(secondHeaderList.get(secondHeaderListIterator)); 
					}
				}
				if(!CollectionUtils.isEmpty(indexList)) {
					finalList.add(indexList);
				}				
			});						
		}		
	}

	public List<Map<String, String>> displayParameters(String companyKey) {
		return verupReportComparisonDao.displayParameters(companyKey);
	}

	@SuppressWarnings("resource")
	public void downloadCsv(GetMappingPojo getMappingPojo, HttpServletResponse response) throws IOException {
		response.setContentType("application/octet-stream");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=Difference.xlsx");
        List<Map<String, String>> firstExtraDataList = new ArrayList<>();
		List<Map<String, String>> secondExtraDataList = new ArrayList<>();
        VerupReportComparisonDto data = verupReportComparisonDao.getData(getMappingPojo.getApiJobId().toString(),getMappingPojo.getApiPtnCode(),getMappingPojo.getExecutionTime());
		List<Map<String, String>> firstDataList = data.getFirstDataMap();
		List<Map<String, String>> secondDataList = data.getSecondDataMap();
		List<String> firstdbheader =  data.getFirstHeaderList();
		List<String> seconddbheader =  data.getSecondHeaderList();
		Map<Integer,List<Integer>> downIndex =  data.getDownloadIndexMap();
		
		final String FILE_NAME = "C:\\HUE\\Workspace\\account\\tmp\\Difference.xlsx";
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("v36");
        XSSFColor myColor = new XSSFColor(Color.GREEN);
        XSSFColor myColorOne = new XSSFColor(Color.BLUE);
        XSSFColor myColorTwo = new XSSFColor(Color.RED);
        sheet.setTabColor(myColor);
        XSSFSheet sheetTwo = workbook.createSheet("v40");
        sheetTwo.setTabColor(myColorOne);
        XSSFSheet sheetThree = workbook.createSheet("Inconsistent Data");
        XSSFSheet sheetFour = workbook.createSheet("Extra Data");
        XSSFCellStyle style = workbook.createCellStyle();
        style.setFillForegroundColor(myColorOne);
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		XSSFCellStyle styleOne = workbook.createCellStyle();
        styleOne.setFillForegroundColor(myColor);
        styleOne.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        XSSFCellStyle styleTwo = workbook.createCellStyle();
        styleTwo.setFillForegroundColor(myColorTwo);
        styleTwo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        
        Row row,rowOne,rowTwo,rowThree;
        
        List<String> firstDbHeaaderExtraList =new ArrayList<>();
        List<String> secondDbHeaaderExtraList =new ArrayList<>();
        Boolean firstGreater,secondGreater = false;
        if(firstdbheader.size() > seconddbheader.size()) {
        	firstGreater = true;
        	  firstdbheader.stream().forEach(action->{
        		if(!seconddbheader.contains(action)) {
        			firstDbHeaaderExtraList.add(action);
        		}
        	});
        }else if(seconddbheader.size() > firstdbheader.size()) {
        	secondGreater = true;
        	seconddbheader.stream().forEach(action->{
        		if(!firstdbheader.contains(action)) {
        			secondDbHeaaderExtraList.add(action);
        		}
        	});
        }
        
        
        int colNumThird = 0,colNumFourth=0;
		int colNumSecond = 0;
		 int colNumFirst = 0;
		 row = sheet.createRow(0);
		for(String as:firstdbheader) {
			   if(firstDbHeaaderExtraList.size() > 0 && firstDbHeaaderExtraList.contains(as) ) {
				   Cell cell = row.createCell(colNumFirst++);
		           cell.setCellValue((String) as);
		           cell.setCellStyle(styleTwo);
			   }else {   
				 Cell cell = row.createCell(colNumFirst++);
	             cell.setCellValue((String) as);
			   }
		}
		rowOne = sheetTwo.createRow(0);
		for(String as:seconddbheader) {
			 if(secondDbHeaaderExtraList.size() > 0 && secondDbHeaaderExtraList.contains(as) ) {
				   Cell cell = row.createCell(colNumSecond++);
		           cell.setCellValue((String) as);
		           cell.setCellStyle(styleTwo);
			   }else {
				 Cell cell = rowOne.createCell(colNumSecond++);
	             cell.setCellValue((String) as);
		}
		}	 
		
		if(seconddbheader.size() > firstdbheader.size() || seconddbheader.size() == firstdbheader.size()) {
		rowTwo = sheetThree.createRow(0);
		for(String as:seconddbheader) {
				 Cell cell = rowTwo.createCell(colNumThird++);
	             cell.setCellValue((String) as);
		}
		}else {
			rowTwo = sheetThree.createRow(0);
			for(String as:firstdbheader) {
					 Cell cell = rowTwo.createCell(colNumThird++);
		             cell.setCellValue((String) as);
			}	
		}
		
		if(seconddbheader.size() > firstdbheader.size() || seconddbheader.size() == firstdbheader.size()) {
		rowThree = sheetFour.createRow(0);
		for(String as:seconddbheader) {
			Cell cell = rowThree.createCell(colNumFourth++);
            cell.setCellValue((String) as);
	    }
		}else {
			rowThree = sheetFour.createRow(0);
			for(String as:firstdbheader) {
				Cell cell = rowThree.createCell(colNumFourth++);
	            cell.setCellValue((String) as);
		    }	
			
		}
		
		 int j=1,p=0;
		 for (Map<String, String> rows : firstDataList) {
             if(rows.values().size() > 1) {
			 row =sheet.createRow(j);
			 int colNum = 0;
			 for(int firstdbheaderIterator=0;firstdbheaderIterator<firstdbheader.size();firstdbheaderIterator++) {				 
				 String idd = rows.get(firstdbheader.get(firstdbheaderIterator));
				 Cell cell = row.createCell(colNum++);
	                 cell.setCellValue((String) idd);
	              if(firstDbHeaaderExtraList.size() > 0 && firstDbHeaaderExtraList.contains(firstdbheader.get(firstdbheaderIterator))){
	            	  cell.setCellStyle(styleTwo);
	              }
			 }
			 j++;
			 }else {
				 secondExtraDataList.add(secondDataList.get(p));
			 }
             p++;
		}
		 int i = 1,q=0;
		 for (Map<String, String> rows : secondDataList) {
			 if(rows.values().size() > 1) {
		     rowOne =sheetTwo.createRow(i);
			 int colNum = 0;
			 for(int seconddbheaderIterator=0;seconddbheaderIterator<seconddbheader.size();seconddbheaderIterator++) {				 
				 String idd = rows.get(seconddbheader.get(seconddbheaderIterator));
				 Cell cell = rowOne.createCell(colNum++);
	                 cell.setCellValue((String) idd);
	               if(secondDbHeaaderExtraList.size() > 0 && secondDbHeaaderExtraList.contains(seconddbheader.get(seconddbheaderIterator))){
		            	  cell.setCellStyle(styleTwo);
		            }   
			 }
			 i++;
			 }else {
				 firstExtraDataList.add(firstDataList.get(q));
			 }
			 q++;
		}
		 List<Integer> indexList = new ArrayList<Integer>();
		 downIndex.entrySet().stream().filter(predicate->!predicate.getValue().isEmpty()).forEach(action->
		 indexList.add(action.getKey()));
		 
		 int kk =1;
		 for(int indexListIterator= 0;indexListIterator<indexList.size();indexListIterator++) {
			 Map<String, String> rowfirst =	 firstDataList.get(indexList.get(indexListIterator));
				 rowTwo = sheetThree.createRow(kk);
				 int colNum = 0;
				 for(int firstdbheaderIterator=0;firstdbheaderIterator<firstdbheader.size();firstdbheaderIterator++) {				 
					 String idd = rowfirst.get(firstdbheader.get(firstdbheaderIterator));
					 Cell cell = rowTwo.createCell(colNum++);
					 cell.setCellValue((String) idd);
					 List<Integer> sd = downIndex.get(indexList.get(indexListIterator));
					 if(sd.contains(firstdbheaderIterator)) {
						 cell.setCellStyle(styleOne);
					 }
				 }
				 kk++;
				 Map<String, String> rowsecond = secondDataList.get(indexList.get(indexListIterator));
				 secondDataList.get(indexList.get(indexListIterator));
				 rowTwo = sheetThree.createRow(kk);
				 int colNumm = 0;
				 for(int seconddbheaderIterator=0;seconddbheaderIterator<seconddbheader.size();seconddbheaderIterator++) {				 
					 String idd = rowsecond.get(seconddbheader.get(seconddbheaderIterator));
					 Cell cell = rowTwo.createCell(colNumm++);
					 cell.setCellValue((String) idd);
					 List<Integer> sd = downIndex.get(indexList.get(indexListIterator));
					 if(sd.contains(seconddbheaderIterator)) {
						 cell.setCellStyle(style);
					 }
				 }
				 kk++;
		 }
		 int kd = 1;
		 for (Map<String, String> rows : firstExtraDataList) {
			 if(rows.values().size() > 1) {
		     rowThree =sheetFour.createRow(kd);
			 int colNm = 0;
			 for(int seconddbheaderIterator=0;seconddbheaderIterator<firstdbheader.size();seconddbheaderIterator++) {				 
				 String idd = rows.get(firstdbheader.get(seconddbheaderIterator));
				 Cell cell = rowThree.createCell(colNm++);
	                 cell.setCellValue((String) idd);
	                 cell.setCellStyle(styleOne);
			 }
			 kd++;
			 }
		}
		 for (Map<String, String> rows : secondExtraDataList) {
			 if(rows.values().size() > 1) {
		     rowThree =sheetFour.createRow(kd);
			 int colNm = 0;
			 for(int seconddbheaderIterator=0;seconddbheaderIterator<seconddbheader.size();seconddbheaderIterator++) {				 
				 String idd = rows.get(seconddbheader.get(seconddbheaderIterator));
				 Cell cell = rowThree.createCell(colNm++);
	                 cell.setCellValue((String) idd);
	                 cell.setCellStyle(style);
			 }
			 kd++;
			 }
		} 
			try {	    		
	            FileOutputStream outputFileStream = new FileOutputStream(FILE_NAME);
				OutputStream outStream = response.getOutputStream();
	            workbook.write(outputFileStream);
				byte[] buffer = new byte[4096];
				int bytesRead = -1;
				FileInputStream inStream = new FileInputStream(FILE_NAME);
				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
	            outStream.close();
	            outputFileStream.close();
	            inStream.close();
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}

	public VerupReportComparisonDto getData(GetMappingPojo getMappingPojo) {
		return verupReportComparisonDao.getData(getMappingPojo.getApiJobId().toString(), getMappingPojo.getApiPtnCode(),getMappingPojo.getExecutionTime());
	}

	public Map<String, Object> getDataOne(GetMappingPojo getMappingPojo) {
		Map<String,Object> returnMap = new  HashMap<>();
		VerupReportComparisonDto dtoObject = getData(getMappingPojo);
		returnMap.put("firstDataMap",dtoObject.getFirstDataMap());
		returnMap.put("secondDataMap", dtoObject.getSecondDataMap());
		returnMap.put("firstHeaderList",dtoObject.getFirstHeaderList());
		returnMap.put("secondHeaderList",dtoObject.getSecondHeaderList());
		returnMap.put("displayListMap",dtoObject.getDisplayListMap());
		returnMap.put("differenceIndexList",dtoObject.getDifferenceIndexList());
		returnMap.put("primaryKeyList", dtoObject.getPrimaryKeyList());
		return returnMap;
	}
	
	public List<Map<String,String>> getResultsData(){
		List<VerupReportComparisonDto> resultDataList=new ArrayList<>();
		resultDataList =verupReportComparisonDao.getResultsData();
		List<Map<String,String>> returnList = new ArrayList<>();
		resultDataList.stream().forEach(action->{
			Map<String,String> returnMap = new HashMap<>();
			returnMap.put("apiJobId",action.getJobId());
			returnMap.put("apiPtnCode", action.getPtnCode());
			returnMap.put("apiJobName", action.getJobName());
			returnMap.put("executionTime", action.getExecutionTime());
			returnMap.put("executionResult", action.getResult());
			returnList.add(returnMap);
		});
		return returnList;
	}

	  public EnvironmentConfigurationVo addEnvironment(EnvironmentConfigurationVo environmentConfigurationVo) {
	        List<EnvironmentConfigurationEntity> environmentConfigurationEntityList = environmentRepository.findAll();
	        if (!environmentConfigurationEntityList.isEmpty()) {
	            environmentConfigurationEntityList.stream().forEach(entity -> {
	                if (entity.getEnvironmentType().name().equals(environmentConfigurationVo.getEnvironmentType().name())) {
	                    entity.setCurrentEnvironment(false);
	                    environmentRepository.save(entity);
	                }
	            });
	        }
	        Date date = new Date();
	        SimpleDateFormat formatter = new SimpleDateFormat(VerupReportComparisonConstants.DATE_FORMAT);
	        String createdDate = formatter.format(date);
	        EnvironmentConfigurationEntity configuration = EnvironmentConfigurationEntity.builder()
	                .name(environmentConfigurationVo.getName())
	                .environmentType(environmentConfigurationVo.getEnvironmentType())
	                .host(environmentConfigurationVo.getHost())
	                .currentEnvironment(true)
	                .port(environmentConfigurationVo.getPort())
	                .sid(environmentConfigurationVo.getSid())
	                .userName(environmentConfigurationVo.getUserName())
	                .password(environmentConfigurationVo.getPassword())
	                .createdDate(createdDate)
	                .createdUser(environmentConfigurationVo.getUserName())
	                .build();
	        if (!jdbcConnection.hostAvailabilityCheck(configuration)) {
	            return null;
	        }
	        environmentRepository.save(configuration);
	        return environmentConfigurationVo;
	    }

	    public EnvironmentConfigurationVo deleteEnvironment(String databaseId) {
	        Optional<EnvironmentConfigurationEntity> environmentConfigurationEntity = environmentRepository
	                .findById(databaseId);
	        environmentRepository.deleteById(databaseId);
	        List<EnvironmentConfigurationEntity> environmentEntityList = environmentRepository
	                .findByEnvironmentType(environmentConfigurationEntity.get().getEnvironmentType());
	        if (!environmentEntityList.isEmpty()) {
	            environmentEntityList.get(0).setCurrentEnvironment(true);
	            environmentRepository.save(environmentEntityList.get(0));
	        }
	        return EnvironmentConfigurationVo.builder()
	                .name(environmentConfigurationEntity.get().getName())
	                .build();
	    }

	    public EnvironmentConfigurationVo saveCurrentEnvironments(EnvironmentConfigurationVo environmentConfigurationVo) {
	        Map<String, Object> versionConnectionMap = new HashMap<String, Object>();
	        Map<String, String> objectMap = new HashMap<String, String>();
	        AtomicInteger testCheckCount = new AtomicInteger();
	        objectMap.put(verupReportComparisonConstants.ENUM_VERSION_36, environmentConfigurationVo.getVersionId_36());
	        objectMap.put(verupReportComparisonConstants.ENUM_VERSION_40, environmentConfigurationVo.getVersionId_40());
	        if (Objects.nonNull(objectMap)) {
	            objectMap.entrySet().stream().forEach(entity -> {
	                Optional<EnvironmentConfigurationEntity> environmentConfigurationEntity = environmentRepository
	                        .findById(entity.getValue());
	                if (environmentConfigurationEntity.isPresent()) {
	                    EnvironmentConfigurationEntity environmentConfiguration = environmentConfigurationEntity.get();
	                    if (jdbcConnection.hostAvailabilityCheck(environmentConfiguration)) {
	                        testCheckCount.incrementAndGet();
	                        verTypeEnum environmentType = verTypeEnum.valueOf(entity.getKey());
	                        List<EnvironmentConfigurationEntity> environmentConfigurationEntityList = environmentRepository
	                                .findByEnvironmentType(environmentType);
	                        if (!environmentConfigurationEntityList.isEmpty()) {
	                            environmentConfigurationEntityList.stream().forEach(action -> {
	                                action.setCurrentEnvironment(false);
	                                environmentRepository.save(action);
	                            });
	                        }
	                        environmentConfiguration.setCurrentEnvironment(true);
	                        environmentRepository.save(environmentConfiguration);
	                    }

	                }
	            });
	        }
	        isTestedConnection(versionConnectionMap, testCheckCount.get());
	        return EnvironmentConfigurationVo.builder()
	                .testChecker(
	                        Boolean.parseBoolean(String.valueOf(versionConnectionMap.get(verupReportComparisonConstants.TEST_CHECKER))))
	                .build();
	    }
	    
	    public EnvironmentConfigurationVo getAllEnvironments() {
	        Map<String, Object> versionConnectionMap = new HashMap<String, Object>();
	        List<EnvironmentConfigurationEntity> environmentList = environmentRepository.findAll();
	        AtomicInteger testCheckCount = new AtomicInteger();
	        environmentList.stream().filter(action -> action.isCurrentEnvironment()).forEach(entity -> {
	            checkEnvironments(entity, versionConnectionMap, testCheckCount);
	        });
	        isTestedConnection(versionConnectionMap, testCheckCount.get());
	        versionConnectionMap.put(verupReportComparisonConstants.ENV_LIST, environmentList);
	        return EnvironmentConfigurationVo.builder()
	                .environmentList(versionConnectionMap.get(verupReportComparisonConstants.ENV_LIST))
	                .testChecker(
	                        Boolean.parseBoolean(String.valueOf(versionConnectionMap.get(verupReportComparisonConstants.TEST_CHECKER))))
	                .version_36(Boolean.parseBoolean(String.valueOf(versionConnectionMap.get(verupReportComparisonConstants.VERSION_36))))
	                .version_40(Boolean.parseBoolean(String.valueOf(versionConnectionMap.get(verupReportComparisonConstants.VERSION_40))))
	                .build();
	    }
	    
	    public void checkEnvironments(EnvironmentConfigurationEntity environmentConfiguration,
	            Map<String, Object> versionConnectionMap, AtomicInteger testCheckCount) {
	        if (jdbcConnection.hostAvailabilityCheck(environmentConfiguration)) {
	            versionConnectionMap.put(environmentConfiguration.getEnvironmentType().name(), true);
	            testCheckCount.incrementAndGet();
	        } else {
	            versionConnectionMap.put(environmentConfiguration.getEnvironmentType().name(), false);
	        }
	    }
	    
	    private void isTestedConnection(Map<String, Object> versionConnectionMap, int testCheckCount) {
	        versionConnectionMap.put(verupReportComparisonConstants.TEST_CHECKER, true);
	        if (testCheckCount == 2) {
	            versionConnectionMap.put(verupReportComparisonConstants.TEST_CHECKER, false);
	        }
	    }
	    

}
