package org.intraweb.tools.ReportComparison.dao.dto;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Document(collection="report_data")
@Component
public class VerupReportComparisonDto {
	
	@Id
	private ObjectId id;
	
	private String jobId;
	
	private String ptnCode;
	
	private String jobName;
	
	private String executionTime;
	
	private String result;
	
	private List<Map<String,String>> firstDataMap;
	
	private List<Map<String,String>> secondDataMap;

	private List<String> firstHeaderList;
	
	private List<String> secondHeaderList;
	
	private Map<Integer,List<Integer>> downloadIndexMap;
	
	private List<Object> differenceIndexList;
	
	private Set<Object> displayListMap;
	
	private Object primaryKeyList;

}
