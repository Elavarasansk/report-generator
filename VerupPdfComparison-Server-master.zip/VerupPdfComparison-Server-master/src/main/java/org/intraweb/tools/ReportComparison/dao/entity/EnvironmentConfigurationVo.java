package org.intraweb.tools.ReportComparison.dao.entity;


import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity.verTypeEnum;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnvironmentConfigurationVo {
    private String id;
    private String name;
    private verTypeEnum environmentType;
    private String host;
    private String port;
    private String sid;
    private String userName;
    private String password;
    private String createdUser;
    private String createdDate;
    private String updatedUser;
    private String updatedDate;
    private boolean currentEnvironment;
    private boolean testChecker;
    private Object environmentList;
    private boolean version_36;
    private boolean version_40;
    private String versionId_36;
    private String versionId_40;

}
