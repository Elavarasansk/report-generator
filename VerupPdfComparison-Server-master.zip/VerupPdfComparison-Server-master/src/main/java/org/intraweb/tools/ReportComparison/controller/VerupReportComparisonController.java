package org.intraweb.tools.ReportComparison.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationEntity;
import org.intraweb.tools.ReportComparison.dao.entity.EnvironmentConfigurationVo;
import org.intraweb.tools.ReportComparison.dao.entity.GetMappingPojo;
import org.intraweb.tools.ReportComparison.service.VerupReportComparisonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@CrossOrigin
@RestController
public class VerupReportComparisonController {
	@Autowired
	VerupReportComparisonService verupReportComparisonService;
	
	@PostMapping("/reportGenerate")
	public void reportGenerate(@RequestBody GetMappingPojo getMappingPojo) throws InterruptedException, IOException {
		Map<String,Object> returnMap = new  HashMap<>();
		verupReportComparisonService.reportGenerate(getMappingPojo,returnMap);
	}

	@PostMapping("/displayParameters")
	public List<Map<String,String>> displayParameters(@RequestBody GetMappingPojo getMappingPojo) {
		return verupReportComparisonService.displayParameters(getMappingPojo.getDbVersionCompanyKey());
	}
	
	@PostMapping("/getData")
	public Map<String,Object> getData(@RequestBody GetMappingPojo getMappingPojo){

		return verupReportComparisonService.getDataOne(getMappingPojo);
	}
	
	@PostMapping("/downloadCsv")
	public void downloadCsv(@RequestBody GetMappingPojo getMappingPojo,HttpServletResponse response) throws IOException {
		verupReportComparisonService.downloadCsv(getMappingPojo,response);
	}
	
	@GetMapping("/getResultsData")
	public List<Map<String,String>> getResultsData(){
		return verupReportComparisonService.getResultsData();
	}
	
	@GetMapping("/getAllEnvironment")
    public EnvironmentConfigurationVo getAllEnvironment() {
        return verupReportComparisonService.getAllEnvironments();
    }

    @PostMapping("/addEnvironment")
    public EnvironmentConfigurationVo addEnvironment(
            @RequestBody EnvironmentConfigurationVo environmentConfigurationVo) {
        return verupReportComparisonService.addEnvironment(environmentConfigurationVo);
    }

    @DeleteMapping("/deleteEnvironment/{id}")
    public EnvironmentConfigurationVo deleteEnvironment(@PathVariable(value = "id") String databaseId) {
        return verupReportComparisonService.deleteEnvironment(databaseId);
    }

    @PostMapping("/saveCurrentEnvironments")
    public EnvironmentConfigurationVo saveCurrentEnvironments(
            @RequestBody EnvironmentConfigurationVo environmentConfigurationVo) {
        return verupReportComparisonService.saveCurrentEnvironments(environmentConfigurationVo);
    }

}
