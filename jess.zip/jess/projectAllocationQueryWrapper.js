'use strict';
const { models } = require('../../server/server');
const FileUtility = require('../utils/fileUtility');
const GeneralService = require('../services/generalService');
const NativeQueryExecutor = require('./nativeQueryExecutor');
const { filter } = require('compression');

const { PROJECT_ALLOCATION_REPORT, PROJECT_ALLOCATION_HIERARCHY, PROJECT_ALLOCATION_REPORT_COUNT, PROJ_ALLOC_LAZY_ROLEBY_USER,
    PROJ_ALLOC_MYTEAM_REPORT, PROJ_ALLOC_MYTEAM_REPORT_COUNT, PROJ_ALLOC_EMP_AND_REPORT} = require('../constants/recursiveCTEQuery').QUERY;
const { ORG_SELECT_COLUMNS, PROJECT_ALLOC_DYNAMIC_VALUE, COLUMN_FILTER_KEY } = require('../constants/recursiveCTEQuery').VALUE;
const { PROJ_ORG_DETAILS, HR_PROXY_APPLY_USER_LIST, HR_PROXY_APPLY_USER_LIST_COUNT } = require('../constants/query_constants');

module.exports = class ProjectAllocationQueryWrapper extends NativeQueryExecutor {

    constructor(props) {
        super(props);
        this.fu = new FileUtility();
        this.gs = new GeneralService();
    }

    /* In query role join can be removed. It gives un-necessary load*/
    formDescendingHierarchyQuery = (selectColumns, reportToId, onDemandJoin, subsidaryConditions) => {
        const { REPORT_TO, CTE_SELECT_COLUMNS, CTE_SUBSIDARY_CONDITION, ON_DEMAND_JOIN } = PROJECT_ALLOC_DYNAMIC_VALUE;
        const contructedQuery = PROJECT_ALLOCATION_REPORT
            .replace(REPORT_TO, reportToId)
            .replace(CTE_SELECT_COLUMNS, selectColumns)
            .replace(ON_DEMAND_JOIN, onDemandJoin)
            .replace(CTE_SUBSIDARY_CONDITION, subsidaryConditions)
            .replace(/\n/g, '');
        return contructedQuery;
    }

    formDescendingHierarchyCountQuery = (reportToId, onDemandJoin, subsidaryConditions) => {
        const { REPORT_TO, CTE_SUBSIDARY_CONDITION, ON_DEMAND_JOIN } = PROJECT_ALLOC_DYNAMIC_VALUE;
        const contructedQuery = PROJECT_ALLOCATION_REPORT_COUNT
            .replace(REPORT_TO, reportToId)
            .replace(ON_DEMAND_JOIN, onDemandJoin)
            .replace(CTE_SUBSIDARY_CONDITION, subsidaryConditions)
            .replace(/\n/g, '');
        return contructedQuery;
    }

    prepareFilterConditions = (whereQueryArray, filter) => {
        filter = filter ? filter : {};
        if (!whereQueryArray || !whereQueryArray.length) {
            whereQueryArray = [];
        }

        const { projectId, roleId, cityId } = filter;
        if (projectId) {
            whereQueryArray.push(this.inFilter(COLUMN_FILTER_KEY.projectId, projectId));
        }
        if (roleId) {
            whereQueryArray.push(this.equalsNumFilter(COLUMN_FILTER_KEY.roleId, roleId));
        }
        if (cityId) {
            whereQueryArray.push(this.equalsNumFilter(COLUMN_FILTER_KEY.cityId, cityId));
        }

        const { userId, empId, email, username, mixedUserSearch } = filter;
        if (userId) {
            whereQueryArray.push(this.equalsStringFilter(COLUMN_FILTER_KEY.userId, userId));
        }
        if (empId) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.empId, empId));
        }
        if (email) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.email, email));
        }
        if (username) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.username, username));
        }
        if (mixedUserSearch) {
            const orCond = [
                this.containsFilter(COLUMN_FILTER_KEY.empId, mixedUserSearch),
                this.containsFilter(COLUMN_FILTER_KEY.probationId, mixedUserSearch),
                this.containsFilter(COLUMN_FILTER_KEY.email, mixedUserSearch),
                this.containsFilter(COLUMN_FILTER_KEY.username, mixedUserSearch),
                this.containsFilter(COLUMN_FILTER_KEY.firstName, mixedUserSearch),
            ];
            whereQueryArray.push(` ( ${orCond.join(' or ')} ) `);
        }

        const { active, current } = filter;
        if (typeof active !== "undefined") {
            whereQueryArray.push(this.equalsNumFilter(COLUMN_FILTER_KEY.active, !!active));

            if (!!active && typeof current !== "undefined") {
                whereQueryArray.push(this.equalsNumFilter(COLUMN_FILTER_KEY.current, !!current));
            }
        }

        const { reportUserId, reportEmpId, reportEmail, reportUsername, reportFirstName } = filter;
        if (reportUserId) {
            whereQueryArray.push(this.equalsStringFilter(COLUMN_FILTER_KEY.reportUserId, reportUserId));
        }
        if (reportEmpId) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.reportEmpId, reportEmpId));
        }
        if (reportEmail) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.reportEmail, reportEmail));
        }
        if (reportUsername) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.reportUsername, reportUsername));
        }
        if (reportFirstName) {
            whereQueryArray.push(this.containsFilter(COLUMN_FILTER_KEY.reportFirstName, reportFirstName));
        }

        /*RCL settings remove after first-release*/
        // const { spentOn } = filter;
        // if (spentOn) {
        //     whereQueryArray.push(this.equalsDateFilter(COLUMN_FILTER_KEY.spentOn, spentOn));
        // }
        /*RCL settings remove after first-release*/

        return (whereQueryArray.length > 0) ? ` where ${whereQueryArray.join(" and ")} ` : "";
    }


    getMyTeamDescendingHierarchy = async (reportToMe, paging, filter) => {
        const whereQueryArray = [];
        const selectColumns = `${ORG_SELECT_COLUMNS.DEFAULT_COLUMN}, ${ORG_SELECT_COLUMNS.PROJECT_EMPLOYEE}, ${ORG_SELECT_COLUMNS.PROJECT_REPORT}`;
        let subsidaryConditions = `${this.prepareFilterConditions(whereQueryArray, filter)}`;

        if (paging) {
            subsidaryConditions += ` limit ${paging.size} offset ${paging.num * paging.size} `;
        }
        const query = this.formDescendingHierarchyQuery(selectColumns, reportToMe, "", subsidaryConditions);
        return await this.executeNativeSQL(query);
    }

    getMyTeamDescHierarchyForNestedLink = async (reportToMe, paging, filter) => {
        const whereQueryArray = [];
        const selectColumns = `employeeId`;
        let subsidaryConditions = ` ${this.prepareFilterConditions(whereQueryArray, filter)} `;

        if (paging) {
            subsidaryConditions += ` limit ${paging.size} offset ${paging.num * paging.size} `;
        }
        const query = this.formDescendingHierarchyQuery(selectColumns, reportToMe, subsidaryConditions);
        return await this.executeNativeSQL(query);
    }

    getMyTeamDescHierarchyCountOtherTables = async (reportToMe, joinConditions, whereQueryArray, projAllocfilter) => {
        const subsidaryConditions = `${this.prepareFilterConditions(whereQueryArray, projAllocfilter)}`;
        const query = this.formDescendingHierarchyCountQuery(reportToMe, joinConditions, subsidaryConditions);

        const { totalCount } = (await this.executeNativeSQL(query))[0];
        return totalCount;
    }

    getMyTeamDescHierarchyOtherTables = async (selectColumns, reportToMe, joinConditions, whereQueryArray, projAllocfilter, orderBy, paging) => {
        let subsidaryConditions = `${this.prepareFilterConditions(whereQueryArray, projAllocfilter)}`;

        if (orderBy) {
            subsidaryConditions += ` order by ${orderBy} `;
        }
        if (paging) {
            subsidaryConditions += ` limit ${paging.size} offset ${paging.num * paging.size} `;
        }
        const query = this.formDescendingHierarchyQuery(selectColumns, reportToMe, joinConditions, subsidaryConditions);
        return await this.executeNativeSQL(query);
    }

    getMyRoleBasedHierarchy = async (reportToId) => {
        const { REPORT_TO } = PROJECT_ALLOC_DYNAMIC_VALUE;
        const contructedQuery = PROJECT_ALLOCATION_HIERARCHY
            .replace(REPORT_TO, reportToId)
            .replace(/\n/g, '');
        return await this.executeNativeSQL(contructedQuery);
    }


    getLazyUserHierarchyByRoles = async (reportToId, projAllocfilter, paging) => {
        const { REPORT_TO, CTE_SUBSIDARY_CONDITION } = PROJECT_ALLOC_DYNAMIC_VALUE;
        let subsidaryConditions = `${this.prepareFilterConditions([], projAllocfilter)}`;

        if (paging) {
            subsidaryConditions += ` limit ${paging.size} offset ${paging.num * paging.size} `;
        }
        const contructedQuery = PROJ_ALLOC_LAZY_ROLEBY_USER
            .replace(REPORT_TO, reportToId)
            .replace(CTE_SUBSIDARY_CONDITION, subsidaryConditions)
            .replace(/\n/g, '');

        return await this.executeNativeSQL(contructedQuery);
    }

    getProjOrgDetailsForBulkUploadTemplate = async () => {
        return await this.executeNativeSQL(PROJ_ORG_DETAILS);
    }


    getMyTeamEmpAndReportTo = async (reportToMe, projAllocfilter) => {
        let subsidaryConditions = `${this.prepareFilterConditions([], projAllocfilter)}`;
        const query = formEmpReportToHierarchyQuery(reportToMe, subsidaryConditions);

        function formEmpReportToHierarchyQuery(reportToId, subsidaryConditions) {
            const { REPORT_TO, CTE_SUBSIDARY_CONDITION } = PROJECT_ALLOC_DYNAMIC_VALUE;
            const contructedQuery = PROJ_ALLOC_EMP_AND_REPORT
                .replace(REPORT_TO, reportToId)
                .replace(CTE_SUBSIDARY_CONDITION, subsidaryConditions)
                .replace(/\n/g, '');
            return contructedQuery;
        }
        const result = await this.executeNativeSQL(query);
        return JSON.parse(JSON.stringify(result));
    }

    getHrProxyApplyableList = async (userId, paging, filter) => {
      let subsidaryConditions = '';
      if(userId){
        subsidaryConditions += ' and project_allocation.employee_id != '+userId;
      }
      if(filter){
        if(filter.mixedUserSearch){
          const { mixedUserSearch } = filter;
          const orCond = [
            this.containsFilter("employee.empId", mixedUserSearch),
            this.containsFilter("employee.probationId", mixedUserSearch),
            this.containsFilter("employee.email", mixedUserSearch),
            this.containsFilter("employee.username", mixedUserSearch),
            this.containsFilter("employee.firstName", mixedUserSearch)
          ]
          subsidaryConditions += " and ( "+ orCond.join(' or ')+" )"
        }
      }
      if (paging) {
          subsidaryConditions += ` limit ${paging.size} offset ${paging.num * paging.size} `;
      }
      const query = this.formHrProxyApplyableListQuery(subsidaryConditions);
      return await this.executeNativeSQL(query);
  }

      /* In query role join can be removed. It gives un-necessary load*/
  formHrProxyApplyableListQuery = (subsidaryConditions) => {
        const contructedQuery = HR_PROXY_APPLY_USER_LIST + subsidaryConditions
        return contructedQuery;
    }
  getHrProxyApplyableListCount = async (userId,filter) => {
      let subsidaryConditions = '';
      if(userId){
        subsidaryConditions += ' and project_allocation.employee_id != '+userId;
      }
      if(filter){
        if(filter.mixedUserSearch){
          const { mixedUserSearch } = filter;
          const orCond = [
            this.containsFilter("employee.empId", mixedUserSearch),
            this.containsFilter("employee.probationId", mixedUserSearch),
            this.containsFilter("employee.email", mixedUserSearch),
            this.containsFilter("employee.username", mixedUserSearch),
            this.containsFilter("employee.firstName", mixedUserSearch)
          ]
          subsidaryConditions += " and ( "+ orCond.join(' or ')+" )"
        }
      }
      const query = this.formHrProxyApplyableListQuerCount(subsidaryConditions);
      console.log(query);
      const { totalCount } = (await this.executeNativeSQL(query))[0];
      console.log(totalCount)
      return totalCount;
  }
  formHrProxyApplyableListQuerCount = (subsidaryConditions) => {
    const contructedQuery = HR_PROXY_APPLY_USER_LIST_COUNT + subsidaryConditions
    return contructedQuery;
  }
}
