
const REDMINE_LOG_REPORT_GROUP_VIEW_QUERY = "SELECT R1.id, R1.kairo_user_id,N1.empId , R1.spentOn ,N1.isProbation,N1.probationPrefix,N1.probationId,loggedHours as spentHours , N1.firstName AS firstName ,  N2.firstName AS reportTo , N1.email , P1.name as projectName,"
    + " R1.kairo_user_project_id , R1.month"
    + " FROM redmine_consolidated_logdetails AS R1 "
    + " INNER JOIN kairo_user AS N1 ON R1.kairo_user_id = N1.id "
    + " INNER JOIN project_allocation ON R1.kairo_user_id = project_allocation.employee_id "
    + " LEFT JOIN kairo_user AS N2 ON project_allocation.report_to = N2.id "
    + " INNER JOIN project AS P1 ON R1.kairo_user_project_id = P1.id "
    + " $HAVING ORDER BY spentOn DESC"

const REDMINE_LOG_REPORT_SINGLE_VIEW_QUERY = "SELECT spentOn,hours as spentHours ,kairo_user_id , N1.firstName ,  N2.firstName AS reportTo ,project_allocation.report_to  , activityName , issueId  ,month , P1.name as projectName , kairo_user_project_id FROM redmine_log_report"
    + " INNER JOIN kairo_user AS N1 ON redmine_log_report.kairo_user_id = N1.id"
    + " INNER JOIN project_allocation ON redmine_log_report.kairo_user_id  = project_allocation.employee_id"
    + " LEFT JOIN kairo_user AS N2 ON project_allocation.report_to = N2.id"
    + " INNER JOIN project AS P1 ON redmine_log_report.kairo_user_project_id = P1.id "
    + " $WHERE ORDER BY spentOn DESC"

const REDMINE_LOG_REPORT_COUNT = "SELECT COUNT(*) as totalCount from ( $SELECT ) AS REDMINE_LOG_REPORT_COUNT ";

const MY_TEAM_LOGTIME = " SELECT employee_id  , K1.firstName ,K1.empId , K1.isProbation, K1.probationId , K1.probationPrefix, K1.email,P1.name as projectName , activityName , hours as spentHours , spentOn , report_to FROM project_allocation"
    + " INNER JOIN kairo_user AS K1 ON project_allocation.employee_id = K1.id"
    + " INNER JOIN redmine_log_report ON project_allocation.employee_id  = redmine_log_report.kairo_user_id"
    + " INNER JOIN project AS P1 ON redmine_log_report.kairo_user_project_id = P1.id "
    + " $WHERE"

const MY_TEAM_LOGTIME_COUNT = " SELECT count(*) as totalCount FROM project_allocation"
    + " INNER JOIN kairo_user"
    + " ON project_allocation.employee_id = kairo_user.id"
    + " INNER JOIN redmine_log_report"
    + " ON project_allocation.employee_id  = redmine_log_report.kairo_user_id"
    + " WHERE report_to = ${REPORT_TO}"

const ORGANISATION_ATTENDANCE_REPORT = "SELECT R1.id, R1.kairo_user_id,N1.empId , R1.spentOn ,N1.isProbation,N1.probationPrefix,N1.probationId,loggedHours as spentHours , N1.firstName AS firstName , N1.username ,  N2.firstName AS reportTo , N1.email ,N1.active, P1.name as projectName,"
    + " R1.kairo_user_project_id , OD1.organisation_id , P1.organisation_division_id , R1.month, N3.firstName as managerName,O1.displayName as organisationDisplayName ,O1.name as organisationName , OD1.name as organisationDivisionName , C1.name as location "
    + " FROM redmine_consolidated_logdetails AS R1 "
    + " INNER JOIN kairo_user AS N1 ON R1.kairo_user_id = N1.id "
    + " INNER JOIN project_allocation ON R1.project_allocation_id  = project_allocation.id "
    + " INNER JOIN kairo_user AS N2 ON project_allocation.report_to = N2.id "
    + " INNER JOIN kairo_user AS N3 ON project_allocation.manager_id = N3.id "
    + " INNER JOIN project AS P1 ON R1.kairo_user_project_id = P1.id "
    + " INNER JOIN organisation_division AS OD1 ON P1.organisation_division_id = OD1.id "
    + " INNER JOIN organisation AS O1 ON OD1.organisation_id = O1.id "
    + " INNER JOIN city AS C1 ON project_allocation.city_id  = C1.id "
    + " $HAVING ORDER BY spentOn DESC"

const ORGANISATION_ATTENDANCE_GROUP_VIEW_REPORT = "  SELECT  R.kairo_user_id,N1.empId ,N1.isProbation,N1.probationPrefix,N1.probationId, spentHours , N1.firstName AS firstName ,N1.username  , N1.email ,N1.active,P1.name as projectName, N2.firstName AS reportTo,"
    + " R.kairo_user_project_id , OD1.organisation_id , P1.organisation_division_id , R.month, N3.firstName as managerName,O1.displayName as organisationDisplayName ,O1.name as organisationName , OD1.name as organisationDivisionName , C1.name as location "
    + " FROM (  SELECT kairo_user_id, sum(loggedHours) as spentHours,project_allocation_id,kairo_user_project_id,month FROM redmine_consolidated_logdetails "
    + " WHERE spentOn >= '$STARTDATE' AND spentOn <= '$ENDDATE' GROUP BY kairo_user_id,kairo_user_project_id) AS R "
    + " INNER JOIN kairo_user AS N1 ON R.kairo_user_id = N1.id "
    + " INNER JOIN project_allocation ON R.project_allocation_id  = project_allocation.id "
    + " INNER JOIN kairo_user AS N2 ON project_allocation.report_to = N2.id "
    + " INNER JOIN kairo_user AS N3 ON project_allocation.manager_id = N3.id "
    + " INNER JOIN project AS P1 ON R.kairo_user_project_id = P1.id "
    + " INNER JOIN organisation_division AS OD1 ON P1.organisation_division_id = OD1.id "
    + " INNER JOIN organisation AS O1 ON OD1.organisation_id = O1.id "
    + " INNER JOIN city AS C1 ON project_allocation.city_id  = C1.id "
    + " $HAVING ORDER BY kairo_user_id DESC";

const ORGANISATION_ATTENDANCE_REPORT_COUNT = "SELECT COUNT(*) as totalCount , COUNT(DISTINCT kairo_user_id) as employeeCount , SUM(spentHours) as totalSpentHours from ( $SELECT ) AS ORGANISATION_ATTENDANCE_REPORT ";


const CONFLICT_LEAVE_REQUEST_QUERY = "SELECT L1.id,L1.conflictDate, L1.status, L1.applicant_id, L1.leave_request_id, K1.empId ,"
    + " K1.probationId ,K1.isProbation , K1.firstName , K1.probationPrefix , L2.fromDate, L2.toDate, L2.type, L1.noonType "
    + " FROM leave_logtime_conflict AS L1 "
    + " INNER JOIN leave_request AS L2 ON L1.leave_request_id = L2.id "
    + " INNER JOIN leave_request_fragments AS L3 ON L1.leave_request_fragment_id = L3.id "
    + " INNER JOIN kairo_user AS K1 ON L1.applicant_id = K1.id "
    + " $HAVING ORDER BY conflictDate DESC ";

const CONFLICT_LEAVE_REQUEST_QUERY_COUNT = "SELECT COUNT(*) as totalCount from ( $SELECT ) AS CONFLICT_LEAVE_REQUEST_QUERY ";


const CONFLICT_LEAVE_REQUEST_APPROVAL_QUERY = "SELECT L1.id,L3.actionStatus, L3.current_approver_id , L3.applicant_id ,L3.leave_logtime_conflict_id , L1.conflictDate, L1.status, L1.leave_request_id, K1.empId ,"
    + " K1.probationId , K1.isProbation , K1.firstName , K1.probationPrefix ,K1.username,K1.email, L2.fromDate, L2.toDate, L2.type, L1.noonType "
    + " FROM leave_logtime_conflict AS L1 "
    + " INNER JOIN leave_request AS L2 ON L1.leave_request_id = L2.id "
    + " INNER JOIN leave_logtime_conflict_approval AS L3 ON L1.id = L3.leave_logtime_conflict_id "
    + " INNER JOIN leave_request_fragments AS L4 ON L1.leave_request_fragment_id = L4.id "
    + " INNER JOIN kairo_user AS K1 ON L1.applicant_id = K1.id "
    + " $HAVING ORDER BY conflictDate DESC ";


const ORGANISATION_SPECIFIC_ATTENDANCE_REPORT = " SELECT  R1.kairo_user_id,N1.empId  ,N1.isProbation,N1.probationPrefix,N1.probationId,sum(loggedHours) as spentHours , N1.email , N1.firstName ,  OD1.organisation_id "
    + " FROM redmine_consolidated_logdetails AS R1 "
    + " INNER JOIN kairo_user AS N1 ON R1.kairo_user_id = N1.id "
    + " INNER JOIN project AS P1 ON R1.kairo_user_project_id = P1.id "
    + " INNER JOIN organisation_division AS OD1 ON P1.organisation_division_id = OD1.id "
    + " INNER JOIN organisation AS O1 ON OD1.organisation_id = O1.id "
    + " $WHERE "
    + " GROUP BY kairo_user_id , organisation_id  "
    + " ORDER BY kairo_user_id ASC ";


const ORGANISATION_DIVISION_SPECIFIC_ATTENDANCE_REPORT = " SELECT  R1.kairo_user_id,N1.empId  ,N1.isProbation,N1.probationPrefix,N1.probationId,sum(loggedHours) as spentHours , N1.email , N1.firstName , P1.organisation_division_id "
    + " FROM redmine_consolidated_logdetails AS R1 "
    + " INNER JOIN kairo_user AS N1 ON R1.kairo_user_id = N1.id "
    + " INNER JOIN project AS P1 ON R1.kairo_user_project_id = P1.id "
    + " INNER JOIN organisation_division AS OD1 ON P1.organisation_division_id = OD1.id "
    + " INNER JOIN organisation AS O1 ON OD1.organisation_id = O1.id "
    + " $WHERE "
    + " GROUP BY kairo_user_id , organisation_division_id "
    + " ORDER BY kairo_user_id ASC ";


const PROJECT_SPECIFIC_ATTENDANCE_REPORT = " SELECT  R1.kairo_user_id,N1.empId  ,N1.isProbation,N1.probationPrefix,N1.probationId,sum(loggedHours) as spentHours , N1.email , R1.kairo_user_project_id ,  N1.firstName "
    + " FROM redmine_consolidated_logdetails AS R1 "
    + " INNER JOIN kairo_user AS N1 ON R1.kairo_user_id = N1.id "
    + " INNER JOIN project AS P1 ON R1.kairo_user_project_id = P1.id "
    + " $WHERE "
    + " GROUP BY kairo_user_id , kairo_user_project_id  "
    + " ORDER BY kairo_user_id ASC ";

const PROJ_ORG_DETAILS = "SELECT OG.displayName AS company, OD.name AS division, PR.name AS project"
    +  " FROM project AS PR INNER JOIN organisation_division AS OD ON OD.id = PR.organisation_division_id"
    +  " INNER JOIN organisation AS OG ON OG.id = OD.organisation_id";

const ORGANISATION_ATTENDANCE_NOTLOGGED_REPORT = "SELECT R1.id, R1.kairo_user_id,N1.empId , R1.flawDate ,N1.isProbation,N1.probationPrefix,N1.probationId,R1.insufficientHours,R1.isLeaveApplied, N1.firstName AS firstName , N1.username ,  N2.firstName AS reportTo , N1.email ,N1.active, P1.name as projectName,"
    + " R1.kairo_user_project_id , OD1.organisation_id , P1.organisation_division_id , R1.month, N3.firstName as managerName,O1.displayName as organisationDisplayName ,O1.name as organisationName , OD1.name as organisationDivisionName , C1.name as location "
    + " FROM redmine_notlogged AS R1 "
    + " INNER JOIN kairo_user AS N1 ON R1.kairo_user_id = N1.id "
    + " INNER JOIN project_allocation ON R1.project_allocation_id  = project_allocation.id "
    + " INNER JOIN kairo_user AS N2 ON project_allocation.report_to = N2.id "
    + " INNER JOIN kairo_user AS N3 ON project_allocation.manager_id = N3.id "
    + " INNER JOIN project AS P1 ON R1.kairo_user_project_id = P1.id "
    + " INNER JOIN organisation_division AS OD1 ON P1.organisation_division_id = OD1.id "
    + " INNER JOIN organisation AS O1 ON OD1.organisation_id = O1.id "
    + " INNER JOIN city AS C1 ON project_allocation.city_id  = C1.id "
    + " $HAVING ORDER BY flawDate DESC"

    const ORGANISATION_ATTENDANCE_NOTLOGGED_REPORT_COUNT = "SELECT COUNT(*) as totalCount , COUNT(DISTINCT kairo_user_id) as employeeCount , SUM(insufficientHours) as totalInsufficientHours from ( $SELECT ) AS ORGANISATION_ATTENDANCE_NOTLOGGED_REPORT ";

    const LEAVE_ALLOTMENT_HR_APPROVAL_LEAVE_TYPE = "SELECT leaveType FROM leave_allotment_settings WHERE isHrApprovalRequired = 1 GROUP BY leaveType ";

    const HR_PROXY_APPLY_USER_LIST = `SELECT project_allocation.id,project_id, employee_id as userId, report_to, manager_id, role_id, city_id, current, support, shift_id,
      employee.email as email, employee.empId as empId, employee.firstName as firstName, employee.probationId as probationId, employee.probationPrefix as probationPrefix,
      employee.username as username, city.name as cityName,
      reportTO.id as reportUserId, reportTO.firstName as reportFirstName, reportTO.email as reportEmail, reportTO.empId as reportEmpId, reportTO.probationId as reportProbationId, reportTO.probationPrefix as reportProbationPrefix, reportTO.username as reportUsername,
      kairo_role.name as roleName
      from project_allocation as project_allocation
      LEFT JOIN  kairo_user as reportTO on reportTO.id = project_allocation.report_to
      LEFT JOIN  kairo_user as employee on employee.id = project_allocation.employee_id
      INNER JOIN kairo_role as kairo_role  on kairo_role.id = project_allocation.role_id
      INNER JOIN city as city on city.id = project_allocation.city_id
      where project_allocation.current = 1`
    const HR_PROXY_APPLY_USER_LIST_COUNT = `SELECT COUNT(*) as totalCount from project_allocation as project_allocation
      LEFT JOIN  kairo_user as reportTO on reportTO.id = project_allocation.report_to
      LEFT JOIN  kairo_user as employee on employee.id = project_allocation.employee_id
      INNER JOIN kairo_role as kairo_role  on kairo_role.id = project_allocation.role_id
      INNER JOIN city as city on city.id = project_allocation.city_id
      where project_allocation.current = 1`
module.exports = {
    REDMINE_LOG_REPORT_COUNT,
    MY_TEAM_LOGTIME,
    MY_TEAM_LOGTIME_COUNT,
    REDMINE_LOG_REPORT_GROUP_VIEW_QUERY,
    REDMINE_LOG_REPORT_SINGLE_VIEW_QUERY,
    ORGANISATION_ATTENDANCE_REPORT,
    ORGANISATION_ATTENDANCE_REPORT_COUNT,
    ORGANISATION_ATTENDANCE_GROUP_VIEW_REPORT,
    CONFLICT_LEAVE_REQUEST_QUERY,
    CONFLICT_LEAVE_REQUEST_QUERY_COUNT,
    CONFLICT_LEAVE_REQUEST_APPROVAL_QUERY,
    ORGANISATION_SPECIFIC_ATTENDANCE_REPORT,
    ORGANISATION_DIVISION_SPECIFIC_ATTENDANCE_REPORT,
    PROJECT_SPECIFIC_ATTENDANCE_REPORT,
    PROJ_ORG_DETAILS,
    ORGANISATION_ATTENDANCE_NOTLOGGED_REPORT,
    ORGANISATION_ATTENDANCE_NOTLOGGED_REPORT_COUNT,
    LEAVE_ALLOTMENT_HR_APPROVAL_LEAVE_TYPE,
    HR_PROXY_APPLY_USER_LIST,
    HR_PROXY_APPLY_USER_LIST_COUNT
}
