'use strict';
const moment = require('moment');
const fs = require('fs');
const path = require('path');
const Excel = require('exceljs');
const multiparty = require('multiparty');
const { models } = require('../../server/server');
const xlsxHandler = require('read-excel-file/node');
const DateUtility = require('../utils/dateUtils');
const FileUtility = require('../utils/fileUtility');
const GeneralUtility = require('../utils/generalUtility');
const GeneralService = require('../services/generalService');

const sheetById = path.join(__dirname, '../../resources/PROJECT_ALLOCATION_ID.xlsx');
const sheetByName = path.join(__dirname, '../../resources/PROJECT_ALLOCATION_NAME.xlsx');
const resourceAllocTemplate = path.join(__dirname, '../../resources/Emp_project_alloc_template.xlsx');

const ProjectAllocationQueryWrapper = require('../nativeSqlWrapper/projectAllocationQueryWrapper');
const { SQL_DATE_FORMAT } = require('../metadata/holidayMeta.json');

module.exports = class ProjectAllocationService {

    constructor() {
        const { ProjectAllocation, RoleMapping, KairoRole } = models;
        this.du = new DateUtility();
        this.fu = new FileUtility();
        this.gu = new GeneralUtility();
        this.gs = new GeneralService();
        this.ProjectAllocation = ProjectAllocation;
        this.RoleMapping = RoleMapping;
        this.KairoRole = KairoRole;
        this.paqw = new ProjectAllocationQueryWrapper();
    }

    downloadTemplate = async (type, res) => {
        const filePathToDownload = (type === 'id') ? sheetById : sheetByName;
        const files = fs.createReadStream(filePathToDownload);
        const pathSplit = filePathToDownload.split("\\");
        res.writeHead(200, { 'Content-disposition': `attachment; filename=${pathSplit[pathSplit.length - 1]}` });
        files.pipe(res);
    }

    async promisifyUpload(req) {
        return new Promise((resolve, reject) => {
            const form = new multiparty.Form();
            form.parse(req, function (err, fields, files) {
                if (err) {
                    throw new Error('Error is uploaded file');
                }
                return resolve([fields, files]);
            });
        });
    }

    projectAllocationFromDoc = async (req, isById) => {

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const { KairoUser, KairoRole, Project, ProjectAllocation } = models;
        const userIdList = [], roleIdList = [], projectIdList = [];
        const mailIdMapping = [], roleIdMapping = [], projectIdMapping = [];

        const userList = await KairoUser.find({ fields: ["email", "id"] });
        userList.forEach(e => {
            userIdList.push(e.id);
            mailIdMapping[e.email] = e.id;
        });

        const roleList = await KairoRole.find({ fields: ["name", "id"] });
        roleList.forEach(e => {
            roleIdList.push(e.id);
            roleIdMapping[e.name] = e.id;
        });

        const projectList = await Project.find({ fields: ["name", "id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
            projectIdMapping[e.name] = e.id;
        });

        //Validation and bulk insert to project allocation table.
        let schema = {};
        const metaData = { userIdList, roleIdList, projectIdList, mailIdMapping, roleIdMapping, projectIdMapping };
        if (isById) {
            schema = await this.batchInsertById(metaData);
        } else {
            schema = await this.batchInsertByName(metaData);
        }

        const { rows, errors } = await xlsxHandler(fileInfo.path, { schema });
        if (errors.length > 0) {
            console.error('Project Allocation Upload sheet error', errors);
        }
        if (rows.length === 0) {
            throw new Error(`You have uploaded empty sheet - ${originalFilename}`);
        }
        try {
            return await ProjectAllocation.create(rows);
        } catch (err) {
            console.log(err);
        }
    }

    batchInsertById = async (metaData) => {
        const { userIdList, roleIdList, projectIdList, cityIdList } = metaData;
        const schema = {
            project_id: {
                prop: 'project_id',
                required: true,
                type: Number,
                parse(cellData) {
                    const value = parseInt(cellData);
                    const checkExists = projectIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Project Doesn\'t exists');
                    }
                    return value
                }
            },
            employee_id: {
                prop: 'employee_id',
                required: true,
                type: Number,
                parse(cellData) {
                    const value = cellData;
                    const checkExists = userIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Employee Doesn\'t exists');
                    }
                    return value
                }
            },
            role_id: {
                prop: 'role_id',
                required: true,
                type: Number,
                parse(cellData) {
                    const value = parseInt(cellData);
                    const checkExists = roleIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Role Doesn\'t exists');
                    }
                    return value
                }
            },
            manager_id: {
                prop: 'manager_id',
                type: Number,
                parse(cellData) {
                    if (!cellData) {
                        return cellData;
                    }
                    const value = parseInt(cellData);
                    const checkExists = userIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Manager Doesn\'t exists');
                    }
                    return value
                }
            },
            report_to: {
                prop: 'report_to',
                type: Number,
                parse(cellData) {
                    if (!cellData) {
                        return cellData;
                    }
                    const value = parseInt(cellData);
                    const checkExists = userIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('Report to Doesn\'t exists');
                    }
                    return value
                }
            },
            city_id: {
                prop: 'city_id',
                type: Number,
                parse(cellData) {
                    const value = parseInt(cellData);
                    const checkExists = cityIdList.includes(value);
                    if (!checkExists) {
                        throw new Error('City Doesn\'t exists');
                    }
                    return value
                }
            },
            department: {
                prop: 'department',
                type: String
            },
            active: {
                prop: 'active',
                parse(value) {
                    switch (value) {
                        case 1:
                        case true:
                        case 'True':
                        case 'true':
                            return true;

                        default:
                            return 0;
                    }
                }
            },
            joiningDate: {
                prop: 'joiningDate',
                type: Date
            },
            relievingDate: {
                prop: 'relievingDate',
                type: Date
            }
        }
        return schema;
    }


    batchInsertByName = async (metaData) => {
        const { mailIdMapping, roleIdMapping, projectIdMapping } = metaData;
        const schema = {
            project_name: {
                prop: 'project_id',
                required: true,
                type: Number,
                parse(value) {
                    const id = projectIdMapping[value];
                    if (!id) {
                        throw new Error('Project Doesn\'t exists')
                    }
                    return id;
                }
            },
            employee_email: {
                prop: 'employee_id',
                required: true,
                type: Number,
                parse(value) {
                    const id = mailIdMapping[value];
                    if (!id) {
                        throw new Error('Employee Doesn\'t exists')
                    }
                    return id;
                }
            },
            role_type: {
                prop: 'role_id',
                required: true,
                type: Number,
                parse(value) {
                    const id = roleIdMapping[value];
                    if (!id) {
                        throw new Error('Role Doesn\'t exists')
                    }
                    return id;
                }
            },
            manager_email: {
                prop: 'manager_id',
                required: true,
                type: Number,
                parse(value) {
                    if (!value) {
                        return value;
                    }
                    const id = mailIdMapping[value];
                    if (!id) {
                        throw new Error('Manager Doesn\'t exists')
                    }
                    return id;
                }
            },
            report_to_email: {
                prop: 'report_to',
                required: true,
                type: Number,
                parse(value) {
                    if (!value) {
                        return value;
                    }
                    const id = mailIdMapping[value];
                    if (!id) {
                        throw new Error('Report to Doesn\'t exists')
                    }
                    return id;
                }
            },
            active: {
                prop: 'active',
                parse(value) {
                    switch (value) {
                        case 1:
                        case true:
                        case 'True':
                        case 'true':
                            return true;

                        default:
                            return 0;
                    }
                }
            },
            joiningDate: {
                prop: 'joiningDate',
                type: Date,
            },
            relievingDate: {
                prop: 'relievingDate',
                type: Date,
            }
        }
        return schema;
    }

    /* Warning! Use this API only for inserting new records */
    projectAllocBulkInsert = async (req) => {

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }
        return await this.projectAllocBulkInsertFromFile(fileInfo.path);
    }

    projectAllocBulkInsertFromFile = async (path) => {
        try {
            const { Project, OrganisationDivision } = models;
            const finalResource = await xlsxHandler(path, { sheet: 1 });

            const projectObj = this.getProjectList(finalResource);
            const projects = [];
            const orgList = {};

            const orgDivision = await OrganisationDivision.find({ fields: ["name", "id"] });
            orgDivision.forEach(e => {
                orgList[e.name] = [e.id];
            });

            Object.entries(projectObj).forEach(([key, value]) => {
                const temp = { name: key, 'organisation_division_id': orgList[value] };
                projects.push(temp);
            });

            await Project.create(projects);
            /**Boolean is passed to getProjectAllocList() to insist reading file for reading Date of Releiving column */
            const projectAllocList = await this.getProjectAllocList(finalResource, true);
            return await this.insertProjectTable(projectAllocList);
        } catch (err) {
            console.log(err);
            throw new Error('Project allocation bulk insert failed');
        }
    }

    insertProjectTable = async (projectAllocList) => {

        const templatePath = path.join(__dirname, '../../resources/PROJECT_ALLOCATION_ID.xlsx');
        const outputFilePath = __dirname + '/' + `PROJECT_ALLOCATION_ID${Date.now()}.xlsx`;
        const workbook = new Excel.Workbook();
        const { KairoShiftConfiguration } = models;

        const shiftRec = await KairoShiftConfiguration.findOne({ fields: ["id", "shiftName"] });

        await workbook.xlsx.readFile(templatePath);
        let count = 2;
        let worksheet = workbook.getWorksheet('PROJECT_ALLOCATION_ID');
        projectAllocList.forEach(data => {
            const { employee_id, manager_id, project_id, report_to, role_id, department, city_id } = data;

            let row = worksheet.getRow(count);
            row.getCell(2).value = project_id;
            row.getCell(3).value = employee_id;
            row.getCell(4).value = role_id;
            row.getCell(5).value = manager_id;
            row.getCell(6).value = report_to;
            row.getCell(7).value = city_id;
            row.getCell(8).value = department;
            row.commit();
            count++;
        });
        await workbook.xlsx.writeFile(outputFilePath);

        const { KairoUser, KairoRole, ProjectAllocation, City, Project } = models;
        const userIdList = [], roleIdList = [], projectIdList = [], cityIdList = [];

        const userList = await KairoUser.find({ fields: ["id", "empId", "probationId"] });
        userList.forEach(e => {
            userIdList.push(e.id);
        });

        const roleList = await KairoRole.find({ fields: ["name", "id"] });
        roleList.forEach(e => {
            roleIdList.push(e.id);
        });

        const projectList = await Project.find({ fields: ["name", "id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
        });

        const cityList = await City.find({ fields: ["name", "id"] });
        cityList.forEach(e => {
            cityIdList.push(e.id);
        });

        //Validation and bulk insert to project allocation table.
        let schema = {};
        const metaData = { userIdList, roleIdList, projectIdList, cityIdList };
        schema = await this.batchInsertById(metaData);

        const { rows, errors } = await xlsxHandler(outputFilePath, { schema });
        fs.unlinkSync(outputFilePath);

        if (errors.length > 0) {
            console.error('Project Allocation Upload sheet error', errors);
        }
        if (rows.length === 0) {
            console.error(`You have uploaded empty sheet`);
        }

        // Shift configuration for project allocation
        rows.map(rec => rec['shift_id'] = shiftRec['id']);
        try {
            return await ProjectAllocation.create(rows);
        } catch (err) {
            console.log(err);
        }
    }

    getProjectList = (finalResource) => {
        const projectObj = {};
        for (var c = 1; c < finalResource.length; c++) {
            let rec = finalResource[c];
            let name = rec[8];
            let divison = rec[7];
            if (!projectObj[name]) {
                projectObj[name] = divison.toUpperCase();
            }

        }
        return projectObj;
    }

    getProjectAllocListNew = async (finalResource) => {

        const { KairoUser, Project, RoleMapping, City, MenuOperationControl, ProjectAllocation, KairoRole } = models;
        const userIdList = {}, projectIdList = [];
        const nameIdMapping = [], roleIdMapping = [], projectIdMapping = [], cityMapping = [], empIdMapping = [];
        const active = true;
        const projOrgDivMapping = {}, empDetailsMapping = {}, roleMapping = {};
        let successfulAllocationCount = 0;

        const projOrgDivDetails = await this.paqw.getProjOrgDetailsForBulkUploadTemplate();
        projOrgDivDetails.forEach(rec => {
            projOrgDivMapping[rec.project.toLowerCase()] = { company: rec['company'].toLowerCase(),
                division: rec['division'].toLowerCase() };
        });

        const userList = await KairoUser.find({ where: { active },
            fields: ["firstName", "empId", "email", "id", "probationPrefix", "probationId", "gender", "username"]
        });
        userList.forEach(e => {
            userIdList[e.email.toLowerCase()] = e.id;
            nameIdMapping[e.firstName.toLowerCase()] = e.id;
            let empId = '';
            if(e.empId) {
                empIdMapping[e.empId] = e.id;
                empId = e.empId;
            } else {
                empId = `${e.probationPrefix}-${e.probationId}`;
                empIdMapping[empId] = e.id;
            }
            empDetailsMapping[e.email] = { id: e.id.toString().toLowerCase(), empId: empId.toString().toLowerCase(),
                name: e.firstName.toString().toLowerCase(), gender: e.gender.toString().toLowerCase(),
                domainId: e.username.toString().toLowerCase() };
        });

        // const roleIdMappingList = await RoleMapping.find({ fields: ["principalId", "roleId"] });
        // roleIdMappingList.forEach(e => {
        //     roleIdMapping[e.principalId] = e.roleId;
        // });

        const projectList = await Project.find({ fields: ["name", "id", "organisation_division_id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
            projectIdMapping[e.name.toString().toLowerCase()] = e.id;
        });

        const cityList = await City.find({ fields: ["name", "id"] });
        cityList.forEach(e => {
            cityMapping[e.name.toString().toLowerCase()] = e.id;
        });

        const roleList = await KairoRole.find({ fields: ["id", "name"]});
        roleList.forEach(rec => {
            roleMapping[rec['name'].toLowerCase()] = rec['id'];
        });

        const validReportToRoles = await MenuOperationControl.find({ where: { description: 'Approve Leave', crudType: 'UPDATE' }, fields: ["common_allowed_roles"] });
        let validReportToRolesList = []
        if (validReportToRoles) {
            validReportToRolesList = validReportToRoles[0]['__data']['common_allowed_roles'];
        }

        const projectAllocErrorList = [];
        for (var c = 1; c < finalResource.length; c++) {
            let rec = finalResource[c];
            const userEmail = rec[10].toString().toLowerCase();
            try {
                let project_id, managerName, manager_id, reportToName, report_to, role_id, city_id, employee_id;

                const roleIdMappingList = await RoleMapping.find({ fields: ["principalId", "roleId"] });
                roleIdMappingList.forEach(e => {
                    roleIdMapping[e.principalId] = e.roleId;
                });

                if(!userEmail) {
                    throw new Error('Incorrect or empty Email Id column');
                }
                const userDetails = empDetailsMapping[userEmail];

                // User details validation
                if(rec[1] && rec[1].toString().toLowerCase() === userDetails['empId']
                    && rec[2] && rec[2].toString().toLowerCase() === userDetails['name']
                    && rec[11] && rec[11].toString().toLowerCase() === userDetails['domainId']
                    && rec[12] && rec[12].toString().toLowerCase() === userDetails['gender']) {
                    employee_id = userDetails['id'];
                    // role_id = roleIdMapping[userIdList[rec[10]]];
                } else {
                    throw new Error('Incorrect or empty user details. Please recheck Emp ID, Name, Email Id, Domain Id, Gender columns');
                }

                // Project, company, division validation
                if (rec[8] && projectIdMapping[rec[8].toString().toLowerCase()] &&
                    projOrgDivMapping[rec[8].toString().toLowerCase()]['company'] === rec[6].toString().toLowerCase()
                    && projOrgDivMapping[rec[8].toString().toLowerCase()]['division'] === rec[7].toString().toLowerCase()) {
                    project_id = projectIdMapping[rec[8].toString().toLowerCase()];
                }
                else {
                    throw new Error('Incorrect or empty Company/Division/Project columns');
                }

                // Role column validation
                if(rec[9] && roleMapping[rec[9].toLowerCase()]) {
                    role_id = roleMapping[rec[9].toLowerCase()];
                } else {
                    throw new Error('Incorrect or empty Role column');
                }

                if(rec[3]) {
                    if (nameIdMapping[rec[3].toString().toLowerCase()]) {
                        managerName = rec[3].toString().toLowerCase();
                        manager_id = nameIdMapping[managerName];
                    }
                    else {
                        throw new Error('Incorrect value in PMO column');
                    }
                }

                if((rec[4] || rec[5]) && (!rec[3])) {
                    throw new Error('PMO name column should be specified when Jr PMO/CL or LL column is specified.');
                }

                reportToName = rec[5] && rec[5] != "" ? rec[5] : rec[4] && rec[4] != "" ? rec[4] : managerName;
                reportToName = reportToName ? reportToName.toString().toLowerCase() : "";
                if (reportToName) {
                    if (nameIdMapping[reportToName]) {
                        const report_to_id = nameIdMapping[reportToName]
                        if (roleIdMapping[report_to_id]) {
                            if (validReportToRolesList.indexOf(roleIdMapping[report_to_id]) !== -1) {
                                report_to = report_to_id;
                            }
                            else {
                                throw new Error(reportToName + " is not eligible for Lead/Manager role");
                            }
                        }
                        else {
                            throw new Error("Can't find role id of LL/Manager");
                        }
                    } else {
                        throw new Error("Kindly recheck the LL/Manager");
                    }
                }
                else {
                    report_to = null;
                }

                const isValidHierarchy = await this.validateHierarchy(report_to, manager_id, project_id);
                if(!isValidHierarchy) {
                    throw new Error(`Incorrect hierarchy. PMO or Jr PMO/CL or LL does not belong to the project ${rec[8]}`);
                }

                if(rec[13] && cityMapping[rec[13].toString().toLowerCase()]) {
                    city_id = cityMapping[rec[13].toString().toLowerCase()]
                }
                else {
                    throw new Error('Incorrect or empty Location column')
                }

                if((report_to && employee_id === report_to.toString())
                    || (manager_id && employee_id === manager_id.toString())) {
                    throw new Error('Employee Name cannot be same as PMO or Jr PMO/CL or LL name.')
                }

                let resouceData = {
                    project_id,
                    employee_id,
                    role_id,
                    manager_id,
                    report_to,
                    city_id
                }

                const projectRec = await ProjectAllocation.findOne({ where: resouceData });

                if (!projectRec) {
                    await ProjectAllocation.updateAll({ employee_id }, { current: false });
                    await ProjectAllocation.create({ ...resouceData, current: true, shift_id: 1 });
                    successfulAllocationCount++;
                } else {
                    const { id } = projectRec;

                    await ProjectAllocation.updateAll({ employee_id }, { current: false });
                    await ProjectAllocation.upsertWithWhere({ id }, { current: true,  shift_id: 1 });
                    successfulAllocationCount++;
                }
                await RoleMapping.upsertWithWhere({ principalId: employee_id }, { roleId: role_id });
            }
            catch (error) {
                rec[15] = error.message;
                projectAllocErrorList.push(rec);
                continue;
            }
        }
        if (projectAllocErrorList.length) {
            projectAllocErrorList.unshift(finalResource[0]);
        }
        return {
            successfulAllocationCount,
            projectAllocErrorList
        };
    }

    //columnExists is added for differentiating the file read for update and insert
    getProjectAllocList = async (finalResource, columnExists) => {

        const { KairoUser, KairoRole, Project, RoleMapping, City } = models;
        const userIdList = {}, roleIdList = {}, projectIdList = [];
        const nameIdMapping = [], roleIdMapping = [], projectIdMapping = [], cityMapping = [];
        const active = true;

        const userList = await KairoUser.find({ where: { active }, fields: ["firstName", "empId", "email", "id"] });
        userList.forEach(e => {
            userIdList[e.email] = e.id;
            nameIdMapping[e.firstName] = e.id;
        });

        const roleIdMappingList = await RoleMapping.find({ fields: ["principalId", "roleId"] });
        roleIdMappingList.forEach(e => {
            roleIdMapping[e.principalId] = e.roleId;
        });

        const projectList = await Project.find({ fields: ["name", "id"] });
        projectList.forEach(e => {
            projectIdList.push(e.id);
            projectIdMapping[e.name] = e.id;
        });

        const cityList = await City.find({ fields: ["name", "id"] });
        cityList.forEach(e => {
            cityMapping[e.name] = e.id;
        });

        /* find duplicate user
         let duplicateList = [] , duplicateData = [] , duplicateMap = [];
         finalResource.forEach(e =>{
             if(!duplicateList.includes(e[2])){
                 duplicateList.push(e[2]);
             }else{
                 duplicateMap.push(e[2]);
                 duplicateData.push(e)
             }
         })
         */

        const projectAllocList = [];
        for (var c = 1; c < finalResource.length; c++) {
            let rec = finalResource[c];
            let projectName = rec[8];
            let emailId = rec[9];
            let managerName = rec[3];
            let reportToName = rec[5] && rec[5] != "" ? rec[5] : rec[4] && rec[4] != "" ? rec[4] : managerName;
            if (emailId) {
                let employeeId = nameIdMapping[rec[2]];
                let reportTo = nameIdMapping[reportToName];

                /* find duplicate user
                if(duplicateData[rec[2]]){
                   const filterData = duplicateData.filter(e => e[2] == rec[2] && e[3] == managerName );
                   employeeId = filterData ? filterData[1] : employeeId ;
                }
                if(duplicateData[reportToName]){
                    const filterData = duplicateData.filter(e => e[2] == rec[2] && e[3] == managerName );
                    reportTo = filterData ? filterData[1] : reportTo ;
                }
                */

                let resouceData = {
                    project_id: projectIdMapping[projectName],
                    employee_id: employeeId,
                    role_id: roleIdMapping[userIdList[rec[9]]],
                    manager_id: nameIdMapping[managerName],
                    report_to: reportTo,
                    city_id: columnExists ? cityMapping[rec[13].toUpperCase()] : cityMapping[rec[12].toUpperCase()]
                }
                projectAllocList.push(resouceData);

            };
        }
        return projectAllocList;
    }

    projectAllocBulkUpdate = async (req) => {

        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const finalResource = await xlsxHandler(fileInfo.path, { sheet: 1 });
        /**Boolean is passed to getProjectAllocList() to insist reading file for reading Date of Releiving column */
        const projectAllocList = await this.getProjectAllocList(finalResource, false);
        let insertList = [];
        let oldProjectList = [];
        const { ProjectAllocation } = models;

        for (let data of projectAllocList) {
            let userList = await this.findProjectChange(data);
            if (!userList) {
                insertList.push(data);
                oldProjectList.push(data.employee_id);
            }
        };
        for (let oldData of oldProjectList) {
            await ProjectAllocation.updateAll({ employee_id: oldData }, { current: false });
        }
        return await this.insertProjectTable(insertList);
    }

    findProjectChange = async (data) => {
        const { ProjectAllocation } = models;
        const { employee_id, project_id } = data;
        let userList = await ProjectAllocation.findOne({ where: { and: [{ employee_id }, { project_id }, { current: true }] } });
        return userList;
    }

    changeEmployeeRole = async (options, employee_id, role_id, project_id) => {
        const { ProjectAllocation } = models;
        let allocRec = await ProjectAllocation.find({ where: { and: [{ employee_id: { inq: employee_id }, project_id }] } });

        for (let c = 0; c < allocRec.length; c++) {
            let rec = allocRec[c];
            let auditList = [];
            rec = rec['__data'];
            if (rec['audit']) {
                auditList = rec['audit'];
            }
            delete rec['audit'];
            auditList.push(rec);
            const updatedRec = await ProjectAllocation.upsertWithWhere({ employee_id: rec['employee_id'], project_id }, { report_to: null, manager_id: null, role_id, audit: auditList, current: true });
        }
    }

    changeEmployeeTeam = async (options, employee_id, project_id, report_to, manager_id) => {
        const { ProjectAllocation } = models;
        let allocRec = await ProjectAllocation.find({ where: { and: [{ employee_id: { inq: employee_id }, project_id }] } });

        for (let c = 0; c < allocRec.length; c++) {
            let rec = allocRec[c];
            let auditList = [];
            rec = rec['__data'];
            if (rec['audit']) {
                auditList = rec['audit'];
            }
            delete rec['audit'];
            auditList.push(rec);
            const updatedRec = await ProjectAllocation.upsertWithWhere({ employee_id: rec['employee_id'], project_id }, { report_to, manager_id, audit: auditList, current: true });
        }
    }

    changeEmployeeProject = async (options, employee_id, project_id, role_id) => {
        const { ProjectAllocation } = models;
        const resData = [];

        let allocRec = await ProjectAllocation.find({ where: { and: [{ employee_id: { inq: employee_id }, current: true }] } });
        for (let c = 0; c < allocRec.length; c++) {
            let rec = allocRec[c];
            rec = rec['__data'];

            let existingRec = await ProjectAllocation.findOne({ where: { and: [{ employee_id: rec['employee_id'], project_id }] } });
            if (existingRec) {
                await ProjectAllocation.upsertWithWhere({ id: existingRec['id'] }, { role_id, current: true, report_to: null, manager_id: null });
            } else {
                resData.push({ employee_id: rec['employee_id'], project_id, role_id, current: true });
            }
            await ProjectAllocation.upsertWithWhere({ id: rec['id'] }, { current: false });
        }
        try {
            await ProjectAllocation.create(resData);
        } catch (err) {
            console.log(err);
        }
    }

    /* v1.0 Project Allocation Template Format - REMOVE IF v2.0 implementation is completed - START */
    downloadResourceAllocTemplate = async (res) => {
        // Uncomment this if any issue with the template
        // this.fu.downloadTemplate(resourceAllocTemplate, res);

        const fileName = "Emp_project_alloc_template.xlsx";
        const allocTemplate = await this.prepareBulkResourceMovementTemplate();
        const resTemplate = await this.prepareProjDetailsTemplate(allocTemplate);
        const finalTemplate = await this.prepareRoleDetailsTemplate(resTemplate);
        await this.fu.downloadWorkbook(res, finalTemplate, fileName);
    }

    prepareBulkResourceMovementTemplate = async() => {
        const sheetName = "Bulk Resource Movement";
        const dataList = [
            {
                empId: '', name: '', pmo: '', cl: '', ll: '', company: '', division: '', project: '', role: '', email: '', domain: '', gender: '', location: ''
            }
        ];

        const columnHeaders = [
            { header: 'Emp ID', key: "empId", width: 20 },
            { header: 'Name', key: "name", width: 40 },
            { header: 'PMO', key: "pmo",width: 40 },
            { header: 'Jr PMO/CL', key: "cl",width: 40 },
            { header: 'LL', key: "ll",width: 40 },
            { header: 'Company', key: "company",width: 30 },
            { header: 'Division', key: "division",width: 30 },
            { header: 'Project', key: "project",width: 30 },
            { header: 'Role', key: "role",width: 30 },
            { header: 'Email Id', key: "email",width: 30 },
            { header: 'Domain Id', key: "domain",width: 20 },
            { header: 'Gender', key: "gender",width: 20 },
            { header: 'Location', key: "location",width: 30 }
        ];
        return await this.fu.createWorkbookFromData(sheetName, columnHeaders, dataList);
    }

    prepareProjDetailsTemplate = async(allocTemplate) => {
        const projDetails = await this.paqw.getProjOrgDetailsForBulkUploadTemplate();
        const sheetName = "Project Organisation Details";
        const columnHeaders = [
            { header: 'Company', key: 'company', width: 30 },
            { header: 'Division', key: 'division', width: 30 },
            { header: 'Project', key: 'project', width: 30 }
        ];

        return await this.fu.createWorkbookFromData(sheetName, columnHeaders, projDetails, allocTemplate);
    }
    /* v1.0 Project Allocation Template Format - REMOVE IF v2.0 implementation is completed - END */

    getProjAllocRecords = async ({ size, num }, { project_id, manager_id, report_to, empId, name, active, current }) => {
        const { ProjectAllocation, KairoUser } = models;
        const skip = num * size;
        let conditions = {};
        const empIdList = [];

        current ? conditions = { ...conditions, current } : conditions = { ...conditions };

        if (project_id) {
            conditions = { ...conditions, project_id }
        }
        if (manager_id) {
            conditions = { ...conditions, manager_id }
        }
        if (report_to) {
            conditions = { ...conditions, report_to }
        }

        if (empId && name) {
            const condition = this.getValidatedEmpId(empId);
            name = '%' + name + '%';
            let empRec = await KairoUser.find({ where: { and: [{ firstName: { like: name } }, { or: condition }, { active }] } });
            empRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        else if (empId) {
            const condition = this.getValidatedEmpId(empId);
            let empRec = await KairoUser.find({ where: { and: [{ or: condition }, { active }] } })
            empRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        else if (name) {
            name = '%' + name + '%';
            let nameRec = await KairoUser.find({ where: { firstName: { like: name } , active } });
            nameRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (active && !empId && !name) {
            let empRec = await KairoUser.find({ where: { active } });
            empRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (empIdList.length > 0) {
            conditions = { ...conditions, employee_id: { inq: empIdList } }
        }
        const filter = {
            where: { ...conditions },
            fields: ["employee_id", "role_id", "report_to", "manager_id", "project_id", "city_id", "current", "support"],
            include: [
                {
                    relation: "employee",
                    scope: { fields: ["firstName", "empId", "username", "probationPrefix", "probationId", "email", "active"] }
                }, {
                    relation: "kairoRole",
                    scope: { fields: ["name"] }
                }, {
                    relation: "reportTo",
                    scope: { fields: ["firstName"] }
                }, {
                    relation: "manager",
                    scope: { fields: ["firstName"] }
                }, {
                    relation: "city"
                }
            ],
            order: "employee_id"
        }

        const totalCount = await ProjectAllocation.count({ ...conditions });
        const options = totalCount > size ? totalCount > skip ? { limit: size, skip } : { limit: size, skip: Math.floor(totalCount - 1 / size) * size } : {};
        //const projAllocList = await this.sortProjectAllocByEmpId(await ProjectAllocation.find({ ...filter}), true);
        const projAllocList = await ProjectAllocation.find({ ...filter, ...options });
        const records = [];

        const { projectMapById } = await this.gs.getProjectByOrgDiv();
        const { organisationMapById } = await this.gs.getOrganisation();
        const { orgDivisionMapById } = await this.gs.getDivisionByOrg();

        for (let rec of projAllocList) {
            rec = rec['__data'];
            const project = this.constructProjectObject(rec['project_id'], projectMapById, organisationMapById, orgDivisionMapById);
            rec = { ...rec, project };
            records.push(rec);
        }
        return {
            totalCount,
            records
        };
    }

    getValidatedEmpId = (empId) => {
        const pattern = /^P|^P-/i, empIdCondition = [];
        if(pattern.test(empId)){
            empId = empId.includes('-') && empId.split(`-`)[1] ? `%${empId.split(`-`)[1]}%` : '';
            empId ? empIdCondition.push({probationId: { like: empId }}) : empIdCondition.push({isProbation: true});
        }else{
            empIdCondition.push({ empId: { like: `%${empId}%` } }, { probationId: { like: `%${empId}%` } });
        }
        return empIdCondition;
    }

    getMyTeamResources = async (userId, limit, skip, manager_id, report_to, empId, name) => {
        const { ProjectAllocation, KairoUser } = models;
        const conditions = [];
        const empIdList = [];

        let whereCondition = { and: [{ current: true }, { or: [{ report_to: userId }, { manager_id: userId }] }] };

        if (manager_id) {
            conditions.push({ manager_id });
        }
        if (report_to) {
            conditions.push({ report_to });
        }
        if (empId) {
            empId = '%' + empId + '%';
            let empRec = await KairoUser.find({ where: { or: [{ empId: { like: empId } }, { probationId: { like: empId } }] } })
            empRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (name) {
            name = '%' + name + '%';
            let nameRec = await KairoUser.find({ where: { firstName: { like: name } } });
            nameRec.forEach(rec => empIdList.push(rec['id']));
            empIdList.length === 0 ? empIdList.push("") : "";
        }
        if (empIdList.length > 0) {
            conditions.push({ employee_id: { inq: empIdList } });
        }
        if (conditions.length > 0) {
            let andCond = whereCondition['and'];
            andCond.push({ and: conditions });
            whereCondition['and'] = andCond;
        }

        const filter = {
            where: whereCondition,
            fields: ["employee_id", "role_id", "report_to", "manager_id", "project_id", "city_id"],
            include: [
                {
                    relation: "employee",
                    scope: { fields: ["firstName", "empId", "username", "email", "gender", "probationPrefix", "probationId"] }
                }, {
                    relation: "kairoRole",
                    scope: { fields: ["name", "power"] }
                }, {
                    relation: "reportTo",
                    scope: { fields: ["empId", "firstName", "username", "email"] }
                }, {
                    relation: "manager",
                    scope: { fields: ["empId", "firstName", "username", "email"] }
                }, {
                    relation: "city"
                }
            ]
        }

        const totalCount = await ProjectAllocation.count(filter);
        const myTeamList = (await this.sortProjectAllocByEmpId(await ProjectAllocation.find({ ...filter, limit, skip }), true));
        const records = [];

        const { projectMapById } = await this.gs.getProjectByOrgDiv();
        const { organisationMapById } = await this.gs.getOrganisation();
        const { orgDivisionMapById } = await this.gs.getDivisionByOrg();

        for (let rec of myTeamList) {
            rec = rec['__data'];
            const project = this.constructProjectObject(rec['project_id'], projectMapById, organisationMapById, orgDivisionMapById);
            rec = { ...rec, project };
            records.push(rec);
        }

        return {
            totalCount,
            records
        };
    }

    /* v1.0 Project Allocation Bulk Update Implementation - START */
    projectAllocBulkUpdateNew = async (req) => {
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const finalResource = await xlsxHandler(fileInfo.path, { sheet: 1 });
        const projectAllocFetchMap = await this.getProjectAllocListNew(finalResource);
        const { successfulAllocationCount, projectAllocErrorList } = projectAllocFetchMap;

        let response = {
            successfulAllocationCount,
            projectAllocErrorList
        }
        return response;
    }
    /* v1.0 Project Allocation Bulk Update Implementation - END */

    sortProjectAllocByEmpId = async function (records, isAsc) {
        return await records.sort((a, b) => {
            let aEmpId = a['__data']['employee']['__data']['empId'] ? a['__data']['employee']['__data']['empId'] : a['__data']['employee']['__data']['probationPrefix'] + '-' + a['__data']['employee']['__data']['probationId'];
            let bEmpId = b['__data']['employee']['__data']['empId'] ? b['__data']['employee']['__data']['empId'] : b['__data']['employee']['__data']['probationPrefix'] + '-' + b['__data']['employee']['__data']['probationId'];
            if (isAsc)
                return aEmpId - bEmpId;
            return bEmpId - aEmpId;
        });
    }



    addUserProject = async (result) => {
        const { ProjectAllocation, Project, KairoUser, RoleMapping } = models;
        // const defaultMangerId = await Project.find({ fields: ["default_manager_id"], where: { id: result.project } });
        // const { default_manager_id } = defaultMangerId[0];
        let roleMapping = null;
        const {project, id, role, manager} = result;
        const projAllocData = {
            support: 0,
            current: 1,
            project_id: project ? project : null,
            employee_id: id ? id : null,
            role_id: role ? role : null,
            manager_id: manager ? manager : null,
            city_id: 1
        }
        const createRoleMapping = {
            principalType: "USER",
            principalId: id,
            roleId: role
        }
        roleMapping = await RoleMapping.create(createRoleMapping);
        return await ProjectAllocation.create(projAllocData);
    }

    downloadProjAllocRecords = async (filter, res) => {
        const { project_id, manager_id, report_to, empId, name, active, current } = filter;

        const data = await this.getProjAllocRecords({}, { project_id, manager_id, report_to, empId, name, active, current });
        const today = new Date();
        const fileName = `ProjectAllocation_${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;

        const { columnHeaders, dataList } = this.createProjectAllocDocData(data);
        const workbookFile = await this.fu.createWorkbookFromData("Project_Resource_Details", columnHeaders, dataList);
        await this.fu.downloadWorkbook(res, workbookFile, fileName);
    }

    createProjectAllocDocData = data => {
        const { records } = data;
        const dataList = [];

        const columnHeaders = [
            { header: 'Employee ID', key: 'employee_id', width: 16 },
            { header: 'Name', key: 'first_name', width: 30 },
            { header: 'Role', key: 'role', width: 20 },
            { header: 'Working', key: 'user_status', width: 30 },
            { header: 'Reporting To', key: 'report_to', width: 40 },
            { header: 'Manager', key: 'manager', width: 30 },
            { header: 'Project Name', key: 'project_name', width: 40 },
            { header: 'Organisation Divison', key: 'org_divison', width: 30 },
            { header: 'Project Activity', key: 'project_status', width: 30 },
            { header: 'Location', key: 'city_name', width: 30 }
        ];

        if (records) {
            for (let index = 0; index < records.length; index++) {
                let rec = records[index];
                const { employee, kairoRole, reportTo, manager, project, city, current, support } = rec;
                const { name } = city;

                const supportInfo = support ? 'Support' : '-';
                let project_status = "-";
                if (employee && employee.active) {
                    project_status = current ? 'Current' : supportInfo;
                } else {
                    project_status = current ? 'Last Active' : supportInfo;
                }

                const newRow = {
                    employee_id: employee ? employee.empId ? employee.empId : employee.probationPrefix + '-' + employee.probationId : "",
                    first_name: employee ? employee.firstName : "",
                    role: kairoRole ? kairoRole.name : "",
                    report_to: reportTo ? reportTo.firstName : "",
                    manager: manager ? manager.firstName : "",
                    project_name: project ? project.name : "",
                    org_divison: project && project['organisationDivision'] ? project['organisationDivision']['name'] : "",
                    city_name: name ? name : "",
                    user_status: employee ? employee.active ? "ACTIVE" : "INACTIVE" : "-",
                    project_status
                }
                dataList.push(newRow);
            }
        }
        return { columnHeaders, dataList };
    }

    downloadMyTeamResources = async (userId, res) => {
        const { KairoUser } = models;
        const data = await this.getMyTeamResources(userId);
        const { columnHeaders, dataList } = this.createMyTeamDocData(data);
        const userData = await KairoUser.findOne({ where: { id: userId }, fields: ["firstName", "empId"] });
        const { firstName, empId } = userData;
        const fileName = `${firstName.toUpperCase}[${empId}] - Team.xlsx`;

        const workbookFile = await this.fu.createWorkbookFromData("My_Team_Details", columnHeaders, dataList);
        await this.fu.downloadWorkbook(res, workbookFile, fileName);
    }

    createMyTeamDocData = data => {
        const { records } = data;
        const dataList = [];

        const columnHeaders = [
            { header: 'Employee ID', key: 'employee_id', width: 15 },
            { header: 'Name', key: 'first_name', width: 30 },
            { header: 'Domain Name', key: 'domain_name', width: 20 },
            { header: 'Role', key: 'role', width: 20 },
            { header: 'Reporting To', key: 'report_to', width: 30 },
            { header: 'Manager', key: 'manager', width: 35 },
            { header: 'Email ID', key: 'email_id', width: 35 },
            { header: 'Gender', key: 'gender', width: 10 },
            { header: 'Location', key: 'city', width: 10 }
        ]

        if (records) {
            for (let index = 0; index < records.length; index++) {
                let rec = records[index];
                const { employee, kairoRole, reportTo, manager, city } = rec;
                const newRow = {
                    employee_id: employee ? employee.empId ? employee.empId : employee.probationPrefix + '-' + employee.probationId : "",
                    first_name: employee ? employee.firstName : "",
                    domain_name: employee ? employee.username : "",
                    role: kairoRole ? kairoRole.name : "",
                    report_to: reportTo ? reportTo.firstName : "",
                    manager: manager ? manager.firstName : "",
                    email_id: employee ? employee.email : "",
                    gender: employee ? employee.gender : "",
                    city: city ? city.name : ""
                }
                dataList.push(newRow);
            }
        }
        return { columnHeaders, dataList };
    }

    constructProjectObject = (project_id, projectMapById, organisationMapById, orgDivisionMapById) => {
        const { organisation_division_id } = projectMapById[project_id];
        const { organisation_id } = orgDivisionMapById[organisation_division_id];
        const { displayName } = organisationMapById[organisation_id];

        return {
            id: project_id,
            name: projectMapById[project_id]['name'],
            organisation_division_id,
            organisationDivision: {
                id: organisation_division_id,
                name: orgDivisionMapById[organisation_division_id]['name'],
                organisation_id,
                organisation: {
                    displayName,
                    id: organisation_id,
                    name: organisationMapById[organisation_id]['name']
                }
            }
        }
    }

    getMyProjectHistory = async (employee_id) => {
        const { ProjectAllocation, RoleMapping } = models;
        const filter = {
            order: 'workStartDate DESC',
            where: { employee_id },
            fields: ["workStartDate", "workEndDate", "support", "current", "project_id", "employee_id", "role_id", "manager_id", "report_to", "city_id"],
            include: [
                {
                    relation: "kairoRole",
                    scope: { fields: ["name", "domain"] }
                }, {
                    relation: "reportTo",
                    scope: { fields: ["empId", "firstName", "username", "email"] }
                }, {
                    relation: "manager",
                    scope: { fields: ["empId", "firstName", "username", "email"] }
                }, {
                    relation: "city"
                }
            ]
        }
        const projectAllocData = await ProjectAllocation.find({ ...filter });

        const projectOrganisationDetailsMap = await this.gs.getProjectDetailsById();

        //Active roles grouped by role_id
        const activeRoleMap = {};
        const activeRolesList = await this.gs.getActiveRoles();
        activeRolesList.map(e => activeRoleMap[e.id] = e);

        //Grouping Roles by princileId(employee_id)
        //In-order to get the Role of report_to and manager_id for each record in project_allocation table
        const roleIdMap = {};
        const roleIdMappingList = await RoleMapping.find({ fields: ["principalId", "roleId"] });
        roleIdMappingList.map(e => roleIdMap[e.principalId] = activeRoleMap[e.roleId]);

        let result = [];
        for (let rec of projectAllocData) {
            rec = rec.toJSON();
            const { project_id, report_to, manager_id, workStartDate, workEndDate } = rec;
            if (workStartDate && workEndDate) {
                rec.experience = this.du.calculateMonthsBetweenDates(workStartDate, workEndDate);
                rec['workStartDate'] = moment(workStartDate).format(SQL_DATE_FORMAT);
                rec['workEndDate'] = moment(workEndDate).format(SQL_DATE_FORMAT);
            }
            let myReportingHierarchy = [];
            if (rec.reportTo) {
                await this.getMyReportToFlow(rec.reportTo.id, myReportingHierarchy)
                rec = { ...rec, myReportingHierarchy }
            }
            if (rec.reportTo) {
                let kairoRole = roleIdMap[report_to];
                rec.reportTo = { ...rec.reportTo, kairoRole };
            }
            if (rec.manager) {
                let kairoRole = roleIdMap[manager_id];
                rec.manager = { ...rec.manager, kairoRole };
            }
            const project = projectOrganisationDetailsMap[project_id];
            rec = { ...rec, project };
            result.push(rec);
        }
        return {
            result
        }
    }

    getMyReportToFlow = async (employee_id, myHigherAuthorites) => {
        const { ProjectAllocation } = models;
        const currAllocInfo = await ProjectAllocation.find({
            where: { employee_id, current: true },
            fields: ["id", "employee_id", "role_id", "report_to", "manager_id"],
            include: [{
                relation: "employee",
                scope: {
                    fields: ["empId", "email", "username", "gender", "isProbation", "probationId", "probationPrefix","active"]
                }
            }, {
                relation: "kairoRole",
                scope: {
                    fields: ["name", "domain"]
                }
            }]
        });

        if (!currAllocInfo[0]) {
            return;
        }

        const isActive =  currAllocInfo[0].toJSON().employee.active ;
        if( isActive ){
            myHigherAuthorites.push(currAllocInfo[0]);
        }

        const { report_to, manager_id } = currAllocInfo[0];
        if(employee_id === report_to) {
            return;
        }
        if (report_to) {
            await this.getMyReportToFlow(report_to, myHigherAuthorites);
        }
    }

    getMyTeamDescendingHierarchy = async (userId, paging, filter) => {
        if (filter.reportUserId) {
            userId = filter.reportUserId;
            delete filter.reportUserId;
        }

        const totalCount = await this.paqw.getMyTeamDescHierarchyCountOtherTables(userId, "", [], filter);
        paging = paging ? this.gu.fixPageCount(totalCount, paging) : paging;

        const records = await this.paqw.getMyTeamDescendingHierarchy(userId, paging, filter);
        return {
            totalCount,
            records
        };
    }

    downloadMyTeamHierarchy = async (userId, res,filter) => {
        const filteredData = await this.getMyTeamDescendingHierarchy(userId, '', filter);

        const today = new Date();
        const fileName = `OrganisationMyTeam_${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;

        const { columnHeaders, dataList } = await this.createMyTeamHierarchyDocData(filteredData);
        const workbookFile = await this.fu.createWorkbookFromData("Organisation_MyTeam_Details", columnHeaders, dataList);
        await this.fu.downloadWorkbook(res, workbookFile, fileName);
    }

    getMyTeamDescHierarchyForNestedLink = async (userId, paging, filter) => {
        return await this.paqw.getMyTeamDescHierarchyForNestedLink(userId, paging, filter);
    }

    getProjAllocFilters = async ({ project_id }) => {
        const { ProjectAllocation } = models;
        let conditions = { current: true }
        if (project_id) {
            conditions = { ...conditions, project_id }
        }
        const filter = {
            where: { ...conditions },
            fields: ["report_to", "manager_id"],
            include: [
                {
                    relation: "reportTo",
                    scope: { fields: ["firstName"] }
                }, {
                    relation: "manager",
                    scope: { fields: ["firstName"] }
                }
            ],
        }
        const filterData = await ProjectAllocation.find({ ...filter })
        let reportToMap = {};
        let managerMap = {};
        filterData.forEach(data => {
            data = data['__data'];
            if (data.report_to) {
                if (!reportToMap[data.report_to]) {
                    reportToMap[data.report_to] = data['reportTo']['firstName']
                }
            }
            if (data.manager_id) {
                if (!managerMap[data.manager_id]) {
                    managerMap[data.manager_id] = data['manager']['firstName'];
                }
            }
        })
        return {
            reportToMap,
            managerMap
        };
    }

    validateHierarchy = async(report_to, manager_id, project_id) => {
        const { ProjectAllocation } = models;
        const empProjectMap = {};

        const allRec = await ProjectAllocation.find({
            fields: ["employee_id", "project_id"],
        });
        allRec.forEach(rec => {
            if(!empProjectMap[rec['employee_id']]) {
                empProjectMap[rec['employee_id']] = [rec['project_id']];
            } else {
                let temp = empProjectMap[rec['employee_id']];
                temp.push(rec['project_id']);
                empProjectMap[rec['employee_id']] = temp;
            }
        });

        if(report_to && empProjectMap[report_to].indexOf(project_id) === -1) {
            return false;
        }
        if(manager_id && empProjectMap[manager_id].indexOf(project_id) === -1) {
            return false;
        }
        return true;
    }

    createMyTeamHierarchyDocData = async(data) => {
        const { records } = data;
        const dataList = [],userMap={};
        const { KairoUser } = models;

        const projectMap = await this.gs.getProjectDetailsById();

        const userList = await KairoUser.find({ fields: ["email","firstName" ,"id"] });
        userList.map(user=>{
            userMap[user.id] = {name:user.firstName,mail:user.email}
        });

        const columnHeaders = [
            { header: 'Employee ID', key: 'employee_id', width: 15 },
            { header: 'Name', key: 'firstName', width: 30 },
            { header: 'Email ID', key: 'email', width: 35 },
            { header: 'Role', key: 'roleName', width: 20 },
            { header: 'Project Name', key: 'project', width: 30 },
            { header: 'Reporting To', key: 'reportFirstName', width: 30 },
            { header: 'Manager', key: 'manager', width: 30 },
            { header: 'Location', key: 'cityName', width: 10 }
        ]

        if (records) {
            for (let index = 0; index < records.length; index++) {
                const teamMemberInfo = records[index];
                const { empId, probationPrefix, probationId, projectId, managerId } = teamMemberInfo;
                teamMemberInfo.employee_id = empId ? empId : probationPrefix + '-' + probationId;
                teamMemberInfo.project = projectMap ? projectMap[projectId] ? projectMap[projectId].projectName : "" : "";
                teamMemberInfo.manager = userMap ? userMap[managerId] ? userMap[managerId].name : "" : "";
                dataList.push(teamMemberInfo);
            }
        }
        return { columnHeaders, dataList };
    }

    /* v2.0 Project Allocation Template Implementation */
    downloadResourceAllocTemplateUpdated = async (res) => {
        const fileName = "Emp_project_alloc_template.xlsx";
        const allocTemplate = await this.prepareBulkResourceMovementTemplateUpdated();
        const resTemplate = await this.prepareProjDetailsTemplateUpdated(allocTemplate);
        const finalTemplate = await this.prepareRoleDetailsTemplate(resTemplate);
        await this.fu.downloadWorkbook(res, finalTemplate, fileName);
    }

    prepareBulkResourceMovementTemplateUpdated = async() => {
        const sheetName = "Bulk Resource Movement";
        const dataList = [
            {
                userEmail: '', project: '', role: '', pmoEmail: '', clEmail: '', llEmail: '', location: ''
            }
        ];

        const columnHeaders = [
            { header: 'Employee Email', key: "userEmail", width: 40 },
            { header: 'Project Name', key: "project", width: 30 },
            { header: 'Role', key: "role",width: 40 },
            { header: 'PMO Email', key: "pmoEmail",width: 40 },
            { header: 'Jr PMO/CL Email', key: "clEmail",width: 40 },
            { header: 'LL Email', key: "llEmail",width: 40 },
            { header: 'Working Location', key: "location",width: 30 }
        ];
        return await this.fu.createWorkbookFromData(sheetName, columnHeaders, dataList);
    }

    prepareProjDetailsTemplateUpdated = async(allocTemplate) => {
        const projDetails = await this.paqw.getProjOrgDetailsForBulkUploadTemplate();
        const sheetName = "Project Details";
        const columnHeaders = [
            { header: 'Project Name', key: 'project', width: 40 }
        ];

        return await this.fu.createWorkbookFromData(sheetName, columnHeaders, projDetails, allocTemplate);
    }

    prepareRoleDetailsTemplate = async(allocTemplate) => {
        const { KairoRole } = models;
        const roleDetails = [];
        (await KairoRole.find({ fields: ["id","name","power"] })).forEach(rec => roleDetails.push({ power: rec['power'], name: rec['name']}));
        const sheetName = "Role Details";
        const columnHeaders = [
            { header: 'Hierarchy', key: 'power', width: 50 },
            { header: 'Role Name', key: 'name', width: 50 }
        ];

        return await this.fu.createWorkbookFromData(sheetName, columnHeaders, roleDetails, allocTemplate);
    }

    /* v2.0 Project allocation bulk upload implementation */
    projectAllocBulkUpdateNewVersion = async (req) => {
        const [fields, files] = await this.promisifyUpload(req);
        const fileInfo = files.file[0];

        const { originalFilename } = fileInfo;
        if (!originalFilename.includes('.xlsx')) {
            throw new Error(`Please upload file with correct extension.
             xlsx format is required`);
        }

        const resourceList = await xlsxHandler(fileInfo.path, { sheet: 1 });
        const { successfulAllocationCount, projectAllocErrorList } = await this.insertProjAllocFromResourcesList(resourceList);

        return { successfulAllocationCount, projectAllocErrorList };
    }

    getProjAllocMappings = async() => {
        const { KairoUser, Project, City, ProjectAllocation, KairoRole } = models;
        const idEmailMapping = {}, idProjectRoleMapping = {}, projMapping = {}, cityMapping = {}, roleMapping = {}, rolePowerMapping = {};

        const activeUsersList = await KairoUser.find({
            fields: ["id", "email", "active"],
            where: { active: true }
        });
        activeUsersList.forEach(rec => idEmailMapping[rec['email'].toLowerCase()] = rec['id']);

        const projAllocList = await ProjectAllocation.find({
            fields: ["id","current","project_id","role_id","employee_id"]
        });
        projAllocList.forEach(rec => {
            const { employee_id, project_id, role_id } = rec;
            if(!idProjectRoleMapping[employee_id]) {
                idProjectRoleMapping[employee_id] = {};
                if(!idProjectRoleMapping[employee_id][project_id]) {
                    idProjectRoleMapping[employee_id][project_id] = [role_id];
                } else {
                    idProjectRoleMapping[employee_id][project_id].push(role_id);
                }
            } else {
                if(!idProjectRoleMapping[employee_id][project_id]) {
                    idProjectRoleMapping[employee_id][project_id] = [role_id];
                } else {
                    idProjectRoleMapping[employee_id][project_id].push(role_id);
                }
            }
        });

        (await Project.find({ fields: ["id","name"] })).forEach(rec => projMapping[rec['name'].toLowerCase()] = rec['id']);
        (await City.find({ fields: ["id","name"]})).forEach(rec => cityMapping[rec['name'].toLowerCase()] = rec['id']);
        (await KairoRole.find({ fields: ["id","name","power"]})).forEach(rec => {
            roleMapping[rec['name'].toLowerCase()] = rec['id']
            rolePowerMapping[rec['id']] = rec['power']
        });

        return { idEmailMapping, idProjectRoleMapping, projMapping, cityMapping, roleMapping, rolePowerMapping };
    }

    insertProjAllocFromResourcesList = async(resourceList) => {
        const { idEmailMapping, idProjectRoleMapping, projMapping, cityMapping, roleMapping, rolePowerMapping } = await this.getProjAllocMappings();
        let successfulAllocationCount = 0, projectAllocErrorList = [resourceList[0]];
        const { ProjectAllocation, RoleMapping } = models;

        if(resourceList.length <= 1) {
            throw new Error('Error! There are no records in the uploaded sheet');
        }
        resourceList = resourceList.slice(1);
        for(let rec of resourceList) {
            const employee_id = idEmailMapping[rec[1] ? rec[1].toLowerCase() : null];
            const project_id = projMapping[rec[2] ? rec[2].toLowerCase() : null];
            const role_id = roleMapping[rec[3] ? rec[3].toLowerCase() : null];
            const manager_id = idEmailMapping[rec[4] ? rec[4].toLowerCase() : null];
            const reportTo = rec[6] ? rec[6] : rec[5] ? rec[5] : rec[4];
            const report_to = idEmailMapping[reportTo ? reportTo : null];
            const city_id = cityMapping[rec[7] ? rec[7].toLowerCase() : null];

            const projAllocObj = { employee_id, project_id, role_id, report_to, manager_id, city_id };

            if(!employee_id || !project_id || !role_id || !city_id) {
                rec[10] = 'Incorrect/Empty Employee Email, Project Name, Role or Working Location';
                projectAllocErrorList.push(rec);
                continue;
            }

            if(report_to && !manager_id) {
                rec[10] = 'Incorrect/Empty PMO Email column. It should be mentioned correctly when Jr PMO/CL Email or LL Email column is specified.';
                projectAllocErrorList.push(rec);
                continue;
            }

            if((manager_id && Object.keys(idProjectRoleMapping[manager_id]).indexOf(project_id.toString()) === -1)
                || (report_to && Object.keys(idProjectRoleMapping[report_to]).indexOf(project_id.toString()) === -1)) {
                rec[10] = 'Invalid hierarchy. PMO Email or Jr PMO/CL Email or LL Email does not belong to this project';
                projectAllocErrorList.push(rec);
                continue;
            }

            const projAllocRec = await ProjectAllocation.findOne({ where: projAllocObj });
            await ProjectAllocation.updateAll({ employee_id }, { current: false, shift_id: 1 });

            if(projAllocRec) {
                await ProjectAllocation.upsertWithWhere({ id: projAllocRec['id'] }, { current: true, shift_id: 1 });
            } else {
                await ProjectAllocation.create({ ...projAllocObj, current: true, shift_id: 1 });
            }
            await RoleMapping.upsertWithWhere({ principalId: employee_id }, { roleId: role_id });
            successfulAllocationCount++;
        }

        if(projectAllocErrorList.length <= 1) {
            projectAllocErrorList = [];
        }

        return { successfulAllocationCount, projectAllocErrorList };
    }

    getMyProxyApplyableUserList = async (userId, paging, filter) => {
      const hasHrRole = await this.checkWhetherRoleIsHR(userId);
      if(hasHrRole){
        const totalCount = await this.paqw.getHrProxyApplyableListCount(userId,filter);
        delete filter.reportUserId;
        paging = paging ? this.gu.fixPageCount(totalCount, paging) : paging;
        const records = await this.paqw.getHrProxyApplyableList(userId,paging, filter)
        return {
          totalCount,
          records
      };
      }
      else{
        if (filter.reportUserId) {
          userId = filter.reportUserId;
          delete filter.reportUserId;
        }
        const totalCount = await this.paqw.getMyTeamDescHierarchyCountOtherTables(userId, "", [], filter);
        paging = paging ? this.gu.fixPageCount(totalCount, paging) : paging;

        const records = await this.paqw.getMyTeamDescendingHierarchy(userId, paging, filter);
        return {
            totalCount,
            records
        };
      }
    }

    checkWhetherRoleIsHR = async (userId) => {
      /* TODO: Actually here include relation name shdn't be user.
         It name shd be KairoRole. But the mistake was done in model-config.json file.
         Correct there and ask for other developers to check and fix the occurences.
      */
      let hasHrRole = false;
      const userRoleDetails = await this.RoleMapping.find({
          where: { principalId: userId }, fields: ["principalId", "roleId"],
          include: [{
              relation: "user",
              scope: { fields: ["name", "domain", "id"] }
          }]
      });

      for (let i = 0; i < userRoleDetails.length; i++) {
          const userRoleInfo = userRoleDetails[i].toJSON();
          if (userRoleInfo.user.name.toLowerCase().includes('hr')) {
              hasHrRole = true;
              break;
          }
      }

      const myProjectRoles = (await this.ProjectAllocation.find({
          where: { employee_id: userId },
          fields: ["role_id"]
      })).map(e => parseInt(e.role_id));

      const userRoleDetailsList = await this.KairoRole.find({ where: { id: { inq: myProjectRoles }}} );

      for (let i = 0; i < userRoleDetailsList.length; i++) {
          const userRoleInfo = userRoleDetailsList[i];
          if (userRoleInfo.name.toLowerCase().includes('hr')) {
              hasHrRole = true;
              break;
          }
      }

      return hasHrRole;
  }

}
