package datachecker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import datachecker.dao.entity.RelationalInfoEntity;
import datachecker.dao.entity.vo.TableRelationBySqlParam;
import datachecker.service.DataCheckerService;
import datachecker.service.SqlReaderService;

@RestController
@RequestMapping("/dbmatcher")
public class DataCheckerController {

    @Autowired
    private DataCheckerService dataCheckerService;

    @Autowired
    private SqlReaderService sqlReaderService;

    @GetMapping("/checkDataInconsistency")
    public void checkInconsistantData(@RequestParam String _id) throws Exception {
        dataCheckerService.start(_id);
    }

    @PostMapping("/getTableRelationBySql")
    public List<RelationalInfoEntity> getTableRelationBySql(
            @RequestBody TableRelationBySqlParam tableRelationBySqlParam) {
        return sqlReaderService.extractSql(tableRelationBySqlParam);
    }
}
