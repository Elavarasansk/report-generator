package datachecker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import datachecker.dao.dto.OracleDbDetailsEntity;
import datachecker.service.DatabaseProcessorService;

@RestController
@RequestMapping("/dbProcessor")
public class DatabaseProcessorController {

    @Autowired
    private DatabaseProcessorService databaseProcessorService;

    @PostMapping("/dbCheck")
    public String checkDatabaseDetails(@RequestBody OracleDbDetailsEntity oracleDbDetailsEntity) {
        return databaseProcessorService.checkDatabaseDetails(oracleDbDetailsEntity.getOracleHostName(),
                oracleDbDetailsEntity.getOraclePort(), oracleDbDetailsEntity.getOracleServiceId(),
                oracleDbDetailsEntity.getOracleUserName(), oracleDbDetailsEntity.getOraclePassword(),
                oracleDbDetailsEntity.getOracleSchema());
    }

    @GetMapping("/getMetaData")
    public void getMetaData() throws Exception {
        databaseProcessorService.getMetaData();
    }
}
