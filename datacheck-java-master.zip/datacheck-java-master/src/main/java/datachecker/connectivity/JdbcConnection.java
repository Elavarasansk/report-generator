package datachecker.connectivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import datachecker.dao.constants.DataCheckConstants;
import datachecker.dao.dto.ColumnRelationEntity;
import datachecker.dao.entity.MultipleMismatchDataEntity;
import datachecker.dao.entity.OracleDbConfigEntity;
import datachecker.dao.entity.SingleMismatchDataEntity;
import datachecker.dao.repository.MultipleMismatchDataRepository;
import datachecker.dao.repository.OracleDbConfigRepository;
import datachecker.dao.repository.SingleMismatchDataRepository;

@Service
public class JdbcConnection {

    @Value("${oracle.schema}")
    private String oracleSchema;

    @Value("${sql.selectsql}")
    private String selectSql;

    @Value("${sql.checkchildinparentsql}")
    private String checkChildInParentSQL;

    @Value("${sql.multijoinsql}")
    private String multiJoinSql;

    @Value("${sql.datacountsql}")
    private String dataCountSql;

    // JDBC driver name and database URL
    final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";

    @Autowired
    SingleMismatchDataRepository singleMismatchDataRepository;

    @Autowired
    MultipleMismatchDataRepository multipleMismatchDataRepository;

    @Autowired
    OracleDbConfigRepository oracleDbConfigRepository;

    Connection conn;

    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DataCheckConstants.PATTERN, Locale.ENGLISH);

    public void prepareConnStatement(String _id) {
        try {
            Optional<OracleDbConfigEntity> dbConfigDetailsValue = oracleDbConfigRepository.findById(new ObjectId(_id));
            if (dbConfigDetailsValue.isPresent()) {
                OracleDbConfigEntity dbConfigDetails = dbConfigDetailsValue.get();
                conn = dbConfigDetails.getDatabaseConnection(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void destroyConnection() {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void validateSingleDependencyParent(String childTableName, String parentTableName,
            ColumnRelationEntity childCol, List<SingleMismatchDataEntity> singleMismatchDataEntityList,
            String scheduleId) {
        String childColumnName = childCol.getColumnName();
        String parentAliasColumnName = childCol.getParentAliasName();

        String validateSql = String.format(checkChildInParentSQL, childColumnName, childTableName, childColumnName,
                parentAliasColumnName, parentTableName, childColumnName);

        List<String> differenceColList = new ArrayList<>();

        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet childResultSet = statement.executeQuery(validateSql);
            differenceColList = processResultSet(childColumnName, childResultSet);
            persistInDbSinglekeyField(childColumnName, parentAliasColumnName, childTableName, parentTableName,
                    differenceColList, singleMismatchDataEntityList, scheduleId);
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    String joinEquate = " %s.%s = %s.%s ";
    String columnNullValidate = "%s.%s is null ";

    public void validateMultiDependencyParent(String childTable, String parentTable,
            List<ColumnRelationEntity> childCol, List<MultipleMismatchDataEntity> multipleMismatchDataEntityList,
            String scheduleId) {

        String childTableName = oracleSchema + "." + childTable;
        String parentTableName = oracleSchema + "." + parentTable;

        String childColumnNames = childCol.stream().map(x -> (childTableName + "." + x.getColumnName()))
                .collect(Collectors.joining(", "));
        List<String> childColumnList = childCol.stream().map(ColumnRelationEntity::getColumnName)
                .collect(Collectors.toList());

        String joinCondition = childCol.stream().map(x -> String.format(joinEquate, childTableName, x.getColumnName(),
                parentTableName, x.getParentAliasName())).collect(Collectors.joining(" and "));
        String nullChecker = childCol.stream()
                .map(x -> String.format(columnNullValidate, parentTableName, x.getParentAliasName()))
                .collect(Collectors.joining(" and "));

        String validateSql = String.format(multiJoinSql, childColumnNames, childTableName, parentTableName,
                joinCondition, nullChecker);

        List<List<String>> differenceColList = new ArrayList<>();

        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet childResultSet = statement.executeQuery(validateSql);
            differenceColList = processResultSet(childColumnList, childResultSet);

            List<String> childColumnNameSet = childCol.stream().map(ColumnRelationEntity::getColumnName)
                    .collect(Collectors.toList());
            List<String> parentColumnNameSet = childCol.stream().map(ColumnRelationEntity::getParentAliasName)
                    .collect(Collectors.toList());
            persistInDbMultiplekeyField(childColumnNameSet, parentColumnNameSet, childTable, parentTable,
                    differenceColList, multipleMismatchDataEntityList, scheduleId);
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private List<String> processResultSet(String columnName, ResultSet childResultSet) {
        List<String> columList = new ArrayList<String>();
        try {
            while (childResultSet.next()) {
                String value = childResultSet.getString(columnName);
                columList.add(value);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return columList;
    }

    private List<List<String>> processResultSet(List<String> childColumnList, ResultSet childResultSet) {
        List<List<String>> columList = new ArrayList<>();
        try {
            while (childResultSet.next()) {
                List<String> value = childColumnList.stream().map(x -> {
                    try {
                        return childResultSet.getString(x);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    return x;
                }).collect(Collectors.toList());
                columList.add(value);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return columList;
    }

    private void persistInDbSinglekeyField(String childCol, String parentCol, String childTable, String parentTable,
            List<String> differenceColList, List<SingleMismatchDataEntity> singleMismatchDataEntityList,
            String scheduleId) {

        int tableDataCount = getTableDataCount(childTable);
        String currentDate = simpleDateFormat.format(new Date());
        SingleMismatchDataEntity smde = SingleMismatchDataEntity.builder().childColumnName(childCol)
                .parentColumnName(parentCol).childTable(childTable).parentTable(parentTable)
                .diffInconsistenceData(differenceColList).executionDate(currentDate).scheduleId(scheduleId)
                .tableDataCount(tableDataCount).build();

        singleMismatchDataRepository.save(smde);
        System.out.println("The single result is stored");
    }

    private void persistInDbMultiplekeyField(List<String> childCol, List<String> parentCol, String childTable,
            String parentTable, List<List<String>> differenceColList,
            List<MultipleMismatchDataEntity> multipleMismatchDataEntityList, String scheduleId) {

        int tableDataCount = getTableDataCount(childTable);
        String currentDate = simpleDateFormat.format(new Date());
        MultipleMismatchDataEntity mmde = MultipleMismatchDataEntity.builder().childColumnName(childCol)
                .parentColumnName(parentCol).childTable(childTable).parentTable(parentTable)
                .diffInconsistenceData(differenceColList).executionDate(currentDate).scheduleId(scheduleId)
                .tableDataCount(tableDataCount).build();

        multipleMismatchDataRepository.save(mmde);
        System.out.println("The multiple result is stored");
    }

    private int getTableDataCount(String tableName) {
        int count = 0;
        String countSql = String.format(dataCountSql, tableName);
        Statement statement;
        try {
            statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(countSql);
            while (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
}
