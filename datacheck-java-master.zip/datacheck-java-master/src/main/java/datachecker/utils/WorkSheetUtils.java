package datachecker.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Workbook;

import datachecker.dao.dto.ColumnRelationEntity;
import datachecker.dao.dto.ParentChildRelationEntity;
import datachecker.dao.entity.RelationalInfoEntity;

public class WorkSheetUtils {

    public static void makeListFromInput(List<RelationalInfoEntity> list, List<ParentChildRelationEntity> pcreMainList) {
        try {
            int readStartRow = 0;
            for (int counter = readStartRow; counter < list.size(); counter++) {
                List<ColumnRelationEntity> columnRelationEntityList = new ArrayList<>();
                String childTable = list.get(counter).getChildTable();
                String parentTable = list.get(counter).getParentTable();
                String childColumn = list.get(counter).getChildColumn();
                String parentColumn = list.get(counter).getParentColumn();
                
                
                ColumnRelationEntity columnRelationEntity = ColumnRelationEntity.builder().columnName(childColumn)
                        .parentAliasName(parentColumn).parentTableName(parentTable).build();
                columnRelationEntityList.add(columnRelationEntity);
                pcreMainList.add(ParentChildRelationEntity.builder().childTableName(childTable)
                        .columnRelationList(columnRelationEntityList).build());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }

  public static String getStringValue(Cell cell) {
    if (cell == null) {
      return "";
    }
    switch (cell.getCellType()) {
    case NUMERIC:
      return Double.toString(cell.getNumericCellValue());
    case STRING:
      return cell.getStringCellValue();
    case FORMULA:
      Workbook wb = cell.getSheet().getWorkbook();
      CreationHelper crateHelper = wb.getCreationHelper();
      FormulaEvaluator evaluator = crateHelper.createFormulaEvaluator();
      return getStringValue(evaluator.evaluateInCell(cell));
    case BOOLEAN:
      return Boolean.toString(cell.getBooleanCellValue());
    case ERROR:
      return "ERROR";
    case BLANK:
    default:
      return "";
    }
  }
}
