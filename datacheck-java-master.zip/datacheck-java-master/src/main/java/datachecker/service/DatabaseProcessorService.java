package datachecker.service;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import datachecker.dao.constants.DataCheckConstants;
import datachecker.dao.entity.OracleDbConfigEntity;
import datachecker.dao.entity.TableMetadataEntity;
import datachecker.dao.repository.OracleDbConfigRepository;
import datachecker.dao.repository.TableMetaDataRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DatabaseProcessorService {

    @Autowired
    private TableMetaDataRepository metaDataRepo;
    @Autowired
    private OracleDbConfigRepository dbConfigRepo;

    List<OracleDbConfigEntity> insertedDbConfigList = new ArrayList<OracleDbConfigEntity>();

    String state = DataCheckConstants.COMPLETE;

    public String getMetaData() throws Exception {

        insertedDbConfigList = getMetadataUncollectedDb();
        if (!state.equals(DataCheckConstants.INPROGRESS)) {
            insertedDbConfigList.stream().forEach(insertedDbConfig -> {
                if (insertedDbConfig.getIsDeleted()) {
                    return;
                }
                insertedDbConfig.setMetadataCollection(DataCheckConstants.INPROGRESS);
                dbConfigRepo.save(insertedDbConfig);
                state = DataCheckConstants.INPROGRESS;
                prepareMetadataCollection(insertedDbConfig);

            });
        }
        return "Inserted Metadata Successfully";

    }

    private void prepareMetadataCollection(OracleDbConfigEntity insertedDbConfig) {
        ArrayList<String> tableList = new ArrayList<String>();
        try (Connection conn = insertedDbConfig.getDatabaseConnection(true)) {
            if (Objects.nonNull(conn)) {
                DatabaseMetaData metaData = conn.getMetaData();
                ResultSet tableResultSet = metaData.getTables(null, insertedDbConfig.getOracleSchema(), "%",
                        DataCheckConstants.TYPES);
                while (tableResultSet.next()) {
                    tableList.add(tableResultSet.getString(DataCheckConstants.TABLE_NAME));
                }
                tableResultSet.close();
                List<String> newTableList = checkIfTableExist(tableList, insertedDbConfig.getId().toString());
                if (!newTableList.isEmpty()) {
                    getTableMetaData(newTableList, metaData, insertedDbConfig.getId().toString());
                }
                conn.close();
            }
            insertedDbConfig.setMetadataCollection(DataCheckConstants.COLLECTED);
            insertedDbConfig.setTableCount(tableList.size());
            dbConfigRepo.save(insertedDbConfig);
            state = DataCheckConstants.COMPLETE;
            if (!getMetadataUncollectedDb().isEmpty()) {
                getMetaData();
            }
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            return;
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }

    private List<OracleDbConfigEntity> getMetadataUncollectedDb() {

        List<OracleDbConfigEntity> dbConfigDetailsValue = dbConfigRepo
                .findAllByMetadataCollection(DataCheckConstants.NOTCOLLECTED);
        return dbConfigDetailsValue;
    }

    private List<String> checkIfTableExist(List<String> tableList, String _id) {
        List<String> newTables = new ArrayList<String>();
        for (String table : tableList) {
            TableMetadataEntity tableMetadataEntity = metaDataRepo.findByTableName(table);
            if (Objects.nonNull(tableMetadataEntity)) {
                List<String> dbIdList = tableMetadataEntity.getDbIdList();
                dbIdList.add(_id);
                tableMetadataEntity.setDbIdList(dbIdList);
                metaDataRepo.save(tableMetadataEntity);
            } else {
                newTables.add(table);
            }
        }
        return newTables;
    }

    private void getTableMetaData(List<String> tableList, DatabaseMetaData metaData, String _id) {
        tableList.stream().forEach(table -> {
            List<String> primaryKeyList = new ArrayList<String>();
            Map<String, String> columnMap = new HashMap<String, String>();
            Map<String, String> primaryKeyMap = new HashMap<String, String>();
            try {
                ResultSet primaryKeyResultSet = metaData.getPrimaryKeys(null, null, table);
                while (primaryKeyResultSet.next()) {
                    primaryKeyList.add(primaryKeyResultSet.getString(DataCheckConstants.COLUMN_NAME));
                }
                primaryKeyResultSet.close();
                ResultSet columnsResultSet = metaData.getColumns(null, null, table, null);
                while (columnsResultSet.next()) {
                    columnMap.put(columnsResultSet.getString(DataCheckConstants.COLUMN_NAME),
                            columnsResultSet.getString(DataCheckConstants.TYPE_NAME));
                }
                columnsResultSet.close();
                for (String primaryKey : primaryKeyList) {
                    primaryKeyMap.put(primaryKey, columnMap.get(primaryKey));
                }
                List<String> idList = new ArrayList<String>();
                idList.add(_id);
                TableMetadataEntity metaDataModel = TableMetadataEntity.builder().tableName(table)
                        .primaryKeyList(primaryKeyMap).columnList(columnMap).dbIdList(idList).build();
                metaDataRepo.save(metaDataModel);
            } catch (SQLException e) {
                log.error("Exception Occured while getting metaData from Oracle " + e.getMessage());
            }
        });
    }

    public String checkDatabaseDetails(String oracleHostName, String oraclePort, String oracleServiceId,
            String oracleUserName, String oraclePassword, String oracleSchema) {
        Connection conn = null;
        OracleDbConfigEntity oracleDbConfigEntity = OracleDbConfigEntity.builder().oracleHostName(oracleHostName)
                .oraclePort(oraclePort).oracleServiceId(oracleServiceId).oracleUserName(oracleUserName)
                .oraclePassword(oraclePassword).build();
        conn = oracleDbConfigEntity.getDatabaseConnection(false);
        if (Objects.nonNull(conn)) {
            boolean schemaCheck = checkIfSchemaExist(conn, oracleSchema);
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (schemaCheck) {
                return DataCheckConstants.DATABASE_VALID;
            } else {
                return DataCheckConstants.SCHEMA_INVALID;
            }
        }
        return DataCheckConstants.DATABASE_INVALID;
    }

    private boolean checkIfSchemaExist(Connection conn, String oracleSchema) {
        DatabaseMetaData metadata;
        List<String> schemaList = new ArrayList<String>();
        try {
            metadata = conn.getMetaData();
            ResultSet rs = metadata.getSchemas();
            while (rs.next()) {
                schemaList.add(rs.getString(1));
            }
            rs.close();
            if (schemaList.contains(oracleSchema)) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
