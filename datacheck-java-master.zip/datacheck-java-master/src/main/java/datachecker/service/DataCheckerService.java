package datachecker.service;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import datachecker.connectivity.JdbcConnection;
import datachecker.dao.constants.DataCheckConstants;
import datachecker.dao.dto.ColumnRelationEntity;
import datachecker.dao.dto.ParentChildRelationEntity;
import datachecker.dao.entity.ErListEntity;
import datachecker.dao.entity.MultipleMismatchDataEntity;
import datachecker.dao.entity.RelationalInfoEntity;
import datachecker.dao.entity.SchedulerConfigEntity;
import datachecker.dao.entity.SingleMismatchDataEntity;
import datachecker.dao.repository.ErListRepository;
import datachecker.dao.repository.MultipleMismatchDataRepository;
import datachecker.dao.repository.RelationalInfoRepository;
import datachecker.dao.repository.SchedulerConfigRepository;
import datachecker.dao.repository.SingleMismatchDataRepository;
import datachecker.utils.WorkSheetUtils;

@Service
public class DataCheckerService {

    @Value("${execution.result.server}")
    private String executionResultServer;

    @Value("${execution.result.endpoint}")
    private String executionResultEndpoint;

    @Autowired
    RelationalInfoRepository relationalInfoRepository;

    @Autowired
    JdbcConnection jdbcConnection;

    @Autowired
    SchedulerConfigRepository schedulerConfigRepository;

    @Autowired
    ErListRepository erListRepository;

    @Autowired
    SingleMismatchDataRepository singleMismatchDataRepository;

    @Autowired
    MultipleMismatchDataRepository multipleMismatchDataRepository;

    List<SingleMismatchDataEntity> singleMismatchDataEntityList = new ArrayList<>();
    List<MultipleMismatchDataEntity> multipleMismatchDataEntityList = new ArrayList<>();

    public void start(String _id) {
        System.out.println("Start Time --------------" + System.currentTimeMillis());
        long start = System.currentTimeMillis();

        Optional<SchedulerConfigEntity> schedulerConfigDetails = schedulerConfigRepository.findById(new ObjectId(_id));
        if (!schedulerConfigDetails.isPresent()) {
            return;
        }
        SchedulerConfigEntity schedulerConfigEntity = schedulerConfigDetails.get();
        jdbcConnection.prepareConnStatement(schedulerConfigEntity.getDbId());

        String ErListId = schedulerConfigEntity.getErListId();
        Optional<ErListEntity> erListDetails = erListRepository.findById(new ObjectId(ErListId));
        if (!erListDetails.isPresent()) {
            return;
        }

        ErListEntity erListData = erListDetails.get();
        List<String> relationInfoIdList = erListData.getRelationInfoIdList();
        relationInfoIdList.stream().forEach(id -> new ObjectId(id));

        List<RelationalInfoEntity> relationInfoList = (List<RelationalInfoEntity>) relationalInfoRepository
                .findAllById(relationInfoIdList);

        List<ParentChildRelationEntity> pcreMainList = new ArrayList<>();
        WorkSheetUtils.makeListFromInput(relationInfoList, pcreMainList);
        Map<String, List<ParentChildRelationEntity>> childBasedGroupedData = pcreMainList.stream()
                .collect(Collectors.groupingBy(ParentChildRelationEntity::getChildTableName, Collectors.toList()));

        List<SingleMismatchDataEntity> existingSingleMismatchEntity = singleMismatchDataRepository
                .findByScheduleId(_id);

        List<MultipleMismatchDataEntity> existingMultipleMismatchEntity = multipleMismatchDataRepository
                .findByScheduleId(_id);

        for (Entry<String, List<ParentChildRelationEntity>> indiviRecord : childBasedGroupedData.entrySet()) {
            String childTableName = indiviRecord.getKey();
            List<ColumnRelationEntity> columnList = indiviRecord.getValue().stream()
                    .flatMap(x -> x.getColumnRelationList().stream()).collect(Collectors.toList());

            Map<String, List<ColumnRelationEntity>> parentBasedGroupedValue = columnList.stream().filter(
                    entity -> !entity.getParentTableName().trim().equals("-") && !entity.getParentTableName().isEmpty())
                    .collect(Collectors.groupingBy(ColumnRelationEntity::getParentTableName, Collectors.toList()));

            for (Entry<String, List<ColumnRelationEntity>> childCol : parentBasedGroupedValue.entrySet()) {
                if (childCol.getValue().size() > 1) {
                    jdbcConnection.validateMultiDependencyParent(childTableName, childCol.getKey(), childCol.getValue(),
                            multipleMismatchDataEntityList, _id);
                    continue;
                }
                jdbcConnection.validateSingleDependencyParent(childTableName, childCol.getKey(),
                        childCol.getValue().get(0), singleMismatchDataEntityList, _id);
            }

        }
        deleteExisitingScheduleDetails(existingSingleMismatchEntity, existingMultipleMismatchEntity);
        sendExecutionDetails(_id);
        jdbcConnection.destroyConnection();
        long end = System.currentTimeMillis();
        System.out.println("Execution Finished:  Time Taken " + (end - start) + "ms");
    }

    private void deleteExisitingScheduleDetails(List<SingleMismatchDataEntity> existingSingleMismatchEntity,
            List<MultipleMismatchDataEntity> existingMultipleMismatchEntity) {

        List<String> singleMismatchIdList = existingSingleMismatchEntity.stream()
                .map(entity -> entity.getId().toString()).collect(Collectors.toList());
        singleMismatchDataRepository.deleteByIdIn(singleMismatchIdList);
        List<String> multipleMismatchIdList = existingMultipleMismatchEntity.stream()
                .map(entity -> entity.getId().toString()).collect(Collectors.toList());
        multipleMismatchDataRepository.deleteByIdIn(multipleMismatchIdList);
    }

    private void sendExecutionDetails(String scheduleId) {
        URL url;
        try {
            url = new URL(executionResultServer + executionResultEndpoint + "/" + scheduleId);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(DataCheckConstants.GET_METHOD);
            connection.setRequestProperty(DataCheckConstants.ACCEPT_CHARSET, DataCheckConstants.UTF8);
            int responseCode = connection.getResponseCode();
            System.out.println("GET Response Code :: " + responseCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
