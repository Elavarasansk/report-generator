package datachecker.service.sqlUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Getter;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.SubJoin;
import net.sf.jsqlparser.util.TablesNamesFinder;

/**
 * SqlTableFinder class extends TablesNamesFinder(JSqlParser class) is used to
 * get aliasName of table and joinlist
 * 
 * @author Hari Sankar R
 *
 */
@Getter
public class SqlTableFinder extends TablesNamesFinder {

    private Set<Join> joinList = new LinkedHashSet();
    private Set<Table> tableList = new LinkedHashSet();
    private Set<EqualsTo> equalsToExpressionList = new LinkedHashSet();
    private Map<String, String> aliasNameMap = new HashMap();
    private Map<String, List<EqualsTo>> tableJoinRelationMap = new HashMap();

    @Override
    public List<String> getTableList(Statement statement) {
        List<String> stringValueTableList = super.getTableList(statement);
        this.joinList.stream().filter(join -> Objects.nonNull(join.getOnExpression())).forEach(join -> {
            join.getOnExpression().accept(this);
        });
        getJoinFromExpression();
        return stringValueTableList;
    }

    @Override
    public void visit(PlainSelect plainSelect) {
        plainSelect.getFromItem().accept(this);

        if (Objects.nonNull(plainSelect.getJoins())) {
            for (Join join : plainSelect.getJoins()) {
                join.getRightItem().accept(this);
                this.joinList.add(join);
            }
        }
        if (Objects.nonNull(plainSelect.getWhere())) {
            plainSelect.getWhere().accept(this);
        }
    }

    @Override
    public void visit(SubJoin subjoin) {
        subjoin.getLeft().accept(this);
        for (Join join : subjoin.getJoinList()) {
            join.getRightItem().accept(this);
            this.joinList.add(join);
        }
    }

    @Override
    public void visit(Table tableName) {
        super.visit(tableName);
        tableList.add(tableName);
        if (Objects.nonNull(tableName.getAlias())) {
            aliasNameMap.put(tableName.getAlias().getName(), tableName.getName());
        }
    }

    @Override
    public void visit(EqualsTo equalsTo) {
        super.visit(equalsTo);
        if (equalsTo.getLeftExpression() instanceof Column && equalsTo.getRightExpression() instanceof Column) {
            Column leftColumn = (Column) equalsTo.getLeftExpression();
            Column rightColumn = (Column) equalsTo.getRightExpression();
            if (!leftColumn.getTable().getName().equals(rightColumn.getTable().getName())) {
                equalsToExpressionList.add(equalsTo);
            }
        }
    }

    public void getJoinFromExpression() {
        equalsToExpressionList.stream()
                .filter(equalsToExpression -> equalsToExpression.getLeftExpression() instanceof Column
                        && equalsToExpression.getRightExpression() instanceof Column)
                .forEach(equalsToExpression -> {
                    String leftTable = ((Column) equalsToExpression.getLeftExpression()).getTable().getName();
                    String rightTable = ((Column) equalsToExpression.getRightExpression()).getTable().getName();
                    String leftRightKey = leftTable + DataCheckConstants.TABLE_SET + rightTable;
                    String rightLeftKey = rightTable + DataCheckConstants.TABLE_SET + leftTable;
                    if (tableJoinRelationMap.containsKey(leftRightKey)) {
                        List<EqualsTo> existList = new ArrayList(tableJoinRelationMap.get(leftRightKey));
                        existList.add(equalsToExpression);
                        tableJoinRelationMap.put(leftRightKey, existList);
                    } else if (tableJoinRelationMap.containsKey(rightLeftKey)) {
                        List<EqualsTo> existList = new ArrayList(tableJoinRelationMap.get(rightLeftKey));
                        existList.add(equalsToExpression);
                        tableJoinRelationMap.put(rightLeftKey, existList);
                    } else {
                        tableJoinRelationMap.put(leftRightKey, Arrays.asList(equalsToExpression));
                    }
                });
    }

}
