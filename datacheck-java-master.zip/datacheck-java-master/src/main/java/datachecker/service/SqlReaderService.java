package datachecker.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ResponseStatusException;

import datachecker.dao.constants.DataCheckConstants;
import datachecker.dao.entity.RelationalInfoEntity;
import datachecker.dao.entity.TableMetadataEntity;
import datachecker.dao.entity.vo.TableComparison;
import datachecker.dao.entity.vo.TableRelationBySqlParam;
import datachecker.dao.repository.RelationalInfoRepository;
import datachecker.dao.repository.TableMetaDataRepository;
import datachecker.service.sqlUtils.SqlTableFinder;
import lombok.extern.slf4j.Slf4j;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.Select;

/**
 * SqlReaderService is used to find the primary table and child table from sql
 * query as input
 * 
 * @author Hari Sankar R
 */
@Service
@Slf4j
public class SqlReaderService {

    @Autowired
    private RelationalInfoRepository relationalInfoRepository;

    @Autowired
    private TableMetaDataRepository tableMetadataRepository;

    /**
     * extractTable is used to compare the table joins and get list of
     * tableComparsions
     * 
     * @param sql
     * @return list of table comparison
     * @throws JSQLParserException
     */
    public List<RelationalInfoEntity> extractSql(TableRelationBySqlParam tableRelationBySqlParam) {
        String inputSql = tableRelationBySqlParam.getSql().toUpperCase();
        String dbId = tableRelationBySqlParam.getDbId();
        if (StringUtils.isEmpty(inputSql) || StringUtils.isEmpty(dbId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Input Sql and DataBase details should not be Empty");
        }
        try {
            Statement statement = CCJSqlParserUtil.parse(inputSql.toUpperCase());
            if (!(statement instanceof Select)) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Please enter select statement");
            }
            Select selectStatement = (Select) statement;
            SqlTableFinder tablesNamesFinder = new SqlTableFinder();
            List<String> tableList = tablesNamesFinder.getTableList(selectStatement);
            log.info("Table List in the given sql" + tableList);
            Map<String, List<String>> primaryKeyMap = new HashMap();
            if (tablesNamesFinder.getTableJoinRelationMap().isEmpty()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No join condition in the sql query");
            }
            tableList.stream().forEach(tableName -> {
                getPrimaryKey(tableName, primaryKeyMap, dbId);
            });
            if (primaryKeyMap.size() != tableList.size()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Table data not found in the list");
            }
            List<TableComparison> tableComparisonList = tablesNamesFinder.getTableJoinRelationMap().entrySet().stream()
                    .map(entrySet -> {
                        return compareTwoTables(entrySet, tablesNamesFinder, primaryKeyMap);
                    }).collect(Collectors.toList());
            List<RelationalInfoEntity> relationalInfoEntityList = relativeInfoEntityMapper(tableComparisonList, dbId);
            if (CollectionUtils.isEmpty(relationalInfoEntityList)) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No Parent-Child relation in the given sql query");
            }
            storeRelativeInfoEntity(relationalInfoEntityList, dbId);
            return relationalInfoEntityList;
        } catch (JSQLParserException e) {
            log.error("Sql Parser Exception Occured " + e.getMessage());
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unable to parse the given sql");
        } catch (NullPointerException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Error in the given sql Please Check");
        }
    }

    /**
     * storeRelativeInfoEntity is used to store relative info data
     * 
     * @param relationalInfoEntityList
     * @param dbId
     */
    private void storeRelativeInfoEntity(List<RelationalInfoEntity> relationalInfoEntityList, String dbId) {
        List<RelationalInfoEntity> relationalInfoInsertValueList = relationalInfoEntityList.stream()
                .filter(relationalInfoEntity -> !isExists(relationalInfoEntity, dbId)).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(relationalInfoInsertValueList)) {
            relationalInfoRepository.insert(relationalInfoInsertValueList);
        }
    }

    /**
     * isExists method is used to check the relationalInfo value is already present
     * in mongoDb
     * 
     * @param relationalInfoEntity
     * @param dbId
     * @return true if data is present, false if it is not present
     */
    private boolean isExists(RelationalInfoEntity relationalInfoEntity, String dbId) {
        RelationalInfoEntity existRelationalInfoEntity = relationalInfoRepository
                .findValue(relationalInfoEntity.getParentTable(), relationalInfoEntity.getChildTable(),
                        relationalInfoEntity.getParentColumn(), relationalInfoEntity.getChildColumn())
                .stream().findFirst().orElse(null);
        return Objects.nonNull(existRelationalInfoEntity) && !StringUtils.isEmpty(existRelationalInfoEntity.getDbId())
                && existRelationalInfoEntity.getDbId().equals(dbId);
    }

    /**
     * compareTwoTables method is to process the joinSet of two tables in the sql
     * 
     * @param entrySet
     * @param tablesNamesFinder
     * @param primaryKeyMap
     * @return TableComparison entity contains relation
     */
    private TableComparison compareTwoTables(Entry<String, List<EqualsTo>> entrySet, SqlTableFinder tablesNamesFinder,
            Map<String, List<String>> primaryKeyMap) {
        List<EqualsTo> joinConditionList = entrySet.getValue();
        Map<String, Integer> primaryKeyComparisonMap = new HashMap();
        String[] tableList = entrySet.getKey().split(DataCheckConstants.TABLE_SET);
        String leftTableName = getTableName(tableList[0], tablesNamesFinder.getAliasNameMap());
        String rightTableName = getTableName(tableList[1], tablesNamesFinder.getAliasNameMap());
        Map<String, Set<String>> tableComparingColumn = new HashMap();
        List<String> conditionList = new ArrayList();
        joinConditionList.stream().forEach(joinCondition -> {
            updatePrimaryKeyComparisonMap(joinCondition, tablesNamesFinder, primaryKeyComparisonMap,
                    tableComparingColumn, conditionList, primaryKeyMap);
        });
        Set<String> leftcompareColumnList = tableComparingColumn.get(leftTableName);
        Set<String> rightcompareColumnList = tableComparingColumn.get(rightTableName);
        if (primaryKeyComparisonMap.get(leftTableName) < primaryKeyComparisonMap.get(rightTableName)) {
            return TableComparison.builder()
                    .primaryTable(leftTableName)
                    .secondaryTable(rightTableName)
                    .primaryTableColumnNames(rightcompareColumnList)
                    .secondaryTableColumnNames(leftcompareColumnList)
                    .isChecked(true)
                    .comparingCondition(conditionList).build();
        }
        TableComparison tableCompare = TableComparison.builder()
                .primaryTable(leftTableName)
                .secondaryTable(rightTableName)
                .remarks("Compared Columns are primary key for both Tables")
                .comparingCondition(conditionList).build();
        if (primaryKeyComparisonMap.get(leftTableName) > primaryKeyComparisonMap.get(rightTableName)) {
            tableCompare.setPrimaryTableColumnNames(leftcompareColumnList);
            tableCompare.setSecondaryTableColumnNames(rightcompareColumnList);
            tableCompare.setChecked(true);

        } else {
            tableCompare.setRemarks("Compared Columns are primary key for both Tables");
        }
        return tableCompare;
    }

    /**
     * updatePrimaryKeyComparisonMap is used to update the primaryKey comparison map
     * 
     * @param joinCondition
     * @param tablesNamesFinder
     * @param primaryKeyComparisonMap contains key as table and value as the number
     *                                of primary column used to join the two tables.
     * @param tableComparingColumn
     * @param conditionList
     * @param primaryKeyMap
     */
    private void updatePrimaryKeyComparisonMap(EqualsTo joinCondition, SqlTableFinder tablesNamesFinder,
            Map<String, Integer> primaryKeyComparisonMap, Map<String, Set<String>> tableComparingColumn,
            List<String> conditionList, Map<String, List<String>> primaryKeyMap) {
        if (joinCondition.getLeftExpression() instanceof Column
                && joinCondition.getRightExpression() instanceof Column) {
            Column leftColumn = (Column) joinCondition.getLeftExpression();
            Column rightColumn = (Column) joinCondition.getRightExpression();
            String leftTableName = getTableName(leftColumn.getTable().getName(), tablesNamesFinder.getAliasNameMap());
            String rightTableName = getTableName(rightColumn.getTable().getName(), tablesNamesFinder.getAliasNameMap());
            String leftColumnName = leftColumn.getColumnName();
            String rightColumnName = rightColumn.getColumnName();
            if (!Objects.equals(leftTableName, rightTableName)) {
                setColumnMap(leftTableName, leftColumnName, tableComparingColumn);
                setColumnMap(rightTableName, rightColumnName, tableComparingColumn);
                primaryKeyComparisonMap.put(leftTableName, 0);
                primaryKeyComparisonMap.put(rightTableName, 0);
                if (primaryKeyMap.get(leftTableName).contains(leftColumnName)) {
                    primaryKeyComparisonMap.put(leftTableName, primaryKeyComparisonMap.get(leftTableName) + 1);
                }
                if (primaryKeyMap.get(rightTableName).contains(rightColumnName)) {
                    primaryKeyComparisonMap.put(rightTableName, primaryKeyComparisonMap.get(rightTableName) + 1);
                }
                conditionList.add(leftTableName + DataCheckConstants.DOT + leftColumnName + DataCheckConstants.EQUAL
                                + rightTableName + DataCheckConstants.DOT + rightColumnName);
            }
        }
    }

    /**
     * setColumnMap used to parent and child table column set
     * 
     * @param tableName
     * @param columnName
     * @param tableComparingColumn
     */
    private void setColumnMap(String tableName, String columnName, Map<String, Set<String>> tableComparingColumn) {
        if (tableComparingColumn.containsKey(tableName)) {
            Set<String> existValue = new LinkedHashSet(tableComparingColumn.get(tableName));
            existValue.add(columnName);
            tableComparingColumn.put(tableName, existValue);
        } else {
            tableComparingColumn.put(tableName, Stream.of(columnName).collect(Collectors.toSet()));
        }
    }

    /**
     * getTableName method is used to get real table name from alias Name
     * 
     * @param tableAliasName
     * @param tablesNamesFinder
     * @return tableName
     */
    private String getTableName(String tableAliasName, Map<String, String> aliasNameMap) {
        if (aliasNameMap.containsKey(tableAliasName)) {
            return aliasNameMap.get(tableAliasName);
        }
        return tableAliasName;
    }

    /**
     * getPrimaryKey method is used to get primary key. This primary key is used in
     * primaryKeyMap param
     * 
     * @param table
     * @param primaryKeyMap
     * @param dbId
     */
    private void getPrimaryKey(String table, Map<String, List<String>> primaryKeyMap, String dbId) {
        TableMetadataEntity tableMetaData = tableMetadataRepository.findByTableName(table);
        List<String> primaryKeyList = new ArrayList();
        if (Objects.isNull(tableMetaData) || Objects.isNull(tableMetaData.getDbIdList())
                || !tableMetaData.getDbIdList().contains(dbId)) {
            return;
        }
        Map<String, String> primaryKeyObject = (Map<String, String>) tableMetaData.getPrimaryKeyList();
        primaryKeyList = primaryKeyObject.entrySet().stream().map(Entry::getKey).collect(Collectors.toList());
        primaryKeyMap.put(table, primaryKeyList);
    }

    /**
     * relativeInfoEntityMapper is used to map the values to RelationalInfoEntity
     * from TableComparison
     * 
     * @param tableComparisonList contains list of tableComparison
     * @param dbId
     * @return list of relationalInfoEntity
     */
    private List<RelationalInfoEntity> relativeInfoEntityMapper(List<TableComparison> tableComparisonList,
            String dbId) {
        List<RelationalInfoEntity> relationalInfoEntityList = new ArrayList();
        tableComparisonList.stream().filter(TableComparison::isChecked).forEach(tableComparison -> {
            List<RelationalInfoEntity> relationalEntityList = tableComparison.getComparingCondition().stream()
                    .map(comparingList -> {
                        String primaryTable = tableComparison.getPrimaryTable().trim();
                        String childTable = tableComparison.getSecondaryTable();
                        String childColumn = DataCheckConstants.EMPTY, parentColumn = DataCheckConstants.EMPTY;
                        String comparision[] = comparingList.split(DataCheckConstants.EQUAL);
                        for (String value : comparision) {
                            if (value.contains(primaryTable + DataCheckConstants.DOT)) {
                                parentColumn = value
                                        .replace(primaryTable + DataCheckConstants.DOT, DataCheckConstants.EMPTY)
                                        .trim();
                            } else {
                                childColumn = value
                                        .replace(childTable + DataCheckConstants.DOT, DataCheckConstants.EMPTY).trim();
                            }
                        }
                        return RelationalInfoEntity.builder()
                                .dbId(dbId)
                                .parentTable(primaryTable)
                                .childTable(childTable)
                                .parentColumn(parentColumn)
                                .childColumn(childColumn).build();
                    }).collect(Collectors.toList());
            relationalInfoEntityList.addAll(relationalEntityList);
        });
        return relationalInfoEntityList;
    }
}
