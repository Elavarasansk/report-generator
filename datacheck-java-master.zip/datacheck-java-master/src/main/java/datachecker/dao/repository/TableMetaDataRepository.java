package datachecker.dao.repository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import datachecker.dao.entity.TableMetadataEntity;

public interface TableMetaDataRepository extends MongoRepository<TableMetadataEntity, ObjectId> {

    TableMetadataEntity findByTableName(String tableName);

}
