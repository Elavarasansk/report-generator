package datachecker.dao.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import datachecker.dao.entity.SingleMismatchDataEntity;

public interface SingleMismatchDataRepository extends MongoRepository<SingleMismatchDataEntity, String> {

    List<SingleMismatchDataEntity> findByScheduleId(String _id);

    void deleteByIdIn(List<String> singleMismatchIdList);

}
