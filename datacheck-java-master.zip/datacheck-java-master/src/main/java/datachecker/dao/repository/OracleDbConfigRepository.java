package datachecker.dao.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import datachecker.dao.entity.OracleDbConfigEntity;

public interface OracleDbConfigRepository extends MongoRepository<OracleDbConfigEntity, ObjectId> {

    List<OracleDbConfigEntity> findAllByMetadataCollection(String string);

}
