package datachecker.dao.repository;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import datachecker.dao.entity.SchedulerConfigEntity;

public interface SchedulerConfigRepository extends MongoRepository<SchedulerConfigEntity, ObjectId> {

}