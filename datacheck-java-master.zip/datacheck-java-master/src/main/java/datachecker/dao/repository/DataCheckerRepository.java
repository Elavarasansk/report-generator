package datachecker.dao.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import datachecker.dao.entity.OracleDbConfigEntity;

public interface DataCheckerRepository extends MongoRepository<OracleDbConfigEntity, String> {
    
    
}
