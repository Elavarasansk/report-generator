package datachecker.dao.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import datachecker.dao.entity.RelationalInfoEntity;

public interface RelationalInfoRepository extends MongoRepository<RelationalInfoEntity, String> {
  
    List<RelationalInfoEntity> findAllByChildTable(List<String> childTable);
    
    List<RelationalInfoEntity> findAllByParentTable(List<String> parentTable);
    
    List<RelationalInfoEntity> findAllById(List<ObjectId> id);
    
    List<RelationalInfoEntity> findAll();

    @Query("{parentTable:'?0' , childTable : '?1', parentColumn:'?2' , childColumn:'?3'}")
    List<RelationalInfoEntity> findValue(String parentTable, String childTable, String parentColumn,
            String childColumn);
}
