package datachecker.dao.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import datachecker.dao.entity.MultipleMismatchDataEntity;

public interface MultipleMismatchDataRepository extends MongoRepository<MultipleMismatchDataEntity, String> {

    List<MultipleMismatchDataEntity> findByScheduleId(String _id);

    void deleteByIdIn(List<String> multipleMismatchIdList);

}
