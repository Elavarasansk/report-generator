package datachecker.dao.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ColumnRelationEntity {

    private String columnName;

    private String parentAliasName;
    
    private String parentTableName;

}
