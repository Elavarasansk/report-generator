package datachecker.dao.dto;

import lombok.Data;

@Data
public class OracleDbDetailsEntity {

    private String oracleHostName;

    private String oraclePort;

    private String oracleServiceId;

    private String oracleUserName;

    private String oraclePassword;

    private String oracleSchema;
}
