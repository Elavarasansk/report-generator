package datachecker.dao.constants;

public class DataCheckConstants {

    public static final String ORACLE_DB_CONFIG_DETAILS = "oracle_db_config_details";

    public static final String TABLE_METADATA = "table_metadata";

    public static final String RELATIONAL_INFO = "relational_info";

    public static final String SCHEDULER_DETAILS = "scheduler_details";

    public static final String DIC_OPERATION_QUERIES = "operation_queries";

    public static final String ERLIST_TABLE_DETAILS = "erList_table_details";

    public static final String SINGLE_KEY_INCONSISTENT_DATA = "single_key_inconsistent_data";

    public static final String MULTIPLE_KEY_INCONSISTENT_DATA = "multiple_key_inconsistent_data";

    public static final String DIC_EXECUTION_RESULT = "execution_result";

    public static final String CIPHER_KEY = "iwb__secret__key";

    public static final byte[] CIPHER_IV = "0000000000000000".getBytes();

    public static final String ALGORITHM = "AES";

    public static final String AES_CBS_PADDING = "AES/CBC/PKCS5Padding ";

    public static final String MD5 = "MD5";

    public static final String UTF8 = "utf-8";

    public static final String[] TYPES = { "TABLE" };

    public static final String COLUMN_NAME = "COLUMN_NAME";

    public static final String TYPE_NAME = "TYPE_NAME";

    public static final String TABLE_NAME = "TABLE_NAME";

    public static final String PATTERN = "MMM d yyyy hh:mm:ss a";

    public static final String GET_METHOD = "GET";

    public static final String ACCEPT_CHARSET = "Accept-Charset";

    public static final String COLLECTED = "COLLECTED";

    public static final String NOTCOLLECTED = "NOT COLLECTED";

    public static final String INPROGRESS = "IN PROGRESS";

    public static final String COMPLETE = "Complete";

    public static final String TABLE_SET = " -> ";

    public static final String DOT = ".";

    public static final String EMPTY = "";

    public static final String EQUAL = " = ";

    public static final String DATABASE_VALID = "DATABASEVALID";

    public static final String DATABASE_INVALID = "DATABASEINVALID";

    public static final String SCHEMA_INVALID = "SCHEMAINVALID";
}
