package datachecker.dao.entity;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = DataCheckConstants.DIC_OPERATION_QUERIES)
public class OperationQueriesEntity {

    @Id
    /*Unique Id*/
    private ObjectId id;

    /*Schedule Id*/
    private String schedulerId;

    /*Insert Query*/
    private List<String> insert;

    /*Delete Query*/
    private List<String> delete;

    /*Created Date*/
    private Date createdDate;

    /*Updated Date*/
    private Date updatedDate;

    /*Created User*/
    private String createdUser;

    /*Updated User*/
    private String updatedUser;
}
