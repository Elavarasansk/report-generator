package datachecker.dao.entity;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Builder
@Slf4j
@Data
@Document(collection = DataCheckConstants.ORACLE_DB_CONFIG_DETAILS)
public class OracleDbConfigEntity {

    @Id
    /* Unique Id */
    private ObjectId id;

    /* Oracle Host Name */
    private String oracleHostName;

    /* Oracle Port */
    private String oraclePort;

    /* Oracle Service Id */
    private String oracleServiceId;

    /* Oracle User Name */
    private String oracleUserName;

    /* Oracle Password */
    private String oraclePassword;

    /* Oracle Schema */
    private String oracleSchema;

    /* Serial Number */
    private int serialNumber;

    /* IsDeleted */
    private Boolean isDeleted;

    /* Db Type */
    private String dbType;

    /* Created Date */
    private Date createdDate;

    /* Updated Date */
    private Date updatedDate;

    /* Created User */
    private String createdUser;

    /* Updated User */
    private String updatedUser;

    /* Metadata Collection */
    private String metadataCollection;

    /* TableCount */
    private int tableCount;

    public Connection getDatabaseConnection(Boolean isEncrypted) {
        Connection conn = null;
        String userName = isEncrypted ? decryptData(this.oracleUserName) : this.oracleUserName;
        String password = isEncrypted ? decryptData(this.oraclePassword) : this.oraclePassword;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@" + oracleHostName + ":" + oraclePort + ":" + oracleServiceId, userName,
                    password);
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            e.printStackTrace();
        }
        return conn;
    }

    private String decryptData(String encrypted) {
        byte[] clearbyte = null;
        try {
            byte[] key = DataCheckConstants.CIPHER_KEY.getBytes(DataCheckConstants.UTF8);
            MessageDigest md = MessageDigest.getInstance(DataCheckConstants.MD5);
            byte[] digest = md.digest(key);
            SecretKeySpec skey = new SecretKeySpec(digest, DataCheckConstants.ALGORITHM);
            Cipher dcipher = Cipher.getInstance(DataCheckConstants.AES_CBS_PADDING);
            dcipher.init(Cipher.DECRYPT_MODE, skey, new IvParameterSpec(DataCheckConstants.CIPHER_IV));
            clearbyte = dcipher.doFinal(DatatypeConverter.parseHexBinary(encrypted));
        } catch (Exception e) {
            log.error("Exception Occured in Decryption " + e.getMessage());
        }
        return new String(clearbyte);
    }

}
