package datachecker.dao.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = DataCheckConstants.TABLE_METADATA)
public class TableMetadataEntity {

    @Id
    /*Unique Id*/
    private ObjectId id;
    
    /*Table Name*/
    private String tableName;
    
    /*Column List*/
    private Object columnList;
    
    /*Primary Key List*/
    private Object primaryKeyList;
    
    /*Db Id List*/
    private List<String> dbIdList;
}
