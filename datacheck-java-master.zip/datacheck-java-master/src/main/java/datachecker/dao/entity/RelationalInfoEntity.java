package datachecker.dao.entity;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = DataCheckConstants.RELATIONAL_INFO)
public class RelationalInfoEntity {

    @Id
    /*Unique Id*/
    private ObjectId id;
    
    /*child Table Name*/
    private String childTable;

    /*child Column*/
    private String childColumn;

    /*parent Table Name*/
    private String parentTable;

    /*parent Column*/
    private String parentColumn;
    
    /*Db Id*/
    private String dbId;

    /*Created Date*/
    private Date createdDate;

    /*Updated Date*/
    private Date updatedDate;

    /*Created User*/
    private String createdUser;

    /*Updated User*/
    private String updatedUser;
}
