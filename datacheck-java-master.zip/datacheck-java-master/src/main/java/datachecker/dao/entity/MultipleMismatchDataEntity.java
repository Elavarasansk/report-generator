package datachecker.dao.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = DataCheckConstants.MULTIPLE_KEY_INCONSISTENT_DATA)
public class MultipleMismatchDataEntity {

    @Id
    /* Unique Id */
    private ObjectId id;

    /* child Table Column Name */
    private List<String> childColumnName;

    /* parent Table Column Name */
    private List<String> parentColumnName;

    /* child Table Name */
    private String childTable;

    /* parent Table Name */
    private String parentTable;

    /* this field will be deprecated */
    private List<String> differenceColData;

    /* different Inconsistent data */
    private List<List<String>> diffInconsistenceData;

    /* Schedule Id */
    private String scheduleId;

    /* Execution Date */
    private String executionDate;

    /* Table data count */
    private int tableDataCount;
}
