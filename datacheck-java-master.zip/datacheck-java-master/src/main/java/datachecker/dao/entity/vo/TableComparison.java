package datachecker.dao.entity.vo;

import java.util.List;
import java.util.Set;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class TableComparison {
    private String primaryTable;
    private String secondaryTable;
    private Set<String> primaryTableColumnNames;
    private Set<String> secondaryTableColumnNames;
    private List<String> comparingCondition;
    private boolean isChecked;
    private String remarks;

}
