package datachecker.dao.entity;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = DataCheckConstants.ERLIST_TABLE_DETAILS)
public class ErListEntity {

    @Id
    /*Unique Id*/
    private ObjectId id;
    
    /*relational Info Name*/
    private String relationalInfoName;
    
    /*relational Info Id List*/
    private List<String> relationInfoIdList;
}
