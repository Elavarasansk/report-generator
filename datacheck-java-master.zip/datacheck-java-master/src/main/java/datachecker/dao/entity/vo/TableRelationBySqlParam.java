package datachecker.dao.entity.vo;

import lombok.Data;

@Data
public class TableRelationBySqlParam {
    private String dbId;
    private String sql;
}
