package datachecker.dao.entity;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import datachecker.dao.constants.DataCheckConstants;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Document(collection = DataCheckConstants.DIC_EXECUTION_RESULT)
public class ExecutionResultSchemaEntity {
   
    @Id
    /*Unique Id*/
    private ObjectId id;
    
    /*Schedule Id*/
    private String scheduleId;

    /*Success Rate*/
    private String successRate;

    /* Execution Date */
    private String executionDate;

    /*Query Date*/
    private String queryDate;
    
    /* Deleted Date*/
    private String deleteDate;

    /* IsDeleted */
    private boolean isDeleted;
    
    /*Created Date*/
    private Date createdDate;

    /*Updated Date*/
    private Date updatedDate;

    /*Created User*/
    private String createdUser;

    /*Updated User*/
    private String updatedUser;
}
