import np_dpr_list from './np_dpr_list.png';
import np_autocomplete from './np_autocomplete.png';
import np_module_cmb from './np_module_cmb.png'


export {
    np_dpr_list,
    np_autocomplete,
    np_module_cmb
};