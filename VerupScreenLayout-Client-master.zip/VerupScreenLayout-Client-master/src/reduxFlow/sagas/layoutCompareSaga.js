import { message as AntMessage } from 'antd';
import locale from '../../localization/verupLocalization';
import { put, call, takeLatest } from 'redux-saga/effects';
import { 
    GET_ALL_DPR_LIST_STATE,
    GET_DPR_INFO_STATE, 
    UPDATE_FORM_CONTROL_DATA_HANDLER_STATE,
    GET_HOME_VIEW_STATE,
    UPDATE_ERROR_CODE_STATE,
    CHAT_DRAWER_STATE,
    USER_VIEW_HANDLE_STATE,
    LOADING_HANDLER_STATE,
    LANG_HANDLER_STATE,
} from '../reducerActionTypes/layoutCompareReducerTypes';
import { 
    WATCH_GET_ALL_DPR_LIST,
    WATCH_GET_DPR_INFO,
    WATCH_UPDATE_FORM_CONTROL_DATA_HANDLER,
    WATCH_HOME_VIEW_CHANGE,
    WATCH_CHAT_DRAWER,
    WATCH_USER_VIEW_HANDLE,
    WATCH_LOADING_HANDLER,
    WATCH_LANG_HANDLER,
    WATCH_UPLOAD_HANDLE,
    WATCH_DELETE_HANDLE,
} from '../watcherActionTypes/layoutComapreWatchTypes';
import {
    GET_ALL_DPR_LIST_URL,
    GET_DPR_INFO_URL,
    UPDATE_FORM_CONTROL_URL,
    UPLOAD_HANDLE_URL,
    DELETE_HANDLE_URL
} from '../axios/endpointList'
import { serverWebAPI,getServer,postServer,putServer,deleteServer,deleteCDN } from '../axios/server';


export function* watchGetAllDprList () {
    try {
        yield takeLatest(WATCH_GET_ALL_DPR_LIST, function*() {
            const {data} = yield call(getServer,GET_ALL_DPR_LIST_URL);
            if(data.statusCode==='404') {
                const message = 'invalid_dpr'
                yield put({type : UPDATE_ERROR_CODE_STATE,message})
            } else if(data.statusCode==='500') {
                const message = 'internal_server_error'
                yield put({type : UPDATE_ERROR_CODE_STATE,message})
            } else {
                yield put({type: GET_ALL_DPR_LIST_STATE, data});
            }
        });
    } catch (error) {
        console.log('Error file fetching request...',error);
    }
}

export function* watchGetDprInfo () {
    try {
        yield takeLatest(WATCH_GET_DPR_INFO, function*(action) {
            const {data} = yield call(postServer,GET_DPR_INFO_URL,action.payload);
            if(data.statusCode==='404') {
                const message = 'invalid_dpr'
                yield put({type : UPDATE_ERROR_CODE_STATE,message})
            } else if(data.statusCode==='500') {
                const message = 'internal_server_error'
                yield put({type : UPDATE_ERROR_CODE_STATE,message})
            } else {
                yield put({type: GET_DPR_INFO_STATE, data});
            }
        });} catch (error) {
        console.log(error);
    }
}


export function* watchUpdateFormControlDataHandler() {
    try {
        yield takeLatest(WATCH_UPDATE_FORM_CONTROL_DATA_HANDLER, function*(action) {
            const {data} = yield call(postServer,UPDATE_FORM_CONTROL_URL,action.payload);
            if(data.statusCode==='404' || data.statusCode==='500') {
                AntMessage.error(locale.status_fail);
            } else {
                if(action.payload.status){
                    AntMessage.success(locale.status_success);
                }
                yield put({type: UPDATE_FORM_CONTROL_DATA_HANDLER_STATE, data});
            }
        });
    } catch(error) {
        console.log(error)
    }
}

export function* watchHomeViewChange(){
    try{
        yield takeLatest(WATCH_HOME_VIEW_CHANGE,function* (action) {
            const {view} = action;
            yield put({type: GET_HOME_VIEW_STATE,view});
        })
    } catch(error) {
        console.log(error)
    }
}

export function* watchChatDrawer(){
    try{
        yield takeLatest(WATCH_CHAT_DRAWER,function*(action){
            const data = action.payload;
            yield put({type:CHAT_DRAWER_STATE,data})
        })
    } catch(error) {
        console.log(error)
    }
}

export function* watchUserViewHandler() {
    yield takeLatest(WATCH_USER_VIEW_HANDLE, function*(action) {
        const data = action.userView;
        yield put({type:USER_VIEW_HANDLE_STATE,data})
    });
};

export function* watchLoadingHandler() {
    yield takeLatest(WATCH_LOADING_HANDLER, function*() {
    yield put({type:LOADING_HANDLER_STATE});
    });
}

export function* watchLangHandler() {
    yield takeLatest(WATCH_LANG_HANDLER, function*(action) {
    const {lang} = action;
    yield put({type:LANG_HANDLER_STATE,lang});
    });
}

export function* watchUploadHandle() {
    try {
        yield takeLatest(WATCH_UPLOAD_HANDLE, function*(action) {
            let payload = {
                request : {
                    method : 'post',
                    url : '/upload',
                    data : action.payload
                }
            }
            const {data} = yield call(postServer,UPLOAD_HANDLE_URL,action.payload);
            if(data.statusCode==='404' || data.statusCode==='500') {
                AntMessage.error(locale.upload_fail);
            } else {
                data.redirect  = true;
                yield put({type:GET_DPR_INFO_STATE, data});
                AntMessage.success(locale.upload_success);
            }
        });
    } catch(error) {
        console.log(error);
    }
}

export function* watchDeleteHandle() {
    try {
        yield takeLatest(WATCH_DELETE_HANDLE, function*(action) {
            let payloadCDN = {
                request : {
                    method : 'delete',
                    url : '/delete',
                    data : action.payload
                }
            }
            let payload = {
                request : {
                    method : 'post',
                    url : '/upload',
                    data : action.payload.data
                }
            }
            yield call(deleteCDN, DELETE_HANDLE_URL,action.payload);
            const {data} = yield call(postServer,UPLOAD_HANDLE_URL, action.payload.data);
            if(data.statusCode==='404' || data.statusCode==='500') {
                AntMessage.error(locale.delete_fail);
            } else {
                data.redirect  = true;
                yield put({type:GET_DPR_INFO_STATE, data});
                AntMessage.success(locale.delete_success);
            }
        });
    } catch(error) {
        console.log(error);
    }
}