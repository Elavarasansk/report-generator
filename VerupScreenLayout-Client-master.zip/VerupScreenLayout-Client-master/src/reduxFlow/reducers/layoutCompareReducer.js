import { 
    GET_ALL_DPR_LIST_STATE,
    GET_DPR_INFO_STATE, 
    UPDATE_FORM_CONTROL_DATA_HANDLER_STATE,
    GET_HOME_VIEW_STATE,
    UPDATE_ERROR_CODE_STATE,
    CHAT_DRAWER_STATE,
    USER_VIEW_HANDLE_STATE,
    LOADING_HANDLER_STATE,
    LANG_HANDLER_STATE,
} from '../reducerActionTypes/layoutCompareReducerTypes';
    
    const status = {
        notYetStarted : 0,
        pending : 0,
        reviewedCount:0
    }

let initalState = {
    allDprList: {
        CAM : [],
        CBM: [],
        CCM : [],
        CFM : [],
        COM : [],
        dprGridList : {
            CAM : [],
            CBM : [],
            CCM : [],
            CFM : [],
            COM : []

        }
    },
    gridData: [],
    overallStatus: {
        ownForms:status,
        sharedForms:status,
        overAll:status
    },
    imageSource: [],
    slideViewGridList: [],
    filePaths: [],
    dprName : '',
    moduleName : '',
    currentView : 'info',
    errorMessage : 'no_selected_dpr',
    isChatDrawerOpen : false,
    currentChatValue : [],
    userType : false, // true - dev-View
    isLoading : false,
    lang : 'ja'
}

export default function screenShotCompare(state = initalState, action) {
    const {type,data} = action;
    switch(type) {
        case GET_DPR_INFO_STATE: 
            let gridList = [];
            let {status} = data;
            status.overAll={
                notYetStarted :  status.ownForms.notYetStarted + status.sharedForms.notYetStarted,
                pending :  status.ownForms.pending + status.sharedForms.pending,
                reviewedCount :  status.ownForms.reviewedCount + status.sharedForms.reviewedCount
            }
            data.fileNameList.forEach((item, index) => {
                gridList.push({'key': index, 'file_name' : item, 'ownDprName' : data.gridData[index].targetDprName, 'caption' : data.imageSource[index].formCaption});
            });
            return {
                ...state,
                gridData : data.gridData,
                overallStatus : data.status,
                dprName : data.dprName,
                moduleName : data.module,
                currentView : state.userType ? data.redirect ? 'screenshot':'dprInfo' : 'screenshot',
                slideViewGridList : gridList,
                filePaths : data.filePathList,
                imageSource : data.imageSource,
                dataSource : data,
                isLoading : false
            };
        case GET_ALL_DPR_LIST_STATE:
            return {
                ...state,
                allDprList : data,
                isLoading : false
            }
        case UPDATE_FORM_CONTROL_DATA_HANDLER_STATE:
            let updateStatus = data.status;
            updateStatus.overAll={
                notYetStarted :  updateStatus.ownForms.notYetStarted + updateStatus.sharedForms.notYetStarted,
                pending :  updateStatus.ownForms.pending + updateStatus.sharedForms.pending,
                reviewedCount :  updateStatus.ownForms.reviewedCount + updateStatus.sharedForms.reviewedCount
            }
            return {
            ...state,
                imageSource : data.imageSource,
                overallStatus : updateStatus,
                gridData : data.gridData,
                isLoading : false
            }
        case GET_HOME_VIEW_STATE:
            return {
                ...state,
                currentView : action.view
            }
        case UPDATE_ERROR_CODE_STATE:
            return{
                ...state,
                currentView : 'info' ,
                errorMessage : action.message,
                isLoading : false
            }
        case CHAT_DRAWER_STATE:
            return{
                ...state,
                isChatDrawerOpen : data.isChatDrawerOpen,
                currentChatValue : data.currentChatValue?data.currentChatValue:state.currentChatValue
            }    
        case USER_VIEW_HANDLE_STATE:
            return{
                ...state,
                userType : data
            }
        case LOADING_HANDLER_STATE:
            return {
                ...state,
                isLoading : true
            }
        case LANG_HANDLER_STATE:
            return{
                ...state,
                lang : action.lang
            }
        default:
            return state;
    }
}
