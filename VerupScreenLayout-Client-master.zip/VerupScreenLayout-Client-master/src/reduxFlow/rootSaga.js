import { all } from 'redux-saga/effects';
import { 
  watchGetAllDprList,
  watchGetDprInfo,
  watchHomeViewChange,
  watchUpdateFormControlDataHandler,
  watchChatDrawer,
  watchUserViewHandler,
  watchLoadingHandler,
  watchLangHandler,
  watchUploadHandle,
  watchDeleteHandle
}  from './sagas/layoutCompareSaga';


export default function* rootSaga() {
  yield all([
    watchGetAllDprList(),
    watchGetDprInfo(),
    watchHomeViewChange(),
    watchUpdateFormControlDataHandler(),
    watchChatDrawer(),
    watchUserViewHandler(),
    watchLoadingHandler(),
    watchLangHandler(),
    watchUploadHandle(),
    watchDeleteHandle(),
  ]);
}
