import { combineReducers } from 'redux';
import screenShotCompare from './reducers/layoutCompareReducer';



export default combineReducers({
  screenShotCompare
});
