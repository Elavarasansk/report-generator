import axios from 'axios';

const baseURL = "http://192.168.57.29:8082/"

const axiosBase = axios.create({
    baseURL,
    responseType: "json"
});

const axiosFileBase = axios.create({
    baseURL,
    responseType: "blob"
})

const axiosStringBase = axios.create({
    baseURL,
    responseType: "text"
})

const CDNBase = axios.create({
    baseURL : "http://192.168.57.30/cdn/",
    responseType: "json"
})

const buildFormData = multiPartData => {
    let formData = new FormData();
    for (const name of multiPartData) {
        formData.append(name, request[name]);
    }
    return formData;
}

export const getServer = async (url) => {
        return await axiosBase.get(url).catch(errorHandler)
}

export const postServer = async (url, payload) => {
    if (payload)
        return await axiosBase.post(url, payload).catch(errorHandler)
    else
        return await axiosBase.post(url).catch(errorHandler)
}

export const putServer = async (url, payload) => {
    if (payload)
        return await axiosBase.put(url, payload).catch(errorHandler)
    else
        return await axiosBase.put(url).catch(errorHandler)
}

export const deleteServer = async (url, param) => {
    if (param)
        return await axiosBase.delete(url, param).catch(errorHandler)
    else
        return await axiosBase.delete(url).catch(errorHandler)
}

export const getFile = async (url) => {
    return await axiosFileBase.get(url).catch(errorHandler)
}

export const postFile = async (url, payload) => {
    multiPartData = buildFormData(payload.request.formData);
    return await axiosFileBase.post(url, param)
}

export const putFile = async (url, payload) => {
    multiPartData = buildFormData(payload.request.formData);
    return await axiosFileBase.put(url, param)
}

export const getString = async (url) => {
    return await axiosStringBase.get(url).catch(errorHandler)
}

export const putString = async (url, payload) => {
    if (payload)
        return await axiosStringBase.put(url, payload).catch(errorHandler)
    else
        return await axiosStringBase.put(url).catch(errorHandler)
}

export const postString = async (url, payload) => {
    if (payload)
        return await axiosStringBase.post(url, payload).catch(errorHandler)
    else
        return await axiosStringBase.post(url).catch(errorHandler)
}

export const deleteCDN = async (url, param) => {
    return await CDNBase.delete(url, param).catch(errorHandler)
}

const errorHandler = (error) => {
    console.log('From Error Handler', error)
    const response = {
        data: {
            statusCode: '500'
        }
    }
    return response
}
