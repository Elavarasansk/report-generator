export const GET_ALL_DPR_LIST_URL = 'getAllDprData';
export const GET_DPR_INFO_URL = 'getDprInfo';
export const UPDATE_FORM_CONTROL_URL = 'updateFormControl';
export const UPLOAD_HANDLE_URL = "upload"
export const DELETE_HANDLE_URL =  'delete';