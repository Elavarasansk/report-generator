import LocalizedStrings from 'react-localization';
import language from './multilingual.json';

let verupLocalization = new LocalizedStrings(language);

export default verupLocalization