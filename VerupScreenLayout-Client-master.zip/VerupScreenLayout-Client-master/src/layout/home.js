import React from 'react'
import {connect} from 'react-redux';
import { Spin, Icon } from 'antd';
import locale from '../localization/verupLocalization';
import NavigationPanel from '../components/navigationPanel';
import '../styles/home.css'
import DPRInfoCard from '../components/dprInfoCard';
import ScreenshotCompare from '../components/screenshotCompare';
import InfoCard from '../components/infoCard';
import ApplicationTour from '../components/tour';
import { 
    WATCH_GET_DPR_INFO,
    WATCH_HOME_VIEW_CHANGE
} from '../reduxFlow/watcherActionTypes/layoutComapreWatchTypes';
class Home extends React.Component{
    constructor(props){
        super(props)
        this.state={ 
            imagepreview : 'listView',
            openTour : false
        }
    }
   
    componentDidMount = () => {
        locale.setLanguage(this.props.lang);
    }

    render(){
        const {imagepreview} = this.state;
        const {changeHomeView} = this.props;
        const {currentView,isLoading} = this.props.home;
        const antIcon = <Icon type="loading" style={{fontSize : 50}} spin />
        return(
            <React.Fragment>
            <ApplicationTour isTourOpen = {this.state.openTour} onTourClose={()=>this.setState({openTour:false})}/>
            <div className="container-fluid mt-5">
                <Spin indicator={antIcon} spinning={isLoading}>
                <div className="row mt-3 mb-3 mx-3">
                    <NavigationPanel  currentView={currentView} changePreviewStyle={(style)=> this.setState({imagepreview: style})} openhelp={()=>this.setState({openTour:true})}/>
                </div>
                <div className="row mx-3" style={{height:'85%'}}>
                {currentView === 'dprInfo'?<DPRInfoCard openScreenshotComapre={()=>changeHomeView('screenshot')}/>
                                            :currentView === 'screenshot'?<ScreenshotCompare previewStyle = {imagepreview} openDprInfo={()=>changeHomeView('dprInfo')}/>
                                            :<InfoCard/>
                                            }
                                            
                </div>
            </Spin>
            </div>
            </React.Fragment>
        )
    }
};

const mapStateToProps = (state) => {
    return {
        home: state.screenShotCompare,
        lang: state.screenShotCompare.lang
    };
  };
  
  const mapDispatchToProps = (dispatch) => {
    return {
        getDprInfo: () => dispatch({ type: WATCH_GET_DPR_INFO }),
        changeHomeView : view => dispatch({type:WATCH_HOME_VIEW_CHANGE,view})
    };
  };

export default connect(mapStateToProps,mapDispatchToProps) (Home);