import React, { Component } from 'react';
import { Route, Switch, HashRouter, Redirect } from 'react-router-dom';
import App from './app.js';
import Home from './layout/home.js';

class Navigator extends Component {

  render() {
    return (
      <HashRouter>
          <App>
            <Switch>
              <Route path='/' exact render={() => { return <Redirect to='/home' /> }} />
              <Route path='/home' component={Home} />
            </Switch>
          </App>
      </HashRouter>
    );
  }
}
export default Navigator;