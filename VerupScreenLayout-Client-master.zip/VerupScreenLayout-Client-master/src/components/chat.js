import React from 'react'
import { Drawer, TextArea, Callout, Code } from '@blueprintjs/core';
import {connect} from 'react-redux'
import{Input, Button, Avatar} from 'antd'
import locale from '../localization/verupLocalization';
import {WATCH_UPDATE_FORM_CONTROL_DATA_HANDLER,WATCH_CHAT_DRAWER} from '../reduxFlow/watcherActionTypes/layoutComapreWatchTypes';
import '../styles/comments.css'
import { timingSafeEqual } from 'crypto';

const commentListStyle = {overflowY:'auto', scrollBehavior:'smooth'};

class ChatDrawer extends React.Component{

    state={
        chatInput : ''
    }

    closeDrawer = () =>{
        const{openChatDrawer} = this.props
        const payload = {
            isChatDrawerOpen : false
        }
        openChatDrawer(payload)
    };
    
    addComment = () =>{
        const {chatInput} = this.state;
        const {screenShotCompare,updateFormControlDataHandler} = this.props;
        const {dprName, moduleName} = screenShotCompare;   
        const {fileName,filePath}= this.props.screenShotCompare.currentChatValue;
        const date = new Date();
        const payload = {
            comment : {
                name : 'Jess',
                date : date.toLocaleDateString() + ' ' + date.toLocaleTimeString(),
                message : chatInput
            },
            dprName,
            fileName,
            filePath,
            moduleName   
        }
        updateFormControlDataHandler(payload);
        this.setState({chatInput:''});
    }

    render(){
        const {chatInput} = this.state;
        const {currentChatValue,imageSource,isChatDrawerOpen} = this.props.screenShotCompare;      
        return(
            <Drawer style={{width:360}} isOpen={isChatDrawerOpen} canOutsideClickClose={false} onClose={this.closeDrawer} icon = "chat" isCloseButtonShown={true} title={locale.discussion} className="bp3-dark">
                <div className="m-2  h-100">
                    <div className="d-flex flex-column-reverse h-100">
                        <div className="d-flex mt-1">
                            <Button type="primary" className="ml-auto" onClick={this.addComment}>{locale.comment}</Button>
                        </div>
                        <TextArea value={chatInput} style={{height:120}} id='comment-input' intent="primary" large ={true} onChange={()=>this.setState({chatInput : event.target.value})}/>
                        <CommentsList value = {imageSource.filter(item => item.filePath === currentChatValue.filePath)[0]}/>
                    </div>
                </div>
            </Drawer>
        )
    }
}

class CommentsList extends React.Component{

    constructor(props){
        super(props)
        this.commentList = React.createRef();
    }

    render(){

        function updateScroll(){
            this.commentList.current.scrollTop = this.commentList.current.scrollHeight;
        }

        setTimeout(updateScroll.bind(this),100);
        const {comments} = this.props.value;
        const messages = comments.map((comment,index) =>(
            <Callout key={index} className="my-1" icon="comment" title={comment.name} intent="warning">
              {comment.message}
              <p className="mt-1"><Code>{comment.date}</Code></p>
             </Callout>
         ))
        return(
            <div ref={this.commentList} id='comment-list' className="d-flex flex-column" style={commentListStyle}>
                {messages}
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        screenShotCompare : state.screenShotCompare
    }
}

const mapDispatchToProps = dispatch => {
    return {
        updateFormControlDataHandler : payload => dispatch({type: WATCH_UPDATE_FORM_CONTROL_DATA_HANDLER, payload}),
        openChatDrawer : payload => dispatch({type:WATCH_CHAT_DRAWER, payload})
    };
};

export default connect(mapStateToProps,mapDispatchToProps)(ChatDrawer)