import React, { Component } from 'react';
import { Card, Button } from 'react-bootstrap';
import { Select, Input, Button as AntButton, Radio, Modal } from 'antd';
import { Chip } from '@material-ui/core'
import { Card as BCard } from '@blueprintjs/core';
import { connect } from 'react-redux';
import locale from '../localization/verupLocalization';
import ListView from '../components/listView';
import SlideView from '../components/slideView';
import ChatDrawer from './chat';
import {
    WATCH_UPDATE_FORM_CONTROL_DATA_HANDLER,
    WATCH_CHAT_DRAWER,
    WATCH_LOADING_HANDLER,
    WATCH_UPLOAD_HANDLE,
    WATCH_DELETE_HANDLE
} from '../reduxFlow/watcherActionTypes/layoutComapreWatchTypes';


const status = ['ALL', 'NOT YET STARTED', 'PENDING', 'REVIEWED'];
const formStatusList = ['NOT YET STARTED', 'PENDING', 'REVIEWED'];
const ownership = ['ALL', 'OWN FORM', 'SHARED FORM'];

class screenshotCompare extends Component {
    constructor(props) {
        super(props);
        this.paginationItem = [];
        this.state = {
            selectedIndex: 0,
            imageDataSource: [],
            listViewImageSource: [],
            isLoading: false,
            searchkey: '',
            selectKey: status[0],
            radioKey: ownership[0],
            expand: false,
            slideViewGridData: []
        };
    }

    static getDerivedStateFromProps(props, state) {
        let imageSource = props.screenShotCompare.imageSource;
        if (state.imageDataSource !== imageSource) {
            return {
                ...state,
                imageDataSource: imageSource,
                listViewImageSource: imageSource,
                slideViewGridData: props.screenShotCompare.slideViewGridList
            }
        } else {
            return {
                ...state
            }
        }
    }

    paginationHandler = (page, filePath, text, view) => {
        let payload = [];
        const dataSource = view == 'list' ? this.state.listViewImageSource : this.props.screenShotCompare.imageSource;
        dataSource.forEach(item => {
            const currentPage = page - 1;
            const { list, slide } = item.activeIndex;
            if (item.filePath === filePath) {
                if (view === 'list') {
                    if (text === 'v36') {
                        list.v36Index = currentPage;
                    } else {
                        list.v40Index = currentPage;
                    }
                } else {
                    if (text === 'v36') {
                        slide.v36Index = currentPage;
                    } else {
                        slide.v40Index = currentPage;
                    }
                }
            }
            payload.push(item);
        });
        this.setState({ listViewImageSource: payload });
    }

    updateFormControlDataHandler = (status, value) => {
        const { dprName, moduleName } = this.props.screenShotCompare;
        const payload = {
            status,
            dprName,
            moduleName,
            fileName: value.fileName,
            filePath: value.filePath
        }
        this.props.loadingHandler();
        this.props.updateFormControlDataHandler(payload);
    }

    filterHandler = (value, type) => {
        const { selectKey, radioKey, searchkey } = this.state;
        if (type === 'SELECT') {
            let response = this.getSelectResponse(value, radioKey, searchkey);
            this.setState({
                listViewImageSource: response,
                selectKey: value
            });
        } else if (type === 'RADIO') {
            let response = this.getRadioResponse(selectKey, value, searchkey);
            this.setState({
                listViewImageSource: response,
                radioKey: value
            });
            let slideViewData = this.filterOwnership(this.props.screenShotCompare.slideViewGridList, value);
            this.setState({ slideViewGridData: slideViewData, selectedIndex: 0 });
        } else {
            let response = this.getSearchResponse(selectKey, radioKey, value);
            this.setState({
                listViewImageSource: response,
                searchkey: value
            })
        }
    }

    filterDataHandler = (value) => {
        let filterResult = this.state.imageDataSource;
        if (value !== status[0]) {
            filterResult = filterResult.filter(item => (item.formStatus ? item.formStatus.toUpperCase() : formStatusList[0]) === value);
        }
        return filterResult;
    }

    filterOwnership = (resource, value) => {
        const { dprName } = this.props.screenShotCompare;
        let response = [];
        switch (value) {
            case ownership[0]:
                response = resource;
                break;
            case ownership[1]:
                response = resource.filter(item => item.ownDprName.toUpperCase() === dprName.toUpperCase());
                break;
            case ownership[2]:
                response = resource.filter(item => item.ownDprName.toUpperCase() !== dprName.toUpperCase());
                break;
        }
        return response;
    }

    uploadHandle = payload => {
        const { dprName, moduleName } = this.props.screenShotCompare;
        payload.dprName = dprName;
        payload.moduleName = moduleName;
        this.props.loadingHandler();
        this.props.uploadHandle(payload);
    }

    deleteHandler = async(file, filePath) => {
        const { confirm } = Modal;
        const { dprName, moduleName } = this.props.screenShotCompare;
        const payload = {
            params: {
                filePath: file
            },
            data: {
                dprName,
                moduleName,
                filePath,
                imagePath: file,
                mode: 'delete'
            }
        }
        let deleteConfimation = new Promise((resolve, reject) => {
            confirm({
                title: locale.delete_confirmation_title,
                content: <p style={{ lineHeight: 2 }}>{locale.delete_confirmation_content}</p>,
                onOk() {
                    return resolve("delete");
                },
                onCancel() {
                    return reject("cancel");
                },
                cancelText : locale.cancel_text
            });
        });
        await deleteConfimation;
        this.props.loadingHandler();
        this.props.deleteHandler(payload);
    }

    getSearchResponse(selectKey, radioKey, value) {
        let response = this.getFilterData(selectKey);
        response = this.filterOwnership(response, radioKey);
        response = this.applyFilter(response, value);
        return response;
    }

    getRadioResponse(selectKey, value, searchkey) {
        let response = this.getFilterData(selectKey);
        response = this.filterOwnership(response, value);
        if (searchkey) {
            response = this.applyFilter(response, searchkey);
        }
        return response;
    }

    getSelectResponse(value, radioKey, searchkey) {
        let response = this.getFilterData(value);
        response = this.filterOwnership(response, radioKey);
        if (searchkey) {
            response = this.applyFilter(response, searchkey);
        }
        return response;
    }

    applyFilter(response, value) {
        return response.filter(item => item.formCaption[locale.getLanguage()].toUpperCase().search(value.toUpperCase()) !== -1);
    }

    getFilterData(value) {
        return this.filterDataHandler(value);
    }

    render() {
        const { Search } = Input;
        const { imageSource, dprName, userType } = this.props.screenShotCompare;
        const { openChatDrawer } = this.props;
        const { expand, listViewImageSource, slideViewGridData } = this.state;
        const statusLocale = [locale.all, locale.not_yet_started_cmb, locale.pending_cmb, locale.reviewed_cmb];
        const ownershipLocale = [locale.all, locale.own_form, locale.shared_form];
        const styles = {
            cardHeader: { backgroundColor: '#d9d9d9', borderRadius: '8px' },
            select: { width: 170, visibility: userType ? 'visible' : 'hidden' },
            userView: { visibility: userType ? 'visible' : 'hidden' },
            listView: { overflowY: 'auto', height: "70vh" }
        }
        return (
            <div className="w-100 h-100">
                <BCard elevation={1} style={{ borderRadius: 10 }}>
                    <Card.Header style={styles.cardHeader}>
                        <div className="d-flex">
                            <Button size="sm" className="mr-2" variant="outline-secondary" onClick={this.props.openDprInfo} hidden={!userType} >{locale.dashboard}</Button>
                            <div className="d-flex" hidden={this.props.previewStyle !== 'listView'}>
                                <Search style={{ width: 280 }} placeholder={locale.filter_placeholder} enterButton onChange={event => this.filterHandler(event.target.value, 'SEARCH')} />
                                <Select style={styles.select} className="ml-2" defaultValue={status[0]} onSelect={(value) => { this.filterHandler(value, 'SELECT') }} >
                                    {status.map((value, index) => (<Select.Option key={value} value={value}>{statusLocale[index]}</Select.Option>))}
                                </Select>
                            </div>
                            <Chip variant="outlined" label={locale.layout_comparison_title} color="primary" className="mx-auto font-weight-bold" hidden={userType}></Chip>
                            <div className="ml-auto" hidden={!userType && this.props.previewStyle !== 'listView'}>
                                <Radio.Group defaultValue={ownership[0]} buttonStyle="solid" onChange={(e) => this.filterHandler(e.target.value, 'RADIO')} style={styles.userView}>
                                    {ownership.map((value, index) => (<Radio.Button key={value} value={value}>{ownershipLocale[index]}</Radio.Button>))}
                                </Radio.Group>
                                <AntButton className="ml-2" icon={expand ? "shrink" : "arrows-alt"} hidden={this.props.previewStyle !== 'listView'} title={expand ? locale.collapse : locale.expand} onClick={() => this.setState({ expand: !expand })} />
                            </div>
                        </div>
                    </Card.Header>
                    {imageSource.length > 0 ? (
                        <div id="views">
                            <div id="listView" style={styles.listView} hidden={this.props.previewStyle !== 'listView'}>
                                {listViewImageSource.map((value, index) =>
                                    <ListView
                                        key={index}
                                        value={value}
                                        index={index}
                                        expand={expand}
                                        userType={userType}
                                        uploadHandle={payload => this.uploadHandle(payload)}
                                        deleteHandler={(file, path) => this.deleteHandler(file, path)}
                                        ownDpr={value.ownDprName === dprName}
                                        updateFormControlDataHandler={this.updateFormControlDataHandler}
                                        openChatDrawer={openChatDrawer}
                                        paginationHandler={(page, filePath, text) => this.paginationHandler(page, filePath, text, 'list')} />)}
                            </div>
                            <div id="slideView" hidden={this.props.previewStyle !== 'slideView'}>
                                <SlideView
                                    dataList={imageSource}
                                    ownDpr={imageSource[this.state.selectedIndex].ownDprName === dprName}
                                    dataSource={slideViewGridData}
                                    userType={userType}
                                    selectedIndex={this.state.selectedIndex}
                                    openChatDrawer={openChatDrawer}
                                    uploadHandle={payload => this.uploadHandle(payload)}
                                    deleteHandler={(file, path) => this.deleteHandler(file, path)}
                                    handleRowClick={(record, index) => this.setState({ selectedIndex: index })}
                                    updateFormControlDataHandler={this.updateFormControlDataHandler}
                                    paginationHandler={(page, filePath, text) => this.paginationHandler(page, filePath, text, 'slide')}
                                    dprName={dprName}
                                />
                            </div>
                        </div>
                    ) : null}
                </BCard>
                <ChatDrawer />
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        screenShotCompare: state.screenShotCompare
    }
}

const mapDispatchToProps = dispatch => {
    return {
        updateFormControlDataHandler: payload => dispatch({ type: WATCH_UPDATE_FORM_CONTROL_DATA_HANDLER, payload }),
        openChatDrawer: payload => dispatch({ type: WATCH_CHAT_DRAWER, payload }),
        loadingHandler: () => dispatch({ type: WATCH_LOADING_HANDLER }),
        uploadHandle: payload => dispatch({ type: WATCH_UPLOAD_HANDLE, payload }),
        deleteHandler: payload => dispatch({ type: WATCH_DELETE_HANDLE, payload })
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(screenshotCompare);