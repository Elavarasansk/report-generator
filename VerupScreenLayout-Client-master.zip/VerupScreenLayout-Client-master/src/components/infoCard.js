import React from 'react'
import {connect} from 'react-redux'
import { Result, Icon } from 'antd';
import { Card } from '@blueprintjs/core';
import locale from '../localization/verupLocalization';


class InfoCard extends React.Component{

    generateContents = (error) =>{
        switch(error){
            case 'no_selected_dpr' :
                return {
                    status : "404",
                    icon : null,
                    title : locale.select_dpr_load,
                    subTitle : locale.select_dpr_load_sub
                }
            case 'invalid_dpr' :
                return {
                    status : "500",
                    icon : null,
                    title : locale.dpr_not_exist,
                    subTitle : locale.dpr_not_exist_sub
                }
            case 'internal_server_error' :
                return {
                    status : null,
                    icon : <Icon type="smile" theme="twoTone"/>,
                    title : locale.internal_error,
                    subTitle : locale.internal_error_sub
                }
            default :
                break;

        }
    }

    render(){
        locale.setLanguage(this.props.lang);
        const {error} =  this.props;
        const {status,icon,title,subTitle} = this.generateContents(error);
        return(
            <div className="d-flex w-100 justify-content-center">
                    <Card elevation="2" className="d-flex w-100 flex-column justify-content-center" style={{borderRadius:10}}>
                        <Result icon={icon?icon:null} status={status} title={title} subTitle={subTitle} />
                    </Card>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        error : state.screenShotCompare.errorMessage,
        lang : state.screenShotCompare.lang
    };
};
export default connect(mapStateToProps,null)(InfoCard)