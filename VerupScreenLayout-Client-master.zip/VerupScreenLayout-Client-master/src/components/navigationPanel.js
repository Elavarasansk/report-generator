import React from 'react'
import { connect } from 'react-redux';
import { Card, H5 } from '@blueprintjs/core';
import locale from '../localization/verupLocalization';
import { AutoComplete, Select, Button, Progress, Typography, Divider, Modal, Radio, Table, Tag, Input, Switch, Badge } from 'antd';
import { 
    WATCH_GET_ALL_DPR_LIST, 
    WATCH_GET_DPR_INFO,
    WATCH_USER_VIEW_HANDLE,
    WATCH_LOADING_HANDLER,
    WATCH_HOME_VIEW_CHANGE,
    WATCH_LANG_HANDLER
} from '../reduxFlow/watcherActionTypes/layoutComapreWatchTypes';

const moduleNames = ['COM', 'CAM', 'CCM', 'CBM', 'CFM'];

class NavigationPanel extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            dprName: '',
            dprNameDlg: '',
            moduleName: moduleNames[0],
            slideView: false,
            listView: true,
            showModal: false,
            dprDataSource: [],
            gridDataSource : {},
            filteredGridDataSource : []
        }
    }

    static getDerivedStateFromProps(props,state){
        const { dprGridList } = props.navigation.allDprList;
        if(state.gridDataSource !== dprGridList){
            return {
                ...state,
                gridDataSource : dprGridList,
                filteredGridDataSource : dprGridList.COM
            }
        } else {
            return {
                ...state
            }
        }
    }
    

    componentDidMount = () => {
        this.props.loadingHandler();
        this.props.getAllDprList();
    }

    getDataSource = (dprName, view) => {
        const { moduleName} = this.state;
        const { allDprList } = this.props.navigation;
        const regexEscape = ['\\','[',']','*','+','(',')','?'];
        for(let i=0;i<regexEscape.length;i++)
            if(dprName.indexOf(regexEscape[i])!==-1)
                return
        if(view === 'DLG') {
            this.setState({ dprNameDlg: dprName });
            let filterResult = allDprList.dprGridList[moduleName];
            filterResult = filterResult.filter(item => item.dprName.toUpperCase().search(dprName.toUpperCase()) !== -1);
            this.setState({
                filteredGridDataSource: filterResult
            })
        } else {
            this.setState({dprName});
        }
        let dataSource = allDprList[moduleName].filter(item => item.toUpperCase().search(dprName.toUpperCase()) !== -1).slice(0, 7);
        this.setState({ dprDataSource: !dprName ? [] : dataSource.length > 0 ? dataSource : ['No Data Found'] });

    }

    changePreviewStyle = (text) => {
        if(text === 'listView'){
            this.setState({listView:true,slideView:false});
        } else {
            this.setState({listView:false,slideView:true});
        }
        this.props.changePreviewStyle(text);
    }

    getDprInfo = dpr => {
        const dprName = dpr === 'No Data Found' ? '' : dpr;
        let payload = {
            dprName,
            moduleName : this.state.moduleName
        }
        this.setState({ dprName });
        if (dprName) {
            this.props.loadingHandler();
            this.props.getDprInfo(payload);
        }
    }

    clickHandler = dprName => {
        this.setState({showModal : !this.state.showModal});
        this.getDprInfo(dprName);
    } 

    changeLang = lang => {
        this.props.changeLang(lang);
        locale.setLanguage(lang);
    }

    render() {
        const { listView, slideView, dprDataSource, showModal, dprName, dprNameDlg, moduleName, filteredGridDataSource,gridDataSource } = this.state;
        const { currentView, status } = this.props;
        const { userType } = this.props.navigation;
        const { notYetStarted, pending, reviewedCount } = status.overAll;
        const { Text } = Typography;
        const total = notYetStarted + pending + reviewedCount;
        const percent = (reviewedCount * 100) / total;
        const styles = {
            radius : {
                borderRadius : 10
            },
            height : {
                height: '1.1em'
            }
        }
        const columns = [
            {
                title: 'DPR LIST',
                dataIndex: 'dprName',
                key: 'dprName',
                render: dprName => (
                    <span>
                        <Button className="w-100" type="dashed" icon="play-circle" 
                        onClick={() => this.clickHandler(dprName)} style={{backgroundColor :'#c4c4c4', textAlign: 'left'}}>
                        {dprName}</Button>
                    </span>
                )
            }
        ]
        return (
            <Card style={styles.radius} elevation={1}  className="w-100">
                <div className="d-flex">
                    <div className="d-flex" id="ss_step-1">
                        <AutoComplete id="np_step-1" style={{ width: 240 }} className="ml-3"
                            value={!showModal ? dprName : ''}
                            onSearch={text => this.getDataSource(text, 'SCREEN')}
                            onSelect={value => this.getDprInfo(value)}
                            dataSource={dprDataSource}
                            placeholder={locale.dpr_name}
                        />
                        <Select id="np_step-2" style={{ width: 75 }} className="ml-3" onChange={moduleName => this.setState({ moduleName })} value={moduleName} >
                        {moduleNames.map(value => {
                            return(<Select.Option key={value} value={value}>{value}</Select.Option>);
                            })}
                        </Select>
                        <Button id="np_step-3" icon="select" className="ml-2" type="primary" onClick={() => this.setState({ showModal: !showModal })}>{locale.select_dpr}</Button>
                            <Modal style={styles.radius} title={locale.select_dpr} footer={false} visible={showModal} centered onCancel={()=>this.setState({showModal:false})} > 
                                <div>
                                    <Radio.Group defaultValue={moduleNames[0]} buttonStyle="solid" onChange={event => { this.setState({ filteredGridDataSource: gridDataSource[event.target.value],moduleName: event.target.value}) }} >
                                        {moduleNames.map(value => {
                                            return (<span className="mr-4"><Badge style={{backgroundColor:'#828282'}} offset={[5,-5]} count={gridDataSource[value].length} overflowCount={5000}><Radio.Button style={{borderRadius:13}} key={value} value={value}>{value}</Radio.Button></Badge></span>);
                                        })}
                                    </Radio.Group>
                                    <Input style={{ width: 405 }} placeholder={locale.filter_dpr_modal} className="mt-2"
                                        value={dprNameDlg}
                                        onChange={event => this.getDataSource(event.target.value, 'DLG')}
                                    />
                                    <Table columns={columns} dataSource={filteredGridDataSource} striped bordered hover className="mt-2"
                                        size="small"  pagination={{simple : true, total : filteredGridDataSource.length}}
                                    ></Table>
                                </div>
                            </Modal>
                        <Switch checkedChildren="Developer" unCheckedChildren="Consultant" className="ml-2 mt-1" onChange={value => this.props.userViewHandler(value)} />
                        <Switch checkedChildren="en" unCheckedChildren="ja" className="ml-2 mt-1" onChange={value => this.changeLang(value?'en':'ja')} />
                    </div>
                    <div className="d-flex ml-auto" >
                        <div className="d-flex" hidden={currentView === 'screenshot' ? false : true}>
                            <div className="d-flex" hidden={!userType}>
                                <Text className="text-primary mt-1 mr-2 font-weight-bold">{locale.overall_status}</Text>
                                <Progress strokeColor="green" width={30} type="dashboard" size="small" className="mr-2" percent={percent} />
                                <div className="d-flex mr-3">
                                    <div className="d-flex mr-1"> <Text className="text-secondary mt-1 mr-1">{locale.not_started_sts}</Text><H5 className="text-primary mt-1">{notYetStarted}</H5> </div>
                                    <Divider type="vertical" className="mt-2" style={styles.height} />
                                    <div className="d-flex mr-1"> <Text className="text-secondary mt-1 mr-1">{locale.pending_sts}</Text><H5 className="text-danger mt-1">{pending}</H5> </div>
                                    <Divider type="vertical" className="mt-2" style={styles.height} />
                                    <div className="d-flex mr-1"> <Text className="text-secondary mt-1 mr-1">{locale.Reviewed_sts}</Text><H5 className="text-success mt-1">{reviewedCount}</H5> </div>
                                    <Divider type="vertical" className="mt-2" style={styles.height} />
                                    <div className="d-flex mr-1"> <Text className="text-secondary mt-1 mr-1">{locale.total}</Text><H5 className="text-warning mt-1">{total}</H5> </div>
                                </div>
                            </div>
                            <div className="d-flex" id="ss_step-2">
                                <Button type={listView ? 'primary' : 'default'} className="mr-2" onClick={() => this.changePreviewStyle('listView')}>{locale.list_view}</Button>
                                <Button type={slideView ? 'primary' : 'default'} onClick={() => this.changePreviewStyle('slideView')}>{locale.slide_view}</Button>
                            </div>
                        </div>
                        <div className="ml-2">
                            <Button icon="question" shape="circle-outline" onClick={this.props.openhelp} ></Button>                     
                        </div>
                    </div>
                </div>
            </Card>
        )

    }
}

const mapStateToProps = state => {
    return {
        navigation: state.screenShotCompare,
        status: state.screenShotCompare.overallStatus,
        lang : state.screenShotCompare.lang
    };
};

const mapDispatchToProps = dispatch => {
    return {
        getAllDprList: () => dispatch({type: WATCH_GET_ALL_DPR_LIST}),
        getDprInfo: payload => dispatch({ type: WATCH_GET_DPR_INFO,payload}),
        userViewHandler: userView => dispatch({type: WATCH_USER_VIEW_HANDLE,userView}),
        loadingHandler : () =>dispatch({type: WATCH_LOADING_HANDLER}),
        changeHomeView : view => dispatch({type:WATCH_HOME_VIEW_CHANGE,view}),
        changeLang : lang => dispatch({type:WATCH_LANG_HANDLER,lang})
    };
};


export default connect(mapStateToProps, mapDispatchToProps)(NavigationPanel);