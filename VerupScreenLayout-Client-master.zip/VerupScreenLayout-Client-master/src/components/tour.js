import React from 'react'
import { connect } from 'react-redux'
import Tour from 'reactour'
import locale from '../localization/verupLocalization';
import * as images from '../styles/images/tour/tourImages'

class ApplicationTour extends React.Component {
    render() {
        const steps = {
            info: [
                {
                    selector: '#np_step-1',
                    content:
                        <div className="mt-2">
                            <img className="ml-4" src={images.np_autocomplete} />
                            <h5 className="mt-2">{locale.tour_np_step_1}</h5>
                        </div>,
                    style: { maxWidth: 500 }
                },
                {
                    selector: '#np_step-2',
                    content:
                        <div className="mt-2">
                            <img className="ml-5" src={images.np_module_cmb} />
                            <h5 className="mt-2">{locale.tour_np_step_2}</h5>
                        </div>
                },
                {
                    selector: '#np_step-3',
                    content:
                        <div className="mt-2">
                            <img width="261" height="385" src={images.np_dpr_list} />
                            <h5 className="mt-2">{locale.tour_np_step_3}</h5>
                        </div>,
                    style: { maxWidth: 500 }
                }
            ],
            screenshot: [
                {
                    selector: '#ss_step-1',
                    content:
                        <h5 className="mt-2">{locale.tour_ss_step_1}</h5>,
                    style: { maxWidth: 500 }
                },
                {
                    selector: '#ss_step-2',
                    content:
                        <h5 className="mt-2">{locale.tour_ss_step_2}</h5>,
                    style: { maxWidth: 500 }
                }
            ],
            dprInfo: [
                {
                    selector: '#step-1000',
                    content: <p>Need to immplement</p>
                },
            ]
        }
        const {view} = this.props;
        return (
            <Tour steps={steps[view]} isOpen={this.props.isTourOpen} onRequestClose={this.props.onTourClose} />
        )
    }
}
const mapStateToProps = state => {
    return {
        view: state.screenShotCompare.currentView
    };
};
export default connect(mapStateToProps, null)(ApplicationTour);