import React from 'react'
import { connect } from 'react-redux';
import { Card, H5, H2, H3 } from '@blueprintjs/core';
import { Input, Select, Table, Tag, Progress, Button, Icon, Tooltip, Radio } from 'antd';
import locale from '../localization/verupLocalization';
import ProgressView from './progress';
import PieChart from './pieChart';
import '../styles/antd_modified.css';
import { WATCH_GET_DPR_INFO } from '../reduxFlow/watcherActionTypes/layoutComapreWatchTypes';

const formSelect = ["ALL", "OWN FORMS", "SHARED FORMS"];


class DPRInfoCard extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            fromList: [],
            filteredFormList: [],
            searchkey: '',
            selectKey: 'ALL',
            chartRadio : 'ALL',
            chartView : false
        }
    }

    static getDerivedStateFromProps(props, state) {
        const { gridData } = props.dprInfoCard;
        const { fromList } = state;
        if (fromList !== gridData) {
            return {
                ...state,
                fromList: gridData,
                filteredFormList: gridData,
            }
        }
    }

    filterResult = async (value, type) => {
        const { searchkey, selectKey } = this.state;
        const filterData = (type === 'SELECT') ? value : selectKey;
        const searchData = (type === 'SELECT') ? searchkey : value;
        let filteredFormList = this.filterHandler(filterData);
        filteredFormList = filteredFormList.filter(item => item.formCaption[locale.getLanguage()].toUpperCase().search(searchData.toUpperCase()) !== -1);
        (type === 'SELECT') ? this.setState({ selectKey: value, filteredFormList }) : this.setState({ searchkey: value, filteredFormList })
    }

    filterHandler = (formType) => {
        const { gridData, dprName } = this.props.dprInfoCard;
        let filterResult = gridData;
        switch (formType) {
            case formSelect[1]:
                filterResult = filterResult.filter(item => item.targetDprName === dprName); //get Dpr name from state
                break;
            case formSelect[2]:
                filterResult = filterResult.filter(item => item.targetDprName !== dprName); // get Dpr name from state
                break;
            case formSelect[0]:
                filterResult = gridData;
                break;
            default:
                break;
        }
        return filterResult;
    }


    render() {
        const { Search } = Input;
        const { filteredFormList,chartRadio,chartView} = this.state;
        const { openScreenshotComapre } = this.props;
        const { overallStatus, dprName } = this.props.dprInfoCard;
        const formSelectLocale = [locale.all, locale.own_form, locale.shared_form];
        const chartData = chartRadio === formSelect[0]?overallStatus.overAll:chartRadio===formSelect[1]?overallStatus.ownForms:overallStatus.sharedForms;
        const columns = [
            {
                title: locale.Name,
                dataIndex: 'formCaption',
                key: 'formCaption',
                render: formCaption => (
                    <span>{formCaption[locale.getLanguage()]}</span>
                )
            },
            {
                title: locale.own_dpr,
                key: 'targetDprName',
                render: data => (
                    <span>
                        <Tag color={data.targetDprName === dprName ? 'green' : null} key={data.targetDprName}>{data.targetDprName === dprName ? `${data.dprCaption[locale.getLanguage()]}` : data.dprCaption[locale.getLanguage()]}</Tag>
                    </span>
                )
            },
            {
                title: locale.status,
                dataIndex: 'status',
                key: 'status',
                filters: [
                    {
                        text: locale.not_yet_started_cmb,
                        value: 'Not Yet Started'
                    },
                    {
                        text: locale.pending_cmb,
                        value: 'Pending'
                    },
                    {
                        text: locale.reviewed_cmb,
                        value: 'Reviewed'
                    }
                ],
                onFilter: (value, record) => record.status === value,
                sorter: (a, b) => a.status.length - b.status.length,
                render: status => (
                    <span>
                        <Tag color={status === 'REVIEWED' ? 'green' : status === 'PENDING' ? 'red' : 'blue'} key={status}>{status === 'REVIEWED' ? locale.reviewed_cmb : status === 'PENDING' ? locale.pending_cmb : locale.not_yet_started_cmb}</Tag>
                    </span>
                )
            },
        ]
        return (
            <div className="w-100" >
                <div className="row" >
                    <div className="col-lg-9 mb-2">
                        <Card className="h-100" elevation={1} style={{ borderRadius: 10 }}>
                            <H5>{locale.list_of_forms}</H5>
                            <div className="d-flex">
                                <Search style={{ width: 260 }} placeholder={locale.filter_placeholder} enterButton onChange={(event) => { this.filterResult(event.target.value, 'SEARCH') }} />
                                <Select style={{ width: 140 }} className="ml-auto" defaultValue="ALL" onSelect={(value) => { this.filterResult(value, 'SELECT') }}>
                                    {formSelect.map((item, index) => (<Select.Option key={item} value={item}>{formSelectLocale[index]}</Select.Option>))}
                                </Select>
                            </div>
                            <Table size="default" className="mt-3" columns={columns} dataSource={filteredFormList} bordered pagination={{ pageSize: 11 }}
                            />
                        </Card>
                    </div>
                    <div className="col-lg-3 mb-2" >
                        <Card style={{ height: 750, borderRadius: 10 }} elevation={1}>
                        <div className="d-flex justify-content-end">
                            <Tooltip placement="bottomLeft" title="Chart View" >
                                <Button className="mr-2" icon={chartView?"bar-chart":"pie-chart"} size="large" onClick={()=>this.setState({chartView:!chartView})} />
                            </Tooltip>
                            <Tooltip placement="bottomLeft" title="Refresh" >
                                <Button color="green"  icon="sync" size="large" />
                            </Tooltip>
                        </div>
                        {chartView?
                        <div className="d-flex justify-content-center" style={{height:'95%'}}>
                            <div className="d-flex flex-column mt-4 justify-content-around">
                                <Radio.Group defaultValue={formSelect[0]} buttonStyle="solid" onChange={(e)=>{this.setState({chartRadio:e.target.value})}}>
                                        {formSelect.map((value, index) => (<Radio.Button key={value} value={value}>{formSelectLocale[index]}</Radio.Button>))}
                                </Radio.Group>
                                <PieChart className="mt-2" data={chartData}/>
                                <Button icon="arrow-right" type="primary" onClick={openScreenshotComapre}>{locale.form_layout}</Button> 
                            </div>
                        </div> :
                        <div className="d-flex justify-content-center" style={{height:'95%'}}>
                            <div className="d-flex flex-column justify-content-around">
                                <ProgressView title={locale.overall} color="green" status={overallStatus.overAll} />
                                <ProgressView title={locale.own_form} color="#0e82c9" status={overallStatus.ownForms} />
                                <ProgressView title={locale.shared_form} color="orange" status={overallStatus.sharedForms} />
                                <Button icon="arrow-right" type="primary" onClick={openScreenshotComapre}>{locale.form_layout}</Button>
                            </div>
                        </div>
                        }
                        </Card>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        dprInfoCard: state.screenShotCompare,
        lang: state.screenShotCompare.lang
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        getDprInfo: () => dispatch({ type: WATCH_GET_DPR_INFO })
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(DPRInfoCard)