import React from 'react'
import { Chart } from '@antv/g2'
import locale from '../localization/verupLocalization';
class PieChart extends React.Component {
    constructor(props) {
        super(props)
        this.chartContainer = React.createRef();
    }
    componentDidMount() {
        this.componentDidUpdate();
    }
    componentDidUpdate() {
        if (this.chartContainer.current.hasChildNodes()) {
            let element = this.chartContainer.current.childNodes[0];
            this.chartContainer.current.removeChild(element);
        }
        let total = 0;
        let data = [];
        let colors = [];
        Object.keys(this.props.data).forEach(key => {
            const count = this.props.data[key];
            let caption;
            if (count > 0) {
                switch (key) {
                    case 'notYetStarted':
                        colors.push('#1890ff')
                        caption = locale.not_yet_started_cmb
                        break;
                    case 'pending':
                        colors.push('#f04864')
                        caption = locale.pending_cmb
                        break;
                    case 'reviewedCount':
                        colors.push('#48f07a')
                        caption = locale.reviewed_cmb
                        break;
                    default :
                        break;
                    }
                    total = total + count;
                    data.push({
                        item: caption,
                        count: count,
                    })
                }
            });
        const chart = new Chart({
            container: 'chartContainer',
            autoFit: true,
            height: 500,
        });

        chart.coordinate('theta', {
            radius: 0.75,
        });
        chart.data(data);

        chart.scale('count', {
            formatter: (val) => {
                val = ((val * 100) / (total)) + '%';
                return val;
            },
        });

        chart.tooltip({
            showTitle: false,
            showMarkers: false,
        });

        chart
            .interval()
            .adjust('stack')
            .position('count')
            .color('item', colors)
            .label('count', {
                offset: -40,
                style: {
                    textAlign: 'center',
                    fontSize: 16,
                    shadowBlur: 2,
                    shadowColor: 'rgba(0, 0, 0, .45)',
                    fill: '#fff',
                },
            })
            .tooltip('item*count', (item, count) => {
                count = ((count * 100) / (total)) + '%';
                return {
                    name: item,
                    value: count,
                };
            });

        chart.interaction('element-active');
        chart.render();
    }

    render() {
        return (
            <div ref={this.chartContainer} id="chartContainer"></div>
        )
    }
}

export default PieChart