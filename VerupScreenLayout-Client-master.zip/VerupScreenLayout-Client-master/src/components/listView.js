import React, { Component } from 'react';
import { Accordion, Card, Button } from 'react-bootstrap';
import { Select, Pagination, Tag, Button as AntButton, Upload, Icon, message as AntMessage, Tooltip, Modal, Breadcrumb, Popover } from 'antd';
import { Chip } from '@material-ui/core';
import { Divider } from '@blueprintjs/core';
import locale from '../localization/verupLocalization';
import ImageView from './imageView';
import noImage from '../styles/images/no_image_available.jpg';

export default class listView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isExpand: this.props.expand,
            isopen: this.props.expand,
            showFullScreen: false,
            slideshowContent: 'v36'
        }
    }

    render() {
        let fileList = [];
        const formStatusList = ['NOT YET STARTED', 'PENDING', 'REVIEWED'];
        const { value, index, paginationHandler, updateFormControlDataHandler, openChatDrawer, ownDpr, expand, userType, uploadHandle, deleteHandler } = this.props;
        const { isExpand, isopen, showFullScreen, slideshowContent } = this.state;
        const statusLocale = [locale.not_yet_started_cmb, locale.pending_cmb, locale.reviewed_cmb];
        const { activeIndex, fileName, filePath, formCaption, formStatus, v36, v40 } = value;
        const { v36Index, v40Index } = activeIndex.list;
        const lengthV40 = v40.length;
        const lengthV36 = v36.length;
        const { confirm } = Modal;
        const openComment = () => {
            const payload = {
                isChatDrawerOpen: true,
                currentChatValue: value
            }
            openChatDrawer(payload)
        }
        if (isExpand !== expand) {
            this.setState({ isExpand: expand, isopen: expand });
        }
        const status = formStatus ? formStatus === formStatusList[0] ? statusLocale[0] : formStatus === formStatusList[1] ? statusLocale[1] : statusLocale[2] : statusLocale[0];
        const color = status !== statusLocale[0] ? status === statusLocale[1] ? 'red' : 'green' : 'blue';
        const path = lengthV40 ? v40[v40Index].split('=')[1] : '';
        const Breadcrubs = (<Breadcrumb >
            {filePath.split("\\").splice(2).map((value, index, array) => {
                return (<Breadcrumb.Item>{index !== array.length - 1 ? <Icon theme="filled" type="folder-open" /> : <Icon theme="filled" type="file" />}<span>{value}</span></Breadcrumb.Item>)
            })}
        </Breadcrumb>)
        const props = {
            name: 'file',
            multiple: false,
            action: 'http://192.168.57.30/cdn/upload',
            method: 'post',
            data: { filePath: lengthV40 ? path.substring(0, path.lastIndexOf("\\") + 1) : filePath.replace(/\\/g, '\\\\') },
            onChange: (info) => {
                const { status } = info.file;
                if (status === 'done') {
                    fileList = [];
                    let payload = {
                        filePath,
                        imagePath: info.file.response.split('=')[1],
                        mode: 'upload'
                    }
                    uploadHandle(payload);
                } else if (status === 'error') {
                }
            },
            showUploadList: false,
        }
        const beforeUpload = async (file, ownDpr) => {
            var uploadPromise = new Promise((resolve, reject) => {
                const fileType = file.name.split('.')[1];
                if (fileType.toUpperCase() !== 'PNG' && fileType.toUpperCase() !== 'JPEG' && fileType.toUpperCase() !== 'JPG') {
                    AntMessage.error(locale.image_format);
                    reject("File format is wrong")
                } else {
                    if (!ownDpr && formStatus === formStatusList[2]) {
                        confirm({
                            title: locale.upload_confirmation_title,
                            content: <p style={{ lineHeight: 2 }}>{locale.upload_confirmation_content_start}<Tag color="green">{statusLocale[2]}</Tag>{locale.upload_confirmation_content_end}<Tag color="red">{statusLocale[1]}</Tag></p>,
                            onOk() {
                                fileList.push(file);
                                return resolve("Upload")
                            },
                            onCancel() {
                                return reject("Cancel")
                            },
                            cancelText : locale.cancel_text,
                            width: 450
                        })
                    } else {
                        fileList.push(file);
                        resolve("upload")
                    }
                }
            })
            await uploadPromise;
        }
        const styles = {
            accordionToggle: { backgroundColor: '#5a6268', borderColor: '#545b62', color: 'white', height: 50 },
            listViewTag: { width: 240, cursor: 'pointer', visibility: userType ? 'visible' : 'hidden' },
            userView: { visibility: userType ? 'visible' : 'hidden' },
            upload: { height: 32, marginTop: 4 },
            select: { float: "right", width: 170, visibility: userType ? 'visible' : 'hidden' },
            divider: { borderWidth: 2, borderColor: '#d0e6fd', marginTop: 0 },
            chipStyle: { color: '#1890ff', borderColor: '#1890ff' }
        }
        return (
            <React.Fragment>
                <Accordion activeKey={isopen ? "0" : "1"} className={index === 0 ? "mt-3" : "mt-2"} key={index} >
                    <Card>
                        <Accordion.Toggle style={isopen ? styles.accordionToggle : { height: 50, cursor: 'pointer' }} className="d-flex btn-outline-secondary" as={Card.Header} eventKey="0" onClick={() => this.setState({ isopen: !isopen })}>
                            <div className="d-flex w-100">
                                {userType ? <React.Fragment>
                                    <p className="mt-1">{userType ? `${fileName.split('.')[0]}` : `${formCaption[locale.getLanguage()]}`}</p>
                                    <Popover content={Breadcrubs} placement="right">
                                        <Icon className="ml-2" style={{ marginTop: 7 }} type="info-circle" />
                                    </Popover>
                                </React.Fragment> :
                                    <p className="mt-1">{userType ? `${fileName.split('.')[0]}` : `${formCaption[locale.getLanguage()]}`}</p>
                                }

                                <div className="d-flex ml-auto" style={styles.listViewTag}>
                                    <Tag className="mr-auto" color={color} key="status" >{status}</Tag>
                                    <Tag className="ml-auto" color={ownDpr ? 'green' : 'red'} key="dpr" >{ownDpr ? locale.own_form : locale.shared_form}</Tag>
                                </div>
                            </div>
                        </Accordion.Toggle>
                        <Accordion.Collapse eventKey="0">
                            <Card.Body style={{ backgroundColor: '#f7f7f7' }} >
                                <div className="mb-2 d-flex">
                                    <div className="col-6">
                                        <div className="d-flex">
                                            <Tooltip placement="right" title={locale.version_36} >
                                                <Chip variant="outlined" style={styles.chipStyle} label={locale.company_screen} className="mr-auto mt-1" />
                                            </Tooltip>
                                            <Tooltip placement="leftBottom" title={locale.full_view}>
                                                <AntButton icon="fullscreen" className="ml-auto mt-1" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v36' }) }}></AntButton>
                                            </Tooltip>
                                        </div>
                                    </div>
                                    <div className="col-6">
                                        <div className="d-flex">
                                            <Tooltip placement="right" title={locale.version_40} >
                                                <Chip variant="outlined" style={styles.chipStyle} label={locale.hue_screen} className="ml-3 mt-1" />
                                            </Tooltip>
                                            <div className="d-flex ml-auto">
                                                <Tooltip placement="bottomLeft" title={locale.delete_screenshot} >
                                                    <AntButton icon="delete" className="mr-2 mt-1" type="danger" disabled={!lengthV40 || formStatus === formStatusList[2]} onClick={() => deleteHandler(path, filePath)} style={{ visibility: userType ? 'visible' : 'hidden' }} />
                                                </Tooltip>
                                                <div style={styles.userView} >
                                                    <Upload {...props} fileList={fileList} beforeUpload={(file) => beforeUpload(file, ownDpr)} >
                                                        <Tooltip placement="bottomLeft" title={locale.upload_screenshot}>
                                                            <AntButton type="primary" className="mr-2" style={styles.upload}>
                                                                <Icon type="upload" />
                                                            </AntButton>
                                                        </Tooltip>
                                                    </Upload>
                                                </div>
                                                <Select className="mr-2 mt-1" style={styles.select} value={formStatus ? formStatus : formStatusList[0]}
                                                    onChange={status => updateFormControlDataHandler(status, value)} disabled={(!ownDpr) || (!lengthV40)}>
                                                    {formStatusList.map((value, index) => (<Select.Option key={value} value={value}>{statusLocale[index]}</Select.Option>))}
                                                </Select>
                                                <Button className="mt-1" size="sm" variant="outline-success" onClick={openComment} style={styles.userView} >{locale.comment}</Button>
                                                <Tooltip placement="bottomLeft" title={locale.full_view}>
                                                    <AntButton icon="fullscreen" className="ml-2 mt-1" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v40' }) }}></AntButton>
                                                </Tooltip>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex ml-auto justify-content-between">
                                    <div className="col-6">
                                        <Card id="imgv36Card" className="border border-dark" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v36' }) }}>
                                            <Tooltip placement="top" title={locale.full_view}>
                                                <Card.Img variant="top" src={lengthV36 ? v36[v36Index] : noImage} height="460" />
                                            </Tooltip>
                                        </Card>
                                        <div className="mt-3">
                                            <Pagination size="small" total={lengthV36} defaultPageSize={1} className="mt-auto" current={parseInt(v36Index) + 1}
                                                onChange={page => paginationHandler(page, filePath, "v36")} />
                                        </div>
                                    </div>
                                    <Divider style={styles.divider} ></Divider>
                                    <div className="col-6">
                                        <Card id="imgv40Card" className="border border-dark" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v40' }) }}>
                                            <Card.Img variant="top" src={lengthV40 ? v40[v40Index] : noImage} height="460" />
                                        </Card>
                                        <div className="mt-3">
                                            <Pagination size="small" total={lengthV40} defaultPageSize={1} className="mt-auto" current={parseInt(v40Index) + 1}
                                                onChange={page => paginationHandler(page, filePath, "v40")} />
                                        </div>
                                    </div>
                                </div>
                            </Card.Body>
                        </Accordion.Collapse>
                    </Card>
                </Accordion>
                <ImageView images={value} version={slideshowContent} show={showFullScreen} onClose={(index, filePath, version) => { this.setState({ showFullScreen: false }); paginationHandler(index + 1, filePath, version) }} view="list" />
            </React.Fragment>
        );
    }
}