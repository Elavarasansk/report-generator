import React, { Component } from 'react';
import { Card, Button } from 'react-bootstrap';
import { Select, Pagination, Table, Tag, Button as AntButton, Upload, Icon, message as AntMessage, Tooltip, Modal } from 'antd';
import { Chip } from '@material-ui/core'
import locale from '../localization/verupLocalization';
import ImageView from './imageView';
import noImage from '../styles/images/no_image_available.jpg';

export default class slideView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showFullScreen: false,
            slideshowContent: 'v36'
        }
    }

    render() {
        let fileList = [];
        const formStatusList = ['NOT YET STARTED', 'PENDING', 'REVIEWED'];
        const statusLocale = [locale.not_yet_started_cmb, locale.pending_cmb, locale.reviewed_cmb];
        const { showFullScreen, slideshowContent } = this.state;
        const { dataList, dataSource, selectedIndex, handleRowClick, paginationHandler, updateFormControlDataHandler, openChatDrawer, ownDpr, dprName, userType, uploadHandle, deleteHandler } = this.props;
        const selectedData = dataList[selectedIndex];
        const { activeIndex, filePath, formStatus, v36, v40 } = selectedData;
        const { v36Index, v40Index } = activeIndex.slide;
        const lengthV40 = v40.length;
        const lengthV36 = v36.length;
        const { confirm } = Modal;
        const path = lengthV40 ? v40[v40Index].split('=')[1] : '';
        const openComment = () => {
            const payload = {
                isChatDrawerOpen: true,
                currentChatValue: selectedData
            }
            openChatDrawer(payload);
        }
        const props = {
            name: 'file',
            multiple: false,
            action: 'http://192.168.57.30/cdn/upload',
            method: 'post',
            data: { filePath: lengthV40 ? path.substring(0, path.lastIndexOf("\\") + 1) : filePath.replace(/\\/g, '\\\\') },
            onChange: (info) => {
                if (info.file.status === 'done') {
                    fileList = [];
                    let payload = {
                        filePath,
                        imagePath: info.file.response.split('=')[1],
                        mode: 'upload'
                    }
                    uploadHandle(payload);
                } else if (info.file.status === 'error') {
                }
            },
            showUploadList: false,
        }
        const beforeUpload = async (file, ownDpr) => {
            var uploadPromise = new Promise((resolve, reject) => {
                const fileType = file.name.split('.')[1];
                if (fileType.toUpperCase() !== 'PNG' && fileType.toUpperCase() !== 'JPEG' && fileType.toUpperCase() !== 'JPG') {
                    AntMessage.error(locale.image_format);
                    reject("File format is wrong")
                } else {
                    if (!ownDpr && formStatus === formStatusList[2]) {
                        confirm({
                            title: locale.upload_confirmation_title,
                            content: <p style={{ lineHeight: 2 }}>{locale.upload_confirmation_content_start}<Tag color="green">{statusLocale[2]}</Tag>{locale.upload_confirmation_content_end}<Tag color="red">{statusLocale[1]}</Tag></p>,
                            onOk() {
                                fileList.push(file);
                                return resolve("Upload")
                            },
                            onCancel() {
                                return reject("Cancel")
                            },
                            cancelText : locale.cancel_text,
                            width: 450,
                            backgroundColor: 'white'
                        })
                    } else {
                        fileList.push(file);
                        resolve("upload")
                    }
                }
            })
            await uploadPromise;
        }
        const columns = [{
            title: 'File Name',
            key: 'file_name',
            widht: 100,
            render: data => (
                <span>
                    {userType ? (<Tag color={dprName === data.ownDprName ? 'green' : 'red'} key={data.file_name}>{data.file_name}</Tag>) : data.caption[locale.getLanguage()]}
                </span>
            )
        }]
        const styles = {
            table: { height: 600, overflow: "auto" },
            userView: { visibility: userType ? 'visible' : 'hidden' },
            select: { float: "right", width: 170, visibility: userType ? 'visible' : 'hidden' },
            tableCard: { height: 630, backgroundColor: '#d9d9d914' },
            card: { height: 630, backgroundColor: '#f7f7f7' },
            chipStyle: { color: '#1890ff', borderColor: '#1890ff' }
        }
        return (
            <React.Fragment>
                <div className="container-fluid mt-3">
                    <div className="row">
                        <div className="col-5">
                            <Card className="mt-2 pl-2 pr-2" style={styles.card} >
                                <div className="d-flex mt-1 mb-2">
                                    <Tooltip placement="right" title={locale.version_36} >
                                        <Chip variant="outlined" style={styles.chipStyle} label={locale.company_screen} className="mt-1 ml-1" />
                                    </Tooltip>
                                    <Tooltip placement="leftBottom" title={locale.full_view}>
                                        <AntButton icon="fullscreen" className="ml-auto mt-1" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v36' }) }}></AntButton>
                                    </Tooltip>
                                </div>
                                <div>
                                    <Card id="imgv36Card" className="border border-dark" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v36' }) }}>
                                        <Tooltip placement="top" title={locale.full_view}>
                                            <Card.Img variant="top" src={lengthV36 ? v36[v36Index] : noImage} height="520" />
                                        </Tooltip>
                                    </Card>
                                    <div className="mt-3">
                                        <Pagination size="small" total={lengthV36} defaultPageSize={1} className="mt-auto" current={parseInt(v36Index) + 1}
                                            onChange={page => paginationHandler(page, filePath, "v36")} />
                                    </div>
                                </div>
                            </Card>
                        </div>
                        <div className="col-2">
                            <Card className="mt-2 pl-2 pr-2" style={styles.tableCard} id="tbl_card">
                                <div id="tbl_div" className="mt-3" >
                                    <Table id="tbl_filename" columns={columns} dataSource={dataSource} style={styles.table}
                                        striped bordered hover showHeader={false} pagination={false}
                                        rowClassName={(record, index) => index === selectedIndex ? 'select-row-cal' : ''}
                                        onRowClick={handleRowClick} size="middle"
                                    />
                                </div>
                            </Card>
                        </div>
                        <div className="col-5">
                            <Card className="mt-2 pl-2 pr-2" style={styles.card}>
                                <div className="d-flex mt-1 mb-2">
                                    <Tooltip placement="right" title={locale.version_40} >
                                        <Chip variant="outlined" style={styles.chipStyle} label={locale.hue_screen} className="ml-1 mt-1" />
                                    </Tooltip>
                                    <div className="d-flex ml-auto" >
                                        <Tooltip placement="bottomLeft" title={locale.delete_screenshot}>
                                            <AntButton icon="delete" className="mr-2 mt-1" type="danger" disabled={!lengthV40 || formStatus === formStatusList[2]} onClick={() => deleteHandler(path, filePath)} style={styles.userView} />
                                        </Tooltip>
                                        <div style={styles.userView}>
                                            <Upload {...props} fileList={fileList} beforeUpload={(file) => beforeUpload(file, ownDpr)} supportServerRender={true} >
                                                <Tooltip placement="bottomLeft" title={locale.upload_screenshot}>
                                                    <AntButton type="primary" className="mr-2 mt-1">
                                                        <Icon type="upload" />
                                                    </AntButton>
                                                </Tooltip>
                                            </Upload>
                                        </div>
                                        <Select className="mr-2 mt-1" style={styles.select} defaultValue={formStatusList[0]} value={formStatus ? formStatus : formStatusList[0]}
                                            onChange={status => updateFormControlDataHandler(status, selectedData)} disabled={(!ownDpr) || (!lengthV40)}>
                                            {formStatusList.map((value, index) => (<Select.Option key={value} value={value}>{statusLocale[index]}</Select.Option>))}
                                        </Select>
                                        <Button className="mt-1" size="sm" variant="outline-success" onClick={openComment} style={styles.userView} >{locale.comment}</Button>
                                        <Tooltip placement="bottomLeft" title={locale.full_view}>
                                            <AntButton icon="fullscreen" className="ml-2 mt-1" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v40' }) }} />
                                        </Tooltip>
                                    </div>
                                </div>
                                <div>
                                    <Card id="imgv36Card" className="border border-dark" onClick={() => { this.setState({ showFullScreen: true, slideshowContent: 'v40' }) }}>
                                        <Card.Img variant="top" src={lengthV40 ? v40[v40Index] : noImage} height="520" />
                                    </Card>
                                    <div className="mt-3">
                                        <Pagination size="small" total={lengthV40} defaultPageSize={1} className="mt-auto" current={parseInt(v40Index) + 1}
                                            onChange={page => paginationHandler(page, filePath, "v40")} />
                                    </div>
                                </div>
                            </Card>
                        </div>
                    </div>
                </div>
                <ImageView images={selectedData} version={slideshowContent} show={showFullScreen} onClose={(index, filePath, version) => { this.setState({ showFullScreen: false }); paginationHandler(index + 1, filePath, version) }} view="slide" />
            </React.Fragment>
        );
    }
}