import React from 'react'
import {H5,H2} from '@blueprintjs/core';
import {Progress} from 'antd';
import '../styles/antd_modified.css';
import locale from '../localization/verupLocalization';
class ProgressView extends React.Component{
    render(){
        const {title,status,color} = this.props;
        const {notYetStarted,pending,reviewedCount} = status;
        const total = notYetStarted+pending+reviewedCount
        const percent = (reviewedCount*100)/total;
        return(
        <div>
            <div className="d-flex">
            <div className="d-flex flex-column">
                <H5 className="mx-auto">{title}</H5>
                <Progress style={{color:'black'}}  strokeColor={color} percent={percent} type="dashboard" format={(percent)=>percent===100?'Done':percent}/>
            </div>
            <div className="d-flex ml-4  flex-column">
                <div className="d-flex"> <H5 className="text-secondary mt-2 mr-2">{locale.not_started_sts}</H5><H2 className="text-primary ml-auto">{notYetStarted}</H2> </div>
                <div className="d-flex"> <H5 className="text-secondary mt-2">{locale.pending_sts}</H5><H2 className="text-danger ml-auto">{pending}</H2> </div>
                <div className="d-flex"> <H5 className="text-secondary mt-2">{locale.Reviewed_sts}</H5><H2 className="text-success ml-auto">{reviewedCount}</H2> </div>
                <div className="d-flex"> <H5 className="text-secondary mt-2">{locale.total}</H5><H2 className="text-warning ml-auto">{total}</H2> </div>
            </div>
            </div>
        </div>
        )
    }
}
export default ProgressView;