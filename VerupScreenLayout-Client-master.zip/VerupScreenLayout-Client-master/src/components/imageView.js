import React from 'react';
import ReactBnbGallery from 'react-bnb-gallery'
import 'react-bnb-gallery/dist/style.css';
import '../styles/bnb-gallery.css';

class ImageView extends React.Component{
    constructor(props){
        super(props)
        this.ImageViewRef = React.createRef();
    }
    generateImagePreview = (images,version) => {
        const photos =  images[version].map((link,index)=>{
            return {
                number : index,
                photo : link,
                caption : images.fileName,
                subcaption : images.filePath
            }
        })
        return photos;
    }
    onClose = ()=>
    {   
        const {onClose,images,version} = this.props;
        const index = this.ImageViewRef.current.gallery.current.state.activePhotoIndex 
        onClose(index,images.filePath,version);
    }
    render(){
        const {images,version,view} = this.props;
        const photos = this.generateImagePreview(images,version);
        const selectedIndex = version === 'v36' ? 'v36Index' : 'v40Index';
        let index = parseInt( view === 'list' ?  images.activeIndex.list[selectedIndex]: images.activeIndex.slide[selectedIndex]);
        return(
            <ReactBnbGallery ref={this.ImageViewRef} activePhotoIndex={index===-1?0:index} show={this.props.show} photos={photos} onClose={this.onClose}/>
        )
    }
}
export default ImageView