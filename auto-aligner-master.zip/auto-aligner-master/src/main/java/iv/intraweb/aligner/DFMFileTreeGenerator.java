package iv.intraweb.aligner;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import iv.intraweb.entity.ComponentStructure;
import iv.intraweb.entity.ComponentStructure.ComponentStructureBuilder;
import iv.intraweb.entity.DFMData;
import iv.intraweb.entity.DFMObject;

public class DFMFileTreeGenerator {

	public static void arrangeCurrentPanel(DFMObject panel) {
		DFMObject currentPanel = panel;
		if(currentPanel.getChild().size() > 0) {
			List<ComponentStructure> childComponents = new ArrayList<>();
			for(int counter = 0; counter < currentPanel.getChild().size(); counter++) {
				ComponentStructureBuilder builder = ComponentStructure.builder();
				builder.componentId(currentPanel.getChild().get(counter).getName());
				builder.componentType(currentPanel.getChild().get(counter).getClassName());
				String top = "", left = "", width = "", height = "", caption = "";
				if(Objects.isNull(currentPanel.getChild().get(counter).getData())) {
					continue;
				}
				for(String key: currentPanel.getChild().get(counter).getData().keySet()) {
					if(key.trim().split("=")[0].equalsIgnoreCase("left")) 
						left = currentPanel.getChild().get(counter).getData().get(key).toString();
					else if(key.trim().split("=")[0].equalsIgnoreCase("top")) 
						top = currentPanel.getChild().get(counter).getData().get(key).toString();
					else if(key.trim().split("=")[0].equalsIgnoreCase("width")) 
						width = currentPanel.getChild().get(counter).getData().get(key).toString();
					else if(key.trim().split("=")[0].equalsIgnoreCase("height")) 
						height = currentPanel.getChild().get(counter).getData().get(key).toString();
					else if(key.trim().split("=")[0].equalsIgnoreCase("caption")) 
						caption = currentPanel.getChild().get(counter).getData().get(key).toString();
				}
				if(!StringUtils.isEmpty(top)) 
					builder.top(Integer.parseInt(top));
				if(!StringUtils.isEmpty(width)) 
					builder.width(Integer.parseInt(width));
				if(!StringUtils.isEmpty(left)) 
					builder.left(Integer.parseInt(left));
				if(!StringUtils.isEmpty(height)) 
					builder.height(Integer.parseInt(height));
				if(!StringUtils.isEmpty(caption)) 
					builder.caption(caption);
				childComponents.add(builder.build());
			}
			if(!childComponents.isEmpty()) {
				List<ComponentStructure> sortedList = childComponents.stream().sorted(Comparator.comparing(ComponentStructure::getTop).thenComparing(ComponentStructure::getLeft))
						.collect(Collectors.toList());


				List<ComponentStructure> alignedData = DFMFileTreeGenerator.makeAbsRowsAndColumns(sortedList);
				for(int counter = 0; counter < currentPanel.getChild().size(); counter++) {

					DFMObject currentChild = currentPanel.getChild().get(counter);

					List<ComponentStructure> comp = alignedData.stream().filter(rec -> 
					rec.getComponentId().trim().contains(currentChild.getName().trim().split(" ")[1].trim())).collect(Collectors.toList());
					if(!comp.isEmpty()) {
						Map<String, DFMData> inputMap = currentChild.getData();
						if(currentChild.getClassName().toLowerCase().contains("date")
								||currentChild.getClassName().toLowerCase().contains("time")) {
							inputMap.entrySet().forEach(rec -> {
								if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("width"))
									inputMap.put(rec.getKey(), new DFMData(String.valueOf(180)));
							});
						}
						if(currentChild.getClassName().toLowerCase().contains("label")) {
							inputMap.entrySet().forEach(rec -> {
								if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("width"))
									inputMap.put(rec.getKey(), new DFMData(String.valueOf(208)));
							});
						}
						if(currentChild.getClassName().toLowerCase().contains("button")) {
							inputMap.entrySet().forEach(rec -> {
								if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("width"))
									inputMap.put(rec.getKey(), new DFMData(String.valueOf(40)));
							});
						}
						inputMap.entrySet().forEach(rec -> {
							if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("left")) 
								inputMap.put(rec.getKey(), new DFMData(String.valueOf(comp.stream().findFirst().get().getLeft())));
							if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("top")) 
								inputMap.put(rec.getKey(), new DFMData(String.valueOf(comp.stream().findFirst().get().getTop())));
							if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("height")) 
								inputMap.put(rec.getKey(), new DFMData("32"));
							if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("align")) 
								inputMap.put(rec.getKey(), new DFMData("alNone"));
//							if(rec.getKey().trim().split("=")[0].equalsIgnoreCase("width")) 
//								inputMap.put(rec.getKey(), new DFMData("208"));
						});
					}
				}
			}
		}

		int maxHeight = 0;
		int maxWidth = 0;
		int maxLeft = 0;
		String leftMostComponent = new String();

		for(DFMObject child : currentPanel.getChild()) {
			if(Objects.nonNull(child.getData())) {
				for(Map.Entry<String,DFMData> entry: child.getData().entrySet()) {
					if(entry.getKey().trim().split("=")[0].equalsIgnoreCase("top")) {
						int top = Integer.parseInt(child.getData().get(entry.getKey()).toString());
						if(top > maxHeight) {
							maxHeight += top;
						}
					}
					if(entry.getKey().trim().split("=")[0].equalsIgnoreCase("left")) {
						int left = Integer.parseInt(child.getData().get(entry.getKey()).toString());
						if(left > maxLeft) {
							maxLeft = left;
							leftMostComponent = child.getName();
						}
					}
				}
			}
		}

		Map<String, DFMData> parentDataMap = currentPanel.getData();

		if(Objects.nonNull(parentDataMap)) {
			for(Map.Entry<String, DFMData> entry: parentDataMap.entrySet()) {
				if(entry.getKey().trim().split("=")[0].equalsIgnoreCase("height")) {
					parentDataMap.put(entry.getKey(), new DFMData(String.valueOf(maxHeight + 40)));
				}
			}
		}
	}

	private static List<ComponentStructure> makeAbsRowsAndColumns(List<ComponentStructure> sortedList) {
		List<ComponentStructure> alignedList = sortedList;
		List<ComponentStructure> finalResList = new ArrayList<>();
		int assumedTop = alignedList.stream().findFirst().get().getTop();
		int assumedLeft = alignedList.stream().findFirst().get().getLeft();
		for(int counter = 0; counter < alignedList.size(); counter++) {
			if(alignedList.get(counter).getHeight() < 40) {
				if((alignedList.get(counter).getTop() <= assumedTop + 10) && (alignedList.get(counter).getTop() >= assumedTop - 10)) 
					alignedList.get(counter).setTop(assumedTop);
				else {
					assumedTop = alignedList.get(counter).getTop();
					alignedList.get(counter).setTop(assumedTop);
				}
			}
		}
		for(int counter = 0; counter < alignedList.size(); counter++) {
			try {
				if(Objects.nonNull(alignedList.get(counter).getComponentType()) && (alignedList.get(counter).getComponentType().contains("Image") || alignedList.get(counter).getComponentType().contains("Shape")
						|| alignedList.get(counter).getComponentType().contains("Bevel")))
					continue;
				if(alignedList.get(counter).getHeight() < 40) {
					if((alignedList.get(counter).getLeft() <= assumedLeft + 10) && (alignedList.get(counter).getLeft() >= assumedLeft - 10)) 
						alignedList.get(counter).setLeft(assumedLeft);
					else {
						assumedLeft = alignedList.get(counter).getLeft();
						alignedList.get(counter).setLeft(assumedLeft);
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		alignedList = alignedList.stream().sorted(Comparator.comparing(ComponentStructure::getTop).thenComparing(ComponentStructure::getLeft))
				.collect(Collectors.toList());
		List<List<ComponentStructure>> rowData = new ArrayList<>();
		List<List<ComponentStructure>> stdAppliedData = new ArrayList<>();
		int currentTop = alignedList.stream().findFirst().get().getTop();
		List<ComponentStructure> currentRow = new ArrayList<>();
		for(int a = 0; a < alignedList.size(); a++) {

			//			if(alignedList.get(a).getHeight() > 10) {

			if(alignedList.get(a).getTop() == currentTop) 
				currentRow.add(alignedList.get(a));
			else {
				rowData.add(currentRow);
				currentRow = new ArrayList<>();
				currentRow.add(alignedList.get(a));
				currentTop = alignedList.get(a).getTop();
			}
			//			} else {
			//				rowData.add(currentRow);
			//				currentRow = new ArrayList<>();
			//				currentRow.add(alignedList.get(a));
			//			}
		}
		rowData.add(currentRow);
		for(int counter = 0; counter < rowData.size(); counter++) {
			if(rowData.get(counter).isEmpty()) {
				rowData.remove(counter);
			}
		}
		int currentop = 8;
		boolean minRowFlag = false;
		int minRowHeight = 0;
		for(int a = 0; a < rowData.size(); a++) {
			for(int counter = 0; counter < rowData.get(a).size(); counter++) {
				rowData.get(a).get(counter).setTop(currentop);
			}
			stdAppliedData.add(DFMFileTreeGenerator.setGeneralWidth(rowData.get(a)));
			currentop = currentop + 40;
		}
		stdAppliedData.stream().forEach(data -> {
			data.stream().forEach(rec -> {
				finalResList.add(rec);
			});
		});
		return finalResList;
	}

	private static List<ComponentStructure> setGeneralWidth(List<ComponentStructure> rowData) {
		int leftVal = 16;
		List<ComponentStructure> stdAppliedRow = new ArrayList<>();
		for(int counter = 0; counter < rowData.size(); counter++) {
			ComponentStructure currentComp = rowData.get(counter);
			if(Objects.nonNull(currentComp.getComponentType())) {
				if(currentComp.getComponentType().toLowerCase().contains("label")) {
					if(Objects.nonNull(currentComp.getCaption()) && currentComp.getCaption().toLowerCase().contains("#65374")) {
						currentComp.setLeft(leftVal);
						currentComp.setWidth(40);
						leftVal = leftVal + 48;
						stdAppliedRow.add(currentComp);
					} else {
						currentComp.setLeft(leftVal);
						currentComp.setWidth(208);
						leftVal = leftVal + 216;
						stdAppliedRow.add(currentComp);
					}
				} else if(currentComp.getComponentType().toLowerCase().contains("combo") || currentComp.getComponentType().toLowerCase().contains("currency") 
						|| currentComp.getComponentType().toLowerCase().contains("edit")) {
					currentComp.setLeft(leftVal);
					if((currentComp.getWidth() >= 0 && currentComp.getWidth() <= 60)) 
						leftVal = leftVal + 68; 
					if((currentComp.getWidth() >= 61 && currentComp.getWidth() <= 120)) 
						leftVal = leftVal + 128; 
					if((currentComp.getWidth() >= 121 && currentComp.getWidth() <= 240)) 
						leftVal = leftVal + 248; 
					if((currentComp.getWidth() >= 241 && currentComp.getWidth() <= 480)) 
						leftVal = leftVal + 488; 
					if((currentComp.getWidth() >= 481 && currentComp.getWidth() <= 720)) 
						leftVal = leftVal + 728; 
					if((currentComp.getWidth() >= 721)) 
						leftVal = leftVal + currentComp.getWidth(); 
					stdAppliedRow.add(currentComp);
				} else if(currentComp.getComponentType().toLowerCase().contains("button")) {
					currentComp.setLeft(leftVal);
					leftVal = leftVal + 48;
					stdAppliedRow.add(currentComp);
				} else if(currentComp.getComponentType().toLowerCase().contains("date") 
						|| currentComp.getComponentType().toLowerCase().contains("time")) {
					currentComp.setLeft(leftVal);
					leftVal = leftVal + 188;
					stdAppliedRow.add(currentComp);
				}

				else 
					stdAppliedRow.add(currentComp);
			}
		}
		return stdAppliedRow;
	}

}
