package iv.intraweb.parentfinder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Stack;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;

public class DFMParentFinder {

    private static String resultData[] = new String[3];

    public static String[] getMissingAttrFromParent(HSSFSheet sheet, String targetDfm, String compId) throws IOException {
        String[] inputData = getComponentAttributes(targetDfm, compId);
        if (StringUtils.isNotEmpty(inputData[0]))
            resultData[0] = inputData[0];
        if (StringUtils.isNotEmpty(inputData[1]))
            resultData[1] = inputData[1];
        if (StringUtils.isNotEmpty(inputData[2]))
            resultData[2] = inputData[2];
        HSSFSheet worksheet = sheet;
        File pasFile = new File(targetDfm.replaceAll("hue_client", "company_client").replaceAll(".dfm", ".pas"));
        if (!pasFile.exists())
            return resultData;
        String parentLine = FileUtils.readLines(pasFile, Charset.defaultCharset()).stream().filter(line -> line.contains("class(")).findFirst().orElse(null);
        String parentName = parentLine.substring(parentLine.indexOf("(") + 1, parentLine.indexOf(")"));
        parentName = parentName.replace("T", "").replaceAll("Frame", "Frm").replaceAll("Dialog", "Dlg") + ".pas";
        String parentPath = new String();
        int startRowNum = 12;
        int lastRow = worksheet.getLastRowNum();
        for (int c = startRowNum; c < lastRow; c++) {
            if (worksheet.getRow(c).getCell(34).getStringCellValue().contains(parentName)) {
                parentPath = getProductPath(worksheet.getRow(c).getCell(34).getStringCellValue()) + worksheet.getRow(c).getCell(34).getStringCellValue();
                break;
            } else
                continue;
        }
        File parentDfm = new File(parentPath.replaceAll(".pas", ".dfm"));
        if (parentDfm.exists()) {
            String[] res = getComponentAttributes(parentPath, compId);
            if (StringUtils.isEmpty(resultData[0])) {
                resultData[0] = res[0];
            }
            if (StringUtils.isEmpty(resultData[1])) {
                resultData[1] = res[1];
            }
            if (StringUtils.isEmpty(resultData[2])) {
                resultData[2] = res[2];
            }
            if (StringUtils.isEmpty(resultData[0]) || StringUtils.isEmpty(resultData[1]) || StringUtils.isEmpty(resultData[2])) {
                getMissingAttrFromParent(sheet, parentPath, compId);
            }
        }
        return resultData;
    }

    private static String[] getComponentAttributes(String targetDfm, String compId) throws IOException {
//        File dfmFile = new File(targetDfm.replaceAll("hue_client", "company_client").replaceAll(".pas", ".dfm"));
        File dfmFile = new File(targetDfm.replaceAll("hue_client", "company_client").replaceAll(".pas", ".dfm").replaceAll("\\\\before\\\\", "\\\\").replaceAll("/before/", "/"));
        if (!dfmFile.exists()) {
            return new String[3];
        }
        FileReader fr = new FileReader(dfmFile);
        BufferedReader br = new BufferedReader(fr);
        String[] resArr = new String[3];
        String line = new String();
        while ((line = br.readLine()) != null) {
            if (line.contains(compId) && (line.contains("inherited") || line.contains("object"))) {
                Stack<String> stk = new Stack<String>();
                while (true) {
                    String subLine = br.readLine();
                    if (subLine.contains("inherited") || subLine.contains("object") || subLine.contains("item"))
                        stk.push("ignore");
                    else if (subLine.contains("end")) {
                        if (stk.isEmpty())
                            break;
                        else
                            stk.pop();
                    }
                    if (stk.isEmpty()) {
                        if (subLine.split("=")[0].trim().equalsIgnoreCase("left"))
                            resArr[1] = subLine.substring(subLine.indexOf("=") + 1, subLine.length()).trim();
                        if (subLine.split("=")[0].trim().equalsIgnoreCase("top"))
                            resArr[0] = subLine.substring(subLine.indexOf("=") + 1, subLine.length()).trim();
                        if (subLine.split("=")[0].trim().equalsIgnoreCase("width"))
                            resArr[2] = subLine.substring(subLine.indexOf("=") + 1, subLine.length()).trim();
                    }
                }
            }
        }
        br.close();
        return resArr;
    }

    private static String getProductPath(String dprPath) {
        String resultPath = new String();
        if (dprPath.contains("\\")) {
            String product = dprPath.substring(0, dprPath.indexOf("\\")).toLowerCase();
            if (product.equalsIgnoreCase("share") || product.equalsIgnoreCase("accommon") || product.equalsIgnoreCase("common")) {
                product = "cac";
            }
            String productName = "hue-ac-chennai-" + product;
            resultPath = "C:\\HUE\\Workspace\\Develop\\" + productName + "\\company_client\\delphi\\";
        }
        return resultPath;
    }

}
