package iv.intraweb.index;


import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.logging.FileHandler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.swing.UnsupportedLookAndFeelException;

public class DFMLauncher {

    private static Logger logger;

    public static boolean isWorksheetMode; // for determining currentMode (not for debugging)

    public static boolean sysoutShow = !false;

    public static boolean isDebug = true;

    public static boolean debugForSingle = true; // works if isDebug is true

    // dummy for jar
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SecurityException, UnsupportedLookAndFeelException, IOException {
        callmain(args);
    }

    public static void callmain(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, SecurityException, IOException {
        logger = Logger.getLogger("Aligner Log");

        FileHandler fh;

        File f = new File("logs\\");
        if (!f.exists()) {
            f.mkdir();
        }

        // This block configure the logger with handler and formatter
        fh = new FileHandler("logs/AutoAligner_Log_" + getTimeStamp() + ".log");
        logger.addHandler(fh);
        SimpleFormatter formatter = new SimpleFormatter() {
            @Override
            public String format(LogRecord record) {
                return record.getMessage() + "\r\n";
            }
        };
        fh.setFormatter(formatter);
        logger.setUseParentHandlers(false); // disable console output (will do it manually)

//        if (isDebug) { // debugging
//            makeLog("[WARNING] Tool in debug mode (was not reset after last delta). Contact developer for reissue.", true);
            if (debugForSingle) {
                isWorksheetMode = false;
                DFMSingleFileProcessFront.initializeGui();
            } else {
                isWorksheetMode = true;
                DFMWorksheetProcessFront.initializeGui();
            }
//        } else {
//            if (args.length > 0 && args[0].equals("-s")) {
//                isWorksheetMode = false;
//                DFMSingleFileProcessFront.initializeGui();
//            } else if (args.length > 0 && args[0].equals("-w")) {
//                isWorksheetMode = true;
//                DFMWorksheetProcessFront.initializeGui();
//            } else {
//                makeLog("[ERROR] Kindly open the tool through .bat files (Single or Worksheet mode) and not through runnable jar.", true);
//            }
//        }
    }

    private static String getTimeStamp() {
        return new Timestamp(Calendar.getInstance().getTimeInMillis()).toString().replace(" ", "_").replace(":", "_");
    }

    public static void makeLog(String msg, boolean... sysout) { // true for out, true, true for err
        if (sysoutShow) {
            System.out.println(msg);
        } else if (sysout.length > 0) {
            System.out.println(msg);
        }
        if (!msg.isEmpty()) {
            logger.info(msg);
        }
    }

}
