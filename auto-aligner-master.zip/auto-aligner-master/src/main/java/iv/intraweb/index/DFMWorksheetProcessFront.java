package iv.intraweb.index;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import iv.intraweb.parser.DFMParser;

public class DFMWorksheetProcessFront {

	public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		initializeGui();
	}

	public static void initializeGui() throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		JFrame f = new JFrame("Intraweb DFM Auto Aligner - Worksheet Mode");
		f.setBounds(0, 0, 600, 148);
		f.setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel input = new JLabel("Input Worksheet Path");
		input.setBounds(20, 20, 180, 22);
		f.add(input);

		JTextField inFile = new JTextField();
		if (DFMLauncher.isDebug)
			inFile.setText("D:\\Task\\Worksheet_PayPlnMng_20190314.xls");
		inFile.setBounds(20, 52, 560, 22);
		f.add(inFile);

		JButton start = new JButton("Auto Align");
		start.setBounds(f.getWidth() - 170, 84, 150, 22);
		f.add(start);

		start.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					//DFMLauncher.makeLog(System.lineSeparator() + "[TOOL] Process started with worksheet process mode." + System.lineSeparator() + "Input file: " + inFile.getText() + System.lineSeparator(), true);
					DFMParser.callWorksheetConvert(inFile.getText());
					System.out.println("Worksheet processing complete");
					//DFMLauncher.makeLog("[TOOL] Worksheet processing complete.", true);
				} catch (IOException e1) {
					DFMLauncher.makeLog("[ERROR] " + e1.getMessage(), true);
					e1.printStackTrace();
				}
			}
		});
		f.setVisible(true);

	}
}
