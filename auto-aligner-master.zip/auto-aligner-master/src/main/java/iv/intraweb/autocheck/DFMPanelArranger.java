package iv.intraweb.autocheck;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;

import iv.intraweb.entity.DFMData;
import iv.intraweb.entity.DFMObject;

public class DFMPanelArranger {



	public static void setColorCode(DFMObject dfmObject) {
		List<DFMObject> objList = new ArrayList<>();
		 setColorCode1(dfmObject,objList);
		 arrangeCurrentPanel(objList);
	}
	
	




	public static void setColorCode1(DFMObject dfmObject, List<DFMObject> objList) {

		for( DFMObject dfmData  :  dfmObject.getChild()) {

			if( CollectionUtils.isNotEmpty(dfmData.getChild())){
				setColorCode1(dfmData,objList);

			}
			objList.add(dfmData);
		}
	}



	public static void  arrangeCurrentPanel(List<DFMObject> panel) {

		for( DFMObject child  :  panel) {
			if(Objects.nonNull(child)) {

				if(isExist(child, "Color") || isExist(child, "Font.Color")) {
					DFMColorCodeFixer.fixColorCode(child);
				}

				
			}

		}
		System.out.println("arrangeCurrentPanel finished..");

	}





	private static boolean isExist(DFMObject node, String paramKey) {
		boolean result = false;
		if(MapUtils.isNotEmpty(node.getData())) {
			return node.getData().entrySet()
					.stream()
					.filter(dfm-> dfm.getKey().trim().split("=")[0].equalsIgnoreCase(paramKey))
					.collect(Collectors.toList()).size() > 0;
		}
		return result;
	}

}
