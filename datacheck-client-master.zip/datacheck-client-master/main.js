import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { logger } from 'redux-logger';
import createSagaMiddleware from 'redux-saga';
import { createStore, compose, applyMiddleware } from 'redux';

import rootSaga from './src/reduxFlow/rootSaga';
import rootReducer from './src/reduxFlow/rootReducer';

import 'bootstrap/dist/css/bootstrap.min.css';
import './src/styles/app.css';
import Navigator from './src/navigator';

const sagaMiddleware = createSagaMiddleware();
let middlewares = applyMiddleware(sagaMiddleware, logger);

const store = createStore(rootReducer, compose(middlewares));

sagaMiddleware.run(rootSaga);

global._babelPolyfill = false;

ReactDOM.render(
  <Provider store={store}>
    <Navigator />
  </Provider>, document.getElementById('app'));