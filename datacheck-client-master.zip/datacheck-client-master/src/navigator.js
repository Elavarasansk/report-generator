import React, { Component } from 'react';
import { Route, Switch, HashRouter } from 'react-router-dom';
import App from './app.js';
import Content from './layout/content';
import ExecutionResult from './layout/executionResult';
import Schedule from './layout/schedule';

class Navigator extends Component{

   render(){
      return(
        <HashRouter>
            <App>
              <Switch>
                <Route path='/content' component={Content} />
                <Route path='/executionResult' component={ExecutionResult} />
                <Route path='/schedule' component={Schedule} />
                </Switch>
            </App>
        </HashRouter>
      );
   }
}
export default Navigator;