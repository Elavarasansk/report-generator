import { put, takeLatest,call } from 'redux-saga/effects';
import { WATCH_EXECUTION_RESULT_DATA } from '../watcherActionTypes/executionResultWatchTypes.js';
import { EXECUTION_RESULT_DATA_STATE } from '../reducerActionTypes/executionResultReducerTypes.js';
import {postServer} from '../../common/serverFile.js';
import {EXECUTION_RESULT_DATA_API} from '../serverConstants/executionResultConstants.js';



function* watchExecutionResultData() {
  yield takeLatest(WATCH_EXECUTION_RESULT_DATA, function* (watchInfo){

    const { param } = watchInfo;
    const data = yield call(postServer,EXECUTION_RESULT_DATA_API,param);
    yield put({ type: EXECUTION_RESULT_DATA_STATE, data });
  });
};


export {
	watchExecutionResultData
}
