import { combineReducers } from 'redux';
import internal from './reducers/internalReducer';
import executionResult from './reducers/executionResultReducer';






export default combineReducers({
  internal,executionResult
});
