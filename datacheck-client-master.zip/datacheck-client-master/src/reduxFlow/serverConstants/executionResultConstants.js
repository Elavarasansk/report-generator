const EXECUTION_RESULT_DATA_API = '/executionresult/getAllSchedulerResults';

export {
    EXECUTION_RESULT_DATA_API
}