import { combineReducers } from 'redux';
import { EXECUTION_RESULT_DATA_STATE } from '../reducerActionTypes/executionResultReducerTypes';

const getExecutionResultDataState = (state = [], action) => {
  const { type, data } = action;
  switch (type) {
    case EXECUTION_RESULT_DATA_STATE:
      return fetchData(data);
    default:
      return state;
  }
};

function fetchData(value) {
	return value.data.data.docs;
}

export default combineReducers({
	getExecutionResultDataState
});
