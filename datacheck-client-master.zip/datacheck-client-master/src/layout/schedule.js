import React, { Component } from 'react';
import { Table } from 'antd';
import { Label, Dialog, Classes } from "@blueprintjs/core";
import "antd/dist/antd.less";

const openDraw = false;
const dataSource = [
	{
		key: '1',
		scheduleName: 'Aarthi',
		dbName: '192.168.1.1',
		time: '8pm',
		erList: '5 tables'
	},
	{
		key: '2',
		scheduleName: 'Vishali',
		dbName: '192.168.1.2',
		time: '9pm',
		erList: '6 tables'
	},
];

const columns = [
	{
		title: 'Schedule Name',
		dataIndex: 'scheduleName',
		key: 'scheduleName',
		width: 150,
	},
	{
		title: 'DB Name',
		dataIndex: 'dbName',
		key: 'dbName',
		width: 150,
	},
	{
		title: 'Time to Run',
		dataIndex: 'time',
		key: 'time',
		width: 150,
	},
	{
		title: 'ER List to Run',
		dataIndex: 'erList',
		key: 'erList',
		width: 150,
	},
];

class Schedule extends Component {
	constructor(props) {
		super(props);
		this.state = {
			finalDataList: dataSource
		};
		this.handleOpenDialog = this.handleOpenDialog.bind(this);
		this.handleCloseDialog = this.handleCloseDialog.bind(this);
	}

	handleOpenDialog() {
		this.setState({
			openDialog: true
		});
	}

	handleCloseDialog() {
		this.setState({
			openDialog: false
		});
	}

	getFilterData = (state, event) => {
		this.setState({
			[state]: event.target.value
		});
	}

	filterSchedulerNames = () => {
		const { scheduleName } = this.state;
		const finalDataList = dataSource.filter(data => (data.scheduleName.indexOf(scheduleName) > -1) || (data.scheduleName.toLowerCase().indexOf(scheduleName) > -1) || (data.scheduleName.toUpperCase().indexOf(scheduleName) > -1));
		this.setState({ finalDataList });
	}

	filterDbItems = () => {
		const { dbItem } = this.state;
		const finalDataList = dataSource.filter(data => (data.dbName.indexOf(dbItem) > -1) || (data.dbName.toLowerCase().indexOf(dbItem) > -1) || (data.dbName.toUpperCase().indexOf(dbItem) > -1));
		this.setState({ finalDataList });
	}

	render() {
		return (
			<div style={{ marginTop: 100, marginLeft: (openDraw ? 242 : 50) }}>
				<table style={{ width: 500 }}>
					<tr>
						<td>
							<Label>
								Name:
        	    	<div class="bp3-input-group .modifier" style={{ width: 200 }}>
									<input class="bp3-input" type="text" placeholder="Name" id="scheduleName" onChange={(event) => this.getFilterData("scheduleName", event)} />
									<button class="bp3-button bp3-minimal bp3-icon-search" onClick={this.filterSchedulerNames}></button>
								</div>
							</Label>
						</td>
						<td>
							<Label>
								DB:
                	<div class="bp3-input-group .modifier" style={{ width: 200 }} >
									<input class="bp3-input" type="text" placeholder="DB" id="dbDetails" onChange={(event) => this.getFilterData("dbItem", event)} />
									<button class="bp3-button bp3-minimal  bp3-icon-search" onClick={this.filterDbItems}></button>
								</div>
							</Label>
						</td>
						<td>
							<button type="button" class="bp3-button bp3-icon-add .modifier" onClick={this.handleOpenDialog} style={{ marginTop: 8 }} >Add</button>
						</td>
					</tr></table>
				<Table dataSource={this.state.finalDataList} columns={columns} bordered />
				<Dialog isOpen={this.state.openDialog} onClose={this.handleCloseDialog} title="Add Details">
					<div className={Classes.DIALOG_BODY}>
						<Label>
							Schedule Name:
        	    	<div class="bp3-input-group .modifier" style={{ width: 200 }}>
								<input class="bp3-input" />
							</div>
						</Label>
						<Label>
							DB Name:
        	    	<div class="bp3-input-group .modifier" style={{ width: 200 }}>
								<input class="bp3-input" />
							</div>
						</Label>
						<Label>
							Time to Run:
        	    	<div class="bp3-input-group .modifier" style={{ width: 200 }}>
								<input class="bp3-input" />
							</div>
						</Label>
						<Label>
							ER List to Run:
        	    	<div class="bp3-input-group .modifier" style={{ width: 200 }}>
								<input class="bp3-input" />
							</div>
						</Label>
					</div>
					<div className={Classes.DIALOG_FOOTER}>
						<div className={Classes.DIALOG_FOOTER_ACTIONS}>
							<button class="bp3-button .modifier" onClick={this.handleCloseDialog}>OK</button>
						</div>
					</div>
				</Dialog>
			</div>
		)
	}
}

export default Schedule;
