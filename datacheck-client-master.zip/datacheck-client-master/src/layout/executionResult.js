import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Table, Button, Dropdown, DatePicker, AutoComplete, Menu } from 'antd';
import { Icon, Card, Position, Classes, Toaster, IToaster, Alert, Intent, Dialog } from "@blueprintjs/core";
import { WATCH_EXECUTION_RESULT_DATA } from '../reduxFlow/watcherActionTypes/executionResultWatchTypes.js';
import 'antd/dist/antd.less';
import moment from 'moment';

const dateFormat = 'YYYY/MM/DD';
const date = new Date();
const ButtonGroup = Button.Group;
const styles = {
	cardComponent: {
		backgroundColor: 'ivory',
		border: '1px solid',
		color: '#ffe58f',
		height: 36,
		padding: 0,
		marginLeft: 20
	},
	iconInfo: {
		marginLeft: 12,
		marginTop: 8
	},
	cardText: {
		color: 'black',
		fontSize: 16
	},
	executionHeader: {
		marginLeft: 20,
		marginTop: 10
	},
	mainDiv: {
		marginTop: 60,
		marginRight: 60
	},
	textInput: {
		width: 420,
	},
	dialogDiv: {
		marginTop: 10,
		marginRight: 60
	},
}
const dataSource = [
	{
		key: '1',
		name: 'Vishali',
		rate: 57,
		runOn: 'Wed Jan 29 2020 09:50:27 GMT+0530',
	},
	{
		key: '2',
		name: 'Aarthi',
		rate: 84,
		runOn: 'Wed Jan 29 2020 09:50:27 GMT+0530',
	},
	{
		key: '3',
		name: 'Saipriya',
		rate: 71,
		runOn: 'Wed Jan 29 2020 09:50:27 GMT+0530',
	}
];
const successResultData = [
	{
		key: '1',
		childTableName: 'PROJECT_INFO',
		successRate: 91
	},
	{
		key: '2',
		childTableName: 'CURRENCY_INFO',
		successRate: 62
	},
	{
		key: '3',
		childTableName: 'BOOK_USER_INFO',
		successRate: 74
	},
	{
		key: '4',
		childTableName: 'BOOK_REFERENCE_INFO',
		successRate: 45
	},
	{
		key: '5',
		childTableName: 'ASSET_INFO',
		successRate: 50
	},
];

class ExecutionResult extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			selectedRowKeys: [],
			loading: false,
			sortedInfo: null,
			isOpenAlert: false,
			isOpenDialog: false,
			isOpenNilRowAlert: false,
			isOpenSelectedRowAlert: false,
			isOpenResultDialog: false,
			isOpenDownloadDialog: false,
			delExecutionDateValue: moment(date).format(dateFormat),
			finalDataList: successResultData
		}
	}
	componentDidMount(){
		const { reduxLoadScheduleData } = this.props;
		const param = {
			  page: 1,
			  sortOptions: {
			  schedulerId : 1,
			  successRate : 1
			}
		}
		reduxLoadScheduleData(param);
	}
	toaster= IToaster;

	onSelectChange = selectedRowKeys => {
		this.setState({ selectedRowKeys });
	};

	sortTableData = (pagination, filters, sorter) => {
		this.setState({
			sortedInfo: sorter
		});
	};

	handleAddRow = (row) => {
		alert(row.name + " " + row.runOn)
	}

	handleDeleteRow = (row) => {
		alert(row.name + " " + row.runOn)
	}

	deleteAll = () => { this.setState({ isOpenAlert: true }) }

	deleteBySchedulerName = () => {
		this.setState({
			isOpenDialog: true,
			deleteMethod: "deleteBySchedulerName"
		})
	}

	deleteBySchedulerNameAndExecutionDate = () => {
		this.setState({
			isOpenDialog: true,
			deleteMethod: "deleteBySchedulerNameAndExecutionDate"
		})
	}

	deleteResultsByCategory = () => {
		const { deleteMethod, valueByOnlySchedulerName, valueBySchedulerName, delExecutionDateValue } = this.state;
		if (deleteMethod == "deleteBySchedulerName") {
			alert(valueByOnlySchedulerName)
		} else if (deleteMethod == "deleteBySchedulerNameAndExecutionDate") {
			alert(valueBySchedulerName + " " + delExecutionDateValue)
		}
	}

	deleteSelectedRows = () => {
		const { selectedRowKeys } = this.state;
		const finalData = [];
		if (selectedRowKeys.length > 0) {
			selectedRowKeys.forEach((key) => {
				dataSource.forEach((value) => {
					if (value.key == key) {
						var data = new Map();
						var currentDate = new Date(value.runOn);
						data.set("name", value.name);
						data.set("runOn", moment(currentDate).format(dateFormat));
						finalData.push(data);
					}
				})
			})
		}
		this.setState({ isOpenSelectedRowAlert: false })
	}

	handleAlertForTable = () => {
		const { selectedRowKeys } = this.state;
		if (selectedRowKeys.length > 0) {
			this.setState({ isOpenSelectedRowAlert: true })
		} else {
			this.setState({ isOpenNilRowAlert: true })
		}
	}

	handleDialogCancel = () => {
		this.setState({
			isOpenDialog: false,
			isOpenResultDialog: false,
			isOpenAlert: false,
			isOpenNilRowAlert: false,
			isOpenSelectedRowAlert: false,
			isOpenDownloadDialog: false
		})
	}

	handleMoveConfirm = () => {
		this.setState({ isOpenAlert: false });
		this.toaster.show({ message: "Records deleted successfully" });
	};

	viewSuccessResultDetails = () => { this.setState({ isOpenResultDialog: true }) }

	selectDownloadPath = () => {
		this.setState({
			isOpenDownloadDialog: true
		})
	}

	selectScheduleDetails = (value) => {
		const { deleteMethod } = this.state;
		if (deleteMethod == "deleteBySchedulerName") {
			this.setState({ valueByOnlySchedulerName: value })
		} else if (deleteMethod == "deleteBySchedulerNameAndExecutionDate") {
			this.setState({ valueBySchedulerName: value })
		}
	}

	getExeChangeDate = (value) => { this.setState({ delExecutionDateValue: value }) }

	filterSchedulerNameList = (value) => {
		const finalDataList = successResultData.filter(data => (data.childTableName.indexOf(value) > -1) || (data.childTableName.toLowerCase().indexOf(value) > -1) || (data.childTableName.toUpperCase().indexOf(value) > -1));
		this.setState({ finalDataList });
	}
	
	render() {
		const { selectedRowKeys } = this.state;
		const exampleMenu = (
			<Menu>
				<Menu.Item onClick={this.deleteAll} >Delete All</Menu.Item>
				<Menu.Item onClick={this.deleteBySchedulerName} >Delete by Scheduler Name</Menu.Item>
				<Menu.Item onClick={this.deleteBySchedulerNameAndExecutionDate} >Delete by Execution Date & Schedule Name</Menu.Item>
			</Menu>
		);
		const deleteConfirmationAlert = (
			<Alert
				cancelButtonText="Cancel"
				confirmButtonText="Delete All"
				intent={Intent.DANGER}
				isOpen={this.state.isOpenAlert}
				onCancel={this.handleDialogCancel}
				onConfirm={this.handleMoveConfirm}>
				<p>Do you want to delete all the records?</p>
			</Alert>
		);
		const nilRowsAlert = (
			<Alert
				confirmButtonText="Okay"
				isOpen={this.state.isOpenNilRowAlert}
				onClose={this.handleDialogCancel}>
				<p>No records selected!</p>
			</Alert>
		);
		const tableSelectedRowsAlert = (
			<Alert
				cancelButtonText="Cancel"
				confirmButtonText="Delete Rows"
				intent={Intent.Primary}
				isOpen={this.state.isOpenSelectedRowAlert}
				onCancel={this.handleDialogCancel}
				onConfirm={this.deleteSelectedRows}>
				<p>Do you want to delete the selected records?</p>
			</Alert>
		);
		const executionDateDiv = (
			<div>
				<div>Execution Date&ensp;&ensp;</div>
				<div style={styles.dialogDiv}>
					<DatePicker defaultValue={moment(date, dateFormat)} format={dateFormat} onChange={this.getExeChangeDate} />
				</div>
			</div>
		);
		let { sortedInfo } = this.state;
		sortedInfo = sortedInfo || {};
		const rowSelection = {
			selectedRowKeys,
			onChange: this.onSelectChange,
		};
		const scheduleNameList = dataSource.map((value) => value.name);
		const finalScheduleNameList = scheduleNameList.filter((x, i, a) => a.indexOf(x) == i);
		const columns = [
			{
				title: 'Scheduler Name',
				dataIndex: 'schedulerId',
				key: 'schedulerId',
				sorter: (a, b) => a.name.localeCompare(b.name),
				sortOrder: sortedInfo.columnKey === 'schedulerId' && sortedInfo.order,
			},
			{
				title: 'Success Rate (in percentage)',
				dataIndex: 'successRate',
				key: 'successRate',
				sorter: (a, b) => a.rate - b.rate,
				sortOrder: sortedInfo.columnKey === 'successRate' && sortedInfo.order,
				render: (rate) => (
					<span>
						{rate}&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
							<Button icon="info-circle" onClick={this.viewSuccessResultDetails} />
					</span>
				),
			},
			{
				title: 'Run ON',
				dataIndex: 'executionDate',
				key: 'executionDate',
			},
			{
				title: 'Query',
				key: 'query',
				width: 120,
				render: (row) => (
					<span>
						<Button icon="plus" disabled={true} onClick={() => this.handleAddRow(row)} />&ensp;&ensp;
						<Button icon="delete" onClick={() => this.handleDeleteRow(row)} />
					</span>
				),
			},
		];
		const successResultsColumns = [
			{
				title: 'Child Table Name',
				dataIndex: 'childTableName',
				key: 'childTableName'
			},
			{
				title: 'Success Rate (in percentage)',
				dataIndex: 'successRate',
				key: 'successRate',
				sorter: (a, b) => a.successRate - b.successRate,
				sortOrder: sortedInfo.columnKey === 'successRate' && sortedInfo.order,
			}
		];
		const deleteRecordsDialog = (
			<Dialog isOpen={this.state.isOpenDialog} onClose={this.handleDialogCancel} isCloseButtonShown={true} title="Delete Execution Results">
				<div className={Classes.DIALOG_BODY}>
					{this.state.deleteMethod == "deleteBySchedulerNameAndExecutionDate" && executionDateDiv}
					<div style={styles.dialogDiv}>
						Scheduler Name&ensp;&ensp;
					</div>
					<div style={styles.dialogDiv}>
						<AutoComplete style={{ width: 200 }} dataSource={scheduleNameList} onSelect={(value) => this.selectScheduleDetails(value)}
							filterOption={(inputValue, option) =>
								option.props.children.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
							} />
					</div>
				</div>
				<div className={Classes.DIALOG_FOOTER}>
					<div className={Classes.DIALOG_FOOTER_ACTIONS}>
						<Button icon="delete" onClick={this.deleteResultsByCategory}>Delete</Button>
					</div>
				</div>
			</Dialog>
		);
		const successResultDialog = (
			<Dialog isOpen={this.state.isOpenResultDialog} onClose={this.handleDialogCancel} isCloseButtonShown={true} title="Success Results">
				<div className={Classes.DIALOG_BODY}>
					<AutoComplete style={{ width: 200 }} dataSource={successResultData.map((data) => data.childTableName)}  onChange={(value) => this.filterSchedulerNameList(value)}
						filterOption={(inputValue, option) => option.props.children.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1} 
					onSelect={(value) => this.filterSchedulerNameList(value)}/>
					<div style={{ marginTop: 10 }}>
						<Table dataSource={this.state.finalDataList} columns={successResultsColumns} onChange={this.sortTableData} bordered pagination={{ defaultPageSize: 10, pageSize: 10, size: 'small' }} />
					</div>
				</div>
			</Dialog>
		);
		const downloadResultDialog = (
			<Dialog isOpen={this.state.isOpenDownloadDialog} onClose={this.handleDialogCancel} isCloseButtonShown={true} title="Download Execution Results">
				<div className={Classes.DIALOG_BODY}>
					<div>
					<input type="text" className={Classes.INPUT} style={styles.textInput} placeholder="e.g) D:\download " />
					</div>
					<div style={{ marginTop: 20}}>
						<Button type="primary">Download Execution Results</Button>
					</div>
				</div>
			</Dialog>
		);
		const { executionResultState } = this.props;

		return (
			<div style={styles.mainDiv}>
				<Card style={styles.cardComponent}>
					<Icon icon="info-sign" iconSize="18px" color="#faad14" style={styles.iconInfo} />&ensp;
					<span style={styles.cardText}>Scheduler information will be updated in every 30 mintues</span>
				</Card>
				<div style={styles.executionHeader}>
					<span>Execution Date&ensp;</span>
					<DatePicker defaultValue={moment(date, dateFormat)} format={dateFormat} id="mainExecutionDate" />
					<span>&ensp;&ensp;Scheduler Name&ensp;</span>
					<AutoComplete style={{ width: 200 }} dataSource={finalScheduleNameList}
						filterOption={(inputValue, option) =>
							option.props.children.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
						}/>
					<ButtonGroup style={{ marginLeft: 400 }}>
						<Button onClick={this.selectDownloadPath}>Download</Button>
						<Button disabled={true}>Add</Button>
					</ButtonGroup>
					<Dropdown.Button onClick={this.handleAlertForTable} overlay={exampleMenu}>Delete</Dropdown.Button>
				</div>
				<div style={styles.executionHeader}>
					<Table rowSelection={rowSelection} dataSource={executionResultState} columns={columns} onChange={this.sortTableData} bordered pagination={{ defaultPageSize: 10, pageSize: 10 }} />
				</div>
				{deleteConfirmationAlert}
				{deleteRecordsDialog}
				{nilRowsAlert}
				{tableSelectedRowsAlert}
				{successResultDialog}
				{downloadResultDialog}
				<div>
					<Toaster ref={ref => (this.toaster = ref)} position={Position.LEFT_BOTTOM} timeout={1800} />
				</div>
			</div>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		executionResultState: state.executionResult.getExecutionResultDataState
	};
  };
  
  const mapDispatchToProps = (dispatch) => {
	return {
	  reduxLoadScheduleData: (param) => dispatch({ type: WATCH_EXECUTION_RESULT_DATA, param })
	};
  };

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ExecutionResult));