import axios from 'axios';

const GET_REQUEST = "get";
const POST_REQUEST = "post";
const PUT_REQUEST = "put";
const DELETE_REQUEST = "delete";

const axiosBase = axios.create({
    baseURL: "http://localhost:3000/v1/",
    responseType: "json"
  });


const buildFormData = multiPartData => {
    let formData = new FormData();
    for(const name of multiPartData) {
        formData.append(name, request[name]);
    }
    return formData;
}

const getServer = async url => {
    let result = await axiosBase.get(url);
    return result;
}

const getServerWithParam = async (url, param) => {
    let result = await axiosBase.get(url, param);
    return result;
}

const putServer = async (url, param) => {
    let result = await axiosBase.put(url, param);
    return result;
}

const postServer = async (url, param) => {
    let result = await axiosBase.post(url,param);
    return result;
}

const deleteServer = async url => {
    let result = await axiosBase.delete(url);
    return result;
}

export default async function serverWebAPI(payload) {
    let url = payload.request.url;
    let data = payload.request.data;
    let response;
    if(payload.request.formData) {
        switch(payload.request.method) {
            case POST_REQUEST:
                multiPartData = url ? payload.request.formData ? buildFormData(payload.request.formData) : "Form Data does not exists" : "Invalid URL";
                response = postServer(url, multiPartData);
                break;
            default:
                response = "Invalid Request";
        }
    } else {
        switch(payload.request.method) {
            case GET_REQUEST:
                response = url ? data ? getServerWithParam(url, data) : getServer(url) : "Invalid URL";
                break;
            case POST_REQUEST:
                response = url ? data ?  postServer(url, data) : "Data does not exists" : "Invalid URL";
                break;
            case PUT_REQUEST:
                response = url ? data ? putServer(url, data) : "Data does not exists" : "Invalid URL";
                break;
            case DELETE_REQUEST:
                response = url ? data ? deleteServer(url, data) : "Data does not exists" : "Invalid URL";
                break;
            default:
                response = "Invalid Request";
        }
    }
    return response;
}


