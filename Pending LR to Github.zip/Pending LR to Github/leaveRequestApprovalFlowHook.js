'use strict';
const { models } = require('../../server/server');
const GlobalHook = require('./globalHook');
const LeaveRequestApprovalService = require('../services/leaveRequestApprovalService');
const ModelDateFilterUtility = require('../utils/modelDateFilterUtility');

const { APPROVAL_FLOW_ACTION_STATUS } = require('../metadata/approvalFlowMeta.json');

module.exports = class LeaveRequestApprovalFlowHook extends GlobalHook {

    constructor(props) {
        super(props);
        const { LeaveRequest } = models;
        this.lras = new LeaveRequestApprovalService();
        const fromDate = "fromDate";
        const toDate = "toDate";
        this.mdfuLeaveRequest = new ModelDateFilterUtility(LeaveRequest, fromDate, toDate);
        this.LeaveRequest = LeaveRequest ;
    }

    beforeTakeActionOnRequestGivenHook = async (ctx) => {
        const { req, details } = ctx.args;
        const { userId } = req.accessToken;
        const { request_id, actionStatus } = details;

        const { LeaveRequestApprovalFlow } = models;
        const { APPROVED, REJECTED_BY_ME, AWAITING_MY_APPROVAL } = APPROVAL_FLOW_ACTION_STATUS;

        if (actionStatus !== APPROVED && actionStatus !== REJECTED_BY_ME) {
            throw new Error(`Invalid action named - '${actionStatus}' is taken on the leave request - ${request_id}`);
        }

        const hasHrRole = await this.lras.checkWhetherRoleIsHR(userId);
        // const where = hasHrRole ? { isHr: true } : { current_approver_id: userId };

        let where = {}, hrFlow = [];
        console.log('*** dont remove unless regression testing done ***', where);
        // if (hasHrRole) {
        //     where = { or: [{ current_approver_id: userId }, { isHr: true }] };
        // } else {
        //     where = { current_approver_id: userId };
        // }
        if (hasHrRole) {
            hrFlow = await LeaveRequestApprovalFlow.find({ where: { isHr: true, request_id, actionStatus: AWAITING_MY_APPROVAL } });
            if (hrFlow.length > 0) {
                where = { id: hrFlow[0].id };
            }
        }
        if (!hasHrRole || (hrFlow.length === 0)) {
            where = { current_approver_id: userId, request_id, actionStatus: AWAITING_MY_APPROVAL }
        }
        console.log('*** dont remove unless regression testing done ***', where);


        where.request_id = request_id;
        const reqFlowDetails = await LeaveRequestApprovalFlow.find({ where });
        if (!reqFlowDetails.length) {
            throw new Error(`Invalid Leave Request - ${request_id}`);
        }
        if (reqFlowDetails[0].actionStatus !== AWAITING_MY_APPROVAL) {
            throw new Error(`Cannot perform action on request which is - ${reqFlowDetails[0].actionStatus}`);
        }
    };

    beforeTakeActionOnMultipleRequestHook = async (ctx) => {
        const { req, details } = ctx.args;
        const { userId } = req.accessToken;
        const { requestIdList, actionStatus, selectAll , filter } = details;


        if (selectAll) {
            const reqIdList = await this.approveAllRequestsGivenToMe(userId ,filter);
            details.requestIdList = reqIdList;
            return;
        }

        const { LeaveRequestApprovalFlow } = models;
        const { APPROVED, REJECTED_BY_ME, AWAITING_MY_APPROVAL } = APPROVAL_FLOW_ACTION_STATUS;

        if (actionStatus !== APPROVED && actionStatus !== REJECTED_BY_ME) {
            throw new Error(`Invalid action named - '${actionStatus}' is taken on the leave request - ${request_id}`);
        }

        let where = {};
        const hasHrRole = await this.lras.checkWhetherRoleIsHR(userId);

        const hrWhereCond = { isHr: true, request_id: { inq: requestIdList }, actionStatus: AWAITING_MY_APPROVAL };
        const normalWhereCond = { current_approver_id: userId, request_id: { inq: requestIdList }, actionStatus: AWAITING_MY_APPROVAL };

        if (hasHrRole) {
            await this.restrictInvalidRequests(hasHrRole, hrWhereCond);
        }
        await this.restrictInvalidRequests(hasHrRole, normalWhereCond);
    };

    restrictInvalidRequests = async (hasHrRole, where) => {
        const { LeaveRequestApprovalFlow } = models;
        const reqFlowDetails = await LeaveRequestApprovalFlow.find({ where });

        if (!hasHrRole && !reqFlowDetails.length) {
            throw new Error(`Invalid Leave Request list - ${request_id}`);
        }

        const { AWAITING_MY_APPROVAL } = APPROVAL_FLOW_ACTION_STATUS;
        const statusList = reqFlowDetails.filter(e => e.actionStatus !== AWAITING_MY_APPROVAL);
        if (statusList.length > 0) {
            throw new Error(`Cannot proceed your request since some of them are not in the status - '${AWAITING_MY_APPROVAL}'`);
        }
        // if (requestIdList.length !== reqFlowDetails.length) {
        //     throw new Error(`Cannot proceed your request since some of them are not in the status - '${AWAITING_MY_APPROVAL}'`);
        // }
    }

    approveAllRequestsGivenToMe = async (current_approver_id , nestedFilter) => {
        let requestIdList = [];
        const { LeaveRequestApprovalFlow } = models;
        const { AWAITING_MY_APPROVAL } = APPROVAL_FLOW_ACTION_STATUS;

        const hasHrRole = await this.lras.checkWhetherRoleIsHR(current_approver_id);

        if (hasHrRole) {
            const hrRequest = await LeaveRequestApprovalFlow.find({ where: { isHr: true, actionStatus: AWAITING_MY_APPROVAL } });
            requestIdList = requestIdList.concat(hrRequest.map(e => e.request_id));
        }

        const normalRequest = await LeaveRequestApprovalFlow.find({ where: { current_approver_id, actionStatus: AWAITING_MY_APPROVAL } });
        requestIdList = requestIdList.concat(normalRequest.map(e => e.request_id));


        const { fromDate, toDate } = nestedFilter;

        delete nestedFilter.fromDate;
        delete nestedFilter.toDate;

        const additionalFilter = { id: { inq: requestIdList }, ...nestedFilter };
        const options = { fields: ["id"] };
        let response = {};

        if (fromDate && toDate) {
            response = await this.mdfuLeaveRequest.findDualRangeDateBetweenDualColumns(fromDate, toDate, additionalFilter, options);
        } else if (fromDate) {
            response = await new ModelDateFilterUtility(this.LeaveRequest, "fromDate").findGreaterDatesFromGivenDate(fromDate, additionalFilter, options);
        } else if (toDate) {
            response = await new ModelDateFilterUtility(this.LeaveRequest, "toDate").findLesserDatesFromGivenDate(toDate, additionalFilter, options);
        } else {
            response.records = await this.LeaveRequest.find({ where: { ...additionalFilter, ...options } });
        }

        requestIdList = response.records ?  response.records.map(e => e.id) : [];

        console.log(requestIdList);

        if (requestIdList.length === 0) {
            throw new Error(`No Request exists`);
        }

        return requestIdList;
    }

    beforeTakeActionOnMultiplePendingRequestHook = async (ctx) => {
        const { details } = ctx.args;
        const { requestIdList, actionStatus, selectAll, filter } = details;
        const { LeaveRequestApprovalFlow, OdRequestApprovalFlow } = models;

        if (selectAll) {
            details.requestIdList = await this.approveAllOrgPendingRequests(filter);
            return;
        }

        const leaveRequestIdList = [];
        const odRequestIdList = [];
        requestIdList.forEach(r=> {
          if(r.type === 'ON-DUTY_LEAVE'){
            odRequestIdList.push(r.id)
          }
          else{
            leaveRequestIdList.push(r.id)
          }
        })

        const { APPROVED, REJECTED_BY_ME, AWAITING_MY_APPROVAL } = APPROVAL_FLOW_ACTION_STATUS;

        if (actionStatus !== APPROVED && actionStatus !== REJECTED_BY_ME) {
            throw new Error(`Invalid action named - '${actionStatus}' is taken on the leave requests`);
        }
        if(leaveRequestIdList.length){
          const leaveReqFlowDetails = await LeaveRequestApprovalFlow.find({ where: { request_id: { inq: leaveRequestIdList }, actionStatus: AWAITING_MY_APPROVAL } });
          if (!leaveReqFlowDetails.length) {
              throw new Error(`Invalid Leave Request list.`);
          }

          const statusList = leaveReqFlowDetails.filter(e => e.actionStatus !== AWAITING_MY_APPROVAL);
          if (statusList.length > 0) {
              throw new Error(`Cannot proceed your request since some status of the requests are changed.`);
          }
        }
        if(odRequestIdList.length){
          const leaveReqFlowDetails = await OdRequestApprovalFlow.find({ where: { request_id: { inq: odRequestIdList }, actionStatus: AWAITING_MY_APPROVAL } });
          if (!leaveReqFlowDetails.length) {
              throw new Error(`Invalid Leave Request list.`);
          }

          const statusList = leaveReqFlowDetails.filter(e => e.actionStatus !== AWAITING_MY_APPROVAL);
          if (statusList.length > 0) {
              throw new Error(`Cannot proceed your request since some status of the requests are changed.`);
          }
        }
    }

    approveAllOrgPendingRequests = async (filter) => {
        const { records } = await this.lras.getOrgPendingLeaveRequest(filter);

        if (!records.length) {
            throw new Error(`No Request exists`);
        }
        let requestIdList = [];
        return requestIdList.concat(records.map(rec => {
          return {
            id:rec.leaveRequestId,
            type:rec.type
          }
        }));
    }

}
