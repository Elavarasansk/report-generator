'use strict';
const { models } = require('../../server/server');
const KairouserService = require('./kairouserService');
const ModelDateFilterUtility = require('../utils/modelDateFilterUtility');
const GeneralUtility = require('../utils/generalUtility');

const APPROVAL_FLOW_META = require('../metadata/approvalFlowMeta.json');
const LEAVE_REQUEST_META = require('../metadata/leaveRequestMeta.json');
const { ORG_PENDING_REQUEST,ORG_PENDING_REQUEST_OD, ORG_FURTHER_APPROVER,  FILTER_DYNAMIC_VALUE, ORG_FURTHER_APPROVER_OD } = require('../constants/orgReportQuery');
const { LEAVE_ALLOTMENT_HR_APPROVAL_LEAVE_TYPE } = require('../constants/query_constants');
const NativeQueryExecutor = require('../nativeSqlWrapper/nativeQueryExecutor');
const DateUtility = require('../utils/dateUtils');

const { LEAVE_TYPE } = LEAVE_REQUEST_META;
const { APPROVAL_REQUEST_STATUS, APPROVAL_FLOW_ACTION_STATUS } = APPROVAL_FLOW_META;

module.exports = class LeaveRequestApprovalService extends NativeQueryExecutor {

    constructor(props) {
        super(props);
        const { LeaveRequest, RoleMapping, ProjectAllocation, KairoRole, KairoUser, LeaveRequestApprovalFlow,OdRequest,OdRequestApprovalFlow } = models;

        this.kus = new KairouserService();
        const fromDate = "fromDate";
        const toDate = "toDate";
        this.mdfuLeaveRequest = new ModelDateFilterUtility(LeaveRequest, fromDate, toDate);
        this.gu = new GeneralUtility();
        this.du = new DateUtility();

        this.RoleMapping = RoleMapping;
        this.ProjectAllocation = ProjectAllocation;
        this.KairoRole = KairoRole;
        this.KairoUser = KairoUser;
        this.LeaveRequest = LeaveRequest;
        this.LeaveRequestApprovalFlow = LeaveRequestApprovalFlow;
        this.OdRequest = OdRequest;
        this.OdRequestApprovalFlow = OdRequestApprovalFlow;
    }


    myRequestDetails = async (applicant_id, request_id) => {
        const fields = ["empId", "email", "username"];
        return await this.LeaveRequestApprovalFlow.find({
            where: { applicant_id, request_id },
            order: 'levelFlow ASC',
            fields: ["actionStatus", "comments", "negativeActionReason", "levelFlow", "isFinal",
                "current_approver_id", "modifiedOn"],
            include: [{
                relation: "currentApprover",
                scope: { fields }
            }]
        });
    }

    requestsGivenToMe = async (current_approver_id, filter, nestedFilter) => {
        const { actionStatus, isFinalString } = filter.where ? filter.where : {};
        const { mixedUserSearch } = nestedFilter ? nestedFilter : {};

        let where = {};
        // const hasHrRole = await this.checkWhetherRoleIsHR(current_approver_id);
        // if (hasHrRole && (!actionStatus || actionStatus === APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL)) {
        //     where.isHr = true;
        // } else {
        //     where.current_approver_id = current_approver_id;
        // }


        where.actionStatus = actionStatus;

        if (isFinalString) {
            where.isFinal = (isFinalString === "true");
        }

        if (!actionStatus) {
            where.actionStatus = APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL;
        }

        //if (nestedFilter && Object.keys(nestedFilter).length > 0) {
            const idList = await this.filterForNestedRequests(current_approver_id, filter, nestedFilter);
            where.request_id = { inq: idList }
        //}

         const hasHrRole = await this.checkWhetherRoleIsHR(current_approver_id);
         if (hasHrRole && (!actionStatus || actionStatus === APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL
            || actionStatus === APPROVAL_FLOW_ACTION_STATUS.WAITING_FOR_PREVIOUS_APPROVERS)) {
            where = { or: [{ isHr : true , ...where }, { current_approver_id, ...where } ] };
        }else {
            where.current_approver_id = current_approver_id;
        }

        console.log('*** dont remove unless regression testing done ***', where);

        const totalCount = await this.LeaveRequestApprovalFlow.count({ ...where });

        const { num, size } = filter.paging ? this.gu.fixPageCount(totalCount, filter.paging) : filter.paging;

        const skip = num * size ;
        const records = await this.LeaveRequestApprovalFlow.find({
            where,
            order: 'createdOn DESC',
            skip,
            limit: size,
            include: [{
                relation: "leaveRequest",
                scope: {
                    fields: ["fromDate", "toDate", "type", "startNoon", "endNoon", "noOfDays",
                        "applicant_id", "actionDueDate", "status", "leaveReason", "withdrawReason"],
                    include: [{
                        relation: "applicant",
                        scope: {
                            fields: ["email", "username","firstName","lastName","fileProfileImage", "empId","isProbation","probationId","probationPrefix"]
                        }
                    }]
                }
            }]
        });

        return {
            totalCount,
            records,
        }
    }

 /*
    checkWhetherRoleIsHR = async (userId) => {

        let hasHrRole = false;
        const userRoleDetails = await this.RoleMapping.find({
            where: { principalId: userId }, fields: ["principalId", "roleId"],
            include: [{
                relation: "user",
                scope: { fields: ["name", "domain", "id"] }
            }]
        });

        for (let i = 0; i < userRoleDetails.length; i++) {
            const userRoleInfo = userRoleDetails[i].toJSON();
            if (userRoleInfo.user.name.toLowerCase().includes('hr')) {
                hasHrRole = true;
                break;
            }
        }
        return hasHrRole;
    }
 */

    checkWhetherRoleIsHR = async (userId) => {
        /* TODO: Actually here include relation name shdn't be user.
           It name shd be KairoRole. But the mistake was done in model-config.json file.
           Correct there and ask for other developers to check and fix the occurences.
        */
        let hasHrRole = false;
        const userRoleDetails = await this.RoleMapping.find({
            where: { principalId: userId }, fields: ["principalId", "roleId"],
            include: [{
                relation: "user",
                scope: { fields: ["name", "domain", "id"] }
            }]
        });

        for (let i = 0; i < userRoleDetails.length; i++) {
            const userRoleInfo = userRoleDetails[i].toJSON();
            if (userRoleInfo.user.name.toLowerCase().includes('hr')) {
                hasHrRole = true;
                break;
            }
        }

        const myProjectRoles = (await this.ProjectAllocation.find({
            where: { employee_id: userId },
            fields: ["role_id"]
        })).map(e => parseInt(e.role_id));

        const userRoleDetailsList = await this.KairoRole.find({ where: { id: { inq: myProjectRoles }}} );

        for (let i = 0; i < userRoleDetailsList.length; i++) {
            const userRoleInfo = userRoleDetailsList[i];
            if (userRoleInfo.name.toLowerCase().includes('hr')) {
                hasHrRole = true;
                break;
            }
        }

        return hasHrRole;
    }

    filterForNestedRequests = async (current_approver_id, filter, nestedFilter) => {
        const { fromDate, toDate,mixedUserSearch } = nestedFilter;
        const { actionStatus, isFinalString } = filter.where;

        let where = {};
        // const hasHrRole = await this.checkWhetherRoleIsHR(current_approver_id);
        // if (hasHrRole && (!actionStatus || actionStatus === APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL)) {
        //     where.isHr = true;
        // } else {
        //     where.current_approver_id = current_approver_id;
        // }
        where.actionStatus = actionStatus;
        if (isFinalString) {
            where.isFinal = (isFinalString === "true");
        }

        console.log('*** dont remove unless regression testing done ***');
        //where.current_approver_id = current_approver_id;
        const hasHrRole = await this.checkWhetherRoleIsHR(current_approver_id);
        if (hasHrRole && (!actionStatus || actionStatus === APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL
            || actionStatus === APPROVAL_FLOW_ACTION_STATUS.WAITING_FOR_PREVIOUS_APPROVERS)) {
            where = { or: [{ isHr : true , ...where }, { current_approver_id, ...where } ] };
        }else {
            where.current_approver_id = current_approver_id;
        }
        console.log('*** dont remove unless regression testing done ***');

        const requestedIdList = (await this.LeaveRequestApprovalFlow.find({
            where,
            fields: ["request_id"]
        })).map(e => e.request_id);

        if (nestedFilter.email) {
            const pattern = new RegExp('.*' + nestedFilter.email + '.*', "i");
            const employeeIdList = (await this.KairoUser.find({
                where: { email: { like: pattern } },
                fields: ["id"]
            })).map(e => e.id);
            nestedFilter.applicant_id = { inq: employeeIdList };
            delete nestedFilter.email;
        }

        if (nestedFilter.applicantEmail) {
            const pattern = new RegExp('.*' + nestedFilter.applicantEmail + '.*', "i");
            const employeeIdList = (await this.KairoUser.find({
                where: { email: pattern },
                fields: ["id"]
            })).map(e => e.id);
            nestedFilter.applicant_id = { inq: employeeIdList };
            delete nestedFilter.applicantEmail;
        }

        if (mixedUserSearch) {
            const userSearch = mixedUserSearch ? mixedUserSearch.startsWith("P-") ? mixedUserSearch.split('-')[1] : mixedUserSearch : '';
            const serachCondition = [
                { firstName: { like: `%${mixedUserSearch}%` } },
                { email: { like: `%${mixedUserSearch}%` } },
                { username: { like: `%${mixedUserSearch}%` } }];
            if (mixedUserSearch.startsWith("P-")) {
                serachCondition.push({ probationId: { like: `%${userSearch}%` } });
            }else if (userSearch) {
                serachCondition.push({ empId: { like: `%${userSearch}%` } });
            }
            const employeeIdList = (await this.KairoUser.find({
                where: {
                    and: [{ or: serachCondition }, { active: true }]
                },
                fields: ["id"]
            })).map(e => e.id);

            nestedFilter.applicant_id = { inq: employeeIdList };
            delete nestedFilter.mixedUserSearch;
        }
        delete nestedFilter.fromDate;
        delete nestedFilter.toDate;

        const additionalFilter = { id: { inq: requestedIdList }, ...nestedFilter };
        const options = { fields: ["id"] };
        let response;

        if (fromDate && toDate) {
            response = await this.mdfuLeaveRequest.findDualRangeDateBetweenDualColumns(fromDate, toDate, additionalFilter, options);
        } else if (fromDate) {
            response = await new ModelDateFilterUtility(this.LeaveRequest, "fromDate").findGreaterDatesFromGivenDate(fromDate, additionalFilter, options);
        } else if (toDate) {
            response = await new ModelDateFilterUtility(this.LeaveRequest, "toDate").findLesserDatesFromGivenDate(toDate, additionalFilter, options);
        } else {
            return await this.LeaveRequest.find({ where: { ...additionalFilter, ...options } }).map(e => e.id);
        }

        return response.records && response.records.map(e => e.id);
    }

    detailsOfRequestGivenToMe = async (userId, request_id) => {
        let reqDetails = await this.LeaveRequestApprovalFlow.find({
            where: { request_id },
            order: 'levelFlow ASC',
            include: [{
                relation: "currentApprover",
                scope: {
                    fields: ["email", "username", "fileProfileImage"]
                }
            }, {
                relation: "leaveRequest",
                scope: {
                    fields: ["applicant_id"]
                }
            }]
        });
        const approversList = reqDetails.map(e => e.current_approver_id);
        reqDetails = JSON.parse(JSON.stringify(reqDetails));

        const hasHrRole = await this.checkWhetherRoleIsHR(userId);

        const userLeaveBalance = await this.kus.getLeaveBalance(reqDetails[0].leaveRequest.applicant_id);
        return approversList.includes(userId) || hasHrRole ? { reqDetails, userLeaveBalance } : [];
    }

    takeActionOnMultipleRequests = async (current_approver_id, details) => {
        const { requestIdList, actionStatus, comments, negativeActionReason } = details;
        const updatedDate = [];
        for (let i = 0; i < requestIdList.length; i++) {
            const request_id = requestIdList[i];
            updatedDate.push(await this.takeActionOnRequestGiven(current_approver_id, { request_id, actionStatus, comments, negativeActionReason }));
        }
        return updatedDate;
    }

    takeActionOnRequestGiven = async (current_approver_id, details) => {
        const { request_id, actionStatus, comments, negativeActionReason } = details;

        console.log('details--------', details);

        // Perform Action on the ApprovalRequest.
        let upsertCondition = {}, hrFlow = [];
        const hasHrRole = await this.checkWhetherRoleIsHR(current_approver_id);
        // const upsertCondition = hasHrRole ? { isHr: true, request_id } : { current_approver_id, request_id };

        if (hasHrRole) {
            hrFlow = await this.LeaveRequestApprovalFlow.find({
                where: {
                    isHr: true, request_id,
                    actionStatus: APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL
                }
            });
            if (hrFlow.length > 0) {
                upsertCondition = { id: hrFlow[0].id };
            }
        }
        if (!hasHrRole || (hrFlow.length === 0)) {
            upsertCondition = { current_approver_id, request_id, actionStatus: APPROVAL_FLOW_ACTION_STATUS.AWAITING_MY_APPROVAL }
        }

        const reqFlowDetails = await this.LeaveRequestApprovalFlow.upsertWithWhere(upsertCondition, {
            current_approver_id, actionStatus,
            comments, negativeActionReason
        });
        console.log('upsertCondition, reqFlowDetails--------', upsertCondition, reqFlowDetails);

        // Update Request Status.
        const { APPLIED, IN_FLOW, APPROVED, REJECTED } = APPROVAL_REQUEST_STATUS;
        let status = (actionStatus !== APPROVED) ? REJECTED : APPLIED;
        if (actionStatus === APPROVAL_FLOW_ACTION_STATUS.APPROVED) {
            status = reqFlowDetails.isFinal ? APPROVED : IN_FLOW;
        }
        await this.LeaveRequest.upsertWithWhere({ id: request_id }, { status });

        console.log('request_id--------', request_id);
        // Audit Leaves & details.
        const { applicant_id, type, noOfDays } = await this.LeaveRequest.findById(request_id);
        if (status === APPROVED) {
            await this.auditLeaveDeatils(applicant_id, type, request_id);
        } else if (status === REJECTED) {
            await this.removeLeaveFromApplied(applicant_id, type, noOfDays);
        }

        console.log('applicant_id--------', applicant_id);
        // Update Nextlevel approvalflow.
        if (!reqFlowDetails.isFinal) {
            const { AWAITING_MY_APPROVAL, REJECTED_BY_ME, REJECTED_BY_OTHERS, WAITING_FOR_PREVIOUS_APPROVERS } = APPROVAL_FLOW_ACTION_STATUS;
            if (actionStatus === REJECTED_BY_ME) {
                await this.LeaveRequestApprovalFlow.updateAll({ request_id, actionStatus: WAITING_FOR_PREVIOUS_APPROVERS },
                    { actionStatus: REJECTED_BY_OTHERS });
                // await this.removeLeaveFromApplied(applicant_id, type, noOfDays);
            }

            if (actionStatus === APPROVAL_FLOW_ACTION_STATUS.APPROVED) {
                await this.LeaveRequestApprovalFlow.upsertWithWhere({ request_id, levelFlow: (reqFlowDetails.levelFlow + 1) },
                    { actionStatus: AWAITING_MY_APPROVAL });
            }
        }

        console.log('final--------', reqFlowDetails);
        return reqFlowDetails;
    }

    auditLeaveDeatils = async (applicant_id, leaveType, leaveRequestId) => {
        const kus = new KairouserService();

        const kairoLeaveInfo = await kus.getLeaveBalance(applicant_id);
        const leaveColName = LEAVE_TYPE[leaveType];

        //Leave applied days should not be negative
        const appliedLeaves = kairoLeaveInfo['leaveApplied'][leaveColName];
        const applied = appliedLeaves < 0 ? 0 : appliedLeaves;

        const leaveDetailsAfterAction = {
            allotted: kairoLeaveInfo['leaveAlloted'][leaveColName],
            applied,
            utilized: kairoLeaveInfo['leaveUtilized'][leaveColName]
        }
        await this.LeaveRequest.upsertWithWhere({ id: leaveRequestId }, { leaveDetailsAfterAction });
    }

    removeLeaveFromApplied = async (userId, leaveType, noOfDays) => {
        const leaveColName = LEAVE_TYPE[leaveType];

        const { leaveApplied } = await this.KairoUser.findById(userId);

        //Leave applied days should not be negative
        const appliedLeaves = leaveApplied[leaveColName] - noOfDays;
        leaveApplied[leaveColName] = appliedLeaves < 0 ? 0 : appliedLeaves;

        await this.KairoUser.upsertWithWhere({ id: userId }, { leaveApplied });
    }

    // moveLeaveFromAppliedToUtilized = async (userId, leaveType, noOfDays) => {
    //     const { KairoUser } = models;
    //     const leaveColName = LEAVE_TYPE[leaveType];

    //     const { leaveApplied, leaveUtilized } = await KairoUser.findById(userId);

    //     leaveApplied[leaveColName] = leaveApplied[leaveColName] - noOfDays;
    //     leaveUtilized[leaveColName] = leaveUtilized[leaveColName] + noOfDays;
    //     await KairoUser.upsertWithWhere({ id: userId }, { leaveApplied, leaveUtilized });
    // }

    getOrgPendingLeaveRequest = async (filter, paging) => {
        const { FILTER_KEY } = ORG_PENDING_REQUEST;
        const { OPEN_LEAVE_STATUS, OPEN_APPROVAL_STATUS } = FILTER_KEY;

        const { conditions,odConditions } = await this.constructFilterCondition(filter);

       const unionStrategy = filter.leaveType?filter.leaveType!=='ON-DUTY_LEAVE'?'LR':'OR':'BOTH';

        conditions.push(OPEN_LEAVE_STATUS);
        conditions.push(OPEN_APPROVAL_STATUS);
        odConditions.push(OPEN_LEAVE_STATUS);
        odConditions.push(OPEN_APPROVAL_STATUS);

        const where = conditions.length > 0 ? ` WHERE ${conditions.join(" AND ")} ` : "";
        const odWhere = unionStrategy!=='LR'?odConditions.length > 0 ? ` WHERE ${conditions.join(" AND ")} ` : "":"";
        paging = paging ? ` LIMIT ${paging.size} OFFSET ${paging.num * paging.size} ` : "";

        const furtherApproverMap = { od: {}, lr: {} };

        (await this.getOrgFurtherApprovers()).map(e => {
          if(e.type === 'ON-DUTY_LEAVE'){
            furtherApproverMap.od[e.request_id] = e.furtherApprovers
          }
          else{
            furtherApproverMap.lr[e.request_id] = e.furtherApprovers
          }
        });
        const response = await this.formOrgPendingReqQuery(where, odWhere, unionStrategy, paging);

        const records = [];
        response.forEach(rec => {
            const { leaveRequestId,type } = rec;
            const furtherApprovers = type==='ON-DUTY_LEAVE'?furtherApproverMap.od[leaveRequestId]:furtherApproverMap.lr[leaveRequestId];
            if (furtherApprovers) {
                rec = { ...rec, furtherApprovers }
            }
            records.push(rec);
        });

        return {
            totalCount: await this.formOrgPendingReqCountQuery(where, odWhere, unionStrategy),
            records
        }
    }

    constructFilterCondition = async (filter)=> {
        const { mixedUserSearch, leaveType, status, currentApproverSearch, fromDate, toDate } = filter;
        const { FILTER_KEY } = ORG_PENDING_REQUEST;

        const conditions = [];
        let odConditions = [];
        if (mixedUserSearch) {
            const userSearch = mixedUserSearch.startsWith('P-') ? mixedUserSearch.split('-')[1] : mixedUserSearch;
            conditions.push(FILTER_KEY.USER_SEARCH.replace(FILTER_DYNAMIC_VALUE.USER_SEARCH, userSearch)
                .replace(FILTER_DYNAMIC_VALUE.USER_SEARCH, userSearch)
                .replace(FILTER_DYNAMIC_VALUE.USER_SEARCH, userSearch)
                .replace(FILTER_DYNAMIC_VALUE.USER_SEARCH, userSearch)
                .replace(FILTER_DYNAMIC_VALUE.USER_SEARCH, userSearch)
                .replace(FILTER_DYNAMIC_VALUE.USER_SEARCH, userSearch));
        }

        if (status) {
            conditions.push(FILTER_KEY.STATUS.replace(FILTER_DYNAMIC_VALUE.STATUS, status));
        }

        if (currentApproverSearch) {
            conditions.push(FILTER_KEY.APPROVER_SEARCH.replace(FILTER_DYNAMIC_VALUE.APPROVER_SEARCH, currentApproverSearch));
        }

        if (fromDate) {
            conditions.push(FILTER_KEY.FROM_DATE.replace(FILTER_DYNAMIC_VALUE.FROM_DATE, this.du.getSqlFormatDatedString(fromDate)));
        }

        if (toDate) {
            conditions.push(FILTER_KEY.TO_DATE.replace(FILTER_DYNAMIC_VALUE.TO_DATE, this.du.getSqlFormatDatedString(toDate)));
        }

        odConditions = [...conditions];

        if (leaveType) {
          conditions.push(FILTER_KEY.LEAVE_TYPE.replace(FILTER_DYNAMIC_VALUE.LEAVE_TYPE, leaveType));
        }

        return {
          conditions,
          odConditions
          };
    }

    formOrgPendingReqCountQuery = async (where, odWhere, unionStrategy,) => {
        const { FROM, INNER_JOIN, ORDER_BY } = ORG_PENDING_REQUEST;
        const { OD_FROM,OD_INNER_JOIN } = ORG_PENDING_REQUEST_OD;
        const formedLrQuery = ` SELECT count(*) as totalCount ${FROM} ${INNER_JOIN.join(' ')} ${where} `
        const formedOdQuery = ` SELECT count(*) as totalCount ${OD_FROM} ${OD_INNER_JOIN.join(' ')} ${where} `
        let formedQuery;
        if(unionStrategy==='BOTH'){
          formedQuery = `SELECT SUM(totalCount) as totalCount from ( ${formedLrQuery} UNION ${formedOdQuery} )tbl1`
        }
        else{
          formedQuery = unionStrategy === 'LR'?formedLrQuery:formedOdQuery;
        }
        const { totalCount } = (await this.executeNativeSQL(formedQuery.replace(/\n/g, '')))[0];
        return totalCount;
    }

    formOrgPendingReqQuery = async (where, odWhere, unionStrategy, paging) => {
        const { SELECT, FROM, INNER_JOIN, GROUP_BY, ORDER_BY } = ORG_PENDING_REQUEST;
        const { OD_SELECT,OD_FROM, OD_INNER_JOIN } = ORG_PENDING_REQUEST_OD;
        const formedLrQuery = `${SELECT.join(',')} ${FROM} ${INNER_JOIN.join(' ')} ${where} ${GROUP_BY} `
        const formedOdQuery = `${OD_SELECT.join(',')} ${OD_FROM} ${OD_INNER_JOIN.join(' ')} ${odWhere} ${GROUP_BY} `
        let formedQuery;
        if(unionStrategy === 'BOTH'){
          formedQuery = `${formedLrQuery} UNION ${formedOdQuery} ${ORDER_BY} ${paging}`
        }
        else{
          formedQuery = `${unionStrategy === 'LR'?formedLrQuery:formedOdQuery} ${ORDER_BY} ${paging}`
        }
        return await this.executeNativeSQL(formedQuery.replace(/\n/g, ''));
    }

    getOrgFurtherApprovers = async () => {
        const { SELECT, FROM, INNER_JOIN, FILTER_KEY, GROUP_BY, ORDER_BY } = ORG_FURTHER_APPROVER;
        const { OD_SELECT,OD_FILTER_KEY,OD_FROM,OD_INNER_JOIN } = ORG_FURTHER_APPROVER_OD;
        const formedQuery = `${SELECT} ${FROM} ${INNER_JOIN.join(' ')} WHERE ${FILTER_KEY} ${GROUP_BY} UNION ${OD_SELECT} ${OD_FROM} ${OD_INNER_JOIN.join(' ')} WHERE ${OD_FILTER_KEY} ${GROUP_BY} ${ORDER_BY} `
        return await this.executeNativeSQL(formedQuery.replace(/\n/g, ''));
    }
    takeActionOnMultiplePendingRequests = async (details) => {
        const { requestIdList, actionStatus, comments, negativeActionReason } = details;
        console.log(requestIdList)
        const leaveRequestIdList = [];
        const odRequestIdList = [];
        requestIdList.forEach(r=> {
          if(r.type === 'ON-DUTY_LEAVE'){
            odRequestIdList.push(r.id)
          }
          else{
            leaveRequestIdList.push(r.id)
          }
        })
;       const { APPROVED, REJECTED, IN_FLOW } = APPROVAL_REQUEST_STATUS;
        const { REJECTED_BY_ME, REJECTED_BY_OTHERS, AWAITING_MY_APPROVAL, WAITING_FOR_PREVIOUS_APPROVERS } = APPROVAL_FLOW_ACTION_STATUS;
        if(leaveRequestIdList.length) {
            const where = {
                request_id: { inq: leaveRequestIdList },
                actionStatus: { inq: [AWAITING_MY_APPROVAL, WAITING_FOR_PREVIOUS_APPROVERS] }
            };

            const conditions = {
                fields: ["id", "actionStatus", "request_id"],
                where
            }

            const apprvlFlowIds = (await this.LeaveRequestApprovalFlow.find({ ...conditions })).map(rec => rec.id);

            if (!apprvlFlowIds.length) {
                throw new Error(`Invalid Leave Request List.`)
            }

            if (actionStatus === REJECTED_BY_ME) {
                const rejectData = {
                    actionStatus: REJECTED_BY_OTHERS,
                    comments: negativeActionReason ? negativeActionReason : 'REJECTED BY HR'
                };
                await this.upsertLeaveRequestApprovalFlow(apprvlFlowIds, rejectData, false);
                await this.upsertLeaveRequest(leaveRequestIdList, REJECTED);
                await this.updateLeaveBalance(leaveRequestIdList);
            } else if (actionStatus === APPROVED) {
                const approveData = {
                    actionStatus: APPROVED,
                    comments: comments ? comments : 'APPROVED BY HR'
                }
                await this.upsertLeaveRequestApprovalFlow(apprvlFlowIds, approveData, true);

                const leaveTypeList = [], updatedRequestIdList = [];
                (await this.executeNativeSQL(LEAVE_ALLOTMENT_HR_APPROVAL_LEAVE_TYPE)).map(e => leaveTypeList.push(e.leaveType));

                const filter = {
                    fields: ["id"],
                    where: { type: { nin: leaveTypeList }, id: { inq: leaveRequestIdList } }
                }
                const leaveRequestList = await this.LeaveRequest.find(filter);
                leaveRequestList.map(e => updatedRequestIdList.push(e.id));

                await this.LeaveRequest.updateAll({ type: { inq: leaveTypeList }, id: { inq: leaveRequestIdList } }, { status: IN_FLOW });

                await this.upsertLeaveRequest(updatedRequestIdList, APPROVED);
            } else {
                throw new Error(`Invalid action performed for Leave Request.`);
            }
        }
        if(odRequestIdList.length) {
            const where = {
              request_id: { inq: odRequestIdList },
              actionStatus: { inq: [AWAITING_MY_APPROVAL, WAITING_FOR_PREVIOUS_APPROVERS] }
          };

          const conditions = {
              fields: ["id", "actionStatus", "request_id"],
              where
          }

          const apprvlFlowIds = (await this.OdRequestApprovalFlow.find({ ...conditions })).map(rec => rec.id);

          if (!apprvlFlowIds.length) {
              throw new Error(`Invalid Leave Request List.`)
          }

          if (actionStatus === REJECTED_BY_ME) {
              const rejectData = {
                  actionStatus: REJECTED_BY_OTHERS,
                  comments: negativeActionReason ? negativeActionReason : 'REJECTED BY HR'
              };
              await this.upsertOdRequestApprovalFlow(apprvlFlowIds, rejectData);
              await this.upsertOdRequest(odRequestIdList, REJECTED);
          } else if (actionStatus === APPROVED) {
              const approveData = {
                  actionStatus: APPROVED,
                  comments: comments ? comments : 'APPROVED BY HR'
              }
              await this.upsertOdRequestApprovalFlow(apprvlFlowIds, approveData);

              await this.upsertOdRequest(odRequestIdList, APPROVED);
          } else {
              throw new Error(`Invalid action performed for Leave Request.`);
          }
        }
        if (actionStatus === REJECTED_BY_ME){
          return `Organisation Pending Request Rejected Successfully`;
        }
        else if (actionStatus === APPROVED){
          return `Organisation Pending Request Approved Successfully`;
        }
    }

    upsertLeaveRequestApprovalFlow = async (apprvlFlowIds, approveData, isApproved) => {
        const { AWAITING_MY_APPROVAL } = APPROVAL_FLOW_ACTION_STATUS;
        const { REJECTED } = APPROVAL_REQUEST_STATUS;
        const actionStatus = isApproved ? AWAITING_MY_APPROVAL : REJECTED;
        for (let id of apprvlFlowIds) {
            await this.LeaveRequestApprovalFlow.upsertWithWhere({ id, isHr: false }, approveData);
            await this.LeaveRequestApprovalFlow.upsertWithWhere({ id, isHr: true }, { actionStatus });
        }
    }

    upsertLeaveRequest = async (requestIdList, status) => {
        for (let id of requestIdList) {
            await this.LeaveRequest.upsertWithWhere({ id }, { status });
        }
    }

    updateLeaveBalance = async (requestIdList) => {
        const rejectedRequestList = await this.LeaveRequest.find({
            fields: ["id", "type", "noOfDays", "applicant_id"],
            where: { id: { inq: requestIdList } }
        });
        for (const { applicant_id, type, noOfDays } of rejectedRequestList) {
            await this.removeLeaveFromApplied(applicant_id, type, noOfDays);
        }
    }

    upsertOdRequestApprovalFlow = async (apprvlFlowIds, approveData) => {
          for (let id of apprvlFlowIds) {
              await this.OdRequestApprovalFlow.upsertWithWhere({ id}, approveData);
          }
      }

      upsertOdRequest = async (requestIdList, status) => {
          for (let id of requestIdList) {
              await this.OdRequest.upsertWithWhere({ id }, { status });
          }
      }

}
