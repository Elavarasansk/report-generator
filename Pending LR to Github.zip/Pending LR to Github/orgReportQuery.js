const FILTER_DYNAMIC_VALUE = {
    FULLDAY: " $fullday$ ",
    SPECIFIC_DATE: " $specific_date$ ",
    SPECIFIC_MONTH: " $specific_month$ ",
    SPECIFIC_YEAR: " $specific_year$ ",
    START_RANGE: " $start_range$ ",
    END_RANGE: " $end_range$ ",
    BOOL_FLAG: " $bool_flag$ ",
    USER_LIST: " $user_list$ ",
    STATUS: " $status_filter$ ",
    LEAVE_TYPE: "$leave_type$ ",
    USER_SEARCH: "$user_search$ ",
    APPROVER_SEARCH: "$approver_search$",
    FROM_DATE: "$from_date$",
    TO_DATE: "$to_date$"
}

const LEAVE_UTILIZATION_REPORT = {
    SELECT: [
        `select sum(lrf.noOfDays) as absentDays, count(distinct(lrf.leave_request_id)) as totalRequests`,
        `group_concat(lrf.dayName separator ',') as daysList`,
        `group_concat(lr.type separator ',') as leaveTypes`,
        `group_concat(lr.project_id separator ',') as projectsApplied`,
        `group_concat(pr.organisation_division_id separator ',') as orgDivApplied`,
        `group_concat(od.organisation_id separator ',') as orgApplied`,
        `group_concat(lr.status separator ',') as leaveStatus`,
        `ku.id as kairo_user_id, ku.username, ku.empId, ku.email, ku.firstName,ku.probationId,ku.probationPrefix`,
        `lr.applicant_id`
    ],
    FROM: `FROM leave_request_fragments as lrf`,
    INNER_JOIN: [
        `INNER JOIN leave_request as lr on lr.id=lrf.leave_request_id`,
        `INNER JOIN kairo_user as ku on ku.id=lr.applicant_id`,
        `INNER JOIN project as pr on pr.id=lr.project_id`,
        `INNER JOIN organisation_division as od on od.id=pr.organisation_division_id`,
        `INNER JOIN organisation as org on org.id=od.organisation_id`
    ],
    FILTER_KEY: {
        UTILIZED_LEAVES: ` lrf.isUtilizationUpdated= ${FILTER_DYNAMIC_VALUE.BOOL_FLAG} `,
        FULLDAY: `isFullday = ${FILTER_DYNAMIC_VALUE.FULLDAY}`,
        SPECIFIC_DATE: `fragmentDate = '${FILTER_DYNAMIC_VALUE.SPECIFIC_DATE}'`,
        SPECIFIC_MONTH: `month = '${FILTER_DYNAMIC_VALUE.SPECIFIC_MONTH}' and year=${FILTER_DYNAMIC_VALUE.SPECIFIC_YEAR} `,
        DATE_RANGE: `fragmentDate >= '${FILTER_DYNAMIC_VALUE.START_RANGE}' and fragmentDate<= '${FILTER_DYNAMIC_VALUE.END_RANGE}'`,
        STATUS: `lr.status IN(${FILTER_DYNAMIC_VALUE.STATUS})`,
        LEAVE_TYPE:`lr.type ='${FILTER_DYNAMIC_VALUE.LEAVE_TYPE}'`,
        USER_SEARCH:`lr.applicant_id IN(SELECT id from kairo_user where username like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' or email like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%'
                      or firstName like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' or empId like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%'
                      or probationId like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' or probationPrefix like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%')`
    },
    GROUP_BY: [
        `group by lr.applicant_id`
    ],
    ORDER_BY: [
        `order by lr.applicant_id`
    ],
    GROUP_PARAMS: {
        ORG_GROUP: `od.organisation_id`,
        ORG_DIV_GROUP: `pr.organisation_division_id`,
        PROJ_GROUP: `lr.project_id`,
    }
}

const ATTENDANCE_TIMSHEET_REPORT = {
    SELECT: [
        `select sum(rcl.loggedHours) as totalLoggedHours,count(distinct(rcl.spentOn)) as totalLoggedDays`,
        `group_concat(rcl.dayName separator ',') as daysList`,

        `group_concat(rcl.kairo_user_project_id separator ',') as projectsApplied`,
        `group_concat(pr.organisation_division_id separator ',') as orgDivApplied`,
        `group_concat(od.organisation_id separator ',') as orgApplied`,
        `ku.id as kairo_user_id, ku.username, ku.empId, ku.email, ku.firstName`
    ],
    FROM: `FROM redmine_consolidated_logdetails as rcl`,
    INNER_JOIN: [
        `INNER JOIN kairo_user as ku on ku.id=rcl.kairo_user_id`,
        `INNER JOIN project as pr on pr.id=rcl.kairo_user_project_id`,
        `INNER JOIN organisation_division as od on od.id=pr.organisation_division_id`,
        `INNER JOIN organisation as org on org.id=od.organisation_id`
    ],
    FILTER_KEY: {
        SPECIFIC_DATE: `spentOn = '${FILTER_DYNAMIC_VALUE.SPECIFIC_DATE}'`,
        SPECIFIC_MONTH: `month = '${FILTER_DYNAMIC_VALUE.SPECIFIC_MONTH}' and year=${FILTER_DYNAMIC_VALUE.SPECIFIC_YEAR} `,
        DATE_RANGE: `spentOn >= '${FILTER_DYNAMIC_VALUE.START_RANGE}' and spentOn<= '${FILTER_DYNAMIC_VALUE.END_RANGE}'`
    },
    GROUP_BY: [
        `group by rcl.kairo_user_id`
    ],
    ORDER_BY: [
        `order by rcl.kairo_user_id`
    ],
    GROUP_PARAMS: {
        ORG_GROUP: `od.organisation_id`,
        ORG_DIV_GROUP: `pr.organisation_division_id`,
        PROJ_GROUP: `rcl.kairo_user_project_id`,
    }
}

const TIMESHEET_LEAVE_DETAILS = {
    SELECT: [
        `select lr.applicant_id, sum(lrf.noOfDays) as absentDays, lrf.isUtilizationUpdated`
    ],
    FROM: `FROM leave_request_fragments as lrf`,
    INNER_JOIN: [
        `INNER JOIN leave_request as lr on lr.id=lrf.leave_request_id`,
        `INNER JOIN project as pr on pr.id=lr.project_id`,
        `INNER JOIN organisation_division as od on od.id=pr.organisation_division_id`,
        `INNER JOIN organisation as org on org.id=od.organisation_id`
    ],
    FILTER_KEY: {
        UTILIZED_LEAVES: ` lr.status not in ('WITHDRAWN','REJECTED') `,
        APPLICANT_LIST: ` applicant_id in (${FILTER_DYNAMIC_VALUE.USER_LIST}) `,
        SPECIFIC_DATE: ` fragmentDate = '${FILTER_DYNAMIC_VALUE.SPECIFIC_DATE}' `,
        SPECIFIC_MONTH: `month = '${FILTER_DYNAMIC_VALUE.SPECIFIC_MONTH}' and year=${FILTER_DYNAMIC_VALUE.SPECIFIC_YEAR} `,
        DATE_RANGE: ` fragmentDate >= '${FILTER_DYNAMIC_VALUE.START_RANGE}' and fragmentDate<= '${FILTER_DYNAMIC_VALUE.END_RANGE}' `
    },
    GROUP_BY: [
        `group by lr.applicant_id, lrf.isUtilizationUpdated`
    ],
    ORDER_BY: [
        `order by lr.applicant_id`
    ],
    GROUP_PARAMS: {
        ORG_GROUP: `od.organisation_id`,
        ORG_DIV_GROUP: `pr.organisation_division_id`,
        PROJ_GROUP: `lr.project_id`,
    }
}

const ORG_PENDING_REQUEST = {
    SELECT: [
        ` SELECT ku.id as userId, ku.email, ku.firstName, ku.username, ku.empId, ku.probationPrefix, ku.probationId `,
        ` lr.id as leaveRequestId, lr.type, lr.fromDate, lr.toDate, lr.startNoon, lr.endNoon, lr.noOfDays, lr.status, lr.leaveReason `,
        ` lraf.isFinal `,
        ` ku1.firstName as currentApprover, ku1.email as approverEmail `
    ],
    FROM: ` FROM leave_request_approval_flow lraf `,
    INNER_JOIN: [
        ` INNER JOIN  kairo_user AS ku ON ku.id = lraf.applicant_id `,
        ` INNER JOIN  kairo_user AS ku1 ON ku1.id = lraf.current_approver_id `,
        ` INNER JOIN  leave_request AS lr ON lr.id = lraf.request_id `
    ],
    FILTER_KEY: {
        OPEN_LEAVE_STATUS: ` lr.status NOT IN ('APPROVED', 'WITHDRAWN', 'REJECTED') `,
        OPEN_APPROVAL_STATUS: ` lraf.actionStatus IN ('AWAITING_MY_APPROVAL') `,
        LEAVE_TYPE: ` lr.type = '${FILTER_DYNAMIC_VALUE.LEAVE_TYPE}' `,
        STATUS: ` lr.status = '${FILTER_DYNAMIC_VALUE.STATUS}' `,
        USER_SEARCH: ` (ku.empId like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.probationId like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.probationPrefix like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%'
        OR ku.email like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.username like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.firstName like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%') `,
        APPROVER_SEARCH: ` ku1.firstName like '%${FILTER_DYNAMIC_VALUE.APPROVER_SEARCH}%' `,
        FROM_DATE: ` lr.fromDate >= '${FILTER_DYNAMIC_VALUE.FROM_DATE}' `,
        TO_DATE: ` lr.toDate <= '${FILTER_DYNAMIC_VALUE.TO_DATE}' `
    },
    GROUP_BY: [
        ` GROUP BY leaveRequestId`
    ],
    ORDER_BY: [
        ` ORDER BY userId `
    ]
}

const ORG_PENDING_REQUEST_OD = {
  OD_SELECT: [
      ` SELECT ku.id as userId, ku.email, ku.firstName, ku.username, ku.empId, ku.probationPrefix, ku.probationId `,
      ` lr.id as leaveRequestId, 'ON-DUTY_LEAVE', lr.fromDate, lr.toDate, lr.startNoon, lr.endNoon, lr.noOfDays, lr.status, lr.leaveReason `,
      ` lraf.isFinal `,
      ` ku1.firstName as currentApprover, ku1.email as approverEmail `
  ],
  OD_FROM: ` FROM od_request_approval_flow lraf `,
  OD_INNER_JOIN: [
      ` INNER JOIN  kairo_user AS ku ON ku.id = lraf.applicant_id `,
      ` INNER JOIN  kairo_user AS ku1 ON ku1.id = lraf.current_approver_id `,
      ` INNER JOIN  od_request AS lr ON lr.id = lraf.request_id `
  ],
  OD_FILTER_KEY: {
      OPEN_LEAVE_STATUS: ` lr.status NOT IN ('APPROVED', 'WITHDRAWN', 'REJECTED') `,
      OPEN_APPROVAL_STATUS: ` lraf.actionStatus IN ('AWAITING_MY_APPROVAL') `,
      STATUS: ` lr.status = '${FILTER_DYNAMIC_VALUE.STATUS}' `,
      USER_SEARCH: ` (ku.empId like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.probationId like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.probationPrefix like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%'
      OR ku.email like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.username like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%' OR ku.firstName like '${FILTER_DYNAMIC_VALUE.USER_SEARCH}%') `,
      APPROVER_SEARCH: ` ku1.firstName like '%${FILTER_DYNAMIC_VALUE.APPROVER_SEARCH}%' `,
      FROM_DATE: ` lr.fromDate >= '${FILTER_DYNAMIC_VALUE.FROM_DATE}' `,
      TO_DATE: ` lr.toDate <= '${FILTER_DYNAMIC_VALUE.TO_DATE}' `
  },
}

const ORG_FURTHER_APPROVER = {
    SELECT: ` SELECT lraf.id, lraf.actionStatus, lraf.request_id as request_id,lraf.applicant_id as applicant_id,lr.type as type, group_concat(ku.firstName separator ',') as furtherApprovers `,
    FROM: ` FROM leave_request_approval_flow AS lraf `,
    INNER_JOIN: [
        ` INNER JOIN  leave_request AS lr ON lr.id = lraf.request_id `,
        ` INNER JOIN  kairo_user AS ku ON ku.id = lraf.current_approver_id `
    ],
    FILTER_KEY: ` lr.status NOT IN ('APPROVED', 'WITHDRAWN', 'REJECTED') AND lraf.actionStatus IN ('WAITING_FOR_PREVIOUS_APPROVERS') AND lraf.isHR = false`,
    GROUP_BY: ` GROUP BY request_id `,
    ORDER_BY: ` ORDER BY applicant_id `
}

const ORG_FURTHER_APPROVER_OD = {
  OD_SELECT: ` SELECT lraf.id, lraf.actionStatus, lraf.request_id as request_id,lraf.applicant_id as applicant_id,'ON-DUTY_LEAVE', group_concat(ku.firstName separator ',') as furtherApprovers `,
  OD_FROM: ` FROM od_request_approval_flow AS lraf `,
  OD_INNER_JOIN: [
      ` INNER JOIN  od_request AS lr ON lr.id = lraf.request_id `,
      ` INNER JOIN  kairo_user AS ku ON ku.id = lraf.current_approver_id `
  ],
  OD_FILTER_KEY: ` lr.status NOT IN ('APPROVED', 'WITHDRAWN', 'REJECTED') AND lraf.actionStatus IN ('WAITING_FOR_PREVIOUS_APPROVERS')`,
}

module.exports = {
    FILTER_DYNAMIC_VALUE,
    LEAVE_UTILIZATION_REPORT,
    ATTENDANCE_TIMSHEET_REPORT,
    TIMESHEET_LEAVE_DETAILS,
    ORG_PENDING_REQUEST,
    ORG_FURTHER_APPROVER,
    ORG_FURTHER_APPROVER_OD,
    ORG_PENDING_REQUEST_OD
}
