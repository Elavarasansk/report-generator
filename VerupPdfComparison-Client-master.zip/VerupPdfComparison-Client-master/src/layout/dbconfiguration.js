import React from 'react';
import { connect } from 'react-redux';
import { Drawer } from '@blueprintjs/core';
import ReactIsCapsLockActive from '@matsun/reactiscapslockactive';
import locale from '../localization/dataCompareLocalization';
import { Form, Table, Input, Spin, Divider, Button, Radio, Popconfirm, Icon, Card, Tag, Result, Tooltip ,Affix} from 'antd';
import {
    WATCH_OPEN_DB_CONFIG_DRAWER,
    WATCH_ENVIRONMENTS,
    WATCH_ADD_ENVIRONMENT,
    WATCH_DELETE_ENVIRONMENT
} from '../reduxFlow/watcherActionTypes/dbConfigurationWatchTypes';
import '../styles/layout/dbConfiguration.css';

class Configuration extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            radioValue: 'VERSION_36',
            popConfirmPassword: false
        }
    }

    componentDidMount = () => {
        const { getAllEnvironmentConfig } = this.props;
        getAllEnvironmentConfig();
    }

    handleDbConfigDrawer = () => {
        const { openConfigDrawer, reduxHandleDbConfigDrawer } = this.props;
        reduxHandleDbConfigDrawer(!openConfigDrawer);
    };

    handleSubmit = (event) => {
        event.preventDefault();
        let isValid = false;
        const { form } = this.props;
        form.validateFields((err) => isValid = !err);
        if (!isValid) {
            return;
        }
        this.insertDatabaseConfiguration();
    };

    insertDatabaseConfiguration = () => {
        const { form ,addEnvironmentConfig} = this.props;
        const param = form.getFieldsValue();
        addEnvironmentConfig(param);
        form.resetFields();
    };

    DeleteDatabaseConfiguration = (row) => {
        const {deleteEnvironmentConfig} = this.props;
        deleteEnvironmentConfig(row.id);
    };

    checkCapsLockOn = () =>{
        let capsChecker = document.getElementsByClassName('caps-checker')[0];
        if (capsChecker) {
            this.setState({ popConfirmPassword: capsChecker.innerText === 'active' })
        }
    }

    render() {
        const { openConfigDrawer, isLoading, items ,isExcutionInprogress} = this.props;
        const { radioValue, popConfirmPassword } = this.state;
        const columns = [
            {
                title: locale.env_name,
                dataIndex: 'name',
                key: 'name',
                rowKey: 'id',
                align: 'center',
                width: 160,
            },
            {
                title: locale.env_version,
                dataIndex: 'environmentType',
                key: 'environmentType',
                align: 'center',
                width: 180,
                filters: [{ text: locale.version_36, value: 'VERSION_36' }, { text: locale.version_40, value: 'VERSION_40' }],
                onFilter: (value, record) => record.environmentType.indexOf(value) === 0
            },
            {
                title: locale.oracle_host_port,
                width: 200,
                align: 'center',
                render: (data) => (
                    <span>
                        <Tag className='margin-round-off' color={'purple'} key={data.host}>{data.host}</Tag> : <Tag className='margin-round-off' color={'purple'} key={data.port}>{data.port}</Tag>
                    </span> 
                )
            },
            {
                title: locale.oracle_sid,
                dataIndex: 'sid',
                key: 'sid',
                align: 'center',
                width: 120,
                render: sid => (
                    <span>
                        <Tag color={'magenta'} key={sid}>{sid}</Tag>
                    </span>
                )
            },
            {
                title: locale.action,
                key: 'action',
                align: 'center',
                width: 120,
                render: (row) => (<span>
                    {false && <Button type='dashed' icon='edit' disabled size='small' shape='round' />}
                    {false && <Divider type='vertical' />}
                    <Popconfirm placement='bottomLeft' title={locale.delete_confirm_message} okText={locale.ok} cancelText={locale.cancel} onConfirm={() => this.DeleteDatabaseConfiguration(row)} icon={<Icon type='question-circle-o' style={{ color: 'red' }} />}>
                        <Button type='button' icon='delete' size='small' shape='square' disabled={isExcutionInprogress}/>
                    </Popconfirm>
                </span>)
            }];
        const { getFieldDecorator } = this.props.form;
        return (<div>
            <Affix>

            
            {openConfigDrawer && <Drawer
                title={locale.db_config}
                isOpen={true}
                onClose={this.handleDbConfigDrawer}
                visible={openConfigDrawer}
                placement='right'
                maskClosable={false}
                width='55%'
                canOutsideClickClose={false}
                >
                <Spin spinning={isLoading} >
                    <div className='container-fluid' style={{ marginTop: '25px' }}>
                        <div className='row' style={{ height: '100%' }} >
                            <div className='col-12' style={{ height: '50%', }} >
                                {/*  className='h-100 card-background-color' */}
                                   <Card  elevation={4}>
                                    <Form onSubmit={this.handleSubmit}>
                                        <div className='d-flex'>
                                            <Form.Item label={locale.env_version} style={{ width: '88%' }}>
                                                {getFieldDecorator('environmentType', {
                                                    initialValue: radioValue,
                                                })(<Radio.Group onChange={(event) => this.setState({radioValue: event.target.value})}>
                                                    <Radio value={'VERSION_36'}>{locale.version_36}</Radio>
                                                    <Radio value={'VERSION_40'}>{locale.version_40}</Radio>
                                                </Radio.Group>)}
                                            </Form.Item>
                                            <Form.Item label={locale.host} className='ml-2' style={{ width: '80%' }}>
                                                {getFieldDecorator('host', {
                                                    rules: [{
                                                        required: true,
                                                        message: locale.host_error_message
                                                    }]
                                                })(<Input allowClear placeholder={locale.host_placeholder}/>)}
                                            </Form.Item>
                                            <Form.Item label={locale.port} className='ml-2' style={{ width: '40%' }}>
                                                {getFieldDecorator('port', {
                                                    rules: [{
                                                        required: true,
                                                        message: locale.port_error_message
                                                    }]
                                                })
                                                    (<Input allowClear placeholder={locale.port_placeholder} />)}
                                            </Form.Item>

                                            <Form.Item label={locale.oracle_sid} className='ml-2' style={{ width: '40%' }}>
                                                {getFieldDecorator('sid', {
                                                    rules: [{
                                                        required: true,
                                                        message: locale.sid_error_message
                                                    }]
                                                })
                                                    (<Input allowClear placeholder={locale.sid_placeholder} />)}
                                            </Form.Item>
                                        </div>
                                        <div className='d-flex'>
                                            <Form.Item label={locale.env_name} style={{ width: '90%' }}>
                                                {getFieldDecorator('name', {
                                                    rules: [{
                                                        required: true,
                                                        message: locale.env_name_error_message
                                                    }]
                                                })(<Input allowClear placeholder={locale.env_placeholder} />)}
                                            </Form.Item>
                                            <Form.Item label={locale.user_name} className='ml-2' style={{ width: '90%' }}>
                                                {getFieldDecorator('userName', {
                                                    rules: [{
                                                        required: true,
                                                        message: locale.username_error_message
                                                    }]
                                                })
                                                    (<Input allowClear placeholder={locale.username_placeholder} />)}
                                            </Form.Item>
                                            <Form.Item label={locale.password} hasFeedback className='ml-2' style={{ width: '90%' }}>
                                                {getFieldDecorator('password', {
                                                    rules: [{
                                                        required: true,
                                                        message: locale.password_error_message
                                                    }]
                                                })
                                                    (<span>
                                                        <Tooltip placement='bottomLeft' title={locale.caps_lock} visible={popConfirmPassword}>
                                                            <Input.Password allowClear type='password' placeholder={locale.password_placeholder} onClick={this.checkCapsLockOn}
                                                                onChange={this.checkCapsLockOn} /></Tooltip></span>)} 
                                            </Form.Item>
                                        </div>
                                        <div className='d-flex'>
                                            <Button icon='save' type='primary' className='mb-2 mt-2' disabled={isExcutionInprogress} style={{ marginLeft: '750px' }} htmlType='submit'>{locale.save}</Button>
                                        </div>
                                    </Form>
                                </Card>
                            </div>
                        </div>
                         <div className='row mt-3 mb-2' > 
                            <div className='col-12' >
                                <Card  className='card-background-color' elevation={4}>
                                    <a class='ui ribbon label' style={{ color: 'crimson', fontSize: 18, fontFamily: 'auto', fontWeigh: 'bold' }}>{locale.dbConfig_Table_Title}</a>
                                    { items.environmentList.length ? <Table className='config-table' columns={columns} dataSource={items.environmentList} striped bordered hover style={{ border: '0px solid #ccc' }} pagination={{ pageSize: 5 }} />
                                        : <Result title={locale.no_data}></Result>}
                                </Card>
                            </div>
                         </div> 
                    </div>
                    <div>
                       <ReactIsCapsLockActive>
                            {active => <span className='caps-checker' style={{ display: 'none' }}>{active ? 'active' : 'inactive'}</span>}
                        </ReactIsCapsLockActive>

                    </div>
                </Spin>
            </Drawer>
            
            
            }</Affix>
        </div>
        );
    }
}

const mapStateToProps = (state) => {
    const {dbConfigReducer,executorReducer} = state;
    return {
        openConfigDrawer: dbConfigReducer.openDbConfigDrawerState,
        items: dbConfigReducer.dbConfiguration,
        addItem: dbConfigReducer.addConfiguration,
        isLoading: dbConfigReducer.isDbLoading
		 };
};

const mapDispatchToProps = (dispatch) => {
    return {
        reduxHandleDbConfigDrawer: (data) => dispatch({ type: WATCH_OPEN_DB_CONFIG_DRAWER, data }),
        getAllEnvironmentConfig: () => dispatch({ type: WATCH_ENVIRONMENTS }),
        addEnvironmentConfig: (payload) => dispatch({ type: WATCH_ADD_ENVIRONMENT, payload }),
        deleteEnvironmentConfig: (payload) => dispatch({ type: WATCH_DELETE_ENVIRONMENT, payload })
    };
};

const DrawerDbConfigForm = Form.create()(Configuration);
export default connect(mapStateToProps, mapDispatchToProps)(DrawerDbConfigForm);
