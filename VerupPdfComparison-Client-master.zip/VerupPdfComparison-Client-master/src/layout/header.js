import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Alignment, Button, Classes, Navbar, Divider, NavbarGroup, NavbarHeading, Label } from "@blueprintjs/core";
import { WATCH_OPEN_PROFILE_DRAWER, WATCH_LANG_HANDLER } from '../reduxFlow/watcherActionTypes/internalWatchTypes.js';
import '../styles/header.css';
import { WATCH_OPEN_DB_CONFIG_DRAWER } from '../reduxFlow/watcherActionTypes/dbConfigurationWatchTypes';
import { Switch } from 'antd';
import locale from '../localization/dataCompareLocalization';

const styles = {
  iw_header: {
    color: "burlywood",
    fontSize: 30,
    fontFamily: "initial"
  },
  divider: {
    height: 20,
    backgroundColor: 'blanchedalmond',
    width: 2
  }
}

class Header extends Component {

  constructor(props) {
    super(props);
    this.state = {
    }
  }

  handleDbConfigDrawer = () => {
    const { openConfigDrawer, reduxHandleDbConfigDrawer } = this.props;
    reduxHandleDbConfigDrawer(!openConfigDrawer);
  }

  handleUserDrawer = () => {
    const { openDrawer, reduxHandleHeaderDrawer } = this.props;
    reduxHandleHeaderDrawer(!openDrawer);
  }
  changeLang = lang => {
    this.props.changeLang(lang);
    locale.setLanguage(lang);
  }

  render() {
    const { lang } = this.props;
    locale.setLanguage(lang);
    const { history } = this.props;
    return (
      <Navbar style={{ position: 'fixed' }}>
        <NavbarGroup align={Alignment.LEFT}>
          <div className={"iw_logo"} />
          <NavbarHeading style={styles.iw_header}>{locale.application_title}</NavbarHeading>
          <Divider style={styles.divider} />
          <Button className={`${Classes.MINIMAL} header-button-text`} icon="play" text={locale.job_executer} onClick={() => { history.push('/dataCompare') }} />
          <Button className={`${Classes.MINIMAL} header-button-text`} icon="database" text={locale.db_config} onClick={this.handleDbConfigDrawer} />
          <Button className={`${Classes.MINIMAL} header-button-text`} icon="automatic-updates" text={locale.results} onClick={() => { history.push('/results') }} />
        </NavbarGroup>
        <NavbarGroup align={Alignment.RIGHT}  >
          <Label style={{ color: 'white', marginTop: 13 }}>{locale.language}</Label>
          <Switch checkedChildren="ja" unCheckedChildren="en" className="ml-3 mt-0 mr-2" defaultChecked={lang === 'en' ? false : true} onChange={value => this.changeLang(value ? 'ja' : 'en')} />
          {/* <div className="bp3-input-group .modifier" style={{ marginRight: 10 }}>
            <span className="bp3-icon bp3-icon-search header-search"></span>
            <input className="bp3-input" type="search" placeholder={locale.search_header} dir="auto" />          </div>

          <Divider style={styles.divider} />
          <Button className={`${Classes.MINIMAL} header-button-text`} icon="user" onClick={this.handleUserDrawer} />
          <Button className={`${Classes.MINIMAL} header-button-text`} icon="notifications" />
          <Button className={`${Classes.MINIMAL} header-button-text`} icon="cog" />*/}

        </NavbarGroup>
      </Navbar>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    openDrawer: state.internal.getDrawerState,
    openConfigDrawer: state.dbConfigReducer.openDbConfigDrawerState,
    lang: state.internal.langSetting.lang
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    reduxHandleDbConfigDrawer: (data) => dispatch({ type: WATCH_OPEN_DB_CONFIG_DRAWER, data }),
    reduxHandleHeaderDrawer: (data) => dispatch({ type: WATCH_OPEN_PROFILE_DRAWER, data }),
    changeLang: lang => dispatch({ type: WATCH_LANG_HANDLER, lang })
  };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));