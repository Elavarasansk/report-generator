import React, { Component } from 'react';
import { Modal, Table, Pagination, Input, Button, Card, SettingOutlined, Icon, Tabs, Collapse, Spin, Select, Switch, Popover } from 'antd';
import '../styles/layout/DiffsComponent.css';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import ColumnSetting from './ColumnSetting';
import JsonDiffsComponent from './JsonDiffsComponent';
import { WATCH_DOWNLOAD_REPORT } from '../reduxFlow/watcherActionTypes/loadGridWatchTypes';
const FileSaver = require('file-saver');
import locale from '../localization/dataCompareLocalization';

class DiffsComponent extends Component {
    constructor(props) {
        super();
        this.state = {
            Differences: {},
            currentPage: 1,
            currentPageSize: 6,
            RowDetailVisible: false,
            initialColumnList: [],
            columnSettingVisible: false,
            viewData: "All Data",
            jsonVisible: false,
            selectedRow: {}

        }
        this.rowDiffs = {
            csv: [],
            mismatch: []
        };
        this.onPageChangeHandler = this.onPageChangeHandler.bind(this);
        this.onPageSizeInputBlurHandler = this.onPageSizeInputBlurHandler.bind(this);
        this.keyUpPageSizeHandler = this.keyUpPageSizeHandler.bind(this);
        this.onCancelRowDiffsHandler = this.onCancelRowDiffsHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this);
    }
    onPageChangeHandler(page) {
        this.setState({ currentPage: page })
    }
    onCancelHandler() {
        this.setState({ columnSettingVisible: false });
    }
    keyUpPageSizeHandler(event) {
        if (event.keyCode == 13) {
            this.onPageSizeInputBlurHandler(event);
        }
    }
    onCancelRowDiffsHandler() {
        this.setState({ RowDetailVisible: false });
    }
    onPageSizeInputBlurHandler(event) {
        if (event.target.value == '') { return; }
        var pageSize = (event.target.value > this.state.Differences.firstDataMap.length) ? this.state.Differences.firstDataMap.length : event.target.value;
        this.setState({ currentPageSize: pageSize });
    }
    getSelectedValues = (value) => {
        this.setState({ viewData: value, currentPage: 1 });
    }
    onSwitchChange = (checked) => {
        this.setState({ jsonVisible: checked });

    }
    onDownloadHandler = () => {
        const { downloadReport, downloadedReport } = this.props;
        const { selectedRow } = this.state;
        downloadReport(selectedRow);
        const { type } = downloadedReport;
        type ? FileSaver.saveAs(downloadedReport, 'Comparison.xlsx') : '';
    }
    static getDerivedStateFromProps(props, state) {
        const { Differences } = props;
        var DifferencesState = { ...Differences };
        if (state.viewData === "Conflicted Data") {
            var firstDataMap = DifferencesState.firstDataMap.filter((row, i) => DifferencesState.differenceIndexList[i].length != 0 && Object.keys(props.Differences.firstDataMap[i]).length !== 1 && Object.keys(props.Differences.secondDataMap[i]).length !== 1);
            DifferencesState.firstDataMap = firstDataMap;
            var secondDataMap = DifferencesState.secondDataMap.filter((row, i) => DifferencesState.differenceIndexList[i].length != 0 && Object.keys(props.Differences.firstDataMap[i]).length !== 1 && Object.keys(props.Differences.secondDataMap[i]).length !== 1);
            DifferencesState.secondDataMap = secondDataMap;
        }
        else if (state.viewData === "Inconsistent Data") {
            var firstDataMap = [];
            var secondDataMap = [];
            for (var i = 0; i < DifferencesState.firstDataMap.length; i++) {
                if (Object.keys(DifferencesState.firstDataMap[i]).length == 1 || Object.keys(DifferencesState.secondDataMap[i]).length == 1) {
                    firstDataMap.push(DifferencesState.firstDataMap[i]);
                    secondDataMap.push(DifferencesState.secondDataMap[i]);
                }
            }
            DifferencesState.firstDataMap = firstDataMap;
            DifferencesState.secondDataMap = secondDataMap;
        }
        return {
            Differences: DifferencesState,
            initialColumnList: props.initialColumnList,
            currentPage: (DifferencesState.firstDataMap != undefined) ? Math.ceil((state.currentPage > (DifferencesState.firstDataMap.length / state.currentPageSize)) ? DifferencesState.firstDataMap.length / state.currentPageSize : state.currentPage) : 1,
            viewData: props.visible ? state.viewData : "All Data",
            selectedRow: props.selectedRow,
            jsonVisible: props.visible ? state.jsonVisible : false
        }
    }
    render() {
        const columns = [];
        var csv1 = [], csv2 = [], Pages = 0;
        const { Panel } = Collapse;
        const { isDiffLoading } = this.props;
        const { Differences, currentPage, currentPageSize, initialColumnList, viewData, jsonVisible } = this.state;
        var popOver1, popOver2;
        if (!(Differences.firstDataMap === undefined)) {
            var actualColumnLength = 0;
            for (var i = 0; i < initialColumnList.length; i++) {
                if (Differences.firstHeaderList.includes(initialColumnList[i])) {
                    let singleColumn = {}
                    singleColumn.title = <div style={{ color: (Differences.secondHeaderList.includes(initialColumnList[i])) ? (Differences.primaryKeyList.includes(initialColumnList[i]) ? 'green' : 'black') : 'blue' }}>{initialColumnList[i]}</div>
                    singleColumn.dataIndex = initialColumnList[i];
                    singleColumn.key = initialColumnList[i];
                    singleColumn.width = 200;
                    var count = 0;
                    actualColumnLength++;
                    singleColumn.render = (text, record, row) => {
                        var column = count % actualColumnLength;
                        var currentRow = ((currentPage - 1) * currentPageSize) + row;
                        count++;
                        return {
                            props: {
                                style: { color: Differences.differenceIndexList[record.key].includes(columns[column].key) ? 'red' : 'black', height: 60, backgroundColor: (Object.keys(record).length > 1) ? "white" : "antiquewhite" }
                            },
                            children: <div>{text}</div>
                        }
                    }
                    columns.push(singleColumn);
                }
            }
            var columns2 = [];
            var actualColumnLength2 = 0;
            for (var i = 0; i < initialColumnList.length; i++) {
                if (Differences.secondHeaderList.includes(initialColumnList[i])) {
                    let singleColumn2 = {}
                    singleColumn2.title = <div style={{ color: (Differences.firstHeaderList.includes(initialColumnList[i])) ? (Differences.primaryKeyList.includes(initialColumnList[i]) ? 'green' : 'black') : 'blue' }}>{initialColumnList[i]}</div>
                    singleColumn2.dataIndex = initialColumnList[i];
                    singleColumn2.key = initialColumnList[i];
                    singleColumn2.width = 200;
                    var count2 = 0;
                    actualColumnLength2++;
                    singleColumn2.render = (text, record, row) => {

                        var column2 = count2 % actualColumnLength2;
                        var currentRow2 = ((currentPage - 1) * currentPageSize) + row;
                        count2++;
                        return {
                            props: {
                                style: { color: Differences.differenceIndexList[record.key].includes(columns2[column2].key) ? 'red' : 'black', height: 60, backgroundColor: (Object.keys(record).length > 1) ? "white" : "antiquewhite" }
                            },
                            children: <div>{text}</div>
                        }
                    }
                    columns2.push(singleColumn2);
                }
            }
            var currentRowStart = (currentPage - 1) * currentPageSize;
            Pages = (currentPageSize != 0) ? Differences.firstDataMap.length / currentPageSize : 0;
            var endCount = (currentPageSize > (Differences.firstDataMap.length - currentRowStart)) ? (Differences.firstDataMap.length - currentRowStart) : currentPageSize;
            if (Differences.firstDataMap.length > 0) {
                for (var i = 0; i < endCount; i++) {
                    csv1.push(Differences.firstDataMap[currentRowStart + i]);
                    csv2.push(Differences.secondDataMap[currentRowStart + i]);
                }
            }

            let firstTableCount = this.props.Differences.firstDataMap.filter((row) => Object.keys(row).length !== 1).length;
            let secondTableCount = this.props.Differences.secondDataMap.filter((row) => Object.keys(row).length !== 1).length;
            let firstMissingCount = this.props.Differences.firstDataMap.length - firstTableCount;
            let secondMissingCount = this.props.Differences.secondDataMap.length - secondTableCount;
            popOver1 = <div >
                <div>{locale.total_records+" : " + firstTableCount}</div>
                <div>{locale.missing_records+" : " + firstMissingCount}</div>
            </div>;
            popOver2 = <div >
                <div>{locale.total_records+" : "  + secondTableCount}</div>
                <div>{locale.missing_records+" : "  + secondMissingCount}</div>
            </div>;
        }

        var viewDataList = ["All Data", "Conflicted Data", "Inconsistent Data"];
        return (
            <Spin style={{ marginTop: 250, marginLeft: 900, width: 300 }} tip='Downloading Results...' spinning={isDiffLoading}>
                <div style={{ marginTop: 70, marginLeft: 75, marginRight: 75, width: 1770 }} footer={null} onCancel={this.props.onCancel}>
                    <Card style={{borderRadius: 24}}>
                    <div style={{ float: "right", width: "100%" }}>
                        <Button type="primary" icon="download" style={{ float: 'right', marginBottom: 8 }} onClick={this.onDownloadHandler}>{locale.download_button} </Button>
                        <Select className="mb-2" value={viewData} style={{ float: 'right', marginRight: 16, width: 200 }} onChange={this.getSelectedValues}>
                            {viewDataList ? viewDataList.map(data => <Option value={data}>{data}</Option >) : ''}
                        </Select>
                        <label style={{ float: 'right', marginRight: 8, width: 80, marginTop: 4 }}>{locale.display_data} </label>
                        <Switch checked={jsonVisible} checkedChildren={locale.table} unCheckedChildren={locale.json} style={{ float: 'right', marginRight: 16, marginTop: 4 }} onChange={this.onSwitchChange}>
                        </Switch>
        <label style={{ float: 'right', marginRight: 8, width: 64, marginTop: 4 }}>{locale.view_type}</label>
                        {this.state.jsonVisible ? null : <Button icon="setting" type="link" style={{ float: "right", marginRight: 16, marginBottom: 0 }} title="Column Settings" onClick={() => { this.setState({ columnSettingVisible: true }) }}></Button>}
                        <Button type="primary" icon="arrow-left" style={{ float: "left" }} onClick={this.props.onBack}>{locale.back}</Button>
                    </div>
                    <div style={{ width: "100%", float: "right" }}>
                        <div style={{ float: 'left', display: "inline-block", width: "48%" }}> <h3 style={{ float: 'left' }}>V36</h3><h6 style={{ display: 'inline-block', marginRight: 642, marginTop: 6 }}> (192.168.41.170) </h6> <Popover placement="leftTop" content={popOver2} title={locale.stats}><Button style={{ float: 'right' }} icon="info" shape="circle" type="primary" /></Popover></div>
                        <div style={{ float: 'right', width: "48%" }}> <h3 style={{ float: 'left' }}>V40</h3><h6 style={{ display: 'inline-block', marginRight: 648, marginTop: 6 }}> (192.168.50.174) </h6> <Popover placement="leftTop" content={popOver1} title={locale.stats}><Button style={{ float: 'right' }} icon="info" shape="circle" type="primary" /></Popover></div>
                    </div>
                    <div className={jsonVisible ? "DiffsInVisible" : "DiffsVisible"}>
                        <div style={{ width: "100%", float: "right" }}>
                            <div className='leftTable' >
                                <Table rowClassName={(record, index) => { return "heightClass" }} style={{ width: 850, height: 642 }} scroll={{ x: initialColumnList.length * 100, y: 620 }} bordered={true} dataSource={csv2} columns={columns2} />
                            </div>
                            <div className='rightTable'>
                                <Table rowClassName={(record, index) => { return "heightClass" }} style={{ width: 850, height: 642 }} scroll={{ x: initialColumnList.length * 100, y: 620 }} bordered={true} dataSource={csv1} columns={columns} />
                            </div>
                        </div>
                        <div style={{ float: "right", width: "100%", marginTop: 32 }}>
                            <Pagination style={{ marginTop: 16, textAlign: "center" }} pageSize={1} current={currentPage} total={Math.ceil(Pages)} onChange={this.onPageChangeHandler} />
                        </div>
                        <ColumnSetting visible={this.state.columnSettingVisible} onCancel={this.onCancelHandler} />
                    </div >
                    <div className={jsonVisible ? "DiffsVisible" : "DiffsInVisible"} style={{ float: "right", width: "100%" }}>
                        <Card>
                            <div style={{ width: 1450, marginTop: 100, marginLeft: 75, marginRight: 75 }} width='90%' className="acediff"> </div>
                            {jsonVisible ? <JsonDiffsComponent firstDataMap={this.state.Differences.firstDataMap} secondDataMap={this.state.Differences.secondDataMap}> </JsonDiffsComponent> : null}
                        </Card>
                    </div>
                    </Card>
                </div>
            </Spin>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        Differences: state.getDifferenceData.differenceData,
        isDiffLoading: state.getDifferenceData.isDiffLoading,
        initialColumnList: state.getDifferenceData.initialColumnList,
        downloadedReport: state.getDownloadedReport.downloadedReport,
        lang: state.internal.langSetting.lang
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        downloadReport: (params) => {
            dispatch({ type: WATCH_DOWNLOAD_REPORT, params });
        },
        changeLang: lang => dispatch({ type: WATCH_LANG_HANDLER, lang })
        
    }
}
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(DiffsComponent))