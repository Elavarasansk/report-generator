import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { Table, Button, Card,Spin,Input,Tag,Icon,DatePicker } from 'antd';
import '../styles/layout/ExecutorResults.css'
import locale from '../localization/dataCompareLocalization';
import {WATCH_RESULT_GRID} from '../reduxFlow/watcherActionTypes/ResultsWatchTypes'
import {WATCH_GET_RESULTS,WATCH_RESET_DIFFERENCES} from '../reduxFlow/watcherActionTypes/loadGridWatchTypes'
import DiffsComponent from './DiffsComponent'
import { WATCH_DOWNLOAD_REPORT } from '../reduxFlow/watcherActionTypes/loadGridWatchTypes';
import Highlighter from 'react-highlight-words';
const FileSaver = require('file-saver');

class ExecutorResults extends Component {
    constructor(props){
        super(props);
        this.state={
            resultGridData:[],
            diffsVisible:false,
            filteredResults:[],
            filterValue:'',
            searchText:'',
            serachedColumn:''
        }
    }
    selectedRow={};
    componentDidMount(){
        const {loadResultsData} = this.props;
        
        loadResultsData();
    }
    static getDerivedStateFromProps(props, state) {
        if(props.resultGridData!=state.resultGridData){
            return{
                resultGridData:props.resultGridData,
                filteredResults:props.resultGridData
            }
        }else{
            return{
                filteredResults:state.filteredResults,
                filterValue:state.filterValue
            }
            
        }
        
    }
    getResultsHandler=(record)=>{
        const {getResults} =this.props;
        this.selectedRow=record;
        getResults(record);
        this.setState({diffsVisible:true})
    }
    downloadResultsHandler=(record)=>{
            const { downloadReport, downloadedReport } = this.props;
            downloadReport(record);
            const { type } = downloadedReport;
            type ? FileSaver.saveAs(downloadedReport, 'Comparison.xlsx') : '';
    }
    onBackHandler=()=>{
        const {resetDifferences} = this.props;
        resetDifferences();
        this.setState({diffsVisible:false})
    }
    filterjobs=(event,value)=>{
        let filteredResults=[];
        filteredResults=this.props.resultGridData.filter((data)=>data.apiJobId.search(value) !== -1 || data.apiJobName.search(value) !== -1);
        this.setState({filteredResults:filteredResults,filterValue:value});
    }
    getColumnSearchProps=dataIndex=>({
        filterDropdown:({setSelectedKeys,selectedKeys,confirm,clearFilters})=>(
            <div style={{padding:8}}>
                {dataIndex === 'executionTime'?<div><DatePicker format={'YYYY/MM/DD'} onChange={e=>{
                    let date=e.format("YYYY/MM/DD");
                    setSelectedKeys(date?[date]:[]);
                }
                    } style={{marginBottom:8}}/><br/></div>
                :<Input ref={node=>{this.searchInput=node;}} value={selectedKeys[0]} onChange={e=>setSelectedKeys(e.target.value?[e.target.value]:[])}
                    placeholder={locale.search+" "+locale[dataIndex]}
                    onPressEnter={()=>this.handleSearch(selectedKeys,confirm,dataIndex)}
                    style={{width:200,marginBottom:8,display:'block'}} />}
                  <Button style={{width:90,marginRight:8}} type="primary" onClick={()=>this.handleSearch(selectedKeys,confirm,dataIndex)} icon="search" size="small">{locale.search}</Button>
                  <Button onClick={()=>this.handleReset(clearFilters)} size ="small" >{locale.reset}</Button>
            </div>
        ),
        filterIcon:filtered=><Icon type="search" size='small' style={{color:filtered?'red':'black'}}/>,
        onFilter:(value,record)=>
            record[dataIndex].indexOf(value) === 0,
        render:(text)=>{
                return <Highlighter highlightStyle={{backgroundColor:'#FEFF75'}} searchWords={[this.state.searchText]} autoEscape textToHighlight={text}/>
        },
        
    });
    handleSearch = (selectedKeys, confirm,dataIndex) =>{
        confirm();
        this.setState({ searchText: selectedKeys[0],serachedColumn:dataIndex });
      }
    handleReset=clearFilters=>{
        clearFilters();
        this.setState({searchText:''});
    }
    render(){
        let resultsColumns=[];
        const {diffsVisible,filteredResults} = this.state;
        const {isResultGridLoading} = this.props;
        
        resultsColumns[0]={
            key:'apiJobId',
            dataIndex:'apiJobId',
            title:locale.job_id,
            width:120,
            ...this.getColumnSearchProps('apiJobId')
        }
        resultsColumns[1]={
            key:'apiPtnCode',
            dataIndex:'apiPtnCode',
            title:locale.ptn_code,
            width:150,
            ...this.getColumnSearchProps('apiPtnCode')
        }
        resultsColumns[2]={
            key:'apiJobName',
            dataIndex:'apiJobName',
            title:locale.job_name,
            width:200,
            ...this.getColumnSearchProps('apiJobName')
        }
        resultsColumns[3]={
            key:'executionTime',
            dataIndex:'executionTime',
            title:locale.execution_time,
            sorter:(a,b)=> ''+a.executionTime.localeCompare(b.executionTime),
            width:200,
            ...this.getColumnSearchProps('executionTime')
        }
        resultsColumns[4]={
            key:'executionResult',
            dataIndex:'executionResult',
            title:locale.results,
            width:150,
            filters:[
                {text:'Success',value:'SUCCESS'},
                {text:'Failure',value:'FAILURE'}
            ],
            onFilter:(value,record)=>record.executionResult.indexOf(value) === 0,
            render:(data)=>{
                return(<div><Tag color={data === "SUCCESS"?"green":"red"}>{data}</Tag></div>)
            }
        }
        resultsColumns[5]={
            key:'viewResult',
            dataIndex:'viewResult',
            title:locale.result_view,
            width:100,
            render:(data,record)=>{
                return(<div>{record.executionResult === "SUCCESS"? <Button icon="eye" shape="circle" type="link" title="View Results" onClick={()=>this.getResultsHandler(record)}/>:"------"}</div>)
            }
        }
        resultsColumns[6]={
            key:'downloadResult',
            dataIndex:'downloadResult',
            title:locale.download_button,
            width:110,
            render:(data,record)=>{
                return(<div>{record.executionResult === "SUCCESS"? <Button icon="download" shape="circle" type="link" title="Download Results" onClick={()=>this.downloadResultsHandler(record)}/>:"------"}</div>)
            }
        }
        return(
             <Spin spinning={isResultGridLoading}>
            {!diffsVisible?<div style={{width:'70%'}}>
                <div style={{ marginTop: 65, marginLeft: 50 }} >
                    <Card style={{borderRadius: 24}} title={locale.results}>
                    <div>
                        {/* <Search value={filterValue} style={{width:360}}  placeholder="Search API_JOB_ID, API_JOB_NAME" enterButton onChange={(e)=>{this.filterjobs(event,event.target.value)}} />*/}
                    </div> 
                        <Table style={{marginTop:16}} bordered dataSource={filteredResults} columns={resultsColumns}></Table>
                    </Card>
                </div>
            </div>:null}
            {diffsVisible?<DiffsComponent visible={this.state.diffsVisible} onBack={this.onBackHandler} selectedRow={this.selectedRow}></DiffsComponent>:null}
             </Spin>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        loadResultsData: () => {
            dispatch({ type:  WATCH_RESULT_GRID});
        },
        getResults:(data)=>{
            dispatch({type:WATCH_GET_RESULTS,data})
        },
        resetDifferences:()=>{
            dispatch({ type: WATCH_RESET_DIFFERENCES });
        },
        downloadReport: (params) => {
            dispatch({ type: WATCH_DOWNLOAD_REPORT, params });
        }
        
    }
}
const mapStateToProps = (state) => {
    return {
        resultGridData:state.getResultGridData.resultGridData,
        isResultGridLoading:state.getResultGridData.isResultGridLoading,
        downloadedReport: state.getDownloadedReport.downloadedReport,
        lang: state.internal.langSetting.lang 
    }
}
export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(ExecutorResults));