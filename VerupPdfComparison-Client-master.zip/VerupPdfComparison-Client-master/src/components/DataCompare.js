import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { WATCH_LOAD_GRID, WATCH_SAVE_SELECTED_ROW, WATCH_RESET_DIFFERENCES, WATCH_GET_RESULTS } from '../reduxFlow/watcherActionTypes/loadGridWatchTypes';
import { Table, Button, Card, Spin, Input, Progress, Icon } from 'antd';
import Popconfirm from './PopupConfirm'
import '../styles/layout/DataCompare.css'
import DbConfigCard from './dbConfigCard';
import * as server from '../common/serverFile.js'
import { Stomp } from '@stomp/stompjs';
import Highlighter from 'react-highlight-words';
import locale from '../localization/dataCompareLocalization';
import { WATCH_LANG_HANDLER } from '../reduxFlow/watcherActionTypes/internalWatchTypes.js';
let stompClient = null;

class DataCompare extends Component {
    state = {
        gridData: [],
        popUpVisible: false,
        diffsVisible: false,
        filteredData: [],
        filterValue: "",
        currentModule: 'All',
        executionStatus: [],
        executionPercent: [],
        executionResult: []
    }
    selectedRow = {};
    constructor(props) {
        super(props);
        this.onClose = this.onClose.bind(this);
        this.onBackHandler = this.onBackHandler.bind(this);
    }
    static getDerivedStateFromProps(props, state) {
        if (props.loadData !== state.gridData) {
            let executionStatus;
            let executionPercent;
            let executionResult;
            if (props.loadData !== undefined) {
                executionStatus = new Array(props.loadData.length).fill(false);
                executionPercent = new Array(props.loadData.length).fill(0);
                executionResult = new Array(props.loadData.length).fill(false);
            }
            return {
                ...state,
                gridData: props.loadData,
                filteredData: props.loadData,
                executionStatus: executionStatus,
                executionPercent: executionPercent,
                executionResult: executionResult
            }
        }
        else {
            return {
                ...state,
                gridData: props.loadData,
                // filteredData:state.diffsVisible?props.loadData:state.filteredData,
                // filterValue:state.diffsVisible?"":state.filterValue,

            }
        }


    }
    componentDidMount() {
        const { loadGridData } = this.props;
        stompClient = new Stomp.client(server.webSocketUrl);
        stompClient.connect({}, () => {
            stompClient.subscribe('/topic/public', this.onMessageRecieved);
        });
        //loadGridData();
    }
    onMessageRecieved = (payload) => {
        const { executionPercent, executionStatus, executionResult } = this.state;
        let message = JSON.parse(payload.body);
        var key = message.key;
        var percent = parseInt(message.percentage);
        var result = message.result;
        var currentExecutionPercent = { ...executionPercent }
        if(result === "pass")
            currentExecutionPercent[key] = percent;
        var currentExecutionStatus = { ...executionStatus };
        if (percent < 100) {
            currentExecutionStatus[key] = true;
        } else {
            currentExecutionStatus[key] = false;
        }
        var currentExecutionResult = { ...executionResult };
        if (result === "pass")
            currentExecutionResult[key] = true;
        else {
            currentExecutionResult[key] = false;
             currentExecutionStatus[key] = false;
        }

        this.setState({ executionPercent: currentExecutionPercent, executionStatus: currentExecutionStatus, executionResult: currentExecutionResult });
    }

    onBackHandler() {
        const { resetDifferences } = this.props;
        resetDifferences();
        this.setState({ diffsVisible: false })
    }
    onClose() {
        this.setState({ popUpVisible: false });
    }
    filterjobs = (event, value) => {
        let filteredData;
        var moduleMatch = { 'CFM': '1', 'CCM': '3', 'CBM': '2', 'CAM': '4', 'COM': '9' };
        if (this.state.currentModule === 'All') {
            filteredData = this.props.loadData.filter((row) => row.apiJobName.search(value) !== -1 || row.apiJobId.search(value) !== -1);
        } else {
            filteredData = this.props.loadData.filter((row) => row.apiJobName.search(value) !== -1 || row.apiJobId.search(value) !== -1 && row.productId === moduleMatch[this.state.currentModule]);
        }

        this.setState({ filteredData: filteredData, filterValue: value })
    }
    getSelectedModule = (value) => {
        var filteredData = [];
        if (this.state.filterValue === '') {
            if (value === 'CBM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '2');
            } else if (value === 'CFM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '1');
            } else if (value === 'CCM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '3');
            } else if (value === 'CAM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '4');
            } else if (value === 'COM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '9');
            } else {
                filteredData = this.state.gridData;
            }
        } else {
            if (value === 'CBM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '2' && (row.apiJobName.search(this.state.filterValue) !== -1 || row.apiJobId.search(this.state.filterValue) !== -1));
            } else if (value === 'CFM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '1' && (row.apiJobName.search(this.state.filterValue) !== -1 || row.apiJobId.search(this.state.filterValue) !== -1));
            } else if (value === 'CCM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '3' && (row.apiJobName.search(this.state.filterValue) !== -1 || row.apiJobId.search(this.state.filterValue) !== -1));
            } else if (value === 'CAM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '4' && (row.apiJobName.search(this.state.filterValue) !== -1 || row.apiJobId.search(this.state.filterValue) !== -1));
            } else if (value === 'COM') {
                filteredData = this.state.gridData.filter((row) => row.productId === '9' && (row.apiJobName.search(this.state.filterValue) !== -1 || row.apiJobId.search(this.state.filterValue) !== -1));
            } else {
                filteredData = this.state.gridData;
            }
        }

        this.setState({ filteredData: filteredData, currentModule: value });
    }
    runHandler = (key) => {
        const { executionStatus, executionPercent } = this.state;
        var currentExecutionStatus = { ...executionStatus };
        currentExecutionStatus[key] = true;
        var currentExecutionPercent = { ...executionPercent };
        currentExecutionPercent[key] = 0;
        this.setState({ popUpVisible: false, executionStatus: currentExecutionStatus, executionPercent: currentExecutionPercent });
    }
    resultsHandler = (record) => {
        const { getResults } = this.props;
        getResults(record);
        this.setState({ diffsVisible: true });
    }
    getColumnSearchProps = dataIndex => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
            <div style={{ padding: 8 }}>
                <Input ref={node => { this.searchInput = node; }} value={selectedKeys[0]} onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    placeholder={locale.search +" "+ locale[dataIndex] }
                    onPressEnter={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
                    style={{ width: 200, marginBottom: 8, display: 'block' }} />
                <Button style={{ width: 90, marginRight: 8 }} type="primary" onClick={() => this.handleSearch(selectedKeys, confirm, dataIndex)} icon="search" size="small">{locale.search}</Button>
        <Button onClick={() => this.handleReset(clearFilters)} size="small" >{locale.reset}</Button>
            </div>
        ),
        filterIcon: filtered => <Icon type="search" size='small' style={{ color: filtered ? 'red' : 'black' }} />,
        onFilter: (value, record) =>
            record[dataIndex].indexOf(value) === 0,
        render: (text) => {
            return <Highlighter highlightStyle={{ backgroundColor: '#FEFF75' }} searchWords={[this.state.searchText]} autoEscape textToHighlight={text} />
        },

    });
    handleSearch = (selectedKeys, confirm, dataIndex) => {
        confirm();
        this.setState({ searchText: selectedKeys[0], serachedColumn: dataIndex });
    }
    handleReset = clearFilters => {
        clearFilters();
        this.setState({ searchText: '' });
    }
    render() {
        const { Search } = Input;
        const openExecuteDialog = (row) => {
            //console.log(row)
            this.selectedRow = row;
            this.setState({ popUpVisible: true })
        }
        const { diffsVisible, filterValue, filteredData, gridData, currentModule, executionStatus, executionPercent, executionResult } = this.state;
        const { isLoading,isDbLoading } = this.props;
        var arr = [];
        arr.push(this.state.gridData.data);
        var columns = [
            {
                key: 'apiJobId',
                title: locale.job_id,
                dataIndex: 'apiJobId',
                width: 200,
                ...this.getColumnSearchProps("apiJobId")
            },
            {
                key: 'apiPtnCode',
                title: locale.ptn_code,
                dataIndex: 'apiPtnCode',
                width: 200,
                ...this.getColumnSearchProps("apiPtnCode")
            },
            {
                key: 'apiJobName',
                title: locale.job_name,
                dataIndex: 'apiJobName',
                width: 300,
                ...this.getColumnSearchProps("apiJobName")
            },
            {
                key: 'productId',
                title: locale.module,
                dataIndex: 'productId',
                width: 200,
                filters: [
                    { text: 'CAM', value: '4' },
                    { text: 'CBM', value: '2' },
                    { text: 'CCM', value: '3' },
                    { text: 'CFM', value: '1' },
                    { text: 'COM', value: '9' },
                ],
                onFilter: (value, record) => record.productId.indexOf(value) === 0,
                render: (data) => {
                    var moduleMatch = { '1': 'CFM', '3': 'CCM', '2': 'CBM', '4': 'CAM', '9': 'COM' };
                    return { children: <div>{moduleMatch[data]}</div> }
                }
            },
            {
                title: locale.execute,
                key: 'EXECUTE',
                width: 125,
                render: (data, row) => (<div>
                    <Button title={Object.values(executionStatus).includes(true) ? "Another batch in execution.." : "Execute batch"} style={{ float: "left" }} disabled={Object.values(executionStatus).includes(true) ? true : false} shape="circle" className={(!executionStatus[row.key] || !executionResult[row.key]) ? "DiffsVisible" : "DiffsInVisible"} type="link" icon="play-circle" onClick={() => openExecuteDialog(row)} />
                    <Progress style={{ float: "left" }} width={40} type='line' status={executionResult[row.key] ? (executionPercent[row.key] == 100) ? "success" : "active" : "exception"} percent={executionPercent[row.key]} className={executionPercent[row.key] > 0 ? "DiffsVisible" : "DiffsInVisible"} />
                    {/* <Button title="View Results" type="link" size="large" icon="eye" className={(executionPercent[row.key]==100 && executionResult[row.key])?"DiffsVisible":"DiffsInVisible"} style={{ float: "right" }} onClick={()=>this.resultsHandler(row)}></Button>  */}
                    {/* <Button title="Error Details" icon="info" type="danger" size="small" className={(executionPercent[row.key] > 0 && !executionResult[row.key]) ? "DiffsVisible" : "DiffsInVisible"} style={{ float: "right", marginTop: 8 }} /> */}
                </div>
                )
            }
        ];
        var moduleList = ['All', 'CFM', 'CBM', 'CAM', 'COM', 'CCM'];
        return (
            <Spin spinning={isLoading || isDbLoading} >
                <div className="container-fluid">
                    <div className="row" style={{ marginTop: 65 }} >
                        <div className="col-9">
                            <Card style={{ borderRadius: 24 }} title={locale.job_executer}>
                                {/* <h3 style={{color:"black"}}>Job Details</h3> */}
                                {/* <Search  value={filterValue} placeholder="Search API_JOB_ID, API_JOB_NAME" enterButton style={{width:360,marginLeft:526,marginTop:8}} onChange={(e)=>{this.filterjobs(event,event.target.value)}} /> */}
                                {/* <label style={{marginLeft:300,marginTop:8 }}>Module</label> */}
                                {/* <Select className="mb-2" value={currentModule} style={{marginTop:8,width: 120,marginLeft:16 }} onChange={this.getSelectedModule}>

{moduleList ? moduleList.map(data => <Option value={data}>{data}</Option >) : ''}
</Select> */}
                                <Table rowKey={row => row.key} bordered columns={columns} dataSource={filteredData} style={{ marginTop: 4 }} pagination={{ pageSize: 10 }} />
                                {<Popconfirm visible={this.state.popUpVisible} onRun={this.runHandler} onClose={() => { this.setState({ popUpVisible: false }) }} selectedRow={this.selectedRow} />}
                            </Card>
                        </div>
                        <div className="col-3">
                            <DbConfigCard />
                        </div>

                    </div>
                </div>

                {/* <div style={{width:'60%',display:'inline-block'}}> */}
                {/* </div> */}


            </Spin>
        )
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        loadGridData: () => {
            dispatch({ type: WATCH_LOAD_GRID });
        },
        saveSelectedData: (data) => {
            dispatch({ type: WATCH_SAVE_SELECTED_ROW, data });
        },
        resetDifferences: () => {
            dispatch({ type: WATCH_RESET_DIFFERENCES });
        },
        getResults: (data) => {
            dispatch({ type: WATCH_GET_RESULTS, data })
        },
        changeLang: lang => dispatch({ type: WATCH_LANG_HANDLER, lang })

    }
}

const mapStateToProps = (state) => {
    return {
        loadData: state.getLoadedData.getGridData,
        moduleList: state.getLoadedData.getModuleList,
        diffsVisible: state.getDifferenceData.diffsVisible,
        isLoading: state.getLoadedData.isLoading,
        isDbLoading: state.dbConfigReducer.isDbLoading,
        lang: state.internal.langSetting.lang
    }
}

export default withRouter(
    connect(mapStateToProps, mapDispatchToProps)(DataCompare))
