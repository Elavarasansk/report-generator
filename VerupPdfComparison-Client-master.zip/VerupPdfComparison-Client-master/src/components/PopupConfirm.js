import React,{Component} from 'react';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { Modal ,Input,Typography, Button,Steps,Card,ALIGN_CENTER,Row,Col} from 'antd';
import '../styles/app.css'
import 'antd/dist/antd.css'
import locale from '../localization/dataCompareLocalization';
import { WATCH_CLICK_RESPONSE } from '../reduxFlow/watcherActionTypes/loadGridWatchTypes';
class PopupConfirm extends Component{
    constructor(props){
        super(props);
        this.state={
            selectedRow:{},
            diffsVisible:false,
            activeStep:0
        }
    }
    static getDerivedStateFromProps(props,state){
        return{
            ...state,
            selectedRow:props.selectedRow,
            activeStep:state.diffsVisible?state.activeStep:0
        }
    }
    render(){
        const{Step} =Steps;
        const sendData = () => {
            let v36envName=this.props.itemsMap.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true))[0].name;
            let v40envName=this.props.itemsMap.environmentList.filter((row)=>(row.environmentType==='VERSION_40' && row.currentEnvironment === true))[0].name;
            let runParams={
                dbVersionCompanyKey:v36envName,
                dbVersionWebKey:v40envName,
                ...this.state.selectedRow
            }
            this.props.sendData(runParams);
            this.props.onRun(this.state.selectedRow.key);
        }
        const{Text}=Typography;
        var apiJobId='';
        var apiJobName='';
        var apiPtnCode='';
        var batchParams;
        if(!(this.state.selectedRow ===undefined)){
            apiJobId=this.state.selectedRow.apiJobId;
            apiJobName=this.state.selectedRow.apiJobName;
            apiPtnCode=this.state.selectedRow.apiPtnCode;
           
        }

        return(
            <div>
            <Modal visible={this.props.visible} onCancel={this.props.onClose} footer={null} width="43%">

                <Card bordered={false} style={{ "textAlign": ALIGN_CENTER, height: "90%" }} >
                    <div><h5> <Text type="primary" color="blue">{locale.popup_title}</Text>  </h5> </div><br/>
                    <Row style={{marginTop :16}} > 
                    <Col span={4}>  <Text type="primary" >{locale.job_id}</Text> </Col>
                    <Col span={6}>  <Input type="text" value={locale.job_id} disabled /> </Col> <br />
                    </Row>
                    <Row style={{marginTop :8}}>
                    <Col span={4}>  <Text type="primary" >{locale.job_name}</Text></Col>
                    <Col span={6}>   <Input type="text" value={locale.job_name} disabled /></Col>
                    </Row>

                    <Row style={{marginTop :8}}>
                    <Col span={4}>   <Text type="primary" >{locale.ptn_code}</Text></Col>
                    <Col span={6}>   <Input type="text" value={locale.ptn_code} disabled /></Col>
                    </Row>
                    {/* <div style={{marginTop :8}}>
                        <Text type="primary" style={{ marginRight: 8 }}>EXTRA_PARAMETERS </Text>
                        <Input type="text" style={{ marginLeft: 18, maxWidth: 480 }}  placeholder="12345,test.csv,ACAP株式会社,テスト"/>
                        <Text type="string" style={{ marginRight: 8 }}> (Optional) </Text>
                    </div> */}
                    <Row style={{ marginTop: 16 }} >
                    <Col span={4}/>
                    <Col span={3}>  <Button onClick={sendData} type="primary">{locale.execute} </Button></Col>
                    <Col span={6}><Button style={{ marginLeft:8 }} onClick={this.props.onClose} type="danger">{locale.cancel}</Button>  </Col>
                    <Col span={16}/>
                    </Row>
                     </Card>
            </Modal>
        </div>

        )
    }
    
}
const mapStateToProps = (state) => {
    const {dbConfigReducer} =state
    return {
        itemsMap: dbConfigReducer.dbConfiguration,
        lang: state.internal.langSetting.lang 
    }
}

const mapDispatchToProps = (dispatch) => {
  
    return {

         sendData: (paramValues) =>
         {dispatch({ type: WATCH_CLICK_RESPONSE, paramValues })}
       
    }
}
export default withRouter(
    connect(mapStateToProps,mapDispatchToProps)(PopupConfirm))