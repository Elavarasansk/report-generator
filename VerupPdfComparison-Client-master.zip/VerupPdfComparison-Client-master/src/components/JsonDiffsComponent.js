import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import React, { Component } from 'react';
import AceDiff from 'ace-diff';
import 'ace-diff/dist/ace-diff.min.css';
import '../styles/layout/DiffsComponent.css';

class JsonDiffsComponent extends Component {
    constructor() {
        super();
        this.getContent = this.getContent.bind(this);
    }
    getContent = (data) => {
        let content = '';
        try {
            data.forEach(val => {
                let row = JSON.stringify(val) + "\n\n";
                content += row.replace(row.substr(row.indexOf("\"key\":\""), row.indexOf("\"", row.indexOf("\"key\":\"") + 7) - row.indexOf("\"key\":\"") + 1), "")
            });
            return content
        } catch (error) {
            return ''
        }
    }
    render() {
        let differ = new AceDiff({
            mode: "json",
            element: '.acediff',
            diffGranularity: 'broad',
            showDiffs: true,
            showConnectors: true,
            maxDiffs: 5000,
            left: {
                content: this.getContent(this.props.firstDataMap),
                editable: false,
                copyLinkEnabled: false
            },
            right: {
                content: this.getContent(this.props.secondDataMap),
                editable: false,
                copyLinkEnabled: false
            },
            classes: {
                diff: 'acediff__diffLine',
                connector: 'acediff__connector',
                newCodeConnectorLinkContent: '&#8594;',
                deletedCodeConnectorLinkContent: '&#8592;'
            },
        });
        differ.options.classes.gutterID = "acediff-gutter";
    return (<div  id="acediff-gutter" style={{ width: 1450, marginTop: 100, marginLeft: 75, marginRight: 75 }} width='90%'> </div>);
    }
}

export default withRouter(
    connect()(JsonDiffsComponent))
