import React,{Component, Children} from 'react';
import {Modal,Table,Checkbox,Input} from 'antd';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import {WATCH_COLUMN_SELECTION} from '../reduxFlow/watcherActionTypes/loadGridWatchTypes';
import locale from '../localization/dataCompareLocalization';
class ColumnSetting extends Component{
    constructor(props){
        super(props);
        this.state={
            data:{},
            selectedRowKeys:[],
            availableColoumn:[],
            selectAllCheckBoxFlag:false,
            filteredData:[],
            searchValue:''
        }
    }

    static getDerivedStateFromProps(props, state) {
        const {Differences,initialColumnList,fixedColumnList} = props;
        if(Differences.firstHeaderList != undefined){
            var availableColumns=[];
            Differences.primaryKeyList.forEach(element=>{
                availableColumns.push(element);
            });
            fixedColumnList.forEach(element => {
                if(!availableColumns.includes(element)){
                    availableColumns.push(element);
                }
            });
            Differences.firstHeaderList.forEach(element => {
                if(!availableColumns.includes(element)){
                    availableColumns.push(element);
                }
            });
            Differences.secondHeaderList.forEach(element=>{
                if(!availableColumns.includes(element)){
                    availableColumns.push(element);
                }
            });
            var availableColumnsData=[];
            for(var i=0;i<availableColumns.length;i++){
                    availableColumnsData.push({"key":i,"availableColoumn":availableColumns[i]});
            }
            var selectedRowKeys=[];
            for(var i=0;i<initialColumnList.length;i++){
                selectedRowKeys.push(availableColumns.indexOf(initialColumnList[i]))
            }
            if(!(props.visible)){
                var searchInput=document.getElementById("searchInput");
                if(searchInput)
                    searchInput.value="";
            }
            var selectAll= props.visible?(state.selectedRowKeys.length==availableColumns.length?true:false):(selectedRowKeys.length == availableColumns.length?true:false);
        }
        return {
            data:props.visible?state.data:availableColumnsData,
            selectedRowKeys:props.visible?state.selectedRowKeys:selectedRowKeys,
            selectAllCheckBoxFlag:selectAll,
            availableColoumn:availableColumns,
            filteredData:props.visible?state.filteredData:availableColumnsData,
            searchValue:props.visible?state.searchValue:''
        }
    }

    onSelectAll=(event)=>{
        let keys = [];
        if (event.target.checked) {
            keys = this.state.data.map((row) => { return row.key })
            this.setState({
                selectAllCheckBoxFlag: true,
                selectedRowKeys: keys,
            })
        } else {
            let fixedColumnKeys=[];
            this.state.availableColoumn.forEach((element,i) => {
                if(this.props.fixedColumnList.includes(element)){
                    fixedColumnKeys.push(i);
                }
            });
            this.setState({
                selectAllCheckBoxFlag: false,
                selectedRowKeys: fixedColumnKeys,
            })
        }

    } 
    filterColumnsNames=(event,value)=>{
        let filteredColumns=this.state.data.filter((row)=>row.availableColoumn.search(value) !== -1);
        this.setState({filteredData:filteredColumns,searchValue:value});
    }
    render(){
        const {visible} =this.props;
        const {Search} =Input;
        const {data,selectedRowKeys,selectAllCheckBoxFlag,filteredData,searchValue} =this.state;
        const onSelectChange=(event,row)=>{
            var keys=selectedRowKeys;
            if(event.target.checked){
                keys.push(row.key);
                this.setState({selectedRowKeys:keys});
            }
            else{
                var index=keys.indexOf(row.key);
                keys.splice(index,1);
                this.setState({selectedRowKeys:keys});
            }        
        }
        var columns=[];
        columns[0]={
            key:"select",
            dataIndex:"select",
            title:<Checkbox  onChange={this.onSelectAll} checked={selectAllCheckBoxFlag}>{locale.checkbox_select_all}</Checkbox> ,
            render:(data,row)=>{
                return(<span>
                    <Checkbox checked={selectedRowKeys.includes(row.key)} disabled={this.props.fixedColumnList.includes(row.availableColoumn)} onChange={(e)=>onSelectChange(e,row)}/>
                </span>)
                
        }   
        }
        columns[1]={
            key:"availableColoumn",
            dataIndex:"availableColoumn",
            title:locale.available_columns,
            render:(data,row)=>{
                    return {
                        props: {
                            style: {color:this.props.Differences.primaryKeyList.includes(data)?'green':(this.props.Differences.firstHeaderList.includes(data) && this.props.Differences.secondHeaderList.includes(data))?'black':'red'}
                        },
                        children: <div>{!(this.props.Differences.firstHeaderList.includes(data))?data+'(Column in V40 only)':(!(this.props.Differences.secondHeaderList.includes(data)))?data+'(Column in V36 only)':data}</div>
                    }
                }
        }
        const onChangeColumnSetting=()=>{
            var newSelectedColumn=[];
            const{selectedRowKeys,availableColoumn} =this.state;
            for(var i=0;i< selectedRowKeys.length;i++){
                newSelectedColumn.push(availableColoumn[selectedRowKeys[i]]);
            }
            this.props.saveSelectedColumns(newSelectedColumn);
            this.props.onCancel();
        }
        
        return(
            <div>
                <Modal visible={visible} onCancel={()=>{this.props.onCancel();}} onOk={()=>onChangeColumnSetting()}>
                    <Search  value={searchValue} placeholder={locale.search_columns} enterButton style={{width:240,marginLeft:125}} onChange={(e)=>{this.filterColumnsNames(event,event.target.value)}}/>
                    <Table bordered style={{marginTop:25}} columns={columns} dataSource={filteredData} pagination={{pageSize:8}}></Table>
                </Modal>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        Differences: state.getDifferenceData.differenceData,
        initialColumnList:state.getDifferenceData.initialColumnList,
        lang: state.internal.langSetting.lang,
        fixedColumnList:state.getDifferenceData.fixedColumnList
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        saveSelectedColumns: (data) => {
            dispatch({ type: WATCH_COLUMN_SELECTION,data });
        },
        changeLang: lang => dispatch({ type: WATCH_LANG_HANDLER, lang })
    }
}

export default withRouter(
    connect(mapStateToProps,mapDispatchToProps)(ColumnSetting))
