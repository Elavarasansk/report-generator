import React, { Component } from 'react';
import { Text } from '@blueprintjs/core';
import { Card, Alert, Select,Button, Spin } from 'antd';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { WATCH_SAVE_ENVIRONMENT_CARD } from '../reduxFlow/watcherActionTypes/dbConfigurationWatchTypes';
import { WATCH_LOAD_GRID} from '../reduxFlow/watcherActionTypes/loadGridWatchTypes';
import locale from '../localization/dataCompareLocalization';

class DbConfigCard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            currentV36Config: '',
            currentV40Config: '',
            itemsMap: {},
            items: [],
            alertFlag: false,
            savedConfig: {},
            v36Connection: '',
            v40Connection: ''
        }
    }

    static getDerivedStateFromProps(props, state) {
        const { savedConfig, itemsMap } = props
        if (itemsMap !== state.itemsMap) {
            return {
                ...state,
                itemsMap: itemsMap,
                items: itemsMap.environmentList,
                currentV36Config: itemsMap.environmentList.filter(data => data.environmentType === 'VERSION_36' && data.currentEnvironment === true).map(data => data.id)[0],
                currentV40Config: itemsMap.environmentList.filter(data => data.environmentType === 'VERSION_40' && data.currentEnvironment === true).map(data => data.id)[0],
                alertFlag: itemsMap.testChecker,
                v36Connection: props.itemsMap.VERSION_36 ? '' : 'v36 Environment',
                v40Connection: props.itemsMap.VERSION_40 ? '' : 'v40 Environment'
            }
        } else if (savedConfig !== state.savedConfig) {
            return {
                ...state,
                savedConfig: savedConfig,
                alertFlag: savedConfig.testChecker,
            }
        }
    }
    // componentDidUpdate(){
    //     const {loadGridData} = this.props;
    //     if(this.state.items.length !== 0){
    //         let v36Environment,v40Environment;
    //         if(this.state.items.filter((data)=>(data.id  === this.state.currentV36Config)).length>0)
    //             v36Environment= this.state.items.filter((data)=>(data.id  === this.state.currentV36Config))[0].name;
    //         if(this.state.items.filter((data=>(data.id === this.state.currentV40Config))).length>0)
    //             v40Environment= this.state.items.filter((data=>(data.id === this.state.currentV40Config)))[0].name;
    //         let environmentParam={
    //             dbVersionCompanyKey:v36Environment,
    //             dbVersionWebKey:v40Environment
    //         }
    //         if(environmentParam.dbVersionCompanyKey && environmentParam.dbVersionWebKey)
    //             loadGridData(environmentParam);
    //     }
    // }
    onSelect36Change = (value) => {
        this.setState({
            currentV36Config: value
        })
        let versionId = {
            versionId_36: value,
            versionId_40: this.state.currentV40Config
        };
        this.saveCurrentEnvironment(versionId);
        // const {loadGridData} = this.props;
        // if(this.state.items.length !== 0){
        //     let v36Environment,v40Environment;
        //     if(this.state.items.filter((data)=>(data.id  === value)).length>0)
        //         v36Environment= this.state.items.filter((data)=>(data.id  === this.state.currentV36Config))[0].name;
        //     if(this.state.items.filter((data=>(data.id === this.state.currentV40Config))).length>0)
        //         v40Environment= this.state.items.filter((data=>(data.id === this.state.currentV40Config)))[0].name;
        //     let environmentParam={
        //         dbVersionCompanyKey:v36Environment,
        //         dbVersionWebKey:v40Environment
        //     }
        //     if(environmentParam.dbVersionCompanyKey && environmentParam.dbVersionWebKey)
        //         loadGridData(environmentParam);
        // }
    }

    onSelect40Change = (value) => {
        this.setState({
            currentV40Config: value
        })
        let versionId = {
            versionId_36: this.state.currentV36Config,
            versionId_40: value
        };
        this.saveCurrentEnvironment(versionId)
    }

    saveCurrentEnvironment = (dataMap) => {
        const { saveCurrentEnvironment } = this.props;
        saveCurrentEnvironment(dataMap);
    }

    renderSelectItems = (data) => {
        return data.map((value, index) =>
            <Select.Option key={value} value={data[index].id}>{data[index].name}</Select.Option>
        )
    }

    setAlertMessage = (v36Select, v40Select) => {
        if (!v36Select.length && !v40Select.length) {
            return locale.database_both_check_env;
        } else if (!v36Select.length) {
            return locale.database_36_check_env;
        } else if (!v40Select.length) {
            return locale.database_40_check_env;
        } else {
            return locale.env_modal_content;
        }
    }

    render() {
        const { isDbLoading,isExcutionInprogress } = this.props;
        const { items, currentV36Config, currentV40Config, alertFlag } = this.state;
        const v36Select = items.filter(data => data.environmentType === 'VERSION_36');
        const v40Select = items.filter(data => data.environmentType === 'VERSION_40');
        let v36SelectElement = this.renderSelectItems(v36Select);
        let v40SelectElement = this.renderSelectItems(v40Select);

        return (
            //<Spin spinning={isDbLoading}>
            <Card title={locale.Db_Details} style={{borderRadius: 24}}>
                <div style={{ width: 351 }}>
                    <div className="d-flex">
                        {alertFlag ? <Alert message={(this.setAlertMessage(v36Select, v40Select))} type="error" showIcon /> : false}
                    </div>
                    <div className="row mt-3 mb-3">
                        <div className="ml-4">
                            <Text className="ml-2 mb-1 ml-auto mt-1 text-secondary">{'V36'}</Text>
                        </div>
                        <div className="col">
                            <Select value={currentV36Config} placeholder={'V36 '+locale.env_name} disabled={isExcutionInprogress} style={{ width: 240 }} onChange={this.onSelect36Change}>
                                {v36SelectElement}
                            </Select>
                        </div>
                    </div>
                    <div className="row mt-2 mb-2 mr-5"> 
                        <div className="ml-4">
                            <Text className="ml-2 mb-1 ml-auto mt-1 text-secondary">{'V40'}</Text>
                        </div>
                        <div className="col">
                            <Select value={currentV40Config} placeholder={'V40'+locale.env_name} disabled={isExcutionInprogress} style={{ width: 240 }} onChange={this.onSelect40Change}>
                                {v40SelectElement}
                            </Select>
                        </div>
                    </div>
                </div>
            </Card>
            //</Spin>
        )
    }
}

const mapStateToProps = (state) => {
    const { executorReducer, dbConfigReducer } = state
    return {
        itemsMap: dbConfigReducer.dbConfiguration,
        savedConfig: dbConfigReducer.savedConfiguration,
        isDbLoading: dbConfigReducer.isDbLoading,
        lang: state.internal.langSetting.lang
    };

};

const mapDispatchToProps = (dispatch) => {
    return {
        saveCurrentEnvironment: (payload) => dispatch({ type: WATCH_SAVE_ENVIRONMENT_CARD, payload }),
        loadGridData: (environmentParam) => {
            dispatch({ type: WATCH_LOAD_GRID,environmentParam });
        }
    };
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(DbConfigCard));