import { combineReducers } from 'redux';
import internal from './reducers/internalReducer';
import {getLoadedData,getSelectedRow} from './reducers/loadJobGridReducer'
import {getDifferenceData,getDownloadedReport} from './reducers/differenceReducer'
import {getResultGridData} from '../reduxFlow/reducers/resultsGridReducer'
import { dbConfigReducer } from  './reducers/dbConfigurationReducer';


export default combineReducers({
  internal,
  dbConfigReducer,
  getLoadedData,
  getSelectedRow,
  getDifferenceData,
  getDownloadedReport,
  getResultGridData
});
