import { put, takeLatest, call } from 'redux-saga/effects';
import { WATCH_CLICK_RESPONSE,WATCH_COLUMN_SELECTION,WATCH_RESET_DIFFERENCES,WATCH_DOWNLOAD_REPORT } from '../watcherActionTypes/loadGridWatchTypes';
import { postServer,downloadPostServer} from '../../common/serverFile';
import {REPORT_GENERATE_API,GET_REPORT_API} from '../serverConstants/loadJobGridServerConstants'
import { LOAD_DIFF_RESPONSE,SET_COLUMN_SELECTION,SET_LOAD_RESPONSE_STATE,LOAD_REPORT_DOWNLOAD} from '../reducerActionTypes/loadGridReducerTypes';
function* sendResponseSaga() {
    yield takeLatest(WATCH_CLICK_RESPONSE, function* (watchInfo) {
        try {
            var data = yield call(postServer, REPORT_GENERATE_API,watchInfo.paramValues);
		} catch (err){
			console.log(err);
		}

    });
   
}

function* saveColumnSelection(){
    yield takeLatest(WATCH_COLUMN_SELECTION, function* (watchInfo) {
        try {
            var columnList=[];
            columnList=watchInfo.data;
            yield put({ type:SET_COLUMN_SELECTION,columnList})
        }catch (err){
			console.log(err);
		}
    });
}

function* resetDifferences(){
    yield takeLatest(WATCH_RESET_DIFFERENCES, function* () {
        try {
            var diffData={
                displayListMap:{
                    initialDisplayList:[]
                }
            };
            yield put({ type:LOAD_DIFF_RESPONSE,diffData})
        }catch (err){
			console.log(err);
		}
    });
}

function* getReport(){
    
    yield takeLatest(WATCH_DOWNLOAD_REPORT, function* (watchInfo) {
        try{
            var data = yield call(downloadPostServer, GET_REPORT_API,watchInfo.params);

            yield put({type:LOAD_REPORT_DOWNLOAD,data})
        }catch (err){
			console.log(err);
		}
    });
}

export {
    sendResponseSaga,saveColumnSelection,resetDifferences,getReport
}
