import { put, takeLatest, call } from 'redux-saga/effects';
import { WATCH_LOAD_GRID,WATCH_SAVE_SELECTED_ROW,WATCH_GET_RESULTS } from '../watcherActionTypes/loadGridWatchTypes';
import { LOAD_GRID_STATE,SET_LOAD_STATE,LOAD_SELECTED_ROW,SET_LOAD_RESPONSE_STATE ,LOAD_DIFF_RESPONSE} from '../reducerActionTypes/loadGridReducerTypes';
import { LOAD_GRID_API ,GET_RESULTS_API} from '../serverConstants/loadJobGridServerConstants';
import { getServer,postServer} from '../../common/serverFile';


function* loadJobGridSaga() {
    yield takeLatest(WATCH_LOAD_GRID, function* (watchInfo) {
        yield put({ type: SET_LOAD_STATE});
        		const data = yield call(postServer, LOAD_GRID_API,watchInfo.environmentParam);
        		var gridData=data.data;
        		yield put({ type: LOAD_GRID_STATE, gridData});
    });
}
function* saveSelectedRow(){
    yield takeLatest(WATCH_SAVE_SELECTED_ROW,function*(data){
        yield put({type:LOAD_SELECTED_ROW,data});
    })
}
 function* getResultsForbatch(){
    yield takeLatest(WATCH_GET_RESULTS,function*(watchInfo){
        try {
            yield put({ type:SET_LOAD_RESPONSE_STATE})
            let data = yield call(postServer, GET_RESULTS_API,watchInfo.data);
            let diffData=data.data;
             yield put({ type: LOAD_DIFF_RESPONSE, diffData });
		} catch (err){
			console.log(err);
		}
    });
 }

export {
    loadJobGridSaga,saveSelectedRow,getResultsForbatch
}
