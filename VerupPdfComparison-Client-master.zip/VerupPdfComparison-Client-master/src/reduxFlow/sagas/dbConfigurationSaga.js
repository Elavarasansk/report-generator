import { message as AntMessage } from 'antd';
import { call, put, takeLatest } from 'redux-saga/effects';
import { LOAD_GRID_STATE,SET_LOAD_STATE} from '../reducerActionTypes/loadGridReducerTypes';
import { LOAD_GRID_API } from '../serverConstants/loadJobGridServerConstants';
import locale from '../../localization/dataCompareLocalization';

import {
	WATCH_ENVIRONMENTS,
	WATCH_ADD_ENVIRONMENT,
	WATCH_DELETE_ENVIRONMENT,
	WATCH_LANG_HANDLER,
	WATCH_OPEN_DB_CONFIG_DRAWER,
	WATCH_SAVE_ENVIRONMENT_CARD
} from '../watcherActionTypes/dbConfigurationWatchTypes.js';
import {
	getServer,
	postServer,
	deleteServer
} from '../../common/serverFile.js';
import {
	DB_CONFIG_DRAWER_STATE,
	CONFIG_ALL_ENVIRONMENT_STATE,
	CONFIG_ADD_ENVIRONMENT_STATE,
	SET_DB_LOADING_STATE,
	LANG_HANDLER_STATE,
	CONFIG_SAVE_ENVIRONMENT_STATE
} from '../reducerActionTypes/dbConfigurationReducerTypes.js';
import {
	GET_ALL_ENVIRONMENT,
	ADD_ENVIRONMENT,
	DELETE_ENVIRONMENT,
	SAVE_ENVIRONMENT
} from '../serverConstants/dbConfigurationConstants.js';

function insertDataErrorCheck(response) {
	if (response === null) {
		return AntMessage.error(locale.database_add_message);
	} else {
		return AntMessage.success(`${locale.database_message}${response.name}${locale.database_add_message}`);
	}
}

function deletedDataErrorCheck(response) {
	return AntMessage.success(`${locale.database_message}${response.name}${locale.database_delete_message}`);
}

function* watchOpenDbConfigDrawer() {
	try {
		yield takeLatest(WATCH_OPEN_DB_CONFIG_DRAWER, function* (watchInfo) {
			const { data } = watchInfo;
			yield put({ type: DB_CONFIG_DRAWER_STATE, response: data });
		});
	} catch (error) {
		console.log(error);
	}

};

function* getAllEnvironmentConfig() {
	try {
		yield takeLatest(WATCH_ENVIRONMENTS, function* () {
			yield put({ type: SET_DB_LOADING_STATE, response: true });
			const response = yield call(getServer, GET_ALL_ENVIRONMENT);
			yield put({ type: CONFIG_ALL_ENVIRONMENT_STATE, response });
			if(response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true)).length !== 0 && 
			response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_40' && row.currentEnvironment === true)).length !== 0){
				let envName=response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true))[0].name;
				yield put({ type: SET_LOAD_STATE});
				let environmentParam={dbVersionCompanyKey:envName};
        		const data = yield call(postServer, LOAD_GRID_API,environmentParam);
        		var gridData=data.data;
        		yield put({ type: LOAD_GRID_STATE, gridData});
			}
		});
	} catch (error) {
		console.log(error);
	}

};

function* addEnvironmentConfig() {
	try {
		yield takeLatest(WATCH_ADD_ENVIRONMENT, function* (action) {
			yield put({ type: SET_DB_LOADING_STATE, response: true });
			const result = yield call(postServer, ADD_ENVIRONMENT, action.payload);
			
			const response = yield call(getServer, GET_ALL_ENVIRONMENT);
			
			if(response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true)).length !== 0 && 
			response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_40' && row.currentEnvironment === true)).length !== 0){
				let envName=response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true))[0].name;
				yield put({ type: SET_LOAD_STATE});
				let environmentParam={dbVersionCompanyKey:envName};
        		const data = yield call(postServer, LOAD_GRID_API,environmentParam);
        		var gridData=data.data;
        		yield put({ type: LOAD_GRID_STATE, gridData});
			}
			yield put({ type: CONFIG_ADD_ENVIRONMENT_STATE, result });
			yield put({ type: CONFIG_ALL_ENVIRONMENT_STATE, response });
			return insertDataErrorCheck(result.data);
		});
	} catch (error) {
		console.log(error);
	}

}

function* deleteEnvironmentConfig() {
	try {
		yield takeLatest(WATCH_DELETE_ENVIRONMENT, function* (action) {
			yield put({ type: SET_DB_LOADING_STATE, response: true });
			const result = yield call(deleteServer, `${DELETE_ENVIRONMENT}/${action.payload}`)
			const response = yield call(getServer, GET_ALL_ENVIRONMENT);
			
			if(response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true)).length === 0 || 
			response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_40' && row.currentEnvironment === true)).length === 0){
				let gridData=[];
				yield put({ type: LOAD_GRID_STATE, gridData});
				
			}else{
				let envName=response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true))[0].name;
				yield put({ type: SET_LOAD_STATE});
				let environmentParam={dbVersionCompanyKey:envName};
        		const data = yield call(postServer, LOAD_GRID_API,environmentParam);
        		var gridData=data.data;
        		yield put({ type: LOAD_GRID_STATE, gridData});
			}
			yield put({ type: CONFIG_ALL_ENVIRONMENT_STATE, response });
			return deletedDataErrorCheck(result.data);
		});
	} catch (error) {
		console.log(error);
	}

}

function* watchLangHandler() {
	try {
		yield takeLatest(WATCH_LANG_HANDLER, function* (action) {
			const lang = action.lang;
			yield put({ type: LANG_HANDLER_STATE, lang });
		});
	} catch (error) {
		console.log(error);
	}
}

function* saveEnvironmentDetails() {
	try {
		yield takeLatest(WATCH_SAVE_ENVIRONMENT_CARD, function* (action) {
			yield put({ type: SET_DB_LOADING_STATE, response: true });
			const { data } = yield call(postServer, SAVE_ENVIRONMENT, action.payload);
			
			const response = yield call(getServer, GET_ALL_ENVIRONMENT);
			
			if(response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true)).length !== 0 && 
			response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_40' && row.currentEnvironment === true)).length !== 0){
				let envName=response.data.environmentList.filter((row)=>(row.environmentType==='VERSION_36' && row.currentEnvironment === true))[0].name;
				yield put({ type: SET_LOAD_STATE});
				let environmentParam={dbVersionCompanyKey:envName};
        		const data = yield call(postServer, LOAD_GRID_API,environmentParam);
        		var gridData=data.data;
        		yield put({ type: LOAD_GRID_STATE, gridData});
			}
			yield put({ type: CONFIG_SAVE_ENVIRONMENT_STATE, data });
			yield put({ type: CONFIG_ALL_ENVIRONMENT_STATE, response });
		});
	} catch (error) {
		console.log(error);
	}
}

export {
	watchOpenDbConfigDrawer,
	getAllEnvironmentConfig,
	addEnvironmentConfig,
	deleteEnvironmentConfig,
	watchLangHandler,
	saveEnvironmentDetails
}
