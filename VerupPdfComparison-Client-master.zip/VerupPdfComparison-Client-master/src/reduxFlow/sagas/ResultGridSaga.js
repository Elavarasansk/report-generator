import { put, takeLatest, call } from 'redux-saga/effects';
import { getServer,postServer} from '../../common/serverFile';
import {WATCH_RESULT_GRID} from '../watcherActionTypes/ResultsWatchTypes';
import {LOAD_RESULTS_GRID_API} from '../serverConstants/resultsGridServerConstatnts';
import {LOAD_RESULT_GRID_STATE,LOAD_RESULT_GRID_DATA} from '../reducerActionTypes/ResultsReducerTypes';

function* getResultGrid(){
    yield takeLatest(WATCH_RESULT_GRID,function* (){
        try{
            yield put({type:LOAD_RESULT_GRID_STATE})
            var resultData=yield call(getServer,LOAD_RESULTS_GRID_API);
            yield put({type:LOAD_RESULT_GRID_DATA,resultData});
        }catch(err){
            console.log(err);
        }
    });
}
export {getResultGrid};