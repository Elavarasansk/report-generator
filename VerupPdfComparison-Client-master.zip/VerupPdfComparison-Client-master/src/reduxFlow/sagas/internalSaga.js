import { put, takeLatest } from 'redux-saga/effects';
import { WATCH_OPEN_PROFILE_DRAWER ,WATCH_LANG_HANDLER} from '../watcherActionTypes/internalWatchTypes.js';
import { PROFILE_DRAWER_STATE ,STATE_LANG_HANDLER} from '../reducerActionTypes/internalReducerTypes.js';


function* watchOpenProfileDrawer() {
  yield takeLatest(WATCH_OPEN_PROFILE_DRAWER, function* (watchInfo){
    
    const { data } = watchInfo;
    yield put({ type: PROFILE_DRAWER_STATE, data });
  });
};

function* watchLangHandler() {
  yield takeLatest(WATCH_LANG_HANDLER, function* (action) {
    const lang = action.lang;
    yield put({ type: STATE_LANG_HANDLER, lang });
  });
}



export {
  watchOpenProfileDrawer,watchLangHandler
}
