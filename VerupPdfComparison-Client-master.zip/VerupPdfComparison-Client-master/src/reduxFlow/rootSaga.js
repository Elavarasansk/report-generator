import { all } from 'redux-saga/effects';
import { watchOpenProfileDrawer,watchLangHandler } from './sagas/internalSaga';
import {loadJobGridSaga, saveSelectedRow,getResultsForbatch} from '../reduxFlow/sagas/syncJobGrid';
import {sendResponseSaga,saveColumnSelection,resetDifferences,getReport} from '../reduxFlow/sagas/sendResponseSaga';
import {getResultGrid} from '../reduxFlow/sagas/ResultGridSaga';
import { 
	watchOpenDbConfigDrawer,
	getAllEnvironmentConfig,
	addEnvironmentConfig,
	deleteEnvironmentConfig,
	saveEnvironmentDetails } from "../reduxFlow/sagas/dbConfigurationSaga";

export default function* rootSaga() {
  yield all([
    watchOpenDbConfigDrawer(),
	  getAllEnvironmentConfig(),
	  addEnvironmentConfig(),
	  deleteEnvironmentConfig(),
    watchLangHandler(),
	  saveEnvironmentDetails(),
    watchOpenProfileDrawer(),
    loadJobGridSaga(),
    saveSelectedRow(),
    sendResponseSaga(),
    saveColumnSelection(),
    resetDifferences(),
    getReport(),
    getResultsForbatch(),
    getResultGrid()
  ]);
}
