const GET_ALL_ENVIRONMENT = '/getAllEnvironment';
const ADD_ENVIRONMENT = '/addEnvironment';
const DELETE_ENVIRONMENT = '/deleteEnvironment';
const SAVE_ENVIRONMENT = '/saveCurrentEnvironments';

export {
    GET_ALL_ENVIRONMENT,
    ADD_ENVIRONMENT,
    DELETE_ENVIRONMENT,
    SAVE_ENVIRONMENT
}
