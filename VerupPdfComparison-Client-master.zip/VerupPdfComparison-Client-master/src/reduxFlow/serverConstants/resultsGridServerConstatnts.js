const LOAD_RESULTS_GRID_API = '/getResultsData';

export{LOAD_RESULTS_GRID_API}