const LOAD_GRID_API = '/displayParameters';
const LOAD_MODULELIST_API="/getModuleList";
const SERVER_URL = 'http://192.168.57.53/';
const REPORT_GENERATE_API = '/reportGenerate';
const GET_REPORT_API='/downloadCsv';
const GET_RESULTS_API='/getData';
export {
    LOAD_GRID_API,
    LOAD_MODULELIST_API,
    REPORT_GENERATE_API,
    SERVER_URL,
    GET_REPORT_API,
    GET_RESULTS_API
}
