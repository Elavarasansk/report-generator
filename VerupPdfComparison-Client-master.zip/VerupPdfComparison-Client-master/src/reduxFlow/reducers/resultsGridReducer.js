import {LOAD_RESULT_GRID_DATA,LOAD_RESULT_GRID_STATE} from '../reducerActionTypes/ResultsReducerTypes';

const initialState={
    isResultGridLoading:false,
    resultGridData:[]
}

const getResultGridData = (state = initialState, action) => {
    const {type,resultData } = action;
    switch(type){
        case LOAD_RESULT_GRID_STATE:
            return{
                ...state,
                isResultGridLoading:true
            }
        case LOAD_RESULT_GRID_DATA:
            return{
                ...state,
                resultGridData:resultData.data,
                isResultGridLoading:false
            }
        default:
            return state;
    }
}
export{getResultGridData}