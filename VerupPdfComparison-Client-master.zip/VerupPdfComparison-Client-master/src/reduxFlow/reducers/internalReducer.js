import { combineReducers } from 'redux';
import { PROFILE_DRAWER_STATE,STATE_LANG_HANDLER  } from '../reducerActionTypes/internalReducerTypes';

const initialState = {
  lang:'ja'
 }

const getDrawerState = (state = false, action) => {
  const { type, data } = action;
  switch (type) {
    case PROFILE_DRAWER_STATE:
      return data;
    default:
      return state;
  }
};

const langSetting = (state = initialState, action) => {
  const { type} = action;
  switch (type) {
    case STATE_LANG_HANDLER:
      return {
        ...state,
        lang: action.lang}
    default:
      return state;
  }
};

export default combineReducers({
  getDrawerState,
  langSetting
});
