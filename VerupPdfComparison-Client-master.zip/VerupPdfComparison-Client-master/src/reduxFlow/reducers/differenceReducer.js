import { LOAD_DIFF_RESPONSE,SET_COLUMN_SELECTION,SET_LOAD_RESPONSE_STATE,LOAD_REPORT_DOWNLOAD } from '../reducerActionTypes/loadGridReducerTypes';

const initialState = {
    differenceData: {},
    isDiffLoading:false,
    differenceVisible:false,
    initialColumnList:[],
    fixedColumnList:[],
    downloadedReport:[]
}  
const getDifferenceData = (state = initialState, action) => {
    const { type, data,columnList,diffData } = action;
    switch (type) {
      case SET_LOAD_RESPONSE_STATE:
      return {
        ...state,
        isDiffLoading:true
      }
      case LOAD_DIFF_RESPONSE:
      return {
        ...state,
        differenceData:diffData,
        initialColumnList:diffData.displayListMap,
        fixedColumnList:diffData.displayListMap,
        isDiffLoading:false,
        differenceVisible:true
      }
      case SET_COLUMN_SELECTION:
      return{
        ...state,
        initialColumnList:columnList
      }
      default:
      return state;
    }
    

}

const getDownloadedReport=(state=initialState,action) =>{
  const { type, data } = action;
  switch(type){
    case LOAD_REPORT_DOWNLOAD:
    return{
      ...state,
      downloadedReport:action.data.data
    }
    default:
    return state;
  }
}
export {getDifferenceData,getDownloadedReport};