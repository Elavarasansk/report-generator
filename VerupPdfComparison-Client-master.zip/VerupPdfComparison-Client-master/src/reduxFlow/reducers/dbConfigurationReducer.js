import {
  DB_CONFIG_DRAWER_STATE,
  CONFIG_ADD_ENVIRONMENT_STATE,
  CONFIG_ALL_ENVIRONMENT_STATE,
  SET_DB_LOADING_STATE,
  LANG_HANDLER_STATE,
  CONFIG_SAVE_ENVIRONMENT_STATE
} from '../reducerActionTypes/dbConfigurationReducerTypes.js';

const initialState = {
  openDbConfigDrawerState: false,
  dbConfiguration: {
    environmentList: [],
    testChecker: false,
    VERSION_36: '',
    VERSION_40: ''
  },
  savedConfiguration: {
    testChecker: false
  },
  addConfiguration: [],
  isDbLoading: false,
  lang: 'ja'
}

const dbConfigReducer = (state = initialState, action) => {
  const { type, response, result } = action;

  switch (type) {
    case DB_CONFIG_DRAWER_STATE:
      return {
        ...state,
        isDbLoading: false,
        openDbConfigDrawerState: response
      }
    case CONFIG_ALL_ENVIRONMENT_STATE:
      return {
        ...state,
        isDbLoading: false,
        dbConfiguration: response.data
      }
    case CONFIG_ADD_ENVIRONMENT_STATE:
      return {
        ...state,
        isDbLoading: false,
        addConfiguration: result.data
      }
    case SET_DB_LOADING_STATE:
      return {
        ...state,
        isDbLoading: true
      }
    case LANG_HANDLER_STATE:
      return {
        ...state,
        lang: action.lang
      }
    case CONFIG_SAVE_ENVIRONMENT_STATE:
      return {
        ...state,
        isDbLoading: false,
        savedConfiguration: action.data
      }

    default:
      return state;
  }
}

export {dbConfigReducer};
