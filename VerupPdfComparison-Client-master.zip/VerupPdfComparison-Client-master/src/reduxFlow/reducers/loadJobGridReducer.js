import { LOAD_GRID_STATE, SET_LOAD_STATE,LOAD_SELECTED_ROW } from '../reducerActionTypes/loadGridReducerTypes';

const initialState = {
    getGridData: [],
    getModuleList:[],
    SelectedRow:{},
    isLoading:false,
    executionStatus:[]
}  

const getLoadedData = (state = initialState, action) => {
    const { type, gridData,data } = action;
    switch (type) {
      case SET_LOAD_STATE:
      return {
        ...state,
        isLoading:true
      }
      case LOAD_GRID_STATE:
      let executionStatus=new Array(gridData.length).fill(false);
      return {
        ...state,
        getGridData:gridData,
        isLoading:false,
        executionStatus:executionStatus
      }
       case LOAD_SELECTED_ROW:
       return {
         ...state,
         SelectedRow:data,
       }
      default:
      return state;
    }
}
const getSelectedRow=(state=initialState,action)=>{
  const{ type,data} = action;
  switch(type){
    case LOAD_SELECTED_ROW:
    return {
     ...state,
     SelectedRow:data,
    }
    default:
      return state;
  }
}

export {getLoadedData,getSelectedRow};