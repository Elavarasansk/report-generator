import React, { Component } from 'react';
import { Route, Switch, HashRouter,Redirect  } from 'react-router-dom';
import App from './app.js';
import Content from './layout/content';
import DataCompare from './components/DataCompare.js'
import ExecutorResults from './components/ExecutorResults'
import { CreateHashHistory } from 'history';
const history = CreateHashHistory;
class Navigator extends Component{
   render(){
      return(
        <HashRouter history={history}>
            <App>
              <Switch>
               <Route path='/' exact render={() => { return <Redirect to='/dataCompare'></Redirect> }} /> 
                <Route path='/content' component={Content} />
                <Route path='/dataCompare' component={DataCompare} />
                <Route path='/results' component={ExecutorResults}/>
              </Switch>
            </App>
        </HashRouter>
      );
   }
}
export default Navigator;