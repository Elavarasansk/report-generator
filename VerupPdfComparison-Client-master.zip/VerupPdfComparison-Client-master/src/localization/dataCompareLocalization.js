import LocalizedStrings from 'react-localization';
import language from './multilingual.json';

let dataCompareLocalization = new LocalizedStrings(language);

export default dataCompareLocalization
