const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CompressionPlugin = require('compression-webpack-plugin');

module.exports = {
   entry: ['babel-polyfill', './main.js'],
   output: {
      path: path.join(__dirname, '/bundle'),
      filename: 'index_bundle.js'
   },
   devServer: {
      inline: true,
      port: 2000,
      disableHostCheck:true,
      host:'localhost',
      allowedHosts:['localhost','127.0.0.1']
   },
   module: {
      rules: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
            query: {
               presets: ['es2015', 'react'],
               plugins: ['transform-class-properties']
            }
         },
         {
           test: /\.css$/i,
           use: ['style-loader', 'css-loader']
         },
         {
           test: /\.(woff(2)?|ttf|eot|svg|png|jpg|jfif)(\?v=\d+\.\d+\.\d+)?$/,
           use: [
             {
               loader: 'file-loader',
               options: {
                 name: '[name].[ext]',
                 outputPath: 'fonts/'
               }
             }
           ]
         }
      ]
   },
   devtool :'nosources-source-map',
   plugins:[
      new HtmlWebpackPlugin({
         template: './index.html'
      }),
      new CompressionPlugin(),
   ]
}