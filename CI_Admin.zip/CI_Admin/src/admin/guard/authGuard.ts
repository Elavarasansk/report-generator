import { Injectable, CanActivate, ExecutionContext,UnauthorizedException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { AccessTokenService } from '../access.token.service';


@Injectable()
export class AuthGuard implements CanActivate {
    
    constructor( private readonly accessTokenService : AccessTokenService){}
    
    canActivate(
            context: ExecutionContext,
    ): boolean | Promise<boolean> | Observable<boolean> {
        return this.validateRequest(context);
    }
    
    validateRequest = async( context: ExecutionContext ) => {
        const request = context.switchToHttp().getRequest();
        const { authorization } = request.headers;
        if(!authorization){
            return true;
        }
        const  data = await this.accessTokenService.getByToken(authorization);
        const diff = new Date().getTime() - data.created.getTime();
        const seconds = Math.floor(diff/1000);
        if(seconds > data.ttl){
            throw new UnauthorizedException('invalid access token');
        }
        return true;
    }
    
    
}