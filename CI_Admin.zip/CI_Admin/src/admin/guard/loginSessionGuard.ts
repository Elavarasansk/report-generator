import { Injectable, CanActivate, ExecutionContext,NotAcceptableException } from '@nestjs/common';
import { Observable } from 'rxjs';
import { AccessTokenService } from '../access.token.service';
import { UsersService } from "../../users/users.service";


@Injectable()
export class LoginSessionGuard implements CanActivate {
    
    constructor( private readonly accessTokenService : AccessTokenService,
                 private readonly usersService: UsersService ){}
    
    canActivate(
            context: ExecutionContext,
    ): boolean | Promise<boolean> | Observable<boolean> {
        return this.validateRequest(context);
    }
    
    validateRequest = async( context: ExecutionContext ) => {
        const request = context.switchToHttp().getRequest();
        const { username } = request.body;
        const loggedInUser = await this.usersService.findAlreadyLoggedInUser(username);
        if(loggedInUser.length > 0){
            throw new NotAcceptableException('Your account has been logged in some other system.');
        }
        return true;
    }
    
    
}