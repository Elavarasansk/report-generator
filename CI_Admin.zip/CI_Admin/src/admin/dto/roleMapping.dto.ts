import { ApiModelProperty } from "@nestjs/swagger";

export class RoleMappingDto {
  @ApiModelProperty()
  readonly principalId: string;

  @ApiModelProperty()
  readonly principalType: string;

  @ApiModelProperty()
  readonly roleId: object;
}
