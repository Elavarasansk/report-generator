import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AdminController } from "./admin.controller";
import { AdminService } from "./admin.service";
import { AccessTokenService } from "./access.token.service";
import { Utility } from ".././common/utility";
import { UsersModule } from "../users/users.module";
import { RoleSchema } from "./schemas/role.schema";
import { RoleMappingSchema } from "./schemas/roleMapping.schema";
import { AccessTokenSchema } from "./schemas/accessToken.schema";
import { RoleMappingService } from "./role.mapping.service";
import { RoleService } from "./role.service";


@Module({
  controllers: [AdminController],
  
  exports: [ AdminService,AccessTokenService,RoleMappingService,RoleService ],
  providers: [AdminService, Utility,AccessTokenService,RoleMappingService,RoleService],
  imports : [ UsersModule,
              MongooseModule.forFeature([{ name: "Role", schema: RoleSchema }]) ,
              MongooseModule.forFeature([{ name: "RoleMapping", schema: RoleMappingSchema }]),
              MongooseModule.forFeature([{ name: "AccessToken", schema: AccessTokenSchema }]
              )]
})
export class AdminModule {}
