import { Injectable } from "@nestjs/common";
import { Model, PassportLocalModel } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { IRole } from "./interface/role.interface";
import { async } from "rxjs/internal/scheduler/async";

@Injectable()
export class RoleService {
  constructor(@InjectModel("Role") private readonly roleModel: Model<IRole>) {}

  findByRoleList = async (val: string[]): Promise<IRole[]> => {
    return await this.roleModel
      .where("name")
      .in(val)
      .exec();
  };

  findByRole = async (val: string): Promise<IRole> => {
    return await this.roleModel.findOne({ name: val }).exec();
  };

  findByRoleId = async (val: object): Promise<IRole> => {
    return await this.roleModel.findById(val).exec();
  };

  findOne = async (options: object): Promise<IRole> => {
    return await this.roleModel.findOne(options).exec();
  };

  findAdminRole = async () => {
    const adminList = ["ci-admin"];
    return await this.roleModel
      .find()
      .where("name")
      .in(adminList)
      .select("id")
      .exec();
  };

  findAdminRoleId = async () => {
    const adminName = "ci-admin";
    const roleData = await this.roleModel.findOne({ name: adminName });
    return roleData._id;
  };
}
