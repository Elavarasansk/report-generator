import * as mongoose from "mongoose";



export const RoleMappingSchema = new mongoose.Schema({
    principalId:String,
    principalType:String,
    roleId : Object
   },{collection : 'RoleMapping'});


