import * as mongoose from "mongoose";



export const RoleSchema = new mongoose.Schema({
    _id: Object,
    name: String,
    modified: Date,
    created: Date
},{collection : 'Role'});


