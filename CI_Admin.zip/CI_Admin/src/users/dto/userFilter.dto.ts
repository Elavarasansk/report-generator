import { ApiModelProperty } from "@nestjs/swagger";


export class UserFilterDto {
    @ApiModelProperty()
    readonly username: string;
  
    @ApiModelProperty()
    readonly emailId: string;
  
    @ApiModelProperty()
    readonly isActive: boolean;
  
    @ApiModelProperty()
    readonly comments: string;
}


export class ReferDto {
    
    @ApiModelProperty()
    readonly keyword: string;
    
    @ApiModelProperty()
    readonly username: string;

    @ApiModelProperty()
    readonly userRole: string;

    @ApiModelProperty()
    limit: number;
    
    @ApiModelProperty()
    offset: number;

    @ApiModelProperty()
    columnName: string;
    
    @ApiModelProperty()
    sortType: number
}
