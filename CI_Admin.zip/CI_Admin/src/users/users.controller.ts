import {
  Controller,
  Get,
  Response,
  HttpStatus,
  Param,
  Body,
  Post,
  Request,
  Patch,
  Delete
} from "@nestjs/common";
import { ApiUseTags, ApiResponse, ApiBearerAuth } from "@nestjs/swagger";
import { UsersService } from "./users.service";
import { Utility } from ".././common/utility";
import { ResMessage } from ".././common/res.message";
import {validate, Contains, IsInt, Length, IsEmail, IsFQDN, IsDate, Min, Max} from "class-validator";
import  * as jwt from 'jsonwebtoken';
import * as config from "config";
import { UserFilterDto , ReferDto } from "./dto/userFilter.dto";


@ApiUseTags("user")
@Controller("user")
export class UsersController {
    constructor(
    private readonly usersService: UsersService,
    private readonly Utility: Utility
      ) {
  }
 
  @Get('view')
  public async findAll(
      @Response() res,
      @Request() req
      ) {
      try {
        const result = await this.usersService.findAll();
      return this.Utility.sendSucc(req,res,result,ResMessage.LOGOUT_SUCC);
      } catch (e){
      return this.Utility.sendErr(req,res,e);
      }
  }

  @Post('update/status')
  public async updateStatus(
      @Response() res,
      @Request() req,
      @Body() userFilterDto: UserFilterDto
      ) {
      try {
      const result = await this.usersService.updateActiveStatus(userFilterDto ,  req.headers.username);
      return this.Utility.sendSucc(req,res,result,ResMessage.USER_STATUS);
      } catch (e){
      return this.Utility.sendErr(req,res,e);
      }
  }
  
  @Post("fetch")
  public async getUserData(@Response() res, @Request() req,@Body() referDto:ReferDto){
      const userData = await this.usersService.fetchUserData(referDto);
      return this.Utility.sendSucc(req,res,userData,ResMessage.LIST_SUCC);
  } 
  
  
}
