import { Model, PassportLocalModel } from "mongoose";
import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { debug } from "console";
import { ResMessage } from ".././common/res.message";
import { IUsersService } from "./interfaces/iusers.service";
import { IUser , IComments } from "./interfaces/user.interface";
import { Utility } from "src/common/utility";
import { UserFilterDto,ReferDto } from "./dto/userFilter.dto";
import { USER_DEVICE_AGGREGATION ,USER_DEVICE_UNWIND,
    DEVICE_DEVICEUSER_AGGREGATION,
    DEVICE_DEVICEUSER_UNWIND
} from './aggregation/aggregation'


@Injectable()
export class UsersService  {
    constructor(
            @InjectModel("User") private readonly userModel: Model<IUser>,
            @InjectModel("comments") private readonly commentsModel: Model<IComments>,
            private readonly Utility: Utility
    ) {}
    findAll = async(): Promise<IUser[]> => {
        return await this.userModel.find().exec();
    }
    
    findOne = async(options: object): Promise<IUser> => {
        return await this.userModel.findOne(options).exec();
    }
    
    findOneAndUpdate = async(option1:object,option2:object):Promise<IUser> =>{
        return await this.userModel.findOneAndUpdate(option1,option2).exec();
    }
    
    updateOne = async(option1:object,option2:object):Promise<IUser> =>{
        return await this.userModel.updateOne(option1,option2).exec();
    }
    
    findById = async(ID: object): Promise<IUser> => {
        return await this.userModel.findById(ID).exec();
    }
    
    update = async(ID: number, newValue: IUser): Promise<IUser> => {
        const user = await this.userModel.findById(ID).exec();
        
        if (!user._id) {
            debug("user not found");
        }
        
        await this.userModel.findByIdAndUpdate(ID, newValue).exec();
        return await this.userModel.findById(ID).exec();
    }
    
    loadUser = async( searchList: object,roleMappingList : string[], sortList:object,offSet : number ,limit:number):Promise<IUser[]> => {
        return await this.userModel.find(searchList)
        .where("_id").in(roleMappingList)
        .skip(offSet)
        .limit(limit)
        .sort(sortList)
        .select("username")
        .select("emails.address")
        .select("active").exec();
    }
    
    getUserCount = async(searchList ,roleMappingList ) : Promise<number> => { 
        return await this.userModel.find(searchList).where("_id").in(roleMappingList).count().exec();
    }
    
    createComments = async(options : object ) :Promise<IComments> => {
        return await this.commentsModel.create(options);
    }
    
    delete = async(ID: number): Promise<string> => {
        try {
            await this.userModel.findByIdAndRemove(ID).exec();
            return "The user has been deleted";
        } catch (err) {
            debug(err);
            return "The user could not be deleted";
        }
    }
    
    updateActiveStatus = async(userFilterDto : UserFilterDto , loginUser : string) => {
        const userData = await this.userModel.find({username:userFilterDto.username}).exec();
        if( userData == null ){
            throw new NotFoundException(
                    `${userFilterDto.username} doesnt have a user access contact Admin team`
            );
        }else{
            const comments = await this.createComments({
                active: userFilterDto.isActive,
                created: new Date(),
                createdBy: loginUser,
                comments: userFilterDto.comments
            });
            
            const user = await this.findOneAndUpdate(
                    { username: userFilterDto.username },
                    { $set: { active: userFilterDto.isActive, updated: new Date() } }
            );
            const updatedUser = await this.updateOne({ username: user.username },
                    { $push: { comments: comments } });
            const emailAddress = updatedUser.emails && updatedUser.emails.length > 0
            ? updatedUser.emails[0].address: "";
            if (emailAddress && userFilterDto.isActive) {
                this.Utility.sendMail(
                        emailAddress,
                        ResMessage.ACTIVATE_SUBJECT,
                        ResMessage.ACTIVATE_MAIL_SUBJECT
                );
            }
            return updatedUser;
        }
    }
    
    
    fetchUserData = async( referDto : ReferDto ):Promise<any> => {
        let { keyword , limit,offset,columnName ,sortType } = referDto;
        keyword = keyword ? keyword : '';
        const match = {
                $match: {
                        'isDelete': false ,
                    $or : [ { 'username': { $regex: new RegExp(keyword, 'i') }} ,
                            {'device.name' :  { $regex: new RegExp(keyword, 'i')  }}  ]
                }
        };
        
        const projection =   {
                $project : {
                    username : '$username',
                    devicename : '$device.name',
                    status :'$device.active',
                    ciPoints :'$ciPoints'
                }   
        };  
        let sort : any = { created : -1 };
        
        if(columnName && columnName != ''){
            sort = { columnName : sortType };
        }
        
        const aggregate = [
                           USER_DEVICE_AGGREGATION ,
                           USER_DEVICE_UNWIND,
                           DEVICE_DEVICEUSER_AGGREGATION,
                           DEVICE_DEVICEUSER_UNWIND,
                           match,
                           projection ,
                           {$facet:{
                               "cond1" : [ {$group:{_id:null, count:{$sum:1}}} ],
                               "cond2" : [{ "$sort": sort },
                                          { '$skip': offset },
                                          { '$limit': limit } ]
                           
                           }},
                           {$project:{
                               count: "$cond1.count",
                               data: "$cond2"
                           }}
                           ];
        return await this.userModel.aggregate(aggregate).exec();
    }
    
    findAlreadyLoggedInUser = async (username :string) : Promise<any> => {
        const match = {
                $match: {
                           'isDelete': false ,
                    $and : [ { 'username':  username } ,
                            {'device.active' : true }  ]
                }
        };
        const aggregate = [ USER_DEVICE_AGGREGATION , USER_DEVICE_UNWIND,
                           DEVICE_DEVICEUSER_AGGREGATION,DEVICE_DEVICEUSER_UNWIND,
                           match];
        
        return await this.userModel.aggregate(aggregate).exec();

    }
    
}
