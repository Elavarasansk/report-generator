
 const  USER_DEVICE_AGGREGATION = {
        $lookup :{
            from  : 'deviceuser',
            localField : '_id',
            foreignField : 'userId',
            as : 'deviceuser'
        }
};

 const  USER_DEVICE_UNWIND = {
        $unwind : {
            path : '$deviceuser',
            preserveNullAndEmptyArrays: true
            
        }  
};

 const DEVICE_DEVICEUSER_AGGREGATION = {
        $lookup :{
            from  : 'device',
            localField : 'deviceuser.deviceId',
            foreignField : '_id',
            as : 'device'
        }

};

 const DEVICE_DEVICEUSER_UNWIND = {
        $unwind : {
            path : '$device',
            preserveNullAndEmptyArrays: true
        }  
};
 
 export {
     USER_DEVICE_AGGREGATION ,
     USER_DEVICE_UNWIND,
     DEVICE_DEVICEUSER_AGGREGATION,
     DEVICE_DEVICEUSER_UNWIND
 };
